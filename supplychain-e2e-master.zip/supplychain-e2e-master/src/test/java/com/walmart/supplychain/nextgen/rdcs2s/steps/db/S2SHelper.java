package com.walmart.supplychain.nextgen.rdcs2s.steps.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.zip.GZIPOutputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.mongodb.BasicDBObject;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.acc.S2SRDCSorterMsg;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.RDCDeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class S2SHelper {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	MongoUtil mongoUtil;

	@Autowired
	ObjectMapper objmapper;

	@Autowired
	SpringJmsUtils springJmsUtils;

	//	@Value("${s2s_sorter_topic_rdc}")
	//	String s2sSorterTopicRDC;

	@Autowired
	Environment environment;

	@Autowired
	TextParser textParser;

	Logger logger = LogManager.getLogger(this.getClass());

	private String deliveryNumberFieldName="deliveryNumber";
	private String offFulfillDBName="offline_fulfillment";
	private String collectionNameoffFull="offline_fulfillments";
	private String collectionNameoffDel="offline_delivery";
	private String returndeliveryStatus="deliveryStatus";

	private String containerFiledName="fulfillmentId";
	private String fulfillmentDBName="fulfillment_db";
	private String fulfillmentCollName="fulfillment_collection";
	private String fulfillmentUnitCollName="fulfillment_unit_collection";
	private String returnFulfillmentCollContainerStatus="fulfillmentStatus";
	private String returnFulfillmentUnitCollContainerStatus="fulfillmentUnitStatus";

	private String s2sUpdateContainerFiledName="eventId";
	private String s2sUpdateContainerStatus="containerStatusEnum";
	private String s2sUpdateDBName="s2s_update";
	private String s2sUpdateCollName="s2s_update";
	private String s2sUpdateMessageFieldName="s2sUpdateMessage";
	private static final String TESTFLOW_DATA="testFlowData";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(30,
			20);
	private Response getShipmentResponse;
	private Response postShipmentResponse;
	JsonUtils jsonUtils = new JsonUtils();
	PropertyResolver propertyResolver = new PropertyResolver();

	public void prepareTestFLowData() throws JsonProcessingException {
		TestFlowDataMain root = new TestFlowDataMain();
		TestFlowData testflowData = new TestFlowData();
		root.setTestFlowData(testflowData);
		ObjectMapper om = new ObjectMapper();
		threadLocal.get().put(TESTFLOW_DATA, om.writeValueAsString(root));
	}

	public void placeEcomFlieInLinuxLocation() throws ParseException, URISyntaxException, IOException, InterruptedException {
		String asnDocID=grenerateRadomNumber(7);
		String bolNumber=grenerateRadomNumber(10).concat(asnDocID);
		String asnDocDate=getCurrentDate();
		String parentLpn=grenerateRadomNumber(10).concat(grenerateRadomNumber(10));
		String childLpn1=grenerateRadomNumber(10).concat(grenerateRadomNumber(10));
		String childLpn2=grenerateRadomNumber(10).concat(grenerateRadomNumber(10));
		String childLpn3=grenerateRadomNumber(10).concat(grenerateRadomNumber(10));
		String childLpn4=grenerateRadomNumber(10).concat(grenerateRadomNumber(10));
		String testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));

		List<String> listOfChildContainers = new ArrayList<>();
		listOfChildContainers.add(childLpn1);
		listOfChildContainers.add(childLpn2);
		listOfChildContainers.add(childLpn3);
		listOfChildContainers.add(childLpn4);


		List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
		OutboundDetail outboundDetails=new OutboundDetail();

		outboundDetails.setBolNumber(bolNumber);
		outboundDetails.setAsnDocID(asnDocID);
		outboundDetails.setContainerIds(listOfChildContainers);
		RDCDeliveryDetail rdcDeliveryDetails = new RDCDeliveryDetail();
		rdcDeliveryDetails.setDeliveryNumber("");
		outboundDetails.setRdcDelievryDetails(rdcDeliveryDetails);
		listOfOutboundObj.add(outboundDetails);

		JSONArray listofOutboundJson = jsonUtils.converyListToJsonArray(listOfOutboundObj);
		testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listofOutboundJson,
				"$.testFlowData.outboundDetails");
		threadLocal.get().put(TESTFLOW_DATA, testFlowData);
		logger.info("testData {}", threadLocal.get().get(TESTFLOW_DATA));

		String ecomOriginalMssg = textParser.readTextFile(FileNames.S2S_RDC_ECOM_FILE_SRC_BASE);
		String ecomUpdatedMssg = ecomOriginalMssg.replaceAll("asn_doc_id", asnDocID);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("bol_number", bolNumber);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("asn_doc_date", asnDocDate);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("parent_lpn", parentLpn);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("child_lpn1", childLpn1);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("child_lpn2", childLpn2);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("child_lpn3", childLpn3);
		ecomUpdatedMssg = ecomUpdatedMssg.replaceAll("child_lpn4", childLpn4);
		logger.info("*******ecomUpdatedMssg**** \n"+ecomUpdatedMssg);
		textParser.writeIntoTextFile(FileNames.S2S_RDC_ECOM_FILE_SRC_UPDATED, ecomUpdatedMssg);
		Thread.sleep(3000);
		gzipAFile(FileNames.S2S_RDC_ECOM_FILE_SRC_UPDATED, FileNames.S2S_RDC_ECOM_FILE_SRC_UPDATED+".gz");
		Thread.sleep(3000);
		String userName = propertyResolver.getPropertyValue("s2s_ecom_username");
		String password = propertyResolver.getPropertyValue("s2s_ecom_password");
		String hostName = propertyResolver.getPropertyValue("s2s_ecom_hostname");
		transferFile(userName,password,hostName,FileNames.S2S_RDC_ECOM_FILE_SRC_UPDATED+".gz",FileNames.S2S_RDC_ECOM_FILE_DEST);
	}

	public void transferFile(String userName, String password, String hostName, String srcLoc,String destLoc) throws IOException, InterruptedException {
		String[] scpCmd = new String[]{"expect", "-c", String.format("spawn scp -r %s %s@%s:%s\n",System.getProperty("user.dir")+srcLoc, userName, hostName, destLoc)  +
				"expect \"?assword:\"\n" +
				String.format("send \"%s\\r\"\n", password) +
		"expect eof"};

		ProcessBuilder pb = new ProcessBuilder(scpCmd);
		logger.info("Run shell command: {}", Arrays.toString(scpCmd));
		Process process = pb.start();
		int errCode = process.waitFor();
		logger.info("Echo command executed, any errors? {}", (errCode == 0 ? "No" : "Yes"));
		Assert.assertEquals(ErrorCodes.S2S_RDC_ECOM_FILE_TRANSFER_FAILED,errCode, 0);
		
		clearZipFile(System.getProperty("user.dir")+srcLoc);
	}

	public long getCountofXDOCRecords(String deliveryNumber) throws SQLException {
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		return mongoUtil.getRecordCount(offFulfillDBName, collectionNameoffFull, searchQuery);
	}

	public  String getdeliveryStatus(String deliveryNumber) throws SQLException {
		String deliveryStatus=null;
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		List<String> deliveryStatusRes = mongoUtil.getDatafromDB(offFulfillDBName, collectionNameoffDel, searchQuery,returndeliveryStatus);
		if ((deliveryStatusRes!=null) && (!deliveryStatusRes.isEmpty())) {
			deliveryStatus= deliveryStatusRes.get(0);
			return deliveryStatus;
		}
		return deliveryStatus;
	}

	public  String getContainerFulfillmentColStatusFMDB(String deliveryNumber, String container) throws SQLException {
		String fulFillmentStatus=null;
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		searchQuery.append(containerFiledName, container);
		List<String> fulFillmentStatusRes = mongoUtil.getDatafromDB(fulfillmentDBName, fulfillmentCollName, searchQuery,returnFulfillmentCollContainerStatus);
		if ((fulFillmentStatusRes!=null) && (!fulFillmentStatusRes.isEmpty())) {
			fulFillmentStatus= fulFillmentStatusRes.get(0);
			return fulFillmentStatus;
		}
		return fulFillmentStatus;
	}

	public  String getContainerFulfillmentUnitColStatusFMDB(String deliveryNumber, String container) throws SQLException {
		String fulFillmentStatus=null;
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		searchQuery.append(containerFiledName, container);
		List<String> fulFillmentStatusRes = mongoUtil.getDatafromDB(fulfillmentDBName, fulfillmentUnitCollName, searchQuery,returnFulfillmentUnitCollContainerStatus);
		if ((fulFillmentStatusRes!=null) && (!fulFillmentStatusRes.isEmpty())) {
			fulFillmentStatus= fulFillmentStatusRes.get(0);
			return fulFillmentStatus;
		}
		return fulFillmentStatus;
	}

	public  int gets2sUpdateStatusCode(String container, String containerStatus) throws SQLException {
		String[] parseds2sUpdateRes=null;
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(s2sUpdateContainerFiledName, container);
		searchQuery.append(s2sUpdateContainerStatus, containerStatus);
		List<String> s2sUpdateRes = mongoUtil.getDatafromDB(s2sUpdateDBName, s2sUpdateCollName, searchQuery,s2sUpdateMessageFieldName);

		if ((s2sUpdateRes!=null) && (!s2sUpdateRes.isEmpty())) {
			String parseds2sUpdateResTemp = s2sUpdateRes.get(0);
			parseds2sUpdateRes = parseds2sUpdateResTemp.split("\\|");
			return Integer.parseInt(parseds2sUpdateRes[7]);

		}
		return 0;
	}

	public void publishSorterMssgOnSorterTopic(String sorterMsg) {
		springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ,Config.DC, environment.getProperty("s2s_sorter_topic_rdc"),
				sorterMsg);
	}
	public String contstructSorterMsg(String container) throws JsonProcessingException{
		S2SRDCSorterMsg sorterMsg = new S2SRDCSorterMsg();
		sorterMsg.setIntendedLane("068");
		sorterMsg.setActualLane("068");
		sorterMsg.setSorterId("lower-psc-server");
		sorterMsg.setMessageType("74");
		sorterMsg.setScannedLabel(container);
		sorterMsg.setEventTime("2019042612572254200");
		sorterMsg.setLabelStatus("NORMAL");
		sorterMsg.setMessageSeqNbr("3");
		sorterMsg.setDispositionQueueCnt("1");
		sorterMsg.setInductNumber("2");
		sorterMsg.setDispositionCode("C00");
		return objmapper.writeValueAsString(sorterMsg);
	}

	public boolean validateRDCS2SDeliveries(String deliveryNumber, Response response,List<String> containersInEcomTestFlow) {
		logger.info("Validating containers in IDM for delivery:{} at RDC", deliveryNumber);
		List<String> containersInDelivery = JsonPath.read(response.asString(), "$..containerLabels[*]");
		if ((containersInEcomTestFlow.size() != containersInDelivery.size())) {
			logger.info("Mismatch in contianer count in the delivery:{} at RDC", deliveryNumber);
			logger.info("Number of containers in Ecom:{}", containersInEcomTestFlow.size());
			logger.info("Number of containers in delivery:{}", containersInDelivery.size());
			return false;
		}
		else {
			for (String container : containersInEcomTestFlow) {
				if (!containersInDelivery.contains(container)) {
					logger.info("Mismatch in containers in the delivery:{} at RDC", deliveryNumber);
					logger.info("Container {} is not present in Delivery response", container);
					return false;
				}
			}
			return true;

		}
	}
	public Response s2sgetShipmentDetails(String asnDocID) {
		String idocGetShipmentBaseURL = environment.getProperty("idoc_getshipment_base_url");
		Failsafe.with(retryPolicy).run(() -> {
			getShipmentResponse = SerenityRest.given().relaxedHTTPSValidation().header("WMT-API-KEY",environment.getProperty("idoc_wmt-api-key")).when().get(idocGetShipmentBaseURL+"="+asnDocID);
			Assert.assertEquals(ErrorCodes.IDOC_UNABLE_TO_FETCH_ASN_FROM_IDOC, Constants.SUCESS_STATUS_CODE,getShipmentResponse.getStatusCode());
		});
		logger.info("IDOC :: Shipment details fetched successfully for asnDocID: "+asnDocID);
		return getShipmentResponse;

	}

	public void s2sPostShipmentDetails(String bolNumber,String asnDocID) throws InterruptedException {
		String postShipmentBody;
		postShipmentBody="{\"billOfLadingNumber\":\""+bolNumber.trim()+"\",\"message\":\"idocs/v2/shipment?shipmentNumber="+asnDocID.trim()+"\"}";
		logger.info("postShipmentBody: "+postShipmentBody);

		Failsafe.with(retryPolicy).run(() -> {
			postShipmentResponse = SerenityRest.given().body(postShipmentBody.trim()).contentType("application/json").when().post(environment.getProperty("idoc_postshipment_url"));
			postShipmentResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
		});
		Thread.sleep(4000);
		logger.info("IDOC :: Shipments details persisted in IDM Container table of RDC for s2s asnDocID:"+asnDocID);
	}

	public String grenerateRadomNumber(int inputDigits) {
		return String.valueOf(inputDigits < 1 ? 0 : new Random()
				.nextInt((9 * (int) Math.pow(10, inputDigits - 1)) - 1)
				+ (int) Math.pow(10, inputDigits - 1));
	}

	public String getCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");  
		LocalDateTime now = LocalDateTime.now();  
		return dtf.format(now); 
	}

	public void gzipAFile(String sourceFilePath, String destinatonZipFilePath) throws IOException{
		byte[] buffer = new byte[1024];
		FileOutputStream fileOutputStream = null;
		GZIPOutputStream gzipOuputStream = null;
		FileInputStream fileInput = null;
		try {
			fileOutputStream =new FileOutputStream(System.getProperty("user.dir")+destinatonZipFilePath);
			gzipOuputStream = new GZIPOutputStream(fileOutputStream);
			fileInput = new FileInputStream(System.getProperty("user.dir")+sourceFilePath);

			int bytesRead;

			while ((bytesRead = fileInput.read(buffer)) > 0) {
				gzipOuputStream.write(buffer, 0, bytesRead);
			}
		}
		finally {
			fileInput.close();
			gzipOuputStream.finish();
			gzipOuputStream.close();
		}
			

	}
	
	public void clearZipFile(String fileName) {
		File file = new File(fileName); 
        if(file.delete()) 
        { 
        	logger.info("File deleted successfully {}",fileName);
        } 
        else
        { 
        	logger.info("Failed to delete the file {}",fileName);
        } 
	}
}
