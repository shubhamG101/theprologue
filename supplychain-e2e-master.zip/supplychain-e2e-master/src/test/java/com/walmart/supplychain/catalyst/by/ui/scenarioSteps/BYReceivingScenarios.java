package com.walmart.supplychain.catalyst.by.ui.scenarioSteps;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.by.ui.steps.BYReceivingSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class BYReceivingScenarios {
	
	
	@Steps
	BYReceivingSteps byReceivingSteps;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	
	@Then("^user verifies inbound shipment status as \"([^\"]*)\" and equipment status as \"([^\"]*)\" in BY Web UI$")
	public void userVerifiesInboundShipmentStatus(String status1, String status2) throws Throwable {
		
		Thread.sleep(10000);
		if (status1.equalsIgnoreCase("Expected") && status2.equalsIgnoreCase("Expected") ) {
			byReceivingSteps.loginToBY();
		}
		else if (status1.equalsIgnoreCase("Receiving") && status2.equalsIgnoreCase("Receiving") ) {
			byReceivingSteps.loginToBY();
		}
		
		byUiHelper.navigateToMentionedMenu("RECEIVING");
		byUiHelper.navigateToMentionedTab("Inbound Shipment");
		
		byReceivingSteps.verifyInboundShipmentStatus(status1, status2);
	}
	
	@Then("^user verifies the check in location corresponding to the shipment$")
	public void validateCheckInDoor() {
		byUiHelper.navigateToMentionedTab("Door Activity");
		byReceivingSteps.gateInvalidationInBy();
	}
	
	@Then("^user verifies the assigned door location corresponding to the shipment$")
	public void validateAssignedDoor() {
		byUiHelper.navigateToMentionedTab("Door Activity");
		byReceivingSteps.doorvalidationInBy();
		
	}
	
	@Then("^user release the hold in BY Web UI$")
	public void userReleaseTheHoldInBYWebUi() throws Throwable {

		byUiHelper.navigateToMentionedMenu("WALMART - RECEIVING");
		byUiHelper.navigateToMentionedTab("Inventory");
		
		byReceivingSteps.performReleaseHold();

	}
}
