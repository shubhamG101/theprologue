
package com.walmart.supplychain.catalyst.receiving.oms.steps;

import static com.jayway.jsonpath.JsonPath.parse;
import static com.jayway.jsonpath.JsonPath.read;
import static net.serenitybdd.rest.SerenityRest.given;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.opencsv.CSVReader;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.witron.ChnText;
import com.walmart.framework.supplychain.domain.witron.ItemDesc;
import com.walmart.framework.supplychain.domain.witron.POLine;
import com.walmart.framework.supplychain.domain.witron.POLineDest;
import com.walmart.framework.supplychain.domain.witron.Vndorstc;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.CatalystItemDetails;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.witronutilities.WitronUtil;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.thor.manifestservices.steps.webservices.ManifestServicesHelper;

import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystCreatePO {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*].poNumber";
	private static final String GET_ITEM_NUMBERS = "$.testFlowData.poDetails[*].poLineDetails[*].itemNumber";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	private static final String XMLMOCKURLPATTERN = "/DCFIN/xmlMock/0";
	private static final String OMSMOCKURL = "oms_ep";
	boolean retry = false;
	Response itemMDMResponse;

	List itemLabelList = null;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	Environment environment;

	Response apiResponse;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	ManifestServicesHelper manifestServicesHelper;

	@Autowired
	DbUtils dbUtils;

	ObjectMapper om = new ObjectMapper();

	@Autowired
	PreRunCleanup preRunCleanup;

	@Autowired
	TextParser textParser;

	@Autowired
	WitronUtil witronUtil;

	Response response;

	private static String wireMockUrl = "http://10.74.87.4:8080";
	private static final String MOCKURLPATTERN = "/NEXTGEN/OMSPubSubGenericRead2/0";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String BOH = "boh";
	private static final String TOTAL_WEIGHT = "totalWeight";
	private static final String WAC = "wac";
	private static final String WAW = "waw";

	public String getReceiveDate(int i, String rotateType) {
		String yearMonth = null;
		if (rotateType.equals("3")) {
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.MONTH, 9);
			int year = calendar.get(Calendar.YEAR);
			int month = calendar.get(Calendar.MONTH);
			String monthString = null;
			String dateString = null;
			if (String.valueOf(month).length() == 1) {
				monthString = "0" + String.valueOf(month);
			} else {
				monthString = String.valueOf(month);
			}
			if (String.valueOf(i).length() == 1) {
				dateString = "0" + String.valueOf(i);
			} else {
				dateString = String.valueOf(i);
			}
			yearMonth = String.valueOf(year) + "-" + monthString + "-" + dateString;
		} else {
			Date currDate = new Date();
			DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
			yearMonth = desturl.format(currDate);
		}
		return yearMonth;
	}

	public void generateXmlMock(String jsonString, String poNbr) {
		try {
			jsonString = jsonString.replaceAll("OMPSRJ", "OMPSR2");
			JSONObject json1 = new JSONObject(jsonString);
			String xml = XML.toString(json1);
			logger.info(xml);

			JSONObject request = new JSONObject();
			JSONObject response = new JSONObject();
			JSONObject finalObj = new JSONObject();
			String newXml = manifestServicesHelper.format(xml, "0" + poNbr);

			request.put("urlPattern", XMLMOCKURLPATTERN + poNbr + ".*");
			request.put("method", "GET");
			logger.info(wireMockUrl + XMLMOCKURLPATTERN + poNbr + ".*");

			response.put("headers", new JSONObject().put("Content-Type", "application/xml"));

			JSONObject obj = null;
			response.put("status", "200");
			response.put("body", newXml);

			finalObj.put("request", request);
			finalObj.put("response", response);
			String UUid = javaUtil.getUUID();
			finalObj.put("id", UUid);
			finalObj.put("uuid", UUid);

			apiResponse = given().contentType("application/json; charset=utf-8").body(finalObj.toString()).when()
					.post(wireMockUrl + "/__admin/mappings");
			logger.info(apiResponse.getBody().asString());

		} catch (Exception e) {
			throw new AutomationFailure("Failed to Post xml Mock", e);
		}
	}

	@Step
	public void createcatalystPO(String flowType) throws JsonProcessingException {
		
		TestFlowDataMain root = new TestFlowDataMain();
		TestFlowData testFlowData = new TestFlowData();
		PoDetail poDetail = new PoDetail();
		List poList = new ArrayList();
		Reader reader = null;

		try {

			JSONObject releaseMessage = new JSONObject(jsonUtil.readFile("catalyst_po.json"));
			JSONObject OMPSRJsonObject = (JSONObject) releaseMessage.get("OMPSRJ");
			JSONObject dataJsonObj = (JSONObject) OMPSRJsonObject.getJSONArray("Data").get(0);
			JSONObject omsPoObj = (JSONObject) dataJsonObj.get("omspo");
			String dccc = (String) omsPoObj.get("dccc");
			logger.info(dccc);
			// logger.info(releaseMessage.toString(2));
			String testData = releaseMessage.toString(2);
			if (flowType.contentEquals("baseFlow")) {
				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + FileNames.CATALYST_OMS_PO_CREATION_DATA));
			}else if (flowType.contentEquals("haccpFlow")) {
				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + FileNames.CATALYST_OMS_HACCP_PO_CREATION_DATA));
			}
			else if (flowType.contentEquals("footprintFlow")) {
				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + FileNames.CATALYST_OMS_TIHI_PO_CREATION_DATA));
			}
			else if (flowType.contentEquals("bananaFlow")) {
				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + FileNames.CATALYST_OMS_BANANA_PO_CREATION_DATA));
			}
			else if (flowType.contentEquals("recallHoldFlow")) {
				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + FileNames.CATALYST_OMS_RECALL_HOLD_PO_CREATION_DATA));
			}
						

			CSVReader csvReader = new CSVReader(reader);
			String[] line;
			int i = 0;
			List poLineList = new ArrayList();
			List testFlowpoLineList = new ArrayList();
			List<String> uuIDList = new ArrayList();
			while ((line = csvReader.readNext()) != null) {
				if (i == 0) {
					i++;
					continue;
				}
				String promoInd = null;
				POLine poLine = new POLine();
				List pOLineDestList = new ArrayList();

				String itemresponse = getItemMDMDetailsForCatalyst(line[0]);
				
				DocumentContext parsedItemDetailsJson = JsonPath.parse(itemresponse);
				PoLineDetail lineDetail = new PoLineDetail();
				CatalystItemDetails itemDetails = new CatalystItemDetails();

				List<String> vnpk = parsedItemDetailsJson
						.read("$.foundSupplyItems..dcProperties..orderableQuantity.amount");
				List<String> whpk = parsedItemDetailsJson
						.read("$.foundSupplyItems..dcProperties..warehousePackQuantity.amount");
				List<String> palletTi = parsedItemDetailsJson.read("$.foundSupplyItems..palletTi");
				List<String> palletHi = parsedItemDetailsJson.read("$.foundSupplyItems..palletHi");
//				List<String> dept = parsedItemDetailsJson
//						.read("$.foundSupplyItems[*].supplierAgreement.department.number");

				lineDetail.setPoLineNumber(String.valueOf(i));
				lineDetail.setItemNumber(line[0]);
				lineDetail.setVnpk(String.valueOf(vnpk.get(0)));
				lineDetail.setWhpk(String.valueOf(whpk.get(0)));
				lineDetail.setTi(String.valueOf(palletTi.get(0)));
				lineDetail.setHi(String.valueOf(palletHi.get(0)));
				lineDetail.setPromoInd(line[9]);
				lineDetail.setPoVnpkQty(line[4]);
				lineDetail.setWhpkSellPrice(line[3]);
//				lineDetail.setCroInd(line[10]);
				lineDetail.setOsdrInd(line[14]);
				lineDetail.setRecvQty(Integer.parseInt(line[11]));
				lineDetail.setRejectQty(line[12]);
				lineDetail.setDamageQty(line[13]);
				lineDetail.setShortQty(line[15]);
				lineDetail.setProblemQty(line[16]);
				lineDetail.setproblemType(line[17]);
//				lineDetail.setDepartmentNumber(dept.get(0));
				List<String> orderableGtinList = parsedItemDetailsJson.read("$.foundSupplyItems[*].orderableGTIN");
				List<String> consumableGtinList = parsedItemDetailsJson.read("$.foundSupplyItems[*].consumableGTIN");
				lineDetail.setCaseUpc(orderableGtinList.get(0));
				lineDetail.setItemUpc(consumableGtinList.get(0));
				String variableInd = String.valueOf(((List) parsedItemDetailsJson
						.read("$.foundSupplyItems..dcProperties.supplyItem..weightFormatType.code")).get(0));
				if(flowType.contentEquals("invoice")) {
				String department = String.valueOf(((List) parsedItemDetailsJson
						.read("$.foundSupplyItems[*].supplierAgreement.department.number")).get(0));
				lineDetail.setDepartmentNumber(department);
				}
				if (variableInd.equals("F")) {
					lineDetail.setIsVariableWeight(false);
				} else {
					lineDetail.setIsVariableWeight(true);
				}

//				itemDetails.setMaxCube(String.valueOf(((List) parsedItemDetailsJson
//						.read("$.foundSupplyItems..dcProperties.shipGroup..maxCube.amount")).get(0)));
//				itemDetails.setMaxHeight(String.valueOf(((List) parsedItemDetailsJson
//						.read("$.foundSupplyItems..dcProperties.shipGroup..maxDimensions.height")).get(0)));
//				itemDetails.setMaxWeight(String.valueOf(((List) parsedItemDetailsJson
//						.read("$.foundSupplyItems..dcProperties.shipGroup..maxWeight.amount")).get(0)));
				itemDetails.setWarehouseRotationTypeCode(String.valueOf(((List) parsedItemDetailsJson
						.read("$.foundSupplyItems[*].dcProperties[*].warehouse.warehouseRotationType.code")).get(0)));
	//				itemDetails.setShipGroupId(String.valueOf(
	//						((List) parsedItemDetailsJson.read("$.foundSupplyItems..dcProperties.shipGroup..id")).get(0)));
//				itemDetails.setOutboundStackGroup(String.valueOf(((List) parsedItemDetailsJson
//						.read("$.foundSupplyItems..dcProperties.shipGroup..outboundStackGroup")).get(0)));
//				boolean ismerge = (boolean) ((List) parsedItemDetailsJson
//						.read("$.foundSupplyItems..dcProperties.shipGroup..isMergeable")).get(0);
//				itemDetails.setMergeable(ismerge);
				String weight=String.valueOf(
						((List) parsedItemDetailsJson.read("$.foundSupplyItems..dcProperties.supplyItem.tradeItems[*].weight.amount")).get(0));
				itemDetails.setWeight(weight);
				itemDetails.setHeight(String.valueOf(
						((List) parsedItemDetailsJson.read("$.foundSupplyItems..tradeItems..dimensions.height"))
								.get(0)));
				itemDetails.setWidth(String
						.valueOf(((List) parsedItemDetailsJson.read("$.foundSupplyItems..tradeItems..dimensions.width"))
								.get(0)));
				itemDetails.setDepth(String
						.valueOf(((List) parsedItemDetailsJson.read("$.foundSupplyItems..tradeItems..dimensions.depth"))
								.get(0)));

//				itemDetails.setWareHouseGroupCode(String.valueOf(
//						((List) parsedItemDetailsJson.read("$.foundSupplyItems..dcProperties..warehouse.groupCode"))
//								.get(0)));
//				
//				itemDetails.setWareHouseGroupCode("DD");
				
				
//				itemDetails.setWareHouseAreaCode(String.valueOf(((List) parsedItemDetailsJson
//						.read("$.foundSupplyItems..dcProperties..warehouse.warehouseArea.code")).get(0)));
				
//				itemDetails.setWareHouseGroupCode("8");
//				itemDetails.setSamePalletIndicator(String.valueOf(
//						((List) parsedItemDetailsJson.read("$.foundSupplyItems..dcProperties..samePalletIndicator"))
//								.get(0)));

				itemDetails.setReceiveDate(getReceiveDate(i,
						String.valueOf(((List) parsedItemDetailsJson
								.read("$.foundSupplyItems[*].dcProperties[*].warehouse.warehouseRotationType.code"))
										.get(0))));

				try {
					itemDetails.setXrefId(String.valueOf(
							((List) parsedItemDetailsJson.read("$.foundSupplyItems..inventoryItemXref..id")).get(0)));
				} catch (Exception IndexOutOfBoundException) {
					itemDetails.setXrefId("0");
				}
//				itemDetails.setProfiledWarehouseArea(String.valueOf(
//						((List) parsedItemDetailsJson.read("$.foundSupplyItems..dcProperties..profiledWarehouseArea"))
//								.get(0)));

				lineDetail.setCatalystItemDetails(itemDetails);
				testFlowpoLineList.add(lineDetail);

				Vndorstc vndrstc = new Vndorstc();
				vndrstc.setVndrstckidtxt(String.valueOf(javaUtil.randonNumberGenerator(5)));
				poLine.setVndrnbr("913913");
				poLine.setVndrdptnbr("94");
				poLine.setVndrseqnbr("3");
				poLine.setVnpkcbuomcd("CF");
				poLine.setVnpkcbqty(line[5]);
				poLine.setVnpkwtqty(line[6]);
				poLine.setVnpkwtqtyuomcd("LB");
				poLine.setVnpkqty(String.valueOf(vnpk.get(0)));
				poLine.setWhpkqty(String.valueOf(whpk.get(0)));
				poLine.setOpolnbr(String.valueOf(i));
				poLine.setSmppoind("N");
				poLine.setMancrtind("N");
				poLine.setPromobuyind(line[9]);
				poLine.setAcctgdptnbr("94");
				poLine.setItmnbr(line[0]);
				poLine.setPlthiqty(String.valueOf(palletTi.get(0)));
				poLine.setPlttiqty(String.valueOf(palletHi.get(0)));
				poLine.setChnlmthdcd("2");
				poLine.setVnpkcstamt(line[3]);
				poLine.setPolnstcd("800");
				poLine.setVndrstckid(vndrstc);
				ItemDesc itemDesc = new ItemDesc();
				itemDesc.setItm1dsctxt("mock description");

				ChnText chnTxt = new ChnText();
				chnTxt.setChnmthdtext("Staplestock");
				poLine.setItm1dsc(itemDesc);
				poLine.setChnmthtxt(chnTxt);
				poLine.setVnpkcbuomcd("US");

				POLineDest pOLineDest = new POLineDest();
				pOLineDest.setVnpkordqty(line[4]);
				pOLineDest.setWhpksellcostamt(line[3]);
				pOLineDestList.add(pOLineDest);
				poLine.setOmspolinedest(pOLineDestList);
				poLineList.add(poLine);

				if (line[9].equals("N")) {
					promoInd = "TURN";
				} else {
					promoInd = "DISTRO";
				}
				
				Map<String,String> averageMap=witronUtil.getBohWacWawTotalWeight(line[0],promoInd, lineDetail.getIsVariableWeight());
				lineDetail.setBoh(Integer.parseInt(averageMap.get(BOH)));
				lineDetail.setWac(Double.parseDouble(averageMap.get(WAC)));
				if(lineDetail.getIsVariableWeight()) {
				lineDetail.setWaw(Double.parseDouble(averageMap.get(WAW)));
				lineDetail.setTotalWeight(Double.parseDouble(averageMap.get(TOTAL_WEIGHT)));
				}
				
				DecimalFormat df = new DecimalFormat("#.###");
				double avgWeight=Double.parseDouble(weight);
				lineDetail.setAverageWeightPerCase(Double.parseDouble(df.format(avgWeight)));

				i++;
			}

			net.minidev.json.JSONArray listofPOLineJson = jsonUtil.converyListToJsonArray(poLineList);
			String updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofPOLineJson,
					"$.OMPSRJ.Data[*].omspo.omspol");
			logger.info(updatedtestflowdata);

			JSONObject request = new JSONObject();
			JSONObject response = new JSONObject();
			JSONObject finalObj = new JSONObject();
			int rand = javaUtil.randonNumberGenerator(8);
			generateXmlMock(updatedtestflowdata, String.valueOf(rand));
			logger.info(updatedtestflowdata);
			String newtestflowdata = manifestServicesHelper.format(updatedtestflowdata, "0" + rand);
			logger.info(newtestflowdata);
			request.put("urlPattern", MOCKURLPATTERN + rand + ".*");
			request.put("method", "GET");
			logger.info(wireMockUrl + MOCKURLPATTERN + rand + ".*");

			response.put("headers", new JSONObject().put("Content-Type", "application/json"));

			JSONObject obj = null;
			response.put("status", "200");
			response.put("body", newtestflowdata);

			finalObj.put("request", request);
			finalObj.put("response", response);
			String UUid = javaUtil.getUUID();
			finalObj.put("id", UUid);
			finalObj.put("uuid", UUid);

			apiResponse = given().contentType("application/json; charset=utf-8").body(finalObj.toString()).when()
					.post(wireMockUrl + "/__admin/mappings");
			logger.info(apiResponse.getBody().asString());
			JSONObject mockObject = new JSONObject(apiResponse.getBody().asString());
			String mockId = mockObject.getString("id");
			logger.info("UUID for Mock : {} ", mockId);
			uuIDList.add(mockId);

			poDetail.setPoNumber("0" + rand);
			poDetail.setSourceNumber(environment.getProperty("facility_num"));
			poDetail.setBaseDiv((String) omsPoObj.get("basediv"));
			poDetail.setSrcCountryCode((String) omsPoObj.get("dccc"));
			poDetail.setPoStatus((String) omsPoObj.get("postatcdtext"));
			poDetail.setPoLineDetails(testFlowpoLineList);
			poDetail.setUuid(uuIDList);
			poDetail.setZonetemperatures("-10.0#0.0#10.0");
			poList.add(poDetail);
			testFlowData.setPoDetails(poList);
			root.setTestFlowData(testFlowData);
			tl.get().put(TEST_FLOW_DATA, om.writeValueAsString(root));
			logger.info("testFlowdata:" + tl.get().get(TEST_FLOW_DATA));
			reader.close();
		} catch (Exception e) {
			throw new AutomationFailure("Failed to create Witron PO", e);
		}
	}
	
	public Headers getHeaders() {
		Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		Header securityId = new Header("WMT-Security-ID", environment.getProperty("wmt_security_id"));
		Header apiKey = new Header("api-key", environment.getProperty("item_mdm_api_key"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(securityId);
		headerList.add(apiKey);
		return new Headers(headerList);
	}

	public String getItemMDMDetailsForCatalyst(String itemNum) {

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().body("[" + itemNum + "]")
					.headers(getHeaders()).post(environment.getProperty("item_mdm_ep"));
			Assert.assertEquals(ErrorCodes.CATALYST_ITEM_FETCH_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}
	
	@Step
	public void populateOMSResponse() {

		PoDetail poDetail = new PoDetail();
		List poList = new ArrayList();

		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testData);
			DocumentContext context = null;
			net.minidev.json.JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toString();
			List<String> poNumberList = objectMapper.readValue(poString, new TypeReference<List<String>>() {
			});

			String poNbr = poNumberList.get(0);
			logger.info(environment.getProperty(OMSMOCKURL)+ poNbr);
			apiResponse = given().relaxedHTTPSValidation().when().get(environment.getProperty(OMSMOCKURL) + poNbr);
			Assert.assertEquals(ErrorCodes.Catalyst_GET_OMS, Constants.SUCESS_STATUS_CODE, apiResponse.getStatusCode());

		} catch (Exception e) {
			throw new AutomationFailure("Failed to fetch Witron PO Details", e);
		}

	}

}
