package com.walmart.supplychain.catalyst.by.ui.pages;


import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.framework.utilities.selenium.UiActionsHelper;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYOutboundPage extends SerenityHelper {
	
	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;
	
	@Autowired
	Environment endPoint;
	
	@Autowired
	UiActionsHelper uiActionsHelper;
	
	@Autowired
	BYReceivingPage byReceivingPage;
	
	

	
	
	//  ############## generic elements ##################
	
	
	private WebElement inputFilterBox(String tabName) {
		return getDriver().findElement(By.xpath("//div[contains(@id,'"+tabName+"')]//input[contains(@id,'Filter')][@style]")); 
	}
	
	private WebElement getButtonByText(String buttonText) {
		return getDriver().findElement(By.xpath("//a[normalize-space()='"+buttonText+"'][contains(@id,'button')]")); 
	}
	
	private WebElement getDropdownOption(String option) {
		return getDriver().findElement(By.xpath("//div[contains(@class,'floating')][not(contains(@style,'hidden'))]//span[normalize-space()='"+option+"']")); 
	}


	private WebElement filterCriteriaUnderDropdownMenu(String filterOption) {
		return getDriver().findElement(By.xpath("//span[normalize-space()='"+filterOption+"']/..")); 
	}
	
	
	
	
	
	
	
	
	// ########  Generic Actions on page elements   #########################################
	
	
	public void enterValueUnderFilterTextBox(String tabName, String value, String filterOption) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(inputFilterBox(tabName)).waitUntilVisible();
		String filterCriteria = filterOption + "=" + value;
		element(inputFilterBox(tabName)).clear();
		element(inputFilterBox(tabName)).sendKeys(filterCriteria);
		
		String filterOptionToSearch = "in " + filterOption;
		
		if(filterCriteriaUnderDropdownMenu(filterOptionToSearch).isDisplayed())
			filterCriteriaUnderDropdownMenu(filterOptionToSearch).click();
		
		else
			element(inputFilterBox(tabName)).sendKeys(Keys.ENTER);
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Entered the value {} to be filtered in filter box under {} tab ==========", value, tabName);
	}
	
	
	public void clickButtonByText(String buttonText) {
		element(getButtonByText(buttonText)).waitUntilVisible();
		element(getButtonByText(buttonText)).waitUntilClickable();
		element(getButtonByText(buttonText)).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Clicked {} button ==========", buttonText);
	}
	
	
	public void clickRefreshIconForDifferentOutboundTabs(String tabName) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement refreshIcon = getDriver().findElement(By.xpath("//div[contains(@id,'"+tabName+"')]//a[contains(@class,'refresh-embedded')]"));
		element(refreshIcon).waitUntilVisible();
		element(refreshIcon).waitUntilClickable();
		element(refreshIcon).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
	}
	
	
	
	
	//   ############## Outbound tab related elements ######################################################
	
	
	
	@FindBy(xpath = "//input[contains(@id,'Filter')][@style]/ancestor::td[@rowspan]/preceding-sibling::td//a[contains(@id,'QuickFilter')]")
	private WebElement quickFilterDropDownIcon;

	
	@FindBy(xpath = "//div[@role='presentation'][text()='Loading']")
	public WebElement loadingIndicator;
	
	
	@FindBy(xpath = "//div[contains(@class,'document-status')]/div")
	private WebElement orderStatusInBY;
	
	
	
	
	private WebElement outboundWorkingFrame(String frameName) {
		return getDriver().findElement(By.xpath("//iframe[contains(@name,'wm."+frameName+"')]")); 
	}
	
	
	private WebElement quickFiltersOption(String filterOption) {
		return getDriver().findElement(By.xpath("//li[text()='Order']//following-sibling::li[normalize-space()='"+filterOption+"']")); 
	}
	
	private WebElement columnValueForFilteredRecordUnderOutboundTab(String columnName) {
		return getDriver().findElement(By.xpath("/td[count(//span[text()='"+columnName+"']/../..//preceding-sibling::div) -1]")); 
	}
	
	private WebElement fieldValueForOrder(String fieldName) {
		return getDriver().findElement(By.xpath("//div[text()='"+fieldName+"']/../../../following-sibling::div[1]//div[contains(@class,'item')][count(//div[text()='"+fieldName+"']/preceding-sibling::div) +1]//span")); 
	}
	
	
	
	
	// ########  Actions on page elements   ##############################################
	
	
	public void switchToFrame(String frameName) {
		getDriver().switchTo().frame(outboundWorkingFrame(frameName));
		logger.info("Switched to working frame {} ----->", frameName);
	}
	
	
	
	public void selectQuickFilter(String filterOption) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(quickFilterDropDownIcon).waitUntilVisible();
		element(quickFilterDropDownIcon).waitUntilClickable();
		element(quickFilterDropDownIcon).click();
		element(quickFiltersOption(filterOption)).waitUntilVisible();
		element(quickFiltersOption(filterOption)).waitUntilClickable();
		element(quickFiltersOption(filterOption)).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected {} filter option from quick filters ====", filterOption);
	}
	
	public String getLoadValue() {
		String loadValue = uiActionsHelper.getElementText(fieldValueForOrder("Load"));
		return loadValue;
	}
	
	public String getOrderStatus() {
		String orderStatus = uiActionsHelper.getElementText(orderStatusInBY);
		return orderStatus;
	}
	
	
	public String getOrderActivityPercentage(String fieldName) {
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement activityElement = getDriver().findElement(By.xpath("//div[text()='"+fieldName+"']/../../../following-sibling::div[1]//div[contains(@class,'item')][count(//div[text()='"+fieldName+"']/preceding-sibling::div) +1]//span[contains(@class,'leftval')]"));
		element(activityElement).waitUntilVisible();
		String orderActivityPercentage = uiActionsHelper.getElementText(activityElement);
		return orderActivityPercentage;
	}
	
	
	//   ############## Waves and Picks tab related elements ##########################################
	
	
	@FindBy(xpath = "//a[contains(@id,'moreactionsbutton')][not(contains(@style,'none'))]")
	private WebElement actionsDropdownIconUnderWave_PicksTab;
	
	@FindBy(css = "input[name='car_move_id']")
	private WebElement loadSearchInputBoxUnderPlanWave;
	
	
	@FindBy(xpath = "//div[contains(@class,'emptytext')]//tr[contains(@id,'MultiLevelGridView')]")
	private WebElement searchedRecordUnderPlanWave;

	
	@FindBy(css = "input[name='waveNumber']")
	private WebElement waveNumberInputField;
	
	
	@FindBy(xpath = "//div[contains(@id,'wavedetails')]//a[contains(@id,'moreactionsbutton')][not(contains(@style,'none'))]")
	private WebElement waveSpecific_ActionsDropdownIcon;
	
	
	/*private WebElement loadIdPopup(String loadId) {
		return getDriver().findElement(By.xpath("//div[normalize-space()='"+loadId+"']")); 
	}*/
	
	
	@FindBy(xpath = "//div[contains(@class,'wave-detail-status')]")
	private WebElement waveStatusInBY;
	
	
	@FindBy(xpath = "//div[contains(@id,'picksgrid')][not(contains(@style,'none'))]//a[contains(@class,'menu-bt')][not(contains(@id,'Menu'))]")
	private WebElement picksGridSpecific_ActionsDropdownIcon;
	
	
	@FindBy(xpath = "//div[contains(@id,'picksgrid')]//tr[contains(@id,'rpMultiLevelGridView')]//div[normalize-space()='Work Assignment']/..")
	public WebElement workAssignmentLinkUnderPicksRecord;
	
	
	@FindBy(xpath = "//div[contains(@id,'releasePickResultWindow')]//a[normalize-space()='OK'][contains(@id,'button')]")
	private WebElement OkButtonUnderReleasePickPopup;
	
	
	@FindBy(xpath = "//div[contains(@id,'picksgrid')]//tr[contains(@id,'rpMultiLevelGridView')]//div[contains(@class,'colheader')][contains(text(),'LST')]")
	private WebElement operationColumnLinkValueUnderPicksGrid_WavePicksTab;
	
	
	// ########  Actions on page elements   ##############################################
	
	
	public void selectOptionsFromActionsDropdownUnderWave_PicksTab(String dropdownOption) {
		
		element(actionsDropdownIconUnderWave_PicksTab).waitUntilVisible();
		element(actionsDropdownIconUnderWave_PicksTab).waitUntilClickable();
		element(actionsDropdownIconUnderWave_PicksTab).click();
		element(getDropdownOption(dropdownOption)).waitUntilVisible();
		element(getDropdownOption(dropdownOption)).waitUntilClickable();
		element(getDropdownOption(dropdownOption)).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Clicked {} option from Actions dropdown under wave and picks tab ====", dropdownOption);
	}
	
	
	public void enterLoadId(String loadId) {
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(loadSearchInputBoxUnderPlanWave).waitUntilVisible();
		element(loadSearchInputBoxUnderPlanWave).sendKeys(loadId);
		logger.info("Selected load id {} for plan wave to search ====", loadId);
	}
	
	
	public WebElement getSearchedRecordForLoad() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(searchedRecordUnderPlanWave).waitUntilVisible();
		element(searchedRecordUnderPlanWave).waitUntilEnabled();
		return element(searchedRecordUnderPlanWave);
	}
	
	public void enterWaveNumberAndClickOkButton(String waveNumber) {
		element(waveNumberInputField).waitUntilVisible();
		element(waveNumberInputField).sendKeys(waveNumber);
		clickButtonByText("OK");
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Entered wave number as {} and clicked on OK button ====", waveNumber);
		
	}
	
	public void selectChechboxUnderAllocateWavePopup(String fieldName) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement checkBoxElement = getDriver().findElement(By.xpath("//td[normalize-space()='"+fieldName+"']/preceding-sibling::td//div[contains(@class,'checker')]"));
		element(checkBoxElement).waitUntilVisible();
		element(checkBoxElement).waitUntilClickable();
		element(checkBoxElement).click();
		logger.info("Selected checkbox for {} field name under allocate popup ====", fieldName);
		
	}
	
	public void selectOptionsFromActionsDropdown_waveSpecific(String dropdownOption) {
		
		element(waveSpecific_ActionsDropdownIcon).waitUntilVisible();
		element(waveSpecific_ActionsDropdownIcon).waitUntilClickable();
		element(waveSpecific_ActionsDropdownIcon).click();
		uiActionsHelper.moveToElementAndClick(getDropdownOption(dropdownOption));
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected {} option from Actions dropdown for specific wave ====", dropdownOption);
		
	}
	
	
	public String getWaveStatus() {
		String waveStatus = uiActionsHelper.getElementText(waveStatusInBY);
		return waveStatus;
	}
	
	public String getWaveActivityPercentage(String fieldName) {
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement activityElement = getDriver().findElement(By.xpath("//td[normalize-space()='"+fieldName+"']/following-sibling::td//span[contains(@class,'leftval')]"));
		element(activityElement).waitUntilVisible();
		String waveActivityPercentage = uiActionsHelper.getElementText(activityElement);
		return waveActivityPercentage;
	}
	
	
	public void clickOnMentionedTabGridForSpecificWave(String tabGridName) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement tabElement = getDriver().findElement(By.xpath("//div[contains(@id,'WaveDetailsToggle')]//span[contains(@id,'btnText')][text()='"+tabGridName+"']/ancestor::a"));
		element(tabElement).waitUntilVisible();
		element(tabElement).waitUntilClickable();
		element(tabElement).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Clicked on {} tab grid under waves and picks screen ===== ", tabGridName);
	}
	
	public String getTaskCountForSpecificTabGrid(String tabGridName) {
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement countElement = getDriver().findElement(By.xpath("//div[contains(@id,'WaveDetailsToggle')]//span[contains(@id,'btnText')][text()='"+tabGridName+"']/..//span[contains(@id,'btnCount')]"));
		element(countElement).waitUntilVisible();
		String taskCount = uiActionsHelper.getElementText(countElement);
		return taskCount;
	}
	
	public void selectCheckboxForPicksRecord() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement checkbox = getDriver().findElement(By.xpath("//div[contains(@id,'picksgrid')]//tr[contains(@id,'rpMultiLevelGridView')]//div[contains(@class,'checker')]"));
		element(checkbox).waitUntilVisible();
		element(checkbox).waitUntilClickable();
		element(checkbox).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected the displayed pick record =====");
	}
	
	
	public String getColumnValueUnderPicksGrid(String columnName) {
		WebElement columnValueElement = getDriver().findElement(By.xpath("//div[contains(@id,'picksgrid')]//tr[contains(@id,'rpMultiLevelGridView')]//td[count(//div[contains(@id,'wm-picks-picksgrid')][not(contains(@style,'none'))]//span[normalize-space()='"+columnName+"']/../../preceding-sibling::div) + 1]/div"));
		element(columnValueElement).waitUntilVisible();
		String columnValue = uiActionsHelper.getElementText(columnValueElement);
		return columnValue;
	}
	
	
	public String getFailedCountUnderReleasePickPopup() {
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement countElement = getDriver().findElement(By.xpath("//div[contains(@id,'releasePickResultWindow')]//td[normalize-space()='Failed']/following-sibling::td/label"));
		element(countElement).waitUntilVisible();
		String faliedCount = uiActionsHelper.getElementText(countElement);
		return faliedCount;
	}
	
	public void selectOptionsFromPicksGridActionsDropdown(String dropdownOption) {
		
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(picksGridSpecific_ActionsDropdownIcon).waitUntilVisible();
		element(picksGridSpecific_ActionsDropdownIcon).waitUntilClickable();
		element(picksGridSpecific_ActionsDropdownIcon).click();
		element(getDropdownOption(dropdownOption)).waitUntilVisible();
		element(getDropdownOption(dropdownOption)).waitUntilClickable();
		element(getDropdownOption(dropdownOption)).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected {} option from picks Actions dropdown ====", dropdownOption);
		
	}
	
	
	public boolean getOKButtonUnderReleasePicksPopup() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		if(element(OkButtonUnderReleasePickPopup).isDisplayed())
			return true;
		else
			return false;
	}
	
	public void clickOKButtonUnderReleasePicksPopup() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(OkButtonUnderReleasePickPopup).waitUntilVisible();
		element(OkButtonUnderReleasePickPopup).waitUntilClickable();
		element(OkButtonUnderReleasePickPopup).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Clicked OK button under release picks confirmation popup==========");
	}
	
	
	
	public String getOperationColumnTextUnderPicksGrid() {
		
		element(operationColumnLinkValueUnderPicksGrid_WavePicksTab).waitUntilVisible();
		String operationNumText = uiActionsHelper.getElementText(operationColumnLinkValueUnderPicksGrid_WavePicksTab);
		logger.info("Operation number for picking : {}", operationNumText);
		return operationNumText;
	}
	
	
	
	
	
	//  ############## Work Queue tab related elements ##########################################
	

	@FindBy(xpath = "//span[contains(@id,'wm-common-workqueueoperation')][not(contains(@style,'none'))]//span[contains(@class,'rp-icon-expanded')][not(contains(@id,'rp'))]/..")
	private WebElement workQueueTab_ActionsDropdownIcon;
	
	
//	@FindBy(xpath = "//div[contains(@id,'workqueue')]//tr[contains(@id,'rpMultiLevelGridView')]//div[contains(@class,'checker')]")
//	private WebElement workAssignmentRecord_Checkbox;
	
	@FindBy(xpath = "(//td[@role='gridcell']//div[@role='presentation'])[1]")
	private WebElement workAssignmentRecord_Checkbox;
	
	
	@FindBy(xpath = "//div[contains(@id,'assignuserwindow')]//input[contains(@id,'rpuxFilterComboBox')]")
	private WebElement inputFilterBoxUnderAssignUserPopup;
	
	
	@FindBy(css = "input[name='priority']")
	private WebElement priorityInputBoxUnderChangePriorityPopup;
	
	@FindBy(xpath = "//a[.//span[text()='Apply']]")
	private WebElement applyBtnUnderChangePriorityPopup;
	
	
	@FindBy(xpath = "//div[contains(@id,'workqueue')]//a[contains(@class,'refresh-embedded')]")
	public WebElement workQueueTabRefreshIcon;
	
	
	
	
	
	
	
	private WebElement columnValueUnderWorkQueueTab(String columnName) {
		sleep(2);
		return getDriver().findElement(By.xpath("//div[contains(@id,'workqueue')]//tr[contains(@id,'rpMultiLevelGridView')]//td[count(//div[contains(@id,'workqueueoperationsgrid')][not(contains(@style,'none'))]//span[contains(@class,'column-header')][normalize-space()='"+columnName+"']/../..//preceding-sibling::div) ]/div")); 
		}
	
	
	
	
	
	
	
	// ########  Actions on page elements   ##############################################
	
	
	
	public String getColumnValueUnderWorkQueueTab(String columnName) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement columnValueElement=columnValueUnderWorkQueueTab(columnName);
		element(columnValueElement).waitUntilVisible();
		String columnValue = uiActionsHelper.getElementText(columnValueElement);
		return columnValue;
	}
	


	
	public void selectOptionsWorkQueueActionsDropdown(String dropdownOption) {
		
		uiActionsHelper.pageLoadWait(getDriver());
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(workQueueTab_ActionsDropdownIcon).waitUntilVisible();
		element(workQueueTab_ActionsDropdownIcon).waitUntilClickable();
		element(workQueueTab_ActionsDropdownIcon).click();
		element(getDropdownOption(dropdownOption)).waitUntilVisible();
		element(getDropdownOption(dropdownOption)).waitUntilClickable();
		element(getDropdownOption(dropdownOption)).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected {} option from work queue Actions dropdown ====", dropdownOption);
		
		
	}
	
	public void selectCheckboxForWorkAssignmentRecordUnderWorkQueueTab() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(workAssignmentRecord_Checkbox).waitUntilVisible();
		element(workAssignmentRecord_Checkbox).waitUntilClickable();
		element(workAssignmentRecord_Checkbox).click();
	//	element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected the displayed work assignment record =====");
	}
	
	public void enterUserToBeAssigned(String userName) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(inputFilterBoxUnderAssignUserPopup).waitUntilVisible();
		String filterCriteria = "User=" + userName;
		element(inputFilterBoxUnderAssignUserPopup).waitUntilEnabled();
		element(inputFilterBoxUnderAssignUserPopup).sendKeys(filterCriteria + Keys.ENTER);
	
//		if(filterCriteriaUnderDropdownMenu("in User").isDisplayed())
//			filterCriteriaUnderDropdownMenu("in User").click();
//		
//		else
//			element(inputFilterBoxUnderAssignUserPopup).sendKeys(Keys.ENTER);

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Entered user {} under assigned user popup =====", userName);
		
	}
	
	public void ClickOnSearchedUserRecordUnderAssignUserPopup(String userName) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		WebElement userRecord = getDriver().findElement(By.xpath("//div[contains(@id,'assignuserwindow')]//tr[contains(normalize-space(),'"+userName+"')]")); 
		element(userRecord).waitUntilVisible();
		element(userRecord).waitUntilClickable();
		element(userRecord).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Selected {} user record under assigned user popup =====", userName);
	}
	
	public void enterPriorityUnderChangePriortyPopup(String priority) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(priorityInputBoxUnderChangePriorityPopup).waitUntilVisible();
		element(priorityInputBoxUnderChangePriorityPopup).clear();
		element(priorityInputBoxUnderChangePriorityPopup).sendKeys(priority);
		logger.info("Entered priority as {} for the work assignment =====", priority);
	}
	
	public void clickApplyButtonUnderChangePriorityPopup() {
		element(applyBtnUnderChangePriorityPopup).waitUntilVisible();
		element(applyBtnUnderChangePriorityPopup).waitUntilClickable();
		element(applyBtnUnderChangePriorityPopup).click();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Clicked apply button after changing priority for work assignment under change priority popup =====");
	}
	
}
