package com.walmart.supplychain.catalyst.gdm.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingSteps;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import cucumber.api.java.en.Given;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })  
public class CatalystGDMSteps extends ScenarioSteps {							


	@Autowired(required = true)
	CatalystGDMHelper gdmHelper;
	
	@Autowired
	YMSHelper ymsHelper;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	Environment environment;
	
	@Autowired
	Environment endpoint;
	
	//private static final Logger LOGGER = LogManager.getLogger(CatalystGDMSteps.class);
	Logger LOGGER = LogManager.getLogger(this.getClass());	
	private Response response;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(10, 15);// 15 times with a delay of 10s
	String DELIVERY_STATUS_PATH = "deliveryStatus";
	String STATUS_FNL = "FNL";
	String STATUS_PND_FNL = "PNDFNL";
	String STATUS_PND_PT = "PNDPT";
	static final String TEST_FLOW_DATA_KEY = "testFlowData";
	private static final String GDM_DELIVERY_EP = "gdm_delivery_ep";    //gdm qa endpoint
	private static final String TEST_FLOW_DATA = "testFlowData";
	//private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	
	ObjectMapper objectMapper = new ObjectMapper();
	
	
	@Step
	public void search_and_validate_deliveryStatus(String deliveryStatus, String deliveryName) {
		try {
			LOGGER.info("Validating GDM delivery Status Code");
			//Thread.sleep(2000);
			Failsafe.with(retryPolicy).run(() -> {
				response = getDeliveryResponse(deliveryName);   
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,       
						response.getStatusCode());
				LOGGER.info("Validating GDM Status is changed to: " + deliveryStatus);

				String actualDeliveryStatus = JsonPath.read(response.asString(), DELIVERY_STATUS_PATH);
				LOGGER.info("Actual delivery status received is:" + actualDeliveryStatus);
				
				String doorNumber = gdmHelper.getDoorNumber();			
				LOGGER.info("doorNumber {} : " + doorNumber);

//				if (Config.isParallel && (actualDeliveryStatus.equals(STATUS_FNL)
//						|| actualDeliveryStatus.equals(STATUS_PND_FNL) || actualDeliveryStatus.equals(STATUS_PND_PT))) {
//					LOGGER.info("Removing door {} from occupied door list", doorNumber);
//					boolean removalStatus = ymsHelper.getInboundOccupiedDoorsList().remove(doorNumber);
//					if (removalStatus) {
//						LOGGER.info("Removed door Number {} from the inbound door list", doorNumber);
//						ymsHelper.getInboundOccupiedDoorsList().notify();
//					}
//
//				}
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_STATUS_NOT_UPDATED, deliveryStatus, actualDeliveryStatus);  
				
			});
		

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating delivery status", e);
		}

	}
	
		
	
	
	public Response getDeliveryResponse(String delvryName) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		JSONArray delNum = JsonPath.read(testFlowData,
				"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");   
		//LOGGER.info("Delivery number " + delNum.get(0));
		LOGGER.info("Delivery number " + delNum);
		Response responseGdm = null;

		if (Config.DC == DC_TYPE.CATALYST) {
			responseGdm = given().relaxedHTTPSValidation().headers(gdmHelper.getGDMHeaders()).when().get(                
					environment.getProperty(GDM_DELIVERY_EP) + delNum.get(0) + "?includeActiveChannelMethods=true"); 
		} else {
			responseGdm = given().relaxedHTTPSValidation().headers(gdmHelper.getGDMHeaders()).when()
					.get(environment.getProperty(GDM_DELIVERY_EP) + delNum.get(0));

		}
		return responseGdm;
	}


}
		
	


