package com.walmart.supplychain.nextgen.op.scenariosteps.api;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.nextgen.op.steps.webservices.OrderTrackerValidationSteps;

import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class OrderTrackerValidationScenarioSteps {
	@Steps
	OrderTrackerValidationSteps orderTrackerValidationSteps;
	
	@And("^orderTacker has order status \"([^\"]*)\" for those orderTracking lines$")
	public void checkOrderTrackerStatus(String orderTrackerStatus){
		orderTrackerValidationSteps.getAllOrderIDsForGivenStatus(orderTrackerStatus);

	}
	
	@And("^user verfies \"([^\"]*)\" qty in OT$")
	public void checkForPickedQtyInOrderTracker(String orderTrackerStatus) {
		orderTrackerValidationSteps.validatePickedQty(orderTrackerStatus);
	}

	@And("^User verifies \"([^\"]*)\" status in OT post VTR$")
	public void verifyOrderTrackerPostVTR(String status) {
		orderTrackerValidationSteps.validateStatusPostVTR(status);
	}
	
	@And("^user verfies \"([^\"]*)\" qty in OT from DB$")
	public void checkForPickedLoadedShippedQtyInOrderTrackerDB(String orderTrackerStatus) {
		orderTrackerValidationSteps.validatePickedLoadedShippedQtyInOrderTracker(orderTrackerStatus);
	}
	
	@And("^user verifies order status \"([^\"]*)\" and delivery finalise indicator \"([^\"]*)\" in OT$")
	public void validateOrderStatusAndFnlindicator(String orderTrackerStatus, String fnlIndicator) {
		orderTrackerValidationSteps.validateOrderStatusAndFnlIndicator(orderTrackerStatus, fnlIndicator);
	}
	
	@And("^user verifies order status \"([^\"]*)\" in OT$")
	public void validateOrderStatus(String orderTrackerStatus) {
		orderTrackerValidationSteps.validateOrderStatus(orderTrackerStatus);
	}
}
