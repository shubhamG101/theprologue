package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class DcTcPoLInePage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//*[@id='root']/div/section[2]/section/div[2]/section[2]/div/ul/li[1]")
	private WebElement firstPOLine_Link;
	
	@FindBy(xpath = "//*[text()='Select from item list']")
	private WebElement poLineNotFound_Link;
	
	@FindBy(xpath = "//*[text()='Item not found?']")
	private WebElement itemNotFound_Link;
	
	@FindBy(xpath = "//*[@class='po-selection-header']//following-sibling::ul//li[1]")
	private WebElement firstItem_Link;
	
	//RDC changes
	@FindBy(xpath = "//*[@class='container fade-in-right']//ul/li[1]")
	private WebElement firstPO_Link;
	
	public void clickOnPOLineNotFound() {
		element(poLineNotFound_Link).waitUntilClickable();
		element(poLineNotFound_Link).click();
	}
	
	public void clickFirstPOLine() {
		element(firstPOLine_Link).waitUntilClickable();
		click(firstPOLine_Link);
	}
	
	public void clickItemNotFound() {
		element(itemNotFound_Link).waitUntilClickable();
		click(itemNotFound_Link);
	}
	
	public void clickFirstItem() {
		click(firstItem_Link);
	}
	
	public void clickFirstPO() {
		click(firstPO_Link);
	}
	
}
