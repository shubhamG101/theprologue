
package com.walmart.supplychain.nextgen.idm.scenariosteps.webservices;

import com.walmart.supplychain.nextgen.idm.steps.webservices.MyAppsSteps;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;
public class MyAppsScenarios {

	@Steps
	MyAppsSteps myAppsSteps;

    @Then("^user launches Unified UI$")
    public void loginToMyApps(){
    	myAppsSteps.launchMyApps();
    }
}