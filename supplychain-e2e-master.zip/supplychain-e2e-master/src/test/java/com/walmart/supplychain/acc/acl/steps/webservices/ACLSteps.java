package com.walmart.supplychain.acc.acl.steps.webservices;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.acc.SorterBackwardFlow;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class ACLSteps {
	@Autowired
	ACLHelper aclHelper;

	@Autowired
	ReceivingHelper receivingHelper;

	Logger logger = LoggerFactory.getLogger(ACLSteps.class);

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	@Autowired
	ACLDBSteps aclDBSteps;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private static final String DELIVERY_JSON_PATH="$.testFlowData.deliveryDetails..deliveryNumber";
	private static final String PO_NUMBER_JSON_PATH="$.testFlowData.deliveryDetails..poNumbers[*]";

	//$.testFlowData.poDetails[?(@.poNumber == '7883030292')]..receivingInstructions[*].parentContainer

	@Step
	public void sendVerificationFromACLtoRec()
	{
		try
		{
			Set<String> uniqueItems;
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			DocumentContext parsedJson = JsonPath.parse(testFlowData);
			List<String> deliveryNumberList = parsedJson.read(DELIVERY_JSON_PATH);
			String deliveryNumber = deliveryNumberList.get(0);
			List<String> poNumberList =JsonPath.read(testFlowData, PO_NUMBER_JSON_PATH);

			for (String poNumber : poNumberList) 
			{
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					List<String> lpnList =JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')]..receivingInstructions[*].parentContainer");
					for (String lpn : lpnList) {
						aclHelper.sendVerificationMssg(deliveryNumber,lpn);
						logger.info("ACL Verification :: Successfully published vefrication mssg for the lpn:{}",lpn);
					}		
				}
				logger.info("ACL Verification :: Successfully published vefrication message for all the lps of the poNumber:{} of deliveryNumber:{}",poNumber,deliveryNumber);
			}
			logger.info("ACL Verification :: Successfully published vefrication message for all the lps of the deliveryNumber:{}",deliveryNumber);
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while publishing ACL verification message to receiving",e);
		}
	}

	@Step
	public void triggerBackwardFlowforSorter() {
		try
		{
			ObjectMapper mapper = new ObjectMapper();
			Set<String> uniqueItems;
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			DocumentContext parsedJson = JsonPath.parse(testFlowData);
			List<String> deliveryNumberList = parsedJson.read(DELIVERY_JSON_PATH);
			String deliveryNumber = deliveryNumberList.get(0);
			List<String> poNumberList =JsonPath.read(testFlowData, PO_NUMBER_JSON_PATH);
			for (String poNumber : poNumberList) 
			{

				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");

				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				for (String itemNum : uniqueItems) {
					logger.info("Updating ACL labels status for the item : {}",itemNum);
					List<String> lpnList =JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.itemNumber == '"+itemNum+"')].receivingInstructions[*].parentContainer");
					Failsafe.with(retryPolicy).run(() -> {
						aclDBSteps.updateACLLableStatusCode(lpnList);
					});	
					logger.info("Updated ACL labels status for the item : {}",itemNum);
					for (String lpnNum : lpnList) {
						logger.info("Triggering Soreter backward flow with REST call to ACL for the LPN : {}",lpnNum);
						SorterBackwardFlow sorterBackwardFlowObj = new SorterBackwardFlow();
						sorterBackwardFlowObj.setLpn(lpnNum);
						sorterBackwardFlowObj.setStatus("SYSTEM_VERIFIED");
						Failsafe.with(retryPolicy).run(() -> {
							Response postSorterBackWardFlowRespose = SerenityRest.given().body("["+mapper.writeValueAsString(sorterBackwardFlowObj)+"]").contentType("application/json").when().post(environment.getProperty("back_ward_flow_sorter_url"));
							Assert.assertEquals(ErrorCodes.SORTER_GET_SORTER_BACKWARD_FLOW_RESPONSE,Constants.SUCESS_STATUS_CODE, postSorterBackWardFlowRespose.getStatusCode());
						});
						logger.info("Triggered Soreter backward flow with REST call to ACL for the LPN : {}",lpnNum);
					}
				}
			}
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while publishing Sorter backward message",e);
		}
	}

}
