package com.walmart.supplychain.rdc.loading.steps;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.opencsv.CSVReader;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.rdc.DivertSorter;
import com.walmart.framework.supplychain.domain.witron.POLine;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.WitronItemDetails;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.rdc.receiving.pages.ReceivingDoorScanPage;

import io.restassured.response.Response;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class RDCSorterSteps {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	RDCUtil rdcUtil;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 5);
	List<String> containerList = null;

	Response response;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	ObjectMapper om = new ObjectMapper();
	private static final String QUEUE = "queue";

	private static final String GET_DOOR_NBR = "$.testFlowData.deliveryDetails[*].inboundDoorNumber";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String GET_DELIVERY = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private static final String GET_RECEIVING_INSTRUCTIONS = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*]";
	private static final String GET_PARENT_CNTRS = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].parentContainer";
	private static final String GET_DELIVERY_DETAILS = "$.testFlowData.deliveryDetails[*]";
	private static final String GET_DOCK_TAGS = "$.testFlowData.deliveryDetails[*].dockTags";
	private static final String ABSOLUTE_PATH = "/src/test/resources/TestData/rdc";

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	String testFlowData;

	@Step
	public void sendSorterDiverts() {
		try {

			Thread.sleep(2000);

			Reader reader = null;
			reader = new BufferedReader(
					new FileReader(System.getProperty("user.dir") + ABSOLUTE_PATH + "/divertContainers.csv"));

			CSVReader csvReader = new CSVReader(reader);
			String[] line;
			int i = 0;
			List poLineList = new ArrayList();
			List testFlowpoLineList = new ArrayList();
			List<String> uuIDList = new ArrayList();
			while ((line = csvReader.readNext()) != null) {
				if (i == 0) {
					i++;
					continue;
				}
				Date currDate = new Date();
				DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				String[] dateStr = desturl.format(currDate).split(" ");
				logger.info(dateStr[0]);
				logger.info(dateStr[1]);

				String dispositionTime = dateStr[0] + "T" + dateStr[1] + ".000Z";

				DivertSorter divert = new DivertSorter();
				divert.setScannedLabel(line[0]);
				divert.setInductNumber(1);
				divert.setLabelStatus("NORMAL");
				divert.setDestination(line[2]);
				divert.setCountryCode("US");
				divert.setLabelType("STORE");
				divert.setCameraId("22487429");
				divert.setMsgEvent("dispositionVerification");
				divert.setSorterId(line[1]);
				divert.setDispositionTimeStamp(dispositionTime);
				divert.setActualLane(line[3]);
				divert.setIntendedLane(line[3]);

				String divertMsg = om.writeValueAsString(divert);

				logger.info(om.writeValueAsString(divert));

				synchronized (stratiConnectionUtil) {
					stratiConnectionUtil.publishStartiMessage(environment.getProperty("sorter_divert_queue"), divertMsg, QUEUE,
							environment.getProperty("qa_connection_factory"),
							environment.getProperty("qa_strati_username"),
							environment.getProperty("adjustments_strati"), "divert");
				}

			}
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_PUBLISH_DIVERTS, e);
		}
	}

}
