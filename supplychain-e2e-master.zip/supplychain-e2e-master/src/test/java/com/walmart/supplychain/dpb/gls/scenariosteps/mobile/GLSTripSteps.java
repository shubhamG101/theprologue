package com.walmart.supplychain.dpb.gls.scenariosteps.mobile;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.jms.KafkaUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.dpb.gls.pages.mobile.GLSTripPage;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class GLSTripSteps extends ScenarioSteps {

	@Autowired
	GLSTripPage glsTripPage;

	@Autowired
	GLSTripHelper GLSTripHelper;

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	IDMSteps idmSteps;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	TextParser textParser;

	@Autowired
	KafkaUtils kafkaUtils;

	String testFlowData;
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String TRIP_SET_JSON_PATH = "$.testFlowData";
	private static final String TRIP_ID_GET_JSON_PATH = "$.testFlowData.trips[*]";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY_30S,
			Constants.RETRY_EXECUTION_COUNT_40);

	Logger logger = LogManager.getLogger(this.getClass());

	@Step
	public void createTripFromGLS(String itemNumbers, String noOfContainers) {
		try {
			int totalPickQty = 0;
			if(itemNumbers.equalsIgnoreCase("item_numbers")) {
				itemNumbers = environment.getProperty("ITEM_NUMBERS");
			}
			List<String> listOfItems = Arrays.asList(itemNumbers.split(","));
			LocalDate currentDate = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			logger.info(currentDate.format(formatter));
			String createDateTS = currentDate.format(formatter) + "T00:00:00.000Z";

			String baseCreateTripJSON = textParser.readTextFile(FileNames.DPB_CREATE_TRIP_JSON);
			String baseItemDetailsCreateTripJSON = textParser.readTextFile(FileNames.DPB_ITEM_DETAILS_CREATE_TRIP_JSON);
			Integer tripId = Integer.parseInt("8" + javaUtil.randonNumberGenerator(4));
			String releaseNo = "" + javaUtil.randonNumberGenerator(5);
			String containerTagID = "" + javaUtil.randonNumberGenerator(10) + javaUtil.randonNumberGenerator(10);
			String containerID = "" + javaUtil.randonNumberGenerator(10);
			String destBuNbr = "3903";
			String purchCompanyId = "1001";
			String mockItemDetailsJSON = "";
			String mockTripCreateJSON = "";
			int noOfItems = listOfItems.size();
			for (int i = 0; i < noOfItems; i++) {
				String currentItemNbr = listOfItems.get(i);
				String pickSlotID = "E" + currentItemNbr;
				String slotPickSequenceNbr = currentItemNbr;
				int pickQty = javaUtil.randomNrGeneratorRange(5, 10);
				String pickUnitQty = "" + pickQty;
				totalPickQty = totalPickQty + pickQty;
				mockItemDetailsJSON = mockItemDetailsJSON + javaUtil.format(baseItemDetailsCreateTripJSON, releaseNo, containerTagID, containerID, "FRONT", destBuNbr, ""+(i+1), currentItemNbr, purchCompanyId, pickSlotID, slotPickSequenceNbr, pickUnitQty);
				if (i < noOfItems - 1) {
					mockItemDetailsJSON = mockItemDetailsJSON + ",";
				}
			}
			mockTripCreateJSON = javaUtil.format(baseCreateTripJSON, tripId.toString(), createDateTS, mockItemDetailsJSON);
			logger.info("dpb Create Trip JSON Body:" + mockTripCreateJSON);
			kafkaUtils.sendCreateOrUpdateGLSTripMessage(mockTripCreateJSON, environment.getProperty("CREATE_TRIP_TOPIC"), "Created", tripId);
			threadLocal.get().put(TEST_FLOW_DATA, mockTripCreateJSON);
			logger.info("Trip details after storing in ThreadLocal {}", threadLocal.get().get(TEST_FLOW_DATA));
			threadLocal.get().put("totalPickQty", totalPickQty);
			logger.info("TotalPickQty after storing in ThreadLocal {}", threadLocal.get().get("totalPickQty"));
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Create Trip", e);
		}
	}

	@Step
	public void qtyCutFromGLS() {
		try {
			String tripDetails = threadLocal.get().get(TEST_FLOW_DATA).toString();
			DocumentContext parsedTripDetailsJson = JsonPath.parse(tripDetails);
			List<Integer> tripIDList = parsedTripDetailsJson.read("$.trips[*].tripid");
			for (Integer tripId : tripIDList) {
				List<String> listOfItems = parsedTripDetailsJson.read("$.trips[?(@.tripid==" + tripId + ")].items[*].itemnbr");
				int indexForQtyCut = javaUtil.randomNrGeneratorRange(1,listOfItems.size());
				List<Integer> listOfPickQtyForIndex = parsedTripDetailsJson.read("$.trips[?(@.tripid==" + tripId + ")].items[?(@.itemseqnbr=="+indexForQtyCut+")].pickunitqty");
				int pickQtyForIndex = listOfPickQtyForIndex.get(0) - javaUtil.randomNrGeneratorRange(1,3);
				String testFlowDataUpdated = jsonUtils.setJsonAtJsonPath(TEST_FLOW_DATA, jsonUtils.convertStringToMinidevJsonObject(""+pickQtyForIndex), "$.trips[?(@.tripid==" + tripId + ")].items[?(@.itemseqnbr=="+indexForQtyCut+")].pickunitqty");
				threadLocal.get().put(TEST_FLOW_DATA, testFlowDataUpdated);
				logger.info("Trip details after storing in ThreadLocal {}", threadLocal.get().get(TEST_FLOW_DATA));
			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to Create Trip", e);
		}
	}

	@Step
	public void changeTripStatus(String status) {
		try {
			int milliSecs = 13000;
			logger.info("Waiting for {} milli seconds before changing the trip status to {}", milliSecs, status);
			Thread.sleep(milliSecs);
			String tripDetails = threadLocal.get().get(TEST_FLOW_DATA).toString();
			DocumentContext parsedTripDetailsJson = JsonPath.parse(tripDetails);
			List<Integer> tripIDList = parsedTripDetailsJson.read("$.trips[*].tripid");
			List<String> createDateTs = parsedTripDetailsJson.read("$.trips..tripcreatedate");
			String createDateTS = createDateTs.get(0);
			String assignedDateTS = createDateTS.split("T")[0] + "T13:29:22.000Z";

			for (Integer tripId : tripIDList) {
				String uuid = javaUtil.getUUID();
				LocalDate currentDate = LocalDate.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				logger.info(currentDate.format(formatter));

				String baseUpdateTripStatusJSON = getBaseJSONForStatus(status);
				String facilityNumber = environment.getProperty("facility_num");

				String mockTripUpdateJSON = "";
				mockTripUpdateJSON = javaUtil.format(baseUpdateTripStatusJSON, facilityNumber, uuid, status, tripId.toString(), createDateTS, assignedDateTS, environment.getProperty("assignedUser")+tripId);

				logger.info("dpb tripId assign json:" + mockTripUpdateJSON);
				String topicName = environment.getProperty("UPDATE_TRIP_TOPIC");
				if(status.equalsIgnoreCase("Cancel")) {
					topicName = environment.getProperty("CREATE_TRIP_TOPIC");
				}
				kafkaUtils.sendCreateOrUpdateGLSTripMessage(mockTripUpdateJSON, topicName, status, tripId);
			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to Update Trip Status to \""+ status+"\" due to below error\n", e);
		}
	}

	private String getBaseJSONForStatus(String status) throws URISyntaxException, IOException {
		String baseUpdateTripStatusJSON = "";
		switch(status) {
			case "Assigned":
				baseUpdateTripStatusJSON = textParser.readTextFile(FileNames.DPB_ASSIGN_TRIP_JSON);
				break;
			case "Unassigned":
				baseUpdateTripStatusJSON = textParser.readTextFile(FileNames.DPB_UNASSIGN_TRIP_JSON);
				break;
			case "Resume":
			case "Completed":
				baseUpdateTripStatusJSON = textParser.readTextFile(FileNames.DPB_COMPLETE_TRIP_JSON);
				break;
			case "Cancel":
				baseUpdateTripStatusJSON = textParser.readTextFile(FileNames.DPB_CANCEL_TRIP_JSON);
				break;
			case "Paused":
				baseUpdateTripStatusJSON = textParser.readTextFile(FileNames.DPB_PAUSE_TRIP_JSON);
				break;
			default:
				new AutomationFailure("Status is not valid");
		}
		return baseUpdateTripStatusJSON;
	}

	@Step
    public void validateTripDetailsAP() {
		String tripDetails = threadLocal.get().get(TEST_FLOW_DATA).toString();
		DocumentContext parsedTripDetailsJson = JsonPath.parse(tripDetails);
		List<Integer> tripIDList = parsedTripDetailsJson.read("$.trips[*].tripid");

        try {
			for (Integer tripId : tripIDList) {
			List<String> containerList = new ArrayList<>();
			Failsafe.with(retryPolicy).run(() -> {
			logger.info("Get trip_id for trip_id {}", environment.getProperty("get_trip_details"));
			List<Map<String, Object>> tripMap = dbUtils.selectFrom(PRODUCT_NAME.AP,
					environment.getProperty("get_trip_details"), tripId.toString());
			logger.info("Size is " + tripMap.size());
			Assert.assertEquals(ErrorCodes.DPB_UNABLE_FIND_TRIP_AP, 1, tripMap.size());
			logger.info("Trip Details Found in AP DB {}", tripMap.get(0));
			String container_tag_id = tripMap.get(0).get("container_tag_id").toString();
			containerList.add(container_tag_id);
			logger.info("Container Tag ID " + container_tag_id);
			});
		}

        } catch (Exception e) {
            throw new AutomationFailure("Something went wrong while fetching Trip details from AP", e);
        }
    }

	@Step
	public void validateTripDetailsFES(int statusCode) {
		try {
			Thread.sleep(60000);
			String tripDetails = threadLocal.get().get(TEST_FLOW_DATA).toString();
			DocumentContext parsedTripDetailsJson = JsonPath.parse(tripDetails);
			List<Integer> tripIDList = parsedTripDetailsJson.read("$.trips[*].tripid");
			for (Integer tripId : tripIDList) {
				LocalDate currentDate = LocalDate.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				logger.info(currentDate.format(formatter));
				String createTs = currentDate.format(formatter) + " 00:00:00";
				String tripMetaData = "{\"legacyTripId\":trip}".replace("trip", tripId.toString());
				logger.info("Trip Meta Data {}", tripMetaData);
				Failsafe.with(retryPolicy).run(() -> {
					logger.info("Get trip_status_code for trip_id {}", environment.getProperty("get_trip_details_fes_withMetaData"), tripMetaData);
					List<Map<String, Object>> tripMap = dbUtils.selectFrom(PRODUCT_NAME.FES,
					environment.getProperty("get_trip_details_fes_withMetaData"), tripMetaData);
					logger.info("Result Set Size from FES {}", tripMap.size());
					Assert.assertEquals(ErrorCodes.DPB_UNABLE_FIND_TRIP_FES, 1, tripMap.size());
					int tripStatusCode = Integer.parseInt(tripMap.get(0).get("trip_state_code").toString());
					Assert.assertEquals(ErrorCodes.DPB_INCORRECT_TRIP_STATUS_FES, statusCode, tripStatusCode);
					if(threadLocal.get().get("fesTripId") == null) {
						String fesTripId = tripMap.get(0).get("trip_id").toString();
						threadLocal.get().put("fesTripId", fesTripId);
						logger.info("fesTripId after storing in ThreadLocal {}", threadLocal.get().get("fesTripId"));
					}
					if(statusCode == 6) {
						verifyTripUnitsStatus(Integer.parseInt(threadLocal.get().get("totalPickQty").toString()), threadLocal.get().get("fesTripId").toString(), statusCode);
					}
				});
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching Trip details from FES", e);
		}
	}

	@Step
	public void confirmPicks(String allOrShort) {
		try {
			String update_trip_topic = environment.getProperty("UPDATE_TRIP_TOPIC");
			boolean isShortPick = false;
			String shortInd = "N";
			if(allOrShort.equalsIgnoreCase("Short")) {
				isShortPick = true;
				shortInd = "Y";
			}
			int totalPickQty = Integer.parseInt(threadLocal.get().get("totalPickQty").toString());
			testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			DocumentContext parsedTripDetailsJson = JsonPath.parse(testFlowData);
			List<Integer> tripIDList = parsedTripDetailsJson.read("$.trips[*].tripid");
			// for every trip
			for (Integer tripId : tripIDList) {
				List<String> createDateTS = JsonPath.read(testFlowData, "$.trips[?(@.tripid=='" + tripId + "')]..tripcreatedate");
				String createTs = createDateTS.get(0);
				List<String> containerTagIDList = JsonPath.read(testFlowData, "$.trips[?(@.tripid=='" + tripId + "')]..containertagid");
				Set<String> uniqueContTagId = new HashSet<>(containerTagIDList);
				logger.info("Set of uniqueContTagId from Create Trip\n" + uniqueContTagId);

				// For Every Container/Pallet in Particular Trip
				if(uniqueContTagId.size() <= 2) {
					int contIndex = -1;
					for (String currentCont : uniqueContTagId) {
						contIndex++;
						String containerName = "FRONT";
						if (contIndex == 1) {
							containerName = "BACK";
						}
						List<String> containerIdList = JsonPath.read(testFlowData, "$..items[?(@.containertagid == '" + currentCont + "')].containerid");
						logger.info("containerIdList from Create Trip\n" + containerIdList);

						List<Integer> itemList = JsonPath.read(testFlowData, "$..items[?(@.containertagid == '" + currentCont + "')].itemnbr");
						logger.info("Item Numbers from Create Trip\n" + itemList);

						// For Every Item in Particular Container
						for (int i = 1; i <= itemList.size(); i++) {
							String facilityNumber = environment.getProperty("facility_num");
							String uuid = javaUtil.getUUID();
							String tripStatus = "Working";

							String basePickConfirmationJson = textParser.readTextFile(FileNames.DPB_PICK_CONFIRMATION_JSON);

							List<String> pickSlotId = parsedTripDetailsJson.read("$.trips..items[?(@.itemnbr == "+itemList.get(i-1)+")].pickslotid");
							logger.info("List<String> pickSlotId=" + pickSlotId);
							List<Integer> slotPickSequenceNbr = parsedTripDetailsJson.read("$.trips..items[?(@.itemnbr == "+itemList.get(i-1)+")].slotpicksequencenbr");
							logger.info("List<Integer> slotPickSequenceNbr=" + slotPickSequenceNbr);
							List<Integer> pickUnitQty = parsedTripDetailsJson.read("$.trips..items[?(@.itemnbr == "+itemList.get(i-1)+")].pickunitqty");
							logger.info("List<Integer> pickUnitQty=" + pickUnitQty);
							String pickedUnitQty = pickUnitQty.get(0).toString();
							// Last Slot will not be shorted
							if(i== itemList.size()) {
								isShortPick = false;
								shortInd = "N";
							}
							if (isShortPick) {
								pickedUnitQty = "" + (Integer.parseInt(pickedUnitQty) - 2);
							}
							String assignedUser = environment.getProperty("assignedUser") + tripId;
							String pickConfirmationJson = javaUtil.format(basePickConfirmationJson, facilityNumber, uuid, tripStatus, tripId.toString(), createTs,
									currentCont, containerIdList.get(0), containerName, "" + i, itemList.get(i-1).toString(), "" + 1001, pickSlotId.get(0), slotPickSequenceNbr.get(0).toString(),
									pickUnitQty.get(0).toString(), pickedUnitQty, shortInd, assignedUser, update_trip_topic);
							logger.info("dpb pick confirmation details json:" + pickConfirmationJson);
							kafkaUtils.sendCreateOrUpdateGLSTripMessage(pickConfirmationJson, update_trip_topic, tripStatus, tripId);
							pollFESForReconnection(assignedUser, 10000);
							String fesTripId = threadLocal.get().get("fesTripId").toString();
							verifyTripUnitsStatus(totalPickQty, fesTripId, Constants.DPB_TRIP_REOPTMIZING);
							Thread.sleep(10000);
						}
					}
				} else {
					throw new AutomationFailure("More than 2 containers in trip");
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Send Pick Confirmation", e);
		}
	}

	private void verifyTripUnitsStatus(int totalPickQty, String fesTripId, int StatusCodeToBeValidated) {
		Failsafe.with(retryPolicy).run(() -> {
			logger.info("Get fes trip_unit_status for trip_id {}", environment.getProperty("get_trip_unit_status"), fesTripId);
			List<Map<String, Object>> tripMap = dbUtils.selectFrom(PRODUCT_NAME.FES,
					environment.getProperty("get_trip_unit_status"), fesTripId);
			logger.info("Result Set Size from FES {}", tripMap.size());
			Assert.assertEquals(ErrorCodes.DPB_TRIP_UNITS_LESS_THAN_EXPECTED_FES, totalPickQty, tripMap.size());
			Failsafe.with(retryPolicy).run(() -> {
				for (int j=0;j<tripMap.size();j++) {
					int trip_unit_status_code = Integer.parseInt(tripMap.get(j).get("trip_unit_status_code").toString());
					// Check if subsequent trip units are still re-optimizing
					if(trip_unit_status_code == 7 && StatusCodeToBeValidated == 7) {
						Assert.assertTrue(ErrorCodes.DPB_PALLET_STILL_RE_OPTIMIZING_FES, false);
					} else if(trip_unit_status_code != 6 && StatusCodeToBeValidated == 6) {
						Assert.assertTrue(ErrorCodes.DPB_TRIP_UNIT_NOT_CANCELLED_FES, false);
					}
				}
			});
		});
	}

	public void pollFESForReconnection(String user, int timeout) {
		try {
			logger.info("Checking for User Connection Every 30 secs");
			for (int i=30000; i<=timeout;) {
				int finalI = i;
				Failsafe.with(retryPolicy).run(() -> {
					logger.info("Get get_Ts_fes {} for {}", environment.getProperty("get_Ts_fes"), user);
					List<Map<String, Object>> tripMap = dbUtils.selectFrom(PRODUCT_NAME.FES,
							environment.getProperty("get_Ts_fes"), user);
					logger.info("Result Set Size from FES {}", tripMap.size());
					logger.info("Timestamps at {} Create: {} and LastChange: {}", finalI, tripMap.get(0).get("create_ts"), tripMap.get(0).get("last_change_ts"));
				});
				Thread.sleep(30000);
				i+=30000;
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching Trip details from FES", e);
		}
	}

	@Step
	public void loginToVisionApp() {
		try {
			String tripDetails = threadLocal.get().get(TEST_FLOW_DATA).toString();
			DocumentContext parsedTripDetailsJson = JsonPath.parse(tripDetails);
			List<Integer> tripIDList = parsedTripDetailsJson.read("$.trips[*].tripid");
			String assignedUser = environment.getProperty("assignedUser") + tripIDList.get(0);
			logger.info("Waiting to be logged in with User {}", assignedUser);
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			glsTripPage.loginToVision(assignedUser);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Login to Vision", e);
		}
	}
}
