package com.walmart.supplychain.acc.poupdate.scenarios.webservices;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.acc.acl.steps.webservices.ACCDoorAssignStep;
import com.walmart.supplychain.acc.poupdate.steps.webservices.POUpdateStep;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class POUpdate {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Steps
	ACCDoorAssignStep accDoorAssignStep;
	
	@Steps
	POUpdateStep poUpdateStep;

	@Given("^OMS pushes the PO update with increase in quantity \"([^\"]*)\"$")
	public void oMSPushesPOUpdate(String poDeltaQty) {
		poUpdateStep.publishPOUpdate(poDeltaQty);
		
	}
	
	@Then("^Validate PO update$")
	public void validatePOUpdate() {
		poUpdateStep.validatePOUpdate();
		
	}
}

