package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TrailerEditPage extends PageObject {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(id = "searchTrailerId")
	private WebElement trailerNumberField;

	@FindBy(id = "searchCarrierId")
	private WebElement scacField;
	
	@FindBy(id = "Retrieve")
	private WebElement retrieveButton;

	@FindBy(id = "trailerStatCode")
	private WebElement walmartStatus;
	
	@FindBy(id = "update")
	private WebElement updateButton;
	
	public void retriveTrailerDetails(String trailerNumber) {
		element(trailerNumberField).type(trailerNumber);
		element(scacField).type(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "scac"));
		element(retrieveButton).click();
	}
	
	public void updateWalmartStatus() {
		element(walmartStatus).selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "obd_trailer_wmstatus"));
		element(updateButton).click();
	}
}
