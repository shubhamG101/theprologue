package com.walmart.supplychain.acc.mcb.scenariosteps.webservices;

import com.walmart.supplychain.acc.mcb.steps.webservices.MCBSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class MCBScenarios {
	@Steps
	MCBSteps mcbSteps;
	@Given("^user creates MCB pallet for combined flow$")
	public void createMCBPalletWithCombinedFlow()
	{
		mcbSteps.createMCBPalletCombinedFlow();
	}

	@Given("^user creates MCB pallet for combined new flow$")
	public void createMCBPalletWithCombinedNewFlow() throws Exception {
		mcbSteps.createMCBPalletforCombinedNew();
	}

	@Then("^user completes MCB pallet$")
	public void completeMCBPalletNewFlow()
	{
		mcbSteps.completeFinishMCBPalletNew();
	}
	
	@Given("^user completes MCB pallet for combined flow$")
	public void completeMCBPalletWithCombinedFlow()
	{
		mcbSteps.completeMCBPalletCombinedFlow();
	}
	@Given("^user completes MCB pallet for regular flow for group name \"([^\"]*)\"$")
	public void completeMCBPalletWithRegularFlow(String groupName)
	{
		mcbSteps.completeMCBPalletRegularFlow(groupName);
	}
	
	@Given("^user creates MCB pallet for regular flow for group name \"([^\"]*)\"$")
	public void createMCBPalletWithRegularFlow(String groupName)
	{
		mcbSteps.createMCBPalletRegularFlow(groupName);
	}
	
	@Given("^user dissociates all child containers from MCB pallet$")
	public void dissociateAllChildFromMCB()
	{
		mcbSteps.dissociateAllChildContainersFromMCB();
	}

	@Given("^user creates MCB pallet for regular new regular flow for group name \"([^\"]*)\"$")
	public void createMCBPalletWithRegularNewFlow(String groupName) throws Exception {
		mcbSteps.createMCBPalletRegularNewFlow(groupName);
	}

}
