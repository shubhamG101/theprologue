package com.walmart.supplychain.acc.problemapp.scenarioSteps;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.acc.problemapp.Steps.ProblemAppSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.loading.steps.db.LoadingDBSteps;
import com.walmart.supplychain.nextgen.loading.steps.mobile.LoadingAppSteps;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingSteps;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSSteps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ProblemAppScenarios {
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Steps
	ProblemAppSteps problemAppSteps;

	@When("^user creates a problem containers in problem app with status \"([^\"]*)\"$")
	public void userCreatesProblemContainersInProblemApp (String problemtype) {
		problemAppSteps.createProblemContainers(problemtype);
	}
	
	@Then("^user resolves the problem ticket$")
	public void userResolvesTheProblemTicket () {
		problemAppSteps.resolveProblemTicket();
	}
	
	@Then("^user does problem re-receiving$")
	public void userDoesProblemreReceiving () {
		problemAppSteps.problemreReceive();
	}
	
	@Then("^user verifies container creation in inventory after problem receiving$")
	public void userVerifiesContainerCreationInInventoryAfterProblemReceiving () {
		problemAppSteps.validateContainerCreationAfterProblemreceiving();
	}
	
	@Then("^user verifies container creation in the sorter$")
	public void userVerifiesContainerCreationInTheSorter () {
		problemAppSteps.validateSorterAfterProblemreceiving();
	}
	
	@Then("^user verifies Problem ticket status$")
	public void useVerifiesProblemTicketStatus () {
		problemAppSteps.validateProblemStatus();
	}
}
