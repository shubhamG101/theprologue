package com.walmart.supplychain.catalyst.sct.scenarios;

import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.sct.steps.webservices.CatalystSCTSteps;
import com.walmart.supplychain.witron.dcfinwitron.steps.WitronDCFINSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class CatalystSCTScenarios {
	@Steps
	CatalystSCTSteps catalystSCTSteps;
	

	
	@Given("^User validates \"([^\"]*)\" after unload in SCT$")
	public void userValidatesDeliveryAfterUnloadingInSct(String entityType) throws JsonProcessingException
	{
		catalystSCTSteps.validateDeliveryAfterUnload(entityType);
	}
	
	@Given("^User validates \"([^\"]*)\" after first receipt in SCT$")
	public void userValidatesDeliveryAfterFirstReceiptInSct(String entityType) throws JsonProcessingException
	{
		catalystSCTSteps.validateDeliveryAfterFirstReceipt(entityType);
	}
	
	@Given("^User validates \"([^\"]*)\" after complete shipment in SCT$")
	public void userValidatesDeliveryAfterCompleteShipmentInSct(String entityType) throws JsonProcessingException
	{
		catalystSCTSteps.validateDeliveryAfterCompleteShipment(entityType);
	}
	
	@Given("^User validates \"([^\"]*)\" response in SCT$")
	public void userValidatesResponseInSct(String entityType) throws JsonProcessingException
	{
		if(entityType.equalsIgnoreCase("PICK")) {
		catalystSCTSteps.validatePickInSct(entityType);
		}
		
		else if(entityType.equalsIgnoreCase("AO_SO")) {
			catalystSCTSteps.validateAllocationOrderStoreOrderInSct(entityType);
		}
	
		else if(entityType.equalsIgnoreCase("AO_LINE")) {
			catalystSCTSteps.validateAllocationOrderLineInSct(entityType);
		}
		
		else if(entityType.equalsIgnoreCase("SO_LINE")) {
			catalystSCTSteps.validateStoreOrderLineInSct(entityType);
		}
	}
	
	@Then("^User validates \"([^\"]*)\" entity after complete shipment in SCT for \"([^\"]*)\" status$")
	public void userValidateEntityAfterCompleteShipmentInSctForParticularStatus(String entityType, String status) throws JsonProcessingException {
		catalystSCTSteps.validateSctEntityAfterCompleteShipment(entityType, status);
	}
	
}