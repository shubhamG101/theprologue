package com.walmart.supplychain.rdc.gdm.scenariosteps.webservices;

import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.rdc.gdm.steps.webservices.RDCGdmSteps;
import com.walmart.supplychain.witron.gdm.steps.GDMUnifiedSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class RdcGDMScenarios {
	
	@Steps
	RDCGdmSteps rdcGdmSteps;
	
	@Steps
	GDMUnifiedSteps gdmUnifiedSteps;
	
//	@Given("user does precleanup for rds for delivery \"([^\"]*)\" and po \"([^\"]*)\"")
//	public void userDoesPrecleanupForRdsForDelivery(String delivery, String poList) {
//		rdcGdmSteps.precleanup();
//		
//	}
	
	@And("Creates shipment with \"([^\"]*)\", \"([^\"]*)\" for RDC \"([^\"]*)\" receiving")
	public void userCreatShipmentForPalletReceiving(String loadNumber, String numOfpacksOnShipmentForEachPOLine, String receivingType) {
		rdcGdmSteps.createMultiShipment("1", loadNumber, numOfpacksOnShipmentForEachPOLine, receivingType);
	}
	
	@Then("user validates the delivery is created in GDM UI")
	public void userValidatesTheDeliveryIsCreatedInRDCWithDeliveryNumber() {
		rdcGdmSteps.validateGDMUI();
		
	}
	
	@Then("user validates the delivery status is changed to \"([^\"]*)\" in GDM")
	public void userValidatesTheDeliveryStatusIsChangedToInGDM(String status) {
		rdcGdmSteps.validateDeliveryStatus(status);
		
	}
	@Given("user creates a delivery in GDM and RDS for \"([^\"]*)\" flow")
	public void userCreatesaDeliveryInGDMAndRDSForFlow(String flowType) {
		rdcGdmSteps.precleanup(flowType);
	}
	
	@Given("user creates asn in GDM")
	public void userCreatesAsnInGDM() {
		rdcGdmSteps.createASNInGDM();
	}
	
	@Then("^user validates OSDR in GDM UI$")
	public void userValidatesOSDRInGDMUI() throws JsonProcessingException
	{
	    gdmUnifiedSteps.validateOSDRINRDCGDM();
	}
	
	@Then("^user validates OSDR in GDM PO Mngmnt$")
    public void user_validates_osdr_in_gdm_po_mngmnt() {
		gdmUnifiedSteps.validateCostItemAndOSDRInRDCPOMgmtPage();
    }
	
	@Then("^user validates docktags in GDM UI$")
    public void userValidatesDocktagsInGDM() {
		gdmUnifiedSteps.validateDockTagsINGDM();
    }
    
    @Then("^user verifies delivery status is changed to \"([^\"]*)\" and delivery legacy status is changed to \"([^\"]*)\"$")
    public void userValidatesDeliveryStatusAndLegacyStatus(String status, String legacyStatus) {
    	rdcGdmSteps.validateGDMstausAndLegacyStatus(status, legacyStatus);
    }
		

}
