package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class DockTagScanPage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_dock_tag']")
	private WebElement scanDockTagInput;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_search_docktag']")
	private WebElement dockTagNextBtn;

	@FindBy(xpath = ".//*[@content-desc='Navigate up']")
	private WebElement backBtn;

	public void enterDockTag(String dockTagId) {

		element(scanDockTagInput).waitUntilVisible();
		element(scanDockTagInput).type(dockTagId);

		element(dockTagNextBtn).waitUntilVisible();
		element(dockTagNextBtn).click();

		logger.info("Navigated to DockTag screen");
	}

	public void navigateToDockTagPage() {
		try {
			Thread.sleep(2000);
			element(backBtn).waitUntilVisible();
			element(backBtn).click();
		} catch (Exception e) {

		}
	}

}
