package com.walmart.supplychain.nextgen.yms.steps.ui;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.Range;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.yms.Yms;
import com.walmart.framework.utilities.jms.SchedulerConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.loading.steps.db.LoadingDBSteps;
import com.walmart.supplychain.nextgen.yms.pages.ui.DockManagementPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.DockManagerPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.MoveCreationPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.OutboundMovePage;
import com.walmart.supplychain.nextgen.yms.pages.ui.TrailerEditPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.YMSDriverPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.YMSGateManagementPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.YMSLoginPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.YMSMultipleLoginPage;
import com.walmart.supplychain.nextgen.yms.pages.ui.YardManagementMoveQueuePage;
import com.walmart.supplychain.nextgen.yms.pages.ui.YardManagementPage;

import net.jodah.failsafe.FailsafeException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class YMSSteps extends ScenarioSteps {

	private static final long serialVersionUID = 1L;

	@Autowired
	private YMSHelper ymsHelper;
	
	@Autowired
	SchedulerConnectionUtil schedulerConnectionUtil;
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	LoadingDBSteps loadingDBSteps;

	YMSLoginPage ymsLoginPage;
	YMSDriverPage ymsDriver;
	YMSGateManagementPage ymsGateManagementPage;
	DockManagementPage dockManagementPage;
	YardManagementPage yardManagementPage;
	YMSDriverPage ymsDriverPage;
	DockManagerPage dockManagerPage;
	MoveCreationPage moveCreationPage;
	YMSMultipleLoginPage ymsMultipleLoginPage;
	YardManagementMoveQueuePage yardManagementMoveQueuePage;
	PropertyResolver propertyResolver = new PropertyResolver();
	Config config = new Config();
	Yms ymsData = new Yms();
	Logger logger = LogManager.getLogger(this.getClass());
	OutboundMovePage outboundMovePage;
	TrailerEditPage trailerEditPage;
	JsonUtils jsonUtil=new JsonUtils();

	@Step
	public void open_YMS_home_page() {
		ymsLoginPage.getUrl(config.ymsUiUrl);
	}

	@Step
	public void login_to_YMS() {
		ymsLoginPage.enteruserIdField(propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "yms_username"));
		ymsLoginPage.enterPasswordField(propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "yms"));
		ymsLoginPage.selectDCNumber(propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number"));
		ymsLoginPage.clickLogInButton();
		logger.info("User is able to login to YMS");
		ymsMultipleLoginPage.continueSession();
	}

	@Step
	public void click_on_GateManagement() {
		ymsGateManagementPage.clickGateManagement();
	}

	@Step
	public void click_on_GateInOrOut() {
		ymsGateManagementPage.clickGateInorOut();
	}

	@Step
	public void perform_DeliveryGateIn() {
		//get deliveryNumber from test flow data
		/*String message = ymsGateManagementPage.deliveryGateIn(deliveryNumber);
		assertTrue(message, message.contains("allocated"));*/
	}

	@Step
	public void perform_TrailerGateIn() {
		//get deliveryNumber from test flow data and set trailernumber
		/*String message = ymsGateManagementPage.TrailerGateIn(deliveryNumber);
		assertTrue(message, message.contains("allocated"));*/
	}

	@Step
	public void perform_TrailerGateOut() {
		//get deliveryNumber and trailernumber from test flow data
		/*String message = ymsGateManagementPage.TrailerGateOut(deliveryNumber, trailerNumber);
		logger.info("message " + message);
		assertTrue(message, message.contains("Trailer "+RunTimeData.getOutBoundTrailer()+" departed successfully."));*/
	}

	@Step
	public void click_on_DockManagement() {
		dockManagementPage.clickDockManagement();
	}

	@Step
	public void click_on_DockManager() {
		dockManagementPage.clickDockManager();
	}

	@Step
	public void select_filter_criteria_for_door(String dockView) {
		dockManagerPage.selectFilterCriteria(dockView);
	}

	@Step
	public void get_Open_DoorsInRange(String dockView) {
		List<String> openDoors = dockManagerPage.getOpenDoors();
		String openDoor = "";
		Range<Integer> range = null;
		if ("Inbound".equalsIgnoreCase(dockView))
			range = Range.between(230, 246);
		else if ("Outbound".equalsIgnoreCase(dockView))
			range = Range.between(350, 366);
		for (String door : openDoors) {
			if (range.contains(Integer.parseInt(door))) {
				openDoor = door;
				break;
			}
		}
		logger.info("Valid open door to be used " + openDoor);
		Assert.assertNotEquals("No Valid Open Doors Available..Doors available:" + openDoors, openDoor, "");
		//set door details
		/*if ("Inbound".equalsIgnoreCase(dockView))
			RunTimeData.setInboundDoor(openDoor);
		else if ("Outbound".equalsIgnoreCase(dockView))
			RunTimeData.setOutboundDoor(openDoor);*/
	}

	@Step
	public void click_on_Manual_Move() {
		moveCreationPage.clickManualMove();
	}

	@Step
	public void create_Manual_Move(String dockView) {
		//get trailerNumer and door number from test flow data
		/*String message = moveCreationPage.createManualMove(dockView,trailerNumber,doorNumber);
		assertTrue(message, message.contains(Constants.TRAIL_MOVE_SUCCESS));*/
	}

	@Step
	public void click_on_Yard_ManagementLink() {
		yardManagementPage.clickYardManagementLink();
	}

	@Step
	public void click_on_Yard_Management_Move_Queue() {
		yardManagementPage.clickYardManagementMoveQueueLink();
	}

	@Step
	public void force_Move_from_YDMQ(String dockView) {
		String trailer = "";
		//get trailer details from test flow data
		/*if ("Inbound".equalsIgnoreCase(dockView))
			trailer = RunTimeData.getInboundTrailer();
		else if ("Outbound".equalsIgnoreCase(dockView))
			trailer = RunTimeData.getOutBoundTrailer();*/
		String message = yardManagementMoveQueuePage.forceMove(trailer);
		if (!message.contains("Assign"))
			assertTrue(message, message.contains(Constants.MOVE_IS_FORCED));
		int assignAndForceMoveCount = yardManagementMoveQueuePage.getMovesPresentInAssignAndForceStatus();
		ymsData.setAssignAndForceMoveCount(assignAndForceMoveCount);
	}

	@Step
	public void open_YMS_Driver_home_page() {
		ymsLoginPage.getUrl(config.ymsDriverUiUrl);
	}

	@Step
	public void login_to_driverUI() {
		login_to_YMS();
	}

	@Step
	public void acceptTheTrailer(String dockView) {
		String trailer = "";
		//get trailer details from test flow data
		/*if ("Inbound".equalsIgnoreCase(dockView))
			trailer = RunTimeData.getInboundTrailer();
		else if ("Outbound".equalsIgnoreCase(dockView))
			trailer = RunTimeData.getOutBoundTrailer();*/
		logger.info("Assign and Force Move Count:{}", ymsData.getAssignAndForceMoveCount());
		boolean moveStatus = ymsDriverPage.acceptTrailer(trailer, ymsData.getAssignAndForceMoveCount());
		assertTrue("Trailer is not displayed to accept the Move", moveStatus);
	}

	@Step
	public void logOut() {
		ymsLoginPage.clickLogoutButton();
	}

	@Step
	public void verify_status_of_door() {
		List<String> openDoors = dockManagerPage.getOpenDoors();
		//get outbound door from test flow data
		//		assertTrue("Outbound door is not free even after Gateout", openDoors.contains(RunTimeData.getOutboundDoor()));
	}

	//	@Step
	//	public void click_on_TrailerEdit() {
	//		yardManagementPage.clickTrailerEdit();
	//	}
	//	
	//	@Step
	//	public void retrive_Trailer_details() {
	//		trailerEditPage.retriveTrailerDetails();
	//	}
	//	
	//	@Step
	//	public void update_Trailer_details() {
	//		trailerEditPage.updateWalmartStatus();
	//	}
	//	
	@Step
	public void click_on_outbound() {
		dockManagementPage.clickOutbound();
	}

	@Step
	public void click_on_outbound_trailer_move() {
		dockManagementPage.clickOutboundTrailerMove();
	}

	@Step
	public void enter_Trailer_details() {
		//get door and trailer number from test flow data
		//		outboundMovePage.enterTrailerDetails(doorNumber, trailerNumber);
	}

	@Step
	public void perform_outbound_move() {
		String message=outboundMovePage.performOutboundMove();
		assertTrue(message, message.contains("Move executed successfully"));
	}


	@Step
	public void logout_YMS_Driver() {
		ymsDriverPage.clickLogoutButton();
	}

	@Step
	public void perform_TrailerGateOut_jms() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		ymsHelper.publishGateOutEvent(testFlowData);
	}

	@Step
	public void perform_TrailerDoorAssign_jms(String doorType) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		if(doorType.equalsIgnoreCase("Inbound"))
			ymsHelper.doorAssignEventInbound(testFlowData);
		else{
			ymsHelper.doorAssignEventOutbound(testFlowData);
		}


	}
	@Step
	public void perform_TrailerDoorAssignRDC_jms()
	{
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		ymsHelper.doorAssignEventRDC(testFlowData);
	}

	@Step
	public void publish_ReceivingReceipts_RDC_jms(String labelCout)
	{
		ymsHelper.PublishReceivingReceiptEventRDC(labelCout);
	}
	
	@Step
	public void trailerCheckIn(String freightType) {
		try {
			if (freightType.equalsIgnoreCase("INBOUND")) {
				String trailerCheckInMessage = ymsHelper.constructTrailerCheckInMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"CHECK_IN");
			}else if(freightType.equalsIgnoreCase("OUTBOUND")){
				String trailerCheckInMessage = ymsHelper.constructTrailerOBGateInMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"OB_GATEIN");	
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Checking In the Trailer", e);
		}
	}
	
	@Step
	public void doorAssign(String freightType) {
		try {
			if (freightType.equalsIgnoreCase("INBOUND")) {
				String trailerCheckInMessage = ymsHelper.constructDoorAssignMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"DOOR_ASSIGN");
			}else if(freightType.equalsIgnoreCase("OUTBOUND")){
				String trailerCheckInMessage = ymsHelper.constructOBDoorAssignMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"DOOR_ASSIGN");
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Assigning Door to the Trailer", e);
		}
	}
	
	@Step
	public void trailerGateOUT(String freightType) {
		try {
			if (freightType.equalsIgnoreCase("INBOUND")) {
				String trailerCheckInMessage = ymsHelper.constructGateOutMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"GATE_OUT");
			}else if(freightType.equalsIgnoreCase("OUTBOUND")){
				String trailerCheckInMessage = ymsHelper.constructGateOutMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"GATE_OUT");
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Getting Out the Trailer", e);
		}
	}
	
	@Step
	public void trailerBumpMove(String freightType) {
		try {
			if (freightType.equalsIgnoreCase("INBOUND")) {
				String trailerCheckInMessage = ymsHelper.constructBumpMoveMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"VDOOR_TO_YARD_ASSIGN");
			}else if(freightType.equalsIgnoreCase("OUTBOUND")){
				String trailerCheckInMessage = ymsHelper.constructBumpMoveMessage(freightType);
				ymsHelper.publishYMSMessage(trailerCheckInMessage,"VDOOR_TO_YARD_ASSIGN");
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Assigning Door to the Trailer", e);
		}
	}
}
