package com.walmart.supplychain.nextgen.common;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.junit.Assume;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.jayway.jsonpath.JsonPath;
import com.walmart.execution.dto.FeatureStatus;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.reporting.GenerateExecutionStatus;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingHelper;
import com.walmart.supplychain.nextgen.fixit.FIXitEnd2EndSteps;
import com.walmart.supplychain.nextgen.fixit.web.pages.FixitHomePage;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.outbound.steps.webservices.OutboundServices;
import com.walmart.supplychain.nextgen.problem.steps.ProblemSteps;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;
import com.walmart.supplychain.thor.manifestservices.steps.webservices.ManifestServicesHelper;

import cucumber.api.Result;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java8.En;
import cucumber.runtime.ScenarioImpl;
import io.strati.libs.commons.configuration.ConfigurationException;
import io.strati.libs.commons.configuration.PropertiesConfiguration;
import net.minidev.json.JSONObject;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.SerenityReports;
import net.serenitybdd.cucumber.suiteslicing.SerenityTags;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.steps.StepEventBus;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class Hooks extends ScenarioSteps implements En {
	static final String FEATURE_STATUS_KEY = "featureStatus";
	static final String TEST_FLOW_DATA_KEY = "testFlowData";
	private static final String ERROR_LOG = "ERROR_LOG";
	static final String DATA_FILE = "data.json";
	@Autowired
	CleanUpScripts cleanUpScripts;
	@Autowired
	OutboundServices outboundService;
	@Autowired
	GenerateExecutionStatus generateExecutionStatus;
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	ProblemSteps problemSteps;
	
	@Autowired
	ManifestServicesHelper manifestServicesHelper;
	@Autowired
	IDMHelper idmHelper;
	@Autowired
	YMSHelper ymsHelper;
	
	Logger logger = LogManager.getLogger(Hooks.class);
	HashMap<String, Object> hm = new HashMap<>();
	
	@Autowired
	FIXitEnd2EndSteps fixitStep;
	
	@Autowired
	Environment environment;
	
	@Autowired
	CatalystReceivingHelper catalystReceivingHelper;
	
	@SuppressWarnings("unchecked")
	@Before()
	public void beforeScenario(Scenario scenario) {
		if(threadLocal.get()==null) {
			threadLocal.set(hm);
		}
		Map<String, FeatureStatus> featuresMap = (Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY);
		String featureFileName = getFeatureFileName(scenario);
		if(Config.isParallel) {
			SerenityTags.create().addTagWith("THREAD_"+Thread.currentThread().getId()+"_"+featureFileName, "THREAD");
		}
		if (featuresMap != null && featuresMap.get(featureFileName) != null
				&& featuresMap.get(featureFileName).isFailed()) {
			Assume.assumeTrue(
					featureFileName + ".feature- Scenario '" + featuresMap.get(featureFileName).getFailedScenario()
							+ "' has failed! Skipping " + scenario.getName(),
					false);
		} else {
			if(Config.isParallel) {
				Thread.currentThread().setName("Thread_"+Thread.currentThread().getId()+"_"+featureFileName);
			}
			logger.info("====================={}------{}=====================", featureFileName, scenario.getName());
			if (featuresMap == null || !featuresMap.containsKey(featureFileName)) {
				pushStatus(featureFileName, scenario.getName(), false);
			}
		}
		List<String> tagNames = (List<String>) scenario.getSourceTagNames();
		if (tagNames != null && !tagNames.isEmpty() && tagNames.contains("@fixitmobile")) {
			try {
				beforeFixitMobile(scenario);
			} catch (ConfigurationException | InterruptedException e) {
				e.printStackTrace();
			} 
		}
		else if(tagNames != null && !tagNames.isEmpty() && tagNames.contains("@loadingtablet")){
			try {
				beforeLoadingTablet(scenario);
			} catch (ConfigurationException | InterruptedException e) {
				e.printStackTrace();
			} 
		}
		else if(tagNames != null && !tagNames.isEmpty() && tagNames.contains("@pharmacymobile")){
			try {
				beforePharmReceiving(scenario);
			} catch (ConfigurationException | InterruptedException e) {
				e.printStackTrace();
			} 
		}
		else if(tagNames != null && !tagNames.isEmpty() && tagNames.contains("@catalystmobile")){
			try {
				beforeCatalystReceiving(scenario);
			} catch (ConfigurationException | InterruptedException e) {
				e.printStackTrace();
			} 
		}
		else if(tagNames != null && !tagNames.isEmpty() && tagNames.contains("@myappsmobile")){
			try {
				beforeMyApps(scenario);
			} catch (ConfigurationException | InterruptedException e) {
				e.printStackTrace();
			} 
		}
		else if(tagNames != null && !tagNames.isEmpty() && tagNames.contains("@dpbmobile")){
			try {
				beforeDPBPicking(scenario);
			} catch (ConfigurationException | InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	//@Before("@fixitmobile")
	public void beforeFixitMobile(Scenario scenario) throws ConfigurationException, InterruptedException {
		System.setProperty("appName", "fixit");
		logger.info("Fixit mobile app config set ");
		try {
			updateMobileAppConfig();
			}
		finally {
		}
	}
	
	public void beforeLoadingTablet(Scenario scenario) throws ConfigurationException, InterruptedException {
		System.setProperty("appName", "myapps");
		logger.info("Loading Tablet app config set ");
		try {
			updateMobileAppConfig();
			}
		finally {
		}
	}
	
	public void beforePharmReceiving(Scenario scenario) throws ConfigurationException, InterruptedException {
		System.setProperty("appName", "pahrmacymyapps");
		logger.info("Pharmacy receiving app config set ");
		try {
			updateMobileAppConfig();
			}
		finally {
		}
	}
	
	public void beforeCatalystReceiving(Scenario scenario) throws ConfigurationException, InterruptedException {
		System.setProperty("appName", "catalystlauncherapp");
		logger.info("Catalyst Launcher app config set ");
		try {
			updateMobileAppConfig();
			}
		finally {
		}
	}
	
	public void beforeMyApps(Scenario scenario) throws ConfigurationException, InterruptedException {
		System.setProperty("appName", "myapps");
		logger.info("Loading Tablet app config set ");
		try {
			updateMobileAppConfig();
			}
		finally {
		}
	}

	public void beforeDPBPicking(Scenario scenario) throws ConfigurationException, InterruptedException {
		System.setProperty("appName", "dpbVision");
		logger.info("DPB Vision app config set ");
		try {
			updateMobileAppConfig();
		}
		finally {
		}
	}
	
	
	
	private void updateMobileAppConfig() {
		try {
			PropertiesConfiguration config = null;
			config = new PropertiesConfiguration("./src/test/resources/env.properties");
			String str=(String)config.getProperty("webdriver.drivertype");
			if(str != null && str.equalsIgnoreCase("notappium")) {
				config.setProperty("webdriver.drivertype", "appium");
				config.save();
				Thread.sleep(10000);
				str=(String)config.getProperty("webdriver.drivertype");
				logger.info("webdriver.drivertype value is : {}",str);
			}
		} catch (ConfigurationException | InterruptedException e) {
			e.printStackTrace();
		} 
	}
	
	public void cleanUpDoorsFromOccupiedList() {
		if(Config.isParallel) {
			String doorNumber=idmHelper.getDoorNumber();
			boolean removalStatus=ymsHelper.getInboundOccupiedDoorsList().remove(doorNumber);
			if(removalStatus) {
				logger.info("Removed the inbound door {} from occupied list as part of cleanup",doorNumber);
				synchronized(ymsHelper.getInboundOccupiedDoorsList()) {
					ymsHelper.getInboundOccupiedDoorsList().notify();
				}
			}
			for(String door :ymsHelper.getOutboundDoorsFromTestFlowData()) {
				 removalStatus=ymsHelper.getInboundOccupiedDoorsList().remove(door);
				if(removalStatus) {
					logger.info("Removed the outbound door {} from occupied list as part of cleanup",door);
					synchronized(ymsHelper.getOutboundOccupiedDoorsList()) {
						ymsHelper.getOutboundOccupiedDoorsList().notify();
					}
				}
			}
		}
	}
	public void dataCleanUp(Scenario scenario,boolean isIgnored) throws JSONException {
		//createEmailDataFile();
		Map<String, FeatureStatus> featuresMap = (Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY);
		String featureFileName = getFeatureFileName(scenario);
		if (threadLocal.get().get(TEST_FLOW_DATA_KEY) != null) {
			logger.info("$$$ TestFlowData After {}-{} Last Scenario is :{}", featureFileName, scenario.getName(),
					threadLocal.get().get(TEST_FLOW_DATA_KEY).toString());
		}
		if (!scenario.isFailed() && featuresMap != null && !featuresMap.get(featureFileName).isFailed()) {
			cleanUpScripts.dataCleanUp();
		}
		outboundService.cleanUpStoMocks();
		cleanUpDoorsFromOccupiedList();
		if (Config.DC == DC_TYPE.ATLAS) {
			problemSteps.revertPOChanges();
		}
		if (Config.DC == DC_TYPE.GDC) {
			fixitStep.logoutFixit();
		}
		manifestServicesHelper.deleteOMSMock();
		HashMap<String, Object> threadLocalMap = threadLocal.get();
		Set<Map.Entry<String, Object>> entries = threadLocalMap.entrySet();
		Iterator<Map.Entry<String, Object>> iterator = entries.iterator();
		while (iterator.hasNext()) {
			Entry<String, Object> entry = iterator.next();
			if (!entry.getKey().equals(FEATURE_STATUS_KEY)) {
				iterator.remove();
			}
		}
		logger.info("Removed thread local entries");
		if(isIgnored) {
			StepEventBus.getEventBus().assumptionViolated("Previous steps are Failed,Marking as ignored ");
			
		}
	}

	@After()
	public void afterScenario(Scenario scenario) throws JSONException, ConfigurationException, InterruptedException {
		Map<String,FeatureStatus> featuresMap=(Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY);
		String featureFileName=getFeatureFileName(scenario);
		boolean isIgnored=false;
		if(scenario.isFailed()) {
			if (featuresMap==null||featuresMap.get(featureFileName)==null||!featuresMap.get(featureFileName).isFailed()) {
				logger.info("### Failed {}------{}=====================",featureFileName,scenario.getName());
				logError(featureFileName,scenario);
				pushStatus(getFeatureFileName(scenario), scenario.getName(), true);
				if (threadLocal.get().get(TEST_FLOW_DATA_KEY) != null) {
					logger.info("$$$ TestFlowData After {}-{} Scenario is :{}", featureFileName, scenario.getName(),
							threadLocal.get().get(TEST_FLOW_DATA_KEY).toString());
				}
				
				if(Config.DC == DC_TYPE.CATALYST) {
					dataCleanUp(scenario,isIgnored);
					catalystReceivingHelper.updateConfig("false");
				}
					
			}
		}else if(featuresMap.get(featureFileName).isFailed()) {
			logger.info("Skipped {}------{}=====================",featureFileName,scenario.getName());
			isIgnored=true;
		}else {
			logger.info("Successfully Completed {}------{}=====================",featureFileName,scenario.getName());
			if(threadLocal.get().get(TEST_FLOW_DATA_KEY)!=null) {
				logger.info("%%% TestFlowData After {}-{} Scenario is :{}", featureFileName,scenario.getName(),threadLocal.get().get(TEST_FLOW_DATA_KEY).toString());
			}
		}
		showStepMessage(featureFileName);
		List<String> tagNames = (List<String>) scenario.getSourceTagNames();
		if (tagNames.contains("@LastScenario")) {
			logger.info("{} is the last Scenario", scenario.getName());
			updateTestFlowDataInFeatureStatusTestFlowData(featureFileName);
			if(Config.isPipeline) {
				generateExecutionStatus.generateExecStatus(featureFileName);
			}
			
			if(Config.DC == DC_TYPE.CATALYST) {
				catalystReceivingHelper.updateConfig("false");
			}
			
			showStepMessage(featureFileName);
			if (Config.DC==DC_TYPE.MCC_RDC) {
				Config.DC=DC_TYPE.MCC;
			}
			else if (Config.DC==DC_TYPE.ATLAS_RDC) {
				Config.DC=DC_TYPE.ATLAS;
			}
			else if (Config.DC==DC_TYPE.ACC_RDC) {
				Config.DC=DC_TYPE.ACC;
			}
			dataCleanUp(scenario,isIgnored);
		}

	}

	@SuppressWarnings("unchecked")
	private void showStepMessage(String featureFileName) {
		FeatureStatus featureStatus = ((Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY))
				.get(featureFileName);
		if (featureStatus != null && featureStatus.getTestFlowData() != null) {
			Serenity.recordReportData().withTitle("Test Flow Data").andContents(featureStatus.getTestFlowData());
		}
		// StepEventBus.getEventBus().addDescriptionToCurrentTest("");//Add
		// description for scenario/Test

	}

	private String getFeatureFileName(Scenario scenario) {
		String filePath = scenario.getId();
		return filePath.substring(filePath.lastIndexOf('/') + 1, filePath.indexOf(".feature"));
	}

	private void pushStatus(String featureFileName, String scenarioName, boolean status) {
		Map<String, FeatureStatus> featuresMap = null;
		if (threadLocal.get().get(FEATURE_STATUS_KEY) == null) {
			featuresMap = new HashMap<>();
		} else {
			featuresMap = (Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY);
		}

		logger.info("Feature File Name:" + featureFileName);
		FeatureStatus featureStatus = featuresMap.get(featureFileName) == null ? new FeatureStatus()
				: featuresMap.get(featureFileName);
		if (status) {
			featureStatus.setFailedScenario(scenarioName);
		}
		if (Config.featureFileToNameMap.containsKey(featureFileName))
			featureStatus.setFeatureName(Config.featureFileToNameMap.get(featureFileName));
		else
			featureStatus.setFeatureName(featureFileName);

		featureStatus.setIsFailed(status);
		if (threadLocal.get().get(TEST_FLOW_DATA_KEY) != null) {
			featureStatus.setTestFlowData(threadLocal.get().get(TEST_FLOW_DATA_KEY).toString());
		}
		featuresMap.put(featureFileName, featureStatus);
		threadLocal.get().put(FEATURE_STATUS_KEY, featuresMap);
	}

	private void updateTestFlowDataInFeatureStatusTestFlowData(String featureFileName) {
		Map<String, FeatureStatus> featuresMap = (Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY);
		if (threadLocal.get().get(TEST_FLOW_DATA_KEY) != null) {
			featuresMap.get(featureFileName).setTestFlowData(threadLocal.get().get(TEST_FLOW_DATA_KEY).toString());
		}
	}

	private void logError(String featureFileName, Scenario scenario) {
		Field field = FieldUtils.getField(((ScenarioImpl) scenario).getClass(), "stepResults", true);
		field.setAccessible(true);
		try {
			ArrayList<Result> results = (ArrayList<Result>) field.get(scenario);
			for (Result result : results) {
				if (result.getError() != null) {
					logger.error("Error Scenario: {}", scenario.getId(), result.getError());
					//writeToFile(featureFileName, scenario, getStackTrace(result));
					Map<String, FeatureStatus> featuresMap = (Map<String, FeatureStatus>) threadLocal.get()
							.get(FEATURE_STATUS_KEY);
					featuresMap.get(featureFileName).setReasonForFailure(result.getError().getMessage());
				}
			}
		} catch (Exception e) {
			logger.error("Error while logging error", e);
		}
	}
	
}
