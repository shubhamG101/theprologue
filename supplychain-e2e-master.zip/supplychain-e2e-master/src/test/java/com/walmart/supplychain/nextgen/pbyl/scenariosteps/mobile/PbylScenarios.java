package com.walmart.supplychain.nextgen.pbyl.scenariosteps.mobile;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.pbyl.steps.mobile.PbylSteps;
import com.walmart.supplychain.nextgen.printing.steps.webservices.PrintingSteps;

import cucumber.api.java.en.*;
import net.thucydides.core.annotations.Steps;

public class PbylScenarios {
private boolean isCloudPrinting=false;
	@Steps
	PbylSteps pbylSteps;
	
	@Steps
	PrintingSteps printingSteps;
	
	@Given("^user selects the printer$")
	public void selectPrinter() {
		if(Config.DC==DC_TYPE.ATLAS&&isCloudPrinting) {
			pbylSteps.launchPbylUrl();
		}else {
			printingSteps.bringPrinterUp();
			pbylSteps.launchPbylUrl();
			pbylSteps.searchforPrinter();
			pbylSteps.selectOnlinePrinter();
		}
	}
	
	
	//@And("^user scans the induct pallets \"([^\"]*)\" and complete the pbyl process$")
	/*public void scanInductPalletDoorCompletePbylProcess(String inductPalletNames) {
		pbylSteps.scanInductPalletAndCompletePbylProcess(inductPalletNames);
	}*/
	
	@And("^user clears slots and parent containers for induct labels \"([^\"]*)\"$")
	public void userClearsSlotsAndParentContainers(String inductPalletNames) {
		pbylSteps.clearSlotsAndParentContainers(inductPalletNames);
	}
	@And("^user scans induct label \"([^\"]*)\"$")
	public void userScansInductLabel(String inductPalletName) {
		pbylSteps.scanInductLpn(inductPalletName);
	}
	@Then("^user starts pbyl trip for induct label \"([^\"]*)\"$")
	public void userStartsPbylTripForInductLabel (String inductPalletName) {
		pbylSteps.startTrip(inductPalletName);
	}
	@Then("^user scans all slots for induct label \"([^\"]*)\"$")
	public void userScansAllSlotsForInductPallet (String inductPalletName) {
		pbylSteps.scanAllSlots(inductPalletName);
	}
	@Then("^user complete pbyl trip for induct label \"([^\"]*)\"$")
	public void userCompletePbylTripForInductPallet  (String inductPalletName) {
		pbylSteps.completeTrip(inductPalletName);
	}
	@And("^user closes container outside trip for induct labels \"([^\"]*)\"$")
	public void closeContainerOutsideTrip(String inductPalletNames) {
		pbylSteps.closeContainerOutsideTripForInductPallets(inductPalletNames);
	}
	@Then("^user completes trip for induct label \"([^\"]*)\"$")
	public void completeTrip(String inductPalletName) {
		pbylSteps.completeTrip(inductPalletName);
	}
	@Then("^user pauses and resumes the trip for induct label \"([^\"]*)\"$")
	public void pauseAndResumeTrip(String inductPalletName) {
		pbylSteps.pauseAndResumeTrip(inductPalletName);
	}
	@Then("^user reports and validate overage for induct label \"([^\"]*)\"$")
	public void reportAndValidateOverage(String inductPalletName) {
		pbylSteps.reportAndValidateOverage(inductPalletName);
	}
	@Then("^user reports and validate shortage for induct label \"([^\"]*)\"$")
	public void reportAndValidateShortage(String inductPalletName) {
		pbylSteps.reportAndValidateShortage(inductPalletName);
	}
	@Then("^user finds and scans all shortage cases for induct label \"([^\"]*)\"$")
	public void pickShortageCases(String inductPalletName) {
		pbylSteps.pickShortageCases(inductPalletName);
	}
	@And("^user true outs and validate all shortage cases for induct label \"([^\"]*)\"$")
	public void trueOutShortageCases(String inductPalletName) {
		pbylSteps.trueOutShortageCases(inductPalletName);
	}
	@And("^user closes container during trip for induct label \"([^\"]*)\"$")
	public void closeContainerDuringTripForInductPallet(String inductPalletName) {
		pbylSteps.closeContainerDuringTripForInductPallet(inductPalletName);
	}
	
}
