package com.walmart.supplychain.nextgen.inventory.pages.mobile;

import static net.serenitybdd.rest.SerenityRest.given;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.pages.PageObject;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class InventoryVtr extends SerenityHelper {

	@Autowired
	Environment endpoint;

	@Autowired
	Environment environment;

	Response response;
	List<String> splitQty;

	private DocumentContext parsedJson;

	Logger logger = LogManager.getLogger(this.getClass());

	// WebDriver driver;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	@FindBy(xpath = "//div/button/span[contains(text(),'OK')]")
	private WebElement handleAuthErro;

	@FindBy(xpath = "//p[contains(text(),'Scan a label to begin')]")
	private WebElement homeScreen;

	@FindBy(xpath = "//ion-grid//a[contains(text(),' EXCEPTION ')]")
	private WebElement clickException;

	@FindBy(xpath = "//h2[contains(text(),'Adjustment is not allowed on LOADED containers.')]")
	private WebElement loadedContainerException;

	@FindBy(xpath = "//button[contains(text(),'SUBMIT')]")
	private WebElement submitVTRButton;

	@FindBy(xpath = "//ion-select")
	private WebElement selectVtr;
	// ion-select
	@FindBy(xpath = "//ion-select-popover//ion-item[2]")
	private WebElement selectVtrType;

	@FindBy(xpath = "//ion-card-content/button[@class=\"qty-uom\"]/span[contains(text(),'AdjustBy')]/span")
	private WebElement vtrQty;

	@FindBy(xpath = "//ion-alert//span[contains(text(),'Confirm')]")
	private WebElement confirmVTR;

	@FindBy(xpath = "//ion-alert//span[contains(text(),'OKAY')]")
	private WebElement successfulVTRConfirmMsg;

	// Damage

	@FindBy(xpath = "//ion-card/ion-grid//ion-avatar")
	private WebElement damageContainer;

	@FindBy(xpath = "//span[@id='totalQuantity']")
	private WebElement damageQty;

	@FindBy(xpath = "//a[@id='item-raiseException']")
	private WebElement raiseDamageExeption;

	@FindBy(xpath = "//ion-select[@placeholder='Select Reason']")
	private WebElement selectDamageTypeList;

	@FindBy(xpath = "//ion-label[text()='Damages']/parent::ion-item/ion-radio")
	// @FindBy(xpath = "//ion-label[text()='Damages']")
	private WebElement selectDamageTypeAsText;

	@FindBy(xpath = "//ion-input[@placeholder='Adjust By']")
	private WebElement selectAdjustBy; // click on and enter qty

	@FindBy(xpath = "//ion-select[@placeholder='ea']")
	private WebElement selectEaDamageBy;

	@FindBy(xpath = "//ion-label[text()='vnpk']/parent::ion-item/ion-radio")
	private WebElement selectVnpkDamageBy;

	@FindBy(xpath = "//button[contains(text(),' SUBMIT')]")
	private WebElement submitDamageButton;

	@FindBy(xpath = "//ion-alert//span[contains(text(),'Confirm')]")
	private WebElement confirmDamage;

	@FindBy(xpath = "//ion-select-popover//ion-label[text()='True Out']/..")
	private WebElement trueOutOption;

	@FindBy(id = "selectReasonCode")
	private WebElement selectReasonCode;

	@FindBy(id = "raiseException")
	private WebElement raiseException;

	@FindBy(id = "pageTitle")
	private WebElement pageTitle;

	@FindBy(tagName = "ion-loading")
	private WebElement loader;

	////////////// Split Pallet///////

	@FindBy(xpath = "//ion-label[contains(text(), 'Split Pallet' )]")
	private WebElement splitpalletLabel;

	@FindBy(xpath = "//span[contains(text(), 'whpk' )]")
	private WebElement verifyWHPKText;

	@FindBy(xpath = "//ion-row[1]/ion-col[2]/ion-card-content")
	private WebElement verifyWHPKQtyText;

	@FindBy(xpath = "//a[contains(text(), ' SPLIT PALLET ' )]")
	private WebElement splitPalletLink;

	@FindBy(xpath = "//ion-input")
	private WebElement inputSplitQty;

	@FindBy(xpath = "//ion-grid[3]/ion-row[1]/ion-col[1]/ion-card-content")
	private WebElement splitContainerLabel;

	@FindBy(xpath = "//a[contains(text(), ' TRANSFER QTY ' )]")
	private WebElement transferLink;

	@FindBy(xpath = "//span[contains(text(), 'OK' )]")
	private WebElement successfulAlert;

	@FindBy(xpath = "//a[contains(text(), ' PRINT LABEL ' )]")
	private WebElement validateSplitSuccessful;

	Boolean loadedException;
	Boolean vtrException;

	@FindBy(xpath = "//h2[contains(text(),'Delivery for the container has already been finalized.')]")
	private WebElement vtrFinalException;

	public void vtrHomePageLanding() {
		WebDriver driver = getDriverInstance();
		if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC || Config.DC == DC_TYPE.WITRON) {
			logger.info("Url:{}", endpoint.getProperty("inv_vtr_ep"));
			driver.get(endpoint.getProperty("inv_vtr_ep"));
		} else {

			logger.info("MCC/ACC URL");

		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(homeScreen).waitUntilVisible();
		logger.info("home page visible");

	}

	public void scanSplitPallet(String container) {
		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		logger.info("Url:{}", endpoint.getProperty("inv_split_ep"));
		driver.get(endpoint.getProperty("inv_split_ep"));
		sleep(5);

		Failsafe.with(retryPolicy).run(() -> {
			logger.info("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
					+ container + "'; return scan;})()));");
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
					+ container + "'; return scan;})()));");
			logger.info("Inventory App :: Split Pallet scan completed");
			sleep(4);

		});
	}

	public String splitContainer(String container, String splitQty) {
		try {
			element(verifyWHPKText).waitUntilVisible();
			element(verifyWHPKQtyText).waitUntilVisible();

			String qty = element(verifyWHPKQtyText).getText();
			logger.info("whpk qty before split {}", qty);

			element(splitPalletLink).waitUntilVisible();

			element(splitPalletLink).waitUntilClickable();
			element(splitPalletLink).click();
			sleep(3);

			element(inputSplitQty).waitUntilVisible();

			element(inputSplitQty).waitUntilClickable();
			sleep(2);

			element(inputSplitQty).click();
			sleep(2);
			element(inputSplitQty).sendKeys(splitQty);
			sleep(1);

			element(splitContainerLabel).waitUntilVisible();

			String splitCntrLabel = element(splitContainerLabel).getText();
			sleep(1);

			logger.info("Splitted container label {}", splitCntrLabel);
			element(transferLink).waitUntilClickable();

			element(transferLink).click();
			sleep(1);

			element(successfulAlert).waitUntilVisible();
			element(successfulAlert).waitUntilClickable();
			sleep(1);

			element(successfulAlert).click();
			sleep(1);

			element(validateSplitSuccessful).waitUntilVisible();
			return splitCntrLabel;
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting inventory response", e);
		}

	}

	public void scanContainer(String container) {
		try {
			WebDriver driver = getDriverInstance();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Failsafe.with(retryPolicy).run(() -> {
				vtrHomePageLanding();

				logger.info("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
						+ container + "'; return scan;})()));");
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
								+ container + "'; return scan;})()));");
				logger.info("Inventory App :: UPC scan completed");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				element(clickException).waitUntilClickable();
				element(clickException).click();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			});
		} catch (WebDriverException e) {
			throw new TestCaseFailure(ErrorCodes.INVENTORY_SCAN_CONTAINER_FAILED, e);
		}
	}

	public void scan(String container) {
		try {
			WebDriver driver = getDriverInstance();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Failsafe.with(retryPolicy).run(() -> {
				vtrHomePageLanding();
				logger.info("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
						+ container + "'; return scan;})()));");
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
								+ container + "'; return scan;})()));");
				logger.info("Inventory App :: UPC scan completed for container:{}", container);
				sleep();
				element(raiseException).waitUntilEnabled();
			});
		} catch (WebDriverException e) {
			throw new TestCaseFailure(ErrorCodes.INVENTORY_SCAN_CONTAINER_FAILED, e);
		}
	}

	public boolean scanLoadedContainerToDamage(String container) {
		try {
			WebDriver driver = getDriverInstance();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Failsafe.with(retryPolicy).run(() -> {
				vtrHomePageLanding();
				logger.info("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
						+ container + "'; return scan;})()));");
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
								+ container + "'; return scan;})()));");
				logger.info("Inventory App :: UPC scan completed");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				element(clickException).waitUntilClickable();
				element(clickException).click();
				loadedException = element(loadedContainerException).waitUntilVisible().isPresent();
				logger.info("Unable to Damage Loaded Container " + element(loadedContainerException).getText());

				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			});
		} catch (WebDriverException e) {
			throw new TestCaseFailure(ErrorCodes.INVENTORY_SCAN_CONTAINER_FAILED, e);
		}
		return loadedException;
	}

	public int getVtrQty() {
		int vtrQTY = 0;
		element(vtrQty).waitUntilVisible();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		vtrQTY = Integer.parseInt(element(vtrQty).getText());
		logger.info("VTR value " + vtrQTY);
		return vtrQTY;
	}

	public void fileVtrAgainstContainer() {
		try {

			Thread.sleep(1000);

			element(selectVtr).click();
			Thread.sleep(1000);

			element(selectVtrType).waitUntilVisible();
			element(selectVtrType).waitUntilClickable();
			element(selectVtrType).click();
			Thread.sleep(15000);

			element(submitVTRButton).waitUntilClickable();
			element(submitVTRButton).click();
			Thread.sleep(2000);

			element(confirmVTR).waitUntilVisible();
			element(confirmVTR).waitUntilClickable();
			element(confirmVTR).click();
			Thread.sleep(3000);

			element(successfulVTRConfirmMsg).waitUntilVisible();
			element(successfulVTRConfirmMsg).waitUntilClickable();
			element(successfulVTRConfirmMsg).click();
			Thread.sleep(2000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (WebDriverException e) {
			throw new TestCaseFailure(ErrorCodes.INVENTORY_UNABLE_SUBMIT_VTR, e);
		}

	}

	public boolean fileVtrAgainstFinalizedContainer() {
		try {

			Thread.sleep(1000);

			element(selectVtr).click();
			Thread.sleep(1000);

			element(selectVtrType).waitUntilVisible();
			element(selectVtrType).waitUntilClickable();
			element(selectVtrType).click();
			Thread.sleep(15000);

			vtrException = element(vtrFinalException).waitUntilVisible().isPresent();
			logger.info("Unable to VTR Container Post Delivery Finalization " + element(vtrFinalException).getText());

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (WebDriverException e) {
			throw new TestCaseFailure(ErrorCodes.INVENTORY_SUBMIT_VTR_FINALIZED_CONTAINER, e);
		}
		return vtrException;

	}

	public void scanContainerDamage(String container) {
		try {
			WebDriver driver = getDriverInstance();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Failsafe.with(retryPolicy).run(() -> {
				vtrHomePageLanding();
				logger.info("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
						+ container + "'; return scan;})()));");
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value ='"
								+ container + "'; return scan;})()));");
				logger.info("Inventory App :: UPC scan completed");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				element(damageContainer).waitUntilClickable();
				element(damageContainer).click();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			});
		} catch (WebDriverException e) {
			throw new AutomationFailure("Something went wrong while scanning container in inventory", e);
		}
	}

	public int getDamageQty() {
		int vtrQTY = 0;
		element(damageQty).waitUntilVisible();
		vtrQTY = Integer.parseInt(element(damageQty).getText());
		logger.info("VTR value " + vtrQTY);
		return vtrQTY;
	}

	public void fileDamageAgainstContainer() {
		try {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			element(raiseDamageExeption).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			element(selectDamageTypeList).waitUntilClickable();

			element(selectDamageTypeList).click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			element(selectDamageTypeAsText).waitUntilVisible();
			// element(selectDamageTypeAsText).waitUntilClickable();

			element(selectDamageTypeAsText).click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			element(selectAdjustBy).click();

			element(selectAdjustBy).sendKeys("-1");

			/*
			 * try { Thread.sleep(1000); } catch (InterruptedException e) {
			 * e.printStackTrace(); } element(selectEaDamageBy).click();
			 * 
			 * try { Thread.sleep(2000); } catch (InterruptedException e) {
			 * e.printStackTrace(); }
			 * 
			 * element(selectVnpkDamageBy).click();
			 */
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			element(submitDamageButton).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			element(confirmDamage).waitUntilVisible();
			element(confirmDamage).waitUntilClickable();
			element(confirmDamage).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		} catch (WebDriverException e) {
			logger.error(e);
			throw new AutomationFailure("Something went wrong while performing damage", e);
		}
	}

	public void trueOutContainer(String container) {
		vtrHomePageLanding();
		element(pageTitle).waitUntilVisible();
		sleep();
		scan(container);
		click(raiseException);
		element(selectReasonCode).waitUntilEnabled();
		sleep(4);
		click(selectReasonCode);
		element(trueOutOption).waitUntilEnabled();
		sleep();
		click(trueOutOption);
		element(submitVTRButton).waitUntilEnabled();
		sleep(4);
		click(submitVTRButton);
		click(confirmVTR);
		sleep();
		click(successfulVTRConfirmMsg);
		logger.info("Successfully performed True out for case:{}", container);

	}
}