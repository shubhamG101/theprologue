package com.walmart.supplychain.nextgen.loading.scenariosteps.mobile;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.acc.loading.scenariosteps.ACCLoadingSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.loading.steps.db.LoadingDBSteps;
import com.walmart.supplychain.nextgen.loading.steps.mobile.LoadingAppSteps;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingSteps;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class LoadingScenario {
	@Steps
	LoadingAppSteps loadingAppSteps;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Steps
	LoadingSteps loadingSteps;

	@Steps
	LoadingDBSteps loadingDBSteps;

	@Steps
	YMSSteps ymsSteps;

	@Steps
	InventorySteps inventorySteps;
	
	@Steps
	ACCLoadingSteps aCCLoadingSteps;

	Logger logger = LogManager.getLogger(this.getClass());

	WebDriver driver;

	@When("^user starts Loading by scanning all containers,Door and Trailer$")
	public void user_starts_Loading_by_scanning_all_containers_Door_and_Trailer() {
		loadingAppSteps.loadContainers();
	}

	@Then("^user verifies the Load ID, WTMS Load ID and Trailer Number from Loading$")
	public void user_verifies_the_Load_ID_WTMS_Load_ID_and_Trailer_Number_from_Loading() {

		loadingSteps.validateLoadedCntrs();
	}

	@And("^user verifies container as loaded in Inventory$")
	public void user_verifies_container_as_loaded_in_Inventory() {

		inventorySteps.validateInventory();
	}

	@When("^user closes the load in Loading$")
	public void when_user_closes_the_load_in_Loading() {

		loadingAppSteps.closeLoads();
	}

	@And("^user verifies the load status as \"([^\"]*)\" and Container status as \"([^\"]*)\" in Loading$")
	public void user_verifies_the_load_status_and_Container_status_in_Loading(String loadStatus,
			String containerStatus) {
		loadingSteps.validateloadStatusAfterCloseLoad(loadStatus);
		loadingSteps.validateCntrStatus(containerStatus);
	}
	
	@And("^Loading should update the status of that container to \"([^\"]*)\" in VTR$")
	public void Loading_should_update_the_status_of_that_container_to_in_vtr(String containerStatus) {

		loadingSteps.validateCntrStatusForVtr(containerStatus);
	}
	
	@When("^user starts Loading by scanning \"([^\"]*)\" containers the app should not permit the same$")
	public void loadDamagedContainers(String containerType){
	   
		loadingAppSteps.loadDamageContainers();
		
	}
	
	@Then ("^user REOPEN the already closed load in loading and put the same ON HOLD$")
	public void user_reopen_the_closed_load_in_loading() {
		
		loadingAppSteps.reopenAndHoldLoad();
		
	}
	
	@Then ("^user opens the Load and performs UNLOAD container operation$")
	public void user_opens_Load_performs_unload_container_operation() {
		
		loadingAppSteps.unloadContainer();
	}
	
	@Then ("^user loads mcb container$")
	public void userLoadsMcbContainer() {
		
		loadingAppSteps.loadMCBContainers();
	}
	
	@Then ("^validate mcb containers$")
	public void validateMcbContainer() {
		
		loadingSteps.validateMCBContainers();
	}
	
	@Then ("^validate inventory for mcb containers$")
	public void validateInventoryForMcbContainers() {
		
		inventorySteps.validateMCBInventory();
	}
	
	@Then("^user verifies the Load ID, WTMS Load ID and Trailer Number from Loading API$")
	public void user_verifies_the_Load_ID_WTMS_Load_ID_and_Trailer_Number_from_Loading_API() {

		loadingSteps.validateLoadDetailsThroughAPI();
	}
	
	@And("^user verifies the load status as \"([^\"]*)\" and Container status as \"([^\"]*)\" in acc Loading API$")
	public void userVerifiesStatusOfTheLoadAndLoadedContainersAPIACC(String loadStatus,String status) {
		loadingSteps.validateloadStatusAfterCloseLoadThroughAPI(loadStatus);
		aCCLoadingSteps.verifyContainerStatusThroughAPI(status);
	}
	
	@And("^user verifies the load status as \"([^\"]*)\" and Container status as \"([^\"]*)\" in mcc Loading API$")
	public void userVerifiesStatusOfTheLoadAndLoadedContainersAPIMCC(String loadStatus,String status) {
		loadingSteps.validateloadStatusAfterCloseLoadThroughAPI(loadStatus);
		aCCLoadingSteps.verifyContainerStatusThroughAPI(status);
	}
	
	@And("^user verifies load in momentum$")
	public void userVerifiesLoadInMomentum() {
		loadingSteps.validateLoadInMomentum();
	}
	
}
