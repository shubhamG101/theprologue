package com.walmart.supplychain.nextgen.wtms.scenariosteps;
import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;
import org.json.JSONException;
import com.walmart.supplychain.nextgen.idoc.steps.webservices.IDOCSteps;
import com.walmart.supplychain.nextgen.wtms.stepswebservices.WtmsSteps;

public class WtmsScenarios {

	@Steps
	WtmsSteps wtmsSteps;

	
	@And("^user checks the STO details in WTMS$")
	public void user_checks_the_STO_details_in_WTMS() throws JSONException {
		wtmsSteps.validateSto();
	}
	

}
