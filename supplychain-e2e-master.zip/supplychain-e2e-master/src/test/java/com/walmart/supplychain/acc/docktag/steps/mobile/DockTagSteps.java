package com.walmart.supplychain.acc.docktag.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.docktag.pages.mobile.ReceivingDocTagPage;
import com.walmart.supplychain.nextgen.receiving.pages.mobile.ReceivingPage;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingSteps;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class DockTagSteps {

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	TextParser textParser;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	ReceivingPage receivingPage;

	@Autowired
	ReceivingDocTagPage receivingDocTagPage;

	@Autowired
	DockTagHelper dockTagHelper;

	@Autowired
	Environment environment;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String DOOR_TYPE = "offline";
	String testFlowData;
	private DocumentContext parsedJson;
	private static final String POMATCH = "$.testFlowData.poDetails[?(@.poNumber == '";
	private static final String ITMMATCH = "')].poLineDetails[?(@.itemNumber==";
	private static final String DELIVERY_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..deliveryNumber";
	private static final String INBOUND_DOOR_JSON_PATH = "$.testFlowData.deliveryDetails..inboundDoorNumber";
	private static final String PO_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..poNumbers[*]";
	private static final String DELIVERY_DETAILS_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails[*]";
	private static final String DOCKTAG_SET_JSON_PATH = "$.testFlowData.deliveryDetails[*].dockTags";
	private static final String DOCKTAG_GET_JSON_PATH = "$.testFlowData.deliveryDetails[*].dockTags[*]";
	private static final String DOCKTAG_FROM_RECEIVE_INSTRUCTION_JSON_PATH = "$[?(@.containerException=='DT' && @.completeTs!=null)].trackingId";
	private String mappedFloorLine;
	private List<String> dockTagContainerList;
	private List<String> dockTagCreatedContainerList = new ArrayList<String>();
	private static final String TESTDATAFLOW = "testFlowData";
	private boolean statusResult=false;
	private String dockTagContainer=null;
	
	@Step
	public void populateDoorType() {
		try {
			String testData = (String) threadLocal.get().get(TESTDATAFLOW);

			JSONArray listOfDeliveries = JsonPath.read(testData, DELIVERY_DETAILS_NUMBER_JSON_PATH);
			String deliveryString = listOfDeliveries.toJSONString();
			List<DeliveryDetail> deliveryList = objectMapper.readValue(deliveryString,
					new TypeReference<List<DeliveryDetail>>() {
					});
			deliveryList.get(0).setDoorType(DOOR_TYPE);
			String updatedtestflowdata;
			JSONArray listofDeliveryJson = jsonUtil.converyListToJsonArray(deliveryList);
			updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofDeliveryJson,
					"$.testFlowData.deliveryDetails");
			threadLocal.get().put(TESTDATAFLOW, updatedtestflowdata);
			logger.info(
					"test flow data after Assigning the offline door for ACC:" + threadLocal.get().get(TESTDATAFLOW));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to populate door type", e);
		}

	}

	@Step
	public void createDockTagPallet() {
		try {
			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			parsedJson = JsonPath.parse(testFlowData);
			List<String> poNumberList = parsedJson.read(PO_NUMBER_JSON_PATH);

			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Creating Docktag for the item {}", itemNum);
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
					receivingPage.scanUPC(itemUPC);

					receivingPage.closeIconForDockTag();
					receivingPage.cancelPallet();

					receivingPage.scanUPC(itemUPC);
					receivingDocTagPage.clickOnPalletCompleteButton();
					Assert.assertTrue(ErrorCodes.DOCKTAG_PALLET_NOT_CREATED,
							receivingDocTagPage.isPalletCompletedMssgDisplayed());
					logger.info("Created Docktag for the item {}", itemNum);
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Dock Tag Pallet creation", e);
		}

	}

	@Step
	public void validateCreatedDocktag() {
		try {
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			List<String> deliveryNumberList =  JsonPath.parse(testFlowData).read(DELIVERY_NUMBER_JSON_PATH);
			String deliveryNumber = deliveryNumberList.get(0);
			String deliveryContainerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
			dockTagCreatedContainerList = JsonPath.parse(deliveryContainerResponse).read(DOCKTAG_FROM_RECEIVE_INSTRUCTION_JSON_PATH);
			Assert.assertTrue(ErrorCodes.DOCKTAG_PALLET_NOT_CREATED, dockTagCreatedContainerList.size() > 0);
			logger.info("DockTag created in Receiving -  {}",dockTagCreatedContainerList);
			
			String testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowData, dockTagCreatedContainerList, DOCKTAG_SET_JSON_PATH);
			threadLocal.get().put(TESTDATAFLOW, testFlowDataUpdated);
			logger.info("TestFlowData after updating DockTag: {}",
			String.valueOf(threadLocal.get().get(TESTDATAFLOW)));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating created Dock Tag in Receiving", e);
		}
	}
	
	@Step
	public void validateCompletedDocktagStatus() {
		try {
			//Receiving COntainer/Instruction response APIfor Docktag wont have any difference. Hence commenting this as of now. And Added one more step in Inventory to validated deleted Docktag 
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			List<String> dockTagContainerList = JsonPath.parse(testFlowData).read(DOCKTAG_GET_JSON_PATH);
			List<String> deliveryNumberList =  JsonPath.parse(testFlowData).read(DELIVERY_NUMBER_JSON_PATH);
			String deliveryNumber = deliveryNumberList.get(0);

			logger.info("Dock Tag Pallet list : {}", dockTagContainerList);
			for (String dockTag : dockTagContainerList) {
				logger.info("Validating dock tag status in Receiving for DockTag: {}", dockTag);
				Failsafe.with(retryPolicy).run(() -> {
					String deliveryContainerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
					List<String> completeTs = JsonPath.parse(deliveryContainerResponse).read("$[?(@.trackingId=='"+dockTag+"')].completeTs");
					Assert.assertNotNull(ErrorCodes.DOCKTAG_STATUS_MISMATCH_IN_RECEIVING, completeTs.get(0));
					
				});

				logger.info("Validated dock tag status in Receiving for DockTag: {}", dockTag);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Dock Tag status in Receiving", e);
		}
	}

	@Step
	public void validateDockTagStatusInInventory(String expDockTagStatus) {
		try {
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			List<String> dockTagContainerList = JsonPath.parse(testFlowData).read(DOCKTAG_GET_JSON_PATH);
			for (String dockTag : dockTagContainerList) {
				logger.info("Validating dock tag status " + expDockTagStatus + " in Inventory for DockTag: {}", dockTag);
				Failsafe.with(retryPolicy).run(() -> {
					Assert.assertEquals(ErrorCodes.DOCKTAG_STATUS_MISMATCH_IN_INVENTORY, expDockTagStatus,
							dockTagHelper.getDockTagStatusInInvent(dockTag));
				});
				logger.info("Validated dock tag status " + expDockTagStatus + " in Inventory for DockTag: {}", dockTag);
//				checkDockTagLabels(dockTag);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating creatd Dock Tag status in Inventory", e);
		}
	}
	
	@Step
	public void validateDockTagDeletedInInventory() {
		try {
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			List<String> dockTagContainerList = JsonPath.parse(testFlowData).read(DOCKTAG_GET_JSON_PATH);
			for (String dockTag : dockTagContainerList) {
				logger.info("Validating whether dock tag deleted from Inventory : {}", dockTag);
				Failsafe.with(retryPolicy).run(() -> {
					Assert.assertEquals(ErrorCodes.DOCKTAG_NOT_DELETED_IN_INVENTORY, Constants.FALIURE_STATUS_CODE,
							dockTagHelper.getInverntoryStatusCodeForTheDeletedDocktag(dockTag));
				});
				logger.info("Dock tag deleted from Inventory : {}", dockTag);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating deleted Dock Tag status in Inventory", e);
		}
	}

	@Step
	public void scanFloorLine() {
		try {
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			parsedJson = JsonPath.parse(testFlowData);
			List<String> inboundDoorList = parsedJson.read(INBOUND_DOOR_JSON_PATH);
			String inboundDoor = inboundDoorList.get(0);
			mappedFloorLine = dockTagHelper.getFloorLineForTheDoor(inboundDoor);
			receivingDocTagPage.checkDoorScanPage();
			receivingDocTagPage.clickOnReceiveMenu();
			receivingDocTagPage.clickOnFloorLineTab();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Scanning the Floor line", e);
		}
	}

	@Step
	public void receiveDockTagPalletAndComplete() {
		try {
			boolean isLineScannedOnce = false;
			parsedJson = JsonPath.parse(testFlowData);
			List<String> dockTagContList = parsedJson.read(DOCKTAG_GET_JSON_PATH);

			for (String dockTag : dockTagContList) {
				if (!isLineScannedOnce) {
					logger.info("Mapped floor line " + mappedFloorLine);
					receivingDocTagPage.scanFloorLine(mappedFloorLine);
				}

				logger.info("Receiving Docktag : {}", dockTag);
				receivingDocTagPage.scanDockTag(dockTag);
				receivingDocTagPage.clickOnCompleteDockTagButton();
				receivingDocTagPage.clickOnConfirmationCompleteButton();
//				Assert.assertTrue(ErrorCodes.DOCKTAG_PALLET_NOT_CREATED,
//						receivingDocTagPage.isPalletDockTagScanSuccessful());
				logger.info("Docktag received successfully : {}", dockTag);

				Thread.sleep(5000);

				// Scan completed dock tag pallet should show an error
				receivingDocTagPage.scanFloorLine(mappedFloorLine);
				logger.info("Floor line is " + mappedFloorLine);
				receivingDocTagPage.scanDockTag(dockTag);
				receivingDocTagPage.clickOnOkButton();
				isLineScannedOnce = true;
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the dock tag pallet", e);
		}
	}

	@Step
	public void receiveInvalidDockTagPallet() {

		try {
			receivingDocTagPage.scanFloorLine(mappedFloorLine);
			logger.info("Receiving invalid Docktag: {}");
			receivingDocTagPage.scanDockTag("kjghghghjgfghjfgjhs");
			receivingDocTagPage.clickOnDialogueInvalidDockTag();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning invalid dock tag pallet", e);
		}
	}

	@Step
	public void receiveCompletedDockTagPallet() {

		try {
			boolean isLineScannedOnce = false;
			parsedJson = JsonPath.parse(testFlowData);
			List<String> dockTagContList = parsedJson.read(DOCKTAG_GET_JSON_PATH);

			for (String dockTag : dockTagContList) {
				if (isLineScannedOnce) {
					receivingDocTagPage.scanFloorLine(mappedFloorLine);
				}

				logger.info("Receiving Completed Docktag : {}", dockTag);
				receivingDocTagPage.scanDockTag(dockTag);
				receivingDocTagPage.clickOnOkButton();
				isLineScannedOnce = true;
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving completed dock tag pallet", e);
		}
	}

	public void checkDockTagLabels(String lpn) {

		// framing the URL for containers
		String labelingurl = environment.getProperty("labeling_data") + lpn;
		logger.info(labelingurl);

		Response response = null;
		response = when().get(labelingurl);
		Assert.assertEquals(ErrorCodes.LABEL_RESPONSE_NOT_CORRECT, Constants.SUCESS_STATUS_CODE,
				response.getStatusCode());

		JSONArray actualclientId = JsonPath.parse(response.getBody().asString()).read("$..clientID");
		Assert.assertEquals(ErrorCodes.LABEL_CLIENT_ID_MISMATCH, "RCV", actualclientId.get(0));
	}
	
	@Step
	public void printPBYLDockTag() {
		try {
			receivingPage.clickOnRecevingRightMenu();
			receivingPage.clickOnPrintPBYLDockTagOption();
			try {
				Thread.sleep(5000);
			} catch(Exception e) {
				e.printStackTrace();
			}
			receivingPage.clickOnCloseIconPrintPBYLDockTag();
			try {
				Thread.sleep(5000);
			} catch(Exception e) {
				e.printStackTrace();
			}
			receivingPage.clickOnBackArrowScanUPCScreen();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("unable to print PBYL DockTag ", e);
		}
	}
	
	@Step
	public void receivePBYLDockTagPalletAndComplete() {
		try {
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			String location = "PTR001";
			boolean isLocationScannedOnce = false;
			parsedJson = JsonPath.parse(testFlowData);
			List<String> dockTagContList = parsedJson.read(DOCKTAG_GET_JSON_PATH);

			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			parsedJson = JsonPath.parse(testFlowData);
			List<String> poNumberList = parsedJson.read(PO_NUMBER_JSON_PATH);
			List<String> deliveryNumberList = parsedJson.read(DELIVERY_NUMBER_JSON_PATH);
			String deliveryNumber = deliveryNumberList.get(0);

			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				receivingPage.clickOnReceivePBYLDockTagButton();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Creating Docktag for the item {}", itemNum);
					List<String> orderQtys = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].poVnpkQty");
					int orderQty = Integer.parseInt(orderQtys.get(0));
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
				for (String dockTag : dockTagContList) {
					if (!isLocationScannedOnce) {
					logger.info("Location " + location);
					receivingDocTagPage.scanPBYLLocation(location);
				}
				logger.info("Receiving Docktag : {}", dockTag);
				receivingDocTagPage.scanPBYLDockTag(dockTag);
				receivingPage.scanUPCPBYLReceiving(itemUPC);
				int qty = Integer.parseInt(receivingPage.getQtyToReceive());
				receivingPage.enterQtyToReceivePBYL(qty);
				receivingPage.clickOnReceiveButton();
				receivingPage.waitForScanNextItemMessageToAppear();
				receivingPage.clickOnFinishPalletButton();
				logger.info("PBYL Docktag received successfully : {}", dockTag);
				Thread.sleep(5000);
				isLocationScannedOnce = true;
			}
			String containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
			logger.info("ContainerResponse for the given delivery::{}", containerResponse);
			receivingHelper.setReceivingInstruction(containerResponse, poNumber, itemNum, "pbyl");
			logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
			logger.info("TestFlowData after Updating Containers:: " + threadLocal.get().get("testFlowData"));
			}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the PBYL dock tag pallet", e);
		}
	}
}
