package com.walmart.supplychain.nextgen.problem.pages;

import net.serenitybdd.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProblemDetailsPage extends PageObject{

	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//div[@id='problemSearchTable']//table[@data-role='selectable']//td[4]/div")
	private WebElement problemStatusField;
	
	@FindBy(xpath="//div[@id='problemSearchTable']//table//tbody/tr")
	private WebElement problemRow;
	
	@FindBy(xpath="//span[contains(text(),'View Full Details')]")
	private WebElement viewDetails;
	
	@FindBy(xpath="//md-select-value[@class='md-select-value']")
	private WebElement resolutionMenu;
	
	@FindBy(xpath="//div[text()='Added a PO line']")
	private WebElement addAPOLine;
	
	@FindBy(xpath="//input[@ng-model='resolution.resolutionQty']")
	private WebElement qtyToReceive;
	
	@FindBy(xpath="//input[@ng-model='resolution.poNbr']")
	private WebElement poNumberField;
	
	@FindBy(xpath="//input[@ng-model='resolution.poLineNbr']")
	private WebElement poLineNumberField;
	
	@FindBy(xpath="(//span[text()='Update'])[2]")
	private WebElement updateButton;
	
	public String getProblemStatus() {
		element(problemStatusField).waitUntilVisible();
		return problemStatusField.getText();
	}
	
	public void selectProblem() {
		element(problemStatusField).waitUntilVisible();
		element(problemStatusField).click();
	}
	
	public void clickOnViewDetails() {
		element(viewDetails).waitUntilVisible();
		element(viewDetails).click();
	}
	
	public void clickOnResolutionMenu() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(resolutionMenu).waitUntilVisible();
		element(resolutionMenu).click();
	}
	
	public void clickOnAddAPOLine() {
		element(addAPOLine).waitUntilVisible();
		element(addAPOLine).click();
	}
	
	public void enterQtyToReceive(String Qty) {
		element(qtyToReceive).waitUntilVisible();
		element(qtyToReceive).click();
		element(qtyToReceive).type(Qty);
	}
	public void enterPONumber(String poNumber) {
		element(poNumberField).waitUntilVisible();
		element(poNumberField).click();
		element(poNumberField).type(poNumber);
	}
	public void enterPOLineNumber(String poLineNumber) {
		element(poLineNumberField).waitUntilVisible();
		element(poLineNumberField).click();
		element(poLineNumberField).type(poLineNumber);
	}
	
	public void clickOnUpdateButton() {
		element(updateButton).waitUntilVisible();
		element(updateButton).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
