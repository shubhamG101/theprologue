package com.walmart.supplychain.baja.loading.loadinghelper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.FileNames;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BajaLoadingHelper {
    List<String> lines = new ArrayList<String>();
    String line = null;

    public void  updateTruckUpFile(String inputFile, String lpn) {
        try {
        	
            File inpFile = new File(inputFile);
            FileReader fr = new FileReader(inpFile);
            BufferedReader br = new BufferedReader(fr);
            while ((line = br.readLine()) != null) {
                if (line.contains("$"))
                    line = line.replace("$", lpn);
                
                lines.add(line);
                lines.add("\n");
            }
            fr.close();
            br.close();

            FileWriter fw = new FileWriter(FileNames.BAJA_TRUCKUP_FILE);
            BufferedWriter out = new BufferedWriter(fw);
            for(String s : lines) {
                 out.write(s);
          }
            out.flush();
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}