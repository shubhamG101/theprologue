package com.walmart.supplychain.nextgen.rdcs2s.scenariosteps.db;

import com.walmart.supplychain.nextgen.rdcs2s.steps.db.S2SSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class S2SScenario {

	@Steps
	S2SSteps s2sSteps;
	
	@Given("^user prepares testflow data$")
	public void userPrapresTestflowData(){
		s2sSteps.s2sPrepareTestFlowData();
	}
	
	@Given("^user place ecom file in EDI consumer Linux location$")
	public void userPlcaeEcomFileEDIconsumerLinuxLocation() {
		s2sSteps.s2sPlaceEcomFileInLinuxLocation();
	}
	
	
	@Then("^validate ASN in IDOC for asnID$")
	public void userValidateASNInIdocForASNId(){
		s2sSteps.s2svalidateIDOCshipmentDetails();
	}
	
	@Then("^user verifies all the containers are attached in S2S delivery$")
	public void userVerifyContainersAttachedInS2SDelievry(){
		s2sSteps.validateCtrsRDCS2SDelivery();
	}

	@Then("^user verifies the fulfiment records and delivery status \"([^\"]*)\" in OF$")
	public void userVerifiesFulfillmentRecordsInOF(String deliveryStatus){
		s2sSteps.s2sValidateOfflineFulfillmentRecordCount();
		s2sSteps.s2sValidateOfflineDeliveryStatus(deliveryStatus);
	}
	
	@Then("^user verifies FM after Receive$")
	public void userVerifiesFMAfterReceive(){
		s2sSteps.s2sValidateContainerStatusInFMAfterRec();
	}
	
	@Then("^user verifies S2S update after Receive$")
	public void userVerifiesS2SUpdateAfterReceive(){
		s2sSteps.s2sValidateContainerStatusInS2SupdateAftreRec();
	}
	
	@When("^user publish sorter message$")
	public void userPublishSorterMssg(){
		s2sSteps.s2sPublishSorterMessg();
	}
	
	@Then("^user verifies FM after Publishing Sorter message$")
	public void userVerifiesFMAftrePublichingSorterMssg(){
		s2sSteps.s2sValidateContainerStatusInFMAfterPublishingSorterMsg();
	}
	
	@Then("^user verifies S2S update after Publishing Sorter message$")
	public void userVerifiesS2SUpdateAfterPublishingSorterMssg(){
		s2sSteps.s2sValidateContainerStatusInS2SupdateAftrePublishingSorterMssg();
	}
	
	@Then("^user verifies fulfiment delivery status \"([^\"]*)\" in OF$")
	public void userVerifyFulfillmentDeliveryStatus(String deliveryStatus){
		s2sSteps.s2sValidateOfflineDeliveryStatus(deliveryStatus);
	}
}
