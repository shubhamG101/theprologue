package com.walmart.supplychain.nextgen.of.steps.db;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class RDCOrderFulfillmentSteps {

	private String[] xdocData=null;
	private int expectedXdocRecCount=0;
	private String deliveryStatusForXdoc=null;
	private static final String RDCDELIVERYJSONPATH = "$.testFlowData.deliveryDetailsRDC[*].deliveryNumber";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(30,
			20);

	@Autowired
	RDCOrderFulfillmentHelper rdcOrderFulfillmentHelper;

	@Autowired
	MongoUtil mongoUtil;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	String testFlowData;

	Logger logger = LogManager.getLogger(this.getClass());

	@Step
	public  String getdeliveryStatus(String deliveryNumber) throws SQLException {
		return rdcOrderFulfillmentHelper.getdeliveryStatus(deliveryNumber);
	}

	@Step
	public void vadlidateXDOCandDeliveryStatus(){
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		DocumentContext parsedJson = JsonPath.parse(testFlowData);

		List<String> deliveryNumberList = parsedJson.read(RDCDELIVERYJSONPATH);

		for (String deliveryNumber : deliveryNumberList) {
			
			Failsafe.with(retryPolicy).run(() -> {
				deliveryStatusForXdoc= getdeliveryStatus(deliveryNumber);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,"COMPLETED", deliveryStatusForXdoc);
			});
			logger.info("RDC XDOC :: Validated XDOC delivery status for the delivery : "+deliveryNumber);
			
			Failsafe.with(retryPolicy).run(() -> {
				expectedXdocRecCount=(int)rdcOrderFulfillmentHelper.getCountofXDOCRecords(deliveryNumber);
				xdocData=rdcOrderFulfillmentHelper.getXDOC(deliveryNumber);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_RECORD_COUNT,expectedXdocRecCount, xdocData.length-3);
			});
			logger.info("RDC XDOC :: Validated XDOC for the delivery : "+deliveryNumber);

		}

	}

}
