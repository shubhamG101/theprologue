package com.walmart.supplychain.nextgen.idm.pages.ui;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.walmart.supplychain.witron.myapps.pages.MyAppsLoginPage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.selenium.SerenityHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

public class IDMHomePage extends SerenityHelper {
	@FindBy(name="searchText")
	private WebElement searchTextBox;

	@FindBy(xpath="//div[div[text()='Delivery Number(s)']]//input")
	private WebElement deliveryNumberTextBox;

	@FindBy(xpath="//button[span[text()='SEARCH']]")
	private WebElement searchButton;

	@FindBy(xpath="//div[@class='table-container']//mat-row[@class='mat-row']")
	private WebElement deliveryList;

	@FindBy(xpath="//div[text()='DETAILS']")
	private WebElement deliveryDetailsTab;

	@FindBy(xpath="//i[text()='keyboard_arrow_down']")
	private WebElement arrowDownlink;

	@FindBy(xpath="//div[ @id='mat-tab-label-0-1' and contains(text(),'LINES')]")
	private WebElement linesLink;

	@FindBy(xpath="//div[@class='po-lines-container']//mat-row")
	private WebElement poLineList;

	@FindBy(xpath="//div[@class='form-group']/input")
	private WebElement fbqTextBox;

	@FindBy(xpath="//button/i[contains(text(),'save')]")
	private WebElement fbqSaveButton;

	@FindBy(xpath="//button/i[contains(text(),'close')]")
	private WebElement fbqCancelButton;

	@FindBy(xpath="//po-details//div[div[contains(text(),'PO Details')]]//i[contains(text(),'arrow_back')]")
	private WebElement backButton;

	@FindBy(xpath = "//div[text()=' GDM - Global Document Manager ']")
	private WebElement clickOnGdmInUnifiedUI;

	@FindBy(xpath = "//div[text()='Delivery Management']")
	private WebElement deliveryManagement;

	//@FindBy(xpath = "//input[@type='text' and @placeholder='Search for delivery number']")
	@FindBy(xpath = "//input[@placeholder='Search for delivery number']")
	private WebElement searchdeliverynbr;

	@FindBy(xpath = "//p[text()='GDM']")
	private WebElement gdmUI;

	@FindBy(xpath = "//div[@class='ld-sc-ui-search-action']/button")
	private WebElement searchBtn;
	
	@FindBy(xpath ="//span[text()='Scheduled Date : Today']")
	private WebElement removeTodayFilter;

	@FindBy(xpath = "//span[@class='delivery-status']/div/span")
	private WebElement getStatus;

	@FindBy(xpath = "//div[@class='table-content']")
	private WebElement deliverynbr;

	@Autowired
	MyAppsLoginPage myAppsLogin;

	@Autowired
	Environment endpoint;

	@Autowired
	Environment environment;
	Logger logger = LogManager.getLogger(this.getClass());

	@FindBy(xpath = "//tr[@class='MuiTableRow-root']/td[6]")
	private WebElement doorDetached;

	public void searchForDelivery(String deliveryNum) {

		element(searchTextBox).waitUntilVisible();
		element(searchTextBox).waitUntilClickable();
		element(searchTextBox).click();
		element(searchTextBox).type(deliveryNum);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(searchTextBox).sendKeys(Keys.RETURN);
	}

	public void clickOnDeliveryListTab(String deliveryNum) {
		element(deliveryList).waitUntilVisible();
		element(deliveryList).waitUntilClickable();
		getDriverInstance().findElement(By.xpath("//mat-row[@class='mat-row']/mat-cell[text()='"+deliveryNum+"']")).click();
	}

	public List<WebElement> getPOListfromUI() {
		element(deliveryDetailsTab).waitUntilVisible();
		element(deliveryDetailsTab).waitUntilClickable();
		return getDriverInstance().findElements(By.xpath("//div[@class='po-list']//a"));
	}

	public void clickOnArrowDownLink(int numberOfPOInDelivery) {
		element(deliveryDetailsTab).waitUntilVisible();
		element(deliveryDetailsTab).waitUntilClickable();
		if (numberOfPOInDelivery>2) {
			element(arrowDownlink).click();
		}
	}
	public void clickOnPoLink(String PoNum) {
		element(deliveryDetailsTab).waitUntilVisible();
		element(deliveryDetailsTab).waitUntilClickable();
		List<WebElement> poList = getDriverInstance().findElements(By.xpath("//div[@class='po-list']//a[text()='"+PoNum+"']"));
		poList.get(0).click();
	}


	public void clickOnLinesLink() {
		element(linesLink).waitUntilVisible();
		element(linesLink).waitUntilClickable();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(linesLink).click();
	}

	public List<WebElement> getPoLineListfromUI() {
		element(poLineList).waitUntilVisible();
		element(poLineList).waitUntilClickable();
		return getDriverInstance().findElements(By.xpath("//div[@class='po-lines-container']//mat-row"));
	}

	public void clickOnFBQEditButton(int lineNum) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		getDriverInstance().findElement(By.xpath("//mat-table/mat-row["+lineNum+"]//mat-cell[contains(@class,'freightBillQty')]//button//mat-icon[contains(text(),'create')]")).click();
	}

	public void enterFBQ(String fbqQty) {
		element(fbqTextBox).waitUntilVisible();
		element(fbqTextBox).waitUntilClickable();
		element(fbqTextBox).type(fbqQty);
	}

	public void clickOnFBQSaveButton() {
		element(fbqSaveButton).waitUntilVisible();
		element(fbqSaveButton).waitUntilClickable();
		element(fbqSaveButton).click();
	}

	public void clickOnFBQCancelButton() {
		element(fbqCancelButton).waitUntilVisible();
		element(fbqCancelButton).waitUntilClickable();
		element(fbqCancelButton).click();
	}

	public  String getSettedFBQValue(int lineNum) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return getDriverInstance().findElement(By.xpath("//mat-table/mat-row["+lineNum+"]/mat-cell[contains(@class,'freightBillQty')]/span")).getText();
	}

	public void clickOnBackButton() {
		element(backButton).waitUntilVisible();
		element(backButton).waitUntilClickable();
		element(backButton).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public String goToGdmUI() {
		WebDriver driver = getDriverInstance();
		String parentId = driver.getWindowHandle();

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click()", element(clickOnGdmInUnifiedUI));
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return parentId;
	}

	public void searchDeliveryInGDM(String dlvryNbr) {
		WebDriver driver = getDriverInstance();
		element(gdmUI).waitUntilVisible();
		element(searchdeliverynbr).waitUntilVisible();
		element(searchdeliverynbr).clear();
		element(searchdeliverynbr).sendKeys(dlvryNbr);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click()", element(searchBtn));
		click_element(searchBtn);

		if (element(removeTodayFilter).isCurrentlyVisible() && !element(deliverynbr).isCurrentlyVisible()) 
			{
			jse.executeScript("arguments[0].click()", element(removeTodayFilter));
				if (deliverynbr.getText() == dlvryNbr)
					element(deliverynbr).click();
			}
		}

//	public void robot() throws AWTException {
//		Robot robot = new Robot();
//		robot.keyPress(KeyEvent.VK_CONTROL);
//		robot.keyPress(KeyEvent.VK_T);
//		robot.keyRelease(KeyEvent.VK_CONTROL);
//		robot.keyRelease(KeyEvent.VK_T);
//	}

	public void click_element(WebElement element) {
		boolean flag = false;
		while (true) {
			try {
				element.click();
				flag = true;
			} catch (Exception e) {
				flag = false;
			}
			if (flag) {
				try {
					element.click();
				} catch (Exception e) {
					e.getMessage();
				}
				break;
			}
		}
	}

	public String getDeliveryStatusInGDM(String deliveryNbr) throws AWTException, InterruptedException {
		WebDriver driver = getDriverInstance();
		String status = null;
		String parent = null;
		Set<String> windowIds;
		windowIds = driver.getWindowHandles();

		if (windowIds.size() < 2) {
			element(clickOnGdmInUnifiedUI).waitUntilVisible();
			parent = goToGdmUI();
			//robot();
			windowIds = driver.getWindowHandles();
			logger.info("windowIds are " + windowIds);
			Iterator<String> I1 = windowIds.iterator();
			while (I1.hasNext()) {
				String child_window = I1.next();
				if (!parent.equals(child_window)) {
					driver.switchTo().window(child_window);
					searchDeliveryInGDM(deliveryNbr);
					Thread.sleep(1000);
					status = element(getStatus).getText();
					logger.info("search delivery nbr is done and the status is " + status);
					break;
				}
			}
		} else if (windowIds.size() > 0 && (!(driver.getTitle().equalsIgnoreCase("GDM")))) {
			String currentWindow = driver.getWindowHandle();
			logger.info(windowIds + " are windowIds ");
			for (String window : windowIds) {
				driver.switchTo().window(window);
				logger.info("switching tab :: checking whether it's myapps or not");
				if (driver.getTitle().contains("My Apps")) {
					goToGdmUI();
					//robot();
					windowIds = driver.getWindowHandles();
					List<String> windowIdList = new ArrayList<>(windowIds);
					driver.switchTo().window(windowIdList.get(windowIds.size() - 1));
					searchDeliveryInGDM(deliveryNbr);
					Thread.sleep(1000);
					status = element(getStatus).getText();
					logger.info("search delivery nbr is done and the status is " + status);
					driver.switchTo().window(currentWindow);
					break;

				}
			}
		} else if (((driver.getTitle().equalsIgnoreCase("GDM")))) {
			searchDeliveryInGDM(deliveryNbr);
			Thread.sleep(1000);
			status = element(getStatus).getText();
			logger.info("search delivery nbr is done and the status is " + status);

		}
		return status;
	}

	public String checkDoorDetached(String deliveryNbr) {
		WebDriver driver = getDriverInstance();
		String door = null;
		Set<String> windowIds = driver.getWindowHandles();
		for (String window : windowIds) {
			driver.switchTo().window(window);
			if (driver.getTitle().contains("GDM")) {
				searchDeliveryInGDM(deliveryNbr);
				door = element(doorDetached).getText();
				break;
			}
		}
		return door;
	}

	public void closeDriver() {
		WebDriver driver = getDriverInstance();
		logger.info("\nClosing current webDriver session\n");
		driver.quit();
	}

}

