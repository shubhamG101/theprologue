package com.walmart.supplychain.nextgen.op.orderTrackerStatus;

import java.util.HashMap;
import java.util.Map;

public class OrderManagerStatus {
	
	private Map<Integer, String> valueToTextMapping = new HashMap<>();
	
	public OrderManagerStatus() {
		valueToTextMapping.put(1, "NEW");
		valueToTextMapping.put(2, "INPROGRESS");
		valueToTextMapping.put(3, "ACKNOWLEDGED");
		valueToTextMapping.put(4, "REJECTED");
	}
	
	public String getValue(int key){
        return valueToTextMapping.get(key);
    }

}
