package com.walmart.supplychain.nextgen.pbyl.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.TimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.ThreadLocalKeys;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.inventory.pages.mobile.InventoryVtr;
import com.walmart.supplychain.nextgen.pbyl.pages.mobile.PbylPages;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class PbylSteps {

	@Autowired
	PbylPages pbylPage;

	@Autowired
	InventoryVtr inventoryPage;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoints;

	private String receivingInstruction = "$..receivingInstructions[*]";

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired(required = true)
	@Qualifier(value = "pbylHelper")
	PbylHelper pbylHelper;

	Logger logger = LoggerFactory.getLogger(PbylSteps.class);
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	private static final String PBYL_IN_PROGRESS_STATUS = "IN_PROGRESS";
	private static final String PBYL_UNIT_STATUS_LABEL_PRINTED = "LABEL_PRINTED";
	private static final String PBYL_CREATED_STATUS = "CREATED";
	private static final String PBYL_COMPLETED_STATUS = "COMPLETED";
	private static final String PBYL_PAUSED_STATUS = "PAUSED";
	private static final String PBYL_FINALIZING_STATUS_FOR_SHORTAGE = "FINALIZING";
	private static final String PBYL_SHORT_UNIT_STATUS = "SHORT";
	private static final String PBYL_TRUE_OUT_UNIT_STATUS = "OUTS";
	private static final String PBYL_COMPLETED_UNIT_STATUS = "PICKED";
	private static final String PARENT_CONTAINER_ASSOCIATED_STATUS = "PARENT_CONTAINER_ASSOCIATED";
	private static final String FULFILLMENT_ID_JSONPATH = "$..fulfillmentId";
	private static final int OVERAGE_COUNT = 5;

	@Step
	public void searchforPrinter() {
		pbylPage.enterPrinter(environment.getProperty("printer_name"));
	}

	@Step
	public void launchPbylUrl() {
		pbylPage.launchPage(endpoints.getProperty("pbyl_webui_url"));
	}

	@Step
	public void selectOnlinePrinter() {
		try {
			pbylPage.selectOnlinePrinter();
			pbylPage.clickOnProceedButton();
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.PRINTING_SELECT_PRINTER_FAILED_IN_PBYL, e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to select the online printer");
		}

	}

	/*
	 * @Step public void scanInductPalletAndCompletePbylProcess(String
	 * inductPalletName) { List<String>
	 * inductPallets=getInductPalletFromTestFlowData(inductPalletName);
	 * clearSlotsAndParentContainerForInductPallet(inductPallets);
	 * logger.info("induct pallets : {}", inductPallets);
	 * Assert.assertNotEquals(ErrorCodes.OF_INDUCT_LABEL_NOT_GENERATED,
	 * inductPallets.size(), 0); for (String pbylpallet : inductPallets) {
	 * executePBYLTrip(pbylpallet); } }
	 */

	String[] getPoNumberAndItemForInductPallet(String inductPallet) {
		String poNumber = "";
		String itemNumber = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			String poDetailsJson = objectMapper
					.writeValueAsString(JsonPath.read(testFlowData, "$.testFlowData.poDetails[*]"));
			List<PoDetail> poDetailList = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsJson, PoDetail.class);

			for (PoDetail poDetail : poDetailList) {
				poNumber = poDetail.getPoNumber();
				for (PoLineDetail poLineDetail : poDetail.getPoLineDetails()) {
					itemNumber = poLineDetail.getItemNumber();
					for (ReceivingInstruction recvInstruction : poLineDetail.getReceivingInstructions()) {
						if (recvInstruction.getParentContainer().equals(inductPallet))
							return new String[] { poNumber, itemNumber };
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return new String[] { poNumber, itemNumber };
	}

	@Step
	public void scanInductLpn(String inductPalletName) {
		String inductPallet = getInductPalletFromTestFlowData(inductPalletName);
		logger.info("Starting the trip for induct label {}", inductPallet);
		validateOFStatusForInductPallet(inductPallet, PBYL_CREATED_STATUS);
		try {
			List<String> slotNames = pbylPage.scanInductLpn(inductPallet);
			threadLocal.get().put(ThreadLocalKeys.PBYL_SLOTS_FOR_TRIP + inductPalletName, slotNames);
			logger.info("Scanned induct label {}", inductPallet);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_SCAN_INDUCT_LPN, e);
		}
	}

	@Step
	public void startTrip(String inductPalletName) {
		String pbylpallet = getInductPalletFromTestFlowData(inductPalletName);
		try {
			pbylPage.startTrip();
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_START_TRIP, e);
		}
		logger.info("Started Trip for induct label {}", pbylpallet);
		validateOFStatusForInductPallet(pbylpallet, PBYL_IN_PROGRESS_STATUS);
	}

	@Step
	public void scanAllSlots(String inductPalletName) {
		String pbylpallet = getInductPalletFromTestFlowData(inductPalletName);
		try {
			List<String> slotNames = (List<String>) threadLocal.get()
					.get(ThreadLocalKeys.PBYL_SLOTS_FOR_TRIP + inductPalletName);
			pbylPage.scanAllSlots(slotNames);
			List<String> pickedSlots = (List<String>) 	threadLocal.get().get(ThreadLocalKeys.PBYL_PICKED_SLOTS_FOR_TRIP + inductPalletName);
			if(pickedSlots!=null)
				pickedSlots.addAll(slotNames);
			threadLocal.get().put(ThreadLocalKeys.PBYL_PICKED_SLOTS_FOR_TRIP + inductPalletName, pickedSlots);
			slotNames.clear();
			threadLocal.get().put(ThreadLocalKeys.PBYL_SLOTS_FOR_TRIP + inductPalletName, slotNames);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_SCAN_SLOTS, e);
		}
		logger.info("Scanned slots for induct label {}", pbylpallet);
	}

	@Step
	public void completeTrip(String inductPalletName) {
		String pbylpallet = getInductPalletFromTestFlowData(inductPalletName);
		try {
			pbylPage.completeTrip();
			logger.info("Completed Trip for induct label {}", pbylpallet);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_COMPLETE_TRIP, e);
		}
		validateOFStatusForInductPallet(pbylpallet, PBYL_COMPLETED_STATUS);
	}

	@Step
	public void reportAndValidateOverage(String inductPalletName) {
		String inductPallet = getInductPalletFromTestFlowData(inductPalletName);
		try {
			pbylPage.reportOverage(OVERAGE_COUNT);
			logger.info("Reported Overage for induct label {}", inductPallet);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_REPORT_OVERAGE, e);
		}
		validateOFStatusForInductPallet(inductPallet, PBYL_COMPLETED_STATUS);
		int overageCount = pbylHelper.getOverageCount(inductPallet);
		if (overageCount == -1)
			Assert.fail(ErrorCodes.OF_PBYL_VALIDATE_OVERAGE);
		Assert.assertEquals(ErrorCodes.OF_PBYL_OVERAGE_MISMATCH, OVERAGE_COUNT, overageCount);
		logger.info("Validated Overage for induct pallet {}", inductPallet);

	}

	@Step
	public void reportAndValidateShortage(String inductPalletName) {
		String inductPallet = getInductPalletFromTestFlowData(inductPalletName);
		List<String> plannedAndLabelPrintedChildContainers = null;
		try {
			List<String> slotNames = (List<String>) threadLocal.get()
					.get(ThreadLocalKeys.PBYL_SLOTS_FOR_TRIP + inductPalletName);
			String ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
			List<String> listOfChildContainerForFirstSlot = pbylHelper.getChildContainerIdsForSlot(ofResponse,
					slotNames.get(0));
			for(String childContainer:listOfChildContainerForFirstSlot) {
				validateOFStatusForChildContainer(ErrorCodes.OF_PBYL_UNIT_STATUS_NOT_UPDATED_TO_LABEL_PRINT, inductPallet, childContainer, PBYL_UNIT_STATUS_LABEL_PRINTED);
				logger.info("Validated child container {} status is changed to {}",childContainer,PBYL_UNIT_STATUS_LABEL_PRINTED);
			}
			
			plannedAndLabelPrintedChildContainers = pbylHelper.getAllChildContainersForTrip(ofResponse);
			pbylPage.reportShortage(slotNames, listOfChildContainerForFirstSlot);
			logger.info("Reported Shortage for induct label {}", inductPallet);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_REPORT_SHORTAGE, e);
		}
		validateOFStatusForInductPallet(inductPallet, PBYL_FINALIZING_STATUS_FOR_SHORTAGE);
		String ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
		for (String childContainer : plannedAndLabelPrintedChildContainers) {
			Assert.assertEquals(ErrorCodes.OF_PBYL_SHORTAGE_UNIT_STATUS_NOT_UPDATED, PBYL_SHORT_UNIT_STATUS,
					pbylHelper.getFulfillmentUnitStatus(ofResponse, childContainer));
		}
		threadLocal.get().put(ThreadLocalKeys.PBYL_SHORTAGE_CASES_FOR_TRIP + inductPalletName,
				plannedAndLabelPrintedChildContainers);
		logger.info("Validated Shortage for induct pallet {}", inductPallet);

	}

	public void pickShortageCases(String inductPalletName) {
		String inductPallet = getInductPalletFromTestFlowData(inductPalletName);
		List<String> shortageCases = (List<String>) threadLocal.get()
				.get(ThreadLocalKeys.PBYL_SHORTAGE_CASES_FOR_TRIP + inductPalletName);
		String ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
		for (String shortageCase : shortageCases) {
			try {
				String slotName = pbylHelper.getSlotForCase(ofResponse, shortageCase);
				pbylPage.pickShortageCase(shortageCase, slotName);
				logger.info("Picked Shortage Case {}", shortageCase);
			} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
				logger.error("Something went wrong while picking shortage case: {}", shortageCase);
				throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_PICK_SHORTAGE_CASE, e);
			}

		}
		validateOFStatusForInductPallet(inductPallet, PBYL_COMPLETED_STATUS);
		ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
		for (String shortageCase : shortageCases) {
			Assert.assertEquals(ErrorCodes.OF_PBYL_SHORTAGE_UNIT_STATUS_NOT_UPDATED, PBYL_COMPLETED_UNIT_STATUS,
					pbylHelper.getFulfillmentUnitStatus(ofResponse, shortageCase));
		}
		logger.info("Validated Shortage Pick for induct pallet {}", inductPallet);

	}

	public void trueOutShortageCases(String inductPalletName) {
		String inductPallet = getInductPalletFromTestFlowData(inductPalletName);
		List<String> shortageCases = (List<String>) threadLocal.get()
				.get(ThreadLocalKeys.PBYL_SHORTAGE_CASES_FOR_TRIP + inductPalletName);
		for (String shortageCase : shortageCases) {
			try {
				inventoryPage.trueOutContainer(shortageCase);
			} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
				logger.error("Something went wrong while performing trueout for shortage case: {}", shortageCase);
				throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_TRUE_OUT_SHORTAGE_CASE, e);
			}
		}
		validateOFStatusForInductPallet(inductPallet, PBYL_COMPLETED_STATUS);
		String ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
		for (String shortageCase : shortageCases) {
			Assert.assertEquals(ErrorCodes.OF_PBYL_TRUE_OUT_UNIT_STATUS_NOT_UPDATED, PBYL_TRUE_OUT_UNIT_STATUS,
					pbylHelper.getFulfillmentUnitStatus(ofResponse, shortageCase));
		}
		logger.info("Validated true out case for induct pallet {}", inductPallet);

	}

	@Step
	public void pauseAndResumeTrip(String inductPalletName) {
		String pbylpallet = getInductPalletFromTestFlowData(inductPalletName);
		try {
			List<String> slotNames = (List<String>) threadLocal.get()
					.get(ThreadLocalKeys.PBYL_SLOTS_FOR_TRIP + inductPalletName);
			String slotName = slotNames.remove(0);
			pbylPage.pauseTrip(slotName);
			List<String> pickedSlots=new ArrayList<>();
			pickedSlots.add(slotName);
			threadLocal.get().put(ThreadLocalKeys.PBYL_PICKED_SLOTS_FOR_TRIP + inductPalletName, pickedSlots);
			threadLocal.get().put(ThreadLocalKeys.PBYL_SLOTS_FOR_TRIP + inductPalletName, slotNames);
			validateOFStatusForInductPallet(pbylpallet, PBYL_PAUSED_STATUS);
			logger.info("Trip needs to be resumed for Slots: {}", slotNames);
			logger.info("Paused Trip for induct label {}", pbylpallet);
			pbylPage.scanInductLpnAndResumeTrip(pbylpallet);
			logger.info("Resumed the trip for induct pallet : {}", pbylpallet);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_PAUSE_TRIP, e);
		}
		validateOFStatusForInductPallet(pbylpallet, PBYL_IN_PROGRESS_STATUS);
	}

	@Step
	public void executePBYLTrip(String pbylpallet) {
		scanInductLpn(pbylpallet);
		startTrip(pbylpallet);
		scanAllSlots(pbylpallet);
		completeTrip(pbylpallet);
		/*
		 * Currently this method is not used.
		 */
	}

	@Step
	public void clearSlotsAndParentContainers(String inductPalletNames) {
		List<String> inductPallets = getInductPalletsFromTestFlowData(inductPalletNames);
		updateTripExecutionStatusInTestFlowData(inductPallets);
		Set<String> distinctSlots = new HashSet<>();
		for (String inductPallet : inductPallets) {
			distinctSlots.addAll(pbylPage.getDistinctSlotsForInductPallet(inductPallet));
		}

		for (String slot : distinctSlots) {
			Response resp = getSlotResponse(slot);
			if (resp.getStatusCode() == 404) {
				logger.error("No Cases to be deleted in Slot {}  Proceeding ..", slot);
			} else {
				logger.info("There are some cases pending in the slot {} which needs to be deleted", slot);
				net.minidev.json.JSONArray fulfillmentIds = JsonPath.read(resp.asString(), FULFILLMENT_ID_JSONPATH);
				String payloadForDeletion = "[{\"fulfillmentIds\":" + fulfillmentIds.toString() + "}]";
				logger.info("Payload for deletion {}", payloadForDeletion);
				if (Config.DC == DC_TYPE.ATLAS) {
					given().relaxedHTTPSValidation().headers(pbylHelper.getAtlasHeaders()).body(payloadForDeletion)
							.delete(environment.getProperty("fulfillment_delete_ep"));
				} else {
					given().body(payloadForDeletion).delete(environment.getProperty("fulfillment_delete_ep"));
				}
				resp = getSlotResponse(slot);// Get the Slot response again to confirm Slot is cleared
				Assert.assertEquals(ErrorCodes.OF_PBYL_SLOT_NOT_CLEARED, 404, resp.getStatusCode());
			}
			String reUsableContainer = "PC" + slot.substring(slot.length() - 2);
			pbylHelper.deleteInventoryforspecificContainer(reUsableContainer);
		}
		threadLocal.get().put(ThreadLocalKeys.PBYL_SLOTS_TO_BE_CLOSED, distinctSlots);
	}

	@Step
	public void closeContainerDuringTripForInductPallet(String inductPalletName) {
		String inductPallet = getInductPalletFromTestFlowData(inductPalletName);
		List<String> slotNames = (List<String>) threadLocal.get()
				.get(ThreadLocalKeys.PBYL_PICKED_SLOTS_FOR_TRIP+inductPalletName);
		logger.info("List of Slots to be closed before completing the trip:{}", slotNames);
		pbylPage.pbylCloseContainerDuringTrip(slotNames);
		for (String slotName : slotNames) {
			List<String> childContainers = pbylHelper
					.getChildContainerIdsForSlot(pbylHelper.ofServiceResponseForLpn(inductPallet), slotName);
			for (String childContainerId : childContainers) {
				validateOFStatusForChildContainer(
						ErrorCodes.OF_PBYL_CHILD_CONTAINER_STATUS_NOT_UPDATED_FOR_CLOSE_CONTAINER, inductPallet,
						childContainerId, PARENT_CONTAINER_ASSOCIATED_STATUS);
			}
		}
		String[] poNumberAndItem = getPoNumberAndItemForInductPallet(inductPallet);
		logger.info("Induct Pallet:{},Po Number:{},Item Number:{}", inductPallet, poNumberAndItem[0],
				poNumberAndItem[1]);
		pbylHelper.createInstrcutionObject(inductPallet, poNumberAndItem[0], poNumberAndItem[1]);
		Set<String> distinctSlots = (Set<String>) threadLocal.get().get(ThreadLocalKeys.PBYL_SLOTS_TO_BE_CLOSED);
		distinctSlots.removeAll(slotNames);
		logger.info("List of Slots to be closed after closing:{}==>{}", slotNames, distinctSlots);
		threadLocal.get().put(ThreadLocalKeys.PBYL_SLOTS_TO_BE_CLOSED, distinctSlots);
	}

	@Step
	public void closeContainerOutsideTripForInductPallets(String inductPalletNames) {
		List<String> inductPallets = getInductPalletsFromTestFlowData(inductPalletNames);
		Set<String> distinctSlots = (Set<String>) threadLocal.get().get(ThreadLocalKeys.PBYL_SLOTS_TO_BE_CLOSED);
		if (distinctSlots == null || distinctSlots.isEmpty()) {
			distinctSlots = new HashSet<>();
			for (String inductPallet : inductPallets) {
				distinctSlots.addAll(pbylPage.getDistinctSlotsForInductPallet(inductPallet));
			}
		}
		try {
			logger.info("Distinct slots  : {} to be closed", distinctSlots);
			pbylPage.pbylCloseContainerAfterTrip(distinctSlots);
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OF_PBYL_UNABLE_TO_CLOSE_CONTAINER, e);
		}
		for (String inductPallet : inductPallets) {
			String[] poNumberAndItem = getPoNumberAndItemForInductPallet(inductPallet);
			logger.info("Induct Pallet:{},Po Number:{},Item Number:{}", inductPallet, poNumberAndItem[0],
					poNumberAndItem[1]);
			pbylHelper.createInstrcutionObject(inductPallet, poNumberAndItem[0], poNumberAndItem[1]);
		}

	}

	public Response getSlotResponse(String slot) {
		Response resp = null;
		String ofPbylUrl = MessageFormat.format(environment.getProperty("of_pbyl_ep"), slot);
		if (Config.DC == DC_TYPE.ATLAS) {
			resp = given().relaxedHTTPSValidation().headers(pbylHelper.getAtlasHeaders()).get(ofPbylUrl);
		} else {
			resp = when().get(ofPbylUrl);
		}
		logger.error("Response code for OF lpn:{}==>{}", slot, resp.getStatusCode());
		return resp;

	}

	public String getInductPalletFromTestFlowData(String inductPalletName) {
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		List<String> palletsVal = JsonPath.read(testFlowData,
				"$..receivingInstructions[?(@.containerName==\"" + inductPalletName + "\")].parentContainer");
		Assert.assertNotEquals(ErrorCodes.OF_INDUCT_LABEL_NOT_GENERATED, 0, palletsVal.size());
		return palletsVal.get(0);
	}

	public List<String> getInductPalletsFromTestFlowData(String pallets) {
		String[] inductPalletNames = pallets.split(",");
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		List<String> inductPallets = new ArrayList<>();
		for (String inductPalletName : inductPalletNames) {
			List<String> palletsVal = JsonPath.read(testFlowData,
					"$..receivingInstructions[?(@.containerName==\"" + inductPalletName + "\")].parentContainer");
			if (!palletsVal.isEmpty())
				inductPallets.add(palletsVal.get(0));
		}
		Assert.assertEquals(ErrorCodes.OF_PBYL_INDUCT_PALLET_MISMATCH, inductPalletNames.length, inductPallets.size());
		return inductPallets;
	}

	private void updateTripExecutionStatusInTestFlowData(List<String> inductPalletLabels) {
		String runTimeData = threadLocal.get().get("testFlowData").toString();
		try {
			for (String inductPalletLabel : inductPalletLabels) {
				runTimeData = jsonUtils.setJsonAtJsonPath(runTimeData, true,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.parentContainer=='"
								+ inductPalletLabel + "')].isPbylTripExecuted");
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while setting the receiving data", e);
		}
		logger.info("Changed isTripExecuted Status for {}", inductPalletLabels);
		threadLocal.get().put("testFlowData", runTimeData);
	}

	@Step
	public void validateOFStatusForInductPallet(String inductPallet, String expectedStatus) {
		Failsafe.with(retryPolicy).run(() -> {
			String status = pbylHelper.ofInductLabelStatus(inductPallet);
			logger.info("Expected Status:{}", expectedStatus);
			logger.info("Actual Status:{}", status);
			Assert.assertEquals(ErrorCodes.OF_INDUCT_LABEL_STATUS_NOT_GETTING_UPDATED, expectedStatus, status);
		});
	}

	@Step
	public void validateOFStatusForChildContainer(ErrorCodes errorCode, String inductPallet, String childContainerId,
			String expectedStatus) {
		logger.info("Child Container Id:{}", childContainerId);
		Failsafe.with(retryPolicy).run(() -> {
			String childContainerStatus = pbylHelper
					.getFulfillmentUnitStatus(pbylHelper.ofServiceResponseForLpn(inductPallet), childContainerId);
			logger.info("Expected Status:{}", expectedStatus);
			logger.info("Actual Status:{}", childContainerStatus);
			Assert.assertEquals(errorCode, expectedStatus, childContainerStatus);
		});
	}

}
