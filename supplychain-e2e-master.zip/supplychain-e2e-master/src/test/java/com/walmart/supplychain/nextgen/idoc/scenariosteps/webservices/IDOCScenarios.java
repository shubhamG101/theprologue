package com.walmart.supplychain.nextgen.idoc.scenariosteps.webservices;

import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;
import org.json.JSONException;

import com.walmart.supplychain.nextgen.idoc.steps.webservices.IDOCSteps;

public class IDOCScenarios {

	@Steps
	IDOCSteps idocSteps;

	
	@And("^user verifies ASN creation$")
	public void validate_created_ASN() throws JSONException {
		idocSteps.validate_IDOCshipment_Details();
	}
	
	@And("user verifies ASN creation for POCON/DSDC$")
	public void validate_created_ASN_For_POCON_DSDC() throws JSONException {
		idocSteps.validate_IDOCshipment_Details_For_POCON_DSDC();
	}
	
}
