/*
 * Please use FeatureList.java to add/remove feature
 */





/*package com.walmart.supplychain.atlas;
import com.walmart.framework.supplychain.config.FeatureList;
import com.walmart.framework.supplychain.constants.FileNames;
import cucumber.api.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
@RunWith(com.walmart.supplychain.CustomSerenityRunner.class)
@CucumberOptions(
		 monochrome=true,
		 glue = {"com.walmart.supplychain.nextgen","com.walmart.supplychain.atlas"} 
)
public class AtlasRunner {
	@BeforeClass
	public static void executeBeforeAllTests() {
		System.out.println("This will run before all the test features triggered by this runner");
	}
	@AfterClass
	public static void executeAfterAllTests() {
		System.out.println("This will run after all the test features triggered by this runner");
	}
}
*/