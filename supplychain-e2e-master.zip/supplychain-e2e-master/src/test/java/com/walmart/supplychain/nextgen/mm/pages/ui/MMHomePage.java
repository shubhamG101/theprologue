package com.walmart.supplychain.nextgen.mm.pages.ui;

import com.walmart.framework.utilities.selenium.SerenityHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class MMHomePage extends SerenityHelper {

    @FindBy(xpath = "//input[@placeholder='Search for container']")
    private WebElement searchContainer;

    @FindBy(xpath = "//div[@class='ld-sc-ui-search-action']/button")
    private WebElement searchBtn;

    @FindBy(xpath = "//tr[@class='MuiTableRow-root']/td[7]")
    private WebElement moveStatus;

    @FindBy(xpath = "//tr[@class='MuiTableRow-root']/td[1]")
    private WebElement checkbox;

    @FindBy(xpath = "//*[@id='simple-tabpanel-0']/div/div[2]/span[3]/div/div[2]")
    private WebElement noDoorInsidedel;

    @FindBy(xpath = "//tr[@class='MuiTableRow-root']/td[6]")
    private WebElement doorDetached;

    @FindBy(xpath = "//div/button/span[text()='Action']")
    //span[text()='Action']")
    private WebElement actionDropDown;

    @FindBy(xpath = "//li[text()='Force Complete']")
    private WebElement completeMove;

    @FindBy(xpath = "//label[text()='Select a reason...']")
    private WebElement selectReasonFormoveCmplte;

    @FindBy(xpath = "//li[@value='Prime Slot Full']")
    private WebElement primeSlotFull;

    @FindBy(xpath = "//span[text()='Update']")
    private WebElement updateBtn;

    @FindBy(xpath = "//div[text()=' GDM - Global Document Manager ']")
    private WebElement clickOnGdmInUnifiedUI;

    @FindBy(xpath = "//div[text()='Delivery Management']")
    private WebElement deliveryManagement;

    //@FindBy(xpath = "//input[@type='text' and @placeholder='Search for delivery number']")
    @FindBy(xpath = "//input[@placeholder='Search for delivery number']")
    private WebElement searchdeliverynbr;

    Logger logger = LogManager.getLogger(this.getClass());

    @Autowired
    Environment endpoint;

    @Autowired
    Environment environment;

    @Autowired
    MMLoginPage mmLoginPage;

    public void click_element(WebElement element) {
        boolean flag = false;
        while (true) {
            try {
                element.click();
                flag = true;
            } catch (Exception e) {
                flag = false;
            }
            if (flag) {
                try {
                    element.click();
                } catch (Exception e) {
                    e.getMessage();
                }
                break;
            }
        }
    }


    public String moveStatus(String container) throws InterruptedException, AWTException {
        String status = null;
        WebDriver driver = getDriverInstance();
        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));

        String currentWindow = driver.getWindowHandle();
        Set<String> windowIds = driver.getWindowHandles();


//		if (windowIds.size() > 0 && (!(driver.getTitle().contains("My Apps")))) {
//			for (String window : windowIds) {
//				driver.switchTo().window(window);
//
//				if (driver.getTitle().contains("My Apps")) {
//					element(MM).click();
//					sleep();
//					robot();
        windowIds = driver.getWindowHandles();
        List<String> windowIdList = new ArrayList<>(windowIds);
        driver.switchTo().window(windowIdList.get(windowIds.size() - 1));
        driver.get(environment.getProperty("mm_url"));
        mmLoginPage.loginIntoMM(environment.getProperty("nextGenUserName"), environment.getProperty("nextGen"), environment.getProperty("source_number"), "US");
        sleep();
        JavascriptExecutor js = null;
        Actions actions = new Actions(driver);
        actions.moveToElement(searchContainer).click();
        click_element(searchContainer);
        actions.build().perform();
        element(searchContainer).sendKeys(container);
        click_element(searchBtn);
        actions.build().perform();
        sleep();
        status = moveStatus.getText();
        logger.info("move status is " + status);
        sleep();
        driver.close();
        driver.switchTo().window(currentWindow);
//
//					break;
//				}
//
//			}
//		}
        return status;
    }

}
