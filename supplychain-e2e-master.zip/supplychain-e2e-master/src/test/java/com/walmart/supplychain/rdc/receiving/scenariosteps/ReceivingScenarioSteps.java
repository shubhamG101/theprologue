package com.walmart.supplychain.rdc.receiving.scenariosteps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.pharmacy.receiving.scenariosteps.mobile.ReceivingPharmSteps;
import com.walmart.supplychain.rdc.myapps.steps.MyAppsSteps;
import com.walmart.supplychain.rdc.receiving.steps.ReceivingSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class ReceivingScenarioSteps {
	
	@Steps
	ReceivingSteps receivingSteps;
	
	@Steps
	ReceivingPharmSteps receivingPharmSteps;
	
	@Given("^user opens the delivery by scanning the door$")
	public void userOpensTheDeliveryByScanningTheDoor() throws JsonProcessingException
	{
		receivingSteps.scanDoor();
		
	}
	
	@Given("^user reopens the delivery by scanning the delivery$")
	public void userReOpensTheDeliveryByScanningTheDelivery() throws JsonProcessingException
	{
		receivingSteps.reOpenDelivery();
		
	}
	
	@Given("^user start receiving the cases for \"([^\"]*)\" delivery$")
	public void userStartsReceivingTheCases(String deliveryType) throws JsonProcessingException
	{
		receivingSteps.receiveRDCItems(deliveryType);
		
	}
	
	@Then("^user Validates the Received containers and receipts in Receiving$")
	public void userValidatesTheReceivedCasesInReceiving() throws JsonProcessingException
	{
		receivingSteps.validateContainersInReceiving();
		receivingSteps.validateReceiptsInReceiving();
		
	}
	
	@Then("^user Validates the Received containers in RDS$")
	public void userValidatesTheReceivedContainersInRDS() throws JsonProcessingException
	{
		receivingSteps.validateContainersInRDS();
	}
	
	@Given("^user completes the delivery$")
	public void userCompletesTheDelivery() throws JsonProcessingException
	{
		receivingSteps.finalizeDelivery();
		
	}
	
	@Given("^user create the docktag from receiving app$")
	public void userCreatesTheDocktag() throws JsonProcessingException
	{
		receivingSteps.createDockTag();
		
	}
	
	@Given("^user receives the docktag containers$")
	public void userReceivesTheDocktagContainers() throws JsonProcessingException
	{
		receivingSteps.receiveDockTag();
		
	}
	
	@Given("^user does a Pallet Correction from Receiving App$")
	public void userDoesAPalletCorrectionFromReceivingApp() throws JsonProcessingException
	{
		receivingSteps.performPalletCorrection();
		
	}
	
	@Then("^user Validates the Label Correction in Receiving$")
	public void userValidatesTheLabelCorrectionInReceiving() throws JsonProcessingException
	{
		receivingSteps.validateContainersAfterReceivingCorrection();
		receivingSteps.validateReceiptsAfterReceivingCorrection();
		
	}
	
	@Then("^user Validates the Label Correction in RDS$")
	public void userValidatesTheLabelCorrectionInRDS() throws JsonProcessingException
	{
		receivingSteps.validateContainersInRDSAfterRC();
		
	}
	
	@Given("^user completes the DockTag$")
	public void userCompletesTheDockTag() throws JsonProcessingException
	{
		receivingSteps.completeDockTag();
		
	}
	
	@Given("^user does item cataloging$")
	public void userDoesItemCataloging() throws JsonProcessingException
	{
		receivingSteps.catalogItems();
		
	}
	
	@Given("^user Validates GDM after item cataloging$")
	public void userValidatesGDMAfterItemCataloging() throws JsonProcessingException
	{
		receivingSteps.validateGDMForItemCatalog();
		
	}
	
	@Then("^user kills the receiving app$")
	public void killApp() {
		try {
			Thread.sleep(5000);
			receivingPharmSteps.killApp();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
