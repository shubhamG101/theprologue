package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.jms.DC_TYPE;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ListViewPage extends SerenityHelper {

	@Autowired
	Environment environment;

	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s

	@FindBy(xpath = "//*[@class='row-head-item w-200']//*[@class='text-input']")
	private WebElement searchTicketCol_Textbox;

	@FindBy(xpath = "//*[@data-testid='grid-row']")
	private WebElement ticket_Link;

	// search
	@FindBy(xpath = "//*[text()='Search']")
	private WebElement search_Box;

	@FindBy(xpath = "//*[@class='search-box']/section[1]/div[2]/input")
	private WebElement search_Textbox;

	@FindBy(xpath = "//*[@name='claimId']")
	private WebElement search_Textbox_claimID;

	@FindBy(xpath = "//*[@name='damageDisplayId']")
	private WebElement search_Textbox_damageID;

	@FindBy(xpath = "//*[@name='deliveryNumber']")
	private WebElement delivery_Textbox;

	@FindBy(xpath = "//*[@class='searchbox-actions']//*[text()='Search']")
	private WebElement search_Button;

	@FindBy(xpath = "//*[@class='grid-rows']/section[1]")
	private WebElement firstTicket_Link;

	@FindBy(xpath = "//*[text()='Create Exception']")
	private WebElement createExeception_Button;

	@FindBy(xpath = ".//*[@class='grid-rows']//section[2]//div")
	private WebElement ticket_Checkbox;

	@FindBy(xpath = "//*[@id=\"root\"]/div/section[2]/section/section[3]/section[2]/section/section[1]/div[5]/section/div/select")
	private WebElement status_Dropdown;

	@FindBy(xpath = "//*[@id=\"root\"]/div/section[2]/section/section[3]/section[2]/section/section[1]/div[4]/section/div/select")
	private WebElement status_Dropdown2;

	@FindBy(xpath = "//*[@class='grid-bulk-actions hover']")
	private WebElement bulkActions_Link;

	@FindBy(xpath = "//*[text()='Resolution']")
	private WebElement resolution_Link;

	@FindBy(xpath = "//*[text()='Comment']")
	private WebElement comment_Link;
	
	@FindBy(xpath = "//*[@class='icon logout']")
	private WebElement logout_Icon;
	
	@FindBy(xpath = "//*[@name='Yes']")
	private WebElement yes_Buttons;
	
	@FindBy(xpath = "//*[@class='top-links']//li[2]")
	private WebElement damage_Icon;
	
	@FindBy(xpath = "//*[text()='Receiving']")
	private WebElement receiving_Link;
	
	@FindBy(xpath = "//*[@name='claimId']")
	private WebElement claimId_Text;

	@FindBy(xpath = "//*[@id=\"root\"]/div/section[2]/section/section[3]/section[2]/section/section[1]/div[6]/section/div/select")
	private WebElement assignmentGroup_Dropdown;

	//for exporting/downloading the data
	@FindBy(xpath = "/html/body/section/div/section[2]/section/section[2]/section[1]/section[2]/div/div/span/svg")
	private WebElement exportdata;

	@FindBy(xpath = "//*[@class='icon dashboard']")
	private WebElement metrics;

	@FindBy(xpath = "//*[@class='results-count']")
	private WebElement results_count;
	
	public void searchTikcetByTicketId(String id) {
		element(searchTicketCol_Textbox).waitUntilVisible();
		element(searchTicketCol_Textbox).type(id);
		element(ticket_Link).waitUntilVisible();
		element(searchTicketCol_Textbox).click();
	}

	public void searchTicket(String ticketNo) {
		element(search_Box).waitUntilVisible();
		element(search_Box).waitUntilClickable();
		element(search_Box).click();
		element(search_Textbox).waitUntilVisible();
		element(search_Textbox).type(ticketNo);
		element(search_Button).waitUntilVisible();
		search_Textbox.sendKeys(Keys.ENTER);
		//element(search_Button).click();
	}

	public void searchClaim(String ticketNo) {
		element(search_Box).waitUntilVisible();
		element(search_Box).waitUntilClickable();
		element(search_Box).click();
		element(search_Textbox_claimID).waitUntilVisible();
		element(search_Textbox_claimID).type(ticketNo);
		element(search_Button).waitUntilVisible();
		search_Textbox_claimID.sendKeys(Keys.ENTER);
		//element(search_Button).click();
	}

	public void searchDamage(String ticketNo) {
		element(search_Box).waitUntilVisible();
		element(search_Box).waitUntilClickable();
		element(search_Box).click();
		element(search_Textbox_damageID).waitUntilVisible();
		element(search_Textbox_damageID).type(ticketNo);
		element(search_Button).waitUntilVisible();
		search_Textbox_claimID.sendKeys(Keys.ENTER);
		//element(search_Button).click();
	}

	public void clickOnFirstTicket() throws InterruptedException {
		element(firstTicket_Link).waitUntilVisible();
		Thread.sleep(4000);
		element(firstTicket_Link).waitUntilClickable();
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", firstTicket_Link);
	}



	public void clickOnCreateTicket() {
		element(createExeception_Button).waitUntilVisible();
		element(createExeception_Button).waitUntilClickable();
		element(createExeception_Button).click();
	}

	public void selectMultipleTickets() {
		for (int i = 1; i <= 3; i++) {
			String strXpath = "//*[@class='grid-rows']//section[" + i + "]//div";
			WebElement checkbox = getDriver().findElement(By.xpath(strXpath));
			click(checkbox);
		}
	}

	public void searchTicketByDelivery(String deliveryNo) {
		click(search_Box);
		element(delivery_Textbox).waitUntilVisible();
		element(delivery_Textbox).type(deliveryNo);
		element(delivery_Textbox).sendKeys(Keys.ENTER);
		//click(search_Button);
	}

	public void selectTicketStatus(String status) {
		String dc = Config.DC.getValue();
		if(dc.equalsIgnoreCase("gdc") || dc.equalsIgnoreCase("rdc")){
			element(status_Dropdown2).waitUntilVisible();
			element(status_Dropdown2).waitUntilClickable();
			element(status_Dropdown2).selectByValue(status);
		}
		else {
			element(status_Dropdown).waitUntilVisible();
			element(status_Dropdown).waitUntilClickable();
			element(status_Dropdown).selectByValue(status);
		}

	}

	public void selectAssignmentGroup(String group) {
		element(assignmentGroup_Dropdown).waitUntilVisible();
		element(assignmentGroup_Dropdown).waitUntilClickable();
		element(assignmentGroup_Dropdown).selectByValue(group);
	}

	public void clickResolution() {
		Actions actions = new Actions(getDriver());
		actions.moveToElement(bulkActions_Link).build().perform();
		click(resolution_Link);
	}

	//for bulk

	public void clickComment() {
		Actions actions = new Actions(getDriver());
		actions.moveToElement(bulkActions_Link).build().perform();
		click(comment_Link);
	}


	
	private List<WebElement> getTikcetListElements() {
		return getDriver().findElements(By.xpath("//*[@class='selected-tickets']//span"));
	}
	
	public List<String> getTicketList() {
		List<String> tickets=new ArrayList<String>();
		List<WebElement> listOfElements=getTikcetListElements();
		for (WebElement element : listOfElements) {
			String ticketNumber=element.getText();
			tickets.add(ticketNumber);
		}
		return tickets;
	}
	
	public void clickSearchButton() {
		click(search_Button);
		JavascriptExecutor executor = (JavascriptExecutor)getDriver();
		executor.executeScript("arguments[0].click();", search_Button);
		Actions action=new Actions(getDriver());
		action.moveToElement(search_Button).click().build().perform();
	}
	
	public void logout() {
		click(logout_Icon);
		click(yes_Buttons);
	}
	
	public void navigateToReceivingDamage() {
		Actions actions = new Actions(getDriver());
		actions.moveToElement(damage_Icon).build().perform();
		click(receiving_Link);
	}
	
	public void searchDamageTicketByCliamID(String cliamId) {
		click(search_Box);
		element(claimId_Text).waitUntilVisible();
		element(claimId_Text).type(cliamId);
		click(search_Button);
	}

	public void exportData() {

		String payload = "{\"documentType\":\"XLS\",\"transportMedium\":\"DOWNLOAD\",\"reportName\":\"DcContainerReport\",\"searchRequest\":{\"exceptionCategory\":[\"PROBLEM\",\"DISPUTE\"]}}";
		Response exportResponse = SerenityRest.given().relaxedHTTPSValidation().body(payload)
				.header("facilityCountryCode","US")
				.header("facilityNum",environment.getProperty("dcNumber"))
				.contentType("application/json").post(environment.getProperty("fixit_report_export"));
		logger.info("Export Response status code:{}", exportResponse.getStatusCode());
		Assert.assertEquals(ErrorCodes.FIXIT_REPORT_EXPORT_FAILED, Constants.SUCESS_STATUS_CODE,
				exportResponse.getStatusCode());
	}



	public void closeBrowser() {
		if(getDriverInstance()!=null) {
			getDriverInstance().quit();
		}
	}

	public void closeDriver() {
		getDriverInstance().close();
	}

	public void verifyMetricsDashboard(String presence) {

		String market = Config.DC.getValue();
		getDriver().manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
		Boolean bool = !getDriver().findElements(By.xpath("//*[@class='icon dashboard']")).isEmpty();
		String isAvailable = (bool)? "available":"unavailable";
		logger.info("Metrics dashboard displayed? Expected : {} & actual : {} ",presence,isAvailable);
		if(market.equalsIgnoreCase(DC_TYPE.WFS.getValue()) || market.equalsIgnoreCase(DC_TYPE.IMPORTS.getValue())){
			Assert.assertFalse(ErrorCodes.FIXIT_PROBLEM_METRICS_DASHBOARD_PRESENCE_MISMATCH, bool);
		} else{
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_METRICS_DASHBOARD_PRESENCE_MISMATCH, bool);
		}
	}

	public String getResultcount(){
		element(results_count).waitUntilVisible();
		return element(results_count).getText();
	}

}
