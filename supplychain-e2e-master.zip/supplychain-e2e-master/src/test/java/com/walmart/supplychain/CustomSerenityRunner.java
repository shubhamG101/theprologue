package com.walmart.supplychain;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;

import com.walmart.framework.utilities.CSVHandlerUtil;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.InitializationError;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.AnnotationConfigWebContextLoader;
import org.springframework.test.context.web.WebAppConfiguration;

import com.walmart.execution.excel.ExcelHandler;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.jms.DC_TYPE;

import cucumber.runtime.junit.FeatureRunner;
import cucumber.util.FixJava;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import spring.SpringTestConfiguration;

@WebAppConfiguration
@ContextConfiguration(loader = AnnotationConfigWebContextLoader.class, classes = SpringTestConfiguration.class)
public class CustomSerenityRunner extends CucumberWithSerenity {
	static List<String> listOfFeaturesToBeExecuted=null;
	public CustomSerenityRunner(Class clazz) throws InitializationError, IOException {
		super(clazz);
		String programName = System.getProperty("PROGRAM");
		String env = System.getProperty("ENV");

		String profile = "e2e";

		System.setProperty("jsse.enableSNIExtension","true");
		System.setProperty(Constants.PROPERTY_FILES_LOC_PATH_KEY,
				"properties/" + programName.toLowerCase() + "/" + env.toLowerCase());
		if (programName.equalsIgnoreCase(DC_TYPE.MCC.getValue()))
			Config.DC = DC_TYPE.MCC;
		else if (programName.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()))
			Config.DC = DC_TYPE.ATLAS;
		else if (programName.equalsIgnoreCase(DC_TYPE.ACC.getValue()))
			Config.DC = DC_TYPE.ACC;
		else if (programName.equalsIgnoreCase(DC_TYPE.THOR.getValue()))
			Config.DC = DC_TYPE.THOR;
		else if (programName.equalsIgnoreCase(DC_TYPE.BAJA.getValue()))
			Config.DC = DC_TYPE.BAJA;
		else if (programName.equalsIgnoreCase(DC_TYPE.WITRON.getValue()))
			Config.DC = DC_TYPE.WITRON;
		else if (programName.equalsIgnoreCase(DC_TYPE.GDC.getValue()))
			Config.DC = DC_TYPE.GDC;
		else if (programName.equalsIgnoreCase(DC_TYPE.SAMS.getValue()))
			Config.DC = DC_TYPE.SAMS;
		else if (programName.equalsIgnoreCase(DC_TYPE.PHARMACY.getValue()))
			Config.DC = DC_TYPE.PHARMACY;
		else if (programName.equalsIgnoreCase(DC_TYPE.RDC.getValue()))
			Config.DC = DC_TYPE.RDC;
		else if (programName.equalsIgnoreCase(DC_TYPE.CATALYST.getValue()))
			Config.DC = DC_TYPE.CATALYST;
		else if (programName.equalsIgnoreCase(DC_TYPE.WFS.getValue()))
			Config.DC = DC_TYPE.WFS;
		else if (programName.equalsIgnoreCase(DC_TYPE.IMPORTS.getValue()))
			Config.DC = DC_TYPE.IMPORTS;
		else if (programName.equalsIgnoreCase(DC_TYPE.VCOE.getValue()))
			Config.DC = DC_TYPE.VCOE;
		else if (programName.equalsIgnoreCase(DC_TYPE.DPB.getValue()))
			Config.DC = DC_TYPE.DPB;

		Config.ENV = ENVIRONMENT.valueOf(env.toUpperCase());
		String mode = System.getProperty("MODE");
		if(Config.DC==DC_TYPE.MCC||Config.DC==DC_TYPE.ATLAS||Config.DC==DC_TYPE.SAMS||Config.DC==DC_TYPE.WITRON||Config.DC==DC_TYPE.CATALYST) {
			Config.isCloud=true;
		}
		Config.isParallel = (mode != null) && (mode.equals("P") || mode.equals("Parallel") || mode.equals("PARALLEL"));
		System.setProperty("log4j.configurationClass", "CustomConfigurationFactory");
		System.setProperty("spring.profiles.active", profile);
		Config.isPipeline = System.getProperty("RUN_ENV") != null
				&& System.getProperty("RUN_ENV").equalsIgnoreCase("Pipeline");
		if(listOfFeaturesToBeExecuted==null) {
			listOfFeaturesToBeExecuted = CSVHandlerUtil.getFeatureList(Config.DC.getValue());
		}
		analyseFeatureFiles();

	}

	@Override
	public List<FeatureRunner> getChildren() {

		List<FeatureRunner> children = super.getChildren();

		Iterator<FeatureRunner> iterator = children.iterator();
		String ignoreFilesContainingWord = System.getProperty("IGNORE_FILE");
		while (iterator.hasNext()) {
			FeatureRunner fr = iterator.next();
			if (fr.getName().contains("This is a blank")) {
				iterator.remove();
			}
			if (Config.DC == DC_TYPE.ATLAS && Config.ENV == ENVIRONMENT.PROD
					&& !(fr.getName().contains("Atlas DA Conveyable Freight")
							|| fr.getName().contains("Atlas PBYL Flow"))) {
				System.out.println("PROD Environment----->Removing " + fr.getName());
				iterator.remove();
			}
			boolean isFeatureToBeExcluded = true;
			
			for (String featureFileName : listOfFeaturesToBeExecuted) {
				String featureName=fr.getName().replaceAll("Feature:", "").trim().toLowerCase();
				featureFileName = featureFileName.substring(featureFileName.lastIndexOf('/') + 1,
						featureFileName.indexOf(".feature"));
				if (!(ignoreFilesContainingWord!=null&&featureFileName.contains(ignoreFilesContainingWord)) &&featureName.equalsIgnoreCase(Config.featureFileToNameMap.get(featureFileName))) {
					isFeatureToBeExcluded = false;
					break;
				}
			}
			if (isFeatureToBeExcluded) {
				System.out.println(fr.getName()+"--> Needs to be excluded in this execution");
				iterator.remove();
			}else {
				Config.totalNumberOfFeatures++;
			}

		}

		for (FeatureRunner fr : children) {
			System.out.println("***************" + fr.getName() + "***************");
		}

		return children;
	}

	@Override
	protected void runChild(FeatureRunner child, RunNotifier notifier) {
		super.runChild(child, notifier);
		System.out.println("This is after feature");
	}

	private void analyseFeatureFiles() {
		try {
			File[] propertlyFileLoc = new File(System.getProperty("user.dir") + "/src/test/resources/Features")
					.listFiles();
			for (File programFeatureDir : propertlyFileLoc) {	
				if (!programFeatureDir.getName().equalsIgnoreCase(Config.DC.getValue())) {
					for (File featureFile : programFeatureDir.listFiles()) {
						if(Config.isPipeline) {
							 featureFile.delete();
						}
					}
				} else {
					for (File featureFile : programFeatureDir.listFiles()) {
						readFeatureFile(featureFile.getAbsolutePath(), featureFile.getName());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void readFeatureFile(String path, String fileName) {
		String gherkin;
		String featureStartText = "Feature:";
		fileName = fileName.substring(0, fileName.indexOf(".feature"));
		if (!Config.featureFileToNameMap.containsKey(fileName)) {
			try {
				gherkin = FixJava.readReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
				String[] lines = gherkin.split("\n");
				for (String line : lines) {
					if (line.contains(featureStartText)) {
						String featureName = line.substring(line.indexOf(featureStartText) + featureStartText.length());
						Config.featureFileToNameMap.put(fileName, featureName.trim());
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}