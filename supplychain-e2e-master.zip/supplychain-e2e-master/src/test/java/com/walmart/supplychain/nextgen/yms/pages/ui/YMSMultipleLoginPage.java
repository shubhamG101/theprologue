package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class YMSMultipleLoginPage extends PageObject {

	PropertyResolver propertyResolver = new PropertyResolver();
	YMSHelper ymsHelper = new YMSHelper();

//	@FindBy(xpath = "//label[contains(text(),'Would you like to continue YMS in this session?')]")
//	private WebElement multipleLoginForm;

	@FindBy(xpath = "//input[contains(@onclick,'multipleLoginConfirm.action')]")
	private WebElement yesButton;

	public void continueSession() {
		if (ymsHelper.isElementVisible("//label[contains(text(),'Would you like to continue YMS in this session?')]"))
			element(yesButton).click();
	}

}