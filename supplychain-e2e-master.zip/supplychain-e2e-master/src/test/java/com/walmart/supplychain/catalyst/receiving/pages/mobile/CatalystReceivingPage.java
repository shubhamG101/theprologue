package com.walmart.supplychain.catalyst.receiving.pages.mobile;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.google.common.collect.ImmutableMap;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingHelper;

import android.renderscript.Sampler.Value;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.core.pages.WebElementState;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystReceivingPage extends SerenityHelper {
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	CatalystUtil catalystUtil;
	
	@Autowired
	CatalystReceivingHelper catalystReceivingHelper;
	

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 
			Constants.RETRY_EXECUTION_COUNT);

	
	final String LAUNCHER_MOBILE_ID = "com.walmart.logistics.launcher.stage:id/";
	final String RECEIVING_MOBILE_ID = "com.walmart.logistics.receiving:id/";
	final String IMPLICIT_TIMEOUT = "webdriver.timeouts.implicitlywait";
	final String WAIT_TIMEOUT = "webdriver.wait.for.timeout";

	
	
	@FindBy(id = "com.android.packageinstaller:id/permission_message")
	private WebElement permissionDialog;	
	
	@FindBy(id = "com.android.packageinstaller:id/permission_allow_button")
	private WebElement permissionDialogAllowButton;
	
	@FindBy(id = LAUNCHER_MOBILE_ID+"image_right_dropdown_icon")
	private WebElement siteSelectBox;
	
	@FindBy(id = LAUNCHER_MOBILE_ID+"btn_continue")
	private WebElement continueButton;
	
	@FindBy(id = LAUNCHER_MOBILE_ID+"spinnerSubmitBtn")
	private WebElement confirmButtton;
	
	@FindBy(xpath = ".//*[contains(@text,'WMT Receiving')]")
	private WebElement receivingAppIcon;	
	
	@FindBy(xpath = ".//*[contains(@text,'BY Mobile')]")
	private WebElement byMobileAppIcon;	
	
	@FindBy(xpath = ".//*[contains(@text,'WMT Loading')]")
	private WebElement loadingAppIcon;
	
	//Locators for Pingfed login
	/*
	@FindBy(xpath = "//*[@resource-id='username1']")
	private WebElement userNameTextBox;
	
	@FindBy(xpath = "//*[@resource-id='password']")
	private WebElement passwordTextBox;
	
	@FindBy(xpath = "//*[@text='SIGN IN']")
	private WebElement signInButton;
	
	
	
	@FindBy(xpath = "//*[@text='Sign in']")
	private WebElement signInButton;
	*/
			
	@FindBy(id = RECEIVING_MOBILE_ID+"image_right_dropdown_icon")
	private WebElement dropdownExpandButton;
	
	@FindBy(id = RECEIVING_MOBILE_ID+"spinner_choose_warehouse")
    private WebElement warehouseSelectBox;
	
	@FindBy(xpath = "//*[@text='Continue']")
	private WebElement byContinueButton;
	
	
	@FindBy(xpath = "//*[@text='Confirm']")
	private WebElement receivingConfirmButton;
	 
	@FindBy(xpath = "//*[@text='Save']")
	private WebElement saveButton;
     
	@FindBy(id = RECEIVING_MOBILE_ID+"text_value")
	private WebElement receivingUserNameTextBox;
  
    @FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value' and @text='Password']")
	private WebElement receivingPasswordTextBox;
    
	@FindBy(xpath = "//*[@text='Sign in']")
	private WebElement receivingSignInButton;
	  
	@FindBy(xpath = "//*[@text='Enter device number']")
	private WebElement deviceNumberTextBox;
   
	@FindBy(xpath = "//*[@text='Submit']")
	private WebElement submitButton;
   
	@FindBy(id = RECEIVING_MOBILE_ID+"image_right_dropdown_icon")
	private WebElement expandDropdownButton;
     
	@FindBy(xpath = "//*[@text='Enter location number']")
	private WebElement locationNumberTextBox;
     
	@FindBy(xpath = "//*[@text='Unloading']")
	private WebElement unloadingOption;
	
	@FindBy(xpath = "//*[@text='Receiving']")
	private WebElement receivingOption;
	
	@FindBy(xpath = "//*[@text='Try searching']")
	private WebElement trySeachingLink;
	
	
	@FindBy(xpath = "//*[@text='Scan or enter to search']")
	private WebElement receivingSearchTextbox;

	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_search']")
	private WebElement receivingSearchButton;
	
	@FindBy(xpath = "//*[@text='RECEIVING']")
	private WebElement searchResultsReceivingArrowButton;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"txt_search_itm_desc']")
	private WebElement searchResultsCheckedInArrowButton;

	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value' and @text='Scan or Enter UPC']")
	private WebElement receivingUpcTextbox;
	
	@FindBy(xpath = "//*[@text='Next']")
	private WebElement receivingNextButton;
	
	@FindBy(xpath = "//*[@text='Receive']")
	private WebElement problemReceiveButton;
	
	@FindBy(xpath = "//*[@content-desc='More options']")
	private WebElement contextMenuOption;
	
	@FindBy(xpath = "//*[contains(@text,'Scan or enter LPN')]")
	private WebElement reverseLPNTextBox;
	
	@FindBy(xpath = "//*[@resource-id='com.walmart.logistics.receiving:id/txt_item_upc_number']")
	private WebElement unexpectedItemUPC;
	
	@FindBy(xpath = "//*[@resource-id='com.walmart.logistics.receiving:id/txt_item_number_value']")
	private WebElement itemNumDisplayedForUnexpectedUPC;
	
	@FindBy(xpath = "//*[@text='Unexpected Item']")
	private WebElement problemReceivePageTitle;
	
	@FindBy(xpath = "//*[contains(@text,'Item not on shipment')]")
	private WebElement problemPopUpText;
	
	@FindBy(xpath = "//*[@text='Problem Item']")
	private WebElement reverseReceiptPageTitleForProblemLPN;
	
	@FindBy(xpath = " //*[@text='Item No. PROBLEM1']")
	private WebElement reverseReceiptItemNumberForProblemLPN;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"editTextQty']")
	private WebElement receivingQtyTextbox;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"textInventoryStatusImage']")
	private WebElement receivingStatusDropdownArrow;
	
	@FindBy(xpath = "//*[@text='Receive']")
	private WebElement receiveButton;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value' and @text='----']")
	private WebElement cityOfOriginField;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value' and @text='Select Country']")
	private WebElement cityOfOriginTextbox;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value' and @text='YYYY-MM-DD']")
	private WebElement expirationDateTextbox;
	
	//unloading app elements
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_open_door']")
	private WebElement openDoorButton;
	
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"txt_door_title']")
	private WebElement doorTitle;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"txt_trlr_details']")
	private WebElement trailerDetails;
	
	
	@FindBy(xpath = "//*[@text='Dock Door number correct?']")
	private WebElement correctDockDoorSafetyQuestion;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_pass' and @text='Yes']")
	private WebElement yesButton;
	
	@FindBy(xpath = "//*[@text='Are Carrier and Trailer Number correct?']")
	private WebElement correctCarrierTrailerNumberSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is dock plate in trailer?']")
	private WebElement dockPlateSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is Trailer light on?']")
	private WebElement trailerLightSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is trailer over 30 ft long?']")
	private WebElement trailerHeightSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Are floor boards in good condition?']")
	private WebElement floorBoardsSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is floor free of spilled liquids or granular materials?']")
	private WebElement floorFreeOfSpilledLiquidSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Trailer height, Dock Door height adequate for Equipment?']")
	private WebElement trailerDockDoorHeightSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is freight stable?']")
	private WebElement freightStabilitySafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Are pallets in good condition?']")
	private WebElement palletConditionSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is merchandise damage-free?']")
	private WebElement merchandiseDamageFreeSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is trailer free of pest activity?']")
	private WebElement pestFreeTrailerSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is trailer hazard-free?']")
	private WebElement hazardFreeTailerSafetyQuestion;
	
	@FindBy(className = "‎‏‎‎‎‎‎‏‎‏‏‏‎‎‎‎‎‎‏‎‎‏‎‎‎‎‏‏‏‏‏‏‏‏‏‏‎‏‎‎‎‏‏‎‏‎‎‎‏‏‎‎‎‏‏‏‏‎‏‎‎‎‎‏‏‎‏‏‎‏‎‎‏‎‎‏‎‎‎‎‎‎‏‎‏‎‎‎‎‏‏‏‎‎‎‎‎android.widget.ImageButton")
	private WebElement navigateUpButton;
	
	
	@FindBy(xpath = "(//android.widget.ImageView[@content-desc='Close'])[5]")
	private WebElement selectItem;
	

	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"unload_freight_title']")
	private WebElement unloadFreightTitle;
			
	public void closeBrowser() {
		getDriver().quit();
	}

	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_complete_shipment']")
	private WebElement completeShipmentOption;
	
	@FindBy(xpath = "//*[@text='Does this Trailer contain multiple stops or shipments?']")
	private WebElement trailerMultipleStopsQuestion;
	
	@FindBy(xpath = "//*[@text='No, trailer is empty']")
	private WebElement trailerIsEmptyOption;
	
	@FindBy(xpath = "//*[@text='Temp Recorder']")
	private WebElement temperatureRecorderHeading;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_yes_be_sure']")
	private WebElement temperatureRecorderAvailable;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_no_temp_found']")
	private WebElement temperatureRecorderNotAvailable;
	

	@FindBy(xpath = "(//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value'])[1]")
	private WebElement zone1TemperatureTextbox;
		
	@FindBy(xpath = "(//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value'])[2]")
	private WebElement zone2TemperatureTextbox;
	
	@FindBy(xpath = "(//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_value'])[3]")
	private WebElement zone3TemperatureTextbox;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_save_temp']")
	private WebElement saveTemperatureButton;
	
	@FindBy(xpath = "//*[@text='OSDR']")
	private WebElement osdrTitle;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_shipment_no']")
	private WebElement shipmentNumberHeading;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_osdr_case_lbl']")
	private WebElement totalCasesReceivedHeading;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_osdr_case_ct']")
	private WebElement totalCasesReceivedValue;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_overage_cases']")
	private WebElement totalOverageCasesValue;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_shortages_cases']")
	private WebElement totalShortageCasesValue;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_damages_cases']")
	private WebElement totalDamageCasesValue;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"btn_confirm_osdr']")
	private WebElement confirmOsdrButton;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"txt_door_title']")
	private WebElement doorSafetyChecklistTitle;
	
	@FindBy(xpath = "//*[@text='Swept out trailer?']")
	private WebElement sweptOutTrailerSafetyQuestion;
	
	
	@FindBy(xpath = "//*[@text='Dock plate retracted after unload is complete?']")
	private WebElement dockPlateRetractedSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is this a swing door trailer']")
	private WebElement isThisSwingDoorTrailerSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Trailer door closed and latched?']")
	private WebElement isTrailerDoorClosedOrLatchedSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Dock door closed and latched?']")
	private WebElement isDockDoorClosedOrLatchedSafetyQuestion;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"img_trophy']")
	private WebElement trophyIcon;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_shipment_complete']")
	private WebElement shipmentCompletedText;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"text_shipment_complete_desc']")
	private WebElement completeShipmentDescription;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"txt_lbl_open_door_title']")
	private WebElement shipmentFinalizedText;
	
	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"txt_lbl_shipment_status']")
	private WebElement shipmentStatus;
	
	@FindBy(xpath = "//*[@text='Yes, swing doors']")
	private WebElement yesSwingDoorsOption;
	
	@FindBy(xpath = "//*[@text='Yes']")
	private WebElement yesOption;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "btn_positive")
	private WebElement confirmOverages;

	private WebElement getElementByContainsText(String text) {
		return getDriver().findElement(By.xpath("//*[contains(@text,"+text+")]"));
	}

	
	// ##############  Generic locators   ##########################################################
	
	private WebElement getElementByPartialText(String partialText) {
		return getDriver().findElement(By.xpath("//*[contains(@text,'"+partialText+"')]"));
	}
	
	private WebElement getfieldValueElementForParticularField(String fieldName) {
		return getDriver().findElement(By.xpath("//*[contains(@text,'"+fieldName+"')]/following-sibling::*[contains(@class,'TextView')][1]"));
	}
	
	private WebElement getfieldValueElementForParticularFieldInPutaway(String fieldName, String partialClassName) {
		return getDriver().findElement(By.xpath("(//*[contains(@text,'"+fieldName+"')]/following-sibling::*[contains(@class,'"+partialClassName+"')])[1]"));
	}
	

	
	WebDriver driver = null;
	
	public Boolean isPermissionDialogDisplayed() {
		driver = getDriverInstance();
		int implicitNegativeTimeout = 5000;
		System.setProperty(IMPLICIT_TIMEOUT, "" + implicitNegativeTimeout);
		System.setProperty(WAIT_TIMEOUT, "" + implicitNegativeTimeout);
		return element(permissionDialogAllowButton).isPresent();
	}
	
	public void clickOnAllowPermissionButton() {
		element(permissionDialog).waitUntilVisible();
		element(permissionDialogAllowButton).waitUntilVisible();
		element(permissionDialogAllowButton).waitUntilVisible();
		element(permissionDialogAllowButton).click();
		logger.info("Clicked on Allow button on Permission Dialog box");
	}
	
	public void clickOnSiteSelectBox() {
		element(siteSelectBox).waitUntilVisible();
		element(siteSelectBox).waitUntilClickable();
		element(siteSelectBox).click();
	}
	
	public void selectSite(String siteNumber) {
		driver = getDriverInstance();
		element(driver.findElement(By.xpath("//*[contains(@text,'"+siteNumber+"')]"))).waitUntilVisible();
	    element(driver.findElement(By.xpath("//*[contains(@text,'"+siteNumber+"')]"))).click();
		logger.info("WMT_LAUNCHER : Selected item "+siteNumber+" from the Site Select Box");}
	
	public void clickOnConfirmButton() {
		element(confirmButtton).waitUntilVisible();
		element(confirmButtton).click();
		logger.info("WMT_LAUNCHER : Clicked on Confirm button on Confirmation box");
	}
	
	public void clickOnContinueButton() {
		element(continueButton).waitUntilVisible();
		element(continueButton).click();
		logger.info("WMT_LAUNCHER : Clicked on Continue button");
	}
	
	public void clickOnReceivingIcon() {
		element(receivingAppIcon).waitUntilVisible();
		element(receivingAppIcon).click();
		logger.info("WMT_LAUNCHER : Clicked on Receiving Icon");
	}
	
	public void clickOnLoadingIcon() {
		element(loadingAppIcon).waitUntilVisible();
		element(loadingAppIcon).click();
		logger.info("WMT_LAUNCHER : Clicked on Loading Icon");
	}
	
	public void clickOnBYMobileAppIcon() {
		element(byMobileAppIcon).waitUntilVisible();
		element(byMobileAppIcon).click();
		logger.info("WMT_LAUNCHER : Clicked on BY Mobile Icon");
	}
	
/*
	public void enterUserName(String userName) {
		element(userNameTextBox).waitUntilVisible();
		element(userNameTextBox).sendKeys(userName);
		logger.info("WMT_LAUNCHER : Entered Lab account Username");
	}
	
	public void enterPassword(String password) {
		element(passwordTextBox).waitUntilVisible();
		element(passwordTextBox).sendKeys(password);
		logger.info("WMT_LAUNCHER : Entered Lab account Password");
	}
	
	public void clickOnSignInButton() {
		element(signInButton).waitUntilVisible();
		element(signInButton).click();
		logger.info("WMT_LAUNCHER : Clicked on SignIn Button");
	}
	*/
	
	public void clickOnDropdownExpandButton() {
		element(dropdownExpandButton).waitUntilVisible();
		element(dropdownExpandButton).click();
	}
		     
	public void clickOWarehouseSelectBox() {
		element(warehouseSelectBox).waitUntilVisible();
		element(warehouseSelectBox).click();
	}
			
	public void enterReceivingUserName(String userName) {
		element(receivingUserNameTextBox).click();
		element(receivingUserNameTextBox).clear();
		element(receivingUserNameTextBox).sendKeys(userName);
		logger.info("WMT_RECEIVING : Entered Receiving Username");
	}


	public void enterReceivingPassword(String password) {
		element(receivingPasswordTextBox).clear();
		element(receivingPasswordTextBox).sendKeys(password);
		logger.info("WMT_RECEIVING : Entered Receiving Password");
	}

	public void clickOnReceivingSignInButton() {
		element(receivingSignInButton).waitUntilVisible();
		element(receivingSignInButton).click();
		logger.info("WMT_RECEIVING : Clicked on SignIn Button");
	}

	public void selectWarehouse(String warehouse) {
		WebDriver driver = getDriverInstance();
		element(driver.findElement(By.xpath("//*[contains(@text,'"+warehouse+"')]"))).waitUntilVisible();       

		element(driver.findElement(By.xpath("//*[contains(@text,'"+warehouse+"')]"))).click();
		logger.info("WMT_RECEIVING : Selected item "+warehouse+" from the Warehouse List");
	}

	public void clickOnReceivingConfirmButton() {
		element(receivingConfirmButton).waitUntilVisible();
		element(receivingConfirmButton).click();
		logger.info("WMT_RECEIVING : Clicked on Confirm Button");
	}

	public void clickOnSaveButton() {
		element(saveButton).waitUntilVisible();
		element(saveButton).click();
		logger.info("WMT_RECEIVING : Clicked on Save Button");
	}

	public void enterDeviceNumber(String deviceNumber) {
		element(deviceNumberTextBox).waitUntilVisible();
		element(deviceNumberTextBox).sendKeys(deviceNumber);
		logger.info("WMT_RECEIVING : Entered Device Number");
	}

	public void clickOnSubmitButton() {
		element(submitButton).waitUntilVisible();
		element(submitButton).click();
		logger.info("WMT_RECEIVING : Clicked on Submit Button");
	}

	public void clickEquipmentExpandDropdownButton() {
		element(expandDropdownButton).waitUntilVisible();
		element(expandDropdownButton).click();
		logger.info("WMT_RECEIVING : Clicked on Equipment Expand Dropdown Button");
	}

	public void selectEquipment(String equipment) {
		WebDriver driver = getDriverInstance();
		element(driver.findElement(By.xpath("//*[contains(@text,'"+equipment+"')]"))).waitUntilVisible();       

		element(driver.findElement(By.xpath("//*[contains(@text,'"+equipment+"')]"))).click();
		logger.info("WMT_RECEIVING : Selected item "+equipment+" from the Equipment List");
	}


	public void enterLocationNumber(String locationNumber) {
		element(locationNumberTextBox).waitUntilVisible();
		element(locationNumberTextBox).sendKeys(locationNumber);
		logger.info("WMT_RECEIVING : Entered Location Number");
	}


	public void clickOnByContinueButton() {
		//      element(byContinueButton).waitUntilVisible();
		element(byContinueButton).click();
		logger.info("BY_App : Clicked on BY Continue Button");
	}


	public void clickOnUnloadingOption() {
		element(unloadingOption).waitUntilVisible();
		element(unloadingOption).click();
		logger.info("WMT_RECEIVING : Selected Unloader UI");
	}
	
	public void clickOnReceivingOption() {
		element(receivingOption).waitUntilVisible();
		element(receivingOption).click();
		logger.info("WMT_RECEIVING : Selected Receiving UI");
	}
	
	public void clickOnTrySearchingLink() {
		element(trySeachingLink).waitUntilVisible();
		element(trySeachingLink).click();
		logger.info("WMT_RECEIVING : Clicked on try Searching Link ");
	}
	
	public void enterDoorNumber(String doorNumber) {
		element(receivingSearchTextbox).waitUntilVisible();
		element(receivingSearchTextbox).sendKeys(doorNumber);
		logger.info("WMT_RECEIVING : Entered Inbound Door Number");
	}
	
	public void clickOnReceivingSearchButton() {
		element(receivingSearchButton).waitUntilVisible();
		element(receivingSearchButton).click();
		logger.info("WMT_RECEIVING : Clicked on Receiving Search Button");
	}
	
	public void clickOnSearchResultsReceivingArrowButton() {
		element(searchResultsReceivingArrowButton).waitUntilVisible();
		element(searchResultsReceivingArrowButton).click();
		logger.info("WMT_RECEIVING : Clicked on Search Results Receiving Arrow Button");
	}
	
	public void clickOnSearchResultsCheckedInArrowButton() {
		element(searchResultsCheckedInArrowButton).waitUntilVisible();
		element(searchResultsCheckedInArrowButton).click();
		logger.info("WMT_RECEIVING : Clicked on Search Results Checked In Arrow Button");
	}
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return  (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriverInstance()).getProxiedDriver();
		}
	
	public void performScan(String valueToScan) throws InterruptedException {
		logger.info("valueToScan : {}", valueToScan);
		String labelType="";
		if(valueToScan.length()<=20) {
			labelType = "EAN128";
		}
		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "--es",
				"com.symbol.datawedge.label_type " + labelType, "--es",
				"com.symbol.datawedge.data_string " + valueToScan);
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
		logger.info("Scan Event :::"+scanEvent);
		Thread.sleep(3000);
		getAndroidDriver().executeScript("mobile: shell", scanEvent);
		try {
			Thread.sleep(3000);
			logger.info("Scanned LPN");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void enterUpc(String Upc) {
		element(receivingUpcTextbox).waitUntilVisible();
		element(receivingUpcTextbox).sendKeys(Upc);
		logger.info("WMT_RECEIVING : Entered Upc");
	} 
	
	
	public void clickOnReceivingNextButton() {
		element(receivingNextButton).waitUntilVisible();
		element(receivingNextButton).click();
		logger.info("WMT_RECEIVING : Clicked on Receiving Next Button");
	}
	
	
	public void enterReceivingQty(String receivingQty) {
		element(receivingQtyTextbox).waitUntilVisible();
		sleep(2);
		element(receivingQtyTextbox).clear();
		element(receivingQtyTextbox).sendKeys(receivingQty);
		logger.info("WMT_RECEIVING : Entered receiving qty");
	} 
	
	public void clickOnReceiveButton() {
		element(receiveButton).waitUntilVisible();
		element(receiveButton).click();
		logger.info("WMT_RECEIVING : Clicked on Receive Button");
	}
	

	public void enterCityOfOrigin(String cityOfOrigin) {
//		element(cityOfOriginField).waitUntilVisible();
//		element(cityOfOriginField).clear();
		logger.info("Value of Country"+ cityOfOrigin);
		element(cityOfOriginTextbox).sendKeys(cityOfOrigin);
		logger.info("WMT_RECEIVING : Entered City Of Origin ");
	} 
	

	public void enterExpirationDate(String expirationDate) {
		element(expirationDateTextbox).waitUntilVisible();
		//element(expirationDateTextbox).clear();
		logger.info("Expiry Date: "+ expirationDate);
		element(expirationDateTextbox).sendKeys(expirationDate);
//		element(expirationDateTextbox).click();
		logger.info("WMT_RECEIVING : Entered expiration Date ");
	} 
	
	public boolean isOpenDoorDisplayed() {
		 try
		    {
		        if(element(openDoorButton).isDisplayed()){
		        	logger.info("WMT_RECEIVING :Open Door Button is displayed ");
		            return true;
		        }else{
		        	logger.info("WMT_RECEIVING :Open Door Button is NOT displayed ");
		            return false;
		        }
		    }
		    catch (Exception e)
		    {
		    	logger.info("WMT_RECEIVING :Open Door Button is NOT displayed ");
		    	 return false;
		    }
		
	}
	
	public void clickOnOpenDoorButton() {
		element(openDoorButton).waitUntilVisible();
		element(openDoorButton).click();
		logger.info("WMT_RECEIVING : Clicked on Open Door Button");
	}
	
	
	public void verifyDoorTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(doorTitle));
	}
	
	public void verifyTrailerDetailsIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerDetails));
	}
	
	public void verifyCorrectDockDoorSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(correctDockDoorSafetyQuestion));
	}
	
	public void clickOnYesButton() throws InterruptedException {
		element(yesButton).waitUntilVisible();
		element(yesButton).click();
		logger.info("WMT_RECEIVING : Clicked on YES Button");
		Thread.sleep(500);
	}
	
	
	
	public void verifyCorrectCarrierTrailerNumberSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(correctCarrierTrailerNumberSafetyQuestion));
	}
	
	public void verifyDockPlateSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(dockPlateSafetyQuestion));
	}
	
	public void verifyTrailerLightSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerLightSafetyQuestion));
	}
	
	public void verifyTrailerHeightSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerHeightSafetyQuestion));
	}
	public void verifyFloorBoardsSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(floorBoardsSafetyQuestion));
	}
	public void verifyFloorFreeOfSpilledLiquidSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(floorFreeOfSpilledLiquidSafetyQuestion));
	}
	public void verifyTrailerDockDoorHeightSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerDockDoorHeightSafetyQuestion));
	}
	public void verifyFreightStabilitySafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(freightStabilitySafetyQuestion));
	}
	public void verifyPalletConditionSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(palletConditionSafetyQuestion));
	}
	public void verifyMerchandiseDamageFreeSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(merchandiseDamageFreeSafetyQuestion));
	}
	public void verifyPestFreeTrailerSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(pestFreeTrailerSafetyQuestion));
	}
	
	public void verifyHazardFreeTailerSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(hazardFreeTailerSafetyQuestion));
	}
	
	public void clickOnNavigateUpButton() throws InterruptedException {
		sleep(3);
		//element(navigateUpButton).click();
		getAndroidDriver().pressKey(new KeyEvent().withKey(AndroidKey.BACK));
		logger.info("WMT_RECEIVING : Clicked on Navigate Up Button");	
	}
	
	public void clickOnSelectItemButton() {
		element(selectItem).waitUntilVisible();
		element(selectItem).click();
		logger.info("WMT_RECEIVING : Clicked on Select Item Button");	
	}
	
	public void verifyUnloadFreightTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(unloadFreightTitle));
	}

	public void scrollAndClick(String visibleText) {
		getAndroidDriver().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
	     		+ ".scrollable(true).instance(0)).scrollIntoView(new UiSelector()."
	     		+ "textContains(\""+visibleText+"\").instance(0))").click();
		logger.info("WMT_RECEIVING : Clicked on "+visibleText+" Option");
		 }
	
	public void verifyCompleteShipmentOptionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(completeShipmentOption));
	}
	
	public void clickOnCompleteShipmentOption() {
		element(completeShipmentOption).waitUntilVisible();
		element(completeShipmentOption).click();
		logger.info("WMT_RECEIVING : Clicked on Complete Shipment Option");
	}
	
	public void verifyTrailerMultipleStopsQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerMultipleStopsQuestion));
	}
	
	public void clickOnTrailerIsEmptyOption() {
		element(trailerIsEmptyOption).waitUntilVisible();
		element(trailerIsEmptyOption).click();
		logger.info("WMT_RECEIVING : Clicked on Trailer is Empty Option");
	}
	
	public void verifyTemperatureRecorderHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(temperatureRecorderHeading));
	}
	
	public void clickOnTemperatureRecorderAvailableOption() {
		element(temperatureRecorderAvailable).waitUntilVisible();
		element(temperatureRecorderAvailable).click();
		logger.info("WMT_RECEIVING : Clicked on Temperature Recorder Available Option");
	}
	
	public void clickOnTemperatureRecorderNotAvailableOption() {
		element(temperatureRecorderNotAvailable).waitUntilVisible();
		element(temperatureRecorderNotAvailable).click();
		logger.info("WMT_RECEIVING : Clicked on Temperature Recorder Not Available Option");
	}
	
	public void enterZone1Temperature(String zone1Temperature) {
		element(zone1TemperatureTextbox).waitUntilVisible();
		element(zone1TemperatureTextbox).sendKeys(zone1Temperature);
		logger.info("WMT_RECEIVING : Entered Zone 1 Temperature");
	} 
	
	public void enterZone2Temperature(String zone2Temperature) {
		element(zone2TemperatureTextbox).waitUntilVisible();
		element(zone2TemperatureTextbox).sendKeys(zone2Temperature);
		logger.info("WMT_RECEIVING : Entered Zone 2 Temperature");
	} 
	
	public void enterZone3Temperature(String zone3Temperature) {
		element(zone3TemperatureTextbox).waitUntilVisible();
		element(zone3TemperatureTextbox).sendKeys(zone3Temperature);
		logger.info("WMT_RECEIVING : Entered Zone 3 Temperature");	
	} 
	
	public void clickOnSaveTemperatureButton() {
		element(saveTemperatureButton).waitUntilVisible();
		element(saveTemperatureButton).click();
		logger.info("WMT_RECEIVING : Clicked on Save Temperature Button");
	}

	public void verifyOsdrTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(osdrTitle));
	}
	
	public void verifyShipmentNumberValue(String shipmentNumber) {
		catalystUtil.verifyElementValue(element(shipmentNumberHeading), "Shipment: "+shipmentNumber);
	}
	
	public void verifyTotalCasesReceivedHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(totalCasesReceivedHeading));
	}
	
	public void verifyTotalCasesReceivedValue(String receiveQty) {
		catalystUtil.verifyElementValues(element(totalCasesReceivedValue), receiveQty);
	}
	public void verifyTotalOverageCasesValue(String overageQty) {
		catalystUtil.verifyElementValue(element(totalOverageCasesValue), "Total Cases :"+overageQty);
	}
	public void verifyTotalShortageCasesValue(int shortageQty) {
		catalystUtil.verifyElementValue(element(totalOverageCasesValue), "Total Cases :"+Integer.toString(shortageQty));
	}
	public void verifyTotalDamageCasesValue(String damageQty) {
		catalystUtil.verifyElementValue(element(totalDamageCasesValue), "Total Cases :"+damageQty);
	}
	public void clickOnConfirmOsdrButton() {
		element(confirmOsdrButton).waitUntilVisible();
		element(confirmOsdrButton).click();
		logger.info("WMT_RECEIVING : Clicked on Confirm Osdr Button");
	}
	public void verifyDoorSafetyChecklistTitle(String doorNumber) {
		element(doorSafetyChecklistTitle).waitUntilVisible();
		catalystUtil.verifyElementValue(element(doorSafetyChecklistTitle), "Door "+doorNumber+" safety checklist");
	}
	
	public void verifySweptOutTrailerSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(sweptOutTrailerSafetyQuestion));
	}
	
	public void verifyDockPlateRetractedSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(dockPlateRetractedSafetyQuestion));
	}
	
	public void verifySwingDoorSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(isThisSwingDoorTrailerSafetyQuestion));
	}
	
	public void verifyIsDockDoorClosedSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(isDockDoorClosedOrLatchedSafetyQuestion));
	}
	
	public void verifyIsTrailerDoorClosedSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(isTrailerDoorClosedOrLatchedSafetyQuestion));
	}
	
//	public void verifyTrophyIconIsDisplayed() {
//		catalystUtil.verifyElementIsDisplayed(element(trophyIcon));
//	}
//	public void verifyShipmentCompletedTextIsDisplayed() {
//		catalystUtil.verifyElementIsDisplayed(element(shipmentCompletedText));
//	}
//	public void verifyCompleteShipmentDescValue(String shipmentNumber) {
//		catalystUtil.verifyElementValue(element(completeShipmentDescription), "Shipment "+shipmentNumber+" has been marked completed.");
//	}
	
	public void verifyShipmentFinalizedText() {
		catalystUtil.verifyElementValue(element(shipmentFinalizedText), "Shipment Finalized");
	}
	
	public void verifyShipmentStatus() {
		catalystUtil.verifyElementValue(element(shipmentStatus), "Closed");
	}
	
	
	public void clickOnYesSwingDoorsOption() {
		element(yesSwingDoorsOption).waitUntilVisible();
		element(yesSwingDoorsOption).click();
		logger.info("WMT_RECEIVING : Clicked on Yes,Swing Doors Option");
	}
	
	public void clickOnYesOption() {
		element(yesOption).waitUntilVisible();
		element(yesOption).click();
		logger.info("WMT_RECEIVING : Clicked on Yes Option");
	}
	
	
	public void clickOnReceivingStatusDropdownArrow(){
		element(receivingStatusDropdownArrow).waitUntilVisible();
		element(receivingStatusDropdownArrow).waitUntilClickable();
		element(receivingStatusDropdownArrow).click();
		logger.info("WMT_RECEIVING : Clicked on Receiving Status Dropdown Arrow");
	}
	
	public void selectReceivingStatus(String receivingStatus){
		WebElement receivingStatusOption=getAndroidDriver().findElement(By.xpath("//*[@text='"+receivingStatus+"']"));
		element(receivingStatusOption).waitUntilVisible();
		element(receivingStatusOption).click();
		logger.info("WMT_RECEIVING : Clicked on Receiving Status Dropdown Arrow");
	}
	
	public void pressEnter() throws InterruptedException {
		   getAndroidDriver().pressKey(new KeyEvent().withKey(AndroidKey.ENTER));;
			logger.info("WMT_RECEIVING : Press Enter");	
		}
	
	public void setReceivingDetails(String LPN, int receiveQty,String receivedStatus, String expDate) {
		catalystReceivingHelper.setReceiveAndShortageQty(receiveQty);
		catalystReceivingHelper.setReceivingInstruction(LPN, receiveQty, receivedStatus);
		catalystReceivingHelper.setItemReceiveAndRotateDate(expDate);
	}

	
	//####################################### Full Receive and Overages #############################################
	

	

	public void validateTextBeforeOverages() {
		
		element(locatorWithId("text_title")).waitUntilVisible();
		String overagesMsg = element(locatorWithId("text_title")).getText();
		logger.info("WMT_RECEIVING : Overage Pop-up Message is {}", overagesMsg);
		try {
			if (overagesMsg.contains("Is there more freight to receive?")) {
				// Overages Popup
				element(locatorWithId("radio_btn_continue_rec")).waitUntilVisible();
				element(locatorWithId("radio_btn_continue_rec")).waitUntilClickable();
				element(locatorWithId("radio_btn_continue_rec")).click();
				element(locatorWithId("dialogPositiveBtn")).waitUntilClickable();
				element(locatorWithId("dialogPositiveBtn")).click();

				logger.info("WMT_RECEIVING : Validated the Overages Pop-Up and selected Yes Option");
			}
		} catch (Exception e) {
			throw new AutomationFailure("WMT_RECEIVING : Overages pop-up is not displayed", e);
		}
	}

	
	public void changeInventoryStatus(String inventoryStatus) {
		String invExistingStatus = element(locatorWithId("textInventoryStatus")).getText();
		 logger.info("WMT_RECEIVING : Existing Inventory Status to {} ", invExistingStatus);

		if(!invExistingStatus.equalsIgnoreCase(inventoryStatus)) {
		 //DropDown Element - textInventoryStatus
			clickOnReceivingStatusDropdownArrow();
			selectReceivingStatus(inventoryStatus);
			logger.info("WMT_RECEIVING : Changed Inventory Status to {} ", inventoryStatus);
		}
	}

	public void clickOnNextButton() {

		element(locatorWithId("buttonReceive")).waitUntilVisible();
		element(locatorWithId("buttonReceive")).waitUntilVisible();
		element(locatorWithId("buttonReceive")).click();

		logger.info("WMT_RECEIVING : Clicked on Next Button");
	}

	public void clickOnButton() {

		element(locatorWithId("buttonReceive")).waitUntilVisible();
		element(locatorWithId("buttonReceive")).waitUntilVisible();
		element(locatorWithId("buttonReceive")).click();

		logger.info("WMT_RECEIVING : Clicked on Next Button");
	}
	
	public void clickOnUserButton() {

		element(locatorWithId("toolbar_username")).waitUntilVisible();
		element(locatorWithId("toolbar_username")).waitUntilVisible();
		element(locatorWithId("toolbar_username")).click();

		logger.info("WMT_RECEIVING : Clicked on Username Button");
	}
	
	public void clickOnSignOutButton() {

		element(locatorWithId("txt_user_sign_out")).waitUntilVisible();
		element(locatorWithId("txt_user_sign_out")).waitUntilVisible();
		element(locatorWithId("txt_user_sign_out")).click();
		logger.info("WMT_RECEIVING : Clicked on Sign Out Button");
	}
	
	
	public void confirmOverages() {

		String overageAlert = locatorWithId("txt_dialog_title").getText();
		logger.info("WMT_RECEIVING : Overage Alert is {} ", overageAlert);

		element(locatorWithId("btn_positive")).waitUntilVisible();
		element(locatorWithId("btn_positive")).waitUntilClickable();
		element(locatorWithId("btn_positive")).click();

		logger.info("WMT_RECEIVING : Clicked Yes -> Confirm Overages Alert");
	}

	public void clickOnReceiveBtn() {

		element(locatorWithId("button_save")).waitUntilVisible();
		element(locatorWithId("button_save")).waitUntilClickable();
		element(locatorWithId("button_save")).click();
		logger.info("WMT_RECEIVING : Clicked on Receive Button");
	}

	public String totalCasesNeedToBeReceived() {

		String totalCasesToBeReceived = locatorWithId("text_total_received_count").getText();
		logger.info("WMT_RECEIVING : Text displayed on the Receiving Screen {}", totalCasesToBeReceived);
		String[] splitTotalCases = totalCasesToBeReceived.split("/");
		logger.info("WMT_RECEIVING : Total Received Cases ==> {}", splitTotalCases[0]);
		logger.info("WMT_RECEIVING : Total Cases needs to be Received ==> {}", splitTotalCases[1]);
		int fullReceive = Integer.parseInt(splitTotalCases[1]) - Integer.parseInt(splitTotalCases[0]);
		logger.info("WMT_RECEIVING : Returned value is ==>{}" + fullReceive);
		String finalvalue = (fullReceive + "");
		return finalvalue;
	}
	
	// Setting up the Overage Receiving Details
	public void setOverageReceivingDetails(String LPN, String receiveQty) {
		catalystReceivingHelper.setOverageReceivingInstruction(LPN, receiveQty);
	}
	
	// Setting Full Receiving Details
	public void setFullReceivingDetails(String LPN, int receiveQty, String receivedStatus, String expDate) {
		catalystReceivingHelper.setReceivingInstruction(LPN, receiveQty,receivedStatus);
		catalystReceivingHelper.setItemReceiveAndRotateDate(expDate);
	}
	

	public void validateHaccpScreen() {
		
		element(locatorWithId("txt_workflow_title")).waitUntilVisible();
		element(locatorWithId("txt_workflow_title")).waitUntilClickable();
		String validateHaccp = element(locatorWithId("txt_workflow_title")).getText();
		logger.info("WMT_RECEIVING : Text {} is displayed on HACCP Screen"+validateHaccp);
	}
	
	public void enterHaccpTemp(String itemTemp){
		Failsafe.with(retryPolicy).run(() -> {
		element(locatorWithId("text_value")).waitUntilVisible();
		element(locatorWithId("text_value")).waitUntilClickable();
		element(locatorWithId("text_value")).sendKeys(itemTemp);
		logger.info("WMT_RECEIVING : Entered Temperature value is ==>{}" + itemTemp);
		});
	}
	
	
	//################################### Expected/Unexpected Pop-Ups Section [Receiving / Complete Shipment] ###################################
	
	public void handleRecordExistsPopUp() {
		
		try {
			logger.info("WMT_RECEIVING : Waiting to Handel - Record Exists Popup...");
			if(element(locatorWithId("txt_dialog_title")).isDisplayed()) {
				element(locatorWithId("txt_dialog_title")).waitUntilVisible();
				element(locatorWithId("txt_dialog_title")).waitUntilClickable();
				String recordDialogText = element(locatorWithId("txt_dialog_title")).getText();
				logger.info("WMT_RECEIVING : Pipup text is  {}"+recordDialogText);
				element(xpathContainsText("OK")).waitUntilVisible();
				element(xpathContainsText("OK")).waitUntilClickable();
				element(xpathContainsText("OK")).click();
				logger.info("WMT_RECEIVING : Record Already Exists Pop-up is handled");
			}
			else {
				logger.info("WMT_RECEIVING : Popup is not displayed");
				return;
			}
		} catch (NoSuchElementException e ) {
			
			logger.info("WMT_RECEIVING : Popup is not displayed");
			return;
		}
		
	}
	
	public void handleNoReleaseRulePopUp() {
		try {			
			logger.info("WMT_RECEIVING : Waiting to Handel - No Release Rule Popup...");
			if(element(locatorWithId("txt_dialog_title")).isDisplayed()) {
				element(locatorWithId("txt_dialog_title")).waitUntilVisible();
				element(locatorWithId("txt_dialog_title")).waitUntilClickable();
				String recordDialogText = element(locatorWithId("txt_dialog_title")).getText();
				logger.info("WMT_RECEIVING : Pipup text is  {}"+recordDialogText);
				element(xpathContainsText("OK")).waitUntilVisible();
				element(xpathContainsText("OK")).waitUntilClickable();
				element(xpathContainsText("OK")).click();
				logger.info("WMT_RECEIVING : No Release Rule Pop-up is handled");
			}
			else {
				logger.info("WMT_RECEIVING : Popup is not displayed");
				return;
			}
		} catch (NoSuchElementException e ) {
			
			logger.info("WMT_RECEIVING : No Release Rule Popup is not displayed");
			return;
		}
	}
	
	public void handleMoreFreightPopUpOrClickCompleteShipment() {
		try {
		logger.info("WMT_RECEIVING : Waiting to Handle - Is There more freight to receive Popup...");
		if(element(locatorWithId("text_title")).isDisplayed()) {
		element(locatorWithId("text_title")).waitUntilVisible();
		element(locatorWithId("text_title")).waitUntilClickable();
		String popupText = element(locatorWithId("text_title")).getText();
		logger.info("WMT_RECEIVING : Popup {} is handled "+popupText);
		
		//continue Receiving Radio option
		element(locatorWithId("radio_btn_no_complete_shipment")).waitUntilVisible();
		element(locatorWithId("radio_btn_no_complete_shipment")).waitUntilClickable();
		element(locatorWithId("radio_btn_no_complete_shipment")).click();
		
		//Continue Button
		element(locatorWithId("dialogPositiveBtn")).waitUntilVisible();
		element(locatorWithId("dialogPositiveBtn")).waitUntilClickable();
		element(locatorWithId("dialogPositiveBtn")).click();
		}
		else {
			logger.info("WMT_RECEIVING : More Freight Popup is not displayed");
			clickOnCompleteShipmentOption();
			return;
		}
	} catch (NoSuchElementException e ) {
		
		logger.info("WMT_RECEIVING : More Freight receive Popup is not displayed");
		clickOnCompleteShipmentOption();
		return;
	}
	}
	
	public void handleMoreFreightPopUpWithYes() {
		logger.info("WMT_RECEIVING : Waiting to Handle - Is There more freight to receive Popup...");

		element(locatorWithId("text_title")).waitUntilVisible();
		element(locatorWithId("text_title")).waitUntilClickable();
		String popupText = element(locatorWithId("text_title")).getText();
		logger.info("WMT_RECEIVING : Popup {} is handled "+popupText);

		//Click on Yes Button
		element(locatorWithId("radio_btn_continue_rec")).waitUntilVisible();
		element(locatorWithId("radio_btn_continue_rec")).waitUntilClickable();
		element(locatorWithId("radio_btn_continue_rec")).click();

		element(locatorWithId("dialogPositiveBtn")).waitUntilVisible();
		element(locatorWithId("dialogPositiveBtn")).waitUntilClickable();
		element(locatorWithId("dialogPositiveBtn")).click();
	}
	
	public void handlePendingInspectionPopUp() {
		logger.info("WMT_RECEIVING : Waiting to Handel - Pending Inspection Popup...");
		element(xpathContainsText("Pending Inspection")).waitUntilVisible();
		element(xpathContainsText("Pending Inspection")).waitUntilClickable();
		String popupText = element(xpathContainsText("Pending Inspection")).getText();
		logger.info("WMT_RECEIVING : Popup text is  {} "+popupText);
		
		//OK Button
		element(xpathContainsText("OK")).waitUntilVisible();
		element(xpathContainsText("OK")).waitUntilClickable();
		element(xpathContainsText("OK")).click();
	}
	
	//########################################## Complete Shipment Changes ###############################
	
	public void verifyTrailerMultipleStopShipmentQuestionIsDisplayed() {
		
		element(xpathContainsText("Does this trailer contain multiple stops or shipments?")).waitUntilVisible();
		catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Does this trailer contain multiple stops or shipments?")));
	}
	
	public void verifyTempRecordQuestionIsDisplayed() {
		
		element(locatorWithId("text_temperature_record_label")).waitUntilVisible();
		catalystUtil.verifyElementIsDisplayed(element(locatorWithId("text_temperature_record_label")));
	}
	
	public void clickYesOnTemperatureRecorderAvailableOption(){
		
		element(locatorWithId("btn_yes_be_sure")).waitUntilVisible();
		element(locatorWithId("btn_yes_be_sure")).waitUntilClickable();
		element(locatorWithId("btn_yes_be_sure")).click();
	}
	
	
	public void clickOnCloseButton() throws InterruptedException {
		
		try {
			logger.info("WMT_RECEIVING : Waiting to Handel - Inventory Status Sheet...");
			if(element(locatorWithId("closeSheet")).isDisplayed()) {
			element(locatorWithId("closeSheet")).waitUntilVisible();
			element(locatorWithId("closeSheet")).waitUntilClickable();
			logger.info("WMT_RECEIVING : Clicked on Close Button ");
			}
			else {
				logger.info("WMT_RECEIVING : Close Button not displayed");
				return;
			}
		} catch (NoSuchElementException e ) {
			
			logger.info("WMT_RECEIVING : Close Button is not displayed");
			return;
		}
	}
	
	public void verifyTrophyIconIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(locatorWithId("img_trophy")));
	}
	
	public void verifyShipmentCompletedTextIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(locatorWithId("text_shipment_complete")));
	}
	
	public void verifyCompleteShipmentDescValue(String shipmentNumber) {
		catalystUtil.verifyElementValuesByContainsText(element(locatorWithId("text_shipment_complete_desc")), shipmentNumber);
	}
	
	public void verifyShipmentNumber(String shipmentNumber) {
		catalystUtil.verifyElementValues(element(shipmentNumberHeading), shipmentNumber);
	}
	
	public void verifyTotalOverageCases(String overageQty) {
		catalystUtil.verifyElementValues(element(totalOverageCasesValue), overageQty);
	}
	
	public void verifyTotalDamageCases(String damageQty) {
		catalystUtil.verifyElementValues(element(totalDamageCasesValue), damageQty);
	}
	
	public void verifyDoorSafetyChecklist(String doorNumber) {
		catalystUtil.verifyElementValuesByContainsText(element(doorSafetyChecklistTitle), doorNumber);
	}
	
	public void verifyUnexpectedUPCScanTextIsDisplayed(String text) {
		element(getElementByContainsText(text)).waitUntilVisible();	
		getElementText(text);
	}
	
	
	public List<String> getItemReceivedAndTotalCasesUnderReceivingPage() {
		element(locatorWithId("text_total_received_count")).waitUntilVisible();
		String received_TotalCasesCount = locatorWithId("text_total_received_count").getText();
		logger.info("WMT_RECEIVING : Text displayed on the Receiving Screen {}", received_TotalCasesCount);
		String[] splitTotalCases = received_TotalCasesCount.split("/");
		logger.info("WMT_RECEIVING : Total Received Cases ==> {}", splitTotalCases[0]);
		logger.info("WMT_RECEIVING : Total Cases needs to be Received ==> {}", splitTotalCases[1]);
		return Arrays.asList(splitTotalCases);
	}

	
	public void clickUnexpectedItemReceiveButton() {
		element(problemReceiveButton).waitUntilVisible();
		element(problemReceiveButton).click();
		logger.info("WMT_RECEIVING : Clicked on Receive Button in unexpected item in freight alert pop-up");
	}
	
	public void verifyProblemReceivePage() {
		catalystUtil.verifyElementIsDisplayed(element(problemReceivePageTitle));
		logger.info("Page Title for receiving item in problem state is : {}", problemReceivePageTitle.toString());
		catalystUtil.verifyElementIsDisplayed(element(unexpectedItemUPC));
		String unexpectedUPC = unexpectedItemUPC.getText();
		logger.info("UPC scanned for item not present on freight is : {}", unexpectedUPC);
		catalystUtil.verifyElementIsDisplayed(element(itemNumDisplayedForUnexpectedUPC));
		String itemNumDisplayedForUnexpectedItem = itemNumDisplayedForUnexpectedUPC.getText();
		logger.info("Item No. displayed in Problem receving screen is : {}", itemNumDisplayedForUnexpectedItem);
		String actualitemNumToBeDisplayed = "PROBLEM1";
//		Assert.assertEquals(ErrorCodes.CATALYST_PROBLEM_ITEM_NUM_MISMATCH, itemNumDisplayedForUnexpectedItem.equalsIgnoreCase(actualitemNumToBeDisplayed));
		
	}
	
	public void verifyProblemPopUpText(String problemPoUpText) {
//		String problemPopUpMessage = problemPopUpText.getText();
		catalystUtil.verifyElementValuesByContainsText(element(problemPopUpText), problemPoUpText);
		logger.info("Message displayed while receving an unexpected item is  : {}", problemPoUpText);
	}
		
	public boolean isElementPresentBasedOnExactText(String elementText) {
//		element(xpathContainsText(elementText)).waitUntilVisible();
		if(xpathContainsText(elementText).isDisplayed())
			return true;
		else
			return false;
	}
	
	public boolean isElementPresentBasedOnPartialText(String partialText) {
		if(getElementByPartialText(partialText).isDisplayed())
			return true;
		else
			return false;
	}
	
	public boolean elementPresentBasedOnPartialText(String partialText) {
		List<WebElement> elementList = getDriver().findElements(By.xpath("//*[contains(@text,'"+partialText+"')]"));
		if(elementList.size() > 0)
			return true;
		else
			return false;
	}
	
	public String getfieldValueForParticularField(String fieldName) {
		element(getfieldValueElementForParticularField(fieldName)).waitUntilVisible();
		String fieldValue = getfieldValueElementForParticularField(fieldName).getText().trim();
		logger.info("Value for {} field is: {}", fieldName, fieldValue);
		return fieldValue;
	}
	
	public String getfieldValueForParticularFieldInPutaway(String fieldName, String partialClassName) {
		element(getfieldValueElementForParticularFieldInPutaway(fieldName, partialClassName)).waitUntilVisible();
		String fieldValues = getfieldValueElementForParticularFieldInPutaway(fieldName, partialClassName).getText().trim();
		logger.info("Value for {} field is: {}", fieldName, fieldValues);
		return fieldValues;
	}
	
	public void enterTrailerSealNumber(String sealNumber) throws InterruptedException {
		element(locatorWithId("text_value")).waitUntilVisible();
		element(locatorWithId("text_value")).waitUntilClickable();
		locatorWithId("text_value").clear();
		locatorWithId("text_value").sendKeys(sealNumber);
		logger.info("WMT_RECEIVING : Entered trailer closing seal number as ==> {}", sealNumber);
	}
	
	public String countTiHiForAnItem() {

		logger.info("WMT_RECEIVING : Counting Item Ti x Hi ====");
		element(locatorWithId("txt_tiHiTextValue")).waitUntilVisible();
		element(locatorWithId("txt_tiHiTextValue")).waitUntilPresent();
		String tihiOnReceiveScreen = locatorWithId("txt_tiHiTextValue").getText();
		logger.info("WMT_RECEIVING : Ti x Hi displayed on the Receiving Screen {}", tihiOnReceiveScreen);
		String[] splitTotalCases = tihiOnReceiveScreen.split("X");

		logger.info("WMT_RECEIVING : Ti Hi Value to be Multiply ==> {}", splitTotalCases[0]);
		logger.info("WMT_RECEIVING : Ti Hi Value to be Multiply ==> {}", splitTotalCases[1]);

		// Entering the +1 quantity to validate the TiHi Scenario
		int multipliedTiHi = (Integer.parseInt(splitTotalCases[0].trim()))
				* (Integer.parseInt(splitTotalCases[1].trim())) + 1;
		logger.info("WMT_RECEIVING : Ti Hi Multiplyed value is ==>{}" + multipliedTiHi);
		String finalvalue = (multipliedTiHi + "");
		return finalvalue;
	}
	
	
	public void handleTiHiExceededPopUp() {
		try {
			logger.info("WMT_RECEIVING : Waiting to Handel - Ti Hi Exceeded Pop-Up...");

			if (element(locatorWithId("text_title")).isDisplayed()) {
				element(locatorWithId("text_title")).waitUntilVisible();
				element(locatorWithId("text_title")).waitUntilPresent();
				String recordDialogText = element(locatorWithId("text_title")).getText();

				catalystUtil.verifyElementIsDisplayed(element(locatorWithId("text_title")));
				logger.info("WMT_RECEIVING : Popup text is  {}" + recordDialogText);

			} else {
				logger.info("WMT_RECEIVING : Ti Hi Exceeded Popup is not displayed");
				return;
			}
		} catch (NoSuchElementException e) {

			logger.info("WMT_RECEIVING : Ti Hi Exceeded Popup is not displayed");
			return;
		}
	}
	

	public void verifyEnteredQuantity(String enteredTiHiValue) {

		//String enteredTiHiValue = countTiHiForAnItem();
		logger.info("WMT_RECEIVING : Total Ti Hi Quantity entered {}", enteredTiHiValue);
		String qtyValue = element(locatorWithId("item_qty_val")).getText();
		logger.info("WMT_RECEIVING : Total Quantity displayed on Popup {}", qtyValue);

		catalystUtil.verifyElementValuesByContainsText(element(locatorWithId("item_qty_val")), enteredTiHiValue);
	}

	public void verifyTiHiItemNumber(String itemNumber) {
		logger.info("WMT_RECEIVING : TiHi Item Number {}", itemNumber);
		catalystUtil.verifyElementValues(element(locatorWithId("item_number_val")), itemNumber);
	}
	

	public void clickOnContextMenu() {

		element(contextMenuOption).waitUntilVisible();
		element(contextMenuOption).click();
		logger.info("WMT_RECEIVING : Clicked on context menu option in receiving page");

	}
	
	public void selectReverseReceiptOption() {

		element(xpathContainsText("Reverse receipt")).waitUntilVisible();
		element(xpathContainsText("Reverse receipt")).waitUntilClickable();
		element(xpathContainsText("Reverse receipt")).click();
		logger.info("WMT_RECEIVING : Clicked on Reverse receipt option under context menu option");

	}
	
	public void enterLPNtoBeReversed(String reverseLPN) {

		element(reverseLPNTextBox).waitUntilVisible();
		element(reverseLPNTextBox).sendKeys(reverseLPN);
		element(xpathContainsText("Next")).click();
		logger.info("WMT_RECEIVING : Entered LPN to be reversed :{}", reverseLPN);

	}
	
	public void validateReverseReceiptPage(String receivedStatus) {

		catalystUtil.verifyElementIsDisplayed(element(reverseReceiptPageTitleForProblemLPN));
		logger.info("Page Title for reverse receipt for LPN received in problem state is : {}", reverseReceiptPageTitleForProblemLPN.toString());
		catalystUtil.verifyElementIsDisplayed(element(reverseReceiptItemNumberForProblemLPN));
		logger.info("Page Title for reverse receipt for LPN received in problem state is : {}", reverseReceiptPageTitleForProblemLPN.toString());
		
		if(receivedStatus.equalsIgnoreCase("Problems")) {
			String expectedInventoryStatus = "Prob";
//			catalystUtil.verifyElementIsDisplayed(element(locatorWithId("text_title")));
		}

	}
	
	public void clickOnReverseReceiptButton() {

		element(getElementByPartialText("Reverse receipt")).waitUntilVisible();
		element(getElementByPartialText("Reverse receipt")).click();
		logger.info("WMT_RECEIVING : Clicked on reverse receipt button");

	}

	
//	################################################################# LPN & UPC Scan #######################################################
	
	public void performLPNandUPCScanning(String labelType, String valueToScan) throws InterruptedException {
		logger.info("valueToScan : {}", valueToScan);
		
		
		if ((valueToScan.length() <= 20) && (labelType.equals("EAN128"))) {
			labelType = "EAN128";
			logger.info("Label Type is {} and LPN value To Scan : {}", labelType, valueToScan);
		} else {
			labelType = "UPC";
			logger.info("Label Type is {} and UPC value To Scan : {}", labelType, valueToScan);
		}
		
		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "--es",
				"com.symbol.datawedge.label_type " + labelType, "--es",
				"com.symbol.datawedge.data_string " + valueToScan);
		
		
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
		logger.info("Scanning Event ::: ==> "+scanEvent);
		Thread.sleep(3000);
		getAndroidDriver().executeScript("mobile: shell", scanEvent);
		try {
			Thread.sleep(3000);
			
			if(labelType.contains("EAN128")) {
				logger.info("Scanned LPN ", valueToScan);
			} else {
				logger.info("Scanned UPC ", valueToScan);
			}
		
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
//	################################################################# Infestation #######################################################

	@FindBy(xpath = "//android.widget.ImageView[@content-desc='More options']")
	private WebElement actionButton;
	
	public void verifySafetyInspectionFailedPopUp() {

		logger.info("WMT_RECEIVING : Waiting to Handel - Safety Inspection Pop-Up...");
		
		if (element(xpathContainsText("Safety inspection failed")).isDisplayed()) {
			element(xpathContainsText("Safety inspection failed")).waitUntilVisible();
			element(xpathContainsText("Safety inspection failed")).waitUntilPresent();
			String safetyDialogText = element(xpathContainsText("Safety inspection failed")).getText();

			catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Safety inspection failed")));
			logger.info("WMT_RECEIVING : Popup text is ==== {}", safetyDialogText);
		} else {
			logger.info("WMT_RECEIVING : Safety Inspection Popup is not displayed");
		}
	}

	
	public void clickOnContextActionButton() {

		element(actionButton).waitUntilPresent();
		element(actionButton).waitUntilVisible();
		element(actionButton).waitUntilClickable();
		element(actionButton).click();
		logger.info("WMT_RECEIVING : Clicked on Action Button ====");
	}

	public void selectOptionTailerManagement() {

		element(xpathContainsText("Trailer management")).waitUntilVisible();
		element(xpathContainsText("Trailer management")).waitUntilClickable();

		String trailerManagOption = xpathContainsText("Trailer management").getText();
		logger.info("WMT_RECEIVING : Selected {} Option ====", trailerManagOption);
		element(xpathContainsText("Trailer management")).click();

	}

	public void verifyTrailerManagementScreen() {
		catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Trailer management")));
	}

	public void clickOnChooseTrailerOperation() {

		//*[@text='Choose the trailer operation']
		element(xpathContainsText("Choose the trailer operation")).waitUntilVisible();
		element(xpathContainsText("Choose the trailer operation")).waitUntilClickable();
		element(xpathContainsText("Choose the trailer operation")).click();
		
		catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Close trailer")));
		
		logger.info("WMT_RECEIVING : Clicked on Choose the Trailer Operation ====");

	}

	public void selectCloseTrailerOption() {

		element(xpathContainsText("Close trailer")).waitUntilVisible();
		element(xpathContainsText("Close trailer")).waitUntilClickable();

		String closeTrailergOption = xpathContainsText("Close trailer").getText();
		logger.info("WMT_RECEIVING : Selected {} Option ====", closeTrailergOption);
		element(xpathContainsText("Close trailer")).click();

	}

	public void clickOnChooseTrailerAction() {

		element(xpathContainsText("Select a reason")).waitUntilVisible();
		if(element(xpathContainsText("Select a reason")).isDisplayed()) {
			element(xpathContainsText("Select a reason")).waitUntilClickable();
			element(xpathContainsText("Select a reason")).click();
		} else {
		element(xpathContainsText("Choose the trailer action")).waitUntilVisible();
		element(xpathContainsText("Choose the trailer action")).waitUntilClickable();
		element(xpathContainsText("Choose the trailer action")).click();
		}
		catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Rejected Infestation")));
		logger.info("WMT_RECEIVING : Clicked on Choose the Trailer Action ====");
	}

	public void selectRejectInfestationOption() {

		element(xpathContainsText("Rejected Infestation")).waitUntilVisible();
		element(xpathContainsText("Rejected Infestation")).waitUntilClickable();

		String closeTrailergOption = xpathContainsText("Rejected Infestation").getText();
		logger.info("WMT_RECEIVING : Selected {} Option ====", closeTrailergOption);
		element(xpathContainsText("Rejected Infestation")).click();

	}
	
	public void verifyItemStatusPopUp() {

		logger.info("WMT_RECEIVING : Waiting to Handel - Item Status Popup...");
		
		if (element(xpathContainsText("Item Status")).isDisplayed()) {
			element(xpathContainsText("Item Status")).waitUntilVisible();
			element(xpathContainsText("Item Status")).waitUntilPresent();
			String itemStatus = element(xpathContainsText("Item Status")).getText();

			catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Item Status")));
			logger.info("WMT_RECEIVING : Popup text is  {}" + itemStatus);
		} else {
			logger.info("WMT_RECEIVING : Item Status Popup is not displayed");
		}
	}
	
	
	
	// ######################################### Generic Methods #################################

	private WebElement locatorWithId(String idName) {
		return getDriver().findElement(By.id(RECEIVING_MOBILE_ID + idName));
	}

	private WebElement xpathContainsText(String text) {
		return getDriver().findElement(By.xpath("//*[@text='" + text + "']"));
	}
	
	public String getElementText(String elementText) {
		
		WebElement element = getDriver().findElement(By.xpath("//*[contains(@text,"+elementText+")]"));
		element(element).waitUntilVisible();
		String messageText = element.getText();
		logger.info("WMT_RECEIVING : Returned text: {}", messageText);
		return messageText;
		
	}

	public void clickOnButtonBasedOnText(String elementText) {
		element(xpathContainsText(elementText)).waitUntilVisible();
		element(xpathContainsText(elementText)).click();
		logger.info("WMT_RECEIVING : Clicked on {} element", elementText);
	}

	public void clickOnElementBasedOnPartialText(String partialText) {
		element(getElementByPartialText(partialText)).waitUntilVisible();
		element(getElementByPartialText(partialText)).click();
		logger.info("WMT_RECEIVING : Clicked on {} element", partialText);

	}

	public void clickOnElementBasedOnText(String elementText) {
		element(xpathContainsText(elementText)).waitUntilVisible();
		element(xpathContainsText(elementText)).click();
		logger.info("WMT_RECEIVING : Clicked on {} element", elementText);
	}

	public void clickOnOkButton() {

		element(xpathContainsText("OK")).waitUntilVisible();
		element(xpathContainsText("OK")).waitUntilClickable();
		element(xpathContainsText("OK")).click();
		logger.info("WMT_RECEIVING : Clicked on OK Button");
	}

	public void selectNoButton() throws InterruptedException {
		
		element(xpathContainsText("No")).waitUntilVisible();
		element(xpathContainsText("No")).waitUntilClickable();
		element(xpathContainsText("No")).click();
		logger.info("WMT_RECEIVING : Clicked on No Button ==== ");
		//Wait is mandatory
		Thread.sleep(500);
	}
	
	public void selectYesButton() throws InterruptedException {
		
		element(xpathContainsText("Yes")).waitUntilVisible();
		element(xpathContainsText("Yes")).waitUntilClickable();
		element(xpathContainsText("Yes")).click();
		//Wait is mandatory
		Thread.sleep(500);
	}
	
public void verifyUnidentifiablePopupIsDisplayed() {
		
		element(xpathContainsText("Unidentifiable Item")).waitUntilVisible();
		catalystUtil.verifyElementIsDisplayed(element(xpathContainsText("Unidentifiable Item")));
	}

}

