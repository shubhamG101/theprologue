package com.walmart.supplychain.nextgen.common;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.of.pages.webservices.OrderFulfillmentHelper;
import com.walmart.supplychain.nextgen.of.steps.webservices.OrderFulfillmentSteps;
import com.walmart.supplychain.nextgen.op.pages.webservices.OrderTracking;

import io.restassured.response.Response;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import java.util.ArrayList;
import java.util.List;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CleanUpScripts {

	@Autowired
	InventorySteps invSteps;

	Logger logger = LogManager.getLogger(this.getClass());
	private static List<String> inventoryLpns = new ArrayList<>();
	private Response response;

	@Autowired
	OrderFulfillmentSteps ofSteps;
	@Autowired
	OrderTracking ot;
	
	@Autowired
	IDMHelper idmHelper;
	
	@Autowired
	PreRunCleanup preRunCleanup;

	public void dataCleanUp() throws JSONException {
		if(Config.DC!=DC_TYPE.ATLAS) {
			/*
			//invSteps.deleteInventoryData();
			ofSteps.deleteFulFillment();

			idmHelper.deleteDelivery();
			//ot.deleteOrderTrackingData();This is commented out as OrderId is not available in testFlowData
			*/
		}else {
			/*
			preRunCleanup.cleanUpOf();
			preRunCleanup.cleanUpGDM();
			logger.info("Deleted the GDM data as part of post cleanup");
			*/
		}
	}

}
