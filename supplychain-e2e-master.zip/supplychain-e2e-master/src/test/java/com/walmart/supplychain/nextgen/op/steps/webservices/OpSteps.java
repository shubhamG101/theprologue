package com.walmart.supplychain.nextgen.op.steps.webservices;

import static com.jayway.jsonpath.JsonPath.parse;
import static java.lang.Integer.parseInt;
import static net.serenitybdd.rest.SerenityRest.given;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.*;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.op.orderTrackerStatus.OrderAllocStatus;
import com.walmart.supplychain.nextgen.op.orderTrackerStatus.OrderManagerStatus;
import com.walmart.supplychain.nextgen.op.orderTrackerStatus.OrderTrackerStatus;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;
import io.restassured.http.Header;
import io.restassured.http.Headers;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OpSteps {

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	JavaUtils javautils;

	@Autowired
	Environment environment;

	@Autowired
	OrderProcessingHelper orderProcessingHelper;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Autowired
	OrderManagerStatus orderManagerStatus;
	
	@Autowired
	OrderAllocStatus orderAllocStatus;
	
	@Autowired
	Environment queries;

	Logger logger = LoggerFactory.getLogger(OpSteps.class);
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private static final String ITEM_NUMEBR_JSON_PATH="$..ordersDetails[*].itemNumber";
	private static final String OM_GET_ORDER_STATUS="om_get_order_status";
	private static final String OA_GET_ORDER_STATUS="oa_get_order_status";
	private static final String OM_ORDER_STATUS_CODE_COLUMN="order_status_code";
	private static final String OA_ALLOC_ORDER_STATUS_CODE_COLUMN="alloc_order_status_code";
	private static final String OA_ORDER_ID_COLUMN="order_id";
	private static final String OM_WHSE_ORDER_ID_COLUMN="whse_order_id";
	private static final short DEL_FINAL_OP = 7;
	int totalopenQty = 0;

	@Step
	public void verifyOMSearchServiceForOtnAndQuantity(String status) throws IOException, URISyntaxException {
		try {
			final String errorMsg = "Exception while verifying the created orders in Order Manager";
			ArrayList<String> sourceNumberList = (ArrayList<String>) tl.get().get("sourceNumberList");
			for (String sourceNumber : sourceNumberList) {

				String ja = tl.get().get("testFlowData").toString();
				logger.info("testflow data ::: ::: ::: "+ja);
				JSONArray otnArray = parse(ja).read(
						"$..[?(@.sourceNumber=='" + sourceNumber + "'&&@.isOverage==false)]..orderTrackingNumber",
						JSONArray.class);
				logger.info("sourceNumber list ::"+sourceNumberList+" source number is "+sourceNumber+" OTNS::: "+otnArray);
				final String otnAssertCountMsg = "The expected number of OTN'S is not present in the Order Services response";

				final String nbrOfMatchesJp = "$.nbrOfMatches";
				if(System.getProperty("invalidDest") != null) {
					if (otnArray != null) { 
					   for (int i=0;i<otnArray.size();i++) { 
						   JSONArray destArray = parse(ja).read(
									"$..ordersDetails[?(@.orderTrackingNumber=='"+otnArray.get(i)+"')].destinationNum",
									JSONArray.class);
						   String destination = destArray.get(0).toString();
						   logger.info("Destination for OTN:"+destination+" for "+otnArray.get(i));
					    if(destination.equalsIgnoreCase(System.getProperty("invalidDest"))) {
					    	otnArray.remove(i);
					    }
					   } 
					} 
					logger.info("otnArray after updation"+otnArray);
				}
				String searchWithOtns = getSearchWithOtnsPayload(otnArray);

				Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, Constants.RETRY_EXECUTION_DELAY_18S,
						Constants.RETRY_EXECUTION_COUNT_15)).run(() -> {

							Response response;
//					if (Config.isCloud) {

							response = SerenityRest.given().relaxedHTTPSValidation().headers(getOPHeaders())
									.body(searchWithOtns).when().post(environment.getProperty("om_search"));

//					} else {
//						response = SerenityRest.given().body(searchWithOtns).header("Content-Type", ContentType.JSON)
//								.when().post(environment.getProperty("om_search"));
//					}

							logger.info("Searching OM with OTNS : " + environment.getProperty("om_search")
									+ " with body : " + searchWithOtns);
							String jiraDesc = "Expected otns:" + otnArray;
							if (status.contains("CNL")) {
								Assert.assertEquals(ErrorCodes.OP_OW_ORDER_DOWNLOAD_FAILED, 204,
										response.getStatusCode(), jiraDesc);
								logger.info("OP response : " + +response.getStatusCode());
							} else {
								Assert.assertEquals(ErrorCodes.OP_OW_ORDER_DOWNLOAD_FAILED, 200,
										response.getStatusCode(), jiraDesc);
								String sNbrOfMatches = JsonPath.parse(response.asString()).read(nbrOfMatchesJp)
										.toString();

								Assert.assertEquals(ErrorCodes.OP_COUNT_MISMATCH_IN_OM, otnArray.size(),
										parseInt(sNbrOfMatches), jiraDesc);
								if (Config.DC == DC_TYPE.SAMS) {
									validatePickPoNumberForAllOtns(response, ja);
								}
								populateOrderIdsInTestFlowData(response, otnArray);
							}

						});

			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verify OTN in OM Service", e);
		}
	}

	private void populateOrderIdsInTestFlowData(Response response, JSONArray otnArray) throws IOException {

		ObjectMapper om = new ObjectMapper();
		logger.info("OM Response:{}", response.asString());
		TestFlowDataMain testFlowData_ = om.readValue((String) tl.get().get("testFlowData"), TestFlowDataMain.class);

		List<OrdersDetail> ordersDetails = testFlowData_.getTestFlowData().getOrdersDetails();

		for (int i = 0; i < ordersDetails.size(); i++) {

			OrdersDetail ordersDetail = ordersDetails.get(i);
			String orderTrackingNumber = ordersDetail.getOrderTrackingNumber();
			logger.info("orderTrackingNumber from testflowData:{}", orderTrackingNumber);
			if (otnArray.contains(orderTrackingNumber)) {
				String orderId = (String) parse(response.getBody().asString())
						.read("$.listOfEntities[?(@.origTrackingNbr=='" + orderTrackingNumber + "')]..id",
								JSONArray.class)
						.get(0);
				logger.info("orderId :{}", orderId);
				ordersDetail.setOrderId(orderId);
			}

		}

		tl.get().put("testFlowData", om.writeValueAsString(testFlowData_));

	}

	@Step
	public void verifyOrdersAreDownloaded() throws IOException {

		String testFlowData = tl.get().get("testFlowData").toString();
		JSONArray otns = JsonPath.parse(testFlowData).read("$..orderTrackingNumber");

		String requestBody = "{\"origTrackingNbrs\":[\"";
		for (int i = 0; i < otns.size(); i++) {
			requestBody += i == 0 ? otns.get(i) : ",\"" + otns.get(i);
			requestBody += "\"";
		}
		requestBody += "]}";
		logger.info("Request Body for searching in Order services is  : " + requestBody);

		String requestBodyFailSafe = requestBody;
		Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 10)).run(() -> {
			
			Response response = SerenityRest.given().relaxedHTTPSValidation().headers(getOPHeaders())
					.body(requestBodyFailSafe).post(environment.getProperty("om_search"));

			Assert.assertEquals(ErrorCodes.OP_OW_ORDER_DOWNLOAD_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());

			JSONArray respBody = JsonPath.parse(response.getBody().asString()).read("$..id");

			Assert.assertEquals(ErrorCodes.OP_OW_ORDER_OTN_MISMATCH, respBody.size(), otns.size());

		});
		logger.info("Orders downloaded successfully in Order services");

		Response response = SerenityRest.given().relaxedHTTPSValidation().headers(getOPHeaders())
				.body(requestBodyFailSafe).post(environment.getProperty("om_search"));

		populateOrderIdsInTestFlowData(response, otns);
		for (int i = 0; i < otns.size(); i++) {
			JSONArray searchedOtns = JsonPath.parse(response.getBody().asString())
					.read("$.listOfEntities[?(@.origTrackingNbr=='" + otns.get(i) + "')]..status", JSONArray.class);
			Assert.assertEquals(ErrorCodes.OP_OW_ORDER_DOWNLOAD_FAILED, "Acknowledged", searchedOtns.get(0).toString());
		}
	}

	@Step
	public void verifyOAOrders() throws IOException, URISyntaxException {
		try {
			String testFlowData = (String) tl.get().get("testFlowData");
			JSONArray orderWellOrders = JsonPath.read(testFlowData, "$..ordersDetails[*]");
			ArrayList<String> allocOrderSearchKeys = new ArrayList<>();

			for (int i = 0; i < orderWellOrders.size(); i++) {

				LinkedHashMap orderWellObj = (LinkedHashMap) orderWellOrders.get(i);
				String allocSearch = orderWellObj.get("itemNumber") + ";" + orderWellObj.get("omsChannelMethod") + ";"
						+ orderWellObj.get("plannedPo") + ";"
						+ getOaChannelMethodFromType(testFlowData, orderWellObj.get("plannedPo").toString(),
								orderWellObj.get("omsChannelMethod").toString())
						+ ";" + orderWellObj.get("sourceNumber");
				
				if(System.getProperty("invalidDest") != null) {
				String invalidDest = System.getProperty("invalidDest");
				String dest = orderWellObj.get("destinationNum").toString();
				if(!(dest.equalsIgnoreCase(invalidDest))) {
					allocOrderSearchKeys.add(allocSearch);
				}
				} else {
				allocOrderSearchKeys.add(allocSearch);
				}
			}

			/*
			 * Don not delete this comment. No need for the below step, just check if it
			 * contains the key and if it already contains dont add the key in the above
			 * step.
			 */
			List<String> distinctSearchKeys = allocOrderSearchKeys.stream().distinct().collect(Collectors.toList());

			HashMap<String, Integer> quantityAndSearchKeys = new HashMap<>();

			for (int i = 0; i < distinctSearchKeys.size(); i++) {

				String allocSearchComposite = distinctSearchKeys.get(i);
				String itemNum = allocSearchComposite.split(";")[0];
				String poType = allocSearchComposite.split(";")[1];
				String poNum = allocSearchComposite.split(";")[2];
				String sourceNumber = allocSearchComposite.split(";")[4];
				JSONArray qtyArr;
				if (poType.equalsIgnoreCase("20") || poType.equalsIgnoreCase("33")) {
					qtyArr = parse(orderWellOrders).read(
							"$[*][?(@.itemNumber=='" + itemNum + "' && @.sourceNumber=='" + sourceNumber + "')]",
							JSONArray.class);
				} else {
					if(System.getProperty("invalidDest") != null) {
						qtyArr = parse(orderWellOrders).read(
								"$[*][?(@.itemNumber=='" + itemNum + "' && @.omsChannelMethod=='" + poType
										+ "' && @.plannedPo=='" + poNum + "' && @.sourceNumber=='" + sourceNumber + "' && @.destinationNum!='" + System.getProperty("invalidDest") + "')]",
								JSONArray.class);
					} else {
						qtyArr = parse(orderWellOrders).read(
								"$[*][?(@.itemNumber=='" + itemNum + "' && @.omsChannelMethod=='" + poType
										+ "' && @.plannedPo=='" + poNum + "' && @.sourceNumber=='" + sourceNumber + "')]",
								JSONArray.class);
					}
					
				}

				int qty = 0;

				for (int j = 0; j < qtyArr.size(); j++) {
					qty = qty + Integer.parseInt(((LinkedHashMap) qtyArr.get(j)).get("quantity").toString());
				}

				quantityAndSearchKeys.put(distinctSearchKeys.get(i), qty);

				tl.get().put("quantityAndSearchKeys", quantityAndSearchKeys);
			}

			for (int i = 0; i < distinctSearchKeys.size(); i++) {

				String allocSearchComposite = distinctSearchKeys.get(i);
				String itemNum = allocSearchComposite.split(";")[0];
				String poType = allocSearchComposite.split(";")[1];
				String channelMethod = allocSearchComposite.split(";")[3];
				String poNum = allocSearchComposite.split(";")[2];
				String sourceNumber = allocSearchComposite.split(";")[4];

				verifyOAOrders(itemNum, poNum, poType, channelMethod, sourceNumber, 0, false);

			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying OA Orders", e);
		}
	}

	private String getOaChannelMethodFromType(String testFlowData, String poNumber, String poType) {
		String isChannelFlipVal = ((JSONArray) JsonPath.read(testFlowData,
				"$.testFlowData.poDetails[?(@.poNumber=='" + poNumber + "')].isChannelFlipRequired")).get(0).toString();
		boolean isChannelFlip = isChannelFlipVal != null && !isChannelFlipVal.equals("")
				? Boolean.parseBoolean(isChannelFlipVal)
				: false;
		if (isChannelFlip) {
			logger.info("Channel flip status for PO:{}==>{}", poNumber, isChannelFlip);
			poType = poType.equals("20") ? "33" : "20";
		}
		switch (poType) {
		case "20":
			return "SSTKU";
		case "33":
			return "CROSSU";
		case "3":
			return "CROSSMU";
		case "53":
			return "CROSSMU";
		case "43":
			return "CROSSMU";
		default:
			return null;
		}
	}

	@Step
	public void verifyFulFilledQtyInOA(String db) throws IOException, URISyntaxException {

		// This will get the pre-alloc qty in eaches from the DB
		logger.info("Get pre alloc each qty from order allocation table {}",
				environment.getProperty("select_pre_Alloc_each_qty"));

		// This method will find the received qty from the testflow json
		int receivedQty = calculateReceivedQty();
		Object[] otn = orderTrackingNumber();

		Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 12, 10)).run(() -> {

			List<Map<String, Object>> preAllocEachQty;
			preAllocEachQty = dbUtils.selectFrom(PRODUCT_NAME.OP,
					dbUtils.transformIntoSpringQuery(environment.getProperty("select_pre_Alloc_each_qty"), otn.length),
					otn);

			int preAllocEachQtyDB = 0;
			for (Map<String, Object> data : preAllocEachQty) {
				preAllocEachQtyDB = preAllocEachQtyDB + (int) data.get("pre_alloc_each_qty");
			}
			logger.info("Alloc qty from DB " + preAllocEachQtyDB);

			logger.info("preAllocEachQtyDB - receivedQty " + preAllocEachQtyDB + " " + receivedQty);
			Assert.assertEquals(ErrorCodes.OP_OA_ORDER_QUANITY_MISMATCH, receivedQty, preAllocEachQtyDB);
		});

	}

	@Step
	public void verifyPOEntryInOM() {
		try {
			String testFlowData = (String) tl.get().get("testFlowData");
			DocumentContext parsedTestFlowJson = JsonPath.parse(testFlowData);
			List<String> deliveryNumberList = parsedTestFlowJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
			List<String> poNumberList = parsedTestFlowJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			// This will po enrty from the DB
			logger.info("Checking for PO and Delivery entry in order manager table {}",
					environment.getProperty("pocon_om_po_item_dlvr"));

			for (String poNumber : poNumberList) {
				Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 12, 10)).run(() -> {

					List<Map<String, Object>> poEntry;
					poEntry = dbUtils.selectFrom(Config.DC, environment.getProperty("pocon_om_po_item_dlvr"), poNumber);
					List<String> poType = JsonPath.read(testFlowData,
							"$..poDetails[?(@.poNumber=='" + poNumber + "')].channelMethod");
					if (poType.get(0).equalsIgnoreCase("POCON")) {
						Assert.assertEquals(ErrorCodes.OP_OM_PO_DELIVEYR_ENTRY_CHECK, 0, poEntry.size());
					} else {
						Assert.assertEquals(ErrorCodes.OP_OM_PO_DELIVEYR_ENTRY_CHECK, 1, poEntry.size());
					}
				});
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying OA Orders", e);
		}
	}

	private int calculateReceivedQty() {

		JSONArray receivedQtyArr;
		int receivedQty = 0;
		String receivedQtyJsonPath = "";
		if (Config.DC == DC_TYPE.ACC) {
			receivedQtyJsonPath = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.isPbyl == false && @.isVTR == false && @.labelType == 'normal')].receivedQuantity";
		} else {
			receivedQtyJsonPath = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.isPbyl == false && @.isVTR == false)].receivedQuantity";
		}
		String vnpkQtyJsonPath = "$.testFlowData.poDetails[*].poLineDetails[*].vnpk";

		String testData = (String) tl.get().get("testFlowData");

		receivedQtyArr = parse(testData).read(receivedQtyJsonPath, JSONArray.class);
		logger.info("Receive array size is " + receivedQtyArr.size());

		for (int i = 0; i < receivedQtyArr.size(); i++) {
			receivedQty = receivedQty + Integer.valueOf(receivedQtyArr.get(i).toString());
		}
		logger.info("Received qty is in cases " + receivedQty);

		// Assumption here is that PO is for single PO line
		// in case multiple PO line is there both the item has same vnpk Qty
		// hence taking 0 index from the array
		JSONArray vnpkQtyArr = parse(testData).read(vnpkQtyJsonPath, JSONArray.class);
		logger.info("Vnpk qty " + vnpkQtyArr.get(0));

		int vnpkQty = Integer.valueOf((vnpkQtyArr.get(0).toString()));

		return receivedQty * vnpkQty;
	}

	private Object[] orderTrackingNumber() {

		String testData = (String) tl.get().get("testFlowData");
		String orderTrackingNumberJsonPath = "$.testFlowData.ordersDetails[*].orderTrackingNumber";

		JSONArray orderTrackingNumberList = JsonPath.read(testData, orderTrackingNumberJsonPath);
		Object[] orderTrackingArr = new Object[orderTrackingNumberList.size()];

		for (int i = 0; i < orderTrackingNumberList.size(); i++) {
			orderTrackingArr[i] = orderTrackingNumberList.get(i);
			logger.info("Order tracking number : " + orderTrackingArr[i]);
		}
		logger.info("Order tracking number : " + orderTrackingArr[0]);
		logger.info("OTN length is " + orderTrackingArr.length);

		return orderTrackingArr;
	}

	@Step
	public void verifyFulFilledQtyInOA() throws IOException, URISyntaxException {
		try {
			String testFlowData = (String) tl.get().get("testFlowData");

			HashMap<String, Integer> quantityAndSearchKeys = (HashMap<String, Integer>) tl.get()
					.get("quantityAndSearchKeys");

			Set<String> searchKeys = quantityAndSearchKeys.keySet();

			Iterator<String> searchIter = searchKeys.iterator();

			while (searchIter.hasNext()) {

				String searchKey = searchIter.next();

				String itemNum = searchKey.split(";")[0];
				String channel = searchKey.split(";")[3];
				String sourceNumber = searchKey.split(";")[4];
				channel = channel.equalsIgnoreCase("SSTKU") ? "SSTK" : channel;
				String poNum = searchKey.split(";")[2];
				String poType = searchKey.split(";")[1];

				logger.info("Search details are : Item " + itemNum + " " + "channel " + channel + "  " + "sourceNumber "
						+ sourceNumber + " " + "poNum " + poNum + " " + "poType" + poType);

				JSONArray receivedQtyArr;
				int receivedQty = 0;

				if (channel.equalsIgnoreCase("CROSSMU")) {
					receivedQtyArr = parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber=='" + poNum
							+ "')].poLineDetails[?(@.channelMethod=='" + channel + "' && @.itemNumber=='" + itemNum
							+ "')]..receivingInstructions[?(@.isPbyl==false||@.isPbyl==true&&@.isPbylTripExecuted==false)]..receivedQuantity",
							JSONArray.class);
				} else {
					receivedQtyArr = parse(testFlowData).read(
							"$.testFlowData.poDetails[*].poLineDetails[?(@.itemNumber=='" + itemNum
									+ "')]..receivingInstructions[?(@.isPbyl==false||@.isPbylTripExecuted==false)]..receivedQuantity",
							JSONArray.class);
				}

				logger.info("Size of receivedQty array is " + receivedQtyArr.size());

				for (int i = 0; i < receivedQtyArr.size(); i++) {
					receivedQty += Integer.parseInt(receivedQtyArr.get(i).toString());
				}
				logger.info("Received qty is " + receivedQty);
				verifyOAOrders(itemNum, poNum, poType, channel, sourceNumber, receivedQty, true);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying fulfilled Quantiy in OA", e);
		}
	}

	public String getSearchWithOtnsPayload(JSONArray otnArray) throws IOException, URISyntaxException {

		
		final String otnsJp = "$.origTrackingNbrs";
		TextParser tp = new TextParser();
		String searchTemplate=null;
		String searchOmReqPath=null;
		if(Config.DC==DC_TYPE.ACC || Config.DC==DC_TYPE.ATLAS)
		{
			searchOmReqPath = environment.getProperty("om_search_with_otn_txt_payload");
			searchTemplate = tp.readTextFile(searchOmReqPath);
			String dc = javautils.format(searchTemplate,otnArray.toString());
			logger.info("Updated "+dc+" OTNs in the path ");
			return StringEscapeUtils.unescapeJava(dc);
		}
		else {
			searchOmReqPath = environment.getProperty("om_search_with_otn_payload");
			searchTemplate = tp.readTextFile(searchOmReqPath);
			DocumentContext dc = JsonPath.parse(searchTemplate).set(otnsJp, otnArray);
			return StringEscapeUtils.unescapeJava(dc.jsonString());
		}

	}

	private String getAllocationsPayload(String itemNum, String poNum, String channelMethod, String deliveruNumber,
			int openQty, int poQty, int maxReceivable) throws IOException, URISyntaxException {

		final String getAllocReqPath = environment.getProperty("oa_get_alloc_payload");

		final String itemNbrJp = "$.itemNbr";
		final String baseDivisionNameJp = "$.baseDivisionName";
		final String channelMethodJp = "$.channelMethod";
		final String poNumberJp = "$.poNumber";
		final String deliveryNumberJp = "$.deliveryNumber";
		final String openQtyJp = "$.openQty";
		final String poQtyJp = "$.poQty";
		final String maxReceiveQtyJp = "$.maxReceiveQty";
		final String fbQtyJp = "$.fbQty";
		String baseDivisionName = "WM";
		if (Config.DC == DC_TYPE.SAMS) {
			baseDivisionName = "SAMS";
		}

		TextParser tp = new TextParser();
		String searchTemplate = tp.readTextFile(getAllocReqPath);
		DocumentContext dc;

		if (Config.DC == DC_TYPE.SAMS) {
			dc = JsonPath.parse(searchTemplate).set(channelMethodJp, channelMethod).set(itemNbrJp, itemNum)
					.set(baseDivisionNameJp, baseDivisionName).set(fbQtyJp, String.valueOf(openQty))
					.set(poNumberJp, String.valueOf(poNum)).set(deliveryNumberJp, deliveruNumber)
					.set(openQtyJp, String.valueOf(openQty)).set(poQtyJp, String.valueOf(poQty))
					.set(maxReceiveQtyJp, String.valueOf(maxReceivable));
		} else {
			dc = JsonPath.parse(searchTemplate).set(channelMethodJp, channelMethod).set(itemNbrJp, itemNum)
					.set(baseDivisionNameJp, baseDivisionName).set(poNumberJp, String.valueOf(poNum))
					.set(deliveryNumberJp, deliveruNumber).set(openQtyJp, String.valueOf(openQty))
					.set(poQtyJp, String.valueOf(poQty)).set(maxReceiveQtyJp, String.valueOf(maxReceivable));
		}

		return StringEscapeUtils.unescapeJava(dc.jsonString());
	}

	int sumOfOAOrders;

	private void verifyOAOrders(String itemNum, String poNum, String poType, String channelMethod, String sourceNumber,
			int fulFilledQty, boolean isReceiveCompleted) throws IOException, URISyntaxException {

		HashMap<String, Integer> quantityAndSearchKeys = (HashMap<String, Integer>) tl.get()
				.get("quantityAndSearchKeys");
		/*
		 * Assumption here is that one po line per combination of item and channel
		 */
		logger.info("Test flow " + tl.get().get("testFlowData").toString());
		int rcvQties = 0;
		int poLineQties = 0;

		String channelForFailSafe = channelMethod;
		channelMethod = channelMethod.equalsIgnoreCase("SSTKU") ? "SSTK" : channelMethod;

		logger.info("Parse data " + poNum + "  " + " " + itemNum + "   " + channelMethod);

		JSONArray a = parse(tl.get().get("testFlowData").toString())
				.read("$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemNumber=='"
						+ itemNum + "' && @.channelMethod=='" + channelMethod + "')]", JSONArray.class);
		logger.info("parsing object:" + a.toJSONString());

		LinkedHashMap poDetailsMap = (LinkedHashMap) parse(tl.get().get("testFlowData").toString())
				.read("$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemNumber=='"
						+ itemNum + "' && @.channelMethod=='" + channelMethod + "')]", JSONArray.class)
				.get(0);

		int vnpk = parseInt(poDetailsMap.get("vnpk").toString());
		int poVnpkQty = parseInt(poDetailsMap.get("poVnpkQty").toString());
		int ovgQty = parseInt(poDetailsMap.get("ovgQty").toString()) * vnpk;
		int poQty = poVnpkQty * vnpk;

		fulFilledQty *= vnpk;
		int fulFilledQtyForFailSafe = fulFilledQty;
		channelMethod = channelMethod.equalsIgnoreCase("SSTK") ? "SSTKU" : channelMethod;
		logger.info("quantityAndSearchKeys:{}", quantityAndSearchKeys);
		int totalCreatedOrderQty = quantityAndSearchKeys
				.get(itemNum + ";" + poType + ";" + poNum + ";" + channelMethod + ";" + sourceNumber);
		JSONArray destinationNum = JsonPath.parse(tl.get().get("testFlowData").toString())
				.read("$..ordersDetails[?(@.isOverage==false&&@.itemNumber=='" + itemNum + "')].destinationNum");

		List<String> uniqueDestination = new ArrayList<String>();

		for (int i = 0; i < destinationNum.size(); i++) {
			uniqueDestination.add(destinationNum.get(i).toString());
		}
		LinkedHashSet<String> hashSet = new LinkedHashSet<>(uniqueDestination);

		ArrayList<String> uniDest = new ArrayList<>(hashSet);

		if (!isReceiveCompleted) {
			int totalOvgQtyCreated = getTotalOverageOrdersQty(itemNum, sourceNumber);
			logger.info("Total Overage qty Created:{}", totalOvgQtyCreated);
			totalCreatedOrderQty = totalCreatedOrderQty - totalOvgQtyCreated;
			JSONArray opnQties = null;
			for (int i = 0; i < uniDest.size(); i++) {
				opnQties = JsonPath.parse(tl.get().get("testFlowData").toString())
						.read("$..ordersDetails[?(@.isOverage==false&&@.itemNumber=='" + itemNum
								+ "'&& @.destinationNum=='" + uniDest.get(i).toString() + "'&&@.plannedPo=='" + poNum
								+ "')].quantity");
			}

			for (int j = 0; j < opnQties.size(); j++) {
				totalopenQty = totalopenQty + Integer.parseInt(opnQties.get(j).toString());

			}

			if (uniDest.size() > 1) {
				totalopenQty = totalCreatedOrderQty;
			}

			logger.info("Total Open Qty {}", totalopenQty);
		} else {
			JSONArray rcvQty = JsonPath.parse(tl.get().get("testFlowData").toString())
					.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNum + "')].poLineDetails[?(@.itemNumber=="
							+ itemNum + ")].receivingInstructions[*].receivedQuantity");

			JSONArray poLineQty = JsonPath.parse(tl.get().get("testFlowData").toString())
					.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNum + "')].poLineDetails[?(@.itemNumber=="
							+ itemNum + ")].poVnpkQty");

			for (int i = 0; i < rcvQty.size(); i++) {
				rcvQties = rcvQties + Integer.parseInt(rcvQty.get(i).toString());

			}
			logger.info("Total receive Qty {}", rcvQties);

			for (int i = 0; i < poLineQty.size(); i++) {
				poLineQties = poLineQties + Integer.parseInt(poLineQty.get(i).toString());

			}
			logger.info("Total PO LIne Qty {}", poLineQties);

			if (rcvQties >= poLineQties) {

				if (totalCreatedOrderQty > rcvQties) {
					totalopenQty = rcvQties * vnpk;
				} else {
					totalopenQty = totalCreatedOrderQty;

				}
			} else {
				totalopenQty = totalCreatedOrderQty;

			}
		}

		if (uniDest.size() > 1) {
			totalopenQty = totalCreatedOrderQty;
		}

		logger.info("Total Open Qty {}", totalopenQty);

		int totalCreatedOrderQtyFailSafe = totalCreatedOrderQty;
		logger.info("Total created qty {}", totalCreatedOrderQty);

		sumOfOAOrders = 0;

		String deliveryNumber = (String) parse(tl.get().get("testFlowData").toString())
				.read("$..deliveryDetails..deliveryNumber", JSONArray.class).get(0);

		final String contentType = "application/json";
		final String orderQtyJp = "$.allocations[*]..orderQty";
		final String fulfilledQtyJp = "$.allocations[*]..fulfilledQty";
		final String destNumberJp = "$.allocations[*]..destNbr";
		final String finalDestNumberJp = "$.allocations[*]..finalDestNbr";

		final String otnAssertCountMsg = "The expected number of OTN'S are not present in the Order Services response";

		String getAllocPayload = getAllocationsPayload(itemNum, poNum, channelMethod, deliveryNumber,
				(totalopenQty - fulFilledQty), poQty, (poQty + ovgQty));
		logger.info("Alloc Payload " + getAllocPayload.toString());

		if (channelMethod.equalsIgnoreCase("CROSSMU")) {
			if (fulFilledQty <= totalCreatedOrderQty) {
				getAllocPayload = JsonPath.parse(getAllocPayload)
						.set("$.distributionQty", totalCreatedOrderQty - fulFilledQty).jsonString();

				if ((totalCreatedOrderQty - fulFilledQty) <= 0) {
					getAllocPayload = JsonPath.parse(getAllocPayload).set("$.distributionQty", 1).jsonString();
				}

			} else {
				getAllocPayload = JsonPath.parse(getAllocPayload).set("$.distributionQty", vnpk).jsonString();
			}
		}

		logger.info("totalCreatedOrderQty:{}", totalCreatedOrderQty);
		logger.info("fulFilledQty:{}", fulFilledQty);
		String getAllocPay = getAllocPayload;
		// if ((totalCreatedOrderQty > fulFilledQty) &&
		// !channelMethod.equalsIgnoreCase("CROSSMU")) {
		if ((totalopenQty > fulFilledQty) && !channelMethod.equalsIgnoreCase("CROSSMU")) {

			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 12, 10)).run(() -> {
				logger.info("Searching Alloc Order " + environment.getProperty("alloc_fetch") + " with payload "
						+ getAllocPay);

				Response response = null;
//				if (Config.isCloud) {
				response = SerenityRest.given().relaxedHTTPSValidation().contentType(contentType)
						.headers(orderProcessingHelper.getOpHeaders()).body(getAllocPay).when()
						.post(environment.getProperty("alloc_fetch")).andReturn();
//				} else {
//					response = SerenityRest.given().contentType(contentType).body(getAllocPay).when()
//							.post(environment.getProperty("alloc_fetch")).andReturn();
//				}
				JSONArray allocArray = parse(response.getBody().asString()).read("$.allocations", JSONArray.class);
				logger.info("allocArray size:{}", allocArray.size());
				Assert.assertNotEquals(ErrorCodes.OP_OA_ORDER_QUANITY_MISMATCH, 0, allocArray.size());
			});

		}
		Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 12, 10)).run(() -> {
			Response response = null;
//			if (Config.isCloud) {
			response = SerenityRest.given().relaxedHTTPSValidation().contentType(contentType)
					.headers(orderProcessingHelper.getOpHeaders()).body(getAllocPay).when()
					.post(environment.getProperty("alloc_fetch")).andReturn();
//			} else {
//				response = SerenityRest.given().contentType(contentType).body(getAllocPay).when()
//						.post(environment.getProperty("alloc_fetch")).andReturn();
//			}
			Assert.assertEquals(ErrorCodes.OP_OA_ALLOCATION_SERVICE_ERROR, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
			JSONArray qtyArray = JsonPath.parse(response.asString()).read(orderQtyJp);
			JSONArray fulfilledQtyArray = JsonPath.parse(response.asString()).read(fulfilledQtyJp);
			JSONArray destNumber = JsonPath.parse(response.asString()).read(destNumberJp);
			JSONArray finalDestNumber = JsonPath.parse(response.asString()).read(finalDestNumberJp);

			logger.info("Qty array and fulfilled Qty array " + qtyArray.toJSONString() + " "
					+ fulfilledQtyArray.toJSONString());
			sumOfOAOrders = 0;
			for (int i = 0; i < qtyArray.size(); i++) {
				logger.info((Integer) qtyArray.get(i) + " " + (Integer) fulfilledQtyArray.get(i));
				sumOfOAOrders += (Integer) qtyArray.get(i) - (Integer) fulfilledQtyArray.get(i);
			}
			logger.info("Sum of OA orders " + sumOfOAOrders);

			/*
			 * The assertion below is the same for now, will add in more conditions between
			 * CROSSMU and CROSSU flow.
			 */

			if (channelForFailSafe.equalsIgnoreCase("CROSSMU")) {
				// if (fulFilledQty > totalCreatedOrderQty) {
				logger.info("totalCreatedOrderQty {}", totalCreatedOrderQtyFailSafe);

				logger.info("fulFilledQty {}", fulFilledQtyForFailSafe);
				logger.info("totalCreatedOrderQty - fulFilledQty {}",
						totalCreatedOrderQtyFailSafe - fulFilledQtyForFailSafe);
				logger.info("sumOfOAOrders {}", sumOfOAOrders);
				Assert.assertEquals(ErrorCodes.OP_OA_ORDER_QUANITY_MISMATCH,
						totalCreatedOrderQtyFailSafe - fulFilledQtyForFailSafe, sumOfOAOrders);
				if ((Config.DC != DC_TYPE.SAMS) && !isReceiveCompleted) {
					Assert.assertNotEquals(ErrorCodes.OP_DEST_FINAL_DEST_SAME, (Integer) destNumber.get(0),
							(Integer) finalDestNumber.get(0));
				}
				/*
				 * If needed we can add proration of multiple destinations.
				 */
				// }
			} else {

				/*
				 * This is a validation for receiving not for OA
				 */
				/*
				 * Assert. assertTrue("fulFilledQty > (poQty + ovgQty)) for channel method : " +
				 * channelMethod, fulFilledQty <= (poQty + ovgQty));
				 */
				// logger.info("totalCreatedOrderQty {}", totalCreatedOrderQtyFailSafe);
				logger.info("totalOpenQty {}", totalopenQty);

				logger.info("fulFilledQty {}", fulFilledQtyForFailSafe);
				// logger.info("totalCreatedOrderQty - fulFilledQty {}",
				// totalCreatedOrderQtyFailSafe - fulFilledQtyForFailSafe);

				logger.info("totalOpenQty - fulFilledQty {}", totalopenQty - fulFilledQtyForFailSafe);
				logger.info("sumOfOAOrders {}", sumOfOAOrders);
				Assert.assertEquals(ErrorCodes.OP_OA_ORDER_QUANITY_MISMATCH, (totalopenQty - fulFilledQtyForFailSafe),
						sumOfOAOrders);
			}
		});
		totalopenQty = 0;
	}

	public void verifyOrdersAreCreatedInOm() throws IOException {

		final String queryOmForItemAndPO = "select sum(order_qty) from order_mgr:whse_order where po_nbr=? and item_nbr=?";

		ObjectMapper om = new ObjectMapper();
		JSONArray daChildContainers = parse(tl.get().get("testFlowData").toString())
				.read("$.testFlowData.outboundDetails..containerIds", JSONArray.class);

		String poDetailsString = parse(tl.get().get("testFlowData").toString())
				.read("$.testFlowData.poDetails", JSONArray.class).toJSONString();

		List<PoDetail> poDetailList = om.readValue(poDetailsString, new TypeReference<List<PoDetail>>() {
		});

		HashMap<String, Integer> searchCriteriaFqQtyMap = new HashMap<>();

		for (PoDetail poDetail : poDetailList) {

			Integer rdcFqCount = 0;

			List<PoLineDetail> poLineDetails = poDetail.getPoLineDetails();

			for (PoLineDetail poLineDetail : poLineDetails) {
				List<ReceivingInstruction> receivingInstructions = poLineDetail.getReceivingInstructions();

				for (ReceivingInstruction receivingInstruction : receivingInstructions) {
					List<String> childContainers = receivingInstruction.getChildContainers();

					for (String childContainer : childContainers) {
						if (((JSONArray) daChildContainers.get(0)).contains(childContainer)) {

							rdcFqCount++;

							String uniqueSearchKey = poDetail.getPoNumber() + ";" + poLineDetail.getItemNumber() + ";"
									+ poLineDetail.getVnpk();
							searchCriteriaFqQtyMap.put(uniqueSearchKey, rdcFqCount);
						}
					}
				}
			}
		}

		verifyForEachUniqueKey(searchCriteriaFqQtyMap, queryOmForItemAndPO);
		tl.get().put("searchCriteriaFqQtyMap", searchCriteriaFqQtyMap);
	}

	private void verifyForEachUniqueKey(HashMap<String, Integer> searchCriteriaFqQtyMap, String sqlQuery) {
		Set<Map.Entry<String, Integer>> entries = searchCriteriaFqQtyMap.entrySet();
		Iterator<Map.Entry<String, Integer>> searchKeysIterator = entries.iterator();

		while (searchKeysIterator.hasNext()) {

			Map.Entry<String, Integer> entry = searchKeysIterator.next();
			String key = entry.getKey();
			Integer expectedFqQty = entry.getValue();
			Integer vnpk = Integer.valueOf(key.split(";")[2]);

			Object[] sqlParamsArr = new Object[] { key.split(";")[0], key.split(";")[1] };

			List<Map<String, Object>> maps = dbUtils.selectFrom(Config.DC, sqlQuery, sqlParamsArr);
			Integer actualFqQty = Integer.valueOf(maps.get(0).get("(sum)").toString());

			Assert.assertEquals(ErrorCodes.OP_RDC_FULFILLED_CONTAINER_COUNT_MISMATCH, String.valueOf(expectedFqQty),
					String.valueOf(actualFqQty / vnpk));

		}

	}

	public void verifyOrdersAreCreatedAndFulfilledInOA() {

		final String queryOaForItemAndPO = "select sum(pre_alloc_each_qty) from order_alloc:alloc_order where po_nbr=? and item_nbr=?";

		HashMap<String, Integer> searchCriteriaFqQtyMap = (HashMap<String, Integer>) tl.get()
				.get("searchCriteriaFqQtyMap");

		verifyForEachUniqueKey(searchCriteriaFqQtyMap, queryOaForItemAndPO);

	}

	public Headers getOPHeaders() {

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header contentType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(contentType);
		return new Headers(headerList);

	}

	@Step
	public void validateDeliveryFinalizationOp() {

		try {
			String testFlowdata = (String) tl.get().get("testFlowData");
			String deliveryNumber = JsonPath.read(testFlowdata, "$.testFlowData.deliveryDetails[0].deliveryNumber");
			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 12, 20)).run(() -> {
				logger.info("Validating delivery finalisation in OP for delivery number: {}", deliveryNumber);
				List<Map<String, Object>> deliveryStatus = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_get_delivery_status"), deliveryNumber);
				short i = (short) deliveryStatus.get(0).get("prcss_status_code");
				logger.info("Delivery status in OP for delivery number:{} is: {}", deliveryNumber, i);
				Assert.assertEquals(ErrorCodes.OP_DELIVERY_NOT_FINALIZED, DEL_FINAL_OP, i);
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Delivery Finalisation check failed in OP", e);
		}

	}

	public int getTotalOverageOrdersQty(String itemNumber, String sourceNumber) {
		String testFlowData = tl.get().get("testFlowData").toString();
		List<String> orderList = JsonPath.read(testFlowData, "$..ordersDetails[?(@.isOverage==true&&@.itemNumber=='"
				+ itemNumber + "'&&@.sourceNumber=='" + sourceNumber + "')]");
		int qty = 0;
		if (!orderList.isEmpty()) {
			try {
				JSONArray ordDetailUpdateArr = jsonUtils.converyListToJsonArray(orderList);

				for (int i = 0; i < ordDetailUpdateArr.size(); i++) {
					JSONObject ordObj = (JSONObject) ordDetailUpdateArr.get(i);
					String objItemNum = ordObj.get("itemNumber").toString();
					if (objItemNum.contentEquals(itemNumber)) {
						qty = qty + Integer.parseInt(ordObj.get("quantity").toString());
					}
				}
				logger.info("Total Overage Orders qty:{}", qty);

			} catch (JsonProcessingException e) {
				logger.error(e.getMessage());
			} catch (ParseException e) {
				logger.error(e.getMessage());
			}
		}

		return qty;
	}

	@Step
	public void verifyNewExceptionRaised() {
		String testFlowData = tl.get().get("testFlowData").toString();
		List<String> orderId = JsonPath.read(testFlowData, "$..ordersDetails[*].orderId");

		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		cal.add(Calendar.DATE, -1);
		logger.info("Yesterday's date was " + dateFormat.format(cal.getTime()));
		String reqBody = (environment.getProperty("ow_exception")) + "summary?fromDate="
				+ dateFormat.format(cal.getTime()) + "&toDate=" + javautils.getCurrentDate();
		logger.info("Get the Endpoint-->{}", reqBody);

		logger.info("Get the orderId" + orderId);
		Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 3, 3)).run(() -> {

			try {
				Response response = SerenityRest.given().contentType("application/json").get(reqBody);
				Assert.assertEquals(ErrorCodes.BAJA_NEW_EXCEPTION_RAISED, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			} catch (AssertionError ex) {
				throw ex;
			}
		});
		logger.info("Orders downloaded successfully in Order services");

		Response response = SerenityRest.given().contentType("application/json").get(reqBody);

		JSONArray exceptionStatus = JsonPath.parse(response.getBody().asString()).read("$..exptnStatus",
				JSONArray.class);

		JSONArray GetOrderIDs = JsonPath.parse(response.getBody().asString()).read("$..orderIds", JSONArray.class);

		logger.info("Check the Exception status{}", exceptionStatus.toString());
		logger.info("Get the Order IDs{}", GetOrderIDs);
		for (int i = 0; i < GetOrderIDs.size(); i++) {
			if ((GetOrderIDs.get(i)).toString().contains(orderId.get(0).toString())) {
				logger.info(" Order ID is present in list of exceptions{}", orderId.get(0).toString());
			}
		}

		Assert.assertEquals(ErrorCodes.BAJA_NEW_EXCEPTION_RAISED, "New", exceptionStatus.get(0).toString());

		logger.info("Get the response-->{}", response.asString());
	}

	private void validatePickPoNumberForAllOtns(Response resp, String testFlowData) {
		String response = resp.asString();
		String pickPoNumberJsonPath = "$.listOfEntities[*].[?(@.origTrackingNbr==\"#0#\")].pickPoNbr";
		String testFlowPoNumberJsonPath = "$..ordersDetails[?(@.orderTrackingNumber==\"#0#\")].plannedPo";
		List<String> otns = JsonPath.read(response, "$.listOfEntities[*].origTrackingNbr");
		for (String otn : otns) {
			logger.info("Validating pickPoNbr for otn :{}", otn);
			pickPoNumberJsonPath = javautils.format(pickPoNumberJsonPath, otn);
			testFlowPoNumberJsonPath = javautils.format(testFlowPoNumberJsonPath, otn);
			List<String> pickPoNumberVal = JsonPath.read(response, pickPoNumberJsonPath);
			List<String> plannedPOVal = JsonPath.read(response, pickPoNumberJsonPath);
			if (pickPoNumberVal.isEmpty()) {
				logger.info("pickPoNbr Not found in the response");
				Assert.fail(ErrorCodes.OP_OM_PICK_PO_NBR_NOT_FOUND);
			} else {
				logger.info("Expected pickPoNbr :{}", plannedPOVal.get(0));
				logger.info("Actual pickPoNbr :{}", pickPoNumberVal.get(0));
				Assert.assertEquals(ErrorCodes.OP_OM_PICK_PO_NBR_MISMATCH, plannedPOVal.get(0), pickPoNumberVal.get(0));
			}
		}
	}
	
	@Step
	public void verifyOrderStatusInOM(String expectedStatus) {
		try {
			String testFlowData = tl.get().get("testFlowData").toString();
			List<String> itemNumbers = JsonPath.parse(testFlowData).read(ITEM_NUMEBR_JSON_PATH);
			List<String> uniqueItemNumbers = new ArrayList<>();
			for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
				if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
					uniqueItemNumbers.add(itemNumbers.get(itemNumber));
				}
			}
			for (String itemNum : uniqueItemNumbers) {
				List<String> orderIds = JsonPath.parse(testFlowData).read("$..ordersDetails[?(@.itemNumber=="+itemNum+")].orderId");
				Object[] orderIdsArr = new Object[orderIds.size()];
				for (int i = 0; i < orderIds.size(); i++) {
					orderIdsArr[i] = orderIds.get(i);
				}
				
				Failsafe.with(retryPolicy).run(() -> {
					List<Map<String, Object>> otOrderDetails = dbUtils.selectFrom(PRODUCT_NAME.OP,
								dbUtils.transformIntoSpringQuery(environment.getProperty(OM_GET_ORDER_STATUS), orderIds.size()), orderIdsArr);
					for (Map<String, Object> orderStatusMap : otOrderDetails) {
						logger.info("validating order status: {} for an order: {} in OM",expectedStatus,orderStatusMap.get(OM_WHSE_ORDER_ID_COLUMN));
						Assert.assertEquals(ErrorCodes.OP_OM_ORDER_STATUS_CODE_MISMATCH, expectedStatus.toLowerCase(), orderManagerStatus.getValue(Integer.parseInt(orderStatusMap.get(OM_ORDER_STATUS_CODE_COLUMN).toString())).toLowerCase());
						logger.info("validated order status: {} for an order: {} in OM",expectedStatus,orderStatusMap.get(OM_WHSE_ORDER_ID_COLUMN));
					}
				
				});
			}
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating order status in OM for manual orders",e);
		}
	}
	
	@Step
	public void verifyOrderStatusInOA(String expectedStatus) {
		try {
			String testFlowData = tl.get().get("testFlowData").toString();
			List<String> itemNumbers = JsonPath.parse(testFlowData).read(ITEM_NUMEBR_JSON_PATH);
			List<String> uniqueItemNumbers = new ArrayList<>();
			for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
				if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
					uniqueItemNumbers.add(itemNumbers.get(itemNumber));
				}
			}
			for (String itemNum : uniqueItemNumbers) {
				List<String> orderIds = JsonPath.parse(testFlowData).read("$..ordersDetails[?(@.itemNumber=="+itemNum+")].orderId");
				Object[] orderIdsArr = new Object[orderIds.size()];
				for (int i = 0; i < orderIds.size(); i++) {
					orderIdsArr[i] = orderIds.get(i);
				}
				
				Failsafe.with(retryPolicy).run(() -> {
					List<Map<String, Object>> otOrderDetails = dbUtils.selectFrom(PRODUCT_NAME.OP,
								dbUtils.transformIntoSpringQuery(environment.getProperty(OA_GET_ORDER_STATUS), orderIds.size()), orderIdsArr);
					for (Map<String, Object> orderStatusMap : otOrderDetails) {
						logger.info("validating order status: {} for an order: {} in OA",expectedStatus,orderStatusMap.get(OA_ORDER_ID_COLUMN));
						Assert.assertEquals(ErrorCodes.OP_OA_ALLOC_ORDER_STATUS_CODE_MISMATCH, expectedStatus.toLowerCase(), orderAllocStatus.getValue(Integer.parseInt(orderStatusMap.get(OA_ALLOC_ORDER_STATUS_CODE_COLUMN).toString())).toLowerCase());
						logger.info("validated order status: {} for an order: {} in OA",expectedStatus,orderStatusMap.get(OA_ORDER_ID_COLUMN));
					}
				
				});
			}
		} catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating order status in OA for manual orders",e);
		}
	}
	
	public void updateDateinDB() {

		logger.info("Updating Create Date and PO Date greater then 7 days in DB :{}");
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		JSONArray itemArray = JsonPath.read(testFlowData, "$.testFlowData.poDetails[*].poLineDetails[*].itemNumber");

		String itemNumber = (String) itemArray.get(0);
		logger.info("Item number for which date needs to be updated :{}", itemNumber);

		dbUtils.UpdateFrom(PRODUCT_NAME.OP, queries.getProperty("order_refresh_createUpdate"), itemNumber);
		dbUtils.UpdateFrom(PRODUCT_NAME.OP, queries.getProperty("order_refresh_poUpdate"), itemNumber);

		logger.info("Update successful for Create Date and PO Date for :{}", itemNumber);

	}

	public void triggerOrderRefresh() throws InterruptedException {

		logger.info("Triggering order refresh :{}");

		Response resp = SerenityRest.given().relaxedHTTPSValidation().headers(getOPHeaders()).when()
				.post(environment.getProperty("order_refresh"));

		Assert.assertEquals(ErrorCodes.OP_ORDER_REFRESH_ERROR, Constants.SUCESS_STATUS_CODE, resp.getStatusCode());

		logger.info("Order refresh successful:{}");

	}
}
