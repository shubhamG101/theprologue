package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.utilities.parsing.PropertyResolver;
import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class YardManagementPage extends PageObject {

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//a[contains(text(),'Yard Management')]")
	private WebElement yardManagementLink;

	@FindBy(xpath = "//*[@href ='retrieveYardMoveQueueDetails.action?param=Yard Management|Yard Driver Move Queue']")
	private WebElement yardManagementMoveQueueLink;

	public void clickYardManagementLink() {
		element(yardManagementLink).waitUntilVisible();
		logger.info("Clicking on Yard Managemnet Link");
		element(yardManagementLink).click();
	}

	public void clickYardManagementMoveQueueLink() {
		logger.info("Clicking on Yard Management Move Queue Link");
		element(yardManagementMoveQueueLink).click();
	}
}
