package com.walmart.supplychain.pharmacy.gdm.steps.webservices;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.TextParser;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class GDMPharmHelper {

	@Autowired
	TextParser textParser;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);

	private ArrayList<String> packData;
	private ArrayList<String> itemData;
	private Response omsResponse;
	String testFlowData;

	private static final String VENDOR_NUMBER_JSONPATH_OMS = "$..omspo..vndrnmbr";
	private static final String PO_ORDER_DATE_JSONPATH_OMS = "$..omspo.ordrdt";
	private static final String VNPK_ORDER_QTY_JSONPATH_OMS = "$..omspo..vnpkordqty";
	private static final String VENDOR_DEPT_NUMBER_JSONPATH_OMS = "$..omssuppymtterm[*].vndrdeptnmbr";
	private static final String ITEM_NUMBER_LIST_JSONPATH_OMS = "$..omspol[*].itmnbr";
	private static final String CASE_UPC_JSONPATH_MDM = "$..foundSupplyItems..orderableGTIN";
	private static final String ITEM_UPC_JSONPATH_MDM = "$..foundSupplyItems..consumableGTIN";
	private static final String ITEM_DEPT_NUMBER_JSONPATH_MDM= "$..foundSupplyItems..department.number";
	private static final String ITEM_DESCRIPTON_JSONPATH_MDM= "$..foundSupplyItems[*].description[*].textValue";
	private static final String CASE_UPC_JSONPATH_SCIS = "$..itemIdentifier.orderablePackGtin";
	private static final String ITEM_UPC_JSONPATH_SCIS = "$..itemIdentifier.consumableGtin";
	private static final String WAREHOUSE_PACK_UPC_JSONPATH_SCIS = "$..itemIdentifier.warehousePackGtin";
	private static final String ITEM_DEPT_NUMBER_JSONPATH_SCIS = "$..financials.deptNumber";
	private static final String ITEM_DESCRIPTON_JSONPATH_SCIS = "$..description.textValue";
	private static final String PO_NUMBER_JSONPATH = "$..poDetails..poNumber";
	private static final String PACK_JSONPATH="$..packNumber";

	public String preparePackData(String numOfpacksOnShipmentForEachPOLine, String receiveType) throws Exception{
		try{
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			boolean isMultiSKU = receiveType.equalsIgnoreCase("MultiSKU") && numOfpacksOnShipmentForEachPOLine.equalsIgnoreCase("0.5");
			String packNumber=null;
			String basePackData=null;
			String baseItemData=null;
			basePackData = textParser.readTextFile(FileNames.PHARMACY_PACKDATA_TEMPLATE_FILE);
			if(isMultiSKU){
				basePackData = textParser.readTextFile(FileNames.PHARMACY_MULTISKU_PACKDATA_TEMPLATE_FILE);
				baseItemData = textParser.readTextFile(FileNames.PHARMACY_MULTISKU_ITEMDATA_TEMPLATE_FILE);
			}
			int aggregatedItemQty=0;
			int expectedPOLineQty=0;

			packData = new ArrayList<>();
			itemData = new ArrayList<>();
			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSONPATH);
			if (isMultiSKU){
				packNumber = "00106001" + randonNumberGenerator(6) + randonNumberGenerator(6);
			}
			for (int poNumberCount = 0; poNumberCount < poNumberList.size(); poNumberCount++) {
				String omsUrl = environment.getProperty("oms_ep") + poNumberList.get(poNumberCount) + environment.getProperty("oms_ep_qp");
				logger.info("OMS Url:{}",omsUrl);
				Failsafe.with(retryPolicy).run(() -> {
					omsResponse = SerenityRest.given().accept("application/json").get(omsUrl);
					Assert.assertEquals(ErrorCodes.PHARMACY_UNABLE_TO_FETCH_OMS_PO, 200 , omsResponse.getStatusCode());
				});
				String omsPOResponseString=omsResponse.asString();

				List<String> poOrderDateList = JsonPath.parse(omsPOResponseString).read(PO_ORDER_DATE_JSONPATH_OMS);
				List<String> vendorNumberList = JsonPath.parse(omsPOResponseString).read(VENDOR_NUMBER_JSONPATH_OMS);
				List<String> vendorDeptNumber = JsonPath.parse(omsPOResponseString).read(VENDOR_DEPT_NUMBER_JSONPATH_OMS);

				List<String> poLineNumberList = JsonPath.parse(testFlowData).read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumberList.get(poNumberCount) + "')].poLineDetails..poLineNumber");
				if(Integer.valueOf(vendorDeptNumber.get(0))==38) {
					for (int polineCount = 0; polineCount < poLineNumberList.size(); polineCount++) {
						aggregatedItemQty=0;
						expectedPOLineQty=0;
						List<String> itemNumberList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].itemNumber");
						List<String> vnpkQtyList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].vnpk");
						List<String> whpkQtyList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].whpk");
						List<String> poQty = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].poVnpkQty");
						List<String> vendorStockIdList = JsonPath.parse(omsPOResponseString).read("$..omspol[?(@.opolnbr=='"+poLineNumberList.get(polineCount)+"')]..vndrstckidtxt");
						int derivedQuantity=0;
						String ndcN4=null;
						String ndcN2=null;
						int vnpkQty=Integer.valueOf(vnpkQtyList.get(0));
						int whpkQty=Integer.valueOf(whpkQtyList.get(0));
						derivedQuantity=getderivedQuantity(vnpkQty,whpkQty,receiveType);
						if (vendorStockIdList.size()!=0) {
							ndcN4=vendorStockIdList.get(0).replaceAll("-", "");
							ndcN2=ndcN4.substring(0, 5)+""+ndcN4.substring(6, 11);
							logger.info("ndcN4 and ndcN2 populated using Vendor stock ID field from OMS");
						}
						else {
							int randomNumber1 = randonNumberGenerator(5);
							int randomNumber2 = randonNumberGenerator(5);
							ndcN4=randomNumber1+"0"+randomNumber2;
							ndcN2=randomNumber1+""+randomNumber2;
							logger.info("ndcN4 and ndcN2 generated randomly, since Vendor stock ID field not present for the line: "+polineCount+" on OMS");
						}

						String itemMDMResponseString = getItemDetailsFromSCIS(environment.getProperty("scis_ep"), Integer.parseInt(itemNumberList.get(0)));
						List<String> vendorCaseUPCList = JsonPath.parse(itemMDMResponseString).read(CASE_UPC_JSONPATH_SCIS);//orderableGTIN or GTIN
						List<String> warehouseCaseUPCList = JsonPath.parse(itemMDMResponseString).read(ITEM_UPC_JSONPATH_SCIS);//ConsumableGTIN
						List<String> warehousePackUPCList = JsonPath.parse(itemMDMResponseString).read(WAREHOUSE_PACK_UPC_JSONPATH_SCIS);//warehousePackGTIN
						List<Integer> itemDeptNumberList = JsonPath.parse(itemMDMResponseString).read(ITEM_DEPT_NUMBER_JSONPATH_SCIS);
						List<String> itemDescriptionList = JsonPath.parse(itemMDMResponseString).read(ITEM_DESCRIPTON_JSONPATH_SCIS);

						logger.info("Executing query to get Lot ID for an item: ["+itemNumberList.get(0)+"] with query : "+environment.getProperty("select_queury_to_get_lotID_from_RDS"));
						List<Map<String, Object>> lotIDMap=dbUtils.selectFrom(Config.DC, environment.getProperty("select_queury_to_get_lotID_from_RDS"),poNumberList.get(poNumberCount), poLineNumberList.get(polineCount));
						logger.info("Excuted query to get Lot ID for an item: ["+itemNumberList.get(0)+"]");
						String lotID=(String)lotIDMap.get(0).get("drug_lot_nbr");
						String expirationDate = getDate("yyyy-MM-dd", randonNumberGenerator(3));
						
						expectedPOLineQty=Integer.valueOf(poQty.get(0));
						if(!receiveType.equalsIgnoreCase("MultiSKU")) {
							for (int packCount = 0; packCount < Integer.parseInt(numOfpacksOnShipmentForEachPOLine); packCount++) {
								packNumber = "00106001" + randonNumberGenerator(6) + randonNumberGenerator(6);
								if (receiveType.equalsIgnoreCase("UNIT")) {
									aggregatedItemQty = (int) Math.round((double) expectedPOLineQty);
								} else {
									aggregatedItemQty = (int) Math.round((double) expectedPOLineQty / (Integer.parseInt(numOfpacksOnShipmentForEachPOLine) - packCount));
								}
								logger.info("aggregatedQty PackNo" + (packCount + 1) + "=" + aggregatedItemQty);
								logger.info("PO: " + poNumberList.get(poNumberCount) + "_poline:" + polineCount + "_pack#:" + packCount);
								packData.add(javaUtils.format(basePackData, packNumber, itemNumberList.get(0), vendorCaseUPCList.get(0), warehouseCaseUPCList.get(0),
										vendorNumberList.get(0), String.valueOf(itemDeptNumberList.get(0)), itemDescriptionList.get(0), poNumberList.get(poNumberCount), poLineNumberList.get(polineCount),
										poOrderDateList.get(0), vnpkQtyList.get(0), String.valueOf(derivedQuantity), whpkQtyList.get(0), ndcN2, ndcN4, lotID.trim(), expirationDate, String.valueOf(aggregatedItemQty), warehousePackUPCList.get(0)));
								if (!receiveType.equalsIgnoreCase("UNIT")) {
									expectedPOLineQty = expectedPOLineQty - aggregatedItemQty;
								}
							}
						} else {
							aggregatedItemQty = (int) Math.round((double) expectedPOLineQty);
							logger.info("PO: " + poNumberList.get(poNumberCount) + "_poline:" + polineCount + "_pack#:" + 1);
							itemData.add(javaUtils.format(baseItemData, packNumber, itemNumberList.get(0), vendorCaseUPCList.get(0), warehouseCaseUPCList.get(0),
									vendorNumberList.get(0), String.valueOf(itemDeptNumberList.get(0)), itemDescriptionList.get(0), poNumberList.get(poNumberCount), poLineNumberList.get(polineCount),
									poOrderDateList.get(0), vnpkQtyList.get(0), String.valueOf(derivedQuantity), whpkQtyList.get(0), ndcN2, ndcN4, lotID.trim(), expirationDate, String.valueOf(aggregatedItemQty), warehousePackUPCList.get(0)));
						}
					}
					logger.info("Item Data="+itemData);
					logger.info("Prepared PALLET and PACK Data for all the POs");
				}
			}
			if(isMultiSKU){
				packData.add(javaUtils.format(basePackData, packNumber, itemData.toString()));
			}
			return packData.toString();
		}
		catch (Exception e) {
			logger.info("Something went wrong while preparing PACK level data", e);
			throw e;
		}
	}

	public String prepareShipmentData(String shipment, String packData, String loadNumber) throws Exception {
		try {
			String shipmentData="";
			String documentDate = getTime();
			List<String> totalPacksOnShipmentList=JsonPath.parse(packData).read(PACK_JSONPATH);
			String baseShipmentData=null;
			baseShipmentData = textParser.readTextFile(FileNames.PHARMACY_SHIPMENT_TEMPLATE_FILE);
			shipmentData = javaUtils.format(baseShipmentData, documentDate, String.valueOf(totalPacksOnShipmentList.size()), shipment, loadNumber,packData.toString());
			logger.info("Prepared SHIPMENT Data is : "+shipmentData);
			return shipmentData;
		}
		catch (Exception e) {
			logger.info("Something went wrong while creating Shipment data", e);
			throw e;
		}
	}

	public String getItemDetailsFromSCIS(String scisUrl, Integer itemNumber) {
		logger.info("Item SCIS Url: "+scisUrl);
		JSONObject scisBodyJson = new JSONObject();

		JSONArray itmArr = new JSONArray();
		itmArr.add(itemNumber);
		scisBodyJson.put("ids", itmArr);

		scisBodyJson.put("type", "SI");

		JSONArray responseGroupArr = new JSONArray();
		responseGroupArr.add("itemIdentifier");
		responseGroupArr.add("financials");
		responseGroupArr.add("siInfo");
		responseGroupArr.add("supplier");
		responseGroupArr.add("pack");
		responseGroupArr.add("gtins.gtin");
		responseGroupArr.add("gtins.gtinPhysical");
		responseGroupArr.add("gtins.gtinShipping");
		responseGroupArr.add("gtins.gtinStorage");
		responseGroupArr.add("gtins.isDscsaExemptionInd");
		scisBodyJson.put("responseGroup", responseGroupArr);

		scisBodyJson.put("source", "UBER");
		logger.info("SCIS json body for the item : "+scisBodyJson.toJSONString());

		Response itemResponse = SerenityRest.given().body(scisBodyJson.toJSONString())
				.headers(getItemSCISHeaders())
				.post(scisUrl);
		//				Assert.assertEquals("Unable to fetch Item details from SCIS", 200 , itemResponse.getStatusCode());
		return itemResponse.asString();
	}

	public Headers getItemSCISHeaders() {
		Header acceptType = new Header("Accept", "application/json");
		Header contentType = new Header("Content-Type", "application/json");
		Header consumerId = new Header("WM_CONSUMER.ID", "396336b2-f97e-48f5-877f-3e4dbe5dbf02");
		Header corrolationId = new Header("WM_QOS.CORRELATION_ID", "test");
		Header evn = new Header("WM_SVC.ENV", "test");
		Header name = new Header("WM_SVC.NAME", "MyLocalTest");
		Header version = new Header("WM_SVC.VERSION", "test");
		List<Header> headerList = new ArrayList<>();
		headerList.add(acceptType);
		headerList.add(contentType);
		headerList.add(consumerId);
		headerList.add(corrolationId);
		headerList.add(evn);
		headerList.add(name);
		headerList.add(version);
		return new Headers(headerList);
	}

	public Headers getCreatShipmentHeaders() {
		Header contentType = new Header("Content-Type", "application/json");
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		return new Headers(headerList);
	}

	public Headers getGetShipmentHeaders() {
		Header contentType = new Header("Content-Type", "application/vnd.shipmentsearchresponse1+json");
		Header acceptType = new Header("accept", "application/vnd.shipmentsearchresponse1+json");
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header sellerId = new Header("sellerId", environment.getProperty("sellerId"));
		logger.info("Headers\n" + contentType + ", " + countryCode + ", " + facilityNum + ", " + sellerId);
		List<Header> headerList = new ArrayList<>();
		headerList.add(acceptType);
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(sellerId);
		return new Headers(headerList);
	}

	public String getDate(String format, int plusDate) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar c = Calendar.getInstance();
		if (plusDate!=0) {
			c.add(Calendar.DATE, plusDate);
		}
		dateFormat.format(c.getTime());
		return dateFormat.format(c.getTime());
	}

	public String getTime() {
		Clock clock = Clock.system(ZoneId.of("Asia/Calcutta"));
		return clock.instant().toString();
	}

	private Random rnd = new Random();
	public int randonNumberGenerator(int noOfDigits) {
		int m = (int) Math.pow(10, (noOfDigits - 1));
		return m + rnd.nextInt(9 * m);

	}

	private int getderivedQuantity(int vnpkQty, int whpkQty, String receiveType) {
		int derivedQuantity=0;
		if (vnpkQty==whpkQty) {
			if (vnpkQty==1) {
				derivedQuantity=1;
			}
			else {
				if (receiveType.equalsIgnoreCase("PARTIAL_CASE")) {
					receiveType="CASE";
				}
				switch (receiveType.toUpperCase()) {
				case "PALLET":
					derivedQuantity=((vnpkQty*2)/whpkQty);
					break;
				case "UNIT":	
				case "CASE":
					derivedQuantity=vnpkQty/whpkQty;
					break;
				default:
					derivedQuantity=vnpkQty/whpkQty;
					break;
				}
			}

		}
		else {
			switch (receiveType.toUpperCase()) {
			case "PALLET":
				derivedQuantity=((vnpkQty*2)/whpkQty);
				break;
			case "CASE":
				derivedQuantity=vnpkQty/whpkQty;
				break;
			case "PARTIAL_CASE":
				derivedQuantity=(vnpkQty/whpkQty)-1;
				break;
			default:
				derivedQuantity=vnpkQty/whpkQty;
				break;
			}
		}

		return derivedQuantity;
	}

	public ArrayList<String> getAllGtinsFromSCIS(Integer itemNumber) {
		ArrayList<String> gtinList = new ArrayList<>();
		String itemMDMResponseString = getItemDetailsFromSCIS(environment.getProperty("scis_ep"), itemNumber);
		List<String> orderablePackGtin = JsonPath.parse(itemMDMResponseString).read(CASE_UPC_JSONPATH_SCIS);//orderableGTIN or GTIN
		List<String> warehousePackGtin = JsonPath.parse(itemMDMResponseString).read(ITEM_UPC_JSONPATH_SCIS);//ConsumableGTIN
		List<String> consumableGtin = JsonPath.parse(itemMDMResponseString).read(WAREHOUSE_PACK_UPC_JSONPATH_SCIS);//warehousePackGTIN

		gtinList.add( orderablePackGtin.get(0));
		gtinList.add( warehousePackGtin.get(0));
		gtinList.add( consumableGtin.get(0));
		return gtinList;
	}
}
