package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class DcTcDeliveryUpcPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//*[@name='deliveryNumber']")
	private WebElement delveryNumber_Textbox;
	
	@FindBy(xpath = "//*[@name='upcNumber']")
	private WebElement upcNumber_Textbox;
	
	@FindBy(xpath="//*[@class='delivery-upc-action']/button")
	private WebElement next_Button;
	
	@FindBy(xpath="//*[@class='create-ticket-header']")
	private WebElement exceptionHeader_Text;
	
	//RDC changes
	@FindBy(xpath="//*[@class='MuiBreadcrumbs-ol']")
	private WebElement statusIcon;
	
	public void submitDeliveryUPC(String delivery,String upc) {
		element(delveryNumber_Textbox).waitUntilVisible();
		element(delveryNumber_Textbox).type(delivery);
		element(upcNumber_Textbox).waitUntilVisible();
		element(upcNumber_Textbox).type(upc);
		click(exceptionHeader_Text);
		element(next_Button).waitUntilVisible();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void submitDeliveryUPCWeb(String delivery,String upc) {
		element(delveryNumber_Textbox).waitUntilVisible();
		element(delveryNumber_Textbox).type(delivery);
		element(upcNumber_Textbox).waitUntilVisible();
		element(upcNumber_Textbox).type(upc);
		click(statusIcon);
		click(next_Button);
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
