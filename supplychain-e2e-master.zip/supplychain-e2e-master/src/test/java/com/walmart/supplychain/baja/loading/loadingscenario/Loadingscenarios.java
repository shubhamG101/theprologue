package com.walmart.supplychain.baja.loading.loadingscenario;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.baja.loading.loadingstep.BajaLoadingSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class Loadingscenarios {

	@Steps
	BajaLoadingSteps loadingSteps;
	
	 @Given("^user verifies that truck down file is published to loading$")
	 public void truckDownVerification() {	 
		 loadingSteps.verifyTruckDownFile();
	 }
	
	 
	 @Then("^user uploads truck file from shortrec to generate the load id$")
	 public void uploadTruckupFile() {	 
		 loadingSteps.uploadTruckUpFile();	 
	 }

	
}
