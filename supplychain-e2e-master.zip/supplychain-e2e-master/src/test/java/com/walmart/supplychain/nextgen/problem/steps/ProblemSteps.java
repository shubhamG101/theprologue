package com.walmart.supplychain.nextgen.problem.steps;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.nextgen.problem.pages.ProblemDetailsPage;
import com.walmart.supplychain.nextgen.problem.pages.ProblemLoginPage;
import com.walmart.supplychain.nextgen.problem.pages.ProblemSearchPage;

import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;
@ContextConfiguration(classes= {SpringTestConfiguration.class})
public class ProblemSteps {
	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	
	@Autowired
	ProblemLoginPage problemLoginPage;

	@Autowired
	TextParser textParser;
	
	@Autowired
	Environment environment;
	
	@Autowired
	ProblemSearchPage problemSearchPage;
	
	@Autowired
	ProblemDetailsPage problemDetailsPage;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Autowired
	JsonUtils jsonUtil;
	
	@Step
	public void updateOMSPO(){
		
		logger.info("Adding a new PO line");
		String omsPOMessage;
		try {
			omsPOMessage = textParser.readTextFile(FileNames.OMS_PO_UPDATE);
			JSONObject jsonMessage= new JSONObject(omsPOMessage);
			Response poUpdateResponse;
			logger.info("Request body for PO Update :: {}",jsonMessage);
			poUpdateResponse = SerenityRest.given().body(jsonMessage.toString())
					.when().put(MessageFormat.format(environment.getProperty("oms_update_po_ep"),jsonMessage.get("uuid")));
			poUpdateResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
			logger.info("response after PO update :: {}",poUpdateResponse.asString());
		} catch (JSONException|URISyntaxException|IOException e) {
			throw new AutomationFailure("Something went wrong Adding a new PO Line", e);
		} 
	}
	
	@Step
	public void provideResolution() {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONArray poNumberArray = JsonPath.read(testData,"$.testFlowData.deliveryDetails..poNumbers[*]");
		String poNumber= (String) poNumberArray.get(0);
		String problemResolutionMessage;
		try {
			problemResolutionMessage = textParser.readTextFile(FileNames.PROBLEM_RESOLUTION);
			JSONObject jsonMessage;
			jsonMessage = new JSONObject(problemResolutionMessage);
			jsonMessage.getJSONArray("problemResolutions").getJSONObject(0).put("poNbr", poNumber);
			jsonMessage.getJSONArray("problemResolutions").getJSONObject(0).put("resolutionQty",environment.getProperty("problem_qty"));
			String resolution="ADDED_A_PO_LINE";
			jsonMessage.getJSONArray("problemResolutions").getJSONObject(0).put("problemResolutionType",resolution);
			tl.get().put("problemResolutionType",resolution);
			logger.info("Request body for providing Resolution :: {}",jsonMessage);
			String problemId=(String) tl.get().get("problemId");
			logger.info("Problem Id for Providing Resolution is :: {}",problemId);
			Response resolutionResponse = SerenityRest.given().contentType("application/json").relaxedHTTPSValidation().headers(getProblemHeaders()).body(jsonMessage.toString()).when()
					.put(MessageFormat.format(environment.getProperty("problem_provide_resolution"),
							problemId));
			Assert.assertEquals(ErrorCodes.PROBLEM_RESOLUTION_NOT_UPDATED,Constants.SUCESS_STATUS_CODE,resolutionResponse.getStatusCode());
		} catch (URISyntaxException |JSONException|IOException e) {
			throw new AutomationFailure("Unable to provide the Resolution", e);
		}
	}

	public void reportOVGProblem() {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONArray deliveryNumberArray = JsonPath.read(testData,"$..deliveryDetails..deliveryNumber");
		String deliveryNumber= (String) deliveryNumberArray.get(0);
		String problemResolutionMessage;
		try {
			problemResolutionMessage = textParser.readTextFile(FileNames.PROBLEM_CREATION);
			JSONObject jsonMessage;
			jsonMessage = new JSONObject(problemResolutionMessage);
			jsonMessage.put("deliveryId", deliveryNumber);
			jsonMessage.put("problemQty",environment.getProperty("problem_qty"));
			logger.info("Request body for Creation of problem :: {}",jsonMessage);
			Response reportResponse = SerenityRest.given().contentType("application/json").relaxedHTTPSValidation().headers(getProblemHeaders()).body(jsonMessage.toString()).when()
					.post(environment.getProperty("problem_creation"));
			Assert.assertEquals(ErrorCodes.PROBLEM_STATUS_CODE_MISMATCH,Constants.SUCESS_STATUS_CODE,reportResponse.getStatusCode());
			logger.info("Response of Problem creation :: {}",reportResponse.asString());
			JSONArray problemIdArray=JsonPath.read(reportResponse.asString(),"$..problemTrackingId");
			String problemId=(String) problemIdArray.get(0);
			logger.info("OVG Problem ID is :: {}",problemId);
			JSONArray problemStatusArray=JsonPath.read(reportResponse.asString(),"$..problemStatus");
			String problemStatus=(String) problemStatusArray.get(0);
			logger.info("Actual OVG Problem Status is :: {}",problemStatus);
			Assert.assertEquals(ErrorCodes.PROBLEM_STATUS_CODE_MISMATCH,"ASSIGNED",problemStatus);
			tl.get().put("problemId",problemId);
		} catch (URISyntaxException |JSONException|IOException e) {
			throw new AutomationFailure("Unable to Report a Problem", e);
		}
	}

	public void verifyProblemStatusAndResolution() {
		Response problemResponse = SerenityRest.given().accept(ContentType.JSON).relaxedHTTPSValidation().headers(getProblemHeaders()).when()
				.get(MessageFormat.format(environment.getProperty("problem_details"),
						(String) tl.get().get("problemId")));
		logger.info("ProblemDetails Status Code is :: {}",problemResponse.getStatusCode());
		logger.info("Problem Detils response :: {}",problemResponse.asString());
		String problemStatus=JsonPath.read(problemResponse.asString(),"$.problemStatus");
		logger.info("Actual OVG Problem Status is :: {}",problemStatus);
		Assert.assertEquals(ErrorCodes.PROBLEM_STATUS_CODE_MISMATCH,"ANSWERED_AND_READY_TO_RECEIVE",problemStatus);
		JSONArray problemResolutionArray=JsonPath.read(problemResponse.asString(),"$.problemResolutions[*].problemResolutionType");
		String problemResolution=(String) problemResolutionArray.get(0);
		logger.info("Actual problemResolution is :: {}",problemResolution);
		Assert.assertEquals(ErrorCodes.PROBLEM_RESOLUTION_MISMATCH,(String) tl.get().get("problemResolutionType"),problemResolution);
	}
	
	@Step
	public void revertPOChanges() {
		String omsPOMessage;
		try {
			omsPOMessage = textParser.readTextFile(FileNames.OMS_PO);
			JSONObject jsonMessage= new JSONObject(omsPOMessage);
			Response poResponse;
			logger.info("Request body for PO :: {}",jsonMessage);
			String url=MessageFormat.format(environment.getProperty("oms_update_po_ep"),jsonMessage.get("uuid"));
			logger.info("Request url for revert PO :: {}",url);
			poResponse = SerenityRest.given().body(jsonMessage.toString())
					.when().put(url);
			poResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
			logger.info("response after PO :: {}",poResponse.asString());
		} catch (JSONException|URISyntaxException|IOException e) {
			throw new AutomationFailure("Something went wrong reverting the PO Changes", e);
		} 
	}
	public Headers getProblemHeaders() {

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		return new Headers(headerList);

	}
}
