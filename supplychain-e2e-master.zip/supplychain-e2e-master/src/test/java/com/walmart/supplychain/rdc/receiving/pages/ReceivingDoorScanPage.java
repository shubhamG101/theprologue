package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class ReceivingDoorScanPage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_del_door']")
	private WebElement doorScan;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_search_delivery']")
	private WebElement doorSearchBtn;

	@FindBy(xpath = ".//*[@content-desc='Open navigation drawer']")
	private WebElement menuBtn;
	
	@FindBy(xpath = ".//*[@text='Yes, re-open']")
	private WebElement confirmReOpen;
	
	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_location_tag']")
	private WebElement reOpenDoorInput;
	
	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_continue']")
	private WebElement reOpenContinue;
	
	// @FindBy(xpath =
	// ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/design_menu_item_text']")
	// private WebElement dockTagRecvBtn;

	@FindBy(xpath = ".//*[@text='Dock Tag Receiving']")
	private WebElement dockTagRecvBtn;

	@FindBy(xpath = ".//*[@text='Label Correction']")
	private WebElement palletCorrectionBtn;

	public void scanDoor(String doorNum) {

		element(doorScan).waitUntilVisible();
		element(doorScan).type(doorNum);

		element(doorSearchBtn).waitUntilVisible();
		element(doorSearchBtn).click();
		logger.info("Door Scan is successful");
	}
	
	public void confirmReOpen(String doorNum) {

		element(confirmReOpen).waitUntilVisible();
		element(confirmReOpen).click();

		element(reOpenDoorInput).waitUntilVisible();
		element(reOpenDoorInput).type(doorNum);
		
		element(reOpenContinue).waitUntilVisible();
		element(reOpenContinue).click();
		logger.info("Delivery re-open is successful");
	}

	public void navigateToDockTagScreen() {
		try {
			element(menuBtn).waitUntilVisible();
			element(menuBtn).click();
			Thread.sleep(2000);
			element(dockTagRecvBtn).waitUntilVisible();
			element(dockTagRecvBtn).click();

			logger.info("Navigated to DockTag screen");
		} catch (Exception e) {

		}
	}

	public void navigateToPalletCorrectionScreen() {
		try {
			element(menuBtn).waitUntilVisible();
			element(menuBtn).click();
			Thread.sleep(2000);
			element(palletCorrectionBtn).waitUntilVisible();
			element(palletCorrectionBtn).click();

			logger.info("Navigated to DockTag screen");
		} catch (Exception e) {

		}
	}

}
