package com.walmart.supplychain.acc.sorter.steps.webservices;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;

import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class SorterHelper {
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	Logger logger = LoggerFactory.getLogger(SorterHelper.class);

	public  String getLPNtoRDCMapResponse(List<String> lpnList)
	{
		String lpnRDCMapPostURL = environment.getProperty("lpn_to_rdc_map_url");
		Response postLPNRDCMapRespose = SerenityRest.given().body(lpnList.toString()).contentType("application/json").when().post(lpnRDCMapPostURL);
		Assert.assertEquals(ErrorCodes.SORTER_GET_LPN_RESPONSE,Constants.SUCESS_STATUS_CODE, postLPNRDCMapRespose.getStatusCode());
		String postLPNRDCMapResposeString=postLPNRDCMapRespose.asString();
		logger.info("LPN to RDC mapping :: got response {}",postLPNRDCMapResposeString);
		return postLPNRDCMapResposeString;
	}






}
