package com.walmart.supplychain.nextgen.loading.steps.db;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.db.QueryHelper;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import net.minidev.json.JSONArray;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class LoadingDBSteps {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	Environment environment;
	@Autowired
	DbUtils dbUtils;
	JsonUtils jsonUtils = new JsonUtils();
	QueryHelper queryHelper = new QueryHelper();
	Logger logger = LogManager.getLogger(this.getClass());

	public void cleanUpLoading(List<String> loadIds) {
		logger.info("List of loads to be cleared:{}", loadIds);
		try {

			for (String loadId : loadIds) {

				Object[] loadArr = new Object[1];
				loadArr[0] = loadId;
				List<Map<String, Object>> shippingctrIds = dbUtils.selectFrom(Config.DC,environment.getProperty("select_shipping_container"), loadArr[0]);
				Object[] shipCtrArr = new Object[shippingctrIds.size()];
				for (int rowIndex=0;rowIndex<shippingctrIds.size();rowIndex++) {
					shipCtrArr[rowIndex] = shippingctrIds.get(rowIndex).get("shipping_container_id").toString();
					logger.info("Loading deletion "+shipCtrArr[rowIndex].toString());
				}

				Object[] sealNumArr = new Object[1];
				int sealNo = 0;
				List<Map<String, Object>> sealNos = dbUtils.selectFrom(Config.DC,environment.getProperty("select_load_seal"), loadArr[0]);
				if(!sealNos.isEmpty()) {
				sealNo = (int) sealNos.get(0).get("seal_id");
				sealNumArr[0] = sealNo;
				}
				int deleteCount;
				if(shipCtrArr.length>0) {
				dbUtils.deleteFrom(Config.DC,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_container_activity"),
						shippingctrIds.size()), shipCtrArr);
				}
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_container_activity_by_load"), loadArr[0]);
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load_contaier_map"), loadArr[0]);
				if(shipCtrArr.length>0) {
				dbUtils.deleteFrom(Config.DC,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_container_shipment"),
						shippingctrIds.size()), shipCtrArr);
				dbUtils.deleteFrom(Config.DC,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_container_shipment_parent"),
						shippingctrIds.size()), shipCtrArr);
				dbUtils.deleteFrom(Config.DC,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_shipping_container"),
						shippingctrIds.size()), shipCtrArr);
				}
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load_plan"), loadArr[0]);
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_routing_nbr"), loadArr[0]);
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load_seal"), loadArr[0]);
				if(sealNumArr.length>0)
					dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_seal"), sealNumArr[0]);
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load_door"), loadArr[0]);
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load_activity"), loadArr[0]);
				dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load_shipment"), loadArr[0]);
				deleteCount = dbUtils.deleteFrom(Config.DC,environment.getProperty("delete_load"), loadArr[0]);
				logger.info("Deleted {} records from loading", deleteCount);
			}

		} catch (Exception e) {
			throw new AutomationFailure("Unable to clear the loads for the door", e);

		}
	}

	public List<String> getLoadIdsForDoor(String door) {
		
		List<Map<String, Object>> loadingDoors;
		Object[] doorArr = new Object[1];
		doorArr[0] = door;
		logger.info("List of loads query for door:{} with status InUse:{} ",door,environment.getProperty("select_load_door"));
		loadingDoors = dbUtils.selectFrom(Config.DC,environment.getProperty("select_load_door"), doorArr[0]);
		
		List<String> loadList = new ArrayList<>();
		
		for (Map map : loadingDoors) {

			loadList.add(map.get("load_id").toString());
		}

		logger.info("loadList to be deleted:" + loadList);
		return loadList;
	}

	public String getDoorNumberForOldestLoad(List<String> doors) {
		
		String doorNumber = "";
		Object[] doorArr = new Object[doors.size()];
		for (int i = 0; i < doors.size(); i++) {

			doorArr[i] = doors.get(i);
		}
		List<Map<String, Object>> doorIds;
		doorIds = dbUtils.selectFrom(Config.DC,dbUtils.transformIntoSpringQuery(environment.getProperty("list_of_loads_door"),doors.size()), doorArr);
		doorNumber = (String) doorIds.get(0).get("wm_location_name");
		return doorNumber;
	}

	public void cleanUpLoadingUsingDoorNumber() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray outboundArray = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*]");
		List<OutboundDetail> outboundList = null;
		try {
			outboundList = (List<OutboundDetail>) jsonUtils.getPojoListfromPath(outboundArray.toJSONString(),
					OutboundDetail.class);
		} catch (IOException e) {
			
			logger.error(e.getMessage());
		}
		for (OutboundDetail outbound : outboundList) {
			logger.info("Cleanup the load for outbound door:{}", outbound.getOutboundDoorNumber());
			cleanUpLoading(getLoadIdsForDoor(outbound.getOutboundDoorNumber()));

		}
	}
	
	public void cleanUpLoadingUsingDoorNumber(List<String> doors) {
		for(String door:doors) {
			logger.info("Clean Up data for Door:: {}",door);
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_delete_trailer_tracking"), door);
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_delete_load_activity"), door);
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_delete_load_activity_task"), door);
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_delete_shipping_container"), door);
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_delete_load_shipment"), door);
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_delete_load"), door);
			
		}
	}

}
