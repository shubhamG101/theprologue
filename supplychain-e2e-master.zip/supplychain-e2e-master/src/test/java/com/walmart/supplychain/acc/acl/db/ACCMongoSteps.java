package com.walmart.supplychain.acc.acl.db;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import net.serenitybdd.core.pages.PageObject;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ACCMongoSteps extends PageObject {
	private String testFlowData;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	// @Qualifier(value="mongoTest")
	MongoUtil mongoUtil;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	Environment environment;

	Logger logger = LogManager.getLogger(this.getClass());

	public Map getLabelsForDelivery(String schema, String collection, String deliveryNumber, String poNbr,
			String itmNbr) {
		Map labelsMap = new HashMap();
		try {
			MongoClient mongoClient = mongoUtil.createConnection();
			MongoDatabase database = mongoClient.getDatabase(schema);
			MongoCollection<Document> table = database.getCollection(collection);
			Document group = new Document("$match",
					new Document("deliveryNumber", deliveryNumber).append("status", "PROCESSED")
							.append("deliveryDocument.purchaseReferenceNumber", poNbr)
							.append("itemNumber", Integer.parseInt(itmNbr)));
			List<Document> pipeline = Arrays.asList(group);
			logger.info("get labels from receiving: query-" + pipeline);
			AggregateIterable<Document> output = table.aggregate(pipeline);

			for (Document doc : output) {
				Document a = doc;
				labelsMap.put("lpnLabels", a.get("lpnList"));
				labelsMap.put("ovgLabels", a.get("overageLpnList"));
				labelsMap.put("exceptionLabels", a.get("exceptionLpnList"));
			}
			mongoUtil.closeConnection(mongoClient);
			logger.info("processsed lpns for the delivery,item and po number from the DB"+labelsMap);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate labels in deliverydocumentsbylpns collection", e);
		}
		return labelsMap;

	}

	public String getProcessedLabelsForDelivery(String schema, String collection, String deliveryNumber, String poNbr,
			String itmNbr) {
		
		String status=null;
		try {
			MongoClient mongoClient = mongoUtil.createConnection();
			MongoDatabase database = mongoClient.getDatabase(schema);
			MongoCollection<Document> table = database.getCollection(collection);
			Document group = new Document("$match",
					new Document("deliveryNumber", deliveryNumber)
							.append("deliveryDocument.purchaseReferenceNumber", poNbr)
							.append("itemNumber", Integer.parseInt(itmNbr)));
			List<Document> pipeline = Arrays.asList(group);
			logger.info("get labels from receiving query" + pipeline);
			AggregateIterable<Document> output = table.aggregate(pipeline);

			for (Document doc : output) {
				Document a = doc;
				status=(String) a.get("status");
			}
			mongoUtil.closeConnection(mongoClient);
			logger.info("Checking if labels are processed ......");

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate labels in deliverydocumentsbylpns collection", e);
		}
		return status;

	}

	public List<String> getProblemReceivedCntrs(String schema, String collection, String deliveryNumber) {
		List<String> cntrList=new ArrayList<String>();
		try {
			MongoClient mongoClient = mongoUtil.createConnection();
			MongoDatabase database = mongoClient.getDatabase(schema);
			MongoCollection<Document> table = database.getCollection(collection);
			Document group = new Document("$match",
					new Document("deliveryNumber", deliveryNumber)
							.append("location", "OF2")
							.append("containerType", "Vendor Pack"));
			List<Document> pipeline = Arrays.asList(group);
			logger.info("get containers after problem receiving" + pipeline);
			AggregateIterable<Document> output = table.aggregate(pipeline);

			for (Document doc : output) {
				Document a = doc;
				cntrList.add(a.get("trackingId").toString());
			}
			mongoUtil.closeConnection(mongoClient);

		} catch (Exception e) {
			throw new AutomationFailure("Failed to get containers from the receiving after problem containers receiving", e);
		}
		return cntrList;
}
}