package com.walmart.supplychain.nextgen.fixit;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;
import io.strati.libs.commons.io.FileUtils;
import net.thucydides.core.annotations.findby.By;

public class AppiumHelper {
	
	public static AndroidDriver<AndroidElement> webdriverForPage=null;
	
	public static Map<String,String> mapTestData=null;
	
	public static List<String> listTestData=null;
	
	public static List<String> getListTestData() {
		return listTestData;
	}

	public static void setListTestData(List<String> listTestData) {
		AppiumHelper.listTestData = listTestData;
	}

	public static Map<String, String> getmapTestData() {
		return mapTestData;
	}

	public static void setmapTestData(Map<String, String> map) {
		AppiumHelper.mapTestData = map;
	}

	public static AndroidDriver<AndroidElement> getWebdriverForPage() {
		return webdriverForPage;
	}

	public static void setWebdriverForPage(AndroidDriver<AndroidElement> webdriverForPage) {
		AppiumHelper.webdriverForPage = webdriverForPage;
	}
	
	public static void inputString(MobileElement mobileElement, String stringToBeEntered, MobileDriver driver) {
		FluentWaitForElement(driver, mobileElement);
		mobileElement.sendKeys(stringToBeEntered);
		driver.hideKeyboard();
	}

	public static void clickElement(MobileElement mobileElement, MobileDriver driver) {
		FluentWaitForElement(driver, mobileElement);
		mobileElement.click();
	}

	public static String getAttribute(MobileElement mobileElement, String attr, MobileDriver driver) {
		FluentWaitForElement(driver, mobileElement);
		return mobileElement.getAttribute(attr);
	}

	public static void FluentWaitForElement(WebDriver driver, WebElement element) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(200, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public static void FluentWaitUntilVisible(WebDriver driver, WebElement element) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(200, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public static void scrollToElementInMObile(String str,AndroidDriver driver) {
		//(((AndroidDriver) driver)).findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+str+"\").instance(0))");//.click();
		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+str+"\").instance(0))");//.click();
	}
	
	public static String takeScreenShot(WebDriver driver) {
		String filePath=null;
		try {
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			String timeStamp = new SimpleDateFormat("yyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			filePath="./target/"+timeStamp+".png";
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return filePath;
	}
	
	public static void scan(AndroidDriver androidDriver,String para1) {
		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
				"com.walmart.move.nim.fixit.mobile", "-e",
				"com.motorolasolutions.emdk.datawedge.data_string " + para1, "-e",
				"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN13");
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
		try {
			Thread.sleep(3000);
			androidDriver.executeScript("mobile: shell", scanEvent);
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void ScrollDown(AndroidDriver driver) {
		new TouchAction(driver).press(PointOption.point(550, 640))
		.waitAction().moveTo(PointOption.point(550, 60)).release().perform();

	}

	public static void PullToRefresh(AndroidDriver driver) {
		new TouchAction(driver).press(PointOption.point(550, 500))
				.waitAction().moveTo(PointOption.point(550, 1000)).release().perform();

	}
	
	public static void selectFromDropDown(String strToSelect,List<WebElement> listOfElements) {
		List<WebElement> listOfWebElements = listOfElements;
		for (WebElement webElement : listOfWebElements) {
			String str=webElement.getText().trim();
			if (webElement.getText().trim().equalsIgnoreCase(strToSelect.trim())) {
				webElement.click();
				break;
			}
		}
	}
}
