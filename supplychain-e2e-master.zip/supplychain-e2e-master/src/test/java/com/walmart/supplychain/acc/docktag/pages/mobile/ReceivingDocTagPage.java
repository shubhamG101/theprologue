package com.walmart.supplychain.acc.docktag.pages.mobile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.receiving.pages.mobile.ReceivingPage;

import net.thucydides.core.pages.PageObject;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class ReceivingDocTagPage extends SerenityHelper {
	@Autowired
	Environment endpoint;

	@Autowired
	ReceivingPage receivingPage;
	
	//private WebDriver driver;
	
	Logger logger = LogManager.getLogger(this.getClass());

	@FindBy(xpath = "//div[contains(text(),'New floor line pallet')]")
	private WebElement floorLanePage;
	
	@FindBy(xpath="//button[span[span[contains(text(),'pallet complete')]]]")
	private WebElement palletCompleteButton;
	
	@FindBy(xpath="//button[@aria-label='ArrowBack']/span/*[name()='svg']")
	private WebElement docTagReceiveCloseButton;
	
	@FindBy(xpath = "//div[div[text()='Receiving']]/button")
	private WebElement receivingMenu;
	
	@FindBy(xpath = "//div[text()='Floor Line Receiving']")
	private WebElement floorLineTab;
	
	@FindBy(xpath = "//div[text()='Scan a door to begin receiving']")
	private WebElement scanDoorPannel;
	
	@FindBy(xpath = "//div[contains(text(),'Scan a Floor Line ACL')]")
	private WebElement scanFloorLanePannel;
	
	@FindBy(xpath = "//div[contains(text(),'Scan a dock tag')]")
	private WebElement scanDockTagPannel;
	
	@FindBy(xpath = "//div[contains(text(),'Scan PBYL Location')]")
	private WebElement scanPBYLLocationPannel;
	
	@FindBy(xpath = "//div[contains(text(),'Scan a PBYL dock tag')]")
	private WebElement scanPBYLDockTagPannel;
	
	@FindBy(xpath="//span[contains(text(),'Complete Dock Tag')]")
	private WebElement completeDockTagButton;
	
	@FindBy(xpath = "//div[div[h2[text()='Complete Dock Tag']]]//span[text()='COMPLETE']")
	private WebElement confirmationCompleteButton;

	@FindBy(xpath = "//div[div[h2[text()='Complete Dock Tag']]]//span[text()='CANCEL']")
	private WebElement confirmationCancelButton;
	
	@FindBy(xpath="//span[contains(text(),'OK')]")
	private WebElement dockTagDialogueMessage;
	
	@FindBy(xpath = "//div[contains(text(),'Dock Tag Not Found')]")
	private WebElement dockTagDialogueText;

	@FindBy(xpath = "//div[contains(text(),'Dock Tag Already Received')]")
	private WebElement dockTagCompleteDialogueText;
	
	String palletCompletedMssgXathValue="//div[text()='1 Label Sent to Printer']";
	String dockTagScanSuccessPageXpathValue="//div[contains(text(),'Load all the freight onto the ACL')]";
	
	public void clickOnDialogueInvalidDockTag() {
		element(dockTagDialogueText).waitUntilVisible();
		element(dockTagDialogueMessage).waitUntilVisible();
		element(dockTagDialogueMessage).waitUntilClickable();
		element(dockTagDialogueMessage).click();
	}
	
	public void clickOnPalletCompleteButton() {
		//have to enable to the text on docktag create page
//		element(floorLanePage).waitUntilVisible();
//		element(floorLanePage).waitUntilEnabled();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(palletCompleteButton).waitUntilVisible();
		element(palletCompleteButton).waitUntilEnabled();
		element(palletCompleteButton).click();
	}
	
	public boolean isPalletCompletedMssgDisplayed() {	
		return isElementVisible(palletCompletedMssgXathValue);
	}
	
	public void clickOnDocTagReceiveCloseButton() {
		element(palletCompletedMssgXathValue).waitUntilVisible();
		element(palletCompletedMssgXathValue).waitUntilClickable();
		element(docTagReceiveCloseButton).waitUntilVisible();
		element(docTagReceiveCloseButton).waitUntilClickable();
		element(docTagReceiveCloseButton).click();
	}
	public void checkDoorScanPage() {
		WebDriver driver = getDriverInstance();
		logger.info("Launching the web URL for receiving "+endpoint.getProperty("receivingapp_webui_url"));
		driver.get(endpoint.getProperty("receivingapp_webui_url"));	
		element(scanDoorPannel).waitUntilVisible();
	}
	
	public void clickOnReceiveMenu() {
		element(receivingMenu).waitUntilVisible();
		element(receivingMenu).waitUntilClickable();
		element(receivingMenu).click();
	}
	
	public void clickOnFloorLineTab() {
		element(floorLineTab).waitUntilVisible();
		element(floorLineTab).waitUntilClickable();
		element(floorLineTab).click();
	}
	
	public void scanFloorLine(String floorLane) {
		WebDriver driver=getDriverInstance();
		element(scanFloorLanePannel).waitUntilVisible();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + floorLane
				+ "'}; document.dispatchEvent(door)");
	}
	
	public void scanPBYLLocation(String location) {
		WebDriver driver=getDriverInstance();
		element(scanPBYLLocationPannel).waitUntilVisible();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + location
				+ "'}; document.dispatchEvent(door)");
	}
	
	public void scanPBYLDockTag(String dockTag) {
		WebDriver driver=getDriverInstance();
		element(scanPBYLDockTagPannel).waitUntilVisible();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + dockTag
				+ "'}; document.dispatchEvent(door)");
	}
	
	public void scanDockTag(String dockTag) {
		WebDriver driver=getDriverInstance();
		element(scanDockTagPannel).waitUntilVisible();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + dockTag
				+ "'}; document.dispatchEvent(door)");
	}
	
	public void clickOnCompleteDockTagButton() {
		element(completeDockTagButton).waitUntilVisible();
		element(completeDockTagButton).waitUntilClickable();
		element(completeDockTagButton).click();
	}
		
	public void clickOnConfirmationCompleteButton() {
		element(confirmationCompleteButton).waitUntilVisible();
		element(confirmationCompleteButton).waitUntilClickable();
		element(confirmationCompleteButton).click();
	}
	
	public void clickOnConfirmationCancelButton() {
		element(confirmationCancelButton).waitUntilVisible();
		element(confirmationCancelButton).waitUntilClickable();
		element(confirmationCancelButton).click();
	}
	
	public boolean isPalletDockTagScanSuccessful() {	
		return isElementVisible(dockTagScanSuccessPageXpathValue);
	}
	
	
	public boolean isElementVisible(String fieldName) {
		try {
			WebDriver driver = getDriverInstance();
			WebDriverWait wait=new WebDriverWait(driver, 6);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(fieldName)));
			return true;
		}catch(TimeoutException ex) {
			return false;
		}
	}

	public void clickOnOkButton() {
		element(dockTagCompleteDialogueText).waitUntilVisible();
		element(dockTagDialogueMessage).waitUntilClickable();
		element(dockTagDialogueMessage).click();
	}

}
