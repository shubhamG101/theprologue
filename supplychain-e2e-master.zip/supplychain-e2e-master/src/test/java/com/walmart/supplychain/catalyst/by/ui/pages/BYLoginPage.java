package com.walmart.supplychain.catalyst.by.ui.pages;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.ibm.disthub2.impl.util.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.framework.utilities.selenium.UiActionsHelper;

import net.jodah.failsafe.RetryPolicy;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYLoginPage extends SerenityHelper {
	
	
	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;
	
	
	@Autowired
	Environment environment;
	
	@Autowired
	UiActionsHelper uiActionsHelper;
	
	
	
	public WebElement getFieldById(String id) {
		return driver.findElement(By.id(id));
	}
	
	public WebElement getButtonByText(String btnText) {
		return driver.findElement(By.xpath("//a[normalize-space()='"+btnText+"']"));
	}
	
	
	
	
	
	
	
	
	// ##################################  Actions on page elements   ####################################################
	
	
	public void getUrl(String url) {
		driver = getDriverInstance();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(url);
	}
	
	public void loginIntoBY() throws InterruptedException {
		
		//Login steps for PingFED Login page 	
/*		element(getFieldById("username1")).waitUntilVisible();
		element(getFieldById("username1")).sendKeys(environment.getProperty("userName"));		
		element(getFieldById("password")).waitUntilVisible();
		element(getFieldById("password")).sendKeys(environment.getProperty("receiving_p"));
		element(getButtonByText("SIGN IN")).waitUntilVisible();
		element(getButtonByText("SIGN IN")).click();
		*/
		
		//Login steps used for BY UI Login Page 
		element(getFieldById("loginUserName")).waitUntilVisible();
		element(getFieldById("loginUserName")).sendKeys(environment.getProperty("userName"));		
		element(getFieldById("loginPassword")).waitUntilVisible();
		element(getFieldById("loginPassword")).sendKeys(environment.getProperty("receiving_p"));		
		element(getFieldById("loginButton")).waitUntilVisible();
		element(getFieldById("loginButton")).click();	
		logger.info("Clicked on sign in button--->");
		
	}

			
}
