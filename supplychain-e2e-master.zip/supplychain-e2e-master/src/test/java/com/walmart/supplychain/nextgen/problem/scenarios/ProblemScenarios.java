package com.walmart.supplychain.nextgen.problem.scenarios;

import com.walmart.supplychain.nextgen.problem.steps.ProblemSteps;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class ProblemScenarios {
	
	@Steps
	ProblemSteps problemSteps;
	
	@Then("^user reports OVG problem and verify the status as Assigned$")
	public void reportOVGProblem() {
		problemSteps.reportOVGProblem();
	}
	
	@Then("^user verifies the problem status as ANSWERED_AND_READY_TO_RECEIVE and verify the resolution$")
	public void verifyProblemStatusAndResolution() {
		problemSteps.verifyProblemStatusAndResolution();
	}
	
	@Then("^user updates OMS PO$")
	public void updateOMSPO() {
		//problemSteps.updateOMSPO();
	}
	
	@Then("^user provides the manual resolution for the problem$")
	public void provideManualResolution() {
		problemSteps.provideResolution();
	}
	
	
}
