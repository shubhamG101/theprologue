package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.walmart.framework.utilities.jms.DC_TYPE;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import net.thucydides.core.pages.components.FileToUpload;
import spring.SpringTestConfiguration;

public class DcTcExceptionDetailPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//*[@id='exception-quantity']")
	private WebElement exceptionQty_Textbox;
	
	@FindBy(xpath = "//*[@id='received-vnpk']")
	private WebElement receivedVNPK_Textbox;
	
	@FindBy(xpath = "//*[@id='received-whpk']")
	private WebElement receivedWHPK_Textbox;
	
	@FindBy(xpath = "//*[@id='shipped-To']")
	private WebElement shippedTo_Textbox;
	
	@FindBy(xpath = "//*[@name='caseCount']")
	private WebElement casesPerPallet_Textbox;
	
	@FindBy(xpath = "//*[@id='comment']")
	private WebElement comments_Textbox;
	
	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement submit_Button;
	
	@FindBy(xpath = "//*[@name='destinationDC']")
	private WebElement destination_Textbox;
	
	@FindBy(xpath = "//*[@placeholder='PO Number on Case']")
	private WebElement poNumber_Textbox;
	
	@FindBy(xpath = "//*[@class='form-label']//a")
	private WebElement changePrinter_link;
	
	@FindBy(xpath = "//*[@class='rt-tbody']/div[2]//*[@class='rt-td']")
	private WebElement printerCheckbox_Radiobutton;
	
	@FindBy(xpath = "//*[text()='PROCEED']")
	private WebElement proceed_Button;
	
	//RDC changes
	@FindBy(xpath = "//*[@id='0']")
	private WebElement pallet1_Textbox;
	
	@FindBy(xpath = "//*[@id='1']")
	private WebElement pallet2_Textbox;
	
	@FindBy(xpath = "//*[@class='add-pallet']")
	private WebElement addPallet_Button;
	
	//damage
	@FindBy(xpath = "//*[@id='reclaims']")
	private WebElement reclaims_Textbox;
	
	@FindBy(xpath = "//*[@id='destroy']")
	private WebElement destory_Textbox;
	
	@FindBy(xpath = "//*[@id='sentBackToCarrier']")
	private WebElement sendBackToCarrier_Textbox;

	@FindBy(xpath = "//*[@value='Wet']")
	private WebElement Wet;

	@FindBy(xpath = "//*[@value='Concealed']")
	private WebElement Concealed;
	
	@FindBy(xpath = "//*[@value='Physical Damage']")
	private WebElement physical_Button;
	
	@FindBy(xpath = "//*[@class='form']/input")
	private WebElement upload_Button;
	
	@FindBy(xpath = "//*[text()='Yes']")
	private WebElement yes_Button;

	//wfs and imports
	@FindBy(xpath = "//*[@id='exceptionType']")
	private WebElement exceptionType;

	@FindBy(xpath = "//*[@id='exceptionQty']")
	private WebElement exceptionQty;

	@FindBy(xpath = "//*[@id='number']")
	private WebElement deliveryNumber;

	@FindBy(xpath = "//*[@id='poNumber']")
	private WebElement poNumber;

	@FindBy(xpath = "//*[@id='poLineNumber']")
	private WebElement poLineDropdown;

	@FindBy(xpath = "//*[@id='menu-poLineNumber']/div[3]/ul/li[1]")
	private WebElement poLineNumber;

	@FindBy(xpath = "//*[@id='itemUpc']")
	private WebElement itemUpc;

	@FindBy(xpath = "//*[@id=\"root\"]/div/section[2]/section/div[2]/div[1]/div/section/section[4]/div[2]/section/div/div/div/button")
	private WebElement pickupDate_calendar;

	@FindBy(xpath = "//*[@class='MuiButtonBase-root MuiIconButton-root MuiPickersDay-day MuiPickersDay-current MuiPickersDay-daySelected']")
	private WebElement currentDate;

	//dispute
	@FindBy(xpath = "//*[@id='exceptionReason']")
	private WebElement issueCause;

	@FindBy(xpath = "//*[@id='dcNumber']")
	private WebElement dcNumber_Textbox;

	@FindBy(xpath = "//*[@id='partnerId']")
	private WebElement partnerID;

	@FindBy(xpath = "//*[@id='referenceTicket']")
	private WebElement salesforceID;


	WebDriver driver = null;
	
	public void enterNotWalmartFreightDetails(String exceptionQty,String casesPerPallet,String shippedTo,String comments) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(exceptionQty);
		element(casesPerPallet_Textbox).waitUntilVisible();
		element(casesPerPallet_Textbox).type(casesPerPallet);
		element(shippedTo_Textbox).waitUntilVisible();
		element(shippedTo_Textbox).type(shippedTo);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
	}
	
	public void enterHazmatDetails(String exceptionQty,String casesPerPallet,String comments) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(exceptionQty);
		element(casesPerPallet_Textbox).waitUntilVisible();
		element(casesPerPallet_Textbox).type(casesPerPallet);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
	}
	
	public void enterWrongPackDetails(String exceptionQty,String casesPerPallet,String receivedVnpk,String receivedWhpk,String comments) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(exceptionQty);
		element(casesPerPallet_Textbox).waitUntilVisible();
		element(casesPerPallet_Textbox).type(casesPerPallet);
		element(receivedVNPK_Textbox).waitUntilVisible();
		element(receivedVNPK_Textbox).type(receivedVnpk);
		element(receivedWHPK_Textbox).waitUntilVisible();
		element(receivedWHPK_Textbox).type(receivedWhpk);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
	}
	
	public void enterWrongShipmentDetails(String exceptionQty,String casesPerPallet,String comments,String destination) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(exceptionQty);
		element(casesPerPallet_Textbox).waitUntilVisible();
		element(casesPerPallet_Textbox).type(casesPerPallet);
		element(destination_Textbox).waitUntilVisible();
		element(destination_Textbox).type(destination);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
	}
	
	public void enterNOPDetails(String exceptionQty,String casesPerPallet,String comments,String poNumber) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(exceptionQty);
		element(casesPerPallet_Textbox).waitUntilVisible();
		element(casesPerPallet_Textbox).type(casesPerPallet);
		element(poNumber_Textbox).waitUntilVisible();
		element(poNumber_Textbox).type(poNumber);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
	}
	
	public void submitProblem() {
		element(submit_Button).waitUntilVisible();
		click(submit_Button);
	}
	
	public void submitProbleUsingAction() {
		Actions action=new Actions(getDriver());
		action.moveToElement(submit_Button).click();
		action.perform();
	}
	
	public void selectPrinter() {
		click(changePrinter_link);
		try {
			Thread.sleep(3000);
			click(printerCheckbox_Radiobutton);
			Thread.sleep(3000);
			click(proceed_Button);
		} 
		
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void enterNotWalmartFreightDetailsRdc(String qty,String pallet1,String pallet2,String poNumber,String shippedTo,String comments) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(qty);
		element(shippedTo_Textbox).waitUntilVisible();
		element(shippedTo_Textbox).type(shippedTo);
		element(poNumber_Textbox).waitUntilVisible();
		element(poNumber_Textbox).type(poNumber);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
		click(pallet1_Textbox);
		pallet1_Textbox.sendKeys(Keys.CONTROL,Keys.chord("a"));
		pallet1_Textbox.sendKeys(Keys.BACK_SPACE);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).type(pallet1);
		click(addPallet_Button);		
		element(pallet2_Textbox).waitUntilVisible();
		element(pallet2_Textbox).type(pallet2);
		
	}
	
	public void enterOverageDetailsRdc(String qty,String pallet1,String pallet2,String poNumber,String shippedTo,String comments) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(qty);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
		click(pallet1_Textbox);
		pallet1_Textbox.sendKeys(Keys.CONTROL,Keys.chord("a"));
		pallet1_Textbox.sendKeys(Keys.BACK_SPACE);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).type(pallet1);
		click(addPallet_Button);		
		element(pallet2_Textbox).waitUntilVisible();
		element(pallet2_Textbox).type(pallet2);
	}
	
	public void enterNOPDetailsRdc(String qty,String pallet1,String pallet2,String poNumber,String shippedTo,String comments) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(qty);
		element(poNumber_Textbox).waitUntilVisible();
		element(poNumber_Textbox).type(poNumber);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
		click(pallet1_Textbox);
		pallet1_Textbox.sendKeys(Keys.CONTROL,Keys.chord("a"));
		pallet1_Textbox.sendKeys(Keys.BACK_SPACE);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).type(pallet1);
		click(addPallet_Button);		
		element(pallet2_Textbox).waitUntilVisible();
		element(pallet2_Textbox).type(pallet2);
	}
	
	public void enterWrongPackDetailsRdc(String qty,String pallet1,String pallet2,String comments,String receivedVnpk,String receivedWhpk) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(qty);
		element(receivedVNPK_Textbox).waitUntilVisible();
		element(receivedVNPK_Textbox).type(receivedVnpk);
		element(receivedWHPK_Textbox).waitUntilVisible();
		element(receivedWHPK_Textbox).type(receivedWhpk);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
		click(pallet1_Textbox);
		pallet1_Textbox.sendKeys(Keys.CONTROL,Keys.chord("a"));
		pallet1_Textbox.sendKeys(Keys.BACK_SPACE);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).type(pallet1);
		click(addPallet_Button);		
		element(pallet2_Textbox).waitUntilVisible();
		element(pallet2_Textbox).type(pallet2);
	}
	
	public void enterWrongShipmentDetailsRdc(String qty,String pallet1,String pallet2,String comments,String destination,String poNumber) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(qty);
		
		element(destination_Textbox).waitUntilVisible();
		element(destination_Textbox).type(destination);
		
		element(poNumber_Textbox).waitUntilVisible();
		element(poNumber_Textbox).type(poNumber);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
		click(pallet1_Textbox);
		pallet1_Textbox.sendKeys(Keys.CONTROL,Keys.chord("a"));
		pallet1_Textbox.sendKeys(Keys.BACK_SPACE);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).type(pallet1);
		click(addPallet_Button);		
		element(pallet2_Textbox).waitUntilVisible();
		element(pallet2_Textbox).type(pallet2);
		uploadFiles(2);
	}

	public void enterDamageDetailsRdc(String reclaims,String  destory,String sendBackToCarrier,String comments,String damageName) throws HeadlessException, UnsupportedFlavorException, IOException, AWTException {
		element(reclaims_Textbox).waitUntilVisible();
		element(reclaims_Textbox).type(reclaims);

		element(destory_Textbox).waitUntilVisible();
		element(destory_Textbox).type(destory);

		element(sendBackToCarrier_Textbox).waitUntilVisible();
		element(sendBackToCarrier_Textbox).type(sendBackToCarrier);

		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);

		if(damageName.equals("PHYSICAL")) {
			click(physical_Button);
		}else if(damageName.equals("WET")) {
			click(Wet);
		}
		else if(damageName.equals("CONCEALED")) {
			click(Concealed);
		}

		uploadFiles(2);

	}

	public void clickOnExceptionType(){
		element(exceptionType).waitUntilVisible();
		element(exceptionType).click();
	}

	public void enterExceptionDetails(String exception, String qty,String pallet1,String pallet2,String poNumber,String shippedTo,String comments,String receivedVnpk,String receivedWhpk,String destination) {
		element(exceptionQty_Textbox).waitUntilVisible();
		element(exceptionQty_Textbox).type(qty);
		if(exception.equalsIgnoreCase("NOTWALMARTFREIGHT")){
			element(shippedTo_Textbox).waitUntilVisible();
			element(shippedTo_Textbox).type(shippedTo);
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type(poNumber);
		}else if(exception.equalsIgnoreCase("NOP")){
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type("123456789");
		}else if(exception.equalsIgnoreCase("WRONGPACK") || exception.equalsIgnoreCase("RECALL")){
			element(receivedVNPK_Textbox).waitUntilVisible();
			element(receivedVNPK_Textbox).type(receivedVnpk);
			element(receivedWHPK_Textbox).waitUntilVisible();
			element(receivedWHPK_Textbox).type(receivedWhpk);
		}else if(exception.equalsIgnoreCase("WRONGDCNOTINITEM")){
			element(destination_Textbox).waitUntilVisible();
			element(destination_Textbox).type(destination);
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type(poNumber);
			uploadFiles(2);
		}
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comments);
//		click(pallet1_Textbox);
//		pallet1_Textbox.sendKeys(Keys.CONTROL,Keys.chord("a"));
//		pallet1_Textbox.sendKeys(Keys.BACK_SPACE);
//		element(pallet1_Textbox).waitUntilVisible();
//		element(pallet1_Textbox).type(pallet1);
//		click(addPallet_Button);
//		element(pallet2_Textbox).waitUntilVisible();
//		element(pallet2_Textbox).type(pallet2);
	}

	public void enterExceptionDetails(String exception, String qty,String delivery,String po,String upc,String comments ,String market) {
		try {
			clickOnExceptionType();
			selectFromDropDown(exception,getExceptionDropDownElements());
			element(exceptionQty).waitUntilVisible();
			element(exceptionQty).type(qty);
			element(deliveryNumber).waitUntilVisible();
			element(deliveryNumber).type(delivery);
			element(poNumber).waitUntilVisible();
			element(poNumber).type(po);
			Thread.sleep(2000);
			if(market.equalsIgnoreCase("wfs")) {
				element(poLineDropdown).waitUntilVisible();
				element(poLineDropdown).click();
				if(element(poLineNumber).isCurrentlyVisible()) {
					element(poLineNumber).click();
				}
			}else {
				element(pickupDate_calendar).waitUntilVisible();
				element(pickupDate_calendar).click();
				element(currentDate).waitUntilVisible();
				element(currentDate).click();
			}
			element(itemUpc).waitUntilVisible();
			element(itemUpc).type(upc);
			element(comments_Textbox).waitUntilVisible();
			element(comments_Textbox).type(comments);
			//uploadFiles(1);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void enterDisputeExceptionDetails(String exception, String issue_cause, String qty, String po,String upc,String comments , String partID, String salesID ,String dc) {
		try {
			clickOnExceptionType();
			selectFromDropDown(exception,getExceptionDropDownElements());
			element(dcNumber_Textbox).waitUntilVisible();
			element(dcNumber_Textbox).type(dc);
			element(exceptionQty).waitUntilVisible();
			element(exceptionQty).type(qty);
			if(exception.equalsIgnoreCase("Inventory")){
				element(issueCause).waitUntilVisible();
				element(issueCause).click();
				selectFromDropDown(issue_cause,getExceptionDropDownElements());
			}
			element(salesforceID).waitUntilVisible();
			element(salesforceID).type(salesID);
			element(poNumber).waitUntilVisible();
			element(poNumber).type(po);
			Thread.sleep(2000);
			element(partnerID).waitUntilVisible();
			element(partnerID).type(partID);
			element(itemUpc).waitUntilVisible();
			element(itemUpc).type(upc);
			element(comments_Textbox).waitUntilVisible();
			element(comments_Textbox).type(comments);
			uploadFiles(1);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	private List<WebElement> getExceptionDropDownElements() {
		return getDriver().findElements(By.xpath("//*[@class='MuiList-root MuiMenu-list MuiList-padding']/li"));
	}

	private void selectFromDropDown(String strToSelect,List<WebElement> listOfElements) {
		List<WebElement> listOfWebElements = listOfElements;
		for (WebElement webElement : listOfWebElements) {
			String str=webElement.getText().trim();
			if (webElement.getText().trim().equalsIgnoreCase(strToSelect.trim())) {
				element(webElement).click();
				break;
			}
		}
	}
		
	public void confirmPopUp() {
		click(yes_Button);
	}

	public void uploadFiles(int num){

		for(int i=1;i<=num;i++){
			File file = new File("messageFile.txt");
			driver = getWebDriverInstance();
			//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("document.getElementById('attach').style.opacity='1';");
			js.executeScript("document.getElementById('attach').style.pointerEvents='all';");
			js.executeScript("document.getElementById('attach').style.height='20px';");
			js.executeScript("document.getElementById('attach').style.width='100px';");
			js.executeScript("document.getElementById('attach').style.marginTop='500px';");
			js.executeScript("scroll(0, 500);");
			element(upload_Button).sendKeys(file.getAbsolutePath());
			//pload_Button.sendKeys(file.getAbsolutePath());
			driver.switchTo().defaultContent();

		}
	}
}
