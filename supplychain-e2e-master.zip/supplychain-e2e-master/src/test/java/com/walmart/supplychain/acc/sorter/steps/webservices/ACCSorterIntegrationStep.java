package com.walmart.supplychain.acc.sorter.steps.webservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.acc.BeumerDispositionMsg;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ACCSorterIntegrationStep {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String TESTFLOWDATA = "testFlowData";
	private static final String EXCEPTION_LANE = "112";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ACLDBSteps aclDBSteps;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	SpringJmsUtils springJmsUtils;

	@Autowired
	JavaUtils javaUtils;

	@Value("${beumertosortertopic}")
	String beumerTopivACC;
	
	@Autowired
	Environment env;
	
	ObjectMapper objmapper = new ObjectMapper();
	private static final String TEST_FLOW_DATA = "testFlowData";
	

	@Step
	public void publishDispositionMsg(String labelStatus) {
		try {
			String labelStatusDI=null;
			String labelStatusDV=null;
			if (labelStatus.equalsIgnoreCase("NORMAL")) {
					labelStatusDI="NORMAL_DI";
					labelStatusDV="NORMAL_DV";
			}
			else {
				labelStatusDI=labelStatus;
				labelStatusDV=labelStatus;
			}
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			Map<String, String> doorLaneMap;
			Map<String, Object> hm = new HashMap<>();
			hm.put("deviceName", "Upper Sorter");
			hm.put("deviceAddress", "192.0.0.124");
//			hm.put("msgTimestamp", javaUtils.getCurrentDateAndTime("YYYY/MM/dd hh:mm:ss.SSSSS"));
			hm.put("msgTimestamp", "2025/10/14 01:01:01.00000");
			hm.put("timeZone", "UTC");
			hm.put("backedUpMsgCount", 1);
			hm.put("messageID", 12345);

			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*].destNumber");
			String outBoundDestString = listOfLoads1.toJSONString();
			Set<String> outboundDestList = null;
			outboundDestList = objectMapper.readValue(outBoundDestString, new TypeReference<Set<String>>() {
			});
			Map<String, List> laneLpnMapping = new HashMap();
			for (String dest : outboundDestList) {
				JSONArray listOfLanes = JsonPath.read(testData,
						"$.testFlowData.outboundDetails[?(@.destNumber == " + dest + ")].laneNumber");
				String listOfLanesString = listOfLanes.toJSONString();
				logger.info("Doors List {}", listOfLanesString);
				List<String> laneList = null;
				laneList = objectMapper.readValue(listOfLanesString, new TypeReference<List<String>>() {
				});
				
				JSONArray listOfreceivingInstr = JsonPath.read(testData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType == \"normal\" && @.destNumber == "
								+ dest + ")]");
				String listOfreceivingInstrString = listOfreceivingInstr.toJSONString();
				List<ReceivingInstruction> receivingInstrsList = objectMapper.readValue(listOfreceivingInstrString,
						new TypeReference<List<ReceivingInstruction>>() {
						});
				String beumerMsg = null;
				for (int i = 0; i < receivingInstrsList.size(); i++) {
					hm.put("msgEvent", "disposition");
					String lane = laneList.get(i % laneList.size());
					BeumerDispositionMsg despMsg = new BeumerDispositionMsg();
					despMsg.setScannedLabel(receivingInstrsList.get(i).getParentContainer());
					despMsg.setInductNumber("1");
					despMsg.setIntendedLane(lane);
					despMsg.setActualLane(lane);
					despMsg.setLabelStatus(labelStatusDI);
					despMsg.setCameraId("12345678");
					beumerMsg = objmapper.writeValueAsString(despMsg);
					if (laneLpnMapping.containsKey(lane)) {
						List cntrsList = laneLpnMapping.get(lane);
						cntrsList.add(receivingInstrsList.get(i).getParentContainer());
						laneLpnMapping.put(lane, cntrsList);
					} else {
						List cntrList = new ArrayList();
						cntrList.add(receivingInstrsList.get(i).getParentContainer());
						laneLpnMapping.put(lane, cntrList);
					}
					Thread.sleep(5000);
					springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ,
							Config.DC, beumerTopivACC, beumerMsg, hm);
					logger.info("published Disposition message from beumer to Sorter for lpn:"+receivingInstrsList.get(i).getParentContainer());					
					despMsg.setLabelStatus(labelStatusDV);
					beumerMsg = objmapper.writeValueAsString(despMsg);
					hm.put("msgEvent", "dispositionVerification");
					Thread.sleep(5000);
					springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ,
							Config.DC, beumerTopivACC, beumerMsg, hm);
					logger.info("published Verification message from beumer to Sorter for lpn:"+receivingInstrsList.get(i).getParentContainer());
				}
			}

			JSONArray listOfOutbound = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String listOfOutboundString = listOfOutbound.toJSONString();
			logger.info("Outbound List {}", listOfOutboundString);
			List<OutboundDetail> outboundList = null;
			outboundList = objectMapper.readValue(listOfOutboundString, new TypeReference<List<OutboundDetail>>() {
			});

			List outboundObjList = new ArrayList();
			for (OutboundDetail outbound : outboundList) {
				outbound.setContainerIds(laneLpnMapping.get(outbound.getLaneNumber()));
				outboundObjList.add(outbound);
			}

			JSONArray listofOutboundJson = jsonUtil.converyListToJsonArray(outboundObjList);
			String updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofOutboundJson,
					"$.testFlowData.outboundDetails");
			tl.get().put(TEST_FLOW_DATA, updatedtestflowdata);
			logger.info("testData after updating::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish labels in sorter", e);
		}
	}

	@Step
	public void publishDispositionMsgSingleContainerManually() {
		try {
		
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			Map<String, String> doorLaneMap;
			Map<String, Object> hm = new HashMap<>();
			hm.put("deviceName", "Upper Sorter");
			hm.put("deviceAddress", "192.0.0.124");
//			hm.put("msgTimestamp", javaUtils.getCurrentDateAndTime("YYYY/MM/dd hh:mm:ss.SSSSS"));
			hm.put("msgTimestamp", "2025/10/14 01:01:01.00000");
			hm.put("timeZone", "UTC");
			hm.put("backedUpMsgCount", 1);
			hm.put("messageID", 12345);
			hm.put("msgEvent", "disposition");
			
				String beumerMsg = null;
				BeumerDispositionMsg despMsg = new BeumerDispositionMsg();
				despMsg.setScannedLabel("b328990000000000001749472");
				despMsg.setInductNumber("1");
				despMsg.setIntendedLane("220");
				despMsg.setActualLane("220");
				despMsg.setLabelStatus("NORMAL_DI");
				despMsg.setCameraId("12345678");
				beumerMsg = objmapper.writeValueAsString(despMsg);

					springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ,
							Config.DC, "WMSSORTER/DISPOSITION", beumerMsg, hm);
					despMsg.setLabelStatus("NORMAL_DV");
					beumerMsg = objmapper.writeValueAsString(despMsg);
					hm.put("msgEvent", "dispositionVerification");				
					Thread.sleep(2000);
					springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ,
							Config.DC, "WMSSORTER/DISPOSITION", beumerMsg, hm);
					logger.info("Successfully sent DDI-VI for the lpn MANUALLY");
		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish labels in sorter", e);
		}
	}

	@Step
	public void publishExceptionDispositionMsg(String labelStatus) {
		try {
			String labelStatusDI=null;
			String labelStatusDV=null;
			if (labelStatus.equalsIgnoreCase("NORMAL")) {
					labelStatusDI="NORMAL_DI";
					labelStatusDV="NORMAL_DV";
			}
			else {
				labelStatusDI=labelStatus;
				labelStatusDV=labelStatus;
			}
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfreceivingInstr = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType == \"exception_ovg\" || @.labelType == \"exception_na\")].parentContainer");
			String listOfreceivingInstrString = listOfreceivingInstr.toJSONString();
			List<String> receivingInstrsList = objectMapper.readValue(listOfreceivingInstrString,
					new TypeReference<List<String>>() {
					});

			Map<String, Object> hm = new HashMap<>();
			hm.put("deviceName", "Upper Sorter");
			hm.put("deviceAddress", "192.0.0.124");
			hm.put("msgTimestamp", javaUtils.getCurrentDateAndTime("YYYY/MM/dd hh:mm:ss.SSSSS"));
			hm.put("timeZone", "UTC");
			hm.put("backedUpMsgCount", 1);
			hm.put("messageID", 12345);
			hm.put("msgEvent", "disposition");

			for (String cntrs : receivingInstrsList) {
				BeumerDispositionMsg despMsg = new BeumerDispositionMsg();
				despMsg.setScannedLabel(cntrs);
				despMsg.setInductNumber("1");
				despMsg.setIntendedLane("112");
				despMsg.setActualLane("112");
				despMsg.setLabelStatus(labelStatusDI);
				despMsg.setCameraId("12345678");
				String beumerMsg = objmapper.writeValueAsString(despMsg);
				springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ, Config.DC,
						beumerTopivACC, beumerMsg, hm);
				logger.info("published Disposition message from beumer to Sorter for Exception lpn:"+cntrs);
				despMsg.setLabelStatus(labelStatusDV);
				beumerMsg = objmapper.writeValueAsString(despMsg);
				hm.put("msgEvent", "dispositionVerification");
				Thread.sleep(5000);
				springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ,
						Config.DC, beumerTopivACC, beumerMsg, hm);
				logger.info("published Verification message from beumer to Sorter for lpn:"+cntrs);
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish Exception labels in sorter", e);

		}

	}
	
	@Step
	public void verifySorterDBForLanes(String labelStatus) {
		try {
			
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			
			JSONArray listOfOutbound = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String listOfOutboundString = listOfOutbound.toJSONString();
			logger.info("Outbound List {}", listOfOutboundString);
			List<OutboundDetail> outboundList = null;
			outboundList = objectMapper.readValue(listOfOutboundString, new TypeReference<List<OutboundDetail>>() {
			});

			for (OutboundDetail outbound : outboundList) {

				Failsafe.with(retryPolicy).run(() -> {
				List parentCntrList = outbound.getContainerIds();
				List laneList = aclDBSteps.getLaneNumberForLPNs(parentCntrList,labelStatus);
				Set<String> set = new HashSet<String>(laneList);
				laneList.clear();
				laneList.addAll(set);
				if (labelStatus.equalsIgnoreCase("normal")) {
					Assert.assertEquals(ErrorCodes.SORTER_DISPOSITION_LANE_COUNT_MISMATCH,laneList.size(), 1);
					Assert.assertEquals(ErrorCodes.SORTER_DISPOSITION_LANE_COUNT_MISMATCH,laneList.get(0), outbound.getLaneNumber());
				}
				else
				{
					Assert.assertEquals(ErrorCodes.SORTER_DISPOSITION_LANE_COUNT_MISMATCH,laneList.size(), 1);
				}
				logger.info("LPNs are associated with the lanes in the lpn_crossref table");
				});
			}

		} catch (Exception e) {
			throw new AutomationFailure("Lane mapping is not getting cleaned up after stop diversion in the sorter DB", e);
		}
		
	}

	@Step
	public void verifyExceptionLPNsForLanes(String labelStatus) {
		try {
			Failsafe.with(retryPolicy).run(() -> {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();

			JSONArray listOfParentCntrs = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType == \"exception_ovg\" || @.labelType == \"exception_na\")].parentContainer");
			String parentCntrsString = listOfParentCntrs.toJSONString();
			List<String> parentCntrList = null;
			parentCntrList = om.readValue(parentCntrsString, new TypeReference<List<String>>() {
			});
			if(parentCntrList.size()!=0) {
			List laneList = aclDBSteps.getLaneNumberForLPNs(parentCntrList,labelStatus);
			Set<String> set = new HashSet<String>(laneList);
			laneList.clear();
			laneList.addAll(set);
			Assert.assertEquals(ErrorCodes.SORTER_DISPOSITION_EXP_LANE_COUNT_MISMATCH,laneList.size(), 1);
			Assert.assertEquals(ErrorCodes.SORTER_DISPOSITION_EXP_LANE_COUNT_MISMATCH,laneList.get(0), EXCEPTION_LANE);
			logger.info("LPNs are associated with the lanes in the lpn_crossref table for exception labels");
			}
			});
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Exception labels in sorter DB", e);

		}

	}
}