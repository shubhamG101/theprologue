package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class ProblemSelectItemPage extends MobilePageObject{
	Logger logger = LogManager.getLogger(this.getClass());
	
	public ProblemSelectItemPage(WebDriver driver){
        super(driver);
    }
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	private WebElement next_Button;
	
	@AndroidFindBy(xpath = "(//*[@text='Item #'])[1]")
	private WebElement itemFirst;

	public void navigateToExceptionDetailPage() {
		selectItemFromList();
		next_Button.click();
	}
	
	private void selectItemFromList() {
		itemFirst.click();
	}

	public void navigateToNOP() {
		selectItemFromList();
		next_Button.click();
	}
	

}
