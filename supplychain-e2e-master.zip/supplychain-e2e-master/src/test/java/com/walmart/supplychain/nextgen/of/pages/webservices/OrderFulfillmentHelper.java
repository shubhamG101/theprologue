package com.walmart.supplychain.nextgen.of.pages.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderFulfillmentHelper {
	Config config = new Config();
	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY_30S,
			Constants.RETRY_EXECUTION_COUNT);
	List<String> containerList = null;
	// JsonUtils jsonUtils = new JsonUtils();

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	TextParser textParser;

	@Autowired
	JsonUtils jsonUtils;

	String readTestFlowdata;
	private DocumentContext parsedRcvInst;

	@Autowired
	Environment environment;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	Environment queries;

	public static final String DELIVERY_EVENT_TYPE = "delivery_event_type";

	public Headers prePareHeaders() {
		Header facilityNum;

		facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));

		Header contentType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(contentType);
		return new Headers(headerList);
	}

	public net.minidev.json.JSONArray initializeMessageList() {
		readTestFlowdata = (String) tl.get().get("testFlowData");
		return JsonPath.read(readTestFlowdata,
				"$.testFlowData.poDetails.[*].poLineDetails.[*].receivingInstructions.[*].messageId");

	}

	public Response[] buildInstructionUrlAndGetResponseForSoftAllocation() {

		Response[] responseInstruc = null;
		net.minidev.json.JSONArray msgIdList = initializeMessageList();
		String[] OfInstrucUrl = new String[msgIdList.size()];
		responseInstruc = new Response[msgIdList.size()];
		for (int i = 0; i < msgIdList.size(); i++) {

			OfInstrucUrl[i] = config.initializeSoftAllocationUrlDA() + msgIdList.get(i).toString();
			logger.info("OF received Message Id = " + msgIdList.get(i).toString());
			responseInstruc[i] = when().get(OfInstrucUrl[i]);
			responseInstruc[i].then().statusCode(Constants.SUCESS_STATUS_CODE);
		}

		return responseInstruc;
	}

	public Response[] buildInstructionUrlAndGetResponseForFulfillment() {
		Response[] responseOf = null;
		String readTestFlowdata = (String) tl.get().get("testFlowData");

		try {
			net.minidev.json.JSONArray msgIdList = initializeMessageList();
			logger.info("MessageIDList = " + msgIdList.toJSONString());

			String[] OfFulfillUrl = new String[msgIdList.size()];
			responseOf = new Response[msgIdList.size()];
			for (int i = 0; i < msgIdList.size(); i++) {
				JSONArray arr = new JSONArray();
				JSONObject obj = new JSONObject();
				JSONArray payLoad = new JSONArray();
				arr.put(msgIdList.get(i).toString());
				obj.put("fulfillmentIds", arr);
				payLoad.put(obj);

				if (Config.DC == DC_TYPE.ATLAS||Config.DC == DC_TYPE.SAMS||Config.DC == DC_TYPE.ACC) {
					OfFulfillUrl[i] = environment.getProperty("fulfillment_search_url");
					responseOf[i] = given().relaxedHTTPSValidation().accept("application/json")
							.contentType("application/json").headers(prePareHeaders()).body(payLoad.toString())
							.post(OfFulfillUrl[i].toString());
				} else {
					OfFulfillUrl[i] = config.initializeFulfillmentStatusUrlDA();
					responseOf[i] = given().accept("application/json").contentType("application/json")
							.body(payLoad.toString()).post(OfFulfillUrl[i].toString());
				}

				Assert.assertEquals(ErrorCodes.OF_EMPTY_RESPONSE, responseOf[i].getStatusCode(),
						Constants.SUCESS_STATUS_CODE);
				}
		} catch (JSONException e) {
			throw new AutomationFailure("Unable to get Fulfillment Response", e);
		}

		return responseOf;
	}
	/*
	 * No Soft allocation validation required public void
	 * validateResponseForSoftAllocation(Response[] res) { List<HashMap<String,
	 * Object>> resultList = new ArrayList<HashMap<String, Object>>(); for
	 * (Response r : res) { resultList = r.jsonPath().get("softAllocations"); }
	 * for (HashMap<String, Object> map : resultList) {
	 * Assert.assertEquals("Container Fulfilled by OF", 1, (int)
	 * map.get("fulfilledStatus")); }
	 * 
	 * }
	 */

	public HashMap<String, List<String>> validateResponseForFulfillment(Response[] res) throws Exception {
		HashMap<String, List<String>> map = new HashMap<String, List<String>>();
		String[] parentContainer = new String[res.length];
		parsedRcvInst = JsonPath.parse(readTestFlowdata);
		DocumentContext parseFulFillUnits;
		logger.info("Size of Response == " + res.length);
		int count = 0;

		for (Response r : res) {
			try {
				logger.debug(" total resp log : " + r.getBody().asString());
				JSONArray arr = new JSONArray(r.getBody().asString());
				parseFulFillUnits = JsonPath.parse(arr.toString());
				List<String> resultList = new ArrayList<String>();
				List<String> fulfillUnitQty = parseFulFillUnits
						.read("$..fulfillmentUnits[?(@.fulfillmentUnitStatus!='DELETED')].fulfillmentUnitId");
				JSONObject jobj = new JSONObject();
				jobj = arr.getJSONObject(0);
				logger.debug(" print Array response : " + arr.toString());
				Assert.assertNotEquals(ErrorCodes.OF_EMPTY_RESPONSE, 0, arr.length());
				parentContainer[count] = jobj.getString("srcCtnrTrckgId");
				List<String> recivedQty = parsedRcvInst
						.read("$.testFlowData.poDetails.[*].poLineDetails.[*].receivingInstructions.[?(@.parentContainer =='"
								+ parentContainer[count] + "')].receivedQuantity");
				resultList.add(jobj.getString("fulfillmentStatus"));
				resultList.add(jobj.getString("fulfillmentType"));
				resultList.add(jobj.getString("outboundChannelMethod"));
				int receivedQty = Integer.parseInt(recivedQty.get(0));
				if (resultList.get(1).equals("PBYLTRIP")) {
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_STATUS_NOT_UPDATED, "CREATED",
							resultList.get(0).toString());
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_QTY_NOT_MATCH, receivedQty, fulfillUnitQty.size());

				} else {
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_STATUS_NOT_UPDATED, "COMPLETED",
							resultList.get(0).toString());
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_QTY_NOT_MATCH, receivedQty, fulfillUnitQty.size());
				}

				map.put(parentContainer[count], resultList);
				count++;
			} catch (Exception e) {
				logger.info("Failed at SoftAllocation Pick");
				e.printStackTrace();
				throw new AutomationFailure("Failed at SoftAllocation Pick", e);
			}
		}
		return map;
	}
	
	public void validateResponseForFulfillmentACC(Response[] res) throws Exception {
		HashMap<String, List<String>> map = new HashMap<String, List<String>>();
		String[] parentContainer = new String[res.length];
		parsedRcvInst = JsonPath.parse(readTestFlowdata);
		DocumentContext parseFulFillUnits;
		logger.info("Size of Response == " + res.length);
		int count = 0;
		
		for (Response r : res) {
			try {
				logger.info(" total resp log : " + r.getBody().asString());
				
				JSONObject arr = new JSONObject(r.getBody().asString());
				parseFulFillUnits = JsonPath.parse(arr.toString());
				logger.info(" print Array response : " + arr.toString());
				Assert.assertNotEquals(ErrorCodes.OF_EMPTY_RESPONSE, 0, arr.length());
				List<Integer> recivedQty = parseFulFillUnits
						.read("$..fulfillmentSearchOnReceiveContainer[*].fulfillmentUnits[*].fulfilledQty");
				List<String> fulFillmentStatus = parseFulFillUnits
						.read("$..fulfillmentStatus");						
				int receivedQty = recivedQty.get(0);
				Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_STATUS_NOT_UPDATED, "COMPLETED",
							fulFillmentStatus.get(0).toString());
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_QTY_NOT_MATCH, receivedQty, 1);
			} catch (Exception e) {
				logger.info("Failed at SoftAllocation Pick");
				e.printStackTrace();
				throw new AutomationFailure("Failed at SoftAllocation Pick", e);
			}
		}
	}

	public void updateRunTimeDataForReceivingInstruction(HashMap<String, List<String>> map) {

		String testFlowData_updated = "";
		try {
			String readTestFlowdata = (String) tl.get().get("testFlowData");
			net.minidev.json.JSONArray poDetailList = JsonPath.read(readTestFlowdata, "$.testFlowData.poDetails[*]");
			ObjectMapper om = new ObjectMapper();
			String podtl = poDetailList.toString();
			List<PoDetail> poDetail = null;
			poDetail = om.readValue(podtl, new TypeReference<List<PoDetail>>() {
			});

			JSONArray podtlarr = new JSONArray();
			JSONObject[] podtlobj = new JSONObject[poDetail.size()];
			int pbylPalletIndex = 1;
			for (int i = 0; i < poDetail.size(); i++) {

				ObjectMapper ompodtl = new ObjectMapper();
				String podtljson = null;
				podtljson = ompodtl.writeValueAsString(poDetail.get(i));

				JSONObject podtla = null;
				podtla = new JSONObject(podtljson);

				podtlobj[i] = podtla;

				List<PoLineDetail> poLineDetailsArr = poDetail.get(i).getPoLineDetails();

				JSONObject[] polineobj = new JSONObject[poLineDetailsArr.size()];
				JSONArray polinearr = new JSONArray();

				for (int j = 0; j < poLineDetailsArr.size(); j++) {
					ObjectMapper ompoline = new ObjectMapper();
					String polinejson = null;
					polinejson = ompoline.writeValueAsString(poLineDetailsArr.get(j));

					JSONObject a = null;
					a = new JSONObject(polinejson);

					polineobj[j] = a;

					List<ReceivingInstruction> recvInstArr = poLineDetailsArr.get(j).getReceivingInstructions();

					int count = 0;
					JSONArray receInstArr = new JSONArray();

					for (ReceivingInstruction rcvInstrc : recvInstArr) {
						ObjectMapper mapper = new ObjectMapper();
						String rcvJsonString = null;
						rcvJsonString = mapper.writeValueAsString(rcvInstrc);
						JSONObject rcvInsctObj = null;

						rcvInsctObj = new JSONObject(rcvJsonString);

						JSONObject[] rcvInsct = new JSONObject[recvInstArr.size()];
						for (String parentContainer : map.keySet()) {

							if (rcvInstrc.getParentContainer()
									.contentEquals(parentContainer.replace("[", "").replace("]", ""))) {
								rcvInsctObj.put("channelType",
										map.get(parentContainer).get(2).replace("[", "").replace("]", ""));
								if (map.get(parentContainer).get(1).equals("PBYLTRIP")) {
									rcvInsctObj.put("isPbyl", true);
									rcvInsctObj.put("containerName", "I" + pbylPalletIndex);
									pbylPalletIndex++;
								} else {
									rcvInsctObj.put("isPbyl", false);
								}
								rcvInsctObj.put("isPbylTripExecuted", false);
							}

						}
						rcvInsct[count] = rcvInsctObj;
						receInstArr.put(rcvInsct[count]);
						count++;

					}
					polineobj[j].put("receivingInstructions", receInstArr);
					polinearr.put(polineobj[j]);

				}
				podtlobj[i].put("poLineDetails", polinearr);

				podtlarr.put(podtlobj[i]);
			}
			String poDetailArray = podtlarr.toString();
			testFlowData_updated = jsonUtils.setJsonAtJsonPath(readTestFlowdata,
					jsonUtils.convertStringToMinidevJsonArray(poDetailArray), "$.testFlowData.poDetails");
			logger.info("TestFlowData after updating in OF {}", testFlowData_updated);

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while processing the testFlowData", e);
		}
		tl.get().put("testFlowData", testFlowData_updated);

	}

	public void deleteOfInstructionAndSoftAllocation() {
		net.minidev.json.JSONArray msgIdList = initializeMessageList();
		String[] OfFulfillUrl = new String[msgIdList.size()];
		Response[] responseOf = new Response[msgIdList.size()];
		for (int i = 0; i < msgIdList.size(); i++) {
			OfFulfillUrl[i] = config.deleteFulFillInstructionDA();
			responseOf[i] = given().accept("application/json").contentType("application/json")
					.get(OfFulfillUrl[i] + msgIdList.get(i).toString());
			responseOf[i].then().statusCode(Constants.SUCESS_STATUS_CODE);

		}
	}

	public void deleteFulfillments() throws JSONException {
		net.minidev.json.JSONArray msgIdList = initializeMessageList();
		String[] OfFulfillUrl = new String[msgIdList.size()];
		Response[] responseOf = new Response[msgIdList.size()];
		for (int i = 0; i < msgIdList.size(); i++) {
			JSONArray arr = new JSONArray();
			JSONObject obj = new JSONObject();
			JSONArray payLoad = new JSONArray();

			OfFulfillUrl[i] = config.deleteFulFillmentsDA();
			arr.put(msgIdList.get(i).toString());
			obj.put("fulfillmentIds", arr);
			payLoad.put(obj);
			responseOf[i] = given().accept("application/json").contentType("application/json").body(payLoad.toString())
					.delete(OfFulfillUrl[i]);
			responseOf[i].then().statusCode(Constants.SUCESS_STATUS_CODE);

		}

	}

	public void verifySoftAllocationPicks() {
		net.minidev.json.JSONArray msgIdList = initializeMessageList();
		DocumentContext parsedPickAllocation;
		readTestFlowdata = (String) tl.get().get("testFlowData");
		try {
			logger.info("Number of Message Ids: {}", msgIdList.size());
			for (int i = 0; i < msgIdList.size(); i++) {
				JSONArray pickPayLoadArr = new JSONArray();

				JSONObject pickPayLoadObj = new JSONObject();
				pickPayLoadArr.put(msgIdList.get(i));
				pickPayLoadObj.put("pickIds", pickPayLoadArr);
				net.minidev.json.JSONArray qty = JsonPath.read(readTestFlowdata,
						"$.testFlowData.poDetails.[*].poLineDetails.[*].receivingInstructions.[?(@.messageId =='"
								+ msgIdList.get(i) + "')].receivedQuantity");
				net.minidev.json.JSONArray vnpkArr = JsonPath.read(readTestFlowdata,
						"$.testFlowData.poDetails.[*].poLineDetails.[*].vnpk");
				int vnpk = Integer.parseInt(String.valueOf(vnpkArr.get(0)));
				Response response = SerenityRest.given().relaxedHTTPSValidation().headers(prePareHeaders())
						.body(pickPayLoadObj.toString()).post(environment.getProperty("soft_allocation_pick"));
				logger.debug("Pick response:{}", response.asString());
				Assert.assertEquals(ErrorCodes.OP_INVALID_RESPONSE_FOR_PICK, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				int recivedQty = Integer.parseInt(String.valueOf(qty.get(0)));
				logger.info("Total Number of Quantity received:{}", recivedQty);
				logger.info("Total Number of Quantity received in eaches:{}", recivedQty * vnpk);
				String pickResponse = response.asString();
				parsedPickAllocation = JsonPath.parse(pickResponse);
				net.minidev.json.JSONArray fulfillQty = parsedPickAllocation
						.read("$.picks.[?(@.pickId =='" + msgIdList.get(i) + "')].fulfilledQuantity");
				net.minidev.json.JSONArray blockQty = parsedPickAllocation
						.read("$.picks.[?(@.pickId =='" + msgIdList.get(i) + "')].blockedQuantity");
				logger.info("Blocked Quantity in OA:{}", Integer.parseInt(String.valueOf(blockQty.get(0))));
				logger.info("Fulfilled Quantity in OA:{}", Integer.parseInt(String.valueOf(blockQty.get(0))));
				Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_BLOCKED_QTY_NOT_MATCH_ATLAS, recivedQty * vnpk,
						Integer.parseInt(String.valueOf(blockQty.get(0))));
				Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_RCVED_QTY_NOT_MATCH_ATLAS, recivedQty * vnpk,
						Integer.parseInt(String.valueOf(fulfillQty.get(0))));

			}

		} catch (Exception e) {
			logger.info("Failed at SoftAllocation Pick");
			throw new AutomationFailure("Failed at SoftAllocation Pick", e);
		}
	}

	public short validateDelFinalization() {
		String testFlowdata = (String) tl.get().get("testFlowData");
		String deliveryNumber = JsonPath.read(testFlowdata, "$.testFlowData.deliveryDetails[0].deliveryNumber");
		List<Map<String, Object>> deliveryStatus = dbUtils.selectFrom(PRODUCT_NAME.FM,
				queries.getProperty("of_get_delivery_status"), deliveryNumber);
		logger.info("DeliveryStatus : {}", deliveryStatus);
		if ((!deliveryStatus.isEmpty()) && (deliveryStatus.get(0).get(DELIVERY_EVENT_TYPE) != null)) {
			logger.info("Delivery finalization status in OF is : {} for delivery number: {}",
					deliveryStatus.get(0).get(DELIVERY_EVENT_TYPE), deliveryNumber);
			return (short) deliveryStatus.get(0).get(DELIVERY_EVENT_TYPE);
		}

		else
			return 0;

	}

	public boolean validateResponseForShortage(Response[] response) {

		String testFlowData = (String) tl.get().get("testFlowData");
		List<Integer> fulfillUnitQty = JsonPath.parse(response[0].getBody().asString())
				.read("$..fulfillmentUnits[*].[?(@.fulfillmentUnitStatus == 'PICKED')].fulfilledQty");
		List<String> receivedQty = JsonPath.parse(testFlowData).read("$..receivingInstructions[*].receivedQuantity");
		int sum = fulfillUnitQty.stream().mapToInt(Integer::intValue).sum();
		if (sum == Integer.parseInt(receivedQty.get(0)))
			return true;
		else
			return false;
	}

	public void buildInstructionUrlAndGetResponseForFulfillmentACC()
			throws JsonParseException, JsonMappingException, IOException {

		String readTestFlowdata = (String) tl.get().get("testFlowData");
		ObjectMapper om = new ObjectMapper();
		net.minidev.json.JSONArray listOfParentCntrs = JsonPath.read(readTestFlowdata,
				"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType=='normal')].parentContainer");
		String listOfCntrsString = listOfParentCntrs.toString();
		logger.info("Containers List {}", listOfCntrsString);

		containerList = om.readValue(listOfCntrsString, new TypeReference<List<String>>() {
		});
		logger.info("List " + listOfCntrsString.toString());

			for (int i = 0; i < containerList.size(); i++) {
				validateOFResponse(containerList.get(i));
			}
	}

	private void validateOFResponse(String cntr) {
		Failsafe.with(retryPolicy).run(() -> {
				logger.info("Validating OF status for container "+cntr);
				Response responseOf = null;
				Response[] resp=new Response[1];
				
				String OfFulfillUrl = environment.getProperty("fulfillment_lpn_url") + cntr;
				logger.info("Fulfillment URL " + OfFulfillUrl);
				responseOf = given().relaxedHTTPSValidation().headers(getOFHeaders()).when().get(OfFulfillUrl);
				logger.info("Status code " + responseOf.getStatusCode());

				Assert.assertEquals(ErrorCodes.OF_EMPTY_RESPONSE,
						Constants.SUCESS_STATUS_CODE, responseOf.getStatusCode());
				logger.info("Status code validated");
							
				resp[0]=responseOf;
				readTestFlowdata = (String) tl.get().get("testFlowData");
				logger.info("Validating status of LPN in OF");
				validateResponseForFulfillmentACC(resp);
				logger.info("Successfully Validated OF status for container "+cntr);
		});		
	}
	
	public Headers getOFHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header appType = new Header("Content-Type", "application/json");

		
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(appType);
		
		return new Headers(headerList);
	}
}