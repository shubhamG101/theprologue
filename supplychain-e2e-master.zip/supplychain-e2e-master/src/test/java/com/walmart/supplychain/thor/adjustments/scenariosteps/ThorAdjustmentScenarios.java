package com.walmart.supplychain.thor.adjustments.scenariosteps;

import com.walmart.supplychain.thor.adjustments.steps.ThorAdjustmentSteps;
import com.walmart.supplychain.thor.receiving.steps.ThorReceivingStep;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ThorAdjustmentScenarios {
	
	@Steps
	ThorAdjustmentSteps thorAdjustmentSteps;
	
	@When("^user publishes the adjustments from Thor \"([^\"]*)\"$")
	public void userPublishesTheAdjustmentsFromThor(String adjustmentFlag)
	{
		thorAdjustmentSteps.publishAdjustments(adjustmentFlag);
	}
	
	@Then("^user validates Adjustments$")
	public void userValidatesAdjustments()
	{
		thorAdjustmentSteps.validateAdjustments();
	}

}
