package com.walmart.supplychain.nextgen.receiving.scenariosteps.mobile;

import org.json.JSONException;

import com.walmart.supplychain.nextgen.printing.steps.webservices.PrintingSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ReceivingScenarios {


	@Steps
	ReceivingSteps ReceivingSteps;

	@Steps
	PrintingSteps printingSteps;

	@Given("^user starts receiving by scanning the door through receiving apk$")
	public void scan_sreceiving_door() {


		//if (Config.isCloud) {
			ReceivingSteps.checkForReceivingHomePage();
//		} else {
//			// printingSteps.bringPrinterUp();
//			ReceivingSteps.searchforPrinter();
//			ReceivingSteps.selectOnlinePrinter();
//		}
		// IF condition has to be removed as Trailer is showing NULL in Receiving app.
		// will Remove ReceivingSteps.scanDoorWitron(); later

//		if (Config.DC == DC_TYPE.WITRON) {
//
//			ReceivingSteps.scanDoorWitron();
//		} else
			ReceivingSteps.scanDoor();

		// ReceivingSteps.updateInboundDB();
	}

	@Given("^user performs problem receiving by scanning container label$")
	public void scan_receiving_problem() {
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.performProblemReceiving();
	}

	@Given("^User creates allocations for the items$")
	public void createAllocations() {
		ReceivingSteps.createAllocations();
	}

	@And("^user selects manual receiving option from receiving apk$")
	public void selectManualReceiving() throws JSONException {
		ReceivingSteps.selectManualReceiving();
	}
	
	
	@Then("user updates ti hi (.*)$")
	public void user_updates_ti_hi(String tiHi){
		ReceivingSteps.updateTiHi(tiHi);
	}
	
	@And("^user should be able to manually receive the freight$")
	public void startManualReceiving() throws JSONException {
		ReceivingSteps.startManualReceivingACC();
	}

	@And("^user should be able to manually receive multi PO$")
	public void startReceivingMultiPO() throws JSONException {
		ReceivingSteps.startReceivingMultiPO("Manually");
	}

	@And("^user should be able to receive multi PO \"([^\"]*)\"$")
	public void startReceivingMultiPO(String manualOrNonManual) throws JSONException {
		ReceivingSteps.startReceivingMultiPO(manualOrNonManual);
	}

	@And("^user should be able to receive multi PO \"([^\"]*)\" for online door$")
	public void startReceivingMultiPOOnlineDoor(String manualOrNonManual) throws JSONException {
		ReceivingSteps.startReceivingMultiPOOnlineDoor(manualOrNonManual);
	}

//	@And("^user should be able to manually receive multi PO$")
//	public void startReceivingMultiPO() throws JSONException {
//		ReceivingSteps.startReceivingMultiPO();
//	}
	@When("^user receives qty \"([^\"]*)\" and builds the Pallet with Qty and completes the pallet$")
	public void startReceiving(String receivingType) throws JSONException {
		ReceivingSteps.startReceiving(receivingType);

	}
	
	@When("^user receives qty \"([^\"]*)\" and builds the Pallet with Qty and completes the pallet for Lithium or Limited qty item$")
	public void startReceivingLithiumOrLmitedQtyItem(String receivingType) throws JSONException {
		ReceivingSteps.startReceivingLithiumOrLmitedQtyItem(receivingType);

	}

	
	@When("^user receives qty \"([^\"]*)\" with valid tiHi \"([^\"]*)\" and builds the Pallet with Qty and completes the pallet for grocery$")
	public void startReceivingForWitron(String receivingType,String val) throws JSONException {
		ReceivingSteps.receivingForWitron(receivingType, val,"");

	}
	
	@When("^user receives against \"([^\"]*)\" Item \"([^\"]*)\" for Cross ref item \"([^\"]*)\"$") 
	public void startReceivingForWitronXref(String receivingType,String primeItem,String xrefItem) throws JSONException {
		ReceivingSteps.receivingForWitron(receivingType, primeItem,xrefItem);

	}
	
	
	@Then("^user cancel the pallet$")
	public void user_cancel_pallet() throws JSONException {
		ReceivingSteps.cancelPallet();

	}
	
	@Then("^user reject the pallet at Po Confirmation Page$")
	public void user_reject_po_confirm() throws JSONException {
		ReceivingSteps.rejectTheQtyExceptionAtPoConfirm();

	}
	
	
	@Then("^user reject the pallet at close date$")
	public void reject_at_close_date() throws JSONException {
		ReceivingSteps.rejectPalletWhileReceiving();

	}
	
	
	@When("^user rejects the qty$")
	public void rejectQty() throws JSONException {
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.scanDoor();
		ReceivingSteps.rejectTheQty();

	}
		
	
	@When("^user confirm POs for grocery$")
	public void poConfirm() throws JSONException {
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.scanDoor();
		ReceivingSteps.poConfirm();
		//ReceivingSteps.validateShortRejectDamage(shortDamageRejectValue);
		
	}


	@When("^receiver scan item UPC then he should get message to place the case on the conveyor$")
	public void startReceivingACC() throws JSONException {
		ReceivingSteps.startReceivingACC(true);
	}
	
	@When("^receiver scans item UPC for \"([^\"]*)\" PO then verify the dialog boxes based on channel method$")
	public void startReceivingAccBasedOnChannelMethod(String channelMethod) throws JSONException {
		ReceivingSteps.startReceivingAccBasedOnChannel(channelMethod);
	}
	
	@When("^receiver scan item UPC$")
	public void startReceivingACC_New() throws JSONException {
		ReceivingSteps.startReceivingACC(false);

	}
	
	@Then("^he should get message to place the case on the conveyor$")
	public void validateMessageRelatedToConveyerBelt() throws JSONException {
		ReceivingSteps.validateMessageToPlaceOnConveyerBelt();

	}
	
	
	@Then("^user verifies the Limited Qty Attention popup then accepts that cases are labelled correctly$")
	public void verifyAndAcceptLimitedQtyAttentionPopup() throws JSONException {
		ReceivingSteps.verifyAndAcceptLimitedQtyAttentionPopup();
	}
	
	@Then("^user verifies the Lithium-Ion Attention popup then accepts that cases are labelled correctly$")
	public void verifyAndAcceptLithiumIonAttentionPopup() throws JSONException {
		ReceivingSteps.verifyAndAcceptLithiumIonAttentionPopup();
	}
	

	@When("^user completes the delivery from receiving$")
	public void completesDeliveryFromReceiving() {
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.scanDoor();
		ReceivingSteps.deliveryComplete();
	}
	
	@When("^user completes the delivery from receiving for grocery$")
	public void completesDeliveryFromReceivingForGrocery() {
		ReceivingSteps.deliveryComplete();
	}


	@Given("^user re-open the delivery from receiving$")
	public void reOpenDeliveryFromReceiving() throws InterruptedException {
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.enterDeliveryNumber();
		ReceivingSteps.scanOldLocation();
		//commented as part of Receiving Delivery re-open changes
//		ReceivingSteps.openDeliveryPage();
//		ReceivingSteps.clickonBackArrow();
		
	}
	
	@Then("^user marks pallet on hold$")
	public void userMarkPalletOnHOld() throws JSONException {
		ReceivingSteps.receivingOnHoldPallet();

	}

	@Then("^user marks pallet Cancel for Grocery$")
	public void userMarkPalletCancelForGrocery() throws JSONException {
		ReceivingSteps.receivingVTRPalletWitron("");

	}
	
	@Then("^user does pallet Correction for Grocery$")
	public void userDoesPalletCorrectionForGrocery() throws JSONException {
		String val="";
		ReceivingSteps.receivingPalleCorrectiontWitron(val);

	}
	
	
	@Then("^user does pallet Correction before PO Confirm \"([^\"]*)\"$")
	public void userDoesPalletCorrectionBeforePoCOnfirm(String nagetiveCOrrection) throws JSONException {
		ReceivingSteps.receivingPalleCorrectiontWitron(nagetiveCOrrection);

	}
	
	
	@Then("^user does VTR after PO Confirmation \"([^\"]*)\"$")
	public void userDoesVTRAfterPoCOnfirm(String nagetiveVTR) throws JSONException {
		ReceivingSteps.receivingVTRPalletWitron(nagetiveVTR);

	}

	@When("^user received qty overage and builds the Pallet with Qty and completes the pallet$")
	public void startOverageReceiving() throws JSONException {
		ReceivingSteps.startReceivingOverage();

	}

	@When("^user re-receives the problem label through problem receiving$")
	public void reReceiveProblemLabel() {
		printingSteps.bringPrinterUp();
		ReceivingSteps.searchforPrinter();
		ReceivingSteps.selectOnlinePrinter();
	}

	@When("^user re-receives the problem containers through problem receiving$")
	public void reReceiveProblemContainers() {
		printingSteps.bringPrinterUp();
		ReceivingSteps.searchforPrinter();
		ReceivingSteps.selectOnlinePrinter();
		ReceivingSteps.clickOnProblemReceiveTab();
		ReceivingSteps.scanTheProblemLabel();

	}

	@Then("^Receiving should make a negative entry in the recipts to adjust the existing receipts$")
	public void validateNegativeEntryInReceiving() {
		ReceivingSteps.validateNegativeEntry();
	}

	@And("^user verifies container status in receiving as \"([^\"]*)\"$")
	public void checkContainerStatusAfterVTR(String containerStatus) {
		ReceivingSteps.checkContainerStatusAfterVTR(containerStatus);
	}
	
	@And("^user verifies container status in receiving after pallet correction \"([^\"]*)\"$")
	public void checkContainerStatusAfterPalletCorrection(String containerStatus) {
		ReceivingSteps.checkContainerStatusAfterVTRFromPalletCorrection(containerStatus);
	}
	
	//checkContainerStatusAfterVTRFromPalletCorrection

	@Then("^re-receive the voided container using the receiving App$")
	public void reReceiveVoidedContainer() {
		ReceivingSteps.reReceiveVTRContainer();
	}

	@When("^user scans the item upc and clicks on Report a problem and creates OVG problem$")
	public void reportOvgProblem() {
		ReceivingSteps.reportOverageProblem();
	}

	@When("^user opens the receiving app$")
	public void userOpensTheReceivingApp() {
		ReceivingSteps.openreceivingApp();
	}

	@Then("^user scans the item UPC and CANCEL the receipt in Receiving so that the allocation is released$")
	public void upcScanAndCancelReceipt() {

		ReceivingSteps.scanUpcCancelReceipt();
	}
	
	@Given("^user re-receive problem cases$")
	public void reReceiveProblemForMCC() {
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.reReceiveProblem();
		
	}
	
	@When("^user navigates to DSDC screen$")
	public void navigateToDSDCScreen() {
		ReceivingSteps.navigateToDSDCScreen();
	}
	
	@Then("^user select the POs for the pallet and navigate to Receiving screen$")
	public void recieveDsdcPo() {
		ReceivingSteps.selectDsdcPoAndClickNext();
	}

	@Then("^user validates the Receiving after VTR from \"([^\"]*)\"$")
	public void userValidatesTheReceivingAfterVTR(String vtrType) {

		ReceivingSteps.validateReceivingVTR(vtrType);
		ReceivingSteps.checkForReceivingHomePage();
		ReceivingSteps.scanDoor();
	}

	@Then ("^user selects all po and go for multi po receiving$")
	public void selectAllPos() {
		ReceivingSteps.clickOnYesForMultiPOReceiving();
	}

	@When("^user receives multi pos and completes the dsdc pallet$")
	public void receiveMultiDSDCPoPallet() {
		ReceivingSteps.startReceivingMultiDsdcPO();
	}

	@When("^user navigates to POCON screen$")
	public void navigateToPOCONScreen() {
		ReceivingSteps.navigateToPOCONScreen();
	}

	@Then("^user select the POCON PO for the pallet and navigate to Receiving screen$")
	public void recievePOCONPo() {
		ReceivingSteps.selectPOCONPoAndClickNext();
	}

	@When("^user receives and completes the \"([^\"]*)\" pallet$")
	public void receivePOCONPallet(String poType) {
		ReceivingSteps.startReceivingDsdcOrPocon(poType);
	}
}
