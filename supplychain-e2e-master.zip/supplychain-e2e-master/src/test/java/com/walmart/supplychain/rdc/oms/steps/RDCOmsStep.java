package com.walmart.supplychain.rdc.oms.steps;

import static net.serenitybdd.rest.SerenityRest.given;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.opencsv.CSVReader;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.witron.loading.pages.MyAppsTabletLoginPage;
import com.walmart.supplychain.witron.myapps.pages.MyAppsHomePage;

import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class RDCOmsStep {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	RDCUtil rdcUtil;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	PreRunCleanup preRunCleanup;

	Response response;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	ObjectMapper om = new ObjectMapper();

	@Autowired
	JavaUtils javaUtil;

	Response apiResponse;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String ABSOLUTE_PATH = "/src/test/resources/TestData/rdc/";
	private static final String MOCKURLPATTERN = "/NEXTGEN/OMSPubSubGenericRead2/";
	private static final String GET_DELIVERY_NBR = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*].poNumber";
	private static String wireMockUrl = "http://10.74.87.4:8080";
	String testFlowData;

	@Step
	public void createOMSPO(String flowType) {
		try {

			JSONObject releaseMessage = null;
			Reader reader = null;
			String poName = null;

			if (flowType.equals("osdr")) {
				releaseMessage = new JSONObject(
						jsonUtil.readFile(System.getProperty("user.dir") + ABSOLUTE_PATH + "osdrpo.json"));

				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + ABSOLUTE_PATH + "/rdcOsderFlow.csv"));
				poName = "SSTK";
			} else if (flowType.equals("asn")) {
				releaseMessage = new JSONObject(
						jsonUtil.readFile(System.getProperty("user.dir") + ABSOLUTE_PATH + "asn.json"));

				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + ABSOLUTE_PATH + "/rdcasn.csv"));
				poName = "asn";
			} else if (flowType.equals("docktag")) {
				releaseMessage = new JSONObject(
						jsonUtil.readFile(System.getProperty("user.dir") + ABSOLUTE_PATH + "docktag.json"));

				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + ABSOLUTE_PATH + "/rdcDockTagFlow.csv"));
				poName = "SSTK";
			} else if (flowType.equals("palletCorrection")) {
				releaseMessage = new JSONObject(
						jsonUtil.readFile(System.getProperty("user.dir") + ABSOLUTE_PATH + "palletCorrection.json"));

				reader = new BufferedReader(new FileReader(
						System.getProperty("user.dir") + ABSOLUTE_PATH + "/rdcPalletCorrectionFlow.csv"));
				poName = "SSTK";
			} else if (flowType.equals("itemCatalog")) {
				releaseMessage = new JSONObject(
						jsonUtil.readFile(System.getProperty("user.dir") + ABSOLUTE_PATH + "itemCatalog.json"));

				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + ABSOLUTE_PATH + "/rdcItemCatelog.csv"));
				poName = "SSTK";
			} else if (flowType.equals("overageException")) {
				releaseMessage = new JSONObject(
						jsonUtil.readFile(System.getProperty("user.dir") + ABSOLUTE_PATH + "overageException.json"));

				reader = new BufferedReader(
						new FileReader(System.getProperty("user.dir") + ABSOLUTE_PATH + "/rdcOvgException.csv"));
				poName = "SSTK";
			}
			String poData = releaseMessage.toString(2);

			net.minidev.json.JSONObject omsObj = jsonUtil.convertStringToMinidevJsonObject(poData);
			net.minidev.json.JSONObject OMPSRJsonObject = (net.minidev.json.JSONObject) omsObj.get("OMPSRJ");
			net.minidev.json.JSONArray dataJsonArrObj = (net.minidev.json.JSONArray) OMPSRJsonObject.get("Data");
			net.minidev.json.JSONObject dataJsonObj = (net.minidev.json.JSONObject) dataJsonArrObj.get(0);
			net.minidev.json.JSONObject omsPoObj = (net.minidev.json.JSONObject) dataJsonObj.get("omspo");
			net.minidev.json.JSONArray omsPolObjArr = (net.minidev.json.JSONArray) omsPoObj.get("omspol");

			String poNumber = (String) omsPoObj.get("xrefponbr");

			TestFlowDataMain root = new TestFlowDataMain();
			TestFlowData testFlowData = new TestFlowData();
			List<PoDetail> poList = new ArrayList<PoDetail>();

			String channelMethod = null;
			List<PoLineDetail> poLineList = new ArrayList<PoLineDetail>();

			CSVReader csvReader = new CSVReader(reader);
			String[] line;
			int m = 0;
			Map<String, String> osdrMap = new HashMap<String, String>();
			while ((line = csvReader.readNext()) != null) {
				if (m == 0) {
					m++;
					continue;
				}

				osdrMap.put(line[17] + "#" + line[0], line[10] + "#" + line[14] + "#" + line[11] + "#" + line[12] + "#"
						+ line[9] + "#" + line[15] + "#" + line[13] + "#" + line[16] + "#" + line[1] + "#" + line[2]);
			}

			for (int i = 0; i < omsPolObjArr.size(); i++) {
				net.minidev.json.JSONObject poLineDocument = (net.minidev.json.JSONObject) omsPolObjArr.get(i);
				net.minidev.json.JSONObject chnmthtxtObj = (net.minidev.json.JSONObject) poLineDocument
						.get("chnmthtxt");
				net.minidev.json.JSONArray omspolinedestArr = (net.minidev.json.JSONArray) poLineDocument
						.get("omspolinedest");
				net.minidev.json.JSONObject omspolinedestObj = (net.minidev.json.JSONObject) omspolinedestArr.get(0);
				PoLineDetail lineDetail = new PoLineDetail();
				lineDetail.setPoLineNumber(poLineDocument.get("opolnbr").toString());
				channelMethod = chnmthtxtObj.get("chnmthdtext").toString();
				String itemNbr = poLineDocument.get("itmnbr").toString();
				lineDetail.setItemNumber(itemNbr);
				String itemresponse = rdcUtil.getItemMDMDetails(itemNbr);
				DocumentContext parsedItemDetailsJson = JsonPath.parse(itemresponse);

				List<String> orderableGtinList = parsedItemDetailsJson.read("$.foundSupplyItems[*].orderableGTIN");
				List<String> consumableGtinList = parsedItemDetailsJson.read("$.foundSupplyItems[*].consumableGTIN");
				List<String> palletTi = parsedItemDetailsJson.read("$.foundSupplyItems..palletTi");
				List<String> palletHi = parsedItemDetailsJson.read("$.foundSupplyItems..palletHi");
				List<String> convInd = parsedItemDetailsJson.read("$.foundSupplyItems[*].tradeItems[*].isConveyable");
				List<String> deptNbr = parsedItemDetailsJson
						.read("$.foundSupplyItems[*].supplierAgreement.department.number");

				if (flowType.equals("itemCatalog")) {
					lineDetail.setCaseUpc("407874235" + javaUtil.randonNumberGenerator(5));
				} else {
					lineDetail.setCaseUpc(orderableGtinList.get(0));
				}
				lineDetail.setItemUpc(consumableGtinList.get(0));
				lineDetail.setPoVnpkQty(omspolinedestObj.get("vnpkordqty").toString());
				// lineDetail.setTi(String.valueOf(palletTi.get(0)));
				// lineDetail.setHi(String.valueOf(palletHi.get(0)));

				lineDetail.setChannelMethod(chnmthtxtObj.get("chnmthdtext").toString());
				lineDetail.setVnpk(poLineDocument.get("vnpkqty").toString());
				lineDetail.setWhpk(poLineDocument.get("whpkqty").toString());
				lineDetail.setWhpkSellPrice(poLineDocument.get("vnpkcstamt").toString());
				lineDetail.setDepartmentNumber(String.valueOf(deptNbr.get(0)));
				lineDetail.setIsConveyable(String.valueOf(convInd.get(0)));

				if (!flowType.equals("asn")) {
					String[] osdrArr = osdrMap.get(poLineDocument.get("opolnbr").toString() + "#" + itemNbr).split("#");

					lineDetail.setRecvQty(Integer.parseInt(osdrArr[0]));
					logger.info(osdrArr[6]);
					if (osdrArr[6].equals("o")) {
						lineDetail.setOverageFlag("o");
						lineDetail.setShortQty(osdrArr[1]);
					} else {
						lineDetail.setOverageFlag("s");
						lineDetail.setShortQty(osdrArr[1]);
					}
					lineDetail.setRejectQty(osdrArr[2]);
					lineDetail.setDamageQty(osdrArr[3]);
					lineDetail.setCroInd(osdrArr[4]);
					lineDetail.setProblemQty(osdrArr[5]);
					lineDetail.setOsdrInd(osdrArr[6]);
					lineDetail.setproblemType(osdrArr[7]);
					lineDetail.setTi(osdrArr[8]);
					lineDetail.setHi(osdrArr[9]);
				}
				poLineList.add(lineDetail);
			}

			JSONObject request = new JSONObject();
			JSONObject response = new JSONObject();
			JSONObject finalObj = new JSONObject();
			logger.info(poData);
			request.put("urlPattern", MOCKURLPATTERN + poNumber + ".*");
			request.put("method", "GET");
			logger.info(wireMockUrl + MOCKURLPATTERN + poNumber + ".*");

			response.put("headers", new JSONObject().put("Content-Type", "application/json"));

			JSONObject obj = null;
			response.put("status", "200");
			response.put("body", poData);

			finalObj.put("request", request);
			finalObj.put("response", response);
			String UUid = javaUtil.getUUID();
			finalObj.put("id", UUid);
			finalObj.put("uuid", UUid);

			apiResponse = given().contentType("application/json; charset=utf-8").body(finalObj.toString()).when()
					.post(wireMockUrl + "/__admin/mappings");
			logger.info(apiResponse.getBody().asString());
			JSONObject mockObject = new JSONObject(apiResponse.getBody().asString());
			String mockId = mockObject.getString("id");
			logger.info("UUID for Mock : {} ", mockId);
			List<String> uuIDList = new ArrayList();
			uuIDList.add(mockId);

			PoDetail poDetail = new PoDetail();

			poDetail.setPoNumber(poNumber);
			poDetail.setPoName(poName);
			poDetail.setSourceNumber(environment.getProperty("witron_facility_num"));
			poDetail.setBaseDiv((String) omsPoObj.get("basediv"));
			poDetail.setSrcCountryCode((String) omsPoObj.get("dccc"));
			poDetail.setPoStatus((String) omsPoObj.get("postatcdtext"));
			poDetail.setPoLineDetails(poLineList);
			poDetail.setUuid(uuIDList);
			poList.add(poDetail);
			testFlowData.setPoDetails(poList);
			root.setTestFlowData(testFlowData);
			tl.get().put(TEST_FLOW_DATA, om.writeValueAsString(root));
			logger.info("testFlowdata:" + tl.get().get(TEST_FLOW_DATA));
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_CREATE_PO, e);

		}

	}

	public void rdcPreCleanUp() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			List<String> poList = parsedtestflowJson.read(GET_PONUMBERS);
			String[] poArr = new String[poList.size()];

			String deliveryNum = environment.getProperty(poList.get(0));

			for (int i = 0; i < poList.size(); i++) {
				poArr[i] = poList.get(i);
			}

			preRunCleanup.cleanRDCGDM(deliveryNum);
			preRunCleanup.cleanRDCReceving(deliveryNum);
			preRunCleanup.cleanRDCRDS(poArr);
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_CLEAN_RDC, e);
		}

	}

}
