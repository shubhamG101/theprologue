package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.google.common.base.Predicate;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.PointOption;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.webdriver.WebDriverFacade;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.base.Predicate;
import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.PressesKey;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;
import net.thucydides.core.annotations.findby.By;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

public class FixitMobileHomePage extends MobilePageObject {

	Logger logger = LogManager.getLogger(this.getClass());
	
	public FixitMobileHomePage(WebDriver driver){
        super(driver);
    }
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.move.nim.fixit.mobile:id/search_src_text']")
	private WebElement search_Textbox;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/searchBtn']")
	private WebElement search_Icon;

	@AndroidFindBy(xpath = "//androidx.cardview.widget.CardView[@index='0']")
	private WebElement firstTicket;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_problemId']")
	private WebElement ticketNum_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_deliveryNumber']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement deliveryNum_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_assignedGrp']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement assignedGroup_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_createdBy']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement createdBy_Text;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/iv_tabIcon'])[1]")
	private WebElement Detail_Icon;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/iv_tabIcon'])[2]")
	private WebElement resolution_Icon;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_solution']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement resolutionName_Text;
	
	/*@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='More options']")
	private WebElement ticketAction_Icon;*/
	
	@AndroidFindBy(accessibility = "More options")
	private WebElement ticketAction_Icon;
	
	@AndroidFindBy(xpath = "//*[@text='Cancel Ticket']")
	private WebElement cancelTicket_Link;
	
	@AndroidFindBy(xpath = "//*[@text='Assign to HO']")
	private WebElement assignToHO_Link;
	
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@text='Other']")
	private WebElement other_RadioButton;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_comment']")
	private WebElement comment_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.move.nim.fixit.mobile:id/btn_cancel']")
	private WebElement cancelTicket_Button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_exceptionType']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement problemType_Text;
	
	//assign to ho
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='PO Number on case']")
	private WebElement poNumberOnCase_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='PO Line #']")
	private WebElement poLineNumber_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Item Number']")
	private WebElement itemNumber_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Item Description']")
	private WebElement itemDescription_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Item Department']")
	private WebElement itemDepartment_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='PO Type']")
	private WebElement poType_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='PO Event Code']")
	private WebElement poEventCode_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.move.nim.fixit.mobile:id/btn_assign']")
	private WebElement assign_Button;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Mark Resolved']")
	private WebElement markResolved_Link;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text='YES']")
	private WebElement markResolvedYes_Button;
	
	//validations
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_containerId']")
	private WebElement containerId_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_problemCases']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement problemCases_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_poNumber']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement poNumber_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/lvtv_recievedQty']//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_value']")
	private WebElement qtyToReceive_Text;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_status']")
	private WebElement ticketStatus_Text;

	//assign to HO
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_vendorName']")
	private WebElement vendorName_Text;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_vendorId']")
	private WebElement vendorId_Text;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_itemNumber']")
	private WebElement itemNumber_Text;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_itemDept']")
	private WebElement itemDepartment_Text;

	//Reprint Label
	@AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc=\"Open navigation drawer\"]")
	private WebElement menuIcon;

	@AndroidFindBy(xpath = "//*[@text='Reprint Label']")
	private WebElement reprintLabel_Link;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/btn_selectAll']")
	private WebElement selectAll_Button;

	@AndroidFindBy(xpath = "//*[@text='Reprint']")
	private WebElement reprintIcon;


	public void scanProblemTicket(String ticketNumber) {
		search_Textbox.click();
		AppiumHelper.scan(getAndroidDriver(), ticketNumber);
	}

	public void searchProblemTicket(String ticketNumber) {
		search_Textbox.click();
		search_Textbox.sendKeys(ticketNumber);
		search_Icon.click();
		element(firstTicket).waitUntilClickable();
		element(firstTicket).click();
	}
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
	    return (AndroidDriver<AndroidElement>)
	            ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
	
	public String getDeliveryNum() {
		element(deliveryNum_Text).waitUntilVisible();
		return element(deliveryNum_Text).getText();
	}
	
	public String getTicketNum() {
		element(ticketNum_Text).waitUntilVisible();
		return element(ticketNum_Text).getText();
	}

	public String getTicketStatus() {
		element(ticketStatus_Text).waitUntilVisible();
		return element(ticketStatus_Text).getText();
	}
	
	public String getAssignedGroup() {
		element(assignedGroup_Text).waitUntilVisible();
		return element(assignedGroup_Text).getText();
	}
	
	public String getCreatedBy() {
		element(createdBy_Text).waitUntilVisible();
		return element(createdBy_Text).getText();
	}

	public void clickOnResolutionIcon() {
		element(resolution_Icon).waitUntilVisible();
		element(resolution_Icon).click();
	}
	
	public String getResolutionName() {
		element(resolutionName_Text).waitUntilVisible();
		return element(resolutionName_Text).getText();
	}
	public void cancelTicket() {
		element(ticketAction_Icon).waitUntilVisible();
		element(ticketAction_Icon).waitUntilClickable();
		ticketAction_Icon.click();
		//new TouchAction(getAndroidDriver()).tap((TapOptions) ticketAction_Icon).perform();
		element(cancelTicket_Link).waitUntilVisible();
		element(cancelTicket_Link).waitUntilClickable();
		cancelTicket_Link.click();
		//element(cancelTicket_Link).click();
		element(other_RadioButton).waitUntilVisible();
		element(other_RadioButton).waitUntilClickable();
		other_RadioButton.click();
		//element(other_RadioButton).click();
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(comment_Textbox).waitUntilVisible();
		element(comment_Textbox).type("Cancel ticket from mobile e2e team");
		getAndroidDriver().hideKeyboard();
		element(cancelTicket_Button).waitUntilVisible();
		element(cancelTicket_Button).click();
	}

	public void navigateToReprintLabel() {
		element(menuIcon).waitUntilVisible();
		element(menuIcon).click();
		element(reprintLabel_Link).waitUntilVisible();
		element(reprintLabel_Link).click();
	}

	public void reprintLabel() {
		element(selectAll_Button).waitUntilVisible();
		element(selectAll_Button).click();
		element(reprintIcon).waitUntilVisible();
		element(reprintIcon).click();
	}

	public void assignToHO() {
		element(ticketAction_Icon).waitUntilVisible();
		element(ticketAction_Icon).click();
		element(assignToHO_Link).waitUntilVisible();
		element(assignToHO_Link).click();
	}
	
	public void submitToHoNotWalmartFreight(String ponum,String poline,String itemnum,String itemdesc,String itemdep,String potype,String poevent) throws InterruptedException {
		element(poNumberOnCase_Textbox).waitUntilVisible();
		element(poNumberOnCase_Textbox).type(ponum);
		getAndroidDriver().hideKeyboard();
		element(poLineNumber_Textbox).waitUntilVisible();
		element(poLineNumber_Textbox).type(poline);
		getAndroidDriver().hideKeyboard();
		element(itemNumber_Textbox).waitUntilVisible();
		element(itemNumber_Textbox).type(itemnum);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.ScrollDown(getAndroidDriver());
		/*element(itemDescription_Textbox).waitUntilVisible();
		element(itemDescription_Textbox).type(itemdesc);*/
		element(itemDepartment_Textbox).waitUntilVisible();
		element(itemDepartment_Textbox).type(itemdep);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.ScrollDown(getAndroidDriver());
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(poType_Textbox).waitUntilVisible();
		element(poType_Textbox).type(potype);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(poEventCode_Textbox).waitUntilVisible();
		element(poEventCode_Textbox).type(poevent);
		getAndroidDriver().hideKeyboard();
		element(assign_Button).waitUntilVisible();
		element(assign_Button).click();
		Thread.sleep(6000);
	}

	public void assignTicketToHO(String exceptionType){
		if(exceptionType.equalsIgnoreCase("Not Walmart Freight")){
			element(vendorName_Text).waitUntilVisible();
			element(vendorName_Text).type("Vendor123");
		}else if(exceptionType.equalsIgnoreCase("Not on PO")){
			element(itemNumber_Text).waitUntilVisible();
			element(itemNumber_Text).type("12345678");
			element(assign_Button).waitUntilVisible();
			element(assign_Button).click();
			element(itemDepartment_Text).waitUntilVisible();
			element(itemDepartment_Text).type("101");
			element(vendorName_Text).waitUntilVisible();
			element(vendorName_Text).type("Vendor123");
		}
			element(assign_Button).waitUntilVisible();
			element(assign_Button).click();
	}
	
	public void markResolved() {
		try {
			AppiumHelper.PullToRefresh(getAndroidDriver());
			element(markResolved_Link).waitUntilVisible();
			element(markResolved_Link).click();
			element(markResolvedYes_Button).waitUntilVisible();
			element(markResolvedYes_Button).click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void clickOnDetailIcon() {
		element(Detail_Icon).waitUntilVisible();
		element(Detail_Icon).click();
	}
	
	
	public String getProblemName() {
		element(problemType_Text).waitUntilVisible();
		return element(problemType_Text).getText();
	}
	
	public String getProblemContainerId() {
		AppiumHelper.scrollToElementInMObile("Container Details", getAndroidDriver());
		element(containerId_Text).waitUntilVisible();
		return element(containerId_Text).getText();
	}
	
	public String getProblemCasesCount() {
		element(problemCases_Text).waitUntilVisible();
		return element(problemCases_Text).getText();
	}
	
	public String getProblemPONumebr() {
		element(poNumber_Text).waitUntilVisible();
		return element(poNumber_Text).getText();
	}
	
	public String getQtyToReceive() {
		element(qtyToReceive_Text).waitUntilVisible();
		return element(qtyToReceive_Text).getText();
	}
}
