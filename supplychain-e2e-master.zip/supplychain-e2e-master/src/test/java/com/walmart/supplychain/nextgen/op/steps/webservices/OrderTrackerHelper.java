package com.walmart.supplychain.nextgen.op.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.op.orderTrackerStatus.OrderTrackerStatus;

import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class OrderTrackerHelper {

	private Logger logger = LogManager.getLogger(this.getClass());
	private Response response;
	private List<String> orderIds = new ArrayList<>();
	private List<String> receivedQty = new ArrayList<>();
	private List<String> openQty = new ArrayList<>();
	private int totalReceivedQty;
	private int totalOpnQty;
	private int totalLoadedQty;
	private int totalShippedQty;
	private int totalDamagedQty;
	private int totalFulfilledQtyInOT;
	private int totalOpnQtyInOT;
	private int totalLoadedQtyInOT;
	private int totalShippedQtyInOT;
	private int totalDamagedQtyInOT;
	private  List<Integer> fulfilledQty = new ArrayList<>();
	private  int totalFulfilledQty;
	private final String jsonPathForPickedQty = "$..pickedQty";
	private final String jsonPathForUomMultiplier = "$..uomMultiplier";
	private final String jsonPathForVnpkMultiplier = "$..vnpkMultiplier";
	private boolean assertTrue=true;
	private List<Integer> uomMultipliers = new ArrayList<>();
	private List<Integer> vnpkMultipliers = new ArrayList<>();
	private boolean orderTrackerStatusCheck;
	private static final String SELECT_QTY_OT_ORDERID="select_qty_ot_orderid";
	private static final String SELECT_ORDER_STATUS_FINALISED_IND_OT_ORDERID="select_order_status_finalised_ind_ot_orderid";
	private static final String ENRICH_QTY_COLUMN="enrich_qty";
	private static final String FULFILLMENT_QTY_COLUMN="fulfillment_qty";
	private static final String DAMAGE_QTY_COLUMN="damage_qty";
	private static final String LOAD_QTY_COLUMN="load_qty";
	private static final String SHIP_QTY_COLUMN="ship_qty";
	private static final String UOM_MULTIPLIER_NBR_COLUMN="uom_multiplier_nbr";
	private static final String VNPK_QTY_COLUMN="vnpk_qty";
	private static final String ORDER_ID_COLUMN="order_id";
	private static final String DELIEVRY_FINALIZED_IND_COLUMN="delivery_finalized_ind";
	private static final String ORDER_TRACK_STATUS_CODE="order_track_status_code";
	private static final String ITEM_NUMEBR_JSON_PATH="$..ordersDetails[*].itemNumber";
	private static final String LOADED_CONTAINERS_JSON_PATH="$..outboundDetails[*].containerIds[*]";


	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	Environment environment;

	@Autowired
	InventorySteps inventorySteps;

	@Autowired
	OrderTrackerStatus ordertrackerStatus;
	
	@Autowired
	DbUtils dbUtils;
	
	@Autowired(required = true)
	IDMHelper idmHelper;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			15);

	public boolean checkPickedQtyInOrderTracker(String status){
		
		String jsonPathFortemNumberWithStatus = "$..ordersDetails[*].itemNumber";
		String testData = (String) tl.get().get("testFlowData");
				
		logger.info("Test flow Data inside method checkPickedQtyInOrderTracker : {}",testData);

		try {
			assertTrue=false;
			List<String> itemNumbers = JsonPath.parse(testData).read(jsonPathFortemNumberWithStatus);
			List<String> uniqueItemNumbers = new ArrayList<>();
			for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
				if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
					uniqueItemNumbers.add(itemNumbers.get(itemNumber));
				}
			}

			for (int itemNumber =0;itemNumber<uniqueItemNumbers.size();itemNumber++) {
				String jsonPathForOIDWithStatus = "$..ordersDetails[?(@.itemNumber=="+uniqueItemNumbers.get(itemNumber)+")].orderId";
				receivedQty.clear();
				orderIds.clear();
				openQty.clear();
				totalReceivedQty = 0;
				totalFulfilledQty = 0;
				totalOpnQty=0;
				fulfilledQty.clear();
				orderIds = JsonPath.parse(testData).read(jsonPathForOIDWithStatus);
				String jPathForQty;
				
				if(Config.DC==DC_TYPE.ACC) {
				jPathForQty = "$..poLineDetails[?(@.itemNumber==" + uniqueItemNumbers.get(itemNumber) + ")].receivingInstructions[?(@.isVTR==false && @.isPbyl==false && @.labelType=='normal')].receivedQuantity";
				} else{
				jPathForQty = "$..poLineDetails[?(@.itemNumber==" + uniqueItemNumbers.get(itemNumber) + ")].receivingInstructions[?(@.isVTR==false && @.isPbyl==false)].receivedQuantity";
				}
				
				String jPathForOPNQty = "$..poLineDetails[?(@.itemNumber==" + uniqueItemNumbers.get(itemNumber) + ")].poVnpkQty";
				receivedQty = JsonPath.parse(testData).read(jPathForQty);
				openQty = JsonPath.parse(testData).read(jPathForOPNQty);
				
				Response getDelresponse = given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
						.get(environment.getProperty("idm_delivery_ep") + idmHelper.getDeliveryNumber());
								
				logger.info("Delivery response "+getDelresponse.asString());
				
				String actualDeliveryStatus=JsonPath.read(getDelresponse.asString(),"deliveryStatus");
				for (int index = 0; index < receivedQty.size(); index++) {
					totalReceivedQty += Integer.parseInt(receivedQty.get(index));
				}
				for (int index = 0; index < openQty.size(); index++) {
					totalOpnQty += Integer.parseInt(openQty.get(index));
				}
				Map<String, String> header = new HashMap<>();

				String getAPIKey = environment.getProperty("api-key");
				
				header.put("api-key", getAPIKey);
				String orderDetailsRequestbody = getOrderDetailsForItems(uniqueItemNumbers.get(itemNumber));
				if(totalReceivedQty<totalOpnQty ){
					if(!actualDeliveryStatus.contains("FNL")){
						orderDetailsRequestbody=orderDetailsRequestbody.replace(Constants.TRACKCOMPLETE, Constants.TRACKPARTIAL);
					}
				}

				response = SerenityRest.given().relaxedHTTPSValidation().headers(getOTHeaders()).body(orderDetailsRequestbody).post((environment.getProperty("ot_search_uri")));
				response.then().statusCode(Constants.SUCESS_STATUS_CODE);

				for (int orderId = 0;orderId<orderIds.size();orderId++) {
					String responseStr = JsonPath.parse(response.getBody().asString()).read("$..[?(@.orderId=='"+orderIds.get(orderId)+"')]",JSONArray.class).toJSONString();

					fulfilledQty = JsonPath.parse(responseStr).read(jsonPathForPickedQty);
					uomMultipliers = JsonPath.parse(responseStr).read(jsonPathForUomMultiplier);
					vnpkMultipliers = JsonPath.parse(responseStr).read(jsonPathForVnpkMultiplier);

					totalFulfilledQty += (fulfilledQty.get(0))*(uomMultipliers.get(0))/(vnpkMultipliers.get(0));
				}

				logger.info("Checking fulfilled and received qty to be same in OT");
				logger.info("Received Qty is : {}",totalReceivedQty);
				logger.info("Fulfilled Qty is : {}",totalFulfilledQty);
				if(totalFulfilledQty!=totalReceivedQty){
					logger.info("fulfilled qty and received qty are different for item : {}",uniqueItemNumbers.get(itemNumber));
					return false;
				} else {
					logger.info("fulfilled qty and received qty are same for item : {}",uniqueItemNumbers.get(itemNumber));
					assertTrue=true;
				}
			}

		} catch (Exception e) {
			throw new TestCaseFailure("Order Tracker Picked Quanity validation failed", e);
		}
		return assertTrue;

	}
	
	private String getOrderDetailsForItems(String itemNumber){
		final String searchOTReqPath = "/TestData/OP/payloadtemplates/searchOrderUsingItemAndStatus.json";
		final String itemNumberJsonPath = "$.itemNumbers";

		try {
			TextParser tp = new TextParser();
			String searchTemplate = tp.readTextFile(searchOTReqPath);

			JSONArray itemArray = createItemArray(itemNumber);

			DocumentContext dc = JsonPath.parse(searchTemplate).set(itemNumberJsonPath, itemArray);
			return StringEscapeUtils.unescapeJava(dc.jsonString());

		} catch(IOException e) {
			logger.error("Exception occurred during IO operation in getSomething. Exception : \n"+e);

			try {
				throw new IOException("Exception thrown back.{}", e);
			} catch (Exception e2) {
				logger.error("Exception in throwing IO Exception :: {}" , e2);
			}

		} catch (URISyntaxException e) {
			logger.error("Exception occurred during URI syntax exception operation in getSomething. Exception : \n"+e);

			try {
				throw new URISyntaxException("Exception thrown back.",e.toString());
			} catch (Exception e2) {
				logger.error("Exception in throwing IO Exception ::\n{}" , e2);
			}
		}
		return null;
	}

	private String getOrderDetailsWithItemNumberOnly(String itemNumber){
		final String searchOTReqPath = "/TestData/OP/payloadtemplates/searchOrderUsingItem.json";
		final String itemNumberJsonPath = "$.itemNumbers";

		try {
			TextParser tp = new TextParser();
			String searchTemplate = tp.readTextFile(searchOTReqPath);

			JSONArray itemArray = createItemArray(itemNumber);

			DocumentContext dc = JsonPath.parse(searchTemplate).set(itemNumberJsonPath, itemArray);
			return StringEscapeUtils.unescapeJava(dc.jsonString());

		} catch(IOException e) {
			logger.error("Exception occurred during IO operation in getSomething. Exception : \n{}",e);

			try {
				throw new IOException("Exception thrown back.", e);
			} catch (Exception e2) {
				logger.error("Exception in throwing IO Exception ::\n" + e2);
			}

		} catch (URISyntaxException e) {
			logger.error("Exception occurred during URI syntax exception operation in getSomething. Exception : \n {}",e);

			try {
				throw new URISyntaxException("Exception thrown back.",e.toString());
			} catch (Exception e2) {
				logger.error("Exception in throwing IO Exception ::\n {}" , e2);
			}
		}
		return null;
	}

	private JSONArray createItemArray(String itemNumber) {

		JSONArray itemArray = new JSONArray();
		itemArray.add(itemNumber);
		return itemArray;
	}

	public void checkOrderTrackerStatus(String status){
		orderTrackerStatusCheck=false;

		String jsonPathForItemNumberWithStatus = "$..ordersDetails[*].itemNumber";

		String testData = (String) tl.get().get("testFlowData");
//		logger.info("Test flow Data is : "+testData);

		List<String> itemNumbers = JsonPath.parse(testData).read(jsonPathForItemNumberWithStatus);
		List<String> uniqueItemNumbers = new ArrayList<>();
		for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
			if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
				uniqueItemNumbers.add(itemNumbers.get(itemNumber));
			}
		}

		for (int itemNumber =0;itemNumber<uniqueItemNumbers.size();itemNumber++) {
			String jsonPathForOIDForItem = "$..ordersDetails[?(@.itemNumber=="+uniqueItemNumbers.get(itemNumber)+")].orderId";


			orderIds.clear();
			orderIds = JsonPath.parse(testData).read(jsonPathForOIDForItem);

			Map<String, String> header = new HashMap<>();

			String getAPIKey = environment.getProperty("api-key");
			header.put("api-key", getAPIKey);

			Assert.assertTrue("Checking if Order Id size is greater than zero", (orderIds.size()>0));
			String orderDetailsRequestbody = getOrderDetailsWithItemNumberOnly(uniqueItemNumbers.get(itemNumber));
			logger.info("Order status check - order details request body {}",orderDetailsRequestbody);
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getOTHeaders()).body(orderDetailsRequestbody).post((environment.getProperty("ot_search_uri")));;
			response.then().statusCode(Constants.SUCESS_STATUS_CODE);

			for (int index = 0;index<orderIds.size();index++) {				
				String responseStr = JsonPath.parse(response.getBody().asString()).read("$..[?(@.orderId=='"+orderIds.get(index)+"')]",JSONArray.class).toJSONString();	
				int statusCode = Integer.parseInt(JsonPath.parse(responseStr).read("$..orderStatus",JSONArray.class).get(0).toString());
				String statusFromOT = ordertrackerStatus.getValue(statusCode);

				logger.info("Checking if expected and actual order status are same in Order tracker");
				logger.info("Excpected order status in OT : {}",status);
				logger.info("Actual order status in OT : {}",statusFromOT);
				com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_ORDER_STATUS_MISMATCH,status,statusFromOT);
			}
		}
	}

	public boolean validateOrderTrackerPostVTR(String status) {
		String jsonPathForVTRedContainer = "";
		String testData = (String) tl.get().get("testFlowData");
		List<String> vtrContainers = JsonPath.parse(testData).read(jsonPathForVTRedContainer);

		Map<String, String> header = new HashMap<>();
		String getAPIKey = environment.getProperty("api-key");
		header.put("api-key", getAPIKey);

		orderTrackerStatusCheck = false;
		for (int index = 0; index<vtrContainers.size();index++) {
			List<String> orderIds = inventorySteps.containerToOrderIdMapping(vtrContainers.get(index));
			for (int orderId=0;orderId<orderIds.size();orderId++) {

				response = SerenityRest.given().relaxedHTTPSValidation().headers(getOTHeaders()).get((environment.getProperty("ot_search_uri")));
				response.then().statusCode(Constants.SUCESS_STATUS_CODE);

				int statusCode = Integer.parseInt(((JSONObject)((JSONArray)JsonPath.parse(response.toString()).read("$..status", JSONArray.class)).get(0)).getAsString("status"));
				String statusFromOT = ordertrackerStatus.getValue(statusCode);

				logger.info("Checking if expected and actual order status are same in Order tracker");
				logger.info("Excpected order status in OT : {}",status);
				logger.info("Actual order status in OT : {}",statusFromOT);
				if(!(statusFromOT.equals(status))){
					logger.info("Expected and actual order status are not same");
					return false;
				} else {
					logger.info("Expected and actual order status are same");
					orderTrackerStatusCheck=true;
				}
			}
		}
		return orderTrackerStatusCheck;
	}
	
	public void checkPickedLoadedShippedQtyInOrderTracker(String status){
		String testFlowData = (String) tl.get().get("testFlowData");
			assertTrue=false;
			List<String> itemNumbers = JsonPath.parse(testFlowData).read(ITEM_NUMEBR_JSON_PATH);
			List<String> uniqueItemNumbers = new ArrayList<>();
			for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
				if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
					uniqueItemNumbers.add(itemNumbers.get(itemNumber));
				}
			}

			for (int itemNumber =0;itemNumber<uniqueItemNumbers.size();itemNumber++) {
				receivedQty.clear();
				orderIds.clear();
				openQty.clear();
				totalOpnQty=0;
				totalReceivedQty = 0;
				totalLoadedQty=0;
				totalShippedQty=0;
				totalDamagedQty=0;
		
				fulfilledQty.clear();
				orderIds = JsonPath.parse(testFlowData).read("$..ordersDetails[?(@.itemNumber=="+uniqueItemNumbers.get(itemNumber)+")].orderId");
				readDatafromTestFlowData(testFlowData,uniqueItemNumbers.get(itemNumber));
				
				Object[] orderIdsArr = new Object[orderIds.size()];
				for (int i = 0; i < orderIds.size(); i++) {
					orderIdsArr[i] = orderIds.get(i);
				}
				
				//Validating PICKED LOADED SHIPPED Qty in OT DB
				Failsafe.with(retryPolicy).run(() -> {
					totalOpnQtyInOT=0;
					totalFulfilledQtyInOT = 0;
					totalLoadedQtyInOT=0;
					totalShippedQtyInOT=0;
					totalDamagedQtyInOT=0;
					logger.info("Fetching order details from OT DB");
					List<Map<String, Object>> otOrderDetails = dbUtils.selectFrom(PRODUCT_NAME.OT,
								dbUtils.transformIntoSpringQuery(environment.getProperty(SELECT_QTY_OT_ORDERID), orderIds.size()), orderIdsArr);
					logger.info("Fetched order details from OT DB");
					com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_DB_ORDERID_RECORD_COUNT_MISMATCH, orderIdsArr.length, otOrderDetails.size());
					for (Map<String, Object> otRecordsMap : otOrderDetails) {
						totalOpnQtyInOT += (Integer.parseInt(otRecordsMap.get(ENRICH_QTY_COLUMN).toString())*Integer.parseInt(otRecordsMap.get(UOM_MULTIPLIER_NBR_COLUMN).toString()))/Integer.parseInt(otRecordsMap.get(VNPK_QTY_COLUMN).toString());
						totalFulfilledQtyInOT += (Integer.parseInt(otRecordsMap.get(FULFILLMENT_QTY_COLUMN).toString())*Integer.parseInt(otRecordsMap.get(UOM_MULTIPLIER_NBR_COLUMN).toString()))/Integer.parseInt(otRecordsMap.get(VNPK_QTY_COLUMN).toString());
						totalLoadedQtyInOT += (Integer.parseInt(otRecordsMap.get(LOAD_QTY_COLUMN).toString())*Integer.parseInt(otRecordsMap.get(UOM_MULTIPLIER_NBR_COLUMN).toString()))/Integer.parseInt(otRecordsMap.get(VNPK_QTY_COLUMN).toString());
						totalShippedQtyInOT += (Integer.parseInt(otRecordsMap.get(SHIP_QTY_COLUMN).toString())*Integer.parseInt(otRecordsMap.get(UOM_MULTIPLIER_NBR_COLUMN).toString()))/Integer.parseInt(otRecordsMap.get(VNPK_QTY_COLUMN).toString());
						totalDamagedQtyInOT += Integer.parseInt(otRecordsMap.get(DAMAGE_QTY_COLUMN).toString())/Integer.parseInt(otRecordsMap.get(VNPK_QTY_COLUMN).toString());
					}	
					switch (status) {
						case "ALL":
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_FULFILLED_QUANTITY_MISMATCH, totalReceivedQty, totalFulfilledQtyInOT);
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_LOADED_QUANTITY_MISMATCH, totalLoadedQty, totalLoadedQtyInOT);
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_SHIPPED_QUANTITY_MISMATCH, totalShippedQty, totalShippedQtyInOT);
							logger.info("Validated PICKED,LOADED,SHIPPED quantities from OT DB");
							break;
						case "PICKED":
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_FULFILLED_QUANTITY_MISMATCH, totalReceivedQty, totalFulfilledQtyInOT);
							logger.info("Validated PICKED quantities from OT DB");
							break;
						case "LOADED":
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_FULFILLED_QUANTITY_MISMATCH, totalReceivedQty, totalFulfilledQtyInOT);
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_LOADED_QUANTITY_MISMATCH, totalLoadedQty, totalLoadedQtyInOT);
							logger.info("Validated PICKED,LOADED quantities from OT DB");
							break;
						case "DAMAGED":
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_FULFILLED_QUANTITY_MISMATCH, totalReceivedQty, totalFulfilledQtyInOT);
							com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_DAMAGED_QUANTITY_MISMATCH, totalDamagedQty, totalDamagedQtyInOT);
							logger.info("Validated PICKED,DAMAGED quantities from OT DB");
							break;
						default:
							break;
						}
						});
				if (!(status.equalsIgnoreCase("DAMAGED"))) {
					validateOrderFinalisation(orderIdsArr);
				}
			}
	}
	
	public void readDatafromTestFlowData(String testFlowData,String itemNumber) {
		String jsonPathForRecQty;
		if(Config.DC==DC_TYPE.ACC) {
			jsonPathForRecQty = "$..poLineDetails[?(@.itemNumber==" + itemNumber + ")].receivingInstructions[?(@.isVTR==false && @.isPbyl==false && @.labelType=='normal')].receivedQuantity";
		} else{
			jsonPathForRecQty = "$..poLineDetails[?(@.itemNumber==" + itemNumber + ")].receivingInstructions[?(@.isPbyl==false)].receivedQuantity";
		}
		String jsonPathForOpnQty = "$..poLineDetails[?(@.itemNumber==" + itemNumber + ")].poVnpkQty";
		receivedQty = JsonPath.parse(testFlowData).read(jsonPathForRecQty);
		for (int index = 0; index < receivedQty.size(); index++) {
			totalReceivedQty += Integer.parseInt(receivedQty.get(index));
		}
		openQty = JsonPath.parse(testFlowData).read(jsonPathForOpnQty);
		for (int index = 0; index < openQty.size(); index++) {
			totalOpnQty += Integer.parseInt(openQty.get(index));
		}
		
//		List<String> loadedContainerList = JsonPath.parse(testFlowData).read(LOADED_CONTAINERS_JSON_PATH);
//		for (String cont : loadedContainerList) {
//			 List<String> actualLoadedQty = JsonPath.parse(testFlowData).read("$..receivingInstructions[?(@.parentContainer=='"+cont+"')].receivedQuantity");
//			 totalLoadedQty+=Integer.parseInt(actualLoadedQty.get(0));
//		}
		totalLoadedQty=totalReceivedQty;
		totalShippedQty=totalLoadedQty;
		
		List<Integer> damagedQtyList = JsonPath.parse(testFlowData).read("$..poLineDetails[?(@.itemNumber==" + itemNumber + ")].receivingInstructions[?(@.isDamage==true)].damageQty");
		for (Integer damagedQty : damagedQtyList) {
			totalDamagedQty+=damagedQty;
		}
	}
	public void validateOrderFinalisation(Object[] orderIdsArr) {
		Failsafe.with(retryPolicy).run(() -> {
			List<Map<String, Object>> otOrderDetailsFnlIndMap = dbUtils.selectFrom(PRODUCT_NAME.OT,
						dbUtils.transformIntoSpringQuery(environment.getProperty(SELECT_ORDER_STATUS_FINALISED_IND_OT_ORDERID), orderIdsArr.length), orderIdsArr);
			com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_DB_ORDERID_RECORD_COUNT_MISMATCH, orderIdsArr.length, otOrderDetailsFnlIndMap.size());
			for (Map<String, Object> orderIdFnlp : otOrderDetailsFnlIndMap) {
				logger.info("Validating Finlaised indicator for an order {} from OT DB",orderIdFnlp.get(ORDER_ID_COLUMN).toString());
				com.walmart.framework.utilities.javautils.Assert.assertTrue(ErrorCodes.OT_ORDER_NOT_FINALISED,Boolean.parseBoolean(orderIdFnlp.get(DELIEVRY_FINALIZED_IND_COLUMN).toString()));
				logger.info("Validated Finlaised indicator for an order {} from OT DB",orderIdFnlp.get(ORDER_ID_COLUMN).toString());
			}
		});
	}
	
	public Headers getOTHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header contentType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(contentType);
		return new Headers(headerList);

	}
	
	public void validateOTOrderStatusAndFnlindicator(String expectedStatus, String expectedFnlIndicator) {
		String testFlowData = (String) tl.get().get("testFlowData");
		List<String> itemNumbers = JsonPath.parse(testFlowData).read(ITEM_NUMEBR_JSON_PATH);
		List<String> uniqueItemNumbers = new ArrayList<>();
		for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
			if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
				uniqueItemNumbers.add(itemNumbers.get(itemNumber));
			}
		}
		for (String itemNum : uniqueItemNumbers) {
			orderIds.clear();
			orderIds = JsonPath.parse(testFlowData).read("$..ordersDetails[?(@.itemNumber=="+itemNum+")].orderId");
			Object[] orderIdsArr = new Object[orderIds.size()];
			for (int i = 0; i < orderIds.size(); i++) {
				orderIdsArr[i] = orderIds.get(i);
			}
			Failsafe.with(retryPolicy).run(() -> {
				boolean actualFnlIndicator=false;
				List<Map<String, Object>> otOrderDetails = dbUtils.selectFrom(PRODUCT_NAME.OT,
					dbUtils.transformIntoSpringQuery(environment.getProperty(SELECT_ORDER_STATUS_FINALISED_IND_OT_ORDERID), orderIds.size()), orderIdsArr);
				com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_DB_ORDERID_RECORD_COUNT_MISMATCH, orderIdsArr.length, otOrderDetails.size());
				for (Map<String, Object> otRecordsMap : otOrderDetails) {
					logger.info("validating order status: {} for an order: {} in OT",expectedStatus,otRecordsMap.get(ORDER_ID_COLUMN));
					actualFnlIndicator=Boolean.parseBoolean(otRecordsMap.get(DELIEVRY_FINALIZED_IND_COLUMN).toString());
					com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_ORDER_STATUS_MISMATCH, expectedStatus, ordertrackerStatus.getValue(Integer.parseInt(otRecordsMap.get(ORDER_TRACK_STATUS_CODE).toString())));
					logger.info("validated order status: {} for an order: {} in OT",expectedStatus,otRecordsMap.get(ORDER_ID_COLUMN));
					logger.info("validating Finalise indicatior for an order: {} in OT",otRecordsMap.get(ORDER_ID_COLUMN));
					com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_ORDER_FINALISATION_IND_MISMATCH, Boolean.parseBoolean(expectedFnlIndicator), actualFnlIndicator);
					logger.info("validated Finalise indicatior for an order: {} in OT",otRecordsMap.get(ORDER_ID_COLUMN));
				}
			});
		}
		
	}
	
	public void validateOTOrderStatus(String expectedStatus) {
		String testFlowData = (String) tl.get().get("testFlowData");
		List<String> itemNumbers = JsonPath.parse(testFlowData).read(ITEM_NUMEBR_JSON_PATH);
		List<String> uniqueItemNumbers = new ArrayList<>();
		for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
			if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
				uniqueItemNumbers.add(itemNumbers.get(itemNumber));
			}
		}
		for (String itemNum : uniqueItemNumbers) {
			orderIds.clear();
			orderIds = JsonPath.parse(testFlowData).read("$..ordersDetails[?(@.itemNumber=="+itemNum+")].orderId");
			Object[] orderIdsArr = new Object[orderIds.size()];
			for (int i = 0; i < orderIds.size(); i++) {
				orderIdsArr[i] = orderIds.get(i);
			}
			Failsafe.with(retryPolicy).run(() -> {
				List<Map<String, Object>> otOrderDetails = dbUtils.selectFrom(PRODUCT_NAME.OT,
					dbUtils.transformIntoSpringQuery(environment.getProperty(SELECT_ORDER_STATUS_FINALISED_IND_OT_ORDERID), orderIds.size()), orderIdsArr);
				com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_DB_ORDERID_RECORD_COUNT_MISMATCH, orderIdsArr.length, otOrderDetails.size());
				for (Map<String, Object> otRecordsMap : otOrderDetails) {
					logger.info("validating order status: {} for an order: {} in OT",expectedStatus,otRecordsMap.get(ORDER_ID_COLUMN));
					com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.OT_ORDER_STATUS_MISMATCH, expectedStatus, ordertrackerStatus.getValue(Integer.parseInt(otRecordsMap.get(ORDER_TRACK_STATUS_CODE).toString())));
					logger.info("validated order status: {} for an order: {} in OT",expectedStatus,otRecordsMap.get(ORDER_ID_COLUMN));
				}
			});
		}
		
	}
}
