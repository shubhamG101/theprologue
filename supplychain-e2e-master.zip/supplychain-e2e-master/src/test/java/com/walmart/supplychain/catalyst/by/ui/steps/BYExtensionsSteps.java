package com.walmart.supplychain.catalyst.by.ui.steps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.javautils.Assert;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.by.ui.pages.BYExtensionsPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.catalyst.by.webservices.steps.BYWebservicesSteps;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYExtensionsSteps extends ScenarioSteps {

	WebDriver driver;
	Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	BYOutboundPage byOutboundPage;

	@Autowired
	BYExtensionsPage byExtensionsPage;

	@Autowired
	BYUiHelper byUiHelper;

	@Autowired
	BYWebservicesSteps byWebServicesSteps;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtil;

	private static final String TEST_FLOW_DATA = "testFlowData";

	private static final String IB_HACCP_LPN_NUMBER_JSON_PATH = "$.testFlowData..receivingInstructions..parentContainer";

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	public void performHACCP() throws InterruptedException {

		byExtensionsPage.ClickOnExpandQCDashboardButton();

		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		List<String> haccpLPN = JsonPath.read(runTimeData, IB_HACCP_LPN_NUMBER_JSON_PATH);

		byExtensionsPage.enterValueUnderFilterTB("rpFilter", "Any", "=", haccpLPN.get(0));
		byExtensionsPage.selectLpn(haccpLPN.get(0));
		byExtensionsPage.existingTempature();
		byExtensionsPage.clickOnActionsButton();
		byExtensionsPage.selectOptionHACCPFromActionsMenu();
		byExtensionsPage.enterPassFailAndSelectFromDD("PASS");
		String tempvalue = "26";
		byExtensionsPage.updateTemperature(tempvalue);
		byExtensionsPage.clickOnExecuteActionButton();
		byExtensionsPage.enterValueUnderFilterTB("rpFilter", "Any", "=", haccpLPN.get(0));
		Failsafe.with(retryPolicy).run(() -> {
			String updatedTemp = byExtensionsPage.updatedTempature();
			int delmi = updatedTemp.indexOf(".");
			Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_TASK_COUNT_FOR_PICKS_GRID, tempvalue,
					updatedTemp.subSequence(0, delmi));
		});
	}

	public void changeInvStatusToAvailable() {
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		List<String> haccpLPN = JsonPath.read(runTimeData, IB_HACCP_LPN_NUMBER_JSON_PATH);

		byExtensionsPage.selectLpn(haccpLPN.get(0));
		byExtensionsPage.clickOnActionsButton();
		byExtensionsPage.selectOptionChangeInvStatusFromActionsMenu();
		byExtensionsPage.clickOnInventoryStatusCodeDropdown();
		byExtensionsPage.selectStatus();
		byExtensionsPage.executeActionButton();
		byExtensionsPage.clickOnCloseButton();

	}

}
