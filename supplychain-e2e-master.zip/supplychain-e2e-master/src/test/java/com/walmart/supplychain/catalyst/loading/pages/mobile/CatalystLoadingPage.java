package com.walmart.supplychain.catalyst.loading.pages.mobile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingHelper;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystLoadingPage  extends SerenityHelper {
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	CatalystUtil catalystUtil;
	
	final String LOADING_MOBILE_ID = "com.walmart.logistics.loading:id/";
	
	@FindBy(id = LOADING_MOBILE_ID+"text_value")
	private WebElement loadingUserNameTextBox;
  
    @FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"text_value' and @text='Password']")
	private WebElement loadingPasswordTextBox;
    
	@FindBy(xpath = "//*[@text='Sign in']")
	private WebElement loadingSignInButton;
	
	@FindBy(xpath = "//*[@text='Which job function are you performing?']")
	private WebElement selectJobText;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"radio_btn_loader']")
	private WebElement loadingOption;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"radio_btn_wrapper']")
	private WebElement wrappingOption;

	@FindBy(xpath = "//*[@text=‘Save’]")
	private WebElement saveButton;
	
	@FindBy(xpath = "//*[@text='Wrapping']")
	private WebElement wrappingTitle;
	
	
	
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"btn_handkey']")
	private WebElement handheldKeyLpnLink;
	
	@FindBy(xpath = "//*[@text='Handkey LPN number']")
	private WebElement handheldKeyTitle;
	
	
	@FindBy(xpath = "//*[@text='LPN number' and @class='android.widget.EditText']")
	private WebElement lpnNumberTextbox;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"btn_haul_single']")
	private WebElement haulMoveSingleLink;
	
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"btn_handkey']")
	private WebElement handheldLocationTitle;
	
	@FindBy(xpath = "//*[@text='Location number']")
	private WebElement handheldLocationTextbox;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"toolbar_btn_signout']")
	private WebElement signOutButton;
			
	@FindBy(xpath = "//*[@text='Are you done for the day?']")
	private WebElement doneForDayTitle;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"radio_btn_yes']")
	private WebElement yesButton;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"dialogPositiveBtn']")
	private WebElement dialogYesButton;
	
	//Loading UI
	
	@FindBy(xpath = "//*[contains(@text,'Scan Staging Lane')]")
	private WebElement scanStagingLaneTitle;

	
	@FindBy(xpath = "//*[@text='Load']")
	private WebElement loadButton;
	
	@FindBy(xpath = "//*[@text='Empty pallet stack']")
	private WebElement emptyPalletStackText;
	
	@FindBy(xpath = "//*[@text='Please confirm empty pallet stack is loaded.']")
	private WebElement confirmEmptyPalletStackDialog;
	
	@FindBy(xpath = "//*[@text='Confirm']")
	private WebElement confirmButton;
	
	@FindBy(xpath = "//*[@text='OK']")
	private WebElement okButton;
	
	@FindBy(xpath = "//*[@text='Scan or handkey seal number' and @class='android.widget.EditText']")
	private WebElement sealNumberTextbox;
	
	@FindBy(xpath = "//*[@text='Close and latch dock door']")
	private WebElement closeAndLatchDockDoorDialog;
	
	//Safety Questions
	@FindBy(xpath = "//*[@text='Door Safety Checklist']")
	private WebElement doorSafetyChecklistTitle;
	
	@FindBy(xpath = "//*[@text='Dock Door number correct?']")
	private WebElement correctDockDoorSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is dock plate in trailer?']")
	private WebElement dockPlateSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is Trailer light on?']")
	private WebElement trailerLightSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Are floor boards in good condition?']")
	private WebElement floorBoardsSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is floor free of spilled liquids or debris?']")
	private WebElement floorFreeOfSpilledLiquidSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Trailer height, Dock Door height adequate for Equipment?']")
	private WebElement trailerDockDoorHeightSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is Load Secure?']")
	private WebElement isLoadSecureSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Dock plate retracted?']")
	private WebElement dockPlateRetractedSafetyQuestion;
	
	@FindBy(xpath = "//*[@text='Is this a swing door trailer?']")
	private WebElement swingDoorTrailerQuestion;
	
	@FindBy(xpath = "//*[@resource-id='"+LOADING_MOBILE_ID+"radio_btn_yesSwingDoor']")
	private WebElement yesSwingDoorButton;
	
	@FindBy(xpath = "//*[@text='Shipment ready to close']")
	private WebElement shipmentReadyToCloseText;
	
	@FindBy(xpath = "//*[@text='Verify all trailer zones are set at the correct temperatures']")
	private WebElement trailerZoneTempMsg;
	
	@FindBy(xpath = "//*[@text='Close shipment']")
	private WebElement closeShipmentButton;
	
	@FindBy(xpath = "//*[@text='Shipment Completed']")
	private WebElement shipmentCompletedMsg;
	
	public void enterLoadingUserName(String userName) {
		element(loadingUserNameTextBox).click();
		element(loadingUserNameTextBox).clear();
		element(loadingUserNameTextBox).sendKeys(userName);
		logger.info("WMT_LOADING : Entered Loading Username");
	}


	public void enterLoadingPassword(String password) {
		element(loadingPasswordTextBox).clear();
		element(loadingPasswordTextBox).sendKeys(password);
		logger.info("WMT_LOADING : Entered Loading Password");
	}

	public void clickOnLoadingSignInButton() {
		element(loadingSignInButton).waitUntilVisible();
		element(loadingSignInButton).click();
		logger.info("WMT_LOADING : Clicked on Loading SignIn Button");
	}
	
	public void verifySelectJobTextIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(selectJobText));
	}
	
	public void clickOnLoadingOption() {
		element(loadingOption).waitUntilVisible();
		element(loadingOption).click();
		logger.info("WMT_LOADING : Clicked on Loading option");
	}
	
	public void clickOnWrappingOption() {
		element(wrappingOption).waitUntilVisible();
		element(wrappingOption).click();
		logger.info("WMT_LOADING : Clicked on Wrapping option");
	}
	
	public void clickOnSaveButton() {
		element(saveButton).waitUntilVisible();
		element(saveButton).click();
		logger.info("WMT_LOADING : Clicked on Save Button");
	}
	
	public void verifyWrappingTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(wrappingTitle));
	}
	
	public void clickOnHandheldKeyLpnLink() {
		element(handheldKeyLpnLink).waitUntilVisible();
		element(handheldKeyLpnLink).click();
		logger.info("WMT_LOADING : Clicked on Handheld Key Lpn Link");
	}
	
	public void verifyHandheldKeyTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(handheldKeyTitle));
	}
	
	public void enterLpn(String lpn) {
		element(lpnNumberTextbox).waitUntilVisible();
		element(lpnNumberTextbox).sendKeys(lpn);
		logger.info("WMT_LAUNCHER : Entered LPN number"+lpn);
	}
	public void clickOnDialogYesButton() {
		element(dialogYesButton).waitUntilVisible();
		element(dialogYesButton).click();
		logger.info("WMT_LOADING : Clicked on Dialog Yes Button");
	}
	
	public void clickOnHaulMoveSingleLink() {
		element(haulMoveSingleLink).waitUntilVisible();
		element(haulMoveSingleLink).click();
		logger.info("WMT_LOADING : Clicked on Haul Move Single Link");
	}
	
	public void verifyHandheldLocationTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(handheldLocationTitle));
	}
	
	public void enterLocation(String location) {
		element(handheldLocationTextbox).waitUntilVisible();
		element(handheldLocationTextbox).sendKeys(location);
		logger.info("WMT_LAUNCHER : Entered Location"+location);
	}
	
	public void clickOnSignOutButton() {
		element(signOutButton).waitUntilVisible();
		element(signOutButton).click();
		logger.info("WMT_LOADING : Clicked on Sign Out Button");
	}
	public void verifyDoneForDayTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(doneForDayTitle));
	}
	
	
	public void verifyDoorSafetyChecklistTitleDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(doorSafetyChecklistTitle));
	}
	
	public void verifyCorrectDockDoorSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(correctDockDoorSafetyQuestion));
	}
	
	public void verifyDockPlateSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(dockPlateSafetyQuestion));
	}
	
	public void verifyTrailerLightSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerLightSafetyQuestion));
	}
	
	public void verifyFloorBoardsSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(floorBoardsSafetyQuestion));
	}
	public void verifyFloorFreeOfSpilledLiquidSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(floorFreeOfSpilledLiquidSafetyQuestion));
	}
	public void verifyTrailerDockDoorHeightSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerDockDoorHeightSafetyQuestion));
	}
	public void verifyIsLoadSecureSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(isLoadSecureSafetyQuestion));
	}
	public void verifyDockPlateRetractedSafetyQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(dockPlateRetractedSafetyQuestion));
	}
	public void verifySwingDoorTrailerQuestionIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(swingDoorTrailerQuestion));
	}
	
	public void clickOnYesSwingDoorButton() {
		element(yesSwingDoorButton).waitUntilVisible();
		element(yesSwingDoorButton).click();
		logger.info("WMT_LOADING : Clicked on Yes Swing door");
	}
	
	public void verifyScanStagingLaneTitleIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(scanStagingLaneTitle));
	}
	
	public void verifyEmptyPalletStackTextIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(emptyPalletStackText));
	}
	public void verifyConfirmEmptyPalletStackDialogIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(confirmEmptyPalletStackDialog));
	}
	
	public void clickOnLoadButton() {
		element(loadButton).waitUntilVisible();
		element(loadButton).click();
		logger.info("WMT_LOADING : Clicked on Load Button");
	}
	
	public void clickOnConfirmButton() {
		element(confirmButton).waitUntilVisible();
		element(confirmButton).click();
		logger.info("WMT_LOADING : Clicked on Confirm Button");
	}
	public void clickOnOkButton() {
		element(okButton).waitUntilVisible();
		element(okButton).click();
		logger.info("WMT_LOADING : Clicked on OK Button");
	}
	
	public void enterSealNumber(String sealNumber) {
		element(sealNumberTextbox).waitUntilVisible();
		element(sealNumberTextbox).sendKeys(sealNumber);
		logger.info("WMT_LAUNCHER : Entered Seal number"+sealNumber);
	}
	
	
	public void verifyTrailerZoneTempMsgIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(trailerZoneTempMsg));
	}
	
	public void verifyShipmentReadyToCloseTextIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(shipmentReadyToCloseText));
	}
	
	public void clickOnCloseShipmentButton() {
		element(closeShipmentButton).waitUntilVisible();
		element(closeShipmentButton).click();
		logger.info("WMT_LOADING : Clicked on Close Shipment Button");
	}
	
	public void verifyCloseAndLatchDockDoorDialogIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(closeAndLatchDockDoorDialog));
	}
	
	public void verifyShipmentCompletedMsgIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(shipmentCompletedMsg));
	}
	
}
