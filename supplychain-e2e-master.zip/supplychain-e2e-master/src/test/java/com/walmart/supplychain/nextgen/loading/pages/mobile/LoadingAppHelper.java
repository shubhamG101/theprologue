package com.walmart.supplychain.nextgen.loading.pages.mobile;

public class LoadingAppHelper {

}
