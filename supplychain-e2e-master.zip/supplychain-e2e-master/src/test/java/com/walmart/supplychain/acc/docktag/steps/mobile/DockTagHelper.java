package com.walmart.supplychain.acc.docktag.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mongodb.BasicDBObject;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.parser.ParseException;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class DockTagHelper {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	MongoUtil mongoUtil;

	@Autowired
	Environment environment;

	@Autowired
	InventoryHelper inventoryHelper;
	
	private String dockTagIdFieldName = "dockTagId";
	private String docktagDbName = "receive";
	private String dockTagCollectionName = "docktags";
	private String docTagStatusFieldName = "status";
	private JsonUtils jsonUtil = new JsonUtils();
	String testFlowData;

	private String recContDelievryNumFieldName = "deliveryNumber";
	private String reccontainerExceptionFieldName = "containerException";
	private String recContDbName = "receive_container";
	private String recContcollectionName = "containers";
	private String recContTrackingIdFieldName = "trackingId";

	private String floorLineMapDoorNumFieldName = "doorNumber";
	private String floorLineMapDbName = "receive";
	private String floorLineMapCollectionName = "floorlinemapping";
	private String floorLineMapLocationFieldName = "mappedFloorLineLocation";

	private static final String CONTAINEREXCEPTION = "DT";
	private static final String CONT_STATUS_JSON_PATH = "$.containerStatus";
	private static final String INVENTORY_SEARCH_ENDPOINT_STATUS = "inventory_search_ep_status";
	private static final String INVENTORY_QUERYPARAM_KEY = "inventory_ep_qp";
	private static final String LOCCATION_DOOR_FLOOR_LINE_MAP_ENDPOINT = "get_mapped_floorline_for_door_ep";
	private static final String FLOOR_LINE_TAG_JSON_PATH= "$..tags..tagNames[*]]";
	private Response locationresponse ;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	Logger logger = LogManager.getLogger(this.getClass());

	public Map<String, String> getDockTagStatusInRec(List<String> dockTag) throws SQLException {
		String dockTagStatus = null;
		Map<String, String> dockTagMap = new HashMap<String, String>();

		BasicDBObject searchQuery = new BasicDBObject();

		for (String doc : dockTag) {

			searchQuery.put(dockTagIdFieldName, doc);
			List<String> dockTagStatusRes = mongoUtil.getDatafromDB(docktagDbName, dockTagCollectionName, searchQuery,
					docTagStatusFieldName);

			if ((dockTagStatusRes != null) && (!dockTagStatusRes.isEmpty())) {
				dockTagStatus = dockTagStatusRes.get(0);
				dockTagMap.put(doc, dockTagStatus);
			}
		}
		return dockTagMap;
	}

	public String getDockTagStatusInInvent(String dockTag) {
		
		Response response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
				.get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_STATUS) + dockTag
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		
//		Response response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_STATUS) + dockTag
//				+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		String responseStr = response.getBody().asString();
		DocumentContext parsedJsonInvRes = JsonPath.parse(responseStr);
		return parsedJsonInvRes.read(CONT_STATUS_JSON_PATH);
	}
	
	public int getInverntoryStatusCodeForTheDeletedDocktag(String dockTag) {
		
		Response response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
				.get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_STATUS) + dockTag
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		return response.getStatusCode();
	}

	public String getFloorLineForTheDoor(String doorNumber) throws SQLException {
		
		Failsafe.with(retryPolicy).run(() -> {
			locationresponse = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).body("[{\"names\":[\""+doorNumber+"\"]}]").when()
					.post(environment.getProperty(LOCCATION_DOOR_FLOOR_LINE_MAP_ENDPOINT));
			Assert.assertEquals(ErrorCodes.LOCATION_UNABLE_TO_FETCH_MAPPED_FLOOR_LINE, Constants.SUCESS_STATUS_CODE,
					locationresponse.getStatusCode());
		});
		List<String> mappedFloorLineList = JsonPath.parse(locationresponse.asString()).read(FLOOR_LINE_TAG_JSON_PATH);
		return mappedFloorLineList.get(0);
	}
}
