package com.walmart.supplychain.baja.loading.loadingstep;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReleaseDetails;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.baja.loading.loadinghelper.BajaLoadingHelper;
import com.walmart.supplychain.baja.of.step.OrderFulfilmentSteps;
import com.walmart.supplychain.baja.of.step.PublishTruckupFile;
import com.walmart.supplychain.nextgen.loading.pages.ui.LoadingPage;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingSteps;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;
import io.restassured.response.Response;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BajaLoadingSteps {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	Environment environment;

	@Autowired
	BajaLoadingHelper loadingHelper;

	@Autowired
	PublishTruckupFile truckUpUpload;

	@Steps
	LoadingSteps loadingSteps;

	@Autowired
	LoadingPage loadingPage;
	
	@Autowired
	OrderFulfilmentSteps orderFulfillmentSteps;

	private String TEST_FLOW_DATA = "testFlowData";

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	JsonUtils jsonUtil = new JsonUtils();


	public void verifyTruckDownFile() {

		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray releaseNumber = JsonPath.parse(testData).read("$..releaseNumber");

			Object[] lpnArr = new Object[releaseNumber.size()];
			for (int i = 0; i < releaseNumber.size(); i++) {
				lpnArr[i] = releaseNumber.get(i);
			}

			List<Map<String, Object>> truckDownQuery;
			logger.info("Truck down needs to be verified for " + releaseNumber.size() + "releases");

			truckDownQuery = dbUtils.selectFrom(Config.DC, dbUtils.transformIntoSpringQuery(
					environment.getProperty("truck_down_loading"), releaseNumber.size()), lpnArr);
			Assert.assertEquals(ErrorCodes.BAJA_TRUCK_DOWN_FAIL, truckDownQuery.size(), 1);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying truck down file in loading", e);
		}
	}

	public void uploadTruckUpFile() {

		try {
			String lpn = getLabelDetails();
			logger.info("Label data is " + lpn);

			String reverseLpn = reverse(lpn.trim());
			logger.info("Reversed string is " + reverseLpn.toString());

			logger.info("Updating the truck up file with the reveresed LPN " + reverseLpn);
			loadingHelper.updateTruckUpFile(FileNames.BAJA_BULK_PICK_FILE, reverseLpn);

			logger.info("Uploading truck up file");
			truckUpUpload.uploadTruckUpfile();

			logger.info("Login into loading app and route the truck up file for creating load id");
			loadingSteps.open_Loading_Page();
			loadingSteps.login_to_Loading();

			Failsafe.with(retryPolicy).run(() -> {
				if (retry) {
					loadingPage.closeDriver();
					logger.info("Retrying.......:");
					loadingSteps.open_Loading_Page();
					loadingSteps.login_to_Loading();

				}
				retry = true;
			});

			loadingPage.clickOnRoutingFileUpload();
			logger.info("Clicked on routing upload icon");

			logger.info("Validing if load Id is generated after uploading the file");
			verifyLoadIdPostRoutingFileUpload();

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while uploading truck file from shortrec", e);
		}

	}

	public void verifyLoadIdPostRoutingFileUpload() {

		try {
			int loadId=0;

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray releaseNumber = JsonPath.parse(testData).read("$..releaseNumber");

			Object[] lpnArr = new Object[releaseNumber.size()];
			for (int i = 0; i < releaseNumber.size(); i++) {
				lpnArr[i] = releaseNumber.get(i);
			}

			List<Map<String, Object>> loadIdQuery;
			logger.info("Load Id down needs to be verified for " + releaseNumber.get(0) + "releases");

			loadIdQuery = dbUtils.selectFrom(Config.DC, dbUtils.transformIntoSpringQuery(
					environment.getProperty("load_id_post_routing_upload"), releaseNumber.size()), lpnArr);
			Assert.assertEquals(ErrorCodes.BAJA_LOADID_FAIL, loadIdQuery.size(), 1);

			if (loadIdQuery.size() > 0) {
				loadId = (Integer) loadIdQuery.get(0).get("load_id");
				logger.info("LPN details is " + loadId);
			}
			
			testData = jsonUtil.setJsonAtJsonPath(testData, loadId, "$.testFlowData.releaseDetails[*].loadId");
			tl.get().put(TEST_FLOW_DATA, testData);
			logger.info("test flow data after updating load id:"
					+ tl.get().get(TEST_FLOW_DATA));
						
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying truck down file in loading", e);
		}
	}

	public String reverse(String lpn) {

		String lastTwelveDigitOfLpn = lpn.substring(lpn.length() - 12);

		StringBuilder input = new StringBuilder();

		// append a string into StringBuilder input1
		input.append(lastTwelveDigitOfLpn);

		// reverse StringBuilder input1
		input = input.reverse();

		return input.toString();
	}

	private String getLabelDetails() throws JsonProcessingException, ParseException {
		
	    String testData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONArray releaseNumber = JsonPath.parse(testData).read("$..releaseNumber");
		JSONArray destnum = JsonPath.parse(testData).read("$..testFlowData.ordersDetails[*].destinationNum");

		String lpndetails = null;

		Object[] lpnArr = new Object[releaseNumber.size()];
		for (int i = 0; i < releaseNumber.size(); i++) {
			lpnArr[i] = releaseNumber.get(i);
		}

		List<Map<String, Object>> labelQuery;
		logger.info("Label info needs to be retrieved for " + releaseNumber.size() + "releases");

		labelQuery = dbUtils.selectFrom(Config.DC, dbUtils.transformIntoSpringQuery(
				environment.getProperty("label_details_shipment_manager"), releaseNumber.size()), lpnArr);
		Assert.assertTrue(ErrorCodes.BAJA_TRUCK_DOWN_FAIL, labelQuery.size() > 0);

		if (labelQuery.size() > 0) {
			lpndetails = (String) labelQuery.get(0).get("shipment_container_id");
			logger.info("LPN details is " + lpndetails);
		}

		// add label details to test flow data
		//poDetails -> poLineDetails -> receiving instruction -> cntr

		PoDetail poObj = new PoDetail();
		List<PoDetail> listOfPOObj = new ArrayList<>();

		PoLineDetail poLineDetails = new PoLineDetail();
		List<PoLineDetail> poLineDetail = new ArrayList<>();

		ReceivingInstruction recv = new ReceivingInstruction();
		List<ReceivingInstruction> recvingInstructionList = new ArrayList<>();
		
		List<String> childList = new ArrayList<>();
		String cntr = lpndetails.trim();
		childList.add(cntr);
		recv.setParentContainer(cntr);
		//recv.setMessageId(getMessageIDfromDB());
		recv.setMessageId(getMessageIDAPI());
		recv.setLabelType("normal");
		//Assigning one destination only even if multiple dest are there since for baja we can load dest with different containers
		recv.setDestNumber(destnum.get(0).toString());
		recv.setChildContainers(childList);
		recv.setChannelType("SSTK");
		recv.setIsPbyl(false);
		recv.setIsVTR(false);
		recv.setIsDamage(false);
		recv.setReceivedQuantity("1");
		recvingInstructionList.add(recv);
		
		poLineDetails.setReceivingInstructions(recvingInstructionList);
		poLineDetail.add(poLineDetails);
		
		poObj.setPoLineDetails(poLineDetail);
		listOfPOObj.add(poObj);
		
		String updatedtestflowdata;
		JSONArray listofPOJson = jsonUtil.converyListToJsonArray(listOfPOObj);
		updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofPOJson, "$.testFlowData.poDetails");
		tl.get().put(TEST_FLOW_DATA, updatedtestflowdata);
		logger.info("test flow data after building the receiving instruction for all the labels:"
				+ tl.get().get(TEST_FLOW_DATA));

		return lpndetails;
	}

	private String getMessageIDAPI() {

		Response resp = orderFulfillmentSteps.verifyBulkPick();		
		JSONArray domainNumber = JsonPath.parse(resp.getBody().asString()).read("$..bulkPickId");
		logger.info("Domain ID is "+domainNumber.get(0).toString());
		
		return domainNumber.get(0).toString();
	}

	private String getMessageIDfromDB() {
	
		try {
			String messageId=null;

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray releaseNumber = JsonPath.parse(testData).read("$..releaseNumber");

			Object[] lpnArr = new Object[releaseNumber.size()];
			for (int i = 0; i < releaseNumber.size(); i++) {
				lpnArr[i] = releaseNumber.get(i);
			}

			List<Map<String, Object>> messageIdQuery;
			logger.info("Message Id down needs to be fetched from DB" + releaseNumber.get(0) + "releases");

			messageIdQuery = dbUtils.selectFrom(Config.DC, dbUtils.transformIntoSpringQuery(
					environment.getProperty("of_fulfillment_id"), releaseNumber.size()), lpnArr);
			Assert.assertEquals(ErrorCodes.OF_MESSAGEIDID_FAIL, messageIdQuery.size(), 1);

			if (messageIdQuery.size() > 0) {
				messageId = (String) messageIdQuery.get(0).get("fulfillment_demand_id");
				logger.info("Message is is " + messageId);
			}	
			return messageId;
					
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying truck down file in loading", e);
		}	
	}
}