package com.walmart.supplychain.catalyst.by.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.catalyst.by.ui.steps.BYInventorySteps;
import com.walmart.framework.utilities.javautils.JavaUtils;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.WebElementFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYProblemsPage  extends SerenityHelper{
	
	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;
	
	@Autowired
	CatalystUtil catalystUtil;
	
	@Autowired
	JavaUtils javaUtils;
	
	
	@FindBy(xpath = "//span[@id='ext-comp-1020_header_hd-textEl'][normalize-space()='Problems']")
	public WebElement problemsPageHeading;
	
	@FindBy(xpath = "//span[@id='button-1050-btnWrap']")
	public WebElement actionsButton;
	
	@FindBy(xpath = "//span[normalize-space()='Update Reason Code and Ticket Number']")
	public WebElement updateReasonCodeAndTicketNumber;
	
	@FindBy(xpath = "//input[@class='toggle_switch']")
	public WebElement toggleFlag;
	
	@FindBy(xpath = "//input[@name='prbticknbr1107']")
	public WebElement problemTicketNumber;
	
	@FindBy(xpath = "//input[contains(@name,'problemType')]")
	public WebElement problemTypeDropdown;
	
	@FindBy(xpath = "//ul[@class='x-boundlist-item']/li[text()='Not on PO']")
	public WebElement problemType;
	
	@FindBy(xpath = "//span[text()='Execute Action']/following-sibling::span[1]")
	public WebElement executeActionButton;
	
	@FindBy(xpath = "//iframe[contains(@name,'Problems')]")
	private WebElement problemFrameSwitch;
	
	static String ProblemTicketNum="";
	
	public void verifyProblemsPageHeading() {
//		getDriver().switchTo().frame(problemFrameSwitch);
		element(problemsPageHeading).waitUntilVisible();
//		element(problemsPageHeading).isDisplayed();
		catalystUtil.verifyElementIsDisplayed(problemsPageHeading);
	}
	
	private WebElement getLpnCheckbox(String lpn) {
		return getDriver().findElement(By.xpath("//a[text()='"+lpn+"']/ancestor::td[1]/preceding-sibling::td[1]/div/div[@class='x-grid-row-checker']"));
	}
	
	public void selectLpn(String lpn) throws Exception {
		element(getLpnCheckbox(lpn)).waitUntilVisible();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(20000);
		element(getLpnCheckbox(lpn)).click();
		logger.info("Clicked on Lpn checkbox in BY UI ==========");
	}
	
	public void clickOnActionsButton() {
		element(actionsButton).waitUntilVisible();
		element(actionsButton).click();
		logger.info("Clicked on Actions Button in BY UI ==========");
	}
	
	public void clickUpdateReasonCodeAndTicketNumber() {
		element(updateReasonCodeAndTicketNumber).waitUntilVisible();
		element(updateReasonCodeAndTicketNumber).click();
		logger.info("Clicked on Update Reason Code and Ticket Number in BY UI ==========");
	}
	
	public void toggleProblemTicketFlag() {
		element(toggleFlag).waitUntilVisible();
		element(toggleFlag).click();
		logger.info("Clicked on Toggle Problem Ticket Number button in BY UI ==========");
	}
	
	public void verifyProblemTicketTextBoxIsEnabled() {
		try {
			element(problemTicketNumber).isEnabled();
			logger.info("Problem Ticket Number textbox enabled in BY UI ==========");
		} catch (Exception e){
			logger.info("Problem Ticket Number textbox not enabled in BY UI ==========");
		}
		
	}
	
	public void enterProblemTicket() {
		element(problemTicketNumber).waitUntilVisible();
		element(problemTicketNumber).click();
		ProblemTicketNum="AUTO_PROB"+ javaUtils.randonNumberGenerator(3);
		element(problemTicketNumber).sendKeys(ProblemTicketNum);
		logger.info("Entered Problem Ticket Number in BY UI ========== : {}", ProblemTicketNum);
	}
	
	public void clickProblemTypeDropdown() {
		element(problemTypeDropdown).waitUntilVisible();
		element(problemTypeDropdown).sendKeys("Not On PO");
		logger.info("Clicked problem type dropdown in BY UI ==========");
	}
	
	public void selectProblemType() {
//		element(problemType).waitUntilVisible();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		List<WebElement> dropdownOptions = driver.findElements(By.xpath("//ul[contains(@id, 'react-autosuggest')]//li"));
//		dropdownOptions.get(3).click();
		element(problemType).click();
		logger.info("Selected Problem Type in BY UI ==========");
	}
	
	public void clickOnExecuteActionButton() {
		element(executeActionButton).waitUntilVisible();
		element(executeActionButton).click();
		logger.info("Clicked on Execute Action button in BY UI ==========");
	}

}
