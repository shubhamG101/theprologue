package com.walmart.supplychain.nextgen.inventory.scenariosteps.webservices;

import com.fasterxml.jackson.core.JsonProcessingException;
//import com.walmart.supplychain.nextgen.inventory.steps.ui.InventoryStepsUI;
import com.walmart.supplychain.nextgen.idm.steps.webservices.MyAppsSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class InventoryScenarios {

	@Steps
	InventorySteps inventorySteps;

	// @Steps
	// InventoryStepsUI invrStp;

	@Steps
	MyAppsSteps myAppsSteps;

	private int reasonCode = 200;

	@And("^user verifies the container creation in inventory$")
	public void user_verifies_the_container_creation_in_inventory() {

		inventorySteps.validateContainerData();
		
	}
	
	@And("^user verifies the gfcs container creation in inventory$")
	public void user_verifies_the_gfcs_container_creation_in_inventory() {

		inventorySteps.validateGFCSContainerData();

		
	}


	@Given("^user does a VTR on the received DA and SSTK Container from the Inventory App$")
	public void user_does_a_VTR_on_the_received_DA_Container_from_the_Inventory_App() {

		inventorySteps.performVtr(reasonCode);

	}
	
	@Given("^user does split pallet for grocery$")
	public void user_does_split_pallet() {
		inventorySteps.performSplitPallet();

	}
	@And("^user verifies VTR on finalized container$")
	public void user_verifies_VTR_on_finalized_container() {
		inventorySteps.validateVtrOnFinalizedContainer();
	}
	
	@And("^user verifies the container in inventory after VTR$")
	public void user_verifies_the_container_in_inventory_after_VTR() {
		inventorySteps.validateVTRCntrs();
	}

	@And("^user verifies container as \"([^\"]*)\" in Inventory$")
	public void checkContainerStatusInInventory(String cntrStatus) {
		inventorySteps.validateContainerStatus(cntrStatus);
	}
	
	@Then("^user creates \"([^\"]*)\" securement containers$")
	public void user_creates_dummey_container_in_inventory(String typeOfContainer) {
		inventorySteps.createDummyCntrs(typeOfContainer);
	}
	
	
	@Then("^validate status as \"([^\"]*)\" in inventory$")
	public void validateOnHoldStatus(String status) {
		inventorySteps.validateContainerOnHold(status);
	}
	
	@Then("^validate vtrd container status in inventory$")
	public void validateVTRContainerStatus() {
		inventorySteps.validateDeletedContrForVTR();
	}
	
	@Then("^validate vtrd container status in inventory from pallet Correction$")
	public void validateVTRContainerStatusForPalletCorrection() {
		inventorySteps.validateDeletedContrFromPalletCorrection();
	}
	
	@Given("^user verifies the container status as \"([^\"]*)\" in Inventory$")
	public void user_verifies_the_container_status_in_inventory(String ctrStatus){
	   
		inventorySteps.validateContainerStatusGateOut(ctrStatus);
	    
	}
	
	@Then("^user verifies \"([^\"]*)\" mcb container in Inventory$")
	public void user_verifies_the_mcbcontainer(String mcbStatus){	   
		if (mcbStatus.equalsIgnoreCase("IN_PROGRESS")) {
			inventorySteps.validateInprogressMcbContainer();	  
		}
		else if (mcbStatus.equalsIgnoreCase("COMPLETED")) {
			inventorySteps.validateCompletedMcbContainer();	  
		}
	}
	
	@Then("^user verifies the inventory Balance on Hand for \"([^\"]*)\"$")
	public void userValidatesInventoryBOHPostReceiving(String type)  {
		inventorySteps.validateAndGetBOHResponse();
	}
	@Then("^Witron sends the RTC message to Inventory$")
	public void witronSendsRTC()  {
		inventorySteps.witronSendRTC();
	}
	
	@Then("^user verifies the Inventory containers are deleted after RTC message from Witron$")
	public void inventoryContainerDeletionAfterRTC()  {
		inventorySteps.validateDeletedContrForRTC();
	}
	
	
	@Then("^user verifies MCB pallet deleted in Inventory$")
	public void verifiesMCBPalletDeletedInInventory(){
		inventorySteps.validateDeletedMCBConatainer();
	}

	@Given("^user launches inventory using Myapps$")
	public void inventoryLogin(){
		myAppsSteps.launchInventoryUsingMyApps();
	}

	@Then("^user does a VTR for multiple containers from the Inventory App$")
	public void performVtrInWeb(){
		inventorySteps.performVtrInWeb();
	}
	

}