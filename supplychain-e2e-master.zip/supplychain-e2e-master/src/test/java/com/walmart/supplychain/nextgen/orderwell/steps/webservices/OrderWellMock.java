package com.walmart.supplychain.nextgen.orderwell.steps.webservices;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.framework.supplychain.domain.ow.Order;
import com.walmart.framework.supplychain.domain.ow.OrderWellOrders;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OrderWellMock {

	@Autowired
    Environment endpoints;
	@Autowired
	JavaUtils javaUtil;
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	Logger logger = LogManager.getLogger(this.getClass());

	private static final String INVALID_RESPONSE_CODE_TEXT = "Invalid response code ";
	public static final int SUCESS_STATUS_CODE = 201;
	private static final String JSON_FORMAT = "application/json";
	private static final String MOCK_ADMIN_URL_KEY = "mock_admin_url";
	private static final String OW_URL_KEY = "ow_get_ep";
	private static final String MOCK_ID_LIST_KEY="listOfMocksToBeRemoved";
	private static final String OW_FILE_PATH = "/TestData/ow.txt";
	
	TextParser textParser = new TextParser();
	public void createOrders(JSONArray ordersArray) {
		String uuid = javaUtil.getUUID();
		String orderWellGetUrl=endpoints.getProperty(OW_URL_KEY);
		String orderWellMockUrl=endpoints.getProperty(MOCK_ADMIN_URL_KEY);
		String currentDate=javaUtil.getCurrentDateAndTime("MM-dd-yyyy hh:mm:ss 'UTC'", "UTC");
		try {
		ObjectMapper om=new ObjectMapper();
		OrderWellOrders orderWellOrders=new OrderWellOrders();
		List<Order> listOfOrders=new ArrayList<>();
		int sourceNumber=0;
		int itemNumber=0;
		String channel=null;
		orderWellOrders.setNextPage(null);
		for (int orderIndex = 0; orderIndex < ordersArray.size(); orderIndex++) {
			JSONObject orderObj=(JSONObject) ordersArray.get(orderIndex);
			Order order=om.readValue(orderObj.toJSONString(),Order.class);
			order.setOrderDate(currentDate);
			listOfOrders.add(order);
			sourceNumber=order.getSourceNumber();
			itemNumber=order.getWmtItemNumber();
			if(order.getPoType().equals("20")) {
			channel="SSTK";
			}else {
			channel="DA";
			}
			
		}
		orderWellGetUrl=MessageFormat.format(orderWellGetUrl,""+sourceNumber,""+itemNumber,channel);
		orderWellOrders.setOrders(listOfOrders);
		logger.info("Orders:"+om.writeValueAsString(orderWellOrders));
		String reqBody = textParser.readTextFile(OW_FILE_PATH);
		reqBody = javaUtil.format(reqBody,uuid,orderWellGetUrl,om.writeValueAsString(orderWellOrders));
		logger.info("uuid:"+uuid);
		Response resp = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT).body(reqBody)
				.post(orderWellMockUrl);
		logger.info("response from mock:"+resp.asString());
		if(resp.getStatusCode()!=201) {
			throw new AutomationFailure("Unable to Create Mock Orders. Response code"+resp.getStatusCode());
		}
		List<String> listOfMocksToBeRemoved=(List<String>) threadLocal.get().get(MOCK_ID_LIST_KEY);
		if(threadLocal.get().get(MOCK_ID_LIST_KEY)!=null) {
			listOfMocksToBeRemoved.addAll((ArrayList<String>) threadLocal.get().get(MOCK_ID_LIST_KEY));
		}else {
			listOfMocksToBeRemoved=new ArrayList<>();
		}
		listOfMocksToBeRemoved.add(uuid);
		threadLocal.get().put(MOCK_ID_LIST_KEY, listOfMocksToBeRemoved);
		} catch (Exception e) {
			logger.error(e);
			throw new AutomationFailure("Something went wrong while creating the mock orders", e);
		}
	}

	public void getOrders() {

	}
	
}
