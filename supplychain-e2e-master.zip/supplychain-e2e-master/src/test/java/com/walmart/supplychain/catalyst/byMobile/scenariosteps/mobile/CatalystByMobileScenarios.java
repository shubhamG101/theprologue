package com.walmart.supplychain.catalyst.byMobile.scenariosteps.mobile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.by.steps.mobile.CatalystByMobileSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.strati.libs.commons.configuration.ConfigurationException;
import net.thucydides.core.annotations.Steps;

public class CatalystByMobileScenarios {
	@Steps
	CatalystByMobileSteps catalystByMobileSteps;
	
	@Given("^user performs partial inventory move task$")
	public void userPerformsPartialInventoryMove() throws JsonProcessingException, InterruptedException, ConfigurationException {
		catalystByMobileSteps.performPartialInventoryMove();
	}
	
	@Given("^user performs Inventory Status Change to \"([^\"]*)\" status$")
	public void userPerformsInventoryStatusChange(String newStatus) throws JsonProcessingException, InterruptedException, ConfigurationException {
		catalystByMobileSteps.performInventoryStatusChange(newStatus);
	}
	
	@Given("^user performs manual putaway task to \"([^\"]*)\" Location$")
	public void userPerformsManualPutaway(String desiredLocation) throws JsonProcessingException, InterruptedException, ConfigurationException {
		catalystByMobileSteps.performManualPutaway(desiredLocation);
	}
	
	@Then("^user performs directed putaway task to \"([^\"]*)\" location$")
	public void userPerformsDirectedPutawayToSpecificLocation(String expectedLocation) {
		catalystByMobileSteps.performsDirectedPutaway(expectedLocation);
	}
}
