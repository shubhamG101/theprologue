package com.walmart.supplychain.nextgen.common;

import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.camel.model.dataformat.XStreamDataFormat.ConverterList;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.DeleteResult;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.db.QueryHelper;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.dcfin.scenariosteps.db.DcFinSteps;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.thor.DCFIN.steps.DCFINSteps;

import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class PreRunCleanup extends ScenarioSteps {

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	private BeanFactory beanFactory;

	Logger logger = LoggerFactory.getLogger(PreRunCleanup.class);

	@Autowired
	JsonUtils jsonUtils = new JsonUtils();

	@Autowired
	Environment environment;

	@Autowired
	Environment queries;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	IDMHelper idmHelper;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	RDCUtil rdcUtil;

	@Steps
	DcFinSteps dcfinSteps;

	QueryHelper queryHelper = new QueryHelper();

	private final String ITEM_JSON_PATH = "$.testFlowData.poDetails[*].poLineDetails[*].itemNumber";

	@Step
	public void cleanupReceiving() {

		String testFlowData = threadLocal.get().get("testFlowData").toString();

		MongoTemplate mongoReceiveTemplate = beanFactory.getBean(MongoTemplate.class, "receive");

		MongoTemplate mongoInboundDoc = beanFactory.getBean(MongoTemplate.class, "inbound_document");

		MongoTemplate mongoReceiveContainerTemplate = beanFactory.getBean(MongoTemplate.class, "receive_container");

		JSONArray poNumArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");

		ArrayList<String> deliveryArr = new ArrayList<>();

		for (int i = 0; i < poNumArr.size(); i++) {

			String purchaseReferenceNumber = poNumArr.get(i).toString();

			Query purchaseRefQuery = new Query();
			purchaseRefQuery.addCriteria(Criteria.where("purchaseReferenceNumber").is(purchaseReferenceNumber));
			String[] purchaseRefTables = { "completed-purchasereferences", "overageqtylimits", "receipts",
					"instructions", "overage_quantity_threshold" };

			Query purchaseRef2 = new Query();
			purchaseRef2.addCriteria(
					Criteria.where("deliveryDocuments.purchaseReferenceNumber").is(purchaseReferenceNumber));

			DeleteResult addr = mongoReceiveTemplate.getCollection("availabledeliverydocuments")
					.deleteMany(purchaseRef2.getQueryObject());

			logger.info("Deleted " + addr.getDeletedCount()
					+ " number of documents from the availabledeliverydocuments collection for the purchase reference number : "
					+ purchaseReferenceNumber);

			for (String tableName : purchaseRefTables) {

				DeleteResult deleteResult = mongoReceiveTemplate.getCollection(tableName)
						.deleteMany(purchaseRefQuery.getQueryObject());

				logger.info("Deleted " + deleteResult.getDeletedCount() + " number of documents from the " + tableName
						+ " collection for the purchase reference number : " + purchaseReferenceNumber);
			}

			Query containersQuery = new Query();
			containersQuery.addCriteria(Criteria.where("contents.purchaseReferenceNumber").is(purchaseReferenceNumber));
			DeleteResult deleteResult = mongoReceiveContainerTemplate.getCollection("containers")
					.deleteMany(containersQuery.getQueryObject());

			logger.info("Deleted " + deleteResult.getDeletedCount()
					+ " number of documents from the containers collection for the purchase reference number : "
					+ purchaseReferenceNumber);

			Query prQ = new Query();
			prQ.fields().include("_id");
			prQ.addCriteria(Criteria.where("purchaseReferenceNumbers").is(purchaseReferenceNumber));

			MongoCursor<Document> deliveryIterator = mongoInboundDoc.getCollection("delivery")
					.find(prQ.getQueryObject()).iterator();

			while (deliveryIterator.hasNext()) {
				Document doc = deliveryIterator.next();
				String deliveryNumber = doc.get("_id").toString();
				deliveryArr.add(deliveryNumber);
			}

		}

		for (int i = 0; i < deliveryArr.size(); i++) {

			String deliveryNumber = deliveryArr.get(i).toString();

			Query deliveryNumberQuery = new Query();
			deliveryNumberQuery.addCriteria(Criteria.where("deliveryNumber").is(deliveryNumber));
			String[] delveryNumTables = { "deliveries", "delivery_update_event", "deliveryItem", "items", "printjobs",
					"problems" };

			for (String tableName : delveryNumTables) {

				DeleteResult deleteResult = mongoReceiveTemplate.getCollection(tableName)
						.deleteMany(deliveryNumberQuery.getQueryObject());

				logger.info("Deleted " + deleteResult.getDeletedCount() + " number of documents from the " + tableName
						+ " collection for delivery number : " + deliveryNumber);
			}
		}
	}

	public void cleanUpOP(int itemNo) {
		try {
			Object[] objArr = new Object[1];
			objArr[0] = itemNo;
			int deleteCount;
			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_whse_order"), objArr[0]);
			logger.info("deleted:{} rows from whse_order table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_item_del_om"), objArr[0]);
			logger.info("deleted:{} rows from po_item_dlvr table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_alloc_order"), objArr[0]);
			logger.info("deleted:{} rows from alloc_order table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_item_del_oa"), objArr[0]);
			logger.info("deleted:{} rows from po_item_delivery table as part of OP cleanup", deleteCount); // check

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_item_del_oa"), objArr[0]);
			logger.info("deleted:{} rows from po_item_delivery table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_opr"), objArr[0]);
			logger.info("deleted:{} rows from order_pick_reference table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_eor"), objArr[0]);
			logger.info("deleted:{} rows from enrich_order_reference table as part of OP cleanup", deleteCount);

			logger.info("Clean up completed for item:{}", itemNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cleanUpopRDC(int itemNo) {
		try {
			Object[] objArr = new Object[1];
			objArr[0] = itemNo;
			int deleteCount;
			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_whse_order"), objArr[0]);
			logger.info("deleted:{} rows from whse_order table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_item_del_om"), objArr[0]);
			logger.info("deleted:{} rows from po_item_dlvr table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_alloc_order"), objArr[0]);
			logger.info("deleted:{} rows from alloc_order table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_item_del_oa"), objArr[0]);
			logger.info("deleted:{} rows from po_item_delivery table as part of OP cleanup", deleteCount); // check

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_item_del_oa"), objArr[0]);
			logger.info("deleted:{} rows from po_item_delivery table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_opr"), objArr[0]);
			logger.info("deleted:{} rows from order_pick_reference table as part of OP cleanup", deleteCount);

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_eor"), objArr[0]);
			logger.info("deleted:{} rows from enrich_order_reference table as part of OP cleanup", deleteCount);

			logger.info("Clean up completed for item:{}", itemNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Step
	public void cleanUpopRDC() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray itemArray = JsonPath.read(testFlowData, ITEM_JSON_PATH);
		for (int i = 0; i < itemArray.size(); i++) {
			logger.info("Clean up the data for item:{}", itemArray.get(i).toString());
			cleanUpopRDC(Integer.parseInt(itemArray.get(i).toString()));
		}

	}

	@Step
	public void cleanUpOP() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray itemArray = JsonPath.read(testFlowData, ITEM_JSON_PATH);
		for (int i = 0; i < itemArray.size(); i++) {
			logger.info("Clean up the data for item:{}", itemArray.get(i).toString());
			cleanUpOP(Integer.parseInt(itemArray.get(i).toString()));
		}
	}

	@Step
	public void cleanupOf() {

		String testFlowData = threadLocal.get().get("testFlowData").toString();
		MongoTemplate mongoInboundDoc = beanFactory.getBean(MongoTemplate.class, "inbound_document");

		MongoTemplate mongoDaFulfillmentDaTemplate = beanFactory.getBean(MongoTemplate.class, "da_fulfillment_da");

		MongoTemplate mongoDaFulfillmentSstkTemplate = beanFactory.getBean(MongoTemplate.class, "da_fulfillment_sstk");

		MongoTemplate mongoFulfillmentDb = beanFactory.getBean(MongoTemplate.class, "fulfillment_db");

		JSONArray poNumArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");

		ArrayList<String> deliveryArr = new ArrayList<>();
		ArrayList<String> messageIds = new ArrayList<>();

		/*
		 * Delete on the basis of Purchase Reference number
		 */

		for (int i = 0; i < poNumArr.size(); i++) {

			String purchaseReferenceNumber = poNumArr.get(i).toString();

			Query prQ = new Query();
			prQ.fields().include("purchaseCompanyId");
			prQ.addCriteria(Criteria.where("purchaseReferenceNumbers").is(purchaseReferenceNumber));

			MongoCursor<Document> deliveryIterator = mongoInboundDoc.getCollection("delivery")
					.find(prQ.getQueryObject()).iterator();

			while (deliveryIterator.hasNext()) {
				Document doc = deliveryIterator.next();
				String deliveryNumber = doc.get("_id").toString();
				deliveryArr.add(deliveryNumber);
			}
			Query ffmInstruction = new Query();
			ffmInstruction.addCriteria(Criteria.where("containerInput.inboundDocuments.purchaseReferenceNumber")
					.is(purchaseReferenceNumber));

			MongoCursor<Document> daFfmIter = mongoDaFulfillmentDaTemplate.getCollection("fulfillment_instruction")
					.find(ffmInstruction.getQueryObject()).iterator();

			while (daFfmIter.hasNext()) {
				Document doc = daFfmIter.next();
				String messageId = doc.get("messageId").toString();
				messageIds.add(messageId);
			}
			MongoCursor<Document> sstkFfmIter = mongoDaFulfillmentSstkTemplate.getCollection("fulfillment_instruction")
					.find(ffmInstruction.getQueryObject()).iterator();

			while (sstkFfmIter.hasNext()) {
				Document doc = sstkFfmIter.next();
				String messageId = doc.get("messageId").toString();
				messageIds.add(messageId);
			}

			DeleteResult ffmInstrDeleteResult = mongoDaFulfillmentDaTemplate.getCollection("fulfillment_instruction")
					.deleteMany(ffmInstruction.getQueryObject());

			logger.info("Deleted " + ffmInstrDeleteResult.getDeletedCount()
					+ " number of documents from the fulfillment_instruction collection for the purchase reference number : "
					+ purchaseReferenceNumber);

			mongoDaFulfillmentSstkTemplate.getCollection("fulfillment_instruction")
					.deleteMany(ffmInstruction.getQueryObject());

			logger.info("Deleted " + ffmInstrDeleteResult.getDeletedCount()
					+ " number of documents from the fulfillment_instruction collection for the purchase reference number : "
					+ purchaseReferenceNumber);
		}

		/*
		 * Delete on the basis of item number
		 */

		JSONArray itemArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poLineDetails[*].itemNumber",
				JSONArray.class);

		for (int i = 0; i < itemArr.size(); i++) {

			int itemNumber = Integer.parseInt(itemArr.get(i).toString());

			Query daffmdaSoftAlloc = new Query();
			daffmdaSoftAlloc.addCriteria(Criteria.where("itemNumber").is(itemNumber));

			DeleteResult softAllocDeleteResult = mongoDaFulfillmentDaTemplate.getCollection("soft_allocation")
					.deleteMany(daffmdaSoftAlloc.getQueryObject());

			logger.info("Deleted " + softAllocDeleteResult.getDeletedCount()
					+ " number of documents from the soft_allocation collection for the item number : " + itemNumber);

			mongoDaFulfillmentSstkTemplate.getCollection("soft_allocation")
					.deleteMany(daffmdaSoftAlloc.getQueryObject());

			logger.info("Deleted " + softAllocDeleteResult.getDeletedCount()
					+ " number of documents from the soft_allocation collection for the item number : " + itemNumber);
		}

		/*
		 * Delete on the basis of delivery number
		 */

		for (int i = 0; i < deliveryArr.size(); i++) {
			String deliveryNumber = deliveryArr.get(i).toString();
			Query ffmDelivery = new Query();
			ffmDelivery.addCriteria(Criteria.where("deliveryNumber").is(deliveryNumber));
			DeleteResult delCollDeleteResult = mongoFulfillmentDb.getCollection("delivery_collection")
					.deleteMany(ffmDelivery.getQueryObject());

			logger.info("Deleted " + delCollDeleteResult.getDeletedCount()
					+ " number of documents from the delivery_collection collection for the delivery number : "
					+ deliveryNumber);
		}

		/*
		 * Delete on the basis of message ids
		 */

		for (int i = 0; i < messageIds.size(); i++) {

			String messageId = messageIds.get(i).toString();

			Query eventsFfmDb = new Query();
			eventsFfmDb.addCriteria(Criteria.where("correlationId").is(messageId));

			Query fulfilmentsFfmDb = new Query();
			fulfilmentsFfmDb.addCriteria(Criteria.where("fulfillmentId").is(messageId));

			DeleteResult eventsDeleteResult = mongoFulfillmentDb.getCollection("events")
					.deleteMany(eventsFfmDb.getQueryObject());

			logger.info("Deleted " + eventsDeleteResult.getDeletedCount()
					+ " number of documents from the events collection for the message id : " + messageId);

			DeleteResult ffcDeleteResult = mongoFulfillmentDb.getCollection("fulfillment_collection")
					.deleteMany(fulfilmentsFfmDb.getQueryObject());

			logger.info("Deleted " + ffcDeleteResult.getDeletedCount()
					+ " number of documents from the fulfillment_collection collection for the message id : "
					+ messageId);

			DeleteResult seqDeleteResult = mongoFulfillmentDb.getCollection("fulfillment_sequencing")
					.deleteMany(fulfilmentsFfmDb.getQueryObject());

			logger.info("Deleted " + seqDeleteResult.getDeletedCount()
					+ " number of documents from the fulfillment_sequencing collection for the message id : "
					+ messageId);

			DeleteResult ffmSummaryDeleteResult = mongoFulfillmentDb.getCollection("fulfillment_summary")
					.deleteMany(fulfilmentsFfmDb.getQueryObject());

			logger.info("Deleted " + ffmSummaryDeleteResult.getDeletedCount()
					+ " number of documents from the fulfillment_summary collection for the message id : " + messageId);

			DeleteResult ffmUnitCollDeleteResult = mongoFulfillmentDb.getCollection("fulfillment_unit_collection")
					.deleteMany(fulfilmentsFfmDb.getQueryObject());

			logger.info("Deleted " + ffmUnitCollDeleteResult.getDeletedCount()
					+ " number of documents from the fulfillment_unit_collection collection for the message id : "
					+ messageId);
		}
	}

	public void cleanupIbd() {

		String testFlowData = threadLocal.get().get("testFlowData").toString();

		MongoTemplate mongoInboundDoc = beanFactory.getBean(MongoTemplate.class, "inbound_document");

		JSONArray poNumArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");

		ArrayList<String> deliveryArr = new ArrayList<>();

		for (int i = 0; i < poNumArr.size(); i++) {

			String purchaseReferenceNumber = poNumArr.get(i).toString();

			// ﻿container
			Query prQ = new Query();
			prQ.addCriteria(Criteria.where("containerItems.purchaseReferenceNumber").is(purchaseReferenceNumber));

			DeleteResult containerDeleteResult = mongoInboundDoc.getCollection("container")
					.deleteMany(prQ.getQueryObject());

			logger.info("Deleted " + containerDeleteResult.getDeletedCount()
					+ " number of documents from the container collection for the purchase reference number : "
					+ purchaseReferenceNumber);

			// ﻿delivery
			Query prQ2 = new Query();
			prQ2.addCriteria(Criteria.where("deliveryDocuments.purchaseReferenceNumber").is(purchaseReferenceNumber));

			DeleteResult deliveryDeleteResult = mongoInboundDoc.getCollection("delivery")
					.deleteMany(prQ2.getQueryObject());

			logger.info("Deleted " + deliveryDeleteResult.getDeletedCount()
					+ " number of documents from the delivery collection for the purchase reference number : "
					+ purchaseReferenceNumber);

			// ﻿purchaseReference
			Query prQ3 = new Query();
			prQ3.addCriteria(Criteria.where("_id").is(purchaseReferenceNumber));

			DeleteResult purchaseReferenceDeleteResult = mongoInboundDoc.getCollection("purchaseReference")
					.deleteMany(prQ3.getQueryObject());

			logger.info("Deleted " + purchaseReferenceDeleteResult.getDeletedCount()
					+ " number of documents from the purchaseReference collection for the purchase reference number : "
					+ purchaseReferenceNumber);

			MongoCursor<Document> deliveryIterator = mongoInboundDoc.getCollection("delivery")
					.find(prQ.getQueryObject()).iterator();

			while (deliveryIterator.hasNext()) {
				Document doc = deliveryIterator.next();
				String deliveryNumber = doc.get("_id").toString();
				deliveryArr.add(deliveryNumber);
			}

		}

		for (int i = 0; i < deliveryArr.size(); i++) {

			String deliveryNumber = poNumArr.get(i).toString();

			Query prQ1 = new Query();
			prQ1.addCriteria(Criteria.where("_id").is(deliveryNumber));
			// ﻿deliveryReceipt -> ﻿_id [deliveryNumber]
			DeleteResult deliveryReceiptDeleteResult = mongoInboundDoc.getCollection("deliveryReceipt")
					.deleteMany(prQ1.getQueryObject());

			logger.info("Deleted " + deliveryReceiptDeleteResult.getDeletedCount()
					+ " number of documents from the deliveryReceipt collection for the purchase reference number : "
					+ deliveryNumber);
		}

	}

	@Step
	public void msSqlQueryCheck() {

		List<Map<String, Object>> resultSet = dbUtils.selectFrom(DC_TYPE.ATLAS,
				"SELECT * FROM [gdm_db].[dbo].[Delivery]");
		logger.info("result is :{}", resultSet.get(1).get("deliveryNumber"));

	}

	@Step
	public void cleanupReceivingAtlas() {

		String testFlowData = threadLocal.get().get("testFlowData").toString();
		JSONArray poNumArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");
		for (int i = 0; i < poNumArr.size(); i++) {
			Response deleteReceiptsTable = SerenityRest.given().relaxedHTTPSValidation()
					.headers(receivingHelper.getReceivingHeaders()).when().delete(MessageFormat
							.format(environment.getProperty("delete_receipts_table_ep"), (String) poNumArr.get(i)));
			deleteReceiptsTable.then().statusCode(200);
			Response deleteInstructionTable = SerenityRest.given().relaxedHTTPSValidation()
					.headers(receivingHelper.getReceivingHeaders()).when().delete(MessageFormat
							.format(environment.getProperty("delete_instruction_table_ep"), (String) poNumArr.get(i)));
			deleteInstructionTable.then().statusCode(200);
			logger.info(" ****** Deleted receiving Receitps and Instructions for PO  : {}", poNumArr.get(i));
		}

		Object[] poArr = new Object[poNumArr.size()];
		for (int k = 0; k < poNumArr.size(); k++) {
			poArr[k] = (String) poNumArr.get(k);
			List<Map<String, Object>> deliveryNumber = dbUtils.selectFrom(PRODUCT_NAME.IDM,
					environment.getProperty("gdm_get_delivery_number"), poArr[k]);
			logger.info("deliveryNumber  : >>" + deliveryNumber.toString());
			for (Map map : deliveryNumber) {
				String deliveryNo = map.get("delivery_number").toString();
				logger.info("Deleting delivery {} details from receiving table ", deliveryNo);

				SerenityRest.given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders()).when()
						.delete(MessageFormat.format(environment.getProperty("delete_print_job_ep"), deliveryNo));
				// deletePrintjobTable.then().statusCode(Constants.SUCESS_STATUS_CODE);

				SerenityRest.given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders()).when()
						.delete(MessageFormat.format(environment.getProperty("delete_containers_ep"), deliveryNo));
				// deleteContainerTable.then().statusCode(Constants.SUCESS_STATUS_CODE);
				logger.info(" ****** Deleted receiving data for delivery : {}", deliveryNo);

			}

		}
		logger.info("Cleared data from receiving tables");

	}

	@Step
	public void cleanUpGDM() {
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		List<String> poNumArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");
		for (int k = 0; k < poNumArr.size(); k++) {
			List<Map<String, Object>> deliveryList = dbUtils.selectFrom(PRODUCT_NAME.IDM,
					environment.getProperty("gdm_get_delivery_number"), poNumArr.get(k));
			for (Map map : deliveryList) {
				String deliveryNo = map.get("delivery_number").toString();
				String deleteUrl = MessageFormat.format(environment.getProperty("idm_delivery_delete"), deliveryNo);
				Response resp = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders())
						.delete(deleteUrl);
				logger.info("GDM Delete resp for delivery {} -> {}", deliveryNo, resp.getStatusCode());
			}
			if (!deliveryList.isEmpty())
				logger.info("Cleared data from GDM");
			else
				logger.info("No Existing Delivery found for this PO");

		}
	}

	@Step
	public void cleanUpGDMByItem() {
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		List<String> itemList = JsonPath.parse(testFlowData)
				.read("$.testFlowData.poDetails[*].poLineDetails[*].itemNumber");
		Object[] itemListArr = new Object[itemList.size()];
		for (int i = 0; i < itemList.size(); i++) {
			itemListArr[i] = itemList.get(i);
		}

		List<Map<String, Object>> poMaps = dbUtils.selectFrom(PRODUCT_NAME.OP,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_get_po_for_item"), itemList.size()),
				itemListArr);

		if (poMaps.size()>0) {
			for (Map<String, Object> poMap : poMaps) {
				List<Map<String, Object>> deliveryList = dbUtils.selectFrom(PRODUCT_NAME.IDM,
						environment.getProperty("gdm_get_delivery_number"), poMap.get("ref_asn_po_nbr").toString());
				for (Map map : deliveryList) {
					String deliveryNo = map.get("delivery_number").toString();
					String deleteUrl = MessageFormat.format(environment.getProperty("idm_delivery_delete"), deliveryNo);
					Response resp = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders())
							.delete(deleteUrl);
					logger.info("GDM Delete resp for delivery {} -> {}", deliveryNo, resp.getStatusCode());
				}
				if (!deliveryList.isEmpty())
					logger.info("Cleared data from GDM");
				else
					logger.info("No Existing Delivery found for this PO");
			}
		}
	}

	@Step
	public void cleanUpGDMForPharmacy(String deliveryNo) {
		String deleteUrl = MessageFormat.format(environment.getProperty("idm_delivery_delete"), deliveryNo);
		Response resp = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders())
				.delete(deleteUrl);
		logger.info("GDM Delete resp for delivery {} -> {}", deliveryNo, resp.getStatusCode());
	}

	@Step
	public void cleanUpOPAtlas() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray itemArray = JsonPath.read(testFlowData, ITEM_JSON_PATH);
		for (int i = 0; i < itemArray.size(); i++) {
			logger.info("Clean up the data for item:{}", itemArray.get(i));
			if (Config.DC == DC_TYPE.SAMS && Config.ENV == ENVIRONMENT.PROD) {
				cleanUpOMForItemSams(Integer.parseInt(itemArray.get(i).toString()));
				cleanUpOAForItemSams(Integer.parseInt(itemArray.get(i).toString()));
			} else {
				cleanUpOPForItemAtlas(Integer.parseInt(itemArray.get(i).toString()));
			}
		}

	}

	@Step
	public void cleanUpOTAtlas() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray itemArray = JsonPath.read(testFlowData, ITEM_JSON_PATH);
		for (int i = 0; i < itemArray.size(); i++) {
			logger.info("Clean up the data for item for OT:{}", itemArray.get(i));
			cleanUpOTForItemAtlas(Integer.parseInt(itemArray.get(i).toString()));
		}

	}

	@Step
	public void cleanUpOTAtlasForAddedLine(String itemNumber) {
		logger.info("Clean up the data for item for OT:{}", itemNumber);
		cleanUpOTForItemAtlas(Integer.parseInt(itemNumber));
	}

	public void cleanUpOPForItemAtlas(int itemNumber) {
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_whse_order"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_po_item_dlvr"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_alloc_order_pick"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_alloc_order"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_po_item_delivery"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("order_refresh_cleanup"), itemNumber);

		logger.info("Deleted Item Number {} from OP tables", itemNumber);
	}

	public void cleanUpOTForItemAtlas(int itemNumber) {
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_eor"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_opr"), itemNumber);
		logger.info("Deleted Item Number {} from OT tables", itemNumber);
	}

	public void cleanUpOMForItemSams(int itemNumber) {
		dbUtils.deleteFrom(PRODUCT_NAME.OM, queries.getProperty("op_delete_whse_order"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OM, queries.getProperty("op_delete_po_item_dlvr"), itemNumber);
		logger.info("Deleted Item Number {} from OM tables", itemNumber);
	}

	public void cleanUpOAForItemSams(int itemNumber) {
		dbUtils.deleteFrom(PRODUCT_NAME.OA, queries.getProperty("op_delete_alloc_order_pick"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OA, queries.getProperty("op_delete_alloc_order"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.OA, queries.getProperty("op_delete_po_item_delivery"), itemNumber);
		logger.info("Deleted Item Number {} from OA tables", itemNumber);
	}

	public void cleanUpDCFINWACForItemThor(int itemNumber) {
		dbUtils.deleteFrom(PRODUCT_NAME.DCFIN, queries.getProperty("delete_dcfin_wac"), itemNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.DCFIN, queries.getProperty("delete_dcfin_boh"), itemNumber);
	}

	@Step
	public void cleanUpOf() {
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		List<String> poNumArr = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");
		for (String poNumber : poNumArr) {
			List<Map<String, Object>> deliveryNumber = dbUtils.selectFrom(PRODUCT_NAME.IDM,
					environment.getProperty("gdm_get_delivery_number"), poNumber);
			logger.info("deliveryNumber is:{} ", deliveryNumber);
			if (!deliveryNumber.isEmpty()) {
				List<Map<String, Object>> fulfillmentid = null;
				for (Map map : deliveryNumber) {
					String deliveryNo = map.get("delivery_number").toString();
					logger.info("Getting fulfillmentIds for delivery number ::{}", deliveryNo);
					fulfillmentid = dbUtils.selectFrom(PRODUCT_NAME.FM,
							environment.getProperty("of_get_fulfillment_id"), deliveryNo);
					logger.info("fulfillmentid for the given delivery" + fulfillmentid);
					cleanUpOfBasedOnDeliveryNumber(deliveryNo);
				}
				if ((!fulfillmentid.isEmpty() && Config.DC != DC_TYPE.ATLAS)
						&& (!fulfillmentid.isEmpty() && Config.DC != DC_TYPE.ACC)) {
					for (Map map : fulfillmentid) {
						cleanUpOfBasedOnFulfillmentId(map.get("fulfillment_id").toString().trim());
					}
				}
			}
		}

	}

	public void cleanUpOfBasedOnDeliveryNumber(String deliveryNumber) {
		logger.info("Deleting Delivery Number {}", deliveryNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.FM, environment.getProperty("of_delete_fulfillment"), deliveryNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.FM, environment.getProperty("of_delete_fulfillment_summary"), deliveryNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.FM, environment.getProperty("of_delete_fulfillment_unit"), deliveryNumber);
		dbUtils.deleteFrom(PRODUCT_NAME.FM, environment.getProperty("of_delete_delivery"), deliveryNumber);
	}

	public void cleanUpOfBasedOnFulfillmentId(String fulfillmentId) {
		logger.info("Deleting data for fulfillment id ::{}", fulfillmentId);
		dbUtils.deleteFrom(PRODUCT_NAME.FM, environment.getProperty("of_delete_fulfillment_sequence"), fulfillmentId);
		dbUtils.deleteFrom(PRODUCT_NAME.PLANNER, environment.getProperty("of_delete_fulfillment_plan"), fulfillmentId);
	}

	public void cleanUpSorter() {

		int deleteCount;
		deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_sorter_destination"));
		logger.info("deleted:{} rows from destination_door_assignment table as part of SORTER cleanup", deleteCount);

	}

	public void cleanUpOPBaja() {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		List<String> itemArray = JsonPath.read(testFlowData, "$..itemNumber");
		Set<String> uniqueItems = new HashSet<String>(itemArray);
		logger.info("Unique items size {}: ", uniqueItems.size());

		for (String item : uniqueItems) {

			logger.info("Clean up the data for item:{}", item);
			try {
				Object[] objArr = new Object[1];
				objArr[0] = item;
				int deleteCount;

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_whse_order"), objArr[0]);
				logger.info("deleted:{} rows from whse_order table as part of OP cleanup", deleteCount);

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_exception_order"),
						objArr[0]);
				logger.info("deleted:{} rows from exception_order table as part of OP cleanup", deleteCount);

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_enrich_order"), objArr[0]);
				logger.info("deleted:{} rows from enrich_order table as part of OP cleanup", deleteCount);

				logger.info("Clean up completed for item:{}", item);
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while op clean up", e);
			}
		}
	}

	public void cleanUpInventoryBaja() {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		List<String> itemArray = JsonPath.read(testFlowData, "$..itemNumber");
		Set<String> uniqueItems = new HashSet<String>(itemArray);
		logger.info("Unique items size {}: ", uniqueItems.size());

		for (String item : uniqueItems) {

			logger.info("Clean up the data for item:{}", item);
			try {
				Object[] objArr = new Object[1];
				objArr[0] = item;
				int deleteCount;

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_exception_inventory"));
				logger.info("deleted:{} rows from cntr table as part of inventory cleanup", deleteCount);

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_management_inventory_item"),
						objArr[0]);
				logger.info("deleted:{} rows from cntr table as part of inventory cleanup", deleteCount);

				deleteCount = dbUtils.deleteFrom(Config.DC,
						environment.getProperty("delete_management_inventory_container"), objArr[0]);
				logger.info("deleted:{} rows from cntr table as part of inventory cleanup", deleteCount);

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("update_container_inventory"));
				logger.info("deleted:{} rows from cntr table as part of inventory cleanup", deleteCount);

				deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_inventory_container"));
				logger.info("deleted:{} rows from cntr table as part of inventory cleanup", deleteCount);
				logger.info("Clean up completed for item:{}", item);
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while inventory clean up", e);
			}
		}
	}

	public void cleanUpLoading() {

		try {
			int deleteCount;

			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_routing_number_loading"));
			logger.info("deleted:{} rows from loading where release is not completed as part of loading cleanup",
					deleteCount);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while loading clean up", e);
		}
	}

	public void cleanUpWitronOP(List itmesList) {

		Date currDate = new Date();
		DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr = destDf.format(currDate) + " 00:00:00";
		logger.info("date:" + dateStr);

		Object[] itemArr = new Object[itmesList.size()];
		for (int i = 0; i < itmesList.size(); i++) {
			itemArr[i] = itmesList.get(i);
		}

		dbUtils.deleteFrom(PRODUCT_NAME.OP,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_delete_whse_order"), itemArr.length),
				itemArr);
		dbUtils.deleteFrom(PRODUCT_NAME.OP,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_delete_alloc_order_pick"), itemArr.length),
				itemArr);
		dbUtils.deleteFrom(PRODUCT_NAME.OP,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_delete_alloc_order"), itemArr.length),
				itemArr);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, dbUtils.transformIntoSpringQuery(
				environment.getProperty("op_delete_wave_plan_enrich_order"), itemArr.length), itemArr);
		dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_wave_default_plan"));
		// dbUtils.deleteFrom(PRODUCT_NAME.OP,
		// queries.getProperty("opv_publish_audit_info"), dateStr);
		// dbUtils.deleteFrom(PRODUCT_NAME.OP,dbUtils.transformIntoSpringQuery(environment.getProperty("opv_publish_audit_info"),
		// 1),dateStr);
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_enrich_order_reference"),
				environment.getProperty("facility_num"));
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_pick_reference"),
				environment.getProperty("facility_num"));
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_ship_reference"),
				environment.getProperty("facility_num"));
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_alloc_order_reference"),
				environment.getProperty("facility_num"));
		dbUtils.deleteFrom(PRODUCT_NAME.OT, queries.getProperty("ot_delete_fulfillment_distribution"),
				environment.getProperty("facility_num"));
		logger.info("Deleted Item Numbers from Witron OP tables");

	}

	public void cleanUpWitronCycleWave() {
		try {
			dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_sch_batch_loc_mapping"));
			dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_sch_day"));
			dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_schedule"));
			dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_batch_destination"));
			dbUtils.deleteFrom(PRODUCT_NAME.OP, queries.getProperty("op_delete_batch"));
		} catch (Exception e) {
			throw new AutomationFailure("Failed to clean up cycle wave DB", e);
		}
	}

	public void cleanUpWitronLoading() {
		try {
			logger.info("Deleting Load tables:" + queries.getProperty("delete_load"));
			dbUtils.deleteFrom(PRODUCT_NAME.LOADING, queries.getProperty("delete_load"),
					environment.getProperty("facility_num"));

			// List<Map<String, Object>> loadIDsList =
			// dbUtils.selectFrom(PRODUCT_NAME.LOADING,
			// queries.getProperty("select_witron_loadId"),
			// environment.getProperty("facility_num"));
			// logger.info("deliveryNumber : >>"+loadIDsList.toString());
			//
			// List loadList = new ArrayList();
			// for (Map map : loadIDsList) {
			// loadList.add(map.get("load_id").toString());
			// }
			//
			// Object[] loadArr = new Object[loadList.size()];
			// for (int i = 0; i < loadList.size(); i++) {
			// loadArr[i] = loadList.get(i);
			// }
			//
			// if(loadList.size()>0) {

			// dbUtils.deleteFrom(PRODUCT_NAME.LOADING,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_load_shipment"),
			// loadArr.length),loadArr);
			// dbUtils.deleteFrom(PRODUCT_NAME.LOADING,
			// queries.getProperty("delete_load_shipment"));
			// dbUtils.deleteFrom(PRODUCT_NAME.LOADING,
			// queries.getProperty("delete_shipping_container"));
			// dbUtils.deleteFrom(PRODUCT_NAME.LOADING,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_shipping_container"),
			// loadArr.length),loadArr);
			// dbUtils.deleteFrom(PRODUCT_NAME.LOADING,
			// queries.getProperty("delete_container_distribution"));
			// dbUtils.deleteFrom(PRODUCT_NAME.OP,dbUtils.transformIntoSpringQuery(environment.getProperty("delete_container_distribution"),
			// loadArr.length),loadArr);
			// }
		} catch (Exception e) {
			throw new AutomationFailure("Failed to clean up Loading DB", e);
		}
	}

	public void cleanUpWitronInventory(List itmesList) {
		Object[] itemArr = new Object[itmesList.size()];
		for (int i = 0; i < itmesList.size(); i++) {
			itemArr[i] = itmesList.get(i);
		}

		dbUtils.deleteFrom(PRODUCT_NAME.INV,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_delete_inv_rotate_date"), itemArr.length),
				itemArr);
		dbUtils.deleteFrom(PRODUCT_NAME.INV,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_delete_inv_channel_type"), itemArr.length),
				itemArr);
		dbUtils.deleteFrom(PRODUCT_NAME.INV,
				dbUtils.transformIntoSpringQuery(environment.getProperty("op_delete_inv_order_alloc"), itemArr.length),
				itemArr);
		logger.info("Deleted Item Numbers from Witron Inventory tables");
	}

	public void cleanupMCB() {
		int deleteCount;
		deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_mcb_child_containers"));
		logger.info("deleted:{} rows from mcb_child_container table as part of MCB cleanup", deleteCount);

		deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_mcb_mcb_master_container"));
		logger.info("deleted:{} rows from mcb_master_container table as part of MCB cleanup", deleteCount);
	}

	@Step
	public void cleanDCfin() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> itemList = JsonPath.read(testFlowData, ITEM_JSON_PATH);
		List<String> poNumList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");

		dcfinSteps.cleanDCfinDB(poNumList, itemList);

	}

	public void cleanRDS() {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		List<String> poArray = JsonPath.read(testFlowData, "$..poNumber");
		Set<String> uniquePO = new HashSet<String>(poArray);
		logger.info("Unique PO size {}: ", uniquePO.size());

		for (String po : uniquePO) {

			logger.info("Clean up the data for PO:{}", po);
			try {
				Object[] objArr = new Object[1];
				objArr[0] = po;
				int updateCount;

				// Updating dc_receiver for quantities and final_ts
				updateCount = dbUtils.updateFrom(Config.DC, environment.getProperty("update_dc_receiver"), objArr[0]);
				logger.info("Updated dc_receiver and number of rows updated " + updateCount);

				// Updating dc_common:pharm_po_ln_pedigree_recvg for received_qty
				updateCount = dbUtils.updateFrom(Config.DC,
						environment.getProperty("delete_pharm_po_ln_pedigree_recvg"), objArr[0]);
				logger.info("Deleted pharm_po_ln_pedigree_recv and number of rows updated " + updateCount);

				ArrayList<Integer> receiver_number = getReceiverNumberPO(po);

				// Updating dc_common:receiving_unit for quantity and slot_id
				for (int i = 0; i < receiver_number.size(); i++) {
					updateCount = dbUtils.updateFrom(Config.DC, environment.getProperty("update_dc_receiving_unit"),
							receiver_number.get(i));
					logger.info("Updated receiving_unit and number of rows updated " + updateCount);
				}
				logger.info("update completed in RDS for PO:{}", po);
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while RDS clean up", e);
			}
		}
	}

	public void cleanSmartSlottingDB() {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		List<String> itemArray = JsonPath.read(testFlowData, "$..itemNumber");
		Set<String> uniqueItem = new HashSet<String>(itemArray);
		logger.info("Unique PO size {}: ", uniqueItem.size());

		for (String itemNumber : uniqueItem) {
			logger.info("Cleaning up the data in Smart Slotting for itemNumber:{}", itemNumber);
			try {
				Object[] objArr = new Object[1];
				objArr[0] = itemNumber;
				int deleteCount = dbUtils.deleteFrom(PRODUCT_NAME.SMARTSLOTTING,
						environment.getProperty("smart_slotting_delete_from_slotItemStats"), objArr[0]);
				logger.info("Clean up completed in Smart Slotting for itemNumber:{}", itemNumber);
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while Smart Slotting clean up", e);
			}
		}
	}

	public ArrayList<Integer> getReceiverNumberPO(String poNumber) {

		ArrayList<Integer> recList = new ArrayList<>();

		try {
			logger.info("Get receiver number for po {}", environment.getProperty("get_receiver_number"));
			List<Map<String, Object>> recMap = dbUtils.selectFrom(Config.DC,
					environment.getProperty("get_receiver_number"), poNumber);
			logger.info("Size is " + recMap.size());
			if (recMap.size() > 0) {
				for (int i = 0; i < recMap.size(); i++) {
					recList.add((int) recMap.get(i).get("rcvr_nbr"));
					logger.info("Receiver number " + (int) recMap.get(i).get("rcvr_nbr"));
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info("Failed in" + environment.getProperty("get_receiver_number"));
		}
		return (recList);
	}

	public void mockRDS(String itemNumber, String poType) {

		int insertCount;
		String pur_ord_id = String.valueOf(javaUtil.randonNumberGenerator(6));
		String po_number = String.valueOf(javaUtil.randonNumberGenerator(10));
		int appointment_nbr = javaUtil.randonNumberGenerator(7);
		String currentDate = javaUtil.getCurrentDate();
		String currentDateTime = javaUtil.getCurrentDateAndTime();
		String drug_lot_nbr = String.valueOf(javaUtil.randonNumberGenerator(5));

		String[] result = itemNumber.split(",");

		for (int i = 0; i < result.length; i++) {

			int rcvr_nbr = javaUtil.randonNumberGenerator(4);
			String rcv_unit_id = String.valueOf(javaUtil.randonNumberGenerator(8));
			String rcv_unit_tag_id = String.valueOf(javaUtil.randonNumberGenerator(8));

			int po_line_nbr = (i + 1);
			logger.info("PO line number is " + po_line_nbr);
			logger.info("Item number is " + result[i]);

			if (i == 0) {
				logger.info("Inserting purchase order in dc_common:purchase_order with po_number {}", po_number);
				insertCount = dbUtils.updateFrom(Config.DC, environment.getProperty("insert_purchase_order"),
						pur_ord_id, po_number);
				logger.info("Successfully inserted in purchase order in dc_common:purchase_order {}", insertCount);
			}

			logger.info("Inserting purchase order in dc_common:po_line with pur_ord_id {}", pur_ord_id);
			insertCount = dbUtils.updateFrom(Config.DC, environment.getProperty("insert_po_line"), po_line_nbr,
					result[i], 10, 3, pur_ord_id);
			logger.info("Successfully inserted in purchase order in dc_common:po_line {}", insertCount);

			if (i == 0) {
				logger.info("Inserting purchase order in dc_common:dc_receiver{} with rcv_nbr", rcvr_nbr);
				logger.info("Inserting purchase order in dc_common:dc_receiver with appointment number {}",
						appointment_nbr);

				insertCount = dbUtils.updateFrom(Config.DC, environment.getProperty("insert_dc_receiver"), rcvr_nbr,
						appointment_nbr, po_number, pur_ord_id);
				logger.info("Successfully inserted in purchase order in dc_common:dc_receiver {}", insertCount);
			}

			logger.info("Inserting purchase order in dc_common:receiving_unit ");
			insertCount = dbUtils.updateFrom(Config.DC, environment.getProperty("insert_receiving_unit"), rcv_unit_id,
					rcv_unit_tag_id, rcvr_nbr, po_line_nbr, currentDate, result[i]);
			logger.info("Successfully inserted in purchase order in dc_common:receiving_unit {}", insertCount);

			logger.info("Inserting purchase order in dc_common:pharm_po_line ");
			insertCount = dbUtils.updateFrom(Config.DC, environment.getProperty("insert_pharm_po_line"), po_number,
					po_line_nbr, result[i]);
			logger.info("Successfully inserted in purchase order in dc_common:pharm_po_line {}", insertCount);

			logger.info("Inserting purchase order in dc_common:pharm_po_line_pedigree ");
			insertCount = dbUtils.updateFrom(Config.DC, environment.getProperty("insert_pharm_po_line_pedigree"),
					po_number, po_line_nbr, currentDateTime, drug_lot_nbr, currentDate);
			logger.info("Successfully inserted in purchase order in dc_common:pharm_po_line_pedigree {}", insertCount);

			String latestDateTime = javaUtil.getCurrentDateAndTime();

			if (!poType.equalsIgnoreCase("D40")) {
				logger.info("Inserting purchase order in dc_common:insert_pharm_po_line_pedigree_rcv ");
				insertCount = dbUtils.updateFrom(Config.DC,
						environment.getProperty("insert_pharm_po_line_pedigree_rcv"), po_number, po_line_nbr,
						currentDateTime, latestDateTime, rcv_unit_id);
				logger.info("Successfully inserted in purchase order in dc_common:insert_pharm_po_line_pedigree_rcv {}",
						insertCount);
			}
		}
	}

	public void cleanUpRDS(String queryparam) {
		try {
			String[] queryArray = queryparam.split("#");

			for (int i = 0; i < queryArray.length; i++) {
				try {
					logger.info("deleting the table:" + queryArray[i]);
					dbUtils.deleteFrom(PRODUCT_NAME.RDS, queryArray[i]);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to clean up RDS DB", e);
		}
	}

	public void insertRDS(String queryparam) {
		String[] queryArray = queryparam.split("#");
		try {
			for (int i = 0; i < queryArray.length; i++) {
				logger.info("inserting in table:" + queryArray[i]);
				dbUtils.insertInto(PRODUCT_NAME.RDS, queryArray[i]);
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to records in RDS DB", e);
		}
	}

	public void cleanRDCGDM(String derliveryNum) {
		try {
			rdcUtil.cleanUpGDMDelivery(derliveryNum);

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_CLEAN_GDM, e);
		}

	}

	public void cleanRDCReceving(String deliveryNum) {
		try {

			dbUtils.deleteFrom(PRODUCT_NAME.RECEIVING, queries.getProperty("rdc_receiving_instructions_delete"),
					deliveryNum, environment.getProperty("facility_num"));
			dbUtils.deleteFrom(PRODUCT_NAME.RECEIVING, queries.getProperty("rdc_receiving_container_item_delete"),
					deliveryNum, environment.getProperty("facility_num"));
			dbUtils.deleteFrom(PRODUCT_NAME.RECEIVING, queries.getProperty("rdc_receiving_container_delete"),
					deliveryNum, environment.getProperty("facility_num"));
			dbUtils.deleteFrom(PRODUCT_NAME.RECEIVING, queries.getProperty("rdc_receiving_receipt_delete"), deliveryNum,
					environment.getProperty("facility_num"));
			dbUtils.deleteFrom(PRODUCT_NAME.RECEIVING, queries.getProperty("rdc_receiving_dock_tag_delete"),
					deliveryNum, environment.getProperty("facility_num"));
			dbUtils.deleteFrom(PRODUCT_NAME.RECEIVING, queries.getProperty("rdc_receiving_delivery_meta_data_delete"),
					deliveryNum, environment.getProperty("facility_num"));

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_CLEAN_RECEIVING, e);
		}
	}

	public void cleanRDCRDS(String[] poArr) {
		try {

			List<Map<String, Object>> receiversList = dbUtils.selectFrom(PRODUCT_NAME.RDS,
					dbUtils.transformIntoSpringQuery(environment.getProperty("rds_get_receivers"), poArr.length),
					poArr);

			String[] recvArr = new String[receiversList.size()];

			for (int i = 0; i < receiversList.size(); i++) {
				int recvrNbr= (Integer) receiversList.get(i).get("rcvr_nbr");
				recvArr[i]=String.valueOf(recvrNbr);
			}

			logger.info(environment.getProperty("rds_update_dc_receiver"));
			int updateCount = dbUtils.UpdateFrom(PRODUCT_NAME.RDS,
					dbUtils.transformIntoSpringQuery(environment.getProperty("rds_update_dc_receiver"), poArr.length),
					poArr);
			logger.info("Updated dc_receiver and number of rows updated " + updateCount);

//			int deleteCount = dbUtils.deleteFrom(PRODUCT_NAME.RDS, dbUtils.transformIntoSpringQuery(
//					environment.getProperty("rds_delete_receiving_unit"), recvArr.length), recvArr);
			
			int recvUnitupdateCount = dbUtils.UpdateFrom(PRODUCT_NAME.RDS,
					dbUtils.transformIntoSpringQuery(environment.getProperty("rds_update_receiving_unit"), recvArr.length),
					recvArr);
			logger.info("Updated receiving_unit table and number of rows updated " + recvUnitupdateCount);

//			logger.info("Deleted receiving unit table and number of rows deleted:" + recvUnitupdateCount);

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_CLEAN_RDS, e);
		}
	}

	public void cleanUpDeviceDetailsCatalyst() {
		try {
			dbUtils.UpdateFrom(PRODUCT_NAME.WMS, queries.getProperty("update_terminal_id_details"), environment.getProperty("deviceNumber"));
			logger.info("========Updated Terminal ID details========");
			
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while handheld device clean up", e);
		}
	}

	public void changePriorityOfWorkCatalyst() {
		logger.info("========Changing Priority of Inbound Receiving Haulput tasks as lowest i.e. 99");
		int updatedNoOfWork = dbUtils.UpdateFrom(PRODUCT_NAME.WMS, environment.getProperty("update_work_priority_inbound"));			
		logger.info("Number of Work with changed Priority as 99 is : {}", updatedNoOfWork);
		
	}
	
	public void cleanUpWMSDbCatalyst() {
		try {
			String range = environment.getProperty("inbound_door_range");
			logger.info("Cleaning up WMS DB Tables for doors in range :{}", range);
			String[] doorsArray = range.split("-");
			final int firstValidDoor = Integer.parseInt(doorsArray[0]);
			final int lastValidDoor = Integer.parseInt(doorsArray[1]);	
			//cleaning up inbound doors
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_rcvlin_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_rcvtrk_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_rcvinv_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_appt_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while WMS DB Table clean up", e);
		}
	}
	
	public void cleanUpWorkQueueTableCatalyst() {
		try {
			String range = environment.getProperty("inbound_door_range");
			logger.info("Cleaning up Workqueue Tables for assigned door :{}", range);
			String[] doorsArray = range.split("-");
			final int firstValidDoor = Integer.parseInt(doorsArray[0]);
			final int lastValidDoor = Integer.parseInt(doorsArray[1]);	
			//cleaning up inbound doors
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_rcvlin_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_rcvtrk_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_rcvinv_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_appt_details"), String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while WMS DB Table clean up", e);
		}
	}
	
	public void cleanUpReceivedInventoryDetailsCatalyst() {
		try {
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> lpnList = new ArrayList<String>();
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			
			for(String lpn : lpnList) {
			int delete_invlod_details = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_invlod_details"), lpn, environment.getProperty("deviceNumber") );
			
			List<Map<String, Object>> invSub = dbUtils.selectFrom(PRODUCT_NAME.WMS, queries.getProperty("select_invsub_details"), lpn );
			logger.info("subNum returned is :{}", invSub.get(0).get("subnum"));
			
			int delete_invsub_details = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_invsub_details"), lpn );
			int delete_invdtl_details = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_invdtl_details"),  invSub.get(0).get("subnum"));
			logger.info("Inventory details deleted : {},{},{}",delete_invlod_details, delete_invsub_details, delete_invdtl_details);
			}	
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Inventory Details clean up", e);
		}
	}
	
	public void preCleanUpInventoryDetailsCatalyst() {
		try {
			
			List<String> lpnList = new ArrayList<String>();
			List<Map<String, Object>> invLodDetails = dbUtils.selectFrom(PRODUCT_NAME.WMS, queries.getProperty("select_invlod_details"), environment.getProperty("deviceNumber"));
			
			for(Map currentInvLod : invLodDetails) {
				String currentLPN = currentInvLod.get("lodnum").toString();
				logger.info("LPN returned is :{}", currentLPN);
				lpnList.add(currentLPN);
			}
			
			for(String lpn : lpnList) {
				int delete_invlod_details = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_invlod_details"), lpn, environment.getProperty("deviceNumber") );
			
				List<Map<String, Object>> invSub = dbUtils.selectFrom(PRODUCT_NAME.WMS, queries.getProperty("select_invsub_details"), lpn );
				logger.info("subNum returned is :{}", invSub.get(0).get("subnum"));
			
				int delete_invsub_details = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_invsub_details"), lpn );
				int delete_invdtl_details = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_invdtl_details"),  invSub.get(0).get("subnum"));
				logger.info("Inventory details deleted : {},{},{}",delete_invlod_details, delete_invsub_details, delete_invdtl_details);
			}	
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Inventory Details clean up", e);
		}
	}

}
