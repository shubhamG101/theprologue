package com.walmart.supplychain.catalyst.by.ui.pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.framework.utilities.selenium.UiActionsHelper;
import com.walmart.framework.utilities.javautils.JavaUtils;

import spring.SpringTestConfiguration;

import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;

import cucumber.runtime.Timeout;
import com.walmart.framework.supplychain.constants.Constants;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYExtensionsPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;

	@Autowired
	UiActionsHelper uiActionsHelper;

	@Autowired
	BYOutboundPage byOutboundPage;

	@Autowired
	BYUiHelper byUiHelper;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private WebElement textboxContainsName(String name) {
		return getDriver().findElement(By.xpath("//input[contains(@name,'" + name + "')]"));
	}

	@FindBy(xpath = "//span[contains(text(),'Freight Dashboard')]/../..//a/span[contains(@id,'btnWrap')]")
	private WebElement qcDashExpandBtn;

	@FindBy(xpath = "//iframe[contains(@name,'QC-Dashboard')]")
	public WebElement qcDashboardFrame;


	@FindBy(xpath = "//div[contains(@class,'x-column-layout-ct') and contains(@id,'rpFilterableGrid')]//span[text()='Actions']")
	private WebElement actionsButton;

	@FindBy(xpath = "//div[@role='presentation'][text()='Loading']")
	public WebElement loadingIndicator;

	private WebElement selectOptionFromActions(String optionName) {
		return getDriver().findElement(By.xpath("//a[normalize-space()='" + optionName + "']"));
		// a[normalize-space()='Update Haccp Temperature and Fail Flag']
	}

	@FindBy(xpath = "//div/ul/li[contains(@class,'-item') and text()='FAIL']")
	private WebElement selectFailFromDD;

	@FindBy(xpath = "//div/ul/li[contains(@class,'-item') and text()='PASS']")
	private WebElement selectPassFromDD;

	@FindBy(xpath = "//div[contains(@class,'pagebuilder')]//tr[contains(@id,'record-ext')]//td[count(//div[contains(@class,'pagebuilder')]//div[normalize-space()='HACCP Info'][not(contains(@class,'inner'))]//preceding-sibling::div)]/div")
	private WebElement getHACCPTemp;

	@FindBy(xpath = "//iframe[contains(@name,'QC-Dashboard')]")
	private WebElement switchToQcFrame;

	@FindBy(xpath = "//div[contains(@class,'pagebuilder')]//tr[contains(@id,'record-ext')]//td[count(//div[contains(@class,'pagebuilder')]//div[normalize-space()='HACCP Info'][not(contains(@class,'inner'))]//preceding-sibling::div)]/div")
	private WebElement haccpTemp;
	
	@FindBy(xpath = "(//a[normalize-space()='Execute Action'][contains(@id,'button')]//span[contains(text(),'Execute Action')])[2]")
//	@FindBy(xpath = "//span[text()='Execute Action']/following-sibling::span[1]")
	private WebElement executeActionButton;

	private WebElement getLpnCheckbox(String lpn) {
		return getDriver().findElement(By.xpath("//div[text()='" + lpn
				+ "']/parent::td[1]/preceding-sibling::td[1]/div/div[@class='x-grid-row-checker']"));
	}
	private WebElement inputFilterBox(String tabName) {
		return getDriver()
				.findElement(By.xpath("//div[contains(@id,'" + tabName + "')]//input[contains(@id,'Filter')][@style]"));
	}
	
	private WebElement inputProblemLPNTextBox(String tabName) {
		return getDriver()
				.findElement(By.xpath("(//div[contains(@id,'" + tabName + "')]//input[contains(@id,'Filter')][@style])[1]"));
	}

	private WebElement getButtonByText(String buttonText) {
		return getDriver().findElement(By.xpath("//a[normalize-space()='" + buttonText + "'][contains(@id,'button')]"));

	}
	
	
	//##################################################### Generic Methods ##############################
	
	public void enterValueUnderFilterTB(String tabName, String fieldName, String operator, String value) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(inputFilterBox(tabName)).waitUntilVisible();

		String filterCriteria = fieldName + operator + value;
		element(inputFilterBox(tabName)).clear();
		element(inputFilterBox(tabName)).sendKeys(filterCriteria + Keys.ENTER);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Entered the value {} to be filtered in filter box under {} tab ==========", value, fieldName);
	}

	public void switchToFrameWithElement(WebElement element) {
		getDriver().switchTo().frame(element);
		logger.info("Switched to working frame {} -----> ", element);
	}

	public void switchToDefaultContent() {
		getDriver().switchTo().defaultContent();
		logger.info("Switched to DefaultContent {} -----> ");
	}
	
	public void enterValueUnderFilterBox(String tabName, String fieldName, String operator, String value) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(inputProblemLPNTextBox(tabName)).waitUntilVisible();

		String filterCriteria = fieldName + operator + value;
		element(inputProblemLPNTextBox(tabName)).clear();
		element(inputProblemLPNTextBox(tabName)).sendKeys(filterCriteria + Keys.ENTER);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Entered the value {} to be filtered in filter box under {} tab ==========", value, fieldName);
	}
	
	//###################################################### QC Dashboard Methods #############################

	public void ClickOnExpandQCDashboardButton() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		switchToFrameWithElement(qcDashboardFrame);
		element(qcDashExpandBtn).waitUntilVisible();
		element(qcDashExpandBtn).waitUntilClickable();
		element(qcDashExpandBtn).click();
		logger.info("Clicked on Expand QC Dashboard button ==========");
	}

	public void selectLpn(String lpn) {

		Failsafe.with(retryPolicy).run(() -> {
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			element(getLpnCheckbox(lpn)).waitUntilVisible();
			element(getLpnCheckbox(lpn)).waitUntilClickable();
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			element(getLpnCheckbox(lpn)).click();
			logger.info("Clicked on Lpn checkbox {} ==========", lpn);
		});
	}

	public String existingTempature() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		String currentTemp = element(getHACCPTemp).getText();
		logger.info("Existing HACCP Temperature for LPN is {} ==========", currentTemp);
		return currentTemp;
	}

	public void clickOnActionsButton() {
		Failsafe.with(retryPolicy).run(() -> {
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			element(actionsButton).waitUntilVisible();
			element(actionsButton).waitUntilClickable();
			switchToDefaultContent();
			switchToFrameWithElement(switchToQcFrame);
			uiActionsHelper.moveToElementAndClick(actionsButton);
			logger.info("Clicked on Actions Button ==========");
		});
	}

	public void selectOptionHACCPFromActionsMenu() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(selectOptionFromActions("Update Haccp Temperature and Fail Flag")).waitUntilVisible();
		element(selectOptionFromActions("Update Haccp Temperature and Fail Flag")).waitUntilClickable();
		element(selectOptionFromActions("Update Haccp Temperature and Fail Flag")).click();
		logger.info("Selected option Update Haccp Temperature and Fail Flag from Actions Menu DropDown ==========");
	}

	public void enterPassFailAndSelectFromDD(String passOrFail) {

		Failsafe.with(retryPolicy).run(() -> {
			element(textboxContainsName("uc_haccp_fail_flg")).waitUntilVisible();
			element(textboxContainsName("uc_haccp_fail_flg")).waitUntilClickable();
			element(textboxContainsName("uc_haccp_fail_flg")).clear();

			if (passOrFail.equalsIgnoreCase("PASS")) {

				element(textboxContainsName("uc_haccp_fail_flg")).sendKeys(passOrFail);
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(selectPassFromDD).waitUntilVisible();
				element(selectPassFromDD).waitUntilClickable();
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(selectPassFromDD).click();
				logger.info("Selected PASS option from Tolerance DropDown {} ==========", passOrFail);

			} else {
				element(textboxContainsName("uc_haccp_fail_flg")).sendKeys(passOrFail);
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(selectFailFromDD).waitUntilVisible();
				element(selectFailFromDD).waitUntilClickable();
				element(selectFailFromDD).click();
				logger.info("Selected FAIL option from Tolerance DropDown {}==========", passOrFail);
			}
		});
	}

	public void updateTemperature(String temperature) {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(textboxContainsName("uc_haccp_temp")).waitUntilVisible();
		element(textboxContainsName("uc_haccp_temp")).waitUntilClickable();
		element(textboxContainsName("uc_haccp_temp")).clear();
		element(textboxContainsName("uc_haccp_temp")).sendKeys(temperature);
		logger.info("Updated the Temperature to {} ==========", temperature);
	}

	public void clickOnExecuteActionButton() {
		Failsafe.with(retryPolicy).run(() -> {
			element(getButtonByText("Execute Action")).waitUntilClickable();
			element(getButtonByText("Execute Action")).click();
			logger.info("Clicked on Execute Action button ==========");
		});
	}

	public void executeActionButton() {
		Failsafe.with(retryPolicy).run(() -> {
			element(executeActionButton).waitUntilVisible();
			element(executeActionButton).waitUntilClickable();
			uiActionsHelper.moveToElementAndClick(executeActionButton);
//		element(executeActionButton).click();
		});
	}

	public String updatedTempature() {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(haccpTemp).waitUntilVisible();
		String updatedTemp = element(haccpTemp).getText();
		logger.info("Updated HACCP Temperature for LPN is {} ==========", updatedTemp);
		return updatedTemp;
	}

	// ########################## Change Inventory Status from QCI to Available
	
	@FindBy(xpath = "//label[text()='Invsts-Reacod']/parent::div[1]/following-sibling::table//div[contains(@class,'icon-expanded')]")
	public WebElement inventoryStatusCodeDropdown;
	
	@FindBy(xpath = "//li[contains(text(),'ROC-Vendor')]")
	private WebElement moveDDStatus;

	@FindBy(xpath = "//li[contains(text(),'AVAL')]")
	private WebElement availableStatus;

	@FindBy(xpath = "//input[contains(@name,'reacod')]")
	private WebElement commentTextBox;

	public void selectOptionChangeInvStatusFromActionsMenu() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(selectOptionFromActions("Change Inventory Status")).waitUntilVisible();
		element(selectOptionFromActions("Change Inventory Status")).waitUntilClickable();
		element(selectOptionFromActions("Change Inventory Status")).click();
		logger.info("Selected option Change Inventory Status from Actions Menu DropDown ==========");
	}

	public void clickOnInventoryStatusCodeDropdown() {
		element(inventoryStatusCodeDropdown).waitUntilVisible();
		element(inventoryStatusCodeDropdown).click();
		logger.info("Clicked on Inventory Status Code Dropdown Expansion button in BY UI ==========");
	}

	public void selectStatus() {
		Failsafe.with(retryPolicy).run(() -> {
			uiActionsHelper.moveToElement(moveDDStatus);
			uiActionsHelper.scrollToElement(availableStatus);
			element(availableStatus).click();
//		String status =availableStatus.getText();
//		logger.info("Selected the status as Available for an lpn =========={}", status);
		});
		element(commentTextBox).sendKeys("Automation Testing");
		logger.info("Entered the comment =========={}");
	}

	@FindBy(xpath = "//div/i[contains(@class,'cancel-close')]")
	private WebElement clickOnCloseBtn;

	public void clickOnCloseButton() {
		Failsafe.with(retryPolicy).run(() -> {
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			element(clickOnCloseBtn).waitUntilVisible();
			element(clickOnCloseBtn).waitUntilClickable();
			element(clickOnCloseBtn).click();
			logger.info("Clicked on Close Button =========={}");
		});
	}

}
