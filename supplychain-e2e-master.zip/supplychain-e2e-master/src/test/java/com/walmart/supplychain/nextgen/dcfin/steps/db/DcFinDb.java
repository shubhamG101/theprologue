package com.walmart.supplychain.nextgen.dcfin.steps.db;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.dcfin.scenariosteps.db.DcFinSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class DcFinDb {

	@Steps
	DcFinSteps dcFinDb;

	@And("^user verifies the purchase details in DCFinancials$")
	public void dcFinPurchaseValidation()  {
			dcFinDb.validatePurchase();
	}

	@Then("^user verifies the sales details in DCFinancials$")
	public void dcFinSalesValidation() {
			dcFinDb.validateSale();
	}
	
	@And("^user verifies the purchase details for \"([^\"]*)\" in DCFinancials$")
	public void dcFinAdjustmentValidation(String typeOfAdj) { 
			dcFinDb.validateAdjustment(typeOfAdj);
	}
	
	@And("^user verifies the adjusted details for the item$")
	public void dcFinAdjustmentValidationForThor() {
		dcFinDb.validateAdjustmentforThor();
	}
	@And("^user verifies the GDIS posting detais in DCFinancials$")
	public void dcFinGdisValidation()  {
		dcFinDb.validateGdisPosting();
		
	}
	
	@And("^user verifies OSDR posting in DCFinancials$")
	public void dcFinOsdrValidation()  {
			dcFinDb.validateOsdrPosting();		
	}


}
