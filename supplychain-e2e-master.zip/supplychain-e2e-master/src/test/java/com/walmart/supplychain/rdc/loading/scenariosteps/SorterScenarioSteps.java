package com.walmart.supplychain.rdc.loading.scenariosteps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.pharmacy.receiving.scenariosteps.mobile.ReceivingPharmSteps;
import com.walmart.supplychain.rdc.loading.steps.RDCSorterSteps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class SorterScenarioSteps {
	
	@Steps
	RDCSorterSteps sorterSteps;
	
	@Given("^sorter sends the divert messages to Loading$")
	public void sorterSendsDiverts() throws JsonProcessingException
	{
		sorterSteps.sendSorterDiverts();
		
	}

}
