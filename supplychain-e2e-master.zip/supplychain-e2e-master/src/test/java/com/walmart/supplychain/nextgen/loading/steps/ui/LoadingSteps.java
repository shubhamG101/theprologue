package com.walmart.supplychain.nextgen.loading.steps.ui;

import static net.serenitybdd.rest.SerenityRest.given;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.acc.ContainerSearch;
import com.walmart.framework.supplychain.domain.loading.Load;
import com.walmart.framework.supplychain.domain.loading.SearchContainers;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.loading.pages.mobile.LoadingAppHelper;
import com.walmart.supplychain.nextgen.loading.pages.ui.ContainerVisibilityPage;
import com.walmart.supplychain.nextgen.loading.pages.ui.LoadingLoginPage;
import com.walmart.supplychain.nextgen.loading.pages.ui.LoadingPage;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class LoadingSteps {
	@Autowired
	LoadingLoginPage loadingLoginPage;
	boolean loadingFlow = false;
	@Autowired
	LoadingPage loadingPage;
	ContainerVisibilityPage containerVisibilityPage;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	@Autowired
	Environment endpoint;
	Response response;
	String wtmsLoadId;
	@Autowired
	Environment environment;
	
	@Autowired
	LoadingHelper loadingHelper;
	
	@Autowired
	IDMSteps idmSteps;
	
	@Autowired
	JavaUtils javaUtils;
	
	@Autowired
	DbUtils dbUtils;
	
	private static final String OUTBOUND_GET_ENTITY = "$.testFlowData.outboundDetails[*]";
	private static final String GET_LOADING_STATUS = "$.shippingContainerList[*].containerStatusDesc";
	private static final String GET_LOADING_SEARCH_EP = "loading_search_url";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(12, Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";	
	private static final String DOOR_NUMBER_JSON = "$..doorNumber";
	private static final String LOADID_JSON = "$..loadId";
	private static final String TMSID_JSON = "$..transportationLoadId";
	private static final String TRAILER_NUMBER_JSON = "$..trailer.trailerNumber";
	private static final String LOAD_STATUS_JSON = "$..loadStatusDesc";

	public void open_Loading_Page() {
		logger.info("Launching loading url" + endpoint.getProperty("loading_ui_url"));
		loadingPage.getUrl(endpoint.getProperty("loading_ui_url"));

	}

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	public void login_to_Loading() {
		try {
		loadingLoginPage.enterLoginField(propertyResolver.getPropertyValue("loadingUserName"));
		loadingLoginPage.enterPasswordField(propertyResolver.getPropertyValue("loading"));
		loadingLoginPage.selectDomain("local");
		loadingLoginPage.clickLogInButton();
		logger.info("Logged in to Loading app");
		}
		catch(ElementNotVisibleException|TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.LOADING_UNABLE_TO_LOGIN,e);
		}
	}

	@Step
	public void searchLoadId(String loadId) {
		try {
			Failsafe.with(retryPolicy).run(() -> {
				String tmsId = loadingPage.searchLoadId(loadId);
				logger.info("Waiting for TMS Id to get populated in UI");
				logger.info("TMS Load ID from UI:{}", tmsId);
				Assert.assertNotEquals(ErrorCodes.LOADING_TMSID_NOT_POPULATED, "", tmsId);
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to search loadId in Loading ui", e);
		}

	}

	@Step
	public int searchLoadIdCntrVisibility(String loadId) {
		int rowCntui;
		try {
			rowCntui = containerVisibilityPage.searchLoadId(loadId);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to search loadId in Container Visibility ui", e);
		}
		return rowCntui;

	}

	@Step
	public String validateLoad(String loadId, String door, String trailer) {
		String tmsLoadId = null;
		try {
			tmsLoadId = loadingPage.validateLoadId(loadId, door, trailer);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate loadId", e);
		}

		return tmsLoadId;
	}

	public void click_on_left_Toggle_Button() {
		loadingPage.clickOnLeftToggleButton();
	}

	public void click_on_ContainerVisibility_Option() throws InterruptedException {
		loadingPage.clickContainerVisibilityOption();
		Thread.sleep(3000);

	}

	public void search_for_the_ContainerId(String cntrId) {

		try {
			containerVisibilityPage.enterContainerIdandClickonSearchIcon(cntrId);
		} catch (Exception e) {
			throw new TestCaseFailure("Failed to search containerId in container visibility page", e);
		}
	}

	@Step
	public void validateLoadedCntrs() {
		try {
			
			String testData = (String) tl.get().get("testFlowData");
			JSONArray listOfLoads = JsonPath.read(testData, OUTBOUND_GET_ENTITY);
			String outboundJson = null;
			outboundJson = objectMapper.writeValueAsString(listOfLoads);
			@SuppressWarnings("unchecked")
			List<OutboundDetail> outboundDetailList;
			outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);

			List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
			List<String> listOfChildContainers = new ArrayList<>();
			retry = false;
			for (OutboundDetail outbound : outboundDetailList) {
				
				open_Loading_Page();
				
				login_to_Loading();
				
				Failsafe.with(retryPolicy).run(() -> {
					if (retry) {
						loadingPage.closeDriver();
						logger.info("Retrying.......:");
						open_Loading_Page();
						login_to_Loading();
					}
					retry = true;
					
					String loadId = null;
					String tmsLoadId = null;
					loadId = outbound.getLoadId();
					String door = outbound.getOutboundDoorNumber().trim();
					String trailer = outbound.getTrailerNumber();
					String tmsId = loadingPage.searchLoadId(loadId);
					logger.info("Waiting for TMS Id to get populated in UI");
					logger.info("TMS Load ID from UI:{}", tmsId);
					Assert.assertNotEquals(ErrorCodes.LOADING_TMSID_NOT_POPULATED, "", tmsId);
					tmsLoadId = loadingPage.validateLoadId(loadId, door, trailer);
					outbound.setTmsLoadId(tmsLoadId);
					listOfOutboundObj.add(outbound);
					String updatedtestflowdata;
					JSONArray listofOutboundJson = jsonUtil.converyListToJsonArray(listOfOutboundObj);
					updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofOutboundJson,
							"$.testFlowData.outboundDetails");
					tl.get().put("testFlowData", updatedtestflowdata);
					logger.info("testData after updating::{}", tl.get().get("testFlowData"));
					loadingPage.closeDriver();
					retry = false;
				});
			}
		} 
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		}
		catch (Exception e) {
			throw new AutomationFailure("Failed to validate loadId", e);
		}

	}

	@SuppressWarnings("unchecked")
	@Step
	public void validateloadStatusAfterCloseLoad(String loadStatus) {
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		JSONArray listOfLoads = JsonPath.read(testFlowData, OUTBOUND_GET_ENTITY);
		String outboundJson = null;
		try {
			outboundJson = objectMapper.writeValueAsString(listOfLoads);
		} catch (JsonProcessingException e1) {
			logger.error(e1);
		}
		List<OutboundDetail> outboundDetailList;
		try {
			outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);
			List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
			retry = false;
			for (OutboundDetail outbound : outboundDetailList) {
				Failsafe.with(retryPolicy).run(() -> {
					if (retry) {
						loadingPage.closeDriver();
						logger.info("Retrying.......:");
					}
					retry = true;
					open_Loading_Page();
					login_to_Loading();
					List<String> listOfContainers = new ArrayList<>();
					String tmsId = loadingPage.searchLoadId(outbound.getLoadId());
					logger.info("Waiting for TMS Id to get populated in UI");
					logger.info("TMS Load ID from UI:{}", tmsId);
					Assert.assertNotEquals(ErrorCodes.LOADING_TMSID_NOT_POPULATED, "", tmsId);
					String statusUi = loadingPage.validateLoadStatus(loadStatus);
					logger.info("Loading Status in UI:{}", statusUi);
					Assert.assertEquals(ErrorCodes.LOADING_LOAD_STATUS_MISMATCH_AFTER_CLOSE_LOAD, loadStatus, statusUi);
					loadingPage.closeDriver();
					retry = false;
				});
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Loading status after close load", e);
		}
	}

	@Step
	public void validateCntrStatus(String cntrStatus) {
		try {
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));
			JSONArray listOfLoads = JsonPath.read(testFlowData, OUTBOUND_GET_ENTITY);
			String outboundJson = null;
			try {
				outboundJson = objectMapper.writeValueAsString(listOfLoads);
			} catch (JsonProcessingException e1) {
				logger.error(e1);
			}
			List<OutboundDetail> outboundDetailList;

			outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);
			List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
			retry = false;
			for (OutboundDetail outbound : outboundDetailList) {
				Failsafe.with(retryPolicy).run(() -> {
					if (retry) {
						loadingPage.closeDriver();
						logger.info("Retrying.......:");
					}
					retry = true;
					open_Loading_Page();
					login_to_Loading();
					loadingPage.clickOnLeftToggleButton();
					loadingPage.clickContainerVisibilityOption();
					Thread.sleep(3000);

					List<String> listOfContainers = new ArrayList<>();
					JSONArray listOfCntrsCROSSU = null;
					String cntrString = "";

					if (Config.DC == DC_TYPE.ACC) {
						listOfCntrsCROSSU = JsonPath.read(testFlowData,
								"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
										+ outbound.getDestNumber()
										+ " && @.isPbyl == false  && @.labelType == 'normal' && (@.channelType == \""
										+ CHANNELS.CROSSU.getValue().toUpperCase() + "\" || @.channelType == \""
										+ CHANNELS.CROSSMU.getValue().toUpperCase() + "\"))].childContainers[*]");
						cntrString = listOfCntrsCROSSU.toJSONString();
					} else {
						listOfCntrsCROSSU = JsonPath.read(testFlowData,
								"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
										+ outbound.getDestNumber() + " && @.isPbyl == false  && (@.channelType == \""
										+ CHANNELS.CROSSU.getValue().toUpperCase() + "\" || @.channelType == \""
										+ CHANNELS.CROSSMU.getValue().toUpperCase() + "\"))].childContainers[*]");
						cntrString = listOfCntrsCROSSU.toJSONString();
					}

					List<String> crossuCntrList = objectMapper.readValue(cntrString, new TypeReference<List<String>>() {
					});
					if (crossuCntrList.size() != 0) {
						listOfContainers.addAll(crossuCntrList);

					}

					JSONArray listOfCntrsSstkOrDANonCon = JsonPath.read(testFlowData,
							"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
									+ outbound.getDestNumber()
									+ " && @.isPbyl == false && @.isVTR == false && (@.channelType == \""
									+ CHANNELS.STAPLESTOCK.getValue().toUpperCase() + "\" || @.channelType == \""
									+ CHANNELS.CROSSNA.getValue().toUpperCase() + "\" || @.channelType == \""
									+ CHANNELS.CROSSNMA.getValue().toUpperCase() + "\"))].parentContainer");
					String cntrStringSstkOrDANonCon = listOfCntrsSstkOrDANonCon.toJSONString();
					List<String> sstkuOrDANonConCntrList = objectMapper.readValue(cntrStringSstkOrDANonCon,
							new TypeReference<List<String>>() {
							});

					if (sstkuOrDANonConCntrList.size() != 0) {

						listOfContainers.addAll(sstkuOrDANonConCntrList);

					}
					logger.info("Containers to be validated {}", listOfContainers);
					Thread.sleep(4000);
					
					if(!cntrStatus.equalsIgnoreCase("Picked"))
						containerVisibilityPage.selectLoaded();
					
					int rowCntui = containerVisibilityPage.searchLoadId(outbound.getLoadId());
								
					Assert.assertEquals(ErrorCodes.LOADING_CONTAINER_COUNT_MISMATCH, listOfContainers.size(), rowCntui);
					containerVisibilityPage.validateCntrStatus(listOfContainers, cntrStatus);
					List<String> listOfChildContainers = new ArrayList<>();
					for (int j = 0; j < listOfContainers.size(); j++) {
						listOfChildContainers.add(listOfContainers.get(j).toString());
					}
					outbound.setContainerIds(listOfChildContainers);
					listOfOutboundObj.add(outbound);
					String updatedtestflowdata;
					JSONArray listofOutboundJson = jsonUtil.converyListToJsonArray(listOfOutboundObj);
					updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testFlowData, listofOutboundJson,
							"$.testFlowData.outboundDetails");
					tl.get().put("testFlowData", updatedtestflowdata);
					logger.info("testData after updating::{}", tl.get().get("testFlowData"));

					loadingPage.closeDriver();
					retry = false;
				});
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate ContainerIds in Loading ui", e);
		}
	}

	@Step
	public void validateLoadStatus(OutboundDetail outbound, String loadStatus) {
		try {
			String loadId = outbound.getLoadId();
			searchLoadId(loadId);
			Failsafe.with(retryPolicy).run(() -> {
				String loadStatusui = loadingPage.validateLoadStatus(loadStatus);
				if (loadStatusui.equals("Loading")) {
					loadingPage.clickOnSearchIcon();
				}
				Assert.assertEquals(ErrorCodes.LOADING_LOAD_STATUS_MISMATCH, loadStatusui, loadStatus);
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed in validating load status", e);
		}
	}

	@Step
	public void validateCntrStatusForVtr(String containerStatus) {
		try {
			String testData = (String) tl.get().get("testFlowData");
			ObjectMapper om = new ObjectMapper();
			retry = false;
			Failsafe.with(retryPolicy).run(() -> {
				if (retry) {
					loadingPage.closeDriver();
					logger.info("Retrying.......:");
				}
				retry = true;
				open_Loading_Page();
				login_to_Loading();
				loadingPage.clickOnLeftToggleButton();
				loadingPage.clickContainerVisibilityOption();
				Thread.sleep(3000);
				JSONArray listOfCntrsCROSSU = JsonPath.read(testData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].vtrContainer");
				String vtrCntrString = listOfCntrsCROSSU.toJSONString();
				List<String> vtrCntrList = om.readValue(vtrCntrString, new TypeReference<List<String>>() {
				});
				containerVisibilityPage.validateContainerStatusByCntrId(vtrCntrList, containerStatus);
				retry = false;
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate vtr containers in Loading", e);
		}

	}

	public void deleteLoad() {

		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			ObjectMapper om = new ObjectMapper();
			List outboundListNew = new ArrayList();
			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;
			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});

			for (OutboundDetail outbound : outboundList) {
				Failsafe.with(retryPolicy).run(() -> {
					open_Loading_Page();
					login_to_Loading();
					loadingPage.searchLoadId(outbound.getLoadId());
					loadingPage.deleteLoad(outbound.getLoadId());

				});
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to delete the load", e);
		}

	}

	public void validateMCBContainers() {
		try {
			String testData = (String) tl.get().get("testFlowData");
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*].mcbCntr");
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<String> mcbCntrList = null;
			mcbCntrList = om.readValue(outBoundString, new TypeReference<List<String>>() {
			});

			for (String mcbCntr : mcbCntrList) {
				ContainerSearch search = new ContainerSearch();
				search.setContainerTagId(mcbCntr);
				Failsafe.with(retryPolicy).run(() -> {
					response = given().relaxedHTTPSValidation().body(om.writeValueAsString(search)).when()
							.put(environment.getProperty(GET_LOADING_SEARCH_EP));
					Assert.assertEquals(ErrorCodes.LOADING_CNTR_SEARCH, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());

					JSONArray loadingStatusArray = JsonPath.read(response.asString(), GET_LOADING_STATUS);
					String loadingStatusString = loadingStatusArray.toJSONString();
					List<String> loadingStatusList = objectMapper.readValue(loadingStatusString,
							new TypeReference<List<String>>() {
							});
					String loadStatus = loadingStatusList.get(0);
					Assert.assertEquals(ErrorCodes.LOADING_CNTR_SEARCH, "Loaded", loadStatus);
				});

			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate MCB containers in Loading", e);
		}

	}
	
	@Step
	public void validateLoadDetailsThroughAPI() {
		try {
			String testData = (String) tl.get().get("testFlowData");
			JSONArray listOfLoads = JsonPath.read(testData, OUTBOUND_GET_ENTITY);
			String outboundJson = null;
			outboundJson = objectMapper.writeValueAsString(listOfLoads);
			@SuppressWarnings("unchecked")
			List<OutboundDetail> outboundDetailList;
			outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);

			List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
			retry = false;
			for (OutboundDetail outbound : outboundDetailList) {
					
					String loadId = null;
					wtmsLoadId = null;
					loadId = outbound.getLoadId();
					String door = outbound.getOutboundDoorNumber().trim();
					String trailer = outbound.getTrailerNumber();
					Boolean isTMSIDUpdateReq=false;
					
					JSONArray loadList = new JSONArray();
					loadList.add(Integer.parseInt(loadId));
					JSONObject loadObj = new JSONObject();
					loadObj.put("loadIds", loadList);
					
					int retry=0;
					do {
						Thread.sleep(4000);
						Failsafe.with(retryPolicy).run(() -> {
							response = SerenityRest.given().relaxedHTTPSValidation().contentType("application/json").headers(loadingHelper.getloadingHeaders()).body(loadObj.toString()).when().post(environment.getProperty("search_load_api"));
							Assert.assertEquals(ErrorCodes.LOADING_UNABLE_TO_FETCH_LOAD_DETAILS, Constants.SUCESS_STATUS_CODE,response.getStatusCode());
							DocumentContext loadingResponseParsedJson = JsonPath.parse(response.asString());
							List<String> tmsIdUi  = loadingResponseParsedJson.read(TMSID_JSON);
//							Assert.assertNotEquals(ErrorCodes.LOADING_TMSID_NOT_FOUND, tmsIdUi.get(0), null);
							logger.info("tms loadId" + tmsIdUi.get(0));
							wtmsLoadId=tmsIdUi.get(0);
						});
						retry=retry+1;
					} while ((wtmsLoadId==null) && retry<=5);
					
					isTMSIDUpdateReq = Boolean.valueOf(environment.getProperty("is_TMSID_update_required"));
					if (wtmsLoadId==null && isTMSIDUpdateReq==true) {
						logger.info("Updating WTMS loadID Manualy");
						wtmsLoadId="855"+javaUtils.randonNumberGenerator(5);
						
						
						dbUtils.UpdateFrom(PRODUCT_NAME.LOADING, environment.getProperty("loading_update_TMSLoadId"), wtmsLoadId,loadId);
						logger.info("Updated WTMS loadID Manually");
					}
					DocumentContext loadingResponseParsedJson = JsonPath.parse(response.asString());
					List<String> doorUi  = loadingResponseParsedJson.read(DOOR_NUMBER_JSON);
					List<Integer> loadIdUi  = loadingResponseParsedJson.read(LOADID_JSON);
					List<String> trailerUi  = loadingResponseParsedJson.read(TRAILER_NUMBER_JSON);
					List<String> statusUi  = loadingResponseParsedJson.read(LOAD_STATUS_JSON);
					
					Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_DOOR, door.trim(), doorUi.get(0).trim());
					logger.info("door expected:" + door + "|door ui" + doorUi);

					Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_LOADID,loadId, String.valueOf(loadIdUi.get(0)));
					logger.info("loadId expected:" + loadId + "|loadId ui" + loadIdUi.get(0));

					Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_TRAILER_NUMBER,trailer, trailerUi.get(0));
					logger.info("trailer expected:" + trailer + "|trailer ui" + trailerUi.get(0));
					
					logger.info("Validating load status |status expected: Loading | status ui " + statusUi.get(0));
					Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_LOAD_STATUS,"Loading", statusUi.get(0));
					
					outbound.setTmsLoadId(wtmsLoadId);
					listOfOutboundObj.add(outbound);
					String updatedtestflowdata;
					JSONArray listofOutboundJson = jsonUtil.converyListToJsonArray(listOfOutboundObj);
					updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofOutboundJson,
							"$.testFlowData.outboundDetails");
					tl.get().put("testFlowData", updatedtestflowdata);
					logger.info("testData after updating::{}", tl.get().get("testFlowData"));
					loadingPage.closeDriver();
//					retry = false;
//				});
			}
		} 
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		}
		catch (Exception e) {
			throw new AutomationFailure("Failed to validate loadId", e);
		}
	}
	public String validateLoadIdThroughAPI(String loadId, String door, String trailer) throws InterruptedException {
//		List loadList = new ArrayList();
//		Load load = new Load();
//		load.setLoadId(Integer.parseInt(loadId));
//		loadList.add(load);
//		SearchContainers cntrs = new SearchContainers();
//		cntrs.setLoads(loadList);
		
//		ArrayList<Integer> loadList = new ArrayList<Integer>();
//		loadList.add(Integer.parseInt(loadId));

		JSONArray loadList = new JSONArray();
		loadList.add(Integer.parseInt(loadId));

		JSONObject loadObj = new JSONObject();
		loadObj.put("loadIds", loadList);
		
		
//		ObjectMapper om = new ObjectMapper();
		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().contentType("application/json").headers(loadingHelper.getloadingHeaders()).body(loadObj.toString()).when().post(environment.getProperty("search_load_api"));
			Assert.assertEquals(ErrorCodes.LOADING_UNABLE_TO_FETCH_LOAD_DETAILS, Constants.SUCESS_STATUS_CODE,response.getStatusCode());
		});
		DocumentContext loadingResponseParsedJson = JsonPath.parse(response.asString());
		List<String> doorUi  = loadingResponseParsedJson.read(DOOR_NUMBER_JSON);
		List<Integer> loadIdUi  = loadingResponseParsedJson.read(LOADID_JSON);
		List<String> tmsIdUi  = loadingResponseParsedJson.read(TMSID_JSON);
		List<String> trailerUi  = loadingResponseParsedJson.read(TRAILER_NUMBER_JSON);
		List<String> statusUi  = loadingResponseParsedJson.read(LOAD_STATUS_JSON);
		
		Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_DOOR, door.trim(), doorUi.get(0).trim());
		logger.info("door expected:" + door + "|door ui" + doorUi);

		Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_LOADID,loadId, String.valueOf(loadIdUi.get(0)));
		logger.info("loadId expected:" + loadId + "|loadId ui" + loadIdUi.get(0));

		Assert.assertNotEquals(ErrorCodes.LOADING_TMSID_NOT_FOUND, tmsIdUi.get(0), null);
		logger.info("tms loadId" + tmsIdUi.get(0));

		Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_TRAILER_NUMBER,trailer, trailerUi.get(0));
		logger.info("trailer expected:" + trailer + "|trailer ui" + trailerUi.get(0));

//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		logger.info("Validating load status |status expected: Loading | status ui " + statusUi.get(0));
		Assert.assertEquals(ErrorCodes.LOADING_MISMATCH_IN_LOAD_STATUS,"Loading", statusUi.get(0));
		return tmsIdUi.get(0);
	}
	
	@Step
	public void validateloadStatusAfterCloseLoadThroughAPI(String loadStatus) {
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		JSONArray listOfLoads = JsonPath.read(testFlowData, OUTBOUND_GET_ENTITY);
		String outboundJson = null;
		try {
			outboundJson = objectMapper.writeValueAsString(listOfLoads);
		} catch (JsonProcessingException e1) {
			logger.error(e1);
		}
		List<OutboundDetail> outboundDetailList;
		try {
			outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);
			for (OutboundDetail outbound : outboundDetailList) {
				
//					List loadList = new ArrayList();
//					Load load = new Load();
//					load.setLoadId(Integer.parseInt(outbound.getLoadId()));
//					loadList.add(load);
//					SearchContainers cntrs = new SearchContainers();
//					cntrs.setLoads(loadList);
//					ObjectMapper om = new ObjectMapper();
					
					JSONArray loadList = new JSONArray();
					loadList.add(Integer.parseInt(outbound.getLoadId()));

					JSONObject loadObj = new JSONObject();
					loadObj.put("loadIds", loadList);
				Failsafe.with(retryPolicy).run(() -> {	
					//om.writeValueAsString(cntrs)
					response = SerenityRest.given().relaxedHTTPSValidation().contentType("application/json").headers(loadingHelper.getloadingHeaders()).body(loadObj.toString()).when().post(environment.getProperty("search_load_api"));
					Assert.assertEquals(ErrorCodes.LOADING_UNABLE_TO_FETCH_LOAD_DETAILS, Constants.SUCESS_STATUS_CODE,response.getStatusCode());
					
					DocumentContext loadingResponseParsedJson = JsonPath.parse(response.asString());
					List<String> statusUi  = loadingResponseParsedJson.read("$..loadStatusDesc");
					logger.info("Loading Status in UI:{}", statusUi);
					Assert.assertEquals(ErrorCodes.LOADING_LOAD_STATUS_MISMATCH_AFTER_CLOSE_LOAD, loadStatus.toLowerCase(), statusUi.get(0).toLowerCase());
				});
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Loading status after close load", e);
		}
	}
	
	public void validateLoadInMomentum() {
		logger.info("TestFlowdata while validating LoadInMomentum="+tl.get().get("testFlowData"));
		String testFlowData = tl.get().get(TEST_FLOW_DATA).toString();
		JSONArray tmsLoadIds = JsonPath.read(testFlowData, "$.testFlowData..tmsLoadId");
		String tmsLoadId = tmsLoadIds.get(0).toString();
		logger.info("TMS Load Id for which Load Details are going to be validated is:{}", tmsLoadId);
		
		if(!tmsLoadId.startsWith("855")) {
		Response response = SerenityRest.given().accept("application/json").when()
				.get(MessageFormat.format(environment.getProperty("get_transportation_load_details"), tmsLoadId));
		Assert.assertEquals(ErrorCodes.WTMS_INCORRECT_REESPONSE, 200, response.getStatusCode());
		String responseBody = response.getBody().asString();
		logger.info("API Response="+responseBody);
		
		List<String> poNumbers = JsonPath.read(testFlowData, "$..poNumber");
		for(String poNumber : poNumbers) {
			List<String> channelMethod = JsonPath.read(testFlowData, "$..poDetails[?(@.poNumber == '" + poNumber + "')]..channelMethod");
			List<Integer> loadIdFromAPIResponse = JsonPath.read(responseBody, "$..loadId");
			Assert.assertEquals(ErrorCodes.TMS_LOADID_MATCH_FAILED, tmsLoadId, loadIdFromAPIResponse.get(0).toString());
			List<String> noOfCasesTestFlowData = JsonPath.read(testFlowData, "$..poDetails[?(@.poNumber == '" + poNumber + "')]..receivingInstructions[*].receivedQuantity");
			int sumOfCases = 0;
			for(String cases : noOfCasesTestFlowData) {
			sumOfCases += Integer.parseInt(cases);
			}
			List<String> containersTestFlowData = JsonPath.read(testFlowData, "$..poDetails[?(@.poNumber == '" + poNumber + "')]..receivingInstructions[*].parentContainer");
			int sumOfpallets = containersTestFlowData.size();
			String chnlMthd = channelMethod.get(0).toString();
			
			double sumOfWeights = 0;
			double sumOfCubes = 0;
			List<Double> weights = null;
			List<Double> cubes = null;
			if(chnlMthd.equals("CROSSU") || chnlMthd.equals("SSTK") || chnlMthd.equals("CROSSNA") || chnlMthd.equals("CROSSMNA") || chnlMthd.equals("CROSSMU")) { 
				weights = JsonPath.read(testFlowData, "$..poDetails[?(@.poNumber == '" + poNumber + "')]..weight");
				cubes = JsonPath.read(testFlowData, "$..poDetails[?(@.poNumber == '" + poNumber + "')]..cube");
			} else {
				List<String>deliveryNames = JsonPath.read(testFlowData, "$..deliveryName");
				String getDeliveryResponse = idmSteps.getDeliveryResponse(deliveryNames.get(0)).getBody().asString();
				logger.info("Get Delivery Response=\n"+getDeliveryResponse);
				 weights = JsonPath.read(getDeliveryResponse, "$..deliveryDocuments[*].weight"); 
				 cubes = JsonPath.read(getDeliveryResponse, "$..deliveryDocuments[*].cubeQty"); 
			}
			for(int i=0;i<weights.size();i++) {
				sumOfWeights +=weights.get(i);  
			}
			for(int i=0;i<cubes.size();i++) {
				sumOfCubes +=cubes.get(i);  
			}
			if(chnlMthd.equals("CROSSU") || chnlMthd.equals("SSTK") || chnlMthd.equals("CROSSNA") || chnlMthd.equals("CROSSMNA") || chnlMthd.equals("CROSSMU")) {
				poNumber = environment.getProperty("WTMS_DEFAULT_PO_NUMBER");
				sumOfWeights *= sumOfCases;
				sumOfCubes *= sumOfCases;
			}
			
			List<Integer> noOfCasesFromAPIResponse = JsonPath.read(responseBody, "$.orders[?(@.poNumber == '" + poNumber +"')]..cases");
			List<Integer> noOfPalletsFromAPIResponse = JsonPath.read(responseBody, "$.orders[?(@.poNumber == '" + poNumber +"')]..pallets");
			List<Double> weightsFromAPIResponse = JsonPath.read(responseBody, "$.orders[?(@.poNumber == '" + poNumber +"')]..weight");
			List<Double> cubesFromAPIResponse = JsonPath.read(responseBody, "$.orders[?(@.poNumber == '" + poNumber +"')]..cube");
			Assert.assertEquals(ErrorCodes.WTMS_NO_OF_CASES_MATCH_FAILED, sumOfCases, noOfCasesFromAPIResponse.get(0));
			Assert.assertEquals(ErrorCodes.WTMS_NO_OF_PALLETS_MATCH_FAILED, sumOfpallets, noOfPalletsFromAPIResponse.get(0));
			Assert.assertEquals(ErrorCodes.WTMS_WEIGHT_MATCH_FAILED, Math.ceil(sumOfWeights), Double.parseDouble(""+weightsFromAPIResponse.get(0)));
			Assert.assertEquals(ErrorCodes.WTMS_CUBE_MATCH_FAILED, Math.ceil(sumOfCubes), Double.parseDouble(""+cubesFromAPIResponse.get(0)));
		}
		}
	}
	
}