package com.walmart.supplychain.nextgen.loading.pages.mobile;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.findby.By;

public class LoadingAppPage extends SerenityHelper {

	Logger logger = LoggerFactory.getLogger(LoadingAppPage.class);
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	PropertyResolver propertyResolver = new PropertyResolver();

	@FindBy(xpath = "//img[@class='img_bar_code_scan']")
	private WebElement scanBar;

	@FindBy(xpath = "//mat-label[@class='scan_title_message mat-title']")
	private WebElement titleMsg;

	@FindBy(xpath = "//img[@class='img_scan_trailer']")
	private WebElement scanTrailer;

	@FindBy(xpath = "//button[@id='add_destination_btn']//span//span")
	private WebElement addDestBtn;

	@FindBy(xpath = "//button[@id='load_summary_fab_btn']")
	private WebElement closeLoadTickButton;

	@FindBy(xpath = "//mat-icon[text()='more_vert']")
	private WebElement loadDetailsBtn;

	@FindBy(id = "vertical_menu_load_details")
	private WebElement loadDetails;

	@FindBy(id = "ldLoadId")
	private WebElement loadIdTxt;

	@FindBy(xpath = "//button[@id='fab_menu_close_load']")
	private WebElement closeLoadBtn;

	@FindBy(xpath = "//button[@id='fab_menu_hold_load']")
	private WebElement holdLoadBtn;

	@FindBy(xpath = "//input[@id='seal_number']")
	private WebElement sealNumberTxt;

	@FindBy(xpath = "//span[@ng-reflect-translate='close_load_caps']")
	private WebElement closeLoad;

	@FindBy(xpath = "//a[@id='ldCloseButton']/span/mat-icon")
	private WebElement closeBtn;

	@FindBy(xpath = "//button[@id='vertical_menu_unload']")
	private WebElement unloadBtn;

	@FindBy(xpath = "//input[@id='container']")
	private WebElement unloadScan;

	@FindBy(xpath = "//button[@id='unload']/span/span")
	private WebElement popupunload;

	@FindBy(xpath = "//button[@id='vertical_menu_ready_for_cases']")
	private WebElement readyForCasesBtn;

	@FindBy(xpath = "//button[@id='vertical_menu_start_sorter_diversion']")
	private WebElement startDiversionBtn;

	@FindBy(xpath = "//button[@id='vertical_menu_stop_sorter_diversion']")
	private WebElement stopDiversionBtn;
	
	@FindBy(xpath = "//div[@id='cdk-overlay-1']/div/div//div[3]")
	private WebElement startStopBtnContent;

	@FindBy(css = "div[class='mat-dialog-content']>p")
	private WebElement ctrNotFoundMessage;

	@FindBy(css = "span[ng-reflect-translate='got_it_caps']")
	private WebElement gotItMessage;

	@FindBy(xpath = "//span[text()='YES']")
	private WebElement loadPopupYes;

	@FindBy(xpath = "//input[@id='destination']")
	private WebElement destinationInput;

	@FindBy(xpath = "//span[text()='CREATE']")
	private WebElement loadPopupCreateBtn;

	@FindBy(xpath = "//span[contains(text(),'CONTINUE')]")
	private WebElement overLoadContinueBtn;

	@FindBy(xpath = "//div[contains(text(),'Trailer Overweight')]")
	private WebElement trailerOverWeight;

	@FindBy(xpath = "//mat-dialog-container//span[@class='mat-button-wrapper']/span[text()='NO']")
	private WebElement afterClosePopup;

	@FindBy(xpath = "//span[@ng-reflect-translate='hold_load_caps']")
	private WebElement holdLoad;

	@FindBy(css = "button[id='load_summary_vertical_menu']")
	private WebElement loadSummaryMenu;

	@FindBy(css = "button[id='vertical_menu_unload']")
	private WebElement unloadMenu;

	@FindBy(css = "input[id='container']")
	private WebElement containerTextField;

	@FindBy(css = "span[ng-reflect-translate='unload_caps']")
	private WebElement unloadButton;
	
	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/div[3]")
	private WebElement validateStartDiversion;

	public void clickAddDestBtn() {
		click(addDestBtn);
		logger.info("Added destination in loading");
	}

	public void verifyTrailerIsOverWeight() {
		element(trailerOverWeight).waitUntilVisible();
		logger.info("Trailer is over-weight");
	}

	public void clickContinueBtn() throws InterruptedException {
		WebDriver driver = getDriverInstance();
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(overLoadContinueBtn));
		click(overLoadContinueBtn);
		logger.info("Clicked on Continue button to overload the container");
	}

	public String generateLoadId(List<String> cntrList, String door, String trailer) {
		Set<String> disctinctcontainers = new HashSet<>();
		for (int i = 0; i < cntrList.size(); i++) {
			logger.info("scanning container: {}", cntrList.get(i));
			disctinctcontainers.add(cntrList.get(i));
		}
		List<String> containerList = new ArrayList<>();
		for (String container : disctinctcontainers) {
			containerList.add(container);
		}
		element(scanBar).waitUntilVisible();
		logger.info("Scan bar is available now");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Failsafe.with(retryPolicy).run(() -> {
			for (int i = 0; i < containerList.size(); i++) {
				String parentCntr = (String) containerList.get(i);
				logger.info(parentCntr+" is the parentCntr");
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
								+ parentCntr + "'; return scan;})()));");
				Thread.sleep(1000);
				element(titleMsg).waitUntilVisible();
				logger.info("Loading:Scanned container {}", parentCntr);

			}
		});

		Failsafe.with(retryPolicy).run(() -> {
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ door + "'; return scan;})()));");
			element(scanTrailer).waitUntilVisible();
			logger.info("\n\nDoor scan is successful: " + door);
		});
		logger.info("Loading:Scanned door {}", door);
		Failsafe.with(retryPolicy).run(() -> {
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ trailer + "'; return scan;})()));");

			element(addDestBtn).waitUntilVisible();
		});
		logger.info("Loading:Scanned trailer {}", trailer);
		click(addDestBtn);
		click(loadDetailsBtn);
		click(loadDetails);
		String loadID = loadIdTxt.getText();

		logger.info("loadId Generated in Loading. loadId: {}", Integer.parseInt(loadIdTxt.getText()));
		// driver.quit();
		return loadID;
	}

	public void scanContainer(String cntr) throws InterruptedException {
		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
				+ cntr + "'; return scan;})()));");
		Thread.sleep(1000);
		element(titleMsg).waitUntilVisible();
		logger.info("Loading:Scanned container {}", cntr);

	}

	public void scanDoor(String door) {
		WebDriver driver = getDriverInstance();
		element(scanBar).waitUntilVisible();
		logger.info("Scan bar is available now");
		Failsafe.with(retryPolicy).run(() -> {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
				+ door + "'; return scan;})()));");
		
		Assert.assertFalse(ErrorCodes.LOADING_DOOR_SCAN_FAILED, element(scanBar).isVisible());
		});
		logger.info("Loading:Scanned door {}", door);

	}

	public void scanDoorForLoadingOvershoot(String door) {
		WebDriver driver = getDriverInstance();
		element(scanBar).waitUntilVisible();
		logger.info("Scan bar is available now");
		Failsafe.with(retryPolicy).run(() -> {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ door + "'; return scan;})()));");

		});
		logger.info("Loading:Scanned door {}", door);
	}

	public void closeLoad(String sealNo, String doorType) {
		waitFor(closeLoadTickButton);
		try {
			Thread.sleep(4000);// wait for scan message to disappear..remove this sleep and add the code to
								// handle message
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		click(closeLoadTickButton);
		click(closeLoadBtn);
		if (Config.DC != DC_TYPE.ATLAS) {
			if (doorType.equals("Y")) {
				click(afterClosePopup);
			}
		}
		element(sealNumberTxt).waitUntilVisible();
		element(sealNumberTxt).type(sealNo);
		click(closeLoad);
		try {
			Thread.sleep(4000);// remove this sleep and add the code to handle close message popup
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(scanBar).waitUntilVisible();
		logger.info("seal number at loading:" + sealNo);
		logger.info("load closed successfully");
		WebDriver driver = getDriverInstance();
		// driver.quit();
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);

	}

	public void handleAlertPopup() throws InterruptedException {
		WebDriver driver = getDriverInstance();

		Alert alert = driver.switchTo().alert();
		for (int noOfTimesExecuted = 0; noOfTimesExecuted < 4; noOfTimesExecuted++) {
			waitFor(ExpectedConditions.alertIsPresent());
			alert.dismiss();

			Thread.sleep(100);
		}
		logger.info("pop up neutralised");
	}

	public void unloadContainers(List<String> cntrList, String door) {
		element(loadDetailsBtn).waitUntilClickable();
		for (int i = 0; i < cntrList.size(); i++) {
			click(loadDetailsBtn);
			element(unloadBtn).waitUntilClickable();
			click(unloadBtn);
			logger.info("clicked on Unload button");
			element(unloadScan).waitUntilVisible();
			element(unloadScan).type(cntrList.get(i));
			logger.info("Unload container is added");
			element(popupunload).waitUntilClickable();
			click(popupunload);
			logger.info("clicking on popup unload button");
			element(loadDetailsBtn).waitUntilVisible();
		}

	}

	public void scanLoadDoor(String door) {
		WebDriver driver = getDriverInstance();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
				+ door + "'; return scan;})()));");
		logger.info("Scanned door: {}", door);
		element(loadDetailsBtn).waitUntilVisible();
	}

	public void divertLaneForDoor() throws InterruptedException {

		element(loadDetailsBtn).waitUntilClickable();
		click(loadDetailsBtn);
		element(readyForCasesBtn).waitUntilClickable();
		click(readyForCasesBtn);
		logger.info("clicked on Ready For Cases");
		Thread.sleep(5000);
		element(loadDetailsBtn).waitUntilClickable();
		click(loadDetailsBtn);
		logger.info("Clicked on Load Details icon");
		
		String loadPanelButtonText= validateStartDiversion.getText();
		logger.info("Load panel text "+ loadPanelButtonText);
		
		if(loadPanelButtonText.contains("Start")) {
			element(startDiversionBtn).waitUntilClickable();
			click(startDiversionBtn);
			logger.info("clicked on Start Diverting");
		} else {
			//If no load is opened for door then on clicking ready for cases 
			// automatically start diversion
			logger.info("Load is already diverting and no need to Start diversion");
		}
	}

	public void stopDivertionForDoor() {
		try {
			element(loadDetailsBtn).waitUntilClickable();
			click(loadDetailsBtn);
			element(stopDiversionBtn).waitUntilClickable();
			click(stopDiversionBtn);
		} catch (Exception e) {
			throw e;
		}

	}

	public void scanDamagedContainers(List<String> damageContainers) {

		Set<String> disctinctcontainers = new HashSet<>();
		for (int i = 0; i < damageContainers.size(); i++) {
			logger.info("scanning container:{}", damageContainers.get(i));
			disctinctcontainers.add(damageContainers.get(i).toString());
		}
		List<String> containerList = new ArrayList<>();
		for (String container : disctinctcontainers) {
			containerList.add(container);
		}
		element(scanBar).waitUntilVisible();
		logger.info("Scan bar is available now");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Failsafe.with(retryPolicy).run(() -> {
			for (int i = 0; i < containerList.size(); i++) {
				String parentCntr = (String) containerList.get(i);
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
								+ parentCntr + "'; return scan;})()));");
				Thread.sleep(1000);
				element(ctrNotFoundMessage).waitUntilVisible();
				logger.info("Cannot load the container :{} as its damaged ", parentCntr);
				element(gotItMessage).waitUntilVisible();
				element(gotItMessage).waitUntilClickable();
				element(gotItMessage).click();

			}
		});
	}

	public String generateLoadWithoutContainers(String door, String trailer, String dest) throws InterruptedException {

		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Failsafe.with(retryPolicy).run(() -> {
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ door + "'; return scan;})()));");
			element(scanTrailer).waitUntilVisible();
			logger.info("\n\nDoor scan is successful: " + door);
		});
		logger.info("Loading:Scanned door {}", door);
		Failsafe.with(retryPolicy).run(() -> {
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ trailer + "'; return scan;})()));");
			element(loadPopupYes).waitUntilClickable();
		});
		logger.info("Loading:Scanned trailer {}", trailer);
		click(loadPopupYes);
		element(destinationInput).waitUntilClickable();
		element(destinationInput).type(dest);
		Thread.sleep(3000);
//		WebElement selectDest = driver
//				.findElement(By.xpath("//mat-option[@role='option']//span[text()='" + dest + "']"));
//		element(selectDest).waitUntilClickable();
//		click(selectDest);
		element(loadPopupCreateBtn).waitUntilClickable();
		click(loadPopupCreateBtn);
		click(loadDetailsBtn);
		click(loadDetails);
		String loadID = loadIdTxt.getText();
		logger.info("loadId Generated in Loading. loadId: {}", Integer.parseInt(loadIdTxt.getText()));
		// driver.close();
		return loadID;

	}

	public void closeDriver() {
		getDriverInstance().close();
	}

	public void scanTrailerNumber(String trailer) {

		WebDriver driver = getDriverInstance();
		element(scanTrailer).waitUntilVisible();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
				+ trailer + "'; return scan;})()));");
		logger.info("Loading:Scanned tariler {}", trailer);

	}

	public void holdLoad(String sealNr) {

		logger.info("Holding the Load");
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		waitFor(closeLoadTickButton);
		click(closeLoadTickButton);
		waitFor(holdLoadBtn);
		click(holdLoadBtn);
		element(sealNumberTxt).waitUntilVisible();
		element(sealNumberTxt).type(sealNr);
		logger.info("Enetred sealNR");
		element(holdLoad).click();

	}

	public void scanDoorAndTrailer(String doorNr, String trailerNr) {

		WebDriver driver = getDriverInstance();
		element(scanBar).waitUntilVisible();
		logger.info("Scan bar is available now");
		sleep(4);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Failsafe.with(retryPolicy).run(() -> {
			String script="document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ doorNr + "'; return scan;})()));";
			logger.info("Scanning door : " + script);
			js.executeScript(script);
			element(scanTrailer).waitUntilVisible();
			logger.info("Door scan is successful: " + doorNr);
		});
		logger.info("Loading:Scanned door {}", doorNr);
		Failsafe.with(retryPolicy).run(() -> {
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ trailerNr + "'; return scan;})()));");
		});
		logger.info("Loading:Scanned trailer {}", trailerNr);

	}

	public void unloadContainer(String unloadedContainer) {

		WebDriver driver = getDriverInstance();
		element(loadSummaryMenu).waitUntilVisible();
		logger.info("LoadSummaryMenu is available now");
		sleep(4);
		click(loadSummaryMenu);
		click(unloadMenu);
		element(containerTextField).waitUntilVisible();
		containerTextField.sendKeys(unloadedContainer);
		element(unloadButton).waitUntilClickable();
		click(unloadButton);

	}

	public void addContainersToExistingLoad(String door, String cntr) {
		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Failsafe.with(retryPolicy).run(() -> {
				js.executeScript(
						"document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
								+ cntr + "'; return scan;})()));");
				Thread.sleep(1000);
				element(titleMsg).waitUntilVisible();
				Assert.assertTrue(ErrorCodes.LOADING_CNTR_SCAN_FAILED, element(titleMsg).isVisible());
				logger.info("Loading:Scanned container {}", cntr);
		});

		Failsafe.with(retryPolicy).run(() -> {
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ door + "'; return scan;})()));");
			element(addDestBtn).waitUntilVisible();
			Assert.assertTrue(ErrorCodes.LOADING_DOOR_SCAN_FAILED,element(addDestBtn).isVisible());
			logger.info("\n\nDoor scan is successful: " + door);
		});
		click(addDestBtn);
	}
}
