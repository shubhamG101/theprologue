package com.walmart.supplychain.baja.of.ScenarioSteps;

import java.util.ArrayList;
import java.util.Random;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.baja.of.step.OrderFulfilmentSteps;
import com.walmart.supplychain.baja.of.step.SimulateOPCMessageFromSwisslogToOF;
import com.walmart.supplychain.baja.of.step.UpdateOrderID;
import com.walmart.supplychain.nextgen.orderwell.gluecode.OrderWell;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderFulfilmentScenarios {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrderWell.class);
	
	@Steps
	UpdateOrderID upOrder;

	@Steps
	OrderFulfilmentSteps ofSteps;

	@Autowired
	SimulateOPCMessageFromSwisslogToOF simulateOPC;
		
	@Given("^User simulates the opc messages from swisslog to OF for given load for \"([^\"]*)\"$")
	public void userUpdatesTheOrderId(String typeofPick) throws ParseException, InterruptedException
	{
	
		if(typeofPick.equals("bulk"))
		{
			upOrder.updateOrderID();
			simulateOPC.updateOPCMessageForBulkPick();	
		}
		
		if(typeofPick.equals("Trip"))
		{
	//		simulateOPC.updateOPCMessageForTrip("3456734567884", "1065",listOfTUIDs);
		}
		
	}
	
	@Then("^User verifies bulk pick should get created witin OF$")
	public void bulkPickVerification() {
		ofSteps.verifyBulkPick();
	}
	
	
	@Then("^User verifies bulk pick should not get created witin OF$")
	public void NobulkPickVerification() {
		LOGGER.info("Verify that NO bulkpick is created for Invalid Quantity");
		ofSteps.verifyNOBulkPick();
	}

}
