package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.annotations.findby.By;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

public class ProblemExceptionSubTypePage extends MobilePageObject{
	Logger logger = LogManager.getLogger(this.getClass());
	
	public ProblemExceptionSubTypePage(WebDriver driver){
        super(driver);
    }
	
	@AndroidFindBy(xpath = "//*[@text='Not on PO']")
	private WebElement notOnPO_RadionButton;
	
	@AndroidFindBy(xpath = "//*[contains(@text,'Not Walmart Freight')]")
	private WebElement notWalmartFreight_RadionButton;
	
	@AndroidFindBy(xpath = "//*[contains(@text,'Wrong DC')]")
	private WebElement wrongDC_RadionButton;
	
	@AndroidFindBy(xpath = "//*[contains(@text,'Hazmat')]")
	private WebElement hazmat_RadionButton;
	
	@AndroidFindBy(xpath = "//*[contains(@text,'Wrong Pack')]")
	private WebElement wrongPack_RadionButton;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	private WebElement next_Button;
	
	@AndroidFindBy(xpath = "//*[@text='Overage']")
	private WebElement overrage_RadionButton;
	
	@AndroidFindBy(xpath = "//*[@text='Quality Issue']")
	private WebElement qualityIssue_RadionButton;
	
	@AndroidFindBy(xpath = "//*[@text='Date Issue']")
	private WebElement dateIssue_RadionButton;
	
	//RDC changes
	@AndroidFindBy(xpath = "//*[@text='Recall']")
	private WebElement recall_RadionButton;
	
	@AndroidFindBy(xpath = "//*[@text='Damage']")
	private WebElement damage_RadionButton;

	//Pharmacy Changes
	@AndroidFindBy(xpath = "//*[@text='Suspect']")
	private WebElement suspect_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='No Label']")
	private WebElement nolabel_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='ASN not downloaded']")
	private WebElement asnNotDownloaded_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='PO Issue']")
	private WebElement poIssue_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='ASN Issue']")
	private WebElement asnIssue_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='PO/ASN Issue']")
	private WebElement poAsnIssue_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='Missing all label']")
	private WebElement missingAllLabel_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='Missing SSCC']")
	private WebElement missingSSCC_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='Missing 2D barcode']")
	private WebElement missing2dBarcode_RadionButton;

	@AndroidFindBy(xpath = "//*[@text='Label not scannable']")
	private WebElement labelNotScannable_RadionButton;

	public void selectNotOnPO() {
		element(notOnPO_RadionButton).waitUntilClickable();
		element(notOnPO_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}
	
	public void selectnotWalmartFreight() {
		notWalmartFreight_RadionButton.click();
		next_Button.click();
	}
	
	public void selectwrongDC() {
		element(wrongDC_RadionButton).waitUntilClickable();
		element(wrongDC_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}
	
	public void selectHazmat() {
		hazmat_RadionButton.click();
		next_Button.click();
	}
	
	public void selectWrongPack() {
		wrongPack_RadionButton.click();
		next_Button.click();
	}
	
	public void selectDamage() {
		element(damage_RadionButton).waitUntilClickable();
		element(damage_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}
	
	public void selectRecall() {
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(recall_RadionButton).waitUntilClickable();
		element(recall_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}
	
	public void selectOverrage() {
		element(overrage_RadionButton).waitUntilEnabled();
		element(overrage_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}
	
	public void selectQualityIssue() {
		element(qualityIssue_RadionButton).waitUntilEnabled();
		element(qualityIssue_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}
	
	public void selectDateIssue() {
		element(dateIssue_RadionButton).waitUntilEnabled();
		element(dateIssue_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectSuspect() {
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(suspect_RadionButton).waitUntilClickable();
		element(suspect_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}

	public void selectNoLabel() {
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(nolabel_RadionButton).waitUntilClickable();
		element(nolabel_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}

	public void selectAsnNotDownloaded() {
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(asnNotDownloaded_RadionButton).waitUntilClickable();
		element(asnNotDownloaded_RadionButton).click();
		element(next_Button).waitUntilClickable();
		element(next_Button).click();
	}

	public void selectSubType(String subtype){
		getAndroidDriver().findElementByXPath("//*[@text='" + subtype + "']").click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectPoIssue() {
		element(poIssue_RadionButton).waitUntilEnabled();
		element(poIssue_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectAsnIssue() {
		element(asnIssue_RadionButton).waitUntilEnabled();
		element(asnIssue_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectPoAsnIssue() {
		element(poAsnIssue_RadionButton).waitUntilEnabled();
		element(poAsnIssue_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectMissingAllLabel() {
		element(missingAllLabel_RadionButton).waitUntilEnabled();
		element(missingAllLabel_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectMissingSSCC() {
		element(missingSSCC_RadionButton).waitUntilEnabled();
		element(missingSSCC_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectMissing2dBarcode() {
		element(missing2dBarcode_RadionButton).waitUntilEnabled();
		element(missing2dBarcode_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void selectLabelNotScannable() {
		element(labelNotScannable_RadionButton).waitUntilEnabled();
		element(labelNotScannable_RadionButton).click();
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
	    return (AndroidDriver<AndroidElement>)
	            ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
}
