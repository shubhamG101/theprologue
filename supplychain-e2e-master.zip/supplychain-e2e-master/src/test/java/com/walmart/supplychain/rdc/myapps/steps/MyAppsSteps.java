package com.walmart.supplychain.rdc.myapps.steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.rdc.gdm.steps.webservices.RdcGDMHelper;
import com.walmart.supplychain.witron.gdm.Pages.GDMUnifiedHomePage;
import com.walmart.supplychain.witron.gdm.Pages.GDMUnifiedLoginPage;
import com.walmart.supplychain.witron.loading.pages.MyAppsTabletLoginPage;
import com.walmart.supplychain.witron.myapps.pages.MyAppsHomePage;

import io.restassured.response.Response;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class MyAppsSteps {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	RDCUtil rdcUtil;

	@Autowired
	DbUtils dbUtils;

	Response response;

	@Autowired
	MyAppsTabletLoginPage myAppsTabletLoginPage;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	ObjectMapper om = new ObjectMapper();

	@Autowired
	MyAppsHomePage myAppsHomePage;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	String testFlowData;

	@Step
	public void loginToMyApps() {
		try {
			if (Config.DC == DC_TYPE.RDC) {
				List<String> packageList = new ArrayList<String>();
				packageList.add(environment.getProperty("receiving_app_package"));
				myAppsTabletLoginPage.killApp(packageList);
			}

			boolean isReceivingAppOpen = myAppsTabletLoginPage.loginToMyapps(environment.getProperty("myApps_userName"),
					environment.getProperty("myApps"), environment.getProperty("facility_num"));
			Thread.sleep(7000);
			if (!isReceivingAppOpen) {
				myAppsHomePage.navigateToReceivingApp();
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Login to My apps", e);
		}
	}

	@Step
	public void killMyApps() {
		try {
			myAppsHomePage.signOutMyApps();
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Kill My apps", e);
		}
	}

}
