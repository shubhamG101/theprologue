package com.walmart.supplychain.nextgen.receiving.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.given;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingHelper extends PageObject {

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	InventorySteps invStep;
	@Autowired
	// @Qualifier(value="mongoTest")
	MongoUtil mongoUtil;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtil;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private static final String DA_TRACKING_ID = "$[?(@.containerType=='Vendor Pack')].trackingId";

	private static final String DA_PARENT_TRACKING_ID = "$[?(@.containerType=='Vendor Pack')].parentTrackingId";
	private static final String DA_MESSAGE_ID = "$[?(@.containerType=='Vendor Pack')].messageId";
	private static final String DA_CHANNEL_METHOD = "$[?(@.containerType=='Vendor Pack')].containerItems[*].inboundChannelMethod";
	private static final String DA_DESTINATION = "$[?(@.containerType=='Vendor Pack')].destination.buNumber";
	private static final String CONTAINER_TYPE = "$[*].containerType";
	private static final String SSTK_PARENT_TRACKING_ID = "$[?(@.containerType=='PALLET')].trackingId";
	private static final String SSTK_MESSAGE_ID = "$[?(@.containerType=='PALLET')].messageId";
	private static final String SSTK_CHANNEL_METHOD = "$[?(@.containerType=='PALLET')].containerItems[*].inboundChannelMethod";
	private static final String SSTK_DESTINATION = "$[?(@.containerType=='PALLET')].destination.buNumber";
	private static final String PBYL_DESTINATION = "$[?(@.containerType=='PALLET')].facility.buNumber";
	Response deliveryCancelResponse;

	Logger logger = LogManager.getLogger(this.getClass());

	public String getDatafromRecInstructionDB(String db, String collection, String deliveryNumber, String poNumber)
			throws FileNotFoundException, SQLException, JsonProcessingException, ParseException {
		List<String> containerList = null;
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		MongoClient mongoClient = mongoUtil.createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		MongoCollection<Document> table = database.getCollection(collection);
		BasicDBObject searchQuery_ParentContID = new BasicDBObject();
		searchQuery_ParentContID.put("deliveryNumber", deliveryNumber);
		searchQuery_ParentContID.append("purchaseReferenceNumber", poNumber);

		FindIterable<Document> res_ParentContainerList = table.find(searchQuery_ParentContID);

		for (Document res_ParentCont : res_ParentContainerList) {
			DocumentContext res_ParentCont_parsed = JsonPath.parse(res_ParentCont.toJson());
			containerList = res_ParentCont_parsed.read("$.instructionData..trackingId");
		}
		logger.info("Cancelled Container lpn in receiving is {}", containerList.get(0));
		mongoUtil.closeConnection(mongoClient);
		return containerList.get(0);
	}

	public void getDatafromDB_Rec(String db, String collection, String deliveryNumber, String poNumber, int itemNumber)
			throws FileNotFoundException, SQLException, JsonProcessingException, ParseException {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		MongoClient mongoClient = mongoUtil.createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		JSONArray instArray = new JSONArray();
		MongoCollection<Document> table = database.getCollection(collection);
		BasicDBObject searchQuery_ParentContID = new BasicDBObject();
		searchQuery_ParentContID.put("deliveryNumber", deliveryNumber);
		searchQuery_ParentContID.append("contents.purchaseReferenceNumber", poNumber);

		List<String> poType = JsonPath.read(testFlowData,
				"$..poDetails[?(@.poNumber=='" + poNumber + "')].channelMethod");
		if (poType.get(0).equalsIgnoreCase("POCON")) {
			searchQuery_ParentContID.append("contents.itemNumber", -1);
		} else {
			searchQuery_ParentContID.append("contents.itemNumber", itemNumber);
			searchQuery_ParentContID.append("containerType", "PALLET");
		}

		List<ReceivingInstruction> instructionList = new ArrayList<>();
		if (table.count(searchQuery_ParentContID) > 0) {
			instructionList = storeContainersForNonDaConFrieghts(db, collection, table, searchQuery_ParentContID,
					instructionList);

		}
		searchQuery_ParentContID.append("containerType", "Vendor Pack");
		if (table.count(searchQuery_ParentContID) > 0) {
			instructionList = storeContainerForDaConFreight(db, collection, table, searchQuery_ParentContID,
					instructionList);
		}

		if (poType.get(0).equalsIgnoreCase("POCON")) {
			instructionList.get(0)
					.setDestNumber(String.valueOf(Integer.valueOf(instructionList.get(0).getDestNumber())));
			instructionList.get(0).setChannelType("POCON");
		}
		mongoUtil.closeConnection(mongoClient);

		JSONArray instructJSONArry = jsonUtil.converyListToJsonArray(instructionList);
		String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, instructJSONArry,
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber=="
						+ itemNumber + ")].receivingInstructions");
		threadLocal.get().put("testFlowData", testFlowData_updated);
		System.out.println("TestFlowData after updating receive instructions:" + testFlowData_updated);
	}

	public void getDatafromDB_RecForManuallyReceivedCont(String db, String collection, String deliveryNumber,
			String poNumber, int itemNumber)
			throws FileNotFoundException, SQLException, JsonProcessingException, ParseException {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		MongoClient mongoClient = mongoUtil.createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		JSONArray instArray = new JSONArray();
		MongoCollection<Document> table = database.getCollection(collection);
		BasicDBObject searchQuery_ParentContID = new BasicDBObject();
		searchQuery_ParentContID.put("deliveryNumber", deliveryNumber);
		searchQuery_ParentContID.append("contents.purchaseReferenceNumber", poNumber);

		List<String> poType = JsonPath.read(testFlowData,
				"$..poDetails[?(@.poNumber=='" + poNumber + "')].channelMethod");
		searchQuery_ParentContID.append("contents.itemNumber", itemNumber);
		searchQuery_ParentContID.append("containerType", "Vendor Pack");

		List<ReceivingInstruction> instructionList = new ArrayList<>();

		if (table.count(searchQuery_ParentContID) > 0) {
			instructionList = storeContainersForDaConFrieghtsWithoutParent(db, collection, table,
					searchQuery_ParentContID, instructionList);
		}
		mongoUtil.closeConnection(mongoClient);

		JSONArray instructJSONArry = jsonUtil.converyListToJsonArray(instructionList);
		String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, instructJSONArry,
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber=="
						+ itemNumber + ")].receivingInstructions");
		threadLocal.get().put("testFlowData", testFlowData_updated);
		System.out.println("TestFlowData after updating receive instructions:" + testFlowData_updated);
	}

	public DocumentContext getContainerResponsefromRecv() {
		Response response;
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		DocumentContext parsedJson = JsonPath.parse(testFlowData);
		try {

			if (Config.DC == DC_TYPE.ATLAS) {
				List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
				String delNumber = deliveryNumberList.get(0);
				response = given().relaxedHTTPSValidation().headers(getReceivingHeaders()).when()
						.get(environment.getProperty("receiving_container_url") + delNumber);
				logger.info("Receiving URL = " + environment.getProperty("receiving_container_url") + delNumber);

				parsedJson = JsonPath.parse(response.asString());
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status after VTR", e);
		}
		return parsedJson;
	}

	public void vtrByReceiving(String vtrContr) {

		try {
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			DocumentContext parsedJson = JsonPath.parse(testFlowData);
			List<String> delvryNum = parsedJson.read("$.testFlowData.deliveryDetails[*].deliveryNumber");
			JSONArray cntrNum = new JSONArray();
			cntrNum.add(vtrContr);
			JSONObject payload = new JSONObject();
			payload.put("deliveryNumber", delvryNum.get(0).toString());
			payload.put("trackingIds", cntrNum);

			logger.info("VTRd container payload {} ", payload);

			Failsafe.with(retryPolicy).run(() -> {

				Response response = given().relaxedHTTPSValidation().headers(getReceivingHeaders()).body(payload)
						.post(environment.getProperty("vtr_Receiving"));

				Assert.assertEquals(ErrorCodes.RECEIVING_VTR_VALIDATION, Constants.UPDATE_SUCESS_STATUS_CODE,
						response.getStatusCode());
				logger.info("VTRd container successfully {} ", vtrContr);
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating VTR container", e);
		}
	}

	public void updateReReceivingInstructionPostVTR(String poNumber, int itemNumber, String Channel)
			throws JsonGenerationException, JsonMappingException, IOException, ParseException {
		ObjectMapper mapper = new ObjectMapper();
		JSONParser parser = new JSONParser();

		DocumentContext contrRes;
		List<String> sstkRecContr = new ArrayList<String>();
		List<String> daRecContr = new ArrayList<String>();

		String testFlowData = threadLocal.get().get("testFlowData").toString();
		JSONArray OrigionalRecInstr = JsonPath.read(testFlowData,
				"$.testFlowData..poLineDetails..receivingInstructions[*]");

		JSONArray parentcontr = JsonPath.read(testFlowData,
				"$.testFlowData..poLineDetails..receivingInstructions[*].parentContainer");
		List<String> parentListfromOrgInstr = new ArrayList<String>();
		for (int i = 0; i < parentcontr.size(); i++) {
			parentListfromOrgInstr.add(parentcontr.get(i).toString());
		}
		contrRes = getContainerResponsefromRecv();

		if (Channel.contentEquals("STAPLESTOCK") || Channel.contentEquals("SSTKU")) {
			JSONArray sstkRecContrArr = contrRes.read("$..[?(@.containerType=='PALLET')].trackingId");
			for (int i = 0; i < sstkRecContrArr.size(); i++) {
				sstkRecContr.add(sstkRecContrArr.get(i).toString());
			}

			for (String sstkContainer : sstkRecContr) {
				if (parentListfromOrgInstr.contains(sstkContainer))
					continue;
				else {
					String reRecvSstkContr = sstkContainer;
					ReceivingInstruction recInstruction = new ReceivingInstruction();
					recInstruction.setChannelType(Channel);
					recInstruction.setIsVTR(false);
					recInstruction.setIsPbyl(false);
					recInstruction.setIsDamage(false);
					recInstruction.setParentContainer(reRecvSstkContr.toString());
					List<String> ordrList = invStep.containerToOrderIdMapping(reRecvSstkContr);
					recInstruction.setOrderIds(ordrList);
					recInstruction.setChannelType(Channel.toString());
					JSONArray destinationArr = contrRes
							.read("$[?(@.trackingId=='" + reRecvSstkContr + "')]..destination.buNumber");
					recInstruction.setDestNumber(String.valueOf(destinationArr.get(0)));
					JSONArray mesgIdArr = contrRes.read("$[?(@.trackingId=='" + reRecvSstkContr + "')]..messageId");
					recInstruction.setMessageId(String.valueOf(mesgIdArr.get(0)));
					JSONArray SstkrecContQty = contrRes.read("$[?(@.trackingId=='" + reRecvSstkContr + "')]..quantity");
					JSONArray SstkrecContVNPK = contrRes.read("$[?(@.trackingId=='" + reRecvSstkContr + "')]..vnpkQty");
					int recvedQty = Integer.parseInt(String.valueOf(SstkrecContQty.get(0)))
							/ Integer.parseInt(String.valueOf(SstkrecContVNPK.get(0)));
					recInstruction.setReceivedQuantity(String.valueOf(recvedQty));
					String recInstSstk = mapper.writeValueAsString(recInstruction);
					JSONObject jsonRecInt = (JSONObject) parser.parse(recInstSstk);
					OrigionalRecInstr.add(jsonRecInt);
				}

			}
		} else {

			JSONArray daRecContrArr = contrRes.read("$..parentTrackingId");
			logger.info("container Size = " + daRecContrArr.size() + daRecContrArr.toJSONString().toString());

			for (int i = 0; i < daRecContrArr.size(); i++) {
				if (daRecContrArr.get(i) == null)
					continue;
				else {
					logger.info("Adding containers = " + daRecContrArr.get(i).toString());

					daRecContr.add(daRecContrArr.get(i).toString());
				}
			}
			for (int i = 0; i < parentListfromOrgInstr.size(); i++) {
				logger.info("orogional parent containers = " + parentListfromOrgInstr.get(i).toString());
			}

			for (int i = 0; i < daRecContr.size(); i++) {
				logger.info("Adding to final list = " + daRecContr.get(i).toString());
			}

			logger.info("AFter removing null = " + daRecContrArr.size() + daRecContrArr.toJSONString().toString());

			for (String daContainer : daRecContr) {
				if (parentListfromOrgInstr.contains(daContainer))
					logger.info("In DA IF " + daContainer);
				else {
					logger.info("In DA ELSE " + daContainer);

					String reRecvDaContr = daContainer;
					ReceivingInstruction recInstruction = new ReceivingInstruction();
					recInstruction.setParentContainer(daContainer);
					recInstruction.setChannelType(Channel);
					recInstruction.setIsVTR(false);
					recInstruction.setIsPbyl(false);
					recInstruction.setIsDamage(false);
					List<String> childContainers = new ArrayList<String>();

					JSONArray childrencon = contrRes.read("$[?(@.parentTrackingId=='" + daContainer + "')].trackingId");
					for (int i = 0; i < childrencon.size(); i++) {
						childContainers.add(childrencon.get(i).toString());
					}

					List<String> orderIds = new ArrayList<String>();

					JSONArray ordersIds = contrRes.read("$[?(@.parentTrackingId=='" + daContainer + "')]..orderId");
					for (int i = 0; i < ordersIds.size(); i++) {
						orderIds.add(ordersIds.get(i).toString());
					}

					recInstruction.setChildContainers(childContainers);
					recInstruction.setIsGFCS(false);

					recInstruction.setOrderIds(orderIds);

					JSONArray destinationArr = contrRes
							.read("$[?(@.parentTrackingId=='" + reRecvDaContr + "')]..destination.buNumber");
					recInstruction.setDestNumber(String.valueOf(destinationArr.get(0)));
					JSONArray mesgIdArr = contrRes.read("$[?(@.parentTrackingId=='" + reRecvDaContr + "')]..messageId");
					recInstruction.setMessageId(String.valueOf(mesgIdArr.get(0)));
					JSONArray daRecContQty = contrRes
							.read("$[?(@.parentTrackingId=='" + reRecvDaContr + "')]..quantity");
					JSONArray daRecContVNPK = contrRes
							.read("$[?(@.parentTrackingId=='" + reRecvDaContr + "')]..vnpkQty");
					int recvedQty = Integer.parseInt(String.valueOf(daRecContQty.get(0)))
							/ Integer.parseInt(String.valueOf(daRecContVNPK.get(0)));
					recInstruction.setReceivedQuantity(String.valueOf(recvedQty));
					String recInstDa = mapper.writeValueAsString(recInstruction);
					JSONObject jsonRecInt = (JSONObject) parser.parse(recInstDa);
					logger.info("Before adding Container " + OrigionalRecInstr.toJSONString());
					OrigionalRecInstr.add(jsonRecInt);
					logger.info("Updated Container " + OrigionalRecInstr.toJSONString());

				}

			}
		}

		String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, OrigionalRecInstr,
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber=="
						+ itemNumber + ")].receivingInstructions");
		threadLocal.get().put("testFlowData", testFlowData_updated);
		logger.info("TestFlowData after updating receive instructions:"
				+ String.valueOf(threadLocal.get().get("testFlowData")));
	}

	public void updateReceivingInstructionPostSplitPallet(String poNumber, String poLineNumber, String reRecvSstkContr,
			String splitQty,String rotateDate) throws JsonGenerationException, JsonMappingException, IOException, ParseException {
	
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		ObjectMapper mapper = new ObjectMapper();

		JSONParser parser = new JSONParser();

		DocumentContext contrRes;

//		ObjectMapper mapper = new ObjectMapper();
//		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		contrRes = JsonPath.parse(testFlowData);

		JSONArray OrigionalRecInstr = contrRes.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
				+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].receivingInstructions[*]");
		
		

		ReceivingInstruction recInstruction = new ReceivingInstruction();
		recInstruction.setChannelType("SSTKU");
		recInstruction.setrotateDate(rotateDate);
		recInstruction.setIsVTR(false);


//		recInstruction.setIsPbyl(false);
//		recInstruction.setIsDamage(false);
		//recInstruction.setParentContainerStatus(false);

		recInstruction.setParentContainer(reRecvSstkContr.toString());
		recInstruction.setDestNumber(environment.getProperty("facility_num"));
		recInstruction.setReceivedQuantity(splitQty);
		String recInstSstk = mapper.writeValueAsString(recInstruction);
		JSONObject jsonRecInt = (JSONObject) parser.parse(recInstSstk);
		OrigionalRecInstr.add(jsonRecInt);

		String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, OrigionalRecInstr,
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber=="
						+ poLineNumber + ")].receivingInstructions");
		threadLocal.get().put("testFlowData", testFlowData_updated);
		logger.info("TestFlowData after updating receive instructions:"
				+ String.valueOf(threadLocal.get().get("testFlowData")));
	}

	public void getDatafromDB_Rec_ForVTR(String db, String collection, String deliveryNumber, String poNumber,
			int itemNumber, List<String> rcvdParentContainerList, List<String> alreadyRcvdContainerInst)
			throws SQLException, ParseException, JsonGenerationException, JsonMappingException, IOException {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		List<String> backoutList = new ArrayList<String>();
		ObjectMapper mapper = new ObjectMapper();
		backoutList.add("BACKOUT");
		MongoClient mongoClient = mongoUtil.createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		JSONArray instArray = new JSONArray();
		MongoCollection<Document> table = database.getCollection(collection);
		BasicDBObject searchQuery_ParentContID = new BasicDBObject();
		searchQuery_ParentContID.put("deliveryNumber", deliveryNumber);
		searchQuery_ParentContID.append("contents.purchaseReferenceNumber", poNumber);
		searchQuery_ParentContID.append("contents.itemNumber", itemNumber);
		searchQuery_ParentContID.append("containerType", "PALLET");

		List<ReceivingInstruction> instructionList = new ArrayList<>();
		searchQuery_ParentContID.append("trackingId", new BasicDBObject("$nin", rcvdParentContainerList));
		searchQuery_ParentContID.append("parentTrackingId", new BasicDBObject("$nin", rcvdParentContainerList));
		searchQuery_ParentContID.append("containerStatus", new BasicDBObject("$nin", backoutList));

		JSONArray instructJSONArry = jsonUtil.converyListToJsonArray(alreadyRcvdContainerInst);
		JSONParser parser = new JSONParser();

		if (table.count(searchQuery_ParentContID) > 0) {
			instructionList = storeContainersForNonDaConFrieghts(db, collection, table, searchQuery_ParentContID,
					instructionList);
			for (ReceivingInstruction receivingInstruction : instructionList) {
				String recInst = mapper.writeValueAsString(receivingInstruction);
				JSONObject jsonRecInt = (JSONObject) parser.parse(recInst);
				instructJSONArry.add(jsonRecInt);
			}
		}
		searchQuery_ParentContID.append("containerType", "Vendor Pack");
		if (table.count(searchQuery_ParentContID) > 0) {
			instructionList = storeContainerForDaConFreight(db, collection, table, searchQuery_ParentContID,
					instructionList);
			for (ReceivingInstruction receivingInstruction : instructionList) {
				String recInst = mapper.writeValueAsString(receivingInstruction);
				JSONObject jsonRecInt = (JSONObject) parser.parse(recInst);
				instructJSONArry.add(jsonRecInt);
			}
		}

		mongoUtil.closeConnection(mongoClient);

		String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, instructJSONArry,
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber=="
						+ itemNumber + ")].receivingInstructions");
		threadLocal.get().put("testFlowData", testFlowData_updated);
		System.out.println("TestFlowData after updating receive instructions:"
				+ String.valueOf(threadLocal.get().get("testFlowData")));
	}

	public List<ReceivingInstruction> storeContainersForDaConFrieghtsWithoutParent(String db, String collection,
			MongoCollection<Document> table, BasicDBObject searchQuery_ParentContID,
			List<ReceivingInstruction> instructionList) {
		logger.info(db + " > " + collection + " Executing GET query  for searchQuery_ParentContID : "
				+ searchQuery_ParentContID);
		FindIterable<Document> res_ParentContainerList = table.find(searchQuery_ParentContID);
		BasicDBObject searchQuery_ForChildContID = new BasicDBObject();
		for (Document res_ParentCont : res_ParentContainerList) {
			ReceivingInstruction recInstruction = new ReceivingInstruction();
			searchQuery_ForChildContID.append("trackingId", res_ParentCont.get("trackingId"));
			searchQuery_ForChildContID.append("parentTrackingId", "");
			logger.info(db + " > " + collection + " Executing GET query  for searchQuery_ForChildContID : "
					+ searchQuery_ForChildContID);

			DocumentContext res_ParentCont_parsed = JsonPath.parse(res_ParentCont.toJson());
			recInstruction.setParentContainer(res_ParentCont_parsed.read("$.trackingId").toString());
			recInstruction.setMessageId(res_ParentCont_parsed.read("$.messageId").toString());

			List<String> childContainerList = new ArrayList<>();
			childContainerList.add(res_ParentCont_parsed.read("$.trackingId").toString());
			recInstruction.setChildContainers(childContainerList);
			recInstruction.setChannelType("CROSSU");
			recInstruction.setIsVTR(false);
			recInstruction.setIsPbyl(false);
			recInstruction.setLabelType("normal");
			List<Integer> qtyList = res_ParentCont_parsed.read("$.contents..quantity");
			List<Integer> vnpkQtyList = res_ParentCont_parsed.read("$.contents..vnpkQty");
			int receivedQty = qtyList.get(0) / vnpkQtyList.get(0);
			recInstruction.setReceivedQuantity(String.valueOf(receivedQty));

			try {
				recInstruction.setDestNumber(res_ParentCont_parsed.read("$.finalDestination.buNumber").toString());
			} catch (PathNotFoundException e) {
				recInstruction.setDestNumber("");
			}
			instructionList.add(recInstruction);
		}
		return instructionList;
	}

	public List<ReceivingInstruction> storeContainersForNonDaConFrieghts(String db, String collection,
			MongoCollection<Document> table, BasicDBObject searchQuery_ParentContID,
			List<ReceivingInstruction> instructionList) {
		logger.info(db + " > " + collection + " Executing GET query  for searchQuery_ParentContID : "
				+ searchQuery_ParentContID);
		FindIterable<Document> res_ParentContainerList = table.find(searchQuery_ParentContID);
		BasicDBObject searchQuery_ForChildContID = new BasicDBObject();
		for (Document res_ParentCont : res_ParentContainerList) {
			ReceivingInstruction recInstruction = new ReceivingInstruction();
			searchQuery_ForChildContID.append("parentTrackingId", res_ParentCont.get("trackingId"));
			logger.info(db + " > " + collection + " Executing GET query  for searchQuery_ForChildContID : "
					+ searchQuery_ForChildContID);

			List<String> childContainerList = new ArrayList<>();
			FindIterable<Document> resTable_ChildCont = table.find(searchQuery_ForChildContID);
			for (Document resTable_ChildContList : resTable_ChildCont) {
				childContainerList.add(resTable_ChildContList.getString("trackingId"));
			}

			DocumentContext res_ParentCont_parsed = JsonPath.parse(res_ParentCont.toJson());
			recInstruction.setParentContainer(res_ParentCont_parsed.read("$.trackingId").toString());
			recInstruction.setMessageId(res_ParentCont_parsed.read("$.messageId").toString());
			recInstruction.setChildContainers(childContainerList);
			recInstruction.setChannelType("");
			recInstruction.setIsVTR(false);
			recInstruction.setIsPbyl(false);
			recInstruction.setLabelType("normal");
			List<Integer> qtyList = res_ParentCont_parsed.read("$.contents..quantity");
			List<Integer> vnpkQtyList = res_ParentCont_parsed.read("$.contents..vnpkQty");
			int receivedQty = qtyList.get(0) / vnpkQtyList.get(0);
			recInstruction.setReceivedQuantity(String.valueOf(receivedQty));

			try {
				recInstruction.setDestNumber(res_ParentCont_parsed.read("$.finalDestination.buNumber").toString());
			} catch (PathNotFoundException e) {
				recInstruction.setDestNumber("");
			}
			instructionList.add(recInstruction);
		}
		return instructionList;
	}

	public List<ReceivingInstruction> storeContainerForDaConFreight(String db, String collection,
			MongoCollection<Document> table, BasicDBObject searchQuery_ParentContID,
			List<ReceivingInstruction> instructionList) {
		DistinctIterable<String> res_ParentContainerList = table.distinct("parentTrackingId", searchQuery_ParentContID,
				String.class);
		BasicDBObject searchQuery_ForParentContID_forDaConGrtLyr = new BasicDBObject();
		BasicDBObject searchQuery_ForChildContID = new BasicDBObject();
		logger.info(db + " > " + collection + " Executing GET query  for searchQuery_ForParentContID_forDaConGrtLyr : "
				+ searchQuery_ForParentContID_forDaConGrtLyr);
		logger.info(db + " > " + collection + " Executing GET query  for searchQuery_ForChildContID : "
				+ searchQuery_ForChildContID);
		for (String res_ParentCont : res_ParentContainerList) {
			ReceivingInstruction recInstruction = new ReceivingInstruction();
			String res = res_ParentCont;
			searchQuery_ForParentContID_forDaConGrtLyr.put("trackingId", res_ParentCont);
			FindIterable<Document> res_ParentContID_forDaConGrtLyrt = table
					.find(searchQuery_ForParentContID_forDaConGrtLyr);
			searchQuery_ForChildContID.put("parentTrackingId", res_ParentCont);

			List<String> childContainerList = new ArrayList<>();
			FindIterable<Document> resTable_ChildCont = table.find(searchQuery_ForChildContID);
			for (Document resTable_ChildContList : resTable_ChildCont) {
				childContainerList.add(resTable_ChildContList.getString("trackingId"));
			}

			DocumentContext res_ParentCont_parsed = JsonPath.parse(res_ParentContID_forDaConGrtLyrt.first().toJson());

			recInstruction.setParentContainer(res_ParentCont_parsed.read("$.trackingId").toString());
			recInstruction.setMessageId(res_ParentCont_parsed.read("$.messageId").toString());
			recInstruction.setChildContainers(childContainerList);
			recInstruction.setChannelType("");
			recInstruction.setLabelType("normal");
			recInstruction.setReceivedQuantity(String.valueOf(childContainerList.size()));
			recInstruction.setDestNumber(res_ParentCont_parsed.read("$.finalDestination.buNumber").toString());
			instructionList.add(recInstruction);
		}
		return instructionList;
	}

	public Set<String> getUniqueItemNumbers(List<String> itemNumbers) {
		Set<String> uniqueItems = new HashSet<>();
		for (int i = 0; i < itemNumbers.size(); i++) {
			uniqueItems.add(itemNumbers.get(i).toString());
		}
		return uniqueItems;
	}

	public Headers getReceivingHeaders() {
		Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		Header securityId = new Header("WMT-Security-ID", environment.getProperty("wmt_security_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(securityId);
		return new Headers(headerList);
	}

	public String containerResponseForDelivery(String deliveryNumber) {

		String responseAsString = null;
		String containerRequestUrl = MessageFormat.format(environment.getProperty("container_request_ep"),
				deliveryNumber);
		Response response = SerenityRest.given().relaxedHTTPSValidation().headers(getReceivingHeaders())
				.get(containerRequestUrl);
		responseAsString = response.getBody().asString();
		logger.info("Container Response As String {}", responseAsString);
		return responseAsString;
	}

	public void updateRcvInstruc(List<ReceivingInstruction> instructionList, String itemNumber, String poNumber) {
		JSONArray instructJSONArry;

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		try {
			instructJSONArry = jsonUtil.converyListToJsonArray(instructionList);
			JSONArray existingRecvInstruc = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
					+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNumber + ")].receivingInstructions[*]");
			for (int i = 0; i < instructJSONArry.size(); i++) {
				JSONObject obj = new JSONObject();
				obj = (JSONObject) instructJSONArry.get(i);
				existingRecvInstruc.add(obj);
			}

			logger.info("UPDATED RECV INSTC:" + existingRecvInstruc.toJSONString());

			String testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowData, existingRecvInstruc,
					"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber=="
							+ itemNumber + ")].receivingInstructions");
			threadLocal.get().put("testFlowData", testFlowDataUpdated);
			logger.info("TestFlowData after updating receive instruction:" + testFlowDataUpdated);
		} catch (JsonProcessingException | ParseException e) {
			logger.info("Error while updating receive instruction");
			throw new AutomationFailure("Error while updating receive instruction", e);
		}
	}

	public void setReceivingInstruction(String containerResponse, String poNumber, String itemNumber) {
		setReceivingInstruction(containerResponse, poNumber, itemNumber, null);
	}

	public void setReceivingInstruction(String containerResponse, String poNumber, String itemNumber, String chnlmthd) {
//		String QUANTITY = "$[*].containerItems[?(@.itemNumber == " + itemNumber + ")].quantity";

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		ReceivingInstruction recInstruction = new ReceivingInstruction();
		JSONArray parentContainerArray = null;
		String PARENT_TRACKING_ID = "$[?(@.parentTrackingId==null)].trackingId";

		List<String> vnpkQty = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
				+ "')].poLineDetails[?(@.itemNumber==" + itemNumber + ")].vnpk");
		int intVnpkQty = Integer.parseInt(vnpkQty.get(0));
		parentContainerArray = JsonPath.read(containerResponse, PARENT_TRACKING_ID);

		for (int i = 0; i < parentContainerArray.size(); i++) {
			JSONArray locationArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='" + parentContainerArray.get(i)
			+ "')].location");
			JSONArray messageIdArray = null;
			JSONArray channelmethodArray = null;
			JSONArray destinationArray = null;
			JSONArray receivedQtyArray = null;
			JSONArray childContainersJsonArray = null;
			int receivedQty = 0;
			String DA_QUANTITY = "$[?(@.parentTrackingId=='" + parentContainerArray.get(i)
					+ "')].containerItems[*].quantity";

			List<ReceivingInstruction> instructionList = new ArrayList<>();

			List<String> childContainers = new ArrayList<>();

			JSONArray cnlMtd = null;
			if(chnlmthd == null) {
			 cnlMtd = JsonPath.read(containerResponse, "$[?(@.trackingId=='" + parentContainerArray.get(i)
					+ "')].containerItems[*].outboundChannelMethod");
			} else {
				try {
					cnlMtd = jsonUtil.converyListToJsonArray(Arrays.asList(chnlmthd));
				} catch (Exception e) {
					e.printStackTrace();
					throw new AutomationFailure("Something went wrong while storing PBYL containers");
				}
			}

			if (cnlMtd.size() != 0 && (cnlMtd.contains("STAPLESTOCK") || cnlMtd.contains("POCON"))) {
				logger.info(cnlMtd.get(0) + " Containers = {} ", parentContainerArray.get(i));

				JSONArray parentlistInTestFlow = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[*].receivingInstructions[?(@.parentContainer == '"
								+ parentContainerArray.get(i) + "')]");
				logger.info("parentlistInTestFlow " + parentlistInTestFlow.size() + " Values == "
						+ parentlistInTestFlow.toJSONString());

				if (parentlistInTestFlow.size() != 0) {
					logger.info("Container {} already in TestFlow " + parentContainerArray.get(i));
					continue;
				} else {
					messageIdArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].messageId");
					if (Config.DC==DC_TYPE.ACC) {
						List<String> isChannelFlippedList = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].isChannelFlipRequired");
						if (Boolean.valueOf(isChannelFlippedList.get(0)) && cnlMtd.contains("STAPLESTOCK")  ) {
							recInstruction.setChannelType("SSTKU");
						}
						else {
							channelmethodArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
									+ parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");
							recInstruction.setChannelType((String) channelmethodArray.get(0));
						}
					}
					else {
						channelmethodArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
								+ parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");
						recInstruction.setChannelType((String) channelmethodArray.get(0));
					}
					destinationArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].destination.buNumber");
					if (destinationArray.isEmpty())
						destinationArray = JsonPath.read(containerResponse,
								"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].facility.buNumber");
					recInstruction.setParentContainer((String) parentContainerArray.get(i));
					receivedQtyArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].quantity");
					recInstruction.setMessageId((String) messageIdArray.get(0));
//					recInstruction.setChannelType((String) channelmethodArray.get(0));
					recInstruction.setDestNumber((String) destinationArray.get(0));
					receivedQty = (int) receivedQtyArray.get(0);
					if (cnlMtd.contains("POCON")) {
						recInstruction.setReceivedQuantity(String.valueOf(receivedQty));
					} else {
						recInstruction.setReceivedQuantity(String.valueOf(receivedQty / intVnpkQty));
					}
					if (Config.DC == DC_TYPE.ACC) {
						recInstruction.setLabelType("normal");
					}

					instructionList.add(recInstruction);
					updateRcvInstruc(instructionList, itemNumber, poNumber);
				}
			} else if (cnlMtd.size() != 0 && cnlMtd.contains("CROSSNA") || cnlMtd.contains("CROSSNMA")) {
				logger.info("Non Con  Containers = {} " + parentContainerArray.get(i));

				JSONArray parentlistInTestFlow = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[*].receivingInstructions[?(@.parentContainer == '"
								+ parentContainerArray.get(i) + "')]");
				logger.info("parentlistInTestFlow " + parentlistInTestFlow.size() + " Values == "
						+ parentlistInTestFlow.toJSONString());

				JSONArray containerPONum = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
						+ parentContainerArray.get(i) + "')].containerItems[*].purchaseReferenceNumber");
				if (parentlistInTestFlow.size() != 0) {
					logger.info("Container {} already in TestFlow " + parentContainerArray.get(i));
					continue;
				} else if (parentlistInTestFlow.size() == 0 && containerPONum.get(0).toString().equals(poNumber)) {
					messageIdArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].messageId");
					channelmethodArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
							+ parentContainerArray.get(i) + "')].containerItems[*].outboundChannelMethod");
					destinationArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].destination.buNumber");
					receivedQtyArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].quantity");

					recInstruction.setParentContainer((String) parentContainerArray.get(i));
					recInstruction.setMessageId((String) messageIdArray.get(0));
					recInstruction.setChannelType((String) channelmethodArray.get(0));
					recInstruction.setDestNumber((String) destinationArray.get(0));
					for (int count = 0; count < receivedQtyArray.size(); count++) {
						receivedQty += (int) receivedQtyArray.get(count);
					}
					recInstruction.setReceivedQuantity(String.valueOf(receivedQty / intVnpkQty));
					if (Config.DC == DC_TYPE.ACC) {
						recInstruction.setLabelType("normal");
					}
					instructionList.add(recInstruction);
					updateRcvInstruc(instructionList, itemNumber, poNumber);
				} else {

					logger.info("Container {} already in TestFlow with mismatch with current PO "
							+ parentContainerArray.get(i));
					continue;

				}
			} else {
				JSONArray parentlistInTestFlow = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[*].receivingInstructions[?(@.parentContainer == '"
								+ parentContainerArray.get(i) + "')]");
				logger.info("parentlistInTestFlow " + parentlistInTestFlow.size() + " Values == "
						+ parentlistInTestFlow.toJSONString());

				JSONArray isPbylOrNot = JsonPath.read(containerResponse,
						"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].inventoryStatus");
				JSONArray containerPONum = null;

				if (isPbylOrNot.get(0).toString().equals("AVAILABLE")) {
					containerPONum = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
							+ parentContainerArray.get(i) + "')].containerItems[*].purchaseReferenceNumber");
					logger.info("PBYL PO NUmber " + containerPONum.get(0).toString()
							+ containerPONum.get(0).toString().equals(poNumber));

					if (parentlistInTestFlow.size() != 0) {
						logger.info("Container {} already in TestFlow " + parentContainerArray.get(i));
						continue;
					} else if (parentlistInTestFlow.size() == 0 && containerPONum.get(0).toString().equals(poNumber)) {
						messageIdArray = JsonPath.read(containerResponse,
								"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].messageId");
						channelmethodArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
								+ parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");
						destinationArray = JsonPath.read(containerResponse,
								"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].facility.buNumber");
						receivedQtyArray = JsonPath.read(containerResponse,
								"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].quantity");
						recInstruction.setParentContainer((String) parentContainerArray.get(i));
						recInstruction.setMessageId((String) messageIdArray.get(0));
						recInstruction.setChannelType((String) channelmethodArray.get(0));
						recInstruction.setDestNumber((String) destinationArray.get(0));
						for (int count = 0; count < receivedQtyArray.size(); count++) {
							receivedQty += (int) receivedQtyArray.get(count);
						}
						recInstruction.setReceivedQuantity(String.valueOf(receivedQty / intVnpkQty));
						if (Config.DC == DC_TYPE.ACC) {
							recInstruction.setLabelType("normal");
						}
						instructionList.add(recInstruction);
						updateRcvInstruc(instructionList, itemNumber, poNumber);
					} else {
						logger.info("Container {} already in TestFlow with mismatch with current PO "
								+ parentContainerArray.get(i));
						continue;

					}

				} else if(!(isPbylOrNot.get(0).toString().equals("WORK_IN_PROGRESS"))){
					containerPONum = JsonPath.read(containerResponse, "$[?(@.parentTrackingId=='"
							+ parentContainerArray.get(i) + "')].containerItems[*].purchaseReferenceNumber");
					logger.info("DA PO num " + containerPONum.get(0).toString()
							+ containerPONum.get(0).toString().equals(poNumber));

					if (parentlistInTestFlow.size() != 0) {
						logger.info("Container {} already in TestFlow " + parentContainerArray.get(i));
						continue;
					} else if (parentlistInTestFlow.size() == 0 && containerPONum.get(0).toString().equals(poNumber)) {
						childContainersJsonArray = JsonPath.read(containerResponse,
								"$[?(@.parentTrackingId=='" + parentContainerArray.get(i) + "')].trackingId");
						messageIdArray = JsonPath.read(containerResponse,
								"$[?(@.parentTrackingId=='" + parentContainerArray.get(i) + "')].messageId");
						channelmethodArray = JsonPath.read(containerResponse, "$[?(@.parentTrackingId=='"
								+ parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");
						destinationArray = JsonPath.read(containerResponse,
								"$[?(@.parentTrackingId=='" + parentContainerArray.get(i) + "')].destination.buNumber");
						receivedQtyArray = JsonPath.read(containerResponse, DA_QUANTITY);
						for (int j = 0; j < childContainersJsonArray.size(); j++) {
							childContainers.add(childContainersJsonArray.get(j).toString());
						}
						recInstruction.setChildContainers(childContainers);
						recInstruction.setParentContainer((String) parentContainerArray.get(i));
						recInstruction.setMessageId((String) messageIdArray.get(0));
						recInstruction.setChannelType((String) channelmethodArray.get(0));
						recInstruction.setDestNumber((String) destinationArray.get(0));
						for (int count = 0; count < receivedQtyArray.size(); count++) {
							receivedQty += (int) receivedQtyArray.get(count);
						}
						recInstruction.setReceivedQuantity(String.valueOf(receivedQty / intVnpkQty));
						instructionList.add(recInstruction);
						updateRcvInstruc(instructionList, itemNumber, poNumber);
					} else {
						logger.info("Container {} already in TestFlow with mismatch with current PO "
								+ parentContainerArray.get(i));
						continue;

					}
				}
			}

		}
	}

	public void setReceivingInstructionForWitron(String containerResponse, String poNumber, String itemNumber,
			String poLineNumber, String receivingType, String qty) {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		ReceivingInstruction recInstruction = new ReceivingInstruction();
		JSONArray parentContainerArray = null;
		String PARENT_TRACKING_ID = "$..containerItems[?(@.purchaseReferenceLineNumber == '" + poLineNumber
				+ "')].trackingId";

		List<String> vnpkQty = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
				+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].vnpk");

		int intVnpkQty = Integer.parseInt(vnpkQty.get(0));
		parentContainerArray = JsonPath.read(containerResponse, PARENT_TRACKING_ID);

		for (int i = 0; i < parentContainerArray.size(); i++) {
			JSONArray messageIdArray = null;
			JSONArray channelmethodArray = null;
			JSONArray destinationArray = null;
			JSONArray receivedQtyArray = null;
			JSONArray rotateDate = null;

			int receivedQty = 0;

			List<ReceivingInstruction> instructionList = new ArrayList<>();

			JSONArray cnlMtd = JsonPath.read(containerResponse,
					"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");

			if (cnlMtd.size() != 0 && cnlMtd.contains("SSTKU")) {
				logger.info("SSTK Containers = {} " + parentContainerArray.get(i));

				JSONArray parentlistInTestFlow = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
								+ "')].receivingInstructions[?(@.parentContainer == '" + parentContainerArray.get(i)
								+ "')]");
				logger.info("parentlistInTestFlow " + parentlistInTestFlow.size() + " Values == "
						+ parentlistInTestFlow.toJSONString());

				if (parentlistInTestFlow.size() != 0) {
					logger.info("Container {} already in TestFlow " + parentContainerArray.get(i));
					continue;
				} else {
					messageIdArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].messageId");
					channelmethodArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
							+ parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");
					destinationArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].destination.buNumber");
					if (destinationArray.isEmpty())
						destinationArray = JsonPath.read(containerResponse,
								"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].facility.buNumber");
					recInstruction.setParentContainer((String) parentContainerArray.get(i));

					receivedQtyArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].quantity");

					rotateDate = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].rotateDate");
					long rotateDatelong = (long) rotateDate.get(0);

					String rotateDateVal = javaUtil.unixToJavaDateConversion(rotateDatelong);

					recInstruction.setMessageId((String) messageIdArray.get(0));
					recInstruction.setChannelType((String) channelmethodArray.get(0));
					recInstruction.setDestNumber((String) destinationArray.get(0));
					receivedQty = (int) receivedQtyArray.get(0);
					if (receivingType.contentEquals("split")&& i==0) {
						int receivedQtyPostSplit = (receivedQty / intVnpkQty) - Integer.parseInt(qty);
						recInstruction.setReceivedQuantity(String.valueOf(receivedQtyPostSplit));

					} else {
						recInstruction.setReceivedQuantity(String.valueOf(receivedQty / intVnpkQty));

					}
					recInstruction.setrotateDate(rotateDateVal);
					instructionList.add(recInstruction);
					updateRcvInstrucWitron(instructionList, itemNumber, poNumber, poLineNumber);

				}
			}

		}
	}

	public void updateRcvInstrucWitron(List<ReceivingInstruction> instructionList, String contr, String poNumber,
			String poLineNumber) {
		JSONArray instructJSONArry;

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		try {
			instructJSONArry = jsonUtil.converyListToJsonArray(instructionList);

			JSONArray existingRecvInstruc = JsonPath.read(testFlowData,
					"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber == '"
							+ poLineNumber + "')].receivingInstructions[*]");

			for (int i = 0; i < instructJSONArry.size(); i++) {
				JSONObject obj = new JSONObject();
				obj = (JSONObject) instructJSONArry.get(i);
				existingRecvInstruc.add(obj);
			}

			logger.info("UPDATED RECV INSTC:" + existingRecvInstruc.toJSONString());

			String testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowData, existingRecvInstruc,
					"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber == '"
							+ poLineNumber + "')].receivingInstructions");

			threadLocal.get().put("testFlowData", testFlowDataUpdated);
			logger.info("TestFlowData after updating receive instruction:" + testFlowDataUpdated);

		} catch (JsonProcessingException | ParseException e) {
			logger.info("Error while updating receive instruction");
			throw new AutomationFailure("Error while updating receive instruction", e);
		}
	}

	public void setReceivingInstructionForDSDCOrManualReceiving(String containerResponse, String poNumber,
			String itemNumber, String channelType) throws JsonProcessingException, ParseException {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		ReceivingInstruction recInstruction = new ReceivingInstruction();
		JSONArray parentContainerArray = null;
		String PARENT_TRACKING_ID = "$[?(@.parentTrackingId==null)].trackingId";

		parentContainerArray = JsonPath.read(containerResponse, PARENT_TRACKING_ID);

		List<ReceivingInstruction> instructionListInst = new ArrayList<>();
		JSONArray instructJSONArryInst = jsonUtil.converyListToJsonArray(instructionListInst);

		String testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowData, instructJSONArryInst,
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber=="
						+ itemNumber + ")].receivingInstructions");
		threadLocal.get().put("testFlowData", testFlowDataUpdated);
		logger.info("TestFlowData after clearing receving existing instructions:" + testFlowDataUpdated);
		List<String> vnpkQty = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
				+ "')].poLineDetails[?(@.itemNumber==" + itemNumber + ")].vnpk");
		int intVnpkQty = Integer.parseInt(vnpkQty.get(0));
		
		for (int i = 0; i < parentContainerArray.size(); i++) {
			JSONArray messageIdArray = null;
			JSONArray channelmethodArray = null;
			JSONArray destinationArray = null;
			JSONArray receivedQtyArray = null;
			JSONArray childContainersJsonArray = null;
			int receivedQty = 0;
			String DA_QUANTITY = "$[?(@.parentTrackingId=='" + parentContainerArray.get(i)
					+ "')].containerItems[*].quantity";

			List<ReceivingInstruction> instructionList = new ArrayList<>();

			List<String> childContainers = new ArrayList<>();

			JSONArray cnlMtd = JsonPath.read(containerResponse, "$[?(@.trackingId=='" + parentContainerArray.get(i)
					+ "')].containerItems[*].outboundChannelMethod");

			logger.info(cnlMtd.get(0) + " Containers = {} ", parentContainerArray.get(i));

			JSONArray parentlistInTestFlow = JsonPath.read(testFlowData,
					"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[*].receivingInstructions[?(@.parentContainer == '"
							+ parentContainerArray.get(i) + "')]");
			logger.info("parentlistInTestFlow " + parentlistInTestFlow.size() + " Values == "
					+ parentlistInTestFlow.toJSONString());

			if (parentlistInTestFlow.size() != 0) {
				logger.info("Container {} already in TestFlow " + parentContainerArray.get(i));
				continue;
			} else {
				messageIdArray = JsonPath.read(containerResponse,
						"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].messageId");
				channelmethodArray = JsonPath.read(containerResponse, "$[?(@.trackingId=='"
						+ parentContainerArray.get(i) + "')].containerItems[*].inboundChannelMethod");
				destinationArray = JsonPath.read(containerResponse,
						"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].destination.buNumber");
				if (destinationArray.isEmpty())
					destinationArray = JsonPath.read(containerResponse,
							"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].facility.buNumber");
				recInstruction.setParentContainer((String) parentContainerArray.get(i));
				receivedQtyArray = JsonPath.read(containerResponse,
						"$[?(@.trackingId=='" + parentContainerArray.get(i) + "')].containerItems[*].quantity");
				recInstruction.setMessageId((String) messageIdArray.get(0));
				recInstruction.setChannelType((String) channelmethodArray.get(0));
				recInstruction.setDestNumber((String) destinationArray.get(0));
				receivedQty = (int) receivedQtyArray.get(0);
				if(channelType.equalsIgnoreCase("DSDC")) {
				recInstruction.setReceivedQuantity(String.valueOf(receivedQty));}
				else {
					recInstruction.setReceivedQuantity(String.valueOf(receivedQty / intVnpkQty));
				}
				recInstruction.setLabelType("normal");
				instructionList.add(recInstruction);
				updateRcvInstruc(instructionList, itemNumber, poNumber);
			}
		}
	}

	public String getCancelledContainerDetails(String deliveryNumber) throws JsonGenerationException, JsonMappingException, IOException {
		JSONObject deliveyrJSONObj = new JSONObject();
		deliveyrJSONObj.put("deliveryNumber", Integer.valueOf(deliveryNumber));
		deliveyrJSONObj.put("deliveryStatus", "WRK");
		
		Failsafe.with(retryPolicy).run(() -> {
			deliveryCancelResponse = given().relaxedHTTPSValidation().accept("application/json").headers(getReceivingHeaders()).body(deliveyrJSONObj.toJSONString())
					.when().post(environment.getProperty("get_rcv_instruction_for_delivery"));

			Assert.assertEquals(ErrorCodes.RECEIVING_UNABLE_TO_GET_RECEIVING_INSTRUCTION, Constants.SUCESS_STATUS_CODE,
					deliveryCancelResponse.getStatusCode());
		});
		logger.info("**"+deliveryCancelResponse.asString());
		return deliveryCancelResponse.asString();
	}
	
	
	
}
