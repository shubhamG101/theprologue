package com.walmart.supplychain.catalyst.receiving.oms.scenariosteps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.receiving.oms.steps.CatalystCreatePO;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class CatalystOmsScenario {
	
	@Steps
	CatalystCreatePO catalystCreatePO;

	@Steps
	PreRunCleanup preRunCleanup;
	
	@Given("^User creates a Catalyst PO for \"([^\"]*)\"$")
	public void UserCreatesaCatalystPO(String flowType) throws JsonProcessingException
	{
		preRunCleanup.preCleanUpInventoryDetailsCatalyst();
		preRunCleanup.cleanUpWMSDbCatalyst();
		preRunCleanup.changePriorityOfWorkCatalyst();
		preRunCleanup.cleanUpDeviceDetailsCatalyst();
		catalystCreatePO.createcatalystPO(flowType);
	}
	
	@Given("^User hits OMS to validate the PO for Catalyst$")
	public void userHitsOMSForThePo()
	{
		catalystCreatePO.populateOMSResponse();
	}
}
