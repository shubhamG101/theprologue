package com.walmart.supplychain.nextgen.idoc.steps.webservices;

import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes= {SpringTestConfiguration.class})
public class IDOCSteps extends ScenarioSteps {

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtil;

	Logger logger = LogManager.getLogger(this.getClass());
	private String testFlowData;
	private DocumentContext parsedJson;
	private List<String> outboundLoad_list;
	private Response getShipmentResponse;
	Response postShipmentResponse;
	private String destNumber;
	private static final String GET_DESTINATION_NUMBER_JSONPATH= "$.documentDestination.destinationNumber";
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(30,
			42);



	public void readJSON_ThreadLocal() throws FileNotFoundException, InterruptedException
	{
		Thread.sleep(4000);
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);

		outboundLoad_list = parsedJson.read("$.testFlowData.outboundDetails[*].loadId");
	}

	@Step
	public Response getShipmentDetails(String shipmentNum, boolean isPurePOCON) {
		String  idocGetShipmentBaseURL;
		String  wmtAPIKey;
		String idocUrl;
		String dcType;

		idocGetShipmentBaseURL = environment.getProperty("idoc_getshipment_base_url");
		wmtAPIKey = environment.getProperty("idoc_wmt-api-key");
		if (Config.DC==DC_TYPE.ATLAS || Config.DC==DC_TYPE.ACC) {
			dcType="MCC";
		}else{
			dcType=Config.DC.toString();
		}
		
		idocUrl =idocGetShipmentBaseURL+shipmentNum+"_"+getCurrentDate("yyyyMMdd")+"_"
		+environment.getProperty("facility_num")+"_"+"DC"+"_"+environment.getProperty("country_code")+"/0";
		String jiraDesc="url-"+idocUrl;
		logger.info("iDoc URL "+ idocUrl + "  " + " iDoc header api key "+wmtAPIKey);

		if (isPurePOCON) {
			Failsafe.with(retryPolicy).run(() -> {
				getShipmentResponse = SerenityRest.given().relaxedHTTPSValidation().header("WMT-API-KEY",wmtAPIKey).when().get(idocUrl);
				Assert.assertEquals(ErrorCodes.IDOC_ABLE_TO_FETCH_ASN_FROM_IDOC_FOR_PURE_POCON_OR_DSDC, Constants.NO_CONTENT_STATUS_CODE,getShipmentResponse.getStatusCode(),jiraDesc);
			});
		}
		else {
			Failsafe.with(retryPolicy).run(() -> {
				getShipmentResponse = SerenityRest.given().relaxedHTTPSValidation().header("WMT-API-KEY",wmtAPIKey).when().get(idocUrl);
				Assert.assertEquals(ErrorCodes.IDOC_UNABLE_TO_FETCH_ASN_FROM_IDOC, Constants.SUCESS_STATUS_CODE,getShipmentResponse.getStatusCode(),jiraDesc);
			});
			logger.info("IDOC :: Shipment details fetched successfully for shipment: "+shipmentNum);
		}

		return getShipmentResponse;

	}

	@Step
	public void postShipmentDetails(String tmsLoadID,String shipmentNum) throws InterruptedException {
		String idocPostShipmentURL;

		idocPostShipmentURL = environment.getProperty("idoc_postshipment_url")+shipmentNum;

		Failsafe.with(retryPolicy).run(() -> {
		postShipmentResponse = SerenityRest.given().relaxedHTTPSValidation().header("facilityCountryCode",environment.getProperty("country_code"))
				.header("facilityNum",destNumber).when().post(idocPostShipmentURL);
		Assert.assertEquals(ErrorCodes.IDM_POST_SHIPMENT_FAILED, Constants.SUCESS_STATUS_CODE, postShipmentResponse.getStatusCode());
		});
		Thread.sleep(4000);
		logger.info("IDOC :: Shipments details persisted in IDM Container table of RDC for shipment:"+shipmentNum);
	}

	@Step
	public void validate_IDOCshipment_Details() {
		try {
			readJSON_ThreadLocal();

			for (String loadID : outboundLoad_list) {
				logger.info("IDOC :: Validating ASN for loadId: {}",loadID);

				List<String> tmsLoadID_List = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].tmsLoadId");
				String tmsLoadID = tmsLoadID_List.get(0);

				List<String> destNum_List = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].destNumber");
				String destNum = destNum_List.get(0);

				List<String> loadedContainerList = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].containerIds[*]");
				List<String> unLoadedContainerList = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].unloadedContainers[*]");
				String shipmentNum =null;
				shipmentNum=tmsLoadID+environment.getProperty("facility_num")+destNum;	

				Response shipmentResponse_IDOC = getShipmentDetails(shipmentNum, false);
				String strResponse_IDOC=shipmentResponse_IDOC.asString();
				logger.info("IDOC :: ASN Resp:{}",strResponse_IDOC);
				destNumber = JsonPath.parse(strResponse_IDOC).read(GET_DESTINATION_NUMBER_JSONPATH);
				List<String> containerList_IDOC=JsonPath.parse(strResponse_IDOC).read("$..packs..packNumber");
				List<String> invoiceNumberIDOCList=JsonPath.parse(strResponse_IDOC).read("$..packs..invoiceNumber");
				Set<String> invoiceNumberIDOC = new HashSet<>(invoiceNumberIDOCList);
				
//				ArrayList<String> containerList_IDOC = new ArrayList<String>();
//				Set<String> invoiceNumberIDOC = new HashSet<>();
//				JSONArray jsonArrayResponse_ASN;
//				jsonArrayResponse_ASN = new JSONArray(strResponse_IDOC);
//				if (jsonArrayResponse_ASN!=null) {
//					for (int asnIndex = 0; asnIndex < jsonArrayResponse_ASN.length(); asnIndex++) {
//						containerList_IDOC.add(jsonArrayResponse_ASN.getJSONObject(asnIndex).getString("packNumber"));
//						invoiceNumberIDOC.add(jsonArrayResponse_ASN.getJSONObject(asnIndex).getString("invoiceNumber"));
//					}
//				}
				for(String containerId:loadedContainerList) {
					if (!(unLoadedContainerList.contains(containerId))) {
						logger.info("validating loaded container: {} in ASN IDOC response",containerId);
						Assert.assertTrue(ErrorCodes.IDOC_LOADED_NOT_FOUND_IN_IDOC, 
								containerList_IDOC.contains(containerId));
					}else {
						loadedContainerList.remove(containerId);
					}
				}
				logger.info("IDOC :: Loaded container count(Expected):{} and Container count in ASN(Acutual) {} for loadID: {}",loadedContainerList.size(),containerList_IDOC.size(),loadID);
				Assert.assertEquals(ErrorCodes.IDOC_CONTAINER_COUNT_MISMATCH,loadedContainerList.size(),containerList_IDOC.size());
				logger.info("IDOC :: Validated containers in ASN for loadId: {}",loadID);

				Assert.assertEquals(ErrorCodes.IDOC_INVOICE_NUMBER_VALIDATION_FAILED,1,invoiceNumberIDOC.size());

				String testFlowData_updated;
				testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, shipmentNum, "$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].asnNumber");
				threadLocal.get().put("testFlowData",testFlowData_updated);

				//GDM has migrated from V2 to V5 of IDOC, so it needs code change
				List<String> channelMethod= parsedJson.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].channelType");
					if(CHANNELS.CROSSU.getValue().toUpperCase().equalsIgnoreCase(channelMethod.get(0)))
							postShipmentDetails(tmsLoadID, shipmentNum); 
			}	
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while ASN creation",e);
		}
	}

	@Step
	public void validate_IDOCshipment_Details_For_POCON_DSDC() {
		try {
			readJSON_ThreadLocal();
			for (String loadID : outboundLoad_list) {
				logger.info("IDOC :: Validating ASN for loadId: "+loadID);

				List<String> tmsLoadID_List = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].tmsLoadId");
				String tmsLoadID = tmsLoadID_List.get(0);

				List<String> destNum_List = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].destNumber");
				String destNum = destNum_List.get(0);

				List<String> loadedContainerList = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].containerIds[*]");
				List<String> unLoadedContainerList = parsedJson.read("$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].unloadedContainers[*]");
				String shipmentNum = tmsLoadID+environment.getProperty("facility_num")+destNum;	

				ArrayList<String> loadedNonPOCONContainerList=new ArrayList<>();
				for (String cntr : loadedContainerList) {
					List<String> chnlTypeList = parsedJson.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.parentContainer == \""+cntr+"\")].channelType");
					if (!(chnlTypeList.get(0).equalsIgnoreCase("POCON") || chnlTypeList.get(0).equalsIgnoreCase("DSDC"))) {
						loadedNonPOCONContainerList.add(cntr);
					}
				}
				if (loadedNonPOCONContainerList.isEmpty()) {
					Response shipmentResponse_IDOC = getShipmentDetails(shipmentNum,true);
					logger.info("IDOC :: Validated ASN --ASN NOT FOUND-- for pure POCON/DSDC loadId: {}",loadID);
				}
				else {
					Response shipmentResponse_IDOC = getShipmentDetails(shipmentNum,false);
					String strResponse_IDOC=shipmentResponse_IDOC.asString();
					logger.info("IDOC :: ASN Resp:{}",strResponse_IDOC);
					
					destNumber = JsonPath.parse(strResponse_IDOC).read(GET_DESTINATION_NUMBER_JSONPATH);
					List<String> containerList_IDOC=JsonPath.parse(strResponse_IDOC).read("$..packs..packNumber");
					List<String> invoiceNumberIDOCList=JsonPath.parse(strResponse_IDOC).read("$..packs..invoiceNumber");
					Set<String> invoiceNumberIDOC = new HashSet<>(invoiceNumberIDOCList);
					
//					ArrayList<String> containerList_IDOC = new ArrayList<String>();
//					Set<String> invoiceNumberIDOC = new HashSet<>();
//					JSONArray jsonArrayResponse_ASN;
//					jsonArrayResponse_ASN = new JSONArray(strResponse_IDOC);
//					if (jsonArrayResponse_ASN!=null) {
//						for (int asnIndex = 0; asnIndex < jsonArrayResponse_ASN.length(); asnIndex++) {
//							containerList_IDOC.add(jsonArrayResponse_ASN.getJSONObject(asnIndex).getString("packNumber"));
//							invoiceNumberIDOC.add(jsonArrayResponse_ASN.getJSONObject(asnIndex).getString("invoiceNumber"));
//						}
//					}

					for(String containerId:loadedNonPOCONContainerList) {
						if (!(unLoadedContainerList.contains(containerId))) {
							logger.info("validating loaded container: {} in ASN IDOC response",containerId);
							Assert.assertTrue(ErrorCodes.IDOC_LOADED_NOT_FOUND_IN_IDOC, 
									containerList_IDOC.contains(containerId));
						}else {
							loadedNonPOCONContainerList.remove(containerId);
						}
					}

					logger.info("IDOC :: Loaded container count(Expected):{} and Container count in ASN(Acutual) {} for loadID: {}",loadedNonPOCONContainerList.size(),containerList_IDOC.size(),loadID);
					Assert.assertEquals(ErrorCodes.IDOC_CONTAINER_COUNT_MISMATCH,loadedNonPOCONContainerList.size(),containerList_IDOC.size());
					logger.info("IDOC :: Validated containers in ASN for loadId: {}",loadID);

					Assert.assertEquals(ErrorCodes.IDOC_INVOICE_NUMBER_VALIDATION_FAILED,1,invoiceNumberIDOC.size());

					String testFlowData_updated;
					testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, shipmentNum, "$.testFlowData.outboundDetails[?(@.loadId == '"+loadID+"')].asnNumber");
					threadLocal.get().put("testFlowData",testFlowData_updated);
					logger.info("testFlowData >> "+String.valueOf(threadLocal.get().get("testFlowData")));

					
					//GDM has migrated from V2 to V5 of IDOC, so it needs code change
					List<String> channelMethod= parsedJson.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].channelType");
					if(CHANNELS.CROSSU.getValue().toUpperCase().equalsIgnoreCase(channelMethod.get(0)))
						postShipmentDetails(tmsLoadID, shipmentNum); 
				}
			}
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while ASN creation",e);
		}
	}

	public String getCurrentDate(String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 0);
		dateFormat.format(c.getTime());
		return dateFormat.format(c.getTime());
	}
}
