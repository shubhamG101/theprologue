package com.walmart.supplychain.atlas.receiving.steps.mobile;


import java.io.IOException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.nextgen.receiving.pages.mobile.ReceivingPage;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class ReceivingSteps extends ScenarioSteps {

    @Autowired
    ReceivingHelper receivingHelper;

    @Autowired
    MongoUtil mongoUtil;

    @Autowired
    JsonUtils jsonUtil;

    @Autowired
    ThreadLocal<HashMap<String, Object>> threadLocal;
    
    @Autowired
	TextParser textParser;
    
    @Autowired
	Environment environment;
    
    @Autowired
	StratiConnectionUtil stratiConnectionUtil;
    
    @Autowired
    JavaUtils javaUtils;
    
    ReceivingPage ReceivingPage;

    Logger logger = LoggerFactory.getLogger(ReceivingSteps.class);

    private String deliveryNumber;
    private String inboundDoor,inboundTrailNum;
    private List<String> poNumberList;
    private DocumentContext parsedJson;
    String testFlowData;
    private static final String TOPIC = "topic";
	private static final String INSTRUCTIONID_JSONPATH = "$.instruction.id";
	private static final String INSTRUCTION_REQUEST_EP = "instruction_request_ep";
	static final String INSTRUCTIONID="instructionId";

    public void readJSON_ThreadLocal() throws IOException, JSONException {
        testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
        parsedJson = JsonPath.parse(testFlowData);

        List<String> deliveryNumber_list = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
        deliveryNumber = deliveryNumber_list.get(0);
        List<String> inboundDoor_list = parsedJson.read("$.testFlowData.deliveryDetails..inboundDoorNumber");
        inboundDoor = inboundDoor_list.get(0);
        List<String> inboundTrailNum_list = parsedJson.read("$.testFlowData.deliveryDetails..inboundTrailerNumber");
        inboundTrailNum = inboundTrailNum_list.get(0);
      
        poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
        //need vendorPackCost for ovg calculation

    }
    
    @Step
    public void publishMessageToIDM() {

		JSONObject delStatusMesg = new JSONObject();
		try {
			readJSON_ThreadLocal();
			delStatusMesg.put("deliveryNumber", deliveryNumber);
				delStatusMesg.put("deliveryStatus", "OPEN");
			delStatusMesg.put("userId", "sysadmin");
			delStatusMesg.put("ts", "Jan 30, 2019 4:45:17 PM");
			String messgae = delStatusMesg.toString();
			logger.info("Delivery Open message::{}",messgae);
			stratiConnectionUtil.publishStartiMessage(environment.getProperty("receiving_delivery_topic"), messgae, TOPIC, environment.getProperty("recv_connection_factory"), environment.getProperty("recv_strati_username"),environment.getProperty("recv_strati"));
			
		} catch (JSONException|IOException e) {
			logger.error("Error constructing scan message in Receiving");
			throw new AutomationFailure("Error constructing scan message in Receiving", e);
		}
	}

	@Step
	public void postInstructionRequest() {
		try {
			readJSON_ThreadLocal();
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		for (String poNumber : poNumberList) {
		List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
		Set<String> uniqueItems=receivingHelper.getUniqueItemNumbers(itemList);
        Iterator<String> iterator = uniqueItems.iterator();
		while (iterator.hasNext()) {
			String itemNum=iterator.next();
            logger.info("PO:{} and item:{} in post Instruction request ",poNumber,itemNum);
            List<String> ovgQty= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].ovgQty");
            List<String> openQty= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].poVnpkQty");
            List<String> vnpkQty= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].vnpk");
            List<String> itemUPC= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].itemUpc");
            List<String> overageFlag= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].overageFlag");
            List<String> poType= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].omsChannelMethod");
            List<String> channelMethod= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].channelMethod");
            int ovgQtyValue= Integer.parseInt(ovgQty.get(0));
            int openQtyValue=Integer.parseInt(openQty.get(0));
            int maxReceiveQty=0;
            if(overageFlag.get(0).equals("true"))
            	maxReceiveQty=openQtyValue+ovgQtyValue;
            else
            	maxReceiveQty=openQtyValue;
            
            int expectedQty= Integer.parseInt(openQty.get(0))*Integer.parseInt(vnpkQty.get(0));
             maxReceiveQty=maxReceiveQty*Integer.parseInt(vnpkQty.get(0));
			String instructionMessage=textParser.readTextFile(FileNames.RECEIVING_INSTRUCTION);
				JSONObject jsonMessage= new JSONObject(instructionMessage);
				jsonMessage.put("messageId", "f411ca08-c7d8-499e-"+javaUtils.randonNumberGenerator(4));
				jsonMessage.put("deliveryNumber", Integer.parseInt(deliveryNumber));
				jsonMessage.put("upcNumber", itemUPC.get(0));
				jsonMessage.put("doorNumber", inboundDoor);
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).getJSONArray("deliveryDocumentLines").getJSONObject(0).put("caseUPC", itemUPC.get(0));
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).getJSONArray("deliveryDocumentLines").getJSONObject(0).put("expectedQty", expectedQty);
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).getJSONArray("deliveryDocumentLines").getJSONObject(0).put("openQty",maxReceiveQty);
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).getJSONArray("deliveryDocumentLines").getJSONObject(0).put("itemNbr",itemNum);
				String channelMethodVal=channelMethod.get(0).equalsIgnoreCase("SSTK") ? "SSTKU" : channelMethod.get(0);
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).getJSONArray("deliveryDocumentLines").getJSONObject(0).put("purchaseRefType",channelMethodVal );
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).put("purchaseReferenceNumber", poNumber);
				jsonMessage.getJSONArray("deliveryDocuments").getJSONObject(0).put("purchaseReferenceLegacyType", poType.get(0));
				logger.info("Rest end point of instruction request:: {}",environment.getProperty(INSTRUCTION_REQUEST_EP));
				logger.info("Request body for posting instruction request:: {}",jsonMessage);
				Response response = SerenityRest.given().relaxedHTTPSValidation().body(jsonMessage.toString()).headers(receivingHelper.getReceivingHeaders())
						.when().post(environment.getProperty(INSTRUCTION_REQUEST_EP));
				response.then().statusCode(201);
				logger.info("response of instruction request :: {}",response.asString());
				int instructionId =JsonPath.parse(response.asString()).read(INSTRUCTIONID_JSONPATH);
				threadLocal.get().put(INSTRUCTIONID,instructionId);
				int projectedReceiveQty= JsonPath.parse(response.asString()).read("$.instruction.projectedReceiveQty");
				threadLocal.get().put("projectedReceiveQty",projectedReceiveQty);
				threadLocal.get().put("expectedQty",expectedQty);
				logger.info("Instruction ID Instruction request:: {}",instructionId);
		} 
		}
		}catch (JSONException|URISyntaxException|IOException e) {
			logger.info("Error while posting instruction request");
			throw new AutomationFailure("Error while posting instruction request", e);
		}
	}
	
	@Step
	public void userReceiveQtyAndCompletePallet() {
		
		try {
			readJSON_ThreadLocal();
		int instructionId= (int) threadLocal.get().get(INSTRUCTIONID);
		int projectedReceiveQty = (int) threadLocal.get().get("projectedReceiveQty");
		int expectedQty = (int) threadLocal.get().get("expectedQty");
		testFlowData= String.valueOf(threadLocal.get().get("testFlowData"));
		logger.info("ProjectedReceiveQty in Update Instruction request:: {}",projectedReceiveQty);
		logger.info("expectedQty in Update Instruction request:: {}",expectedQty);
		for (String poNumber : poNumberList) {
			List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
			Set<String> uniqueItems=receivingHelper.getUniqueItemNumbers(itemList);
	        Iterator<String> iterator = uniqueItems.iterator();
	        String itemNum;
			while (iterator.hasNext()) {
				 itemNum=iterator.next();
	            logger.info("PO:{} and item:{} in post Instruction request ",poNumber,itemNum);
	            List<String> channelMethod= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].channelMethod");
	            List<String> itemUPC= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].itemUpc");
	            List<String> vnpkQty= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].vnpk");
	            List<String> ovgQty= parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].ovgQty");
	            Response updateInstructionResponse;
		Response completeInstructionResponse;
		String containerResponse;
			String updateInstructionMessage = textParser.readTextFile(FileNames.UPDATE_INSTRUCTION);
			JSONObject jsonUpdateInstructionMessage= new JSONObject(updateInstructionMessage);
			jsonUpdateInstructionMessage.put("deliveryNumber", deliveryNumber);
			jsonUpdateInstructionMessage.put("doorNumber", inboundDoor);
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("purchaseReferenceNumber", poNumber);
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("purchaseRefType", channelMethod.get(0));
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("expectedQty", expectedQty);
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("quantity", projectedReceiveQty);
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("itemNumber", itemNum);
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("gtin", itemUPC.get(0));
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("vnpkQty", vnpkQty.get(0));
			jsonUpdateInstructionMessage.getJSONArray("deliveryDocumentLines").getJSONObject(0).put("maxOverageAcceptQty",ovgQty.get(0));
			logger.info("Request body for Updating instruction :: {}",jsonUpdateInstructionMessage);
			updateInstructionResponse = SerenityRest.given().relaxedHTTPSValidation().body(jsonUpdateInstructionMessage.toString()).headers(receivingHelper.getReceivingHeaders())
					.when().put(MessageFormat.format(environment.getProperty("update_instruction_ep"), String.valueOf(instructionId)));
			updateInstructionResponse.then().statusCode(200);
			logger.info("response after updating instruction :: {}",updateInstructionResponse.asString());
			//complete instruction
			 completeInstructionResponse = SerenityRest.given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders())
					.when().put(MessageFormat.format(environment.getProperty("complete_instruction_ep"), String.valueOf(instructionId)));
			completeInstructionResponse.then().statusCode(200);
			logger.info("completed the instruction for the instruction id::{}",instructionId);
//			//Container table response for given delivery
			 containerResponse= receivingHelper.containerResponseForDelivery(deliveryNumber);
			 logger.info("ContainerResponse for the given delivery::{}",containerResponse);
			receivingHelper.setReceivingInstruction(containerResponse, poNumber,itemNum);
			} 
		}
		}catch (JSONException|URISyntaxException|IOException e) {
				logger.info("Error while updating or completing instruction request");
				throw new AutomationFailure("Error while updating or completing instruction request", e);
		}
	}
	
	@Step
	public void completeDelivery() {
		try {
			readJSON_ThreadLocal();
			logger.info("Delivery number for completing the delivery :: {}",deliveryNumber);
			Response completeDeliveryResponse = SerenityRest.given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders())
					.when().put(MessageFormat.format(environment.getProperty("complete_delivery_ep"), deliveryNumber));
			completeDeliveryResponse.then().statusCode(200);
		} catch (Exception e) {
			logger.info("Error while completing the delivery");
			throw new AutomationFailure("Error while completing the delivery", e);
		}
    
	}
}
