package com.walmart.supplychain.nextgen.damage.scenariosteps.webservices;

import java.io.IOException;
import java.net.URISyntaxException;

import org.json.JSONException;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.nextgen.damage.steps.webservices.DamageSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class DamageScenarios {

	@Steps
	InventorySteps inventorySteps;
	
	@Steps
	DamageSteps damageSteps;
	
	private int reasonCode = 11;

	@Given("^user scan the container and file Damage against it$")
	public void fileDamageInventoryApk() {
		inventorySteps.performDamage();
	}
	
	@Given("^user should not be able to damage loaded container$")
	public void user_should_not_be_able_to_damage_loaded_container() {
		inventorySteps.damagePostLoaded();
	}
	
	
	@Given("^user scan the container and file prereceiving Damage against it$")
	public void filepreReceivingDamage(){
		damageSteps.filepreReceivingDamage();
	}
	
	@Given("^user verify all the damaged containers are created in inventory$")
	public void validateDamageCntrInVentory() {
		inventorySteps.validateDamageCntrs();
	}

}

