package com.walmart.supplychain.thor.manifestservices.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.supplychain.nextgen.oms.scenariosteps.webservices.OmsSteps;

import android.R.integer;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes= {SpringTestConfiguration.class})
public class ManifestServicesHelper {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	@Autowired
	TextParser textParser;

	@Autowired
	OmsSteps omsStep;
	
	@Autowired
	JsonUtils jsonUtils;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TESTFLOW_DATA="testFlowData";
	String testFlowData;
	Response enterpriseMDMResponse;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	RetryPolicy retryPolicyWithCustomCount = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			3);
	private static final String OMS_TO_MANIFEST_CONNECTION_URL="thor_oms_to_manifest_connection_url";
	private static final String OMS_TO_MANIFEST_PO_CRETAE_TOPIC="thor_oms_to_manifest_pocreate_topic";
	private static final String OMS_TO_MANIFEST_PO_EDIT_TOPIC="thor_oms_to_manifest_poedit_topic";
	private static final String PO_GET_ENTITY = "$.testFlowData.poDetails[*]";
	private static final String THOR_MANIFEST_GETPO_URL="thor_manifest_getpo_url";
	private static final String MOCK_ADMIN_URL = "mock_admin_url";
	private static final String OMSPO_JSON_PATH ="$..poDetails[*].omsPONumber";
	private static final String XREFPO_JSON_PATH ="$..poDetails[*].poNumber";
	private static final String ITEM_NUMBER_JSON_PATH ="$..poDetails[*].poLineDetails..itemNumber";
	private static final String PO_VNPK_QTY_JSON_PATH ="$..poDetails[*].poLineDetails..poVnpkQty";
	private static final String PO_WHPK_QTY_JSON_PATH ="$..poDetails[*].poLineDetails..poWhpkQty";
	private static final String VNPK_JSON_PATH = "$..poDetails[*].poLineDetails..vnpk";
	private static final String WHPK_JSON_PATH ="$..poDetails[*].poLineDetails..whpk";
	private static final String WHPK_SELL_PRICE_JSON_PATH="$..poDetails[*].poLineDetails..whpkSellPrice";
	private static final String UUID_JSON_PATH="$..poDetails[*].uuid[*]";
	private static final String PO_LINE_STATUS_JSON_PATH="$..poDetails[*].poLineDetails..poDestStatus";
	private static final String PO_DETAILS_JSON_PATH = "$.testFlowData.poDetails";
	Response manifestResponse=null;
	Response vendorDetailsResponse=null;
	
	public String createPO(String itemNumber, String poLineQty, String vnpkQty, String whpkQty, String whpkSellCost) throws URISyntaxException, IOException, JSONException, ParseException, InterruptedException {

		String omsPONumber=grenerateRadomNumber(10);
		String xrefPONumber=grenerateRadomNumber(10);
		String uuID=UUID.randomUUID().toString();
		List<String> uuIDList=new ArrayList<>();

		logger.info("xrefPONumber : {}",xrefPONumber);
		logger.info("UUID : {}",uuID);

		//For OMS mock po payload creation
		String omsMockPOMssg = textParser.readTextFile(FileNames.THOR_CREATE_MOCK_PO);
		omsMockPOMssg = format(omsMockPOMssg, omsPONumber,xrefPONumber,itemNumber,poLineQty,vnpkQty,whpkQty,whpkSellCost);
		JSONObject omsMostPostBody = createOMSMockPayload(uuID,xrefPONumber,omsMockPOMssg);

		//For OMS mock po creation and testflow data creation
		Response postMockPoCreateResponse = SerenityRest.given().body(omsMostPostBody.toString()).contentType("application/json").when().post(environment.getProperty(MOCK_ADMIN_URL));
		postMockPoCreateResponse.then().statusCode(Constants.CREATE_SUCESS_STATUS_CODE);
		omsStep.userHitsOmsAndPopulatesPolineData("po", xrefPONumber,"false");

		uuIDList.add(uuID);
		testFlowData = threadLocal.get().get(TESTFLOW_DATA).toString();
		ObjectMapper objectMapper = new ObjectMapper();
		net.minidev.json.JSONArray listOfPoDetails = JsonPath.read(testFlowData, PO_GET_ENTITY);
        String poDetailsJson = objectMapper.writeValueAsString(listOfPoDetails);
		List<PoDetail> poDetailList = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsJson,
                PoDetail.class);
		for(PoDetail poDetail:poDetailList) {
			if(poDetail.getPoNumber().equals(xrefPONumber)) {
				poDetail.setUuid(uuIDList);
			}
		}
		
		net.minidev.json.JSONArray listofPoJson = jsonUtils.converyListToJsonArray(poDetailList);
        testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listofPoJson, PO_DETAILS_JSON_PATH);
        threadLocal.get().put(TESTFLOW_DATA, testFlowData);
//	
		//for multiple poline		
		//				String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_PO_CREATE_KAFKA_MULTI_LINE);//for multiple poline
		//				omsPOKafkaMssg = format(omsPOKafkaMssg, omsPONumber,xrefPONumber);//for multiple poline

		//single po line
		String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_PO_CREATE_KAFKA_SINGLE_LINE);
		omsPOKafkaMssg = format(omsPOKafkaMssg, omsPONumber,xrefPONumber,itemNumber,poLineQty,vnpkQty,whpkQty,whpkSellCost);
		
		postMessageToKafkaTopic(environment.getProperty(OMS_TO_MANIFEST_CONNECTION_URL), environment.getProperty(OMS_TO_MANIFEST_PO_CRETAE_TOPIC), omsPOKafkaMssg);
		Thread.sleep(3000);
		
		return xrefPONumber;
	}

	public void updatePO(String itemNumber) throws URISyntaxException, IOException, InterruptedException {
		String uuid=UUID.randomUUID().toString();
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> omsPONumber = jsonParser.read(OMSPO_JSON_PATH);
		List<String> xrefPONumber = jsonParser.read(XREFPO_JSON_PATH);

		String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_PO_UPDATE_KAFKA);
		omsPOKafkaMssg = format(omsPOKafkaMssg, omsPONumber.get(0),xrefPONumber.get(0),itemNumber,uuid);
		postMessageToKafkaTopic(environment.getProperty(OMS_TO_MANIFEST_CONNECTION_URL), environment.getProperty(OMS_TO_MANIFEST_PO_EDIT_TOPIC), omsPOKafkaMssg);
		Thread.sleep(3000);
	}

	public void updatePOLineQty(String updatedQty, String status) throws URISyntaxException, IOException, ParseException, InterruptedException {
		String uuidToUpdatePOInManifest=UUID.randomUUID().toString();
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> omsPONumberList = jsonParser.read(OMSPO_JSON_PATH);
		List<String> xrefPONumberList = jsonParser.read(XREFPO_JSON_PATH);
		List<String> itemNumberList = jsonParser.read(ITEM_NUMBER_JSON_PATH);
		List<String> oldpoLineQtyList = jsonParser.read(PO_VNPK_QTY_JSON_PATH);
		List<String> vnpkQtyList = jsonParser.read(VNPK_JSON_PATH);
		List<String> whpkQtyList = jsonParser.read(WHPK_JSON_PATH);
		List<String> whpkSellCostList = jsonParser.read(WHPK_SELL_PRICE_JSON_PATH);
		List<String> poCreateOlduuidList = jsonParser.read(UUID_JSON_PATH);
		
		
		String omsMockPOMssg = textParser.readTextFile(FileNames.THOR_CREATE_MOCK_PO);
		omsMockPOMssg = format(omsMockPOMssg,omsPONumberList.get(0),xrefPONumberList.get(0),itemNumberList.get(0),
				updatedQty,vnpkQtyList.get(0),whpkQtyList.get(0),whpkSellCostList.get(0));
		JSONObject omsMostPostBody = createOMSMockPayload(poCreateOlduuidList.get(0),xrefPONumberList.get(0),omsMockPOMssg);

		Response postMockPoCreateResponse = SerenityRest.given().body(omsMostPostBody.toString()).contentType("application/json").when().put(environment.getProperty(MOCK_ADMIN_URL)+poCreateOlduuidList.get(0));
		postMockPoCreateResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);

		if (status.equals("VendorAcknowledged")) {
			String updatedTestFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, updatedQty, PO_VNPK_QTY_JSON_PATH);
			updatedTestFlowData = jsonUtils.setJsonAtJsonPath(updatedTestFlowData, updatedQty, PO_WHPK_QTY_JSON_PATH);
			threadLocal.get().put(TESTFLOW_DATA, updatedTestFlowData);
			testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		}

		String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_POLINE_UPDATE_KAFKA);
		omsPOKafkaMssg = format(omsPOKafkaMssg, uuidToUpdatePOInManifest, omsPONumberList.get(0),xrefPONumberList.get(0),
				itemNumberList.get(0),updatedQty,vnpkQtyList.get(0),whpkQtyList.get(0));
		postMessageToKafkaTopic(environment.getProperty(OMS_TO_MANIFEST_CONNECTION_URL), environment.getProperty(OMS_TO_MANIFEST_PO_EDIT_TOPIC), omsPOKafkaMssg);
		Thread.sleep(3000);
	}
	
	public void poLineAdd(String lineTwoItemNumber, String lineTwoPoLineQty, String lineTwoVnpkQty, String lineTwoWhpkQty, String lineTwoWhpkSellCost) throws URISyntaxException, IOException, InterruptedException, JSONException, ParseException {
		String uuidToUpdatePOInManifest=UUID.randomUUID().toString();
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> omsPONumberList = jsonParser.read(OMSPO_JSON_PATH);
		List<String> xrefPONumberList = jsonParser.read(XREFPO_JSON_PATH);
		List<String> poCreateOlduuidList = jsonParser.read(UUID_JSON_PATH);
		List<String> lineOneItemNumberList = jsonParser.read(ITEM_NUMBER_JSON_PATH);
		List<String> lineOnePoLineQtyList = jsonParser.read(PO_VNPK_QTY_JSON_PATH);
		List<String> lineOneVnpkQtyList = jsonParser.read(VNPK_JSON_PATH);
		List<String> lineOnewhpkQtyList = jsonParser.read(WHPK_JSON_PATH);
		List<String> lineOnewhpkSellCostList = jsonParser.read(WHPK_SELL_PRICE_JSON_PATH);
		
		String omsMockPOMssg = textParser.readTextFile(FileNames.THOR_CREATE_MOCK_FOR_PO_LINE_ADD);
		omsMockPOMssg = format(omsMockPOMssg,omsPONumberList.get(0),xrefPONumberList.get(0),lineOneItemNumberList.get(0),
				lineOnePoLineQtyList.get(0),lineOneVnpkQtyList.get(0),lineOnewhpkQtyList.get(0),lineOnewhpkSellCostList.get(0),
				lineTwoItemNumber,lineTwoPoLineQty,lineTwoVnpkQty,lineTwoWhpkQty,lineTwoWhpkSellCost);
		JSONObject omsMostPostBody = createOMSMockPayload(poCreateOlduuidList.get(0),xrefPONumberList.get(0),omsMockPOMssg);

		Response postMockPoCreateResponse = SerenityRest.given().body(omsMostPostBody.toString()).contentType("application/json").when().put(environment.getProperty(MOCK_ADMIN_URL)+poCreateOlduuidList.get(0));
		postMockPoCreateResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
		omsStep.userHitsOmsAndPopulatesPolineData("po", xrefPONumberList.get(0),"false");
		
		testFlowData = threadLocal.get().get(TESTFLOW_DATA).toString();
		ObjectMapper objectMapper = new ObjectMapper();
		net.minidev.json.JSONArray listOfPoDetails = JsonPath.read(testFlowData, PO_GET_ENTITY);
        String poDetailsJson = objectMapper.writeValueAsString(listOfPoDetails);
		List<PoDetail> poDetailList = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsJson,
                PoDetail.class);
		for(PoDetail poDetail:poDetailList) {
			if(poDetail.getPoNumber().equals(xrefPONumberList.get(0))) {
				poDetail.setUuid(poCreateOlduuidList);
			}
		}
		
		net.minidev.json.JSONArray listofPoJson = jsonUtils.converyListToJsonArray(poDetailList);
        testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listofPoJson, PO_DETAILS_JSON_PATH);
        threadLocal.get().put(TESTFLOW_DATA, testFlowData);
		
		String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_POLINE_ADD_KAFKA);
		omsPOKafkaMssg = format(omsPOKafkaMssg, uuidToUpdatePOInManifest, omsPONumberList.get(0),xrefPONumberList.get(0),
				lineTwoItemNumber,lineTwoPoLineQty,lineTwoVnpkQty,lineTwoWhpkQty,lineTwoWhpkSellCost);
		postMessageToKafkaTopic(environment.getProperty(OMS_TO_MANIFEST_CONNECTION_URL), environment.getProperty(OMS_TO_MANIFEST_PO_EDIT_TOPIC), omsPOKafkaMssg);
		Thread.sleep(3000);
		
	}
	
	public void updatePOLineStatus(String updateLineStatusText) throws URISyntaxException, IOException, ParseException, InterruptedException {
		String uuidToUpdatePOInManifest=UUID.randomUUID().toString();
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> omsPONumberList = jsonParser.read(OMSPO_JSON_PATH);
		List<String> xrefPONumberList = jsonParser.read(XREFPO_JSON_PATH);
		List<String> itemNumberList = jsonParser.read(ITEM_NUMBER_JSON_PATH);
		List<String> oldpoLineQtyList = jsonParser.read(PO_VNPK_QTY_JSON_PATH);
		List<String> vnpkQtyList = jsonParser.read(VNPK_JSON_PATH);
		List<String> whpkQtyList = jsonParser.read(WHPK_JSON_PATH);
		String poLineStatusCode=null;
		
		if (updateLineStatusText.equalsIgnoreCase("CANCELLED")) {
			poLineStatusCode="1300";
		}
		String updatedTestFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, updateLineStatusText.toUpperCase(), PO_LINE_STATUS_JSON_PATH);
        threadLocal.get().put(TESTFLOW_DATA, updatedTestFlowData);
        testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));

		String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_POLINE_CANCEL_KAFKA);
		omsPOKafkaMssg = format(omsPOKafkaMssg, uuidToUpdatePOInManifest, omsPONumberList.get(0),xrefPONumberList.get(0),
				itemNumberList.get(0),oldpoLineQtyList.get(0),vnpkQtyList.get(0),whpkQtyList.get(0),poLineStatusCode);
		logger.info(omsPOKafkaMssg);
		postMessageToKafkaTopic(environment.getProperty(OMS_TO_MANIFEST_CONNECTION_URL), environment.getProperty(OMS_TO_MANIFEST_PO_EDIT_TOPIC), omsPOKafkaMssg);
		Thread.sleep(3000);
	}

	public void poLineAdd_old() throws URISyntaxException, IOException, JSONException, ParseException, InterruptedException {
		String uuid=UUID.randomUUID().toString();
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> omsPONumber = jsonParser.read(OMSPO_JSON_PATH);
		List<String> xrefPONumber = jsonParser.read(XREFPO_JSON_PATH);

		String itemNumberLine2="567392159";
		logger.info("xrefPONumber >> {}",xrefPONumber);

		String omsPOKafkaMssg = textParser.readTextFile(FileNames.THOR_POLINE_ADD_KAFKA);
		omsPOKafkaMssg = format(omsPOKafkaMssg, omsPONumber.get(0),xrefPONumber.get(0),itemNumberLine2,uuid);
		postMessageToKafkaTopic(environment.getProperty(OMS_TO_MANIFEST_CONNECTION_URL), environment.getProperty(OMS_TO_MANIFEST_PO_EDIT_TOPIC), omsPOKafkaMssg);
		Thread.sleep(3000);
	}

	public void validatePO() throws JSONException {
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> poNumberList = jsonParser.read(XREFPO_JSON_PATH);
		validateVendorDetails(poNumberList.get(0));
		List<String> itemNumberList = jsonParser.read("$..poDetails[?(@.poNumber == '"+poNumberList.get(0)+"')].poLineDetails[*].itemNumber");
		for (String itemNumber : itemNumberList) {
			validateEnterpriseMDMDetails(poNumberList.get(0), itemNumber);
		}
	}

	private void postMessageToKafkaTopic(String connectionURL, String topicName, String kafkaPOMssg) {
		// create instance for properties to access producer configs
		Properties props = new Properties();
		props.put("bootstrap.servers", connectionURL);
		// Set acknowledgements for producer requests.
		props.put("acks", "all");

		// If the request fails, the producer can automatically retry,
		props.put("retries", 0);

		// Specify buffer size in config
		props.put("batch.size", 16384);

		// Reduce the no of requests less than 0
		props.put("linger.ms", 1);

		// The buffer.memory controls the total amount of memory available to
		// the producer for buffering.
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		Producer<String, String> producer = new KafkaProducer<String, String>(props);
		producer.send(new ProducerRecord<String, String>(topicName, kafkaPOMssg));
		producer.close();
	}

	private String grenerateRadomNumber(int inputDigits) {
		return String.valueOf(inputDigits < 1 ? 0 : new Random()
				.nextInt((9 * (int) Math.pow(10, inputDigits - 1)) - 1)
				+ (int) Math.pow(10, inputDigits - 1));
	}

	public String format(String text, String... val2) {
		for (int occurence = 0; occurence < val2.length; occurence++) {
			text = text.replace("#" + occurence + "#", val2[occurence]);
		}
		return text;
	}

	private JSONObject createOMSMockPayload(String uuID, String xrefPONumber, String mockPOMssg)
	{
		JSONObject request = new JSONObject();
		request.put("id", uuID);
		request.put("uuid", uuID);

		JSONObject child1 = new JSONObject();
		child1.put("urlPattern", "/"+xrefPONumber+".*");
		child1.put("method", "GET");
		request.put("request", child1);

		JSONObject child2 = new JSONObject();
		child2.put("status", 200);
		child2.put("body", mockPOMssg);


		JSONObject child2Subchild1 = new JSONObject();
		child2Subchild1.put("Content-Type", "application/soap+xml");
		child2.put("headers", child2Subchild1);
		request.put("response", child2);

		return request;
	}

	private void validateEnterpriseMDMDetails(String poNumber, String itemNumber) throws JSONException {
		logger.info("Validating enterprise MDM details for the item {}", itemNumber);
		Failsafe.with(retryPolicy).run(() -> {
		manifestResponse =SerenityRest.given().relaxedHTTPSValidation().header("facilityCountryCode", environment.getProperty("country_code")).header("facilityNum", environment.getProperty("thor_dcNumber")).when().get(environment.getProperty(THOR_MANIFEST_GETPO_URL) + poNumber);
		manifestResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);	
		});
		DocumentContext manifestJsonParser = JsonPath.parse(manifestResponse.asString());
		List<String> manifestCaseUPCList = manifestJsonParser.read("$.lines[*].item.caseUPC");

		Failsafe.with(retryPolicy).run(() -> {
			enterpriseMDMResponse = SerenityRest.given().relaxedHTTPSValidation()
					.header("Content-Type", ContentType.JSON)
					.header("Accept",
							"application/vnd.com.walmart.canonical.masterItem.MasterProduct-7+json")
					.header("wmt-api-key", environment.getProperty("enterprise_mdm_api_key"))
					.header("itemNumbers", itemNumber).get(environment.getProperty("enterprise_mdm_ep"));
			enterpriseMDMResponse.then().statusCode(206);
		});


		JSONArray enterpriseMDMJsonArrayResponse = new JSONArray(enterpriseMDMResponse.asString());
		DocumentContext enterpriseMDMJsonParser = JsonPath.parse(enterpriseMDMJsonArrayResponse.getJSONObject(0).toString());
		List<String> enterpriseMDMCaseUPCList = enterpriseMDMJsonParser.read("$.tradeItemsSupplyItems[*].supplyItemTradeItemPack[*]..orderableGTIN");

		Assert.assertEquals(ErrorCodes.THOR_CASE_UPC_MISMATCH, manifestCaseUPCList.get(0), enterpriseMDMCaseUPCList.get(0));
		logger.info("Successfully validated enterprise MDDM details for the item {}", itemNumber);
	}

	private void validateVendorDetails(String poNumber) {
		logger.info("Validating vendor details for the po {}", poNumber);
		Failsafe.with(retryPolicy).run(() -> {
		manifestResponse =SerenityRest.given().relaxedHTTPSValidation().header("facilityCountryCode", environment.getProperty("country_code")).header("facilityNum", environment.getProperty("thor_dcNumber")).when().get(environment.getProperty(THOR_MANIFEST_GETPO_URL) + poNumber);
		manifestResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
		});
		
		DocumentContext manifestJsonParser = JsonPath.parse(manifestResponse.asString());
		String vndrNumber = manifestJsonParser.read("$.vndrNbr");
		String vndrName = manifestJsonParser.read("$.vndrName");

		Failsafe.with(retryPolicyWithCustomCount).run(() -> {
		vendorDetailsResponse = SerenityRest.given().relaxedHTTPSValidation()
				.header("Accept", "application/json")
				.header("wmt-api-key", environment.getProperty("vendor_details_api"))
				.get(environment.getProperty("get_vendor_details_url")+vndrNumber+"?q=basic");
		vendorDetailsResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
		});
		
		DocumentContext vendorDetailsJsonParser = JsonPath.parse(vendorDetailsResponse.asString());
		List<String> vendorName = vendorDetailsJsonParser.read("$.supplier.legalName[*].textValue");

		Assert.assertEquals(ErrorCodes.THOR_VENDOR_NAME_MISMATCH, vendorName.get(0), vndrName);
		logger.info("Successfully validated vendor details for the po {}", poNumber);
	}
	
	public void deleteOMSMock() {
		if(threadLocal.get().get(TESTFLOW_DATA)!=null) {
		testFlowData = threadLocal.get().get(TESTFLOW_DATA).toString();
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> usedUUIDList = jsonParser.read(UUID_JSON_PATH);
		if (!usedUUIDList.isEmpty()) {
			logger.info("Clearing OMS PO created");
			for (String uuId : usedUUIDList) {
				if ((uuId!=null)&&(!uuId.equals(""))) {
					logger.info("DELETE OMS MOCK PO URL : {}",environment.getProperty(MOCK_ADMIN_URL)+uuId);
					Response postMockPoDeleteResponse = SerenityRest.given().when().delete(environment.getProperty(MOCK_ADMIN_URL)+uuId);
					postMockPoDeleteResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
				}
			}
			logger.info("Cleared OMS PO created");
		}
	}
	}
}
