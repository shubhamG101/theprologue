package com.walmart.supplychain.catalyst.loading.scenariosteps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.loading.steps.mobile.CatalystLoadingSteps;
import com.walmart.supplychain.catalyst.picking.steps.mobile.CatalystPickingSteps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class CatalystLoadingScenarios {

	@Steps
	CatalystLoadingSteps catalystLoadingSteps;
	
	@Given("^user performs wrapping task$")
	public void userPerformsWrapping() throws JsonProcessingException, InterruptedException {
		catalystLoadingSteps.performWrapping();
	}
	
	@Given("^user performs loading task$")
	public void userPerformsLoading() throws JsonProcessingException, InterruptedException {
		catalystLoadingSteps.performLoading();
	}
	
}
