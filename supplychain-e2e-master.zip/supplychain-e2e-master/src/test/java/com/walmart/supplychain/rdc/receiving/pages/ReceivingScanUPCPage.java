package com.walmart.supplychain.rdc.receiving.pages;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.google.common.collect.ImmutableMap;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.webdriver.WebDriverFacade;

public class ReceivingScanUPCPage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_search_delivery']")
	private WebElement doorSearchBtn;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_complete_del']")
	private WebElement deliveryCompleteBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/button1']")
	private WebElement deliveryCompleteConfirmBtn;

	@FindBy(xpath = ".//*[@content-desc='More options']")
	private WebElement kebobBtn;

	// @FindBy(xpath = "//*[@text='loading-mobile']")
	// private WebElement loadingApp;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/title']")
	private WebElement printDockTagBtn;

	@FindBy(xpath = ".//*[@content-desc='Navigate up']")
	private WebElement backBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/button1']")
	private WebElement backCnfrmBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/message']")
	private WebElement upcErrorText;

	@FindBy(xpath = ".//*[@text='Update GTIN']")
	private WebElement updateGTINBtn;
	
	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/summary_close']")
	private WebElement deliveryConfirmCloseBtn;
	
	

	public void scanupc(String upc) {
		try {

			logger.info("Scanning item upc:" + upc);
			List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
					"com.walmart.move.nim.receiving.mobile", "-e",
					"com.motorolasolutions.emdk.datawedge.data_string " + upc, "-e",
					"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN128");

			Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
			logger.info(scanEvent.toString());
			AndroidDriver<AndroidElement> androidDriv = getAndroidDriver();
			androidDriv.executeScript("mobile: shell", scanEvent);
		} catch (Exception e) {

		}
	}

	public void compleDelivery() {
		try {
		element(deliveryCompleteBtn).waitUntilVisible();
		element(deliveryCompleteBtn).click();
		Thread.sleep(1000);
		element(deliveryCompleteConfirmBtn).waitUntilVisible();
		element(deliveryCompleteConfirmBtn).click();
		Thread.sleep(1000);
		element(deliveryConfirmCloseBtn).waitUntilVisible();
		element(deliveryConfirmCloseBtn).click();
		}catch(Exception e) {
			}
	}

	public void clickCreateDockTag() {
		try {
			element(kebobBtn).waitUntilVisible();
			element(kebobBtn).click();
			Thread.sleep(2000);
			element(printDockTagBtn).waitUntilVisible();
			element(printDockTagBtn).click();
		} catch (Exception e) {

		}

	}

	public void navigateToMainMenu() {
		try {
			element(backBtn).waitUntilVisible();
			element(backBtn).click();
			Thread.sleep(4000);
			element(backCnfrmBtn).waitUntilVisible();
			element(backCnfrmBtn).click();
		} catch (Exception e) {

		}

	}

	public String getupcErrorTxt() {
		element(upcErrorText).waitUntilVisible();
		return element(upcErrorText).getText();
	}

	public void clickUpdateGtin() {
		element(updateGTINBtn).waitUntilVisible();
		element(updateGTINBtn).click();
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
	}

}
