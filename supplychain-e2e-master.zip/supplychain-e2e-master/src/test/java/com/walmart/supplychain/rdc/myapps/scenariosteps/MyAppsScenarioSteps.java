package com.walmart.supplychain.rdc.myapps.scenariosteps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.pharmacy.receiving.scenariosteps.mobile.ReceivingPharmSteps;
import com.walmart.supplychain.rdc.myapps.steps.MyAppsSteps;
import com.walmart.supplychain.witron.loading.steps.LoadingStep;
import com.walmart.supplychain.witron.myapps.pages.MyAppsHomePage;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class MyAppsScenarioSteps {

	@Steps
	MyAppsSteps myAppsSteps;

	@Steps
	ReceivingPharmSteps receivingPharmSteps;

	@Given("^user logins to My app Mobile$")
	public void userLoginsToMyApp() throws JsonProcessingException {
		myAppsSteps.loginToMyApps();

	}

	@Given("^user kills my apps$")
	public void userKillsMyApp() throws JsonProcessingException {
		try {
			receivingPharmSteps.killApp();
			myAppsSteps.killMyApps();
		} catch (Exception e) {
		}

	}

}
