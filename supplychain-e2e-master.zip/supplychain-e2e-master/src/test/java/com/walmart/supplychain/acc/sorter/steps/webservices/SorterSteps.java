package com.walmart.supplychain.acc.sorter.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class SorterSteps {

	@Autowired
	SorterHelper sorterHelper;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	Environment environment;

	@Autowired
	InventoryHelper inventoryHelper;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	DbUtils dbUtils;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	Logger logger = LoggerFactory.getLogger(SorterSteps.class);

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private static final String LPN_SORTERRESPONSE_JSONPATH = "$.lpnFoundList[*].containerUUID";
	String sorterLpnSearchResponse = "";
	DocumentContext parsedResponse = null;
	List<String> lpnSearchResLPNList = null;
	private static final String INVENTORY_SEARCH_ENDPOINT_STATUS = "inventory_search_ep_status";
	private static final String INVENTORY_SEARCH_ENDPOINT_KEY = "inventory_search_ep";
	private static final String INVENTORY_QUERYPARAM_KEY = "inventory_ep_qp";
	private static final String CONT_STATUS_NORMAL_LPN_JSON_PATH = "$.aggrInvList[*].containerInventories[*].containerStatus";
	private static final String CONT_STATUS_EXP_LPN_JSON_PATH = "$.containerStatus";
	private static final String PICKED_LPN_STATUS = "PICKED";
	private static final String PROBLEM_NA_LPN_STATUS = "PROBLEM_NA";
	private static final String PROBLME_OV_LPN_STATUS = "PROBLEM_OV";
	private static final String PROBLME_CF_LPN_STATUS = "PROBLEM_CF";
	private static final String NORMAL_LPN_STATUS = "NORMAL";
	private static final String TESTDATAFLOW = "testFlowData";

	@Step
	public void validateAndSetLPNtoStoreMap(String flowType) {
		try {
			DocumentContext parsedJson;
			String testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			String testFlowDataUpdated = testFlowData;
			parsedJson = JsonPath.parse(testFlowData);
			List<String> poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				for (String itemNum : itemList) {
					int expProbNaLPNCount = 0;
					int expProbOvgLPNCount = 0;
					int normalLPNCount = 0;
					int expProbCfLPNCount=0;
					List<String> recAllLPNList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.itemNumber=='" + itemNum
							+ "')].receivingInstructions[*].parentContainer");
					List<String> recNormalLPNList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber=='" + itemNum
							+ "')].receivingInstructions[?(@.labelType=='normal')].parentContainer");
					List<String> recExceptionLPNList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber=='" + itemNum
							+ "')].receivingInstructions[?(@.labelType=='exception')].parentContainer");
					List<String> poQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.itemNumber=='" + itemNum + "')].poVnpkQty");
					int poQty = 0;
					List<String> ovgQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.itemNumber=='" + itemNum + "')].ovgQty");
					int ovgQty = 0;
					List<String> owOrderQtyList = parsedJson
							.read("$.testFlowData.ordersDetails[?(@.itemNumber=='" + itemNum + "')].quantity");
					int owOrderQty = 0;
					List<String> vnpkList = parsedJson
							.read("$.testFlowData.ordersDetails[?(@.itemNumber=='" + itemNum + "')].vnpk");
					for (String intpoQty : poQtyList) {
						poQty = poQty + Integer.parseInt(intpoQty);
					}
					for (String intovgQty : ovgQtyList) {
						ovgQty = ovgQty + Integer.parseInt(intovgQty);
					}
					for (int orderQtyIndex = 0; orderQtyIndex < owOrderQtyList.size(); orderQtyIndex++) {
						owOrderQty = owOrderQty + (Integer.parseInt(owOrderQtyList.get(orderQtyIndex))
								/ Integer.parseInt(vnpkList.get(orderQtyIndex)));
					}

					Failsafe.with(retryPolicy).run(() -> {
						sorterLpnSearchResponse = sorterHelper.getLPNtoRDCMapResponse(recAllLPNList);
						logger.info("sorter response :" + sorterLpnSearchResponse);
						parsedResponse = JsonPath.parse(sorterLpnSearchResponse);
						lpnSearchResLPNList = parsedResponse.read(LPN_SORTERRESPONSE_JSONPATH);
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH, recAllLPNList.size(),
								lpnSearchResLPNList.size());
					});
					for (String recLpn : recAllLPNList) {
						logger.info("LPN to RDC map :: validating and setting destination or container {}", recLpn);
						Assert.assertTrue(ErrorCodes.SORTER_LPN_MISMATCH, lpnSearchResLPNList.contains(recLpn));

						List<Integer> destRDCList = parsedResponse
								.read("$.lpnFoundList[?(@.containerUUID == '" + recLpn + "')].storeNbr");
						List<Integer> labelTypeCodeList = parsedResponse
								.read("$.lpnFoundList[?(@.containerUUID == '" + recLpn + "')].labelTypeCode");
						int labelTypeCode = labelTypeCodeList.get(0);
						if (labelTypeCode == 1) {
							validateInventoryStatusForNormallpn(recLpn, PICKED_LPN_STATUS);
							String destRDC = String.valueOf(destRDCList.get(0));
							testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowDataUpdated, destRDC,
									"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + recLpn
											+ "')].destNumber");
							testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowDataUpdated, "normal",
									"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + recLpn
											+ "')].labelType");
							normalLPNCount = normalLPNCount + 1;
							logger.info("Container {} type is NORMAL", recLpn);

						} else if (labelTypeCode == 3) {
							validateInventoryStatusForExceptionlpn(recLpn, PROBLME_OV_LPN_STATUS);
							testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowDataUpdated, "exception_ovg",
									"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + recLpn
											+ "')].labelType");
							expProbOvgLPNCount = expProbOvgLPNCount + 1;
							logger.info("Container {} type is exception_ovg", recLpn);
						} else if (labelTypeCode == 7) {
							validateInventoryStatusForExceptionlpn(recLpn, PROBLEM_NA_LPN_STATUS);
							testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowDataUpdated, "exception_na",
									"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + recLpn
											+ "')].labelType");
							expProbNaLPNCount = expProbNaLPNCount + 1;
							logger.info("Container {} type is exception_na", recLpn);
						} else if (labelTypeCode == 8) {
							validateInventoryStatusForExceptionlpn(recLpn, PROBLME_CF_LPN_STATUS);
							testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowDataUpdated, "exception_cf",
									"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + recLpn
											+ "')].labelType");
							expProbCfLPNCount = expProbCfLPNCount + 1;
							logger.info("Container {} type is exception_cf", recLpn);
						} 
					}
					logger.info("updated Testdataflow for the item {} is {} ", itemNum, testFlowDataUpdated);
					if (flowType.equalsIgnoreCase(NORMAL_LPN_STATUS)) {
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH_NORMAL_FLOW, recNormalLPNList.size(),
								normalLPNCount);
					} else if (flowType.equalsIgnoreCase(PROBLEM_NA_LPN_STATUS)) {
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH_NORMALLABELS_PROBLEM_NA_FLOW,
								owOrderQty, normalLPNCount);
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH_EXCEPTIONLABELS_PROBLEM_NA_FLOW,
								((recNormalLPNList.size() + recExceptionLPNList.size()) - owOrderQty),
								expProbNaLPNCount);
					} else if (flowType.equalsIgnoreCase(PROBLME_OV_LPN_STATUS)) {
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH_NORMALLABELS_PROBLEM_OVG_FLOW,
								poQty + ovgQty, normalLPNCount);
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH_EXCEPTIONLABELS_PROBLEM_OVG_FLOW,
								recExceptionLPNList.size(), expProbOvgLPNCount);
					} else if (flowType.equalsIgnoreCase(PROBLME_CF_LPN_STATUS)) {
						Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH_FLIP_FLOW, recAllLPNList.size(),
								expProbCfLPNCount);
					}
				}
			}

			threadLocal.get().put(TESTDATAFLOW, testFlowDataUpdated);
			testFlowData = String.valueOf(threadLocal.get().get(TESTDATAFLOW));
			logger.info("TestFlowData after LPN to RDC destination update {}", testFlowData);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure(
					"Something went wrong while validating LPNs of receive Instrution with Sorter LPN resposnse", e);
		}

	}

	@Step
	public void validateInventoryStatusForExceptionlpn(String container, String expContStatus) {
		
		Response response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
				.get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_STATUS) + container
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		
//		Response response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_STATUS) + container
//				+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		
		logger.info("Waiting for validating container Status  {} for Container Id in inventory:{}", expContStatus,
				container);
		Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_STATUS,
				parseInvContainerStatusForExceptionLPN(response, CONT_STATUS_EXP_LPN_JSON_PATH),
				expContStatus.toUpperCase());
		logger.info("validated container Status {} for Container Id in inventory:{}", expContStatus, container);
	}

	@Step
	public void validateInventoryStatusForNormallpn(String container, String expContStatus) {
		
		Response response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
				.get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + container
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		
//		Response response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + container
//				+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
		logger.info("Waiting for validating container Status  {} for Container Id in inventory:{}", expContStatus,
				container);
		Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_STATUS,
				parseInvContainerStatusForNormalLPN(response, CONT_STATUS_NORMAL_LPN_JSON_PATH),
				expContStatus.toUpperCase());
		logger.info("validated container Status {} for Container Id in inventory:{}", expContStatus, container);
	}

	public String parseInvContainerStatusForExceptionLPN(Response response, String contStatusJsonPath) {
		String responseStr = response.getBody().asString();
		DocumentContext parsedJsonInvRes = JsonPath.parse(responseStr);
		return parsedJsonInvRes.read(contStatusJsonPath);
	}

	public String parseInvContainerStatusForNormalLPN(Response response, String contStatusJsonPath) {
		String responseStr = response.getBody().asString();
		DocumentContext parsedJsonInvRes = JsonPath.parse(responseStr);
		List<String> contStatusList = parsedJsonInvRes.read(contStatusJsonPath);
		return contStatusList.get(0);
	}

	public void verificationOfsorterDBpurge() {
		
		try {
			Failsafe.with(retryPolicy).run(() -> {

				String testFlowData = String.valueOf(tl.get().get("testFlowData"));

				JSONArray lpns = JsonPath.parse(testFlowData)
						.read("$..containerIds[*]");
								
				Object[] lpnArr = new Object[lpns.size()];
				for (int i = 0; i < lpns.size(); i++) {
					lpnArr[i] = lpns.get(i);
				}
				List<Map<String, Object>> lpnIds;
				logger.info("LPN count in sorter DB query {}", environment.getProperty("select_lpn_crossref"));

				lpnIds = dbUtils.selectFrom(Config.DC,
						dbUtils.transformIntoSpringQuery(environment.getProperty("select_lpn_crossref"), lpns.size()),
						lpnArr);
				
				logger.info("select_lpn_crossref size is "+lpnIds.size());
				Assert.assertEquals(ErrorCodes.SORTER_DB_NOT_PURGED, 0, lpnIds.size());
				
				logger.info("LPN count in sorter DB query {}", environment.getProperty("select_lpn_xref_vndr_evnt"));

				lpnIds = dbUtils.selectFrom(Config.DC, dbUtils.transformIntoSpringQuery(
						environment.getProperty("select_lpn_xref_vndr_evnt"), lpns.size()), lpnArr);

				logger.info("select_lpn_xref_vndr_evnt size is "+lpnIds.size());
				Assert.assertEquals(ErrorCodes.SORTER_DB_NOT_PURGED, 0, lpnIds.size());

			});			
		} catch (Exception e) {
			logger.info("Sorter DB purge failed ");
		}
	}
}
