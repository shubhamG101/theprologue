package com.walmart.supplychain.catalyst.by.ui.scenarioSteps;

import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.catalyst.by.ui.pages.BYReceivingPage;
import com.walmart.supplychain.catalyst.by.ui.steps.BYInboundSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYOutboundSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYReceivingSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BYInboundScenarios {
	
	@Steps
	BYReceivingSteps byReceivingSteps;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	BYReceivingPage byReceivingPage;
	
	@Steps
	BYInboundSteps byInboundSteps;
	
	@Steps
	BYOutboundSteps byOutboundSteps;
	
	@Given("^User Logins to BY_UI$")
	public void userLoginsToBY_UI() throws Throwable {
	Thread.sleep(10000);
	byReceivingSteps.loginToBY();
	}
	
	@Given("^User navigates to \"([^\"]*)\" Menu and \"([^\"]*)\" tab$")
	public void userNavigatesToMenuAndMentionedTab(String menu, String tab) throws Throwable {	
		byUiHelper.navigateToMentionedMenu(menu);
		byUiHelper.navigateToMentionedTab(tab);
		
	}

	@Given("^user changes QC status as \"([^\"]*)\" in BY Web UI$")
	public void changeQcStatusInQCDashboard(String newStatus) {		
		byInboundSteps.changeQcStatus(newStatus);
	}
	
	@Given("^user changes Inventory Status as \"([^\"]*)\" in BY Web UI$")
	public void changeInventory(String newStatus) {		
		byInboundSteps.changeInventoryStatus(newStatus);
	}
	
	@Given("^user creates problem ticket in BY UI$")
	public void createProblemTicket() throws Throwable {
		
		byInboundSteps.createProblemTicketForUnexpectedItem();
	}
	

}
