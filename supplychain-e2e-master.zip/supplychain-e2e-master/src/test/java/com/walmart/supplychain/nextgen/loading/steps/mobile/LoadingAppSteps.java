package com.walmart.supplychain.nextgen.loading.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.NoAlertPresentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.acc.Unload;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.loading.pages.mobile.LoadingAppPage;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingHelper;
import com.walmart.supplychain.nextgen.yms.pages.ui.YMSLoginPage;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.core.exceptions.SerenityManagedException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;
import com.walmart.framework.utilities.javautils.Assert;
import io.restassured.response.Response;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class LoadingAppSteps extends ScenarioSteps {
	@Autowired
	LoadingAppPage loadingAppPage;
	Response response;

	YMSLoginPage ymsLoginPage;
	Logger logger = LogManager.getLogger(this.getClass());
	PropertyResolver propertyResolver = new PropertyResolver();
	JsonUtils jsonUtil = new JsonUtils();
	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	@Autowired
	TextParser textParser;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	ObjectMapper objectMapper = new ObjectMapper();
	@Autowired
	LoadingHelper loadingHelper;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	public static final String CTR_LIST = "containerList";
	public static final String CTR_TAG_ID = "containerTagId";
	private static final String OUTBOUND_GET_ENTITY = "$.testFlowData.outboundDetails[*]";
	private static final String UNLOAD_EP = "unload_url";
	private static final String UNLOAD_QUERY_PARM = "unload_query_parm";

	public void open_Loading_App_Page() {
		if (Config.DC == DC_TYPE.ATLAS) {
			loadingAppPage.getUrl(environment.getProperty("atlas_loadingappurl"));
		} else {
			logger.info("loadingappurl" + environment.getProperty("loadingappurl"));
			loadingAppPage.getUrl(environment.getProperty("loadingappurl"));
		}
	}

	public void handlePopup() {
		try {
			loadingAppPage.handleAlertPopup();
		} catch (NoAlertPresentException e) {
			Assert.fail(ErrorCodes.LOADING_MOBILE_UI_NOT_AVAILABLE);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to neutralize the popup", e);
		}
		logger.info("popup neutralized");

	}

	@Step
	public String generateTheLoadId(List<String> cntrList, String door, String trailer) {
		try {
			String loadId = loadingAppPage.generateLoadId(cntrList, door, trailer);
			return loadId;
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the load", e);
		}

	}

	public void scanTheDoor(String door) {
		try {
			loadingAppPage.scanDoor(door);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	// @Step
	public String closeLoadInLoading(String doorFlag) {
		try {
			String sealNo = getSealNumber();
			loadingAppPage.closeLoad(sealNo, doorFlag);
			return sealNo;
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while closing the load", e);
		}
	}

	@Step
	public void loadContainers() {
		try {
			String testData = (String) tl.get().get("testFlowData");
			DocumentContext context = null;
			List outBoundList = new ArrayList();
			List obdList = new ArrayList();
			ObjectMapper om = new ObjectMapper();

			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;

			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			if (outboundList.isEmpty())
				throw new AutomationFailure("Outbound List in testflowdata is empty");
			for (int i = 0; i < outboundList.size(); i++) {

				OutboundDetail obdDetail = outboundList.get(i);
				String dest = obdDetail.getDestNumber();
				String door = obdDetail.getOutboundDoorNumber();
				String trailer = obdDetail.getTrailerNumber();
				
				List<String> cntrList= new ArrayList<String>();
				List<String> listOfParentSSTKOrDaNonConCntrToLoad=null;
				List<String> listOfParentDaConCntrToLoad=null;
				List<String> listOfParentDSDCorPOCONToLoad=null;
				listOfParentSSTKOrDaNonConCntrToLoad = JsonPath.read(testData,"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == \""+dest+"\"&& "
						+ "(@.isPbyl == false || @.isPBYL == false) && (@.isVTR == false) && (@.isDamage == false) && "
						+ "(@.channelType ==\""+ CHANNELS.SSTKU.getValue().toUpperCase() +"\"|| @.channelType == \""+CHANNELS.CROSSNA.getValue().toUpperCase() +"\""
						+ "|| @.channelType == \""+ CHANNELS.CROSSNMA.getValue().toUpperCase()+"\"|| @.channelType == \""+ CHANNELS.POCON.getValue().toUpperCase()+"\"))].parentContainer");
				listOfParentDaConCntrToLoad= JsonPath.read(testData,"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == \"" + dest+ "\" "
						+ "&& (@.isPbyl == false || @.isPBYL == false) && (@.isVTR == false) && (@.channelType ==\""+ CHANNELS.CROSSU.getValue().toUpperCase() + "\" "
						+ "|| @.channelType == \""+ CHANNELS.CROSSMU.getValue().toUpperCase() + "\"))].parentContainer");
				listOfParentDSDCorPOCONToLoad= JsonPath.read(testData,"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == \"" + dest+ "\" "
						+ "&& (@.isPbyl == false || @.isPBYL == false) && (@.isVTR == false) && (@.channelType ==\""+ CHANNELS.POCON.getValue().toUpperCase() + "\" "
						+ "|| @.channelType == \""+ CHANNELS.DSDC.getValue().toUpperCase() + "\"))].parentContainer");
				
				cntrList.addAll(listOfParentSSTKOrDaNonConCntrToLoad);
				cntrList.addAll(listOfParentDaConCntrToLoad);
				cntrList.addAll(listOfParentDSDCorPOCONToLoad);
				logger.info("Container list is:{}", cntrList);
				open_Loading_App_Page();
				String loadId = generateTheLoadId(cntrList, door, trailer);
				obdDetail.setLoadId(loadId);
				List<String> listOfChildContainers = new ArrayList<>();
				JSONArray listOfCntrsCROSSU = JsonPath.read(testData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
								+ obdDetail.getDestNumber() + " && @.isPbyl == false && @.isVTR == false && @.isDamage == false && (@.channelType == \""
								+ CHANNELS.CROSSU.getValue().toUpperCase() + "\" || @.channelType == \""
								+ CHANNELS.CROSSMU.getValue().toUpperCase() + "\"))].childContainers[*]");
				String crossucntrString = listOfCntrsCROSSU.toJSONString();
				List<String> crossuCntrList = objectMapper.readValue(crossucntrString, new TypeReference<List<String>>() {
				});
				List<String> listOfContainers = new ArrayList<>();
				if (crossuCntrList.size() != 0) {
					listOfContainers.addAll(crossuCntrList);

				}

				JSONArray listOfCntrsSstkOrDANonCon = JsonPath.read(testData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
								+ obdDetail.getDestNumber()
								+ " && @.isPbyl == false && @.isPbyl == false && @.isVTR == false && @.isDamage == false && (@.channelType == \""
								+ CHANNELS.SSTKU.getValue().toUpperCase() + "\" || @.channelType == \""
								+ CHANNELS.CROSSNA.getValue().toUpperCase() + "\" || @.channelType == \""
								+ CHANNELS.CROSSNMA.getValue().toUpperCase() + "\"))].parentContainer");
				String cntrStringSstkOrDANonCon = listOfCntrsSstkOrDANonCon.toJSONString();
				List<String> sstkuOrDANonConCntrList = objectMapper.readValue(cntrStringSstkOrDANonCon,
						new TypeReference<List<String>>() {
						});
				if (sstkuOrDANonConCntrList.size() != 0) {
					listOfContainers.addAll(sstkuOrDANonConCntrList);
				}

				for (int j = 0; j < listOfContainers.size(); j++) {
					listOfChildContainers.add(listOfContainers.get(j).toString());
				}

				obdDetail.setContainerIds(listOfChildContainers);
//				obdDetail.setContainerIds(cntrList);
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(outboundList);
			context.set("$.testFlowData.outboundDetails",
					JsonPath.parse(om.writeValueAsString(outboundList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put("testFlowData", str);
			logger.info("testData after updating load ID::{}", tl.get().get("testFlowData"));

		} catch (AssertionError | FailsafeException |SerenityManagedException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while loading the containers", e);
		}
	}

	boolean retry = false;

	@Step
	public void closeLoads() {
		try {
			String testData = (String) tl.get().get("testFlowData");
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String outBoundString = listOfLoads1.toJSONString();
			List<OutboundDetail> outboundList = null;
			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			for (int i = 0; i < outboundList.size(); i++) {
				OutboundDetail obdDetail = outboundList.get(i);
				//Failsafe.with(retryPolicy).run(() -> {
//					if (retry) {
//						loadingAppPage.closeDriver();
//						logger.info("Retrying.......:");
//					}
					//retry = true;
					open_Loading_App_Page();
//					handlePopup();
					String door = obdDetail.getOutboundDoorNumber();
					scanTheDoor(door);
					String doorType = null;
					if (Config.DC != DC_TYPE.ATLAS) {
						doorType="Y";
//						response = when().get(environment.getProperty("get_doors_url"));
//						Assert.assertEquals(ErrorCodes.DOORS_STATUS_MISMATCH, 200, response.getStatusCode());
//
//						JSONArray listOfMechanizedInd = JsonPath.read(response.asString(),
//								"$.[?(@.number==" + door + ")].config.conveyorInd");
//						String listOfMechanizedIndString = listOfMechanizedInd.toJSONString();
//						List<String> mechanizedList = null;
//						mechanizedList = om.readValue(listOfMechanizedIndString, new TypeReference<List<String>>() {
//						});
//						doorType = mechanizedList.get(0);
					}
					String sealNo = closeLoadInLoading(doorType);
					obdDetail.setSealNumber(sealNo);
				//});
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(outboundList);
			context.set("$.testFlowData.outboundDetails",
					JsonPath.parse(om.writeValueAsString(outboundList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put("testFlowData", str);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while closing the load", e);
		}

	}

	@Step
	public void createLoad() throws JSONException, URISyntaxException, IOException {

		String createLoadMessage = textParser.readTextFile(FileNames.CREATE_LOAD);
		JSONObject createLoadMessg = new JSONObject(createLoadMessage);
		org.json.JSONArray ctrArr = createLoadMessg.getJSONArray(CTR_LIST);
		String containerListObjSstk = ctrArr.getJSONObject(0).toString();
		String containerListObjDa = ctrArr.getJSONObject(1).toString();
		String runTimeData = (String) tl.get().get("testFlowData");
		String channelType = JsonPath.parse(runTimeData).read("$.testFlowData.ordersDetails[0].channelMethod");
		JSONArray parentCtrs = JsonPath.parse(runTimeData).read("$..parentContainer");
		org.json.JSONArray ctrArrayList = new org.json.JSONArray();

		if (channelType.toLowerCase().contains("stock")) {

			for (int i = 0; i < parentCtrs.size(); i++) {

				JSONObject arrayObject = new JSONObject(containerListObjSstk);
				arrayObject.put(CTR_TAG_ID, parentCtrs.get(i).toString());
				ctrArrayList.put(i, arrayObject);
			}

			createLoadMessg.put(CTR_LIST, ctrArr);

		} else {

			for (int j = 0; j < parentCtrs.size(); j++) {

				List<String> childContainers = JsonPath.parse(runTimeData)
						.read("$..receivingInstructions[?(@.parentContainer=='" + parentCtrs.get(j).toString()
								+ "')].childContainers[*]");
				JSONObject arrayObject = new JSONObject(containerListObjDa);
				arrayObject.put(CTR_TAG_ID, parentCtrs.get(j).toString());
				org.json.JSONArray childCtrs = arrayObject.getJSONArray("childContainers");
				String childObjStr = childCtrs.get(0).toString();
				for (int k = 0; k < childContainers.size(); k++) {

					JSONObject childObj = new JSONObject(childObjStr);
					childObj.put(CTR_TAG_ID, childContainers.get(k).toString());
					childCtrs.put(k, childObj);
				}
				arrayObject.put("childContainers", childCtrs);
				ctrArrayList.put(j, arrayObject);

			}
			createLoadMessg.put(CTR_LIST, ctrArrayList);

		}
		logger.info("Create load message is: {}", createLoadMessg.toString());
		Response response;
		response = given().relaxedHTTPSValidation().body(createLoadMessg.toString())
				.headers(loadingHelper.getloadingHeaders()).when().post((environment.getProperty("create_load_ep")));
		response.then().statusCode(Constants.SUCESS_STATUS_CODE);
		int loadId = (int) JsonPath.parse(response.toString()).read("$.loadId");
		tl.get().put("loadId", loadId);

	}

	@Step
	public void closeLoad() {
		int loadId = (int) tl.get().get("loadId");
		logger.info("load id to close the load :: {}", loadId);
		String closeLoadMessage;
		try {
			closeLoadMessage = textParser.readTextFile(FileNames.CLOSE_LOAD);
			JSONObject jsonMessage = new JSONObject(closeLoadMessage);
			jsonMessage.put("sealNumber", "seal" + javaUtils.randonNumberGenerator(2));
			logger.info("Request body for close load request:: {}", jsonMessage);
			Response closeLoadResponse = SerenityRest.given().relaxedHTTPSValidation().body(jsonMessage.toString())
					.headers(loadingHelper.getloadingHeaders()).when()
					.put(MessageFormat.format(environment.getProperty("close_load_ep"), loadId));
			closeLoadResponse.then().statusCode(Constants.SUCESS_STATUS_CODE);
		} catch (JSONException | URISyntaxException | IOException e) {
			logger.info("Failed to close load");
			throw new TestCaseFailure("Failed to close load", e);
		}

	}

	@Step
	public void loadDamageContainers() {

		String testFlowData = (String) tl.get().get("testFlowData");
		List<String> damagedCtrs = JsonPath.read(testFlowData,
				"$.testFlowData..receivingInstructions[?(@.isDamage==true)].parentContainer");
		open_Loading_App_Page();
//		handlePopup();
		loadingAppPage.scanDamagedContainers(damagedCtrs);

	}

	@Step
	public void validateLoadStatus(String loadStatus) {

		try {
			String testFlowData = (String) tl.get().get("testFlowData");
			String outboundJson = null;
			List<String> loadIds = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*].loadId");
			Response response;
			logger.info("Validating the status of load in Loading");
			JSONArray listOfLoads = JsonPath.read(testFlowData, OUTBOUND_GET_ENTITY);

			try {
				outboundJson = objectMapper.writeValueAsString(listOfLoads);
			} catch (JsonProcessingException e1) {
				logger.error(e1);
			}
			for (String loadId : loadIds) {

				String payload = "{\"loadIds\":[" + loadId + "]}";
				response = SerenityRest.given().contentType("application/json").relaxedHTTPSValidation().body(payload)
						.headers(loadingHelper.getloadingHeaders()).when()
						.post(environment.getProperty("search_load_ep"));
				Assert.assertEquals(ErrorCodes.LOADING_INVALID_RESPONSE_CODE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				String loadStatusResponse = JsonPath.parse(response.asString()).read("$[0].loadStatusDesc");
				Assert.assertEquals(ErrorCodes.LOADING_STATUS_MISMATCH, loadStatus, loadStatusResponse);
			}

			
			List<OutboundDetail> outboundDetailList;
			outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);
			List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
			List<String> listOfChildContainers = new ArrayList<>();

			for (OutboundDetail outbound : outboundDetailList) {
				if(outbound.getContainerIds()==null||outbound.getContainerIds().isEmpty()) {
				JSONArray listOfCntrsCROSSU = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
								+ outbound.getDestNumber() + " && @.isPbyl == false  && (@.channelType == \""
								+ CHANNELS.CROSSU.getValue().toUpperCase() + "\" || @.channelType == \""
								+ CHANNELS.CROSSMU.getValue().toUpperCase() + "\"))].childContainers[*]");
				String cntrString = listOfCntrsCROSSU.toJSONString();

				List<String> crossuCntrList = objectMapper.readValue(cntrString, new TypeReference<List<String>>() {
				});

				List<String> listOfContainers = new ArrayList<>();
				if (crossuCntrList.size() != 0) {
					listOfContainers.addAll(crossuCntrList);

				}

				JSONArray listOfCntrsSstkOrDANonCon = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.destNumber == "
								+ outbound.getDestNumber()
								+ " && @.isPbyl == false && @.isVTR == false && (@.channelType == \""
								+ CHANNELS.STAPLESTOCK.getValue().toUpperCase() + "\" || @.channelType == \""
								+ CHANNELS.CROSSNA.getValue().toUpperCase() + "\" || @.channelType == \""
								+ CHANNELS.CROSSNMA.getValue().toUpperCase() + "\"))].parentContainer");
				String cntrStringSstkOrDANonCon = listOfCntrsSstkOrDANonCon.toJSONString();
				List<String> sstkuOrDANonConCntrList = objectMapper.readValue(cntrStringSstkOrDANonCon,
						new TypeReference<List<String>>() {
						});

				if (sstkuOrDANonConCntrList.size() != 0) {

					listOfContainers.addAll(sstkuOrDANonConCntrList);

				}

				for (int j = 0; j < listOfContainers.size(); j++) {
					listOfChildContainers.add(listOfContainers.get(j).toString());
				}

				outbound.setContainerIds(listOfChildContainers);
				listOfOutboundObj.add(outbound);
				String updatedtestflowdata;
				JSONArray listofOutboundJson = jsonUtil.converyListToJsonArray(listOfOutboundObj);
				updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testFlowData, listofOutboundJson,
						"$.testFlowData.outboundDetails");
				tl.get().put("testFlowData", updatedtestflowdata);
				logger.info("testData after updating::{}", tl.get().get("testFlowData"));

			}
				else {
					
					logger.info("Containers are already populated in the outbound object");
				}
			}	
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Load status in Loading ", e);
		}
	}

	public void reopenAndHoldLoad() {

		try {

			String testFlowData = (String) tl.get().get("testFlowData");
			List<String> loadIds = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*].loadId");
			String unloadId = loadIds.get(0);
			logger.info("ReOpening the already closed load having LoadId: {}", unloadId);
			List<String> door = JsonPath.read(testFlowData, "$..outboundDetails[*].outboundDoorNumber");
			String doorNumber = door.get(0);
			List<String> trailer = JsonPath.read(testFlowData, "$..outboundDetails[*].trailerNumber");
			String trailerNumber = trailer.get(0);
			open_Loading_App_Page();
//			handlePopup();
			scanDoorAndTrailer(doorNumber, trailerNumber);
			logger.info("ReOpened the already closed load in Loaading");
			logger.info("Putting the Load in ON HOLD Status");
			loadingAppPage.holdLoad(getSealNumber());
			logger.info("Succesfully put the Load ON HOLD from Loading UI");

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while putting the Load ON HOLD", e);
		}

	}

	private void scanDoorAndTrailer(String doorNumber, String trailerNumber) {

		try {
			loadingAppPage.scanDoorAndTrailer(doorNumber, trailerNumber);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while loading scan operations", e);
		}

	}

	public void scanTheTrailer(String trailer) {

		try {
			loadingAppPage.scanTrailerNumber(trailer);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the trailer", e);
		}
	}

	private String getSealNumber() {

		return "SL" + javaUtils.randonNumberGenerator(7);
	}

public void unloadContainer() {
		String testFlowData = (String) tl.get().get("testFlowData");
		List<String> loadIds = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*].loadId");
		String reOpenloadId = loadIds.get(0);
		List<String> childContainerList = JsonPath.read(testFlowData,"$..receivingInstructions[?(@.channelType == 'CROSSU')].childContainers[*]");
		Assert.assertNotEquals(ErrorCodes.LOADING_NO_CHILD_CONTAINERS, 0, childContainerList.size());
		String unloadedContainer = childContainerList.get(0);
		logger.info("Going to unload the container:{} which is already loaded in the load Id :{}",unloadedContainer,reOpenloadId);
		List<String> door = JsonPath.read(testFlowData,"$.testFlowData.outboundDetails[?(@.loadId == '"+reOpenloadId+"')].outboundDoorNumber");
		String doorNumber = door.get(0);
		List<String> trailer = JsonPath.read(testFlowData,"$.testFlowData.outboundDetails[?(@.loadId == '"+reOpenloadId+"')].trailerNumber");
		String trailerNumber = trailer.get(0);
		open_Loading_App_Page();
//		handlePopup();
		scanDoorAndTrailer(doorNumber,trailerNumber);
		containerUnload(unloadedContainer);
		logger.info("Unloaded the container :{} succesfully",unloadedContainer);
		updateTestFlowData(testFlowData,unloadedContainer);
		logger.info("TFD after updation of unloaded container is :{}",tl.get().get("testFlowData"));
		validateContainerUnload(reOpenloadId,unloadedContainer);
	}
	
	private void validateContainerUnload(String reOpenloadId, String unloadedContainer) {
		
		JsonObject payload = new JsonObject();
		JsonArray loadIds = new JsonArray();
		JsonArray containerIds = new JsonArray();
		loadIds.add(reOpenloadId);
		containerIds.add(unloadedContainer);
		payload.add("loadIds", loadIds);
		payload.add("containerTagIds", containerIds);
		Response response = given().relaxedHTTPSValidation().body(payload.toString())
				.headers(loadingHelper.getloadingHeaders()).contentType("application/json").when().post((environment.getProperty("search_cntrs_api")));
		response.then().statusCode(Constants.NO_CONTENT_STATUS_CODE);
		logger.info("Validated unloading of container in Loading and the container is not present in Loading");

	}

	private void containerUnload(String unloadedContainer) {

		loadingAppPage.unloadContainer(unloadedContainer);

	}

	private void updateTestFlowData(String testFlowData, String unloadedContainer) {

		JSONArray obdArray = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*]");
		String outboundJson;
		String newTestFlowData;
		List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
		List<String> unloadedContainers = new ArrayList();
		unloadedContainers.add(unloadedContainer);
		try {
			outboundJson = objectMapper.writeValueAsString(obdArray);
			List<OutboundDetail> outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);
			OutboundDetail obdDetail = outboundDetailList.get(0);
			List<String> loadedCtrs = (List<String>) obdDetail.getContainerIds();
			loadedCtrs.remove(unloadedContainer);
			obdDetail.setContainerIds(loadedCtrs);
			obdDetail.setUnloadedContainers(unloadedContainers);
			listOfOutboundObj.add(obdDetail);
			JSONArray listofOutboundJson = jsonUtil.converyListToJsonArray(listOfOutboundObj);
			newTestFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofOutboundJson,
					"$.testFlowData.outboundDetails");
			tl.get().put("testFlowData", newTestFlowData);
			System.out.println("updated");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void loadMCBContainers() {
		try {
			String testData = (String) tl.get().get("testFlowData");
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;
			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});

			for (OutboundDetail obd : outboundList) {
				open_Loading_App_Page();
				if (Config.DC==DC_TYPE.ACC) {
					handlePopup();
				}
				loadingAppPage.addContainersToExistingLoad(obd.getOutboundDoorNumber(), obd.getMcbContainerID());
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to load MCB container", e);
		}
	}

	public void unloadLoadedContainers(List<String> cntrsList) {
		try {

			for (String cntr : cntrsList) {
				Unload unload = new Unload();
				unload.setContainerTagId(cntr);

				response = given().relaxedHTTPSValidation().body(objectMapper.writeValueAsString(unload)).when()
						.put(environment.getProperty(UNLOAD_EP) + cntr + environment.getProperty(UNLOAD_QUERY_PARM));
				Assert.assertEquals(ErrorCodes.UNLOAD_CNTRS, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to unload containers", e);
		}

	}
}
