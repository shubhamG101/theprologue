package com.walmart.supplychain.dpb.gls.scenariosteps.mobile;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class GLSTripHelper extends ScenarioSteps {
	
	@Autowired
	Environment environment;
	
	@Autowired
	JsonUtils jsonUtil;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	DbUtils dbUtils;
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);
	private static final String TEST_FLOW_DATA = "testFlowData";
	private Response instructionResponse=null;
	private static final String DELIVERY_JSON_PATH = "$.testFlowData.deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber";
	private static final String PO_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..poNumbers[*]";
	String testFlowData;
	
	public String getcontainerResponseForDelivery(String deliveryNumber) {
		String responseAsString = null;
		String containerRequestUrl = MessageFormat.format(environment.getProperty("container_request_ep"),
				deliveryNumber);
		Failsafe.with(retryPolicy).run(() -> {
		instructionResponse = SerenityRest.given().relaxedHTTPSValidation().headers(getReceivingHeaders())
				.get(containerRequestUrl);
		Assert.assertEquals(ErrorCodes.PHARMACY_RECEIVING_UNBLE_TO_FETCH_INSTRUCTIONS, Constants.SUCESS_STATUS_CODE , instructionResponse.getStatusCode());
		});
		responseAsString = instructionResponse.getBody().asString();
		return responseAsString;
	}
	
	public Headers getReceivingHeaders() {
		Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		Header securityId = new Header("WMT-Security-ID", environment.getProperty("wmt_security_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(securityId);
		return new Headers(headerList);
	}
}
