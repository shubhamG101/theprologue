package com.walmart.supplychain.acc.loading.scenariosteps;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.openqa.selenium.NoAlertPresentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.loading.Load;
import com.walmart.framework.supplychain.domain.loading.SearchContainers;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.loading.pages.mobile.LoadingAppPage;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ACCLoadingSteps {

	@Steps
	LoadingAppPage loadingAppPage;

	@Steps
	ACLDBSteps aCLDBSteps;

	@Steps
	InventorySteps invSteps;

	Logger logger = LogManager.getLogger(this.getClass());
	PropertyResolver propertyResolver = new PropertyResolver();

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	TextParser textParser;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	JsonUtils jsonUtils;
	
	@Autowired
	LoadingHelper loadingHelper;

	@Autowired
	private YMSHelper ymsHelper;

	public static final String CTR_LIST = "containerList";
	public static final String CTR_TAG_ID = "containerTagId";
	//public static final String SEARCH_LOAD = "http://lb-node.cluster1.cloud.s32800.us.wal-mart.com/us-32898/loading/containers/search";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String JSON_PATH_OUTBOUND_DETAILS="$.testFlowData.outboundDetails[*]";

	public void openLoadingAppPage() {
		logger.info("loadingappurl: {}", environment.getProperty("loadingappurl"));
		loadingAppPage.getUrl(environment.getProperty("loadingappurl"));

	}

//	public void handlePopup() {
//		try {
//			loadingAppPage.handleAlertPopup();
//		} catch (NoAlertPresentException e) {
//			throw new AutomationFailure("There was no popup", e);
//		} catch (Exception e) {
//			throw new AutomationFailure("Failed to neutralize the popu", e);
//		}
//		logger.info("popup neutralized");
//
//	}

	public String generateTheLoadId(List<String> cntrList, String door, String trailer) {
		try {
			return loadingAppPage.generateLoadId(cntrList, door, trailer);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the load", e);
		}

	}

	@Step
	public void loadContainers(String loadType) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			String loadId;
			logger.info(tl.get().get(TEST_FLOW_DATA));
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();
			String securementCase = null;

			JSONArray listOfDoors = JsonPath.read(testData, "$.testFlowData.outboundDetails[*].outboundDoorNumber");
			String listOfDoorsString = listOfDoors.toJSONString();
			logger.info("Outbound List : {}", listOfDoorsString);
			List<String> outboundDoorsList = null;
			outboundDoorsList = om.readValue(listOfDoorsString, new TypeReference<List<String>>() {
			});
			Map<String, String> doorLaneMap = aCLDBSteps.getLanesForDoor(outboundDoorsList);

			List outboundListNew = new ArrayList();

			JSONArray listOfLoads1 = JsonPath.read(testData, JSON_PATH_OUTBOUND_DETAILS);
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List : {}", outBoundString);
			List<OutboundDetail> outboundList = null;

			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			if (outboundList.isEmpty())
				throw new AutomationFailure("Outbound List in testflowdata is empty ");
			for (int i = 0; i < outboundList.size(); i++) {

				List cntrList = new ArrayList();
				OutboundDetail obdDetail = outboundList.get(i);
				aCLDBSteps.updateACCLoading(obdDetail.getOutboundDoorNumber());
				logger.info("RDC to securement container mapping {}", invSteps.destContainerMap);
				securementCase = invSteps.destContainerMap.get(obdDetail.getDestNumber());
				String door = obdDetail.getOutboundDoorNumber();
				String trailer = obdDetail.getTrailerNumber();
				String dest = obdDetail.getDestNumber();
				cntrList.add(securementCase);
				openLoadingAppPage();
//				handlePopup();
				if(loadType.equals("securement")) {
				loadId = generateTheLoadId(cntrList, door, trailer);
				}
				else {
				loadId = loadingAppPage.generateLoadWithoutContainers(door,trailer,dest);
				}
				obdDetail.setLoadId(loadId);
				String lane = (String) doorLaneMap.get(obdDetail.getOutboundDoorNumber());
				obdDetail.setLaneNumber(lane);
				outboundListNew.add(obdDetail);
				aCLDBSteps.deleteDestMappingForDoor(door);
				openLoadingAppPage();
//				handlePopup();
				loadingAppPage.scanLoadDoor(door);
				loadingAppPage.divertLaneForDoor();
				logger.info(obdDetail.getDestNumber());
				validateDivertInSorter(door, obdDetail.getDestNumber());
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(outboundListNew);
			context.set("$.testFlowData.outboundDetails",
					JsonPath.parse(om.writeValueAsString(outboundListNew)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating load ID::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while loading the containers", e);
		}
	}

	public void validateDivertInSorter(String door, String destination) {
		Failsafe.with(retryPolicy).run(() -> {
			Assert.assertEquals(ErrorCodes.VALIDATE_DOOR_LANE_DIVERSION, destination,
					aCLDBSteps.getDestinationForDoorDiversion(door));
		});
		logger.info("RDC is mapped with the door in destination mapping table of Sorter");
	}

	public void validateStopDivertInSorter(String door) {
		Failsafe.with(retryPolicy).run(() -> {
			Assert.assertEquals(ErrorCodes.VALIDATE_DOOR_LANE_DIVERSION, 0,
					aCLDBSteps.validateStopDiversionForDoor(door).size());
		});
		logger.info("RDC is now not mapped with the door in destination mapping table of Sorter");
	}

	@Step
	public void stopDivertUnloadSecurementCase(String loadType) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();
			String securementCase = null;

			List outboundListNew = new ArrayList();

			JSONArray listOfLoads1 = JsonPath.read(testData, JSON_PATH_OUTBOUND_DETAILS);
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;

			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			if (outboundList.isEmpty())
				throw new AutomationFailure("Outbound List in testflowdata is empty");
			for (int i = 0; i < outboundList.size(); i++) {

				OutboundDetail obdDetail = outboundList.get(i);
				securementCase = invSteps.destContainerMap.get(obdDetail.getDestNumber());
				List cntrList = new ArrayList();
				String door = obdDetail.getOutboundDoorNumber();
				cntrList.add(securementCase);
				openLoadingAppPage();
//				handlePopup();
				loadingAppPage.scanLoadDoor(door);
				loadingAppPage.stopDivertionForDoor();
				validateStopDivertInSorter(door);
				if(loadType.equals("securement")) {
				loadingAppPage.unloadContainers(cntrList, door);
				}
				Thread.sleep(10000);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while loading the containers", e);
		}

	}

	public void verifyContainerStatus(String status) {
		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();
			String securementCase = null;

			JSONArray listOfLoads1 = JsonPath.read(testData, JSON_PATH_OUTBOUND_DETAILS);
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;

			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			if (outboundList.isEmpty())
				throw new AutomationFailure("Outbound List in testflowdata is empty");
			for (int i = 0; i < outboundList.size(); i++) {
				Response response;
				List loadList = new ArrayList();
				OutboundDetail obdDetail = outboundList.get(i);
				String loadId = obdDetail.getLoadId();
				Load load = new Load();
				load.setLoadId(Integer.parseInt(loadId));
				loadList.add(load);
				SearchContainers cntrs = new SearchContainers();
				cntrs.setLoads(loadList);

				JSONArray listOfLoadedCntrs = JsonPath.read(testData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType=='normal')].parentContainer");
				String listOfLoadedCntrsString = listOfLoadedCntrs.toJSONString();
				logger.info("Containers List {}", listOfLoadedCntrsString);
				List<String> containerList = null;

				containerList = om.readValue(listOfLoadedCntrsString, new TypeReference<List<String>>() {
				});

				logger.info("containers search url :" + environment.getProperty("search_cntrs_api"));
				logger.info("payload :" + om.writeValueAsString(cntrs));
				response = SerenityRest.given().contentType("application/json").body(om.writeValueAsString(cntrs))
						.when().put(environment.getProperty("search_cntrs_api")).andReturn();
				Assert.assertEquals(ErrorCodes.LOADING_INVALID_CONTAINER_STATUS, 200, response.getStatusCode());

				for (int j = 0; j < containerList.size(); j++) {
					JSONArray searchOfLoadedCntrs = JsonPath.read(response.asString(),
							"$.shippingContainerList[?(@.containerTagId==\"" + containerList.get(j)
									+ "\")].containerStatusDesc");
					String listOfLoadedCntrsSearchString = searchOfLoadedCntrs.toJSONString();
					logger.info("Containers List {}", listOfLoadedCntrsSearchString);
					List<String> searchContainerList = null;

					searchContainerList = om.readValue(listOfLoadedCntrsSearchString,
							new TypeReference<List<String>>() {
							});

					Assert.assertEquals(ErrorCodes.LOADING_INVALID_CONTAINER_STATUS, status,
							searchContainerList.get(0).trim());
				}

			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating the container status", e);

		}

	}

	public void loadOverLoadContainer() {
	
		String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONArray dest = JsonPath.read(testFlowData,"$.testFlowData.outboundDetails[*].destNumber");
		logger.info("destination number is " + dest);

			try {

				logger.info(tl.get().get(TEST_FLOW_DATA));
				JSONArray listOfDoors = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*].outboundDoorNumber");
				String listOfDoorsString = (String) listOfDoors.get(0);
				logger.info("Outbound List {}", listOfDoorsString);
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				final String container = "ACL" + timestamp.getTime();
				//invSteps.containerCreationLoading(dest, typeOfCntr);
				logger.info(container+  " is the container");
				ymsHelper.publishCreationOfContainerMessage(dest.get(0).toString(), container);
				logger.info("published container creation message in inventory for dest " + dest.get(0));
				loadingAppPage.scanContainer(container);
			    loadingAppPage.scanDoorForLoadingOvershoot(listOfDoorsString);
				loadingAppPage.clickContinueBtn();
				loadingAppPage.verifyTrailerIsOverWeight();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	public void verifySorterTableStopDiversion(){
		
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info(tl.get().get(TEST_FLOW_DATA));

		JSONArray listOfDoors = JsonPath.read(testData, "$.testFlowData.outboundDetails[*].outboundDoorNumber");
		String listOfDoorsString = (String) listOfDoors.get(0);
		logger.info("Outbound List {}", listOfDoorsString);
		
		validateStopDivertInSorter(listOfDoorsString);		
	}

	public void verifyStopDivertInSorter() {

		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(tl.get().get(TEST_FLOW_DATA));
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();

			JSONArray listOfDoors = JsonPath.read(testData, "$.testFlowData.outboundDetails[*].outboundDoorNumber");
			String listOfDoorsString = listOfDoors.toJSONString();
			logger.info("Outbound List {}", listOfDoorsString);
			List<String> outboundDoorsList = null;
			outboundDoorsList = om.readValue(listOfDoorsString, new TypeReference<List<String>>() {
			});

			List outboundListNew = new ArrayList();

			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*]");
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;

			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			if (outboundList.isEmpty())
				throw new AutomationFailure("Outbound List in testflowdata is empty");
//
//				List cntrList = new ArrayList();
//				aCLDBSteps.updateACCLoading(obdDetail.getOutboundDoorNumber());
//				logger.info("RDC to securement container mapping" + invSteps.destContainerMap);
//				
//				String door = obdDetail.getOutboundDoorNumber();
//				validateDivertInSorter(door, obdDetail.getDestNumber());
} catch(Exception e) {
	
}
	}
	
	public void verifyContainerStatusThroughAPI(String status) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();
			String securementCase = null;

			JSONArray listOfLoads1 = JsonPath.read(testData, JSON_PATH_OUTBOUND_DETAILS);
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<OutboundDetail> outboundList = null;

			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			if (outboundList.isEmpty())
				throw new AutomationFailure("Outbound List in testflowdata is empty");
			for (int i = 0; i < outboundList.size(); i++) {
				Response response;
//				List loadList = new ArrayList();
//				OutboundDetail obdDetail = outboundList.get(i);
//				String loadId = obdDetail.getLoadId();
//				Load load = new Load();
//				load.setLoadId(Integer.parseInt(loadId));
//				loadList.add(load);
//				SearchContainers cntrs = new SearchContainers();
//				cntrs.setLoads(loadList);
				
				JSONArray loadList = new JSONArray();
				loadList.add(Integer.parseInt(outboundList.get(i).getLoadId()));

				JSONObject loadObj = new JSONObject();
				loadObj.put("loadIds", loadList);

//				JSONArray listOfLoadedCntrs = JsonPath.read(testData,
//						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType=='normal')].parentContainer");
				JSONArray listOfLoadedCntrs = JsonPath.read(testData,
						"$..outboundDetails[*].containerIds[*]");
				
				String listOfLoadedCntrsString = listOfLoadedCntrs.toJSONString();
				logger.info("Containers List {}", listOfLoadedCntrsString);
				List<String> containerList = null;

				containerList = om.readValue(listOfLoadedCntrsString, new TypeReference<List<String>>() {
				});

				logger.info("containers search url :" + environment.getProperty("search_cntrs_api"));
				logger.info("payload :" + loadObj.toString());
				
				response = SerenityRest.given().relaxedHTTPSValidation().contentType("application/json").headers(loadingHelper.getloadingHeaders()).body(loadObj.toString())
						.when().post(environment.getProperty("search_cntrs_api"));
				Assert.assertEquals(ErrorCodes.LOADING_INVALID_CONTAINER_STATUS, 200, response.getStatusCode());
				logger.info(response.asString());
				
				for (int j = 0; j < containerList.size(); j++) {
					logger.info(containerList.get(j));
//					JSONArray searchOfLoadedCntrs = JsonPath.read(response.asString(),
//							"$.shippingContainerList[?(@.containerTagId==\"" + containerList.get(j)
//									+ "\")].containerStatusDesc");
					JSONArray searchOfLoadedCntrs = JsonPath.read(response.asString(),
							"$.containers[?(@.containerTagId=='"+containerList.get(j)+"')].containerStatusDesc");
					String listOfLoadedCntrsSearchString = searchOfLoadedCntrs.toJSONString();
					logger.info("Containers List {}", listOfLoadedCntrsSearchString);
					List<String> searchContainerList = null;

					searchContainerList = om.readValue(listOfLoadedCntrsSearchString,
							new TypeReference<List<String>>() {
							});

					Assert.assertEquals(ErrorCodes.LOADING_INVALID_CONTAINER_STATUS, status.toLowerCase(),
							searchContainerList.get(0).trim().toLowerCase());
				}

			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating the container status", e);

		}

	}
}

