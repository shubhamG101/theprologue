package com.walmart.supplychain.nextgen.idm.steps.webservices;

import com.walmart.supplychain.witron.myapps.pages.MyAppsLoginPage;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class MyAppsSteps extends ScenarioSteps {

    @Autowired
    MyAppsLoginPage myAppsLoginPage;

    @Autowired
    Environment environment;

    @Autowired
    Environment endpoint;

    Logger logger = LogManager.getLogger(this.getClass());

    public void launchMyApps() {
        logger.info("Launching MyApps url " + environment.getProperty("my_apps_url"));
        myAppsLoginPage.getUrl(endpoint.getProperty("unified_UI_URL"));

        myAppsLoginPage.LoginToMyApps(environment.getProperty("nextGenUserName"),
                environment.getProperty("nextGen"), environment.getProperty("source_number"));
    }

    public void launchInventoryUsingMyApps() {
        logger.info("Launching inventory URL " + environment.getProperty("inventory_URL"));
        myAppsLoginPage.getUrl(environment.getProperty("inventory_URL"));
        myAppsLoginPage.LoginToMyApps(environment.getProperty("nextGenUserName"), environment.getProperty("nextGen"), environment.getProperty("source_number"));
    }
}
