package com.walmart.supplychain.nextgen.oms.gluecode.webservices;

public class DestOrderCharacteristics {
    private String orderLinePercentage, destination, source;
    private String poPercentage;

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getOrderLinePercentage() {
        return orderLinePercentage;
    }

    public void setOrderLinePercentage(String orderLinePercentage) {
        this.orderLinePercentage = orderLinePercentage;
    }


    public String getPoPercentage() {
        return poPercentage;
    }

    public void setPoPercentage(String poPercentage) {
        this.poPercentage = poPercentage;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
