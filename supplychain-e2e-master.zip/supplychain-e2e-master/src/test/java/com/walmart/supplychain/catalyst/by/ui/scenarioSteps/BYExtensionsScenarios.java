package com.walmart.supplychain.catalyst.by.ui.scenarioSteps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.jcraft.jsch.Logger;
import com.walmart.supplychain.catalyst.by.ui.steps.BYExtensionsSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYOutboundSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYReceivingSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.catalyst.by.webservices.steps.BYWebservicesSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class BYExtensionsScenarios {

	@Steps
	BYOutboundSteps byOutboundSteps;

	@Steps
	BYExtensionsSteps byExtensionsSteps;

	@Steps
	BYReceivingSteps byReceivingSteps;

	@Steps
	BYWebservicesSteps byWebServicesSteps;

	@Autowired
	BYUiHelper byUiHelper;

	@Then("^user updates the HACCP temperature in BY Web UI$")
	public void user_updates_the_haccp_temperature_in_by_web_ui() throws Throwable {

		byUiHelper.navigateToMentionedMenu("EXTENSIONS");
		byUiHelper.navigateToMentionedTab("QC Dashboard");
		byExtensionsSteps.performHACCP();
		byExtensionsSteps.changeInvStatusToAvailable();

	}

}
