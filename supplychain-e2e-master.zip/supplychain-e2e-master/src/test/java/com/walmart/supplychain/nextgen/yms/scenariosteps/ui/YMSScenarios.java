package com.walmart.supplychain.nextgen.yms.scenariosteps.ui;

import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSSteps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class YMSScenarios {

	@Autowired
	SpringJmsUtils springJmsUtils;

	@Steps
	YMSSteps ymsSteps;

/*	@When("^user does GateIn for the delivery in YMS$")
	public void user_does_GateIn_for_the_delivery_in_YMS() {
		ymsSteps.open_YMS_home_page();
		ymsSteps.login_to_YMS();
		ymsSteps.click_on_GateManagement();
		ymsSteps.click_on_GateInOrOut();
		ymsSteps.perform_DeliveryGateIn();
	}
*/
	@When("^user assigns \"([^\"]*)\" door to the trailer in YMS UI$")
	public void user_assigns_door_to_the_trailer_in_YMS(String dockView) {
		ymsSteps.open_YMS_home_page();
		ymsSteps.login_to_YMS();
		if(dockView.equalsIgnoreCase("Inbound")) {
			ymsSteps.click_on_GateManagement();
			ymsSteps.click_on_GateInOrOut();
			ymsSteps.perform_DeliveryGateIn();
		}
		ymsSteps.click_on_DockManagement();
		ymsSteps.click_on_DockManager();
		ymsSteps.select_filter_criteria_for_door(dockView);
		ymsSteps.get_Open_DoorsInRange(dockView);
		ymsSteps.click_on_Manual_Move();
		ymsSteps.create_Manual_Move(dockView);
		ymsSteps.click_on_Yard_ManagementLink();
		ymsSteps.click_on_Yard_Management_Move_Queue();
		ymsSteps.force_Move_from_YDMQ(dockView);
		ymsSteps.logOut();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		ymsSteps.open_YMS_Driver_home_page();
		ymsSteps.login_to_driverUI();
		ymsSteps.acceptTheTrailer(dockView);
		ymsSteps.logout_YMS_Driver();
	}

	@Then("^user does GateIn for the trailer in YMS$")
	public void user_does_GateIn_for_the_trailer_in_YMS_new_trailer() {
		ymsSteps.open_YMS_home_page();
		ymsSteps.login_to_YMS();
		ymsSteps.click_on_GateManagement();
		ymsSteps.click_on_GateInOrOut();
		ymsSteps.perform_TrailerGateIn();
	}

	@When("^user gates out the Trailer from YMS UI$")
	public void user_gates_out_the_Trailer_from_YMS() {
		ymsSteps.open_YMS_home_page();
		ymsSteps.login_to_YMS();
		ymsSteps.click_on_DockManagement();
		ymsSteps.click_on_outbound();
		ymsSteps.click_on_outbound_trailer_move();
		ymsSteps.enter_Trailer_details();
		ymsSteps.perform_outbound_move();
//		ymsSteps.click_on_Yard_ManagementLink();
//		ymsSteps.click_on_TrailerEdit();
//		ymsSteps.retrive_Trailer_details();
//		ymsSteps.update_Trailer_details();
		ymsSteps.click_on_GateManagement();
		ymsSteps.click_on_GateInOrOut();
		ymsSteps.perform_TrailerGateOut();
//		ymsSteps.perform_TrailerGateOut_jms();
//		ymsSteps.perform_TrailerDoorAssign_jms("Outbound");  //jms way of doing
		
	}

	@Then("^user verifies the door is free in YMS$")
	public void user_verifies_the_door_is_free_in_YMS() {
		ymsSteps.verify_status_of_door();
	}
	@When("^user assigns \"([^\"]*)\" door to the trailer in YMS$")
	public void user_assigns_door_to_the_trailer_in_YMS_using_jms(String dockView) {
		//test spring jdbc
		ymsSteps.perform_TrailerDoorAssign_jms(dockView);
	}
	@When("^user assigns pure offline \"([^\"]*)\" door to the trailer in YMS$")
	public void user_assigns_pure_offline_door_to_the_trailer_in_YMS_using_jms(String dockView) {
		System.setProperty("pureOfflineDoor", "true");
		ymsSteps.perform_TrailerDoorAssign_jms(dockView);
		System.setProperty("pureOfflineDoor", "false");
		System.setProperty("doorAlreadyAssigned", "true");
	}

	@When("^user assigns offline \"([^\"]*)\" door to the trailer in YMS$")
	public void user_assigns_offline_door_to_the_trailer_in_YMS_using_jms(String dockView) {
		System.setProperty("offlineDoor", "true");
		ymsSteps.perform_TrailerDoorAssign_jms(dockView);
		System.setProperty("offlineDoor", "false");
		System.setProperty("doorAlreadyAssigned", "true");
	}
	@When("^user gates out the Trailer from YMS$")
	public void user_gates_out_the_Trailer_from_YMS_using_jms() {
		ymsSteps.perform_TrailerGateOut_jms();
	}
	
	@Then("^user gateIn the delivery for RDC$")
	public void user_gatesIn_delivery() {
		ymsSteps.perform_TrailerDoorAssignRDC_jms();
	}
	
	@Then("^user publish receiving receipts for \"([^\"]*)\" labels$")
	public void user_publish_receiving_receipts(String labelCout) {
		ymsSteps.publish_ReceivingReceipts_RDC_jms(labelCout);
	}
	
	@Then("^user performs \"([^\"]*)\" Trailer Check In in YMS$")
	public void trailerCheckInCatalyst(String freightType) {
		 ymsSteps.trailerCheckIn(freightType);	
			
	}
	
	@Then("^user assigns \"([^\"]*)\" door to the trailer in YMS for Catalyst$")
	public void doorAssign(String freightType) {
		 ymsSteps.doorAssign(freightType);	
			
	}
	@Then("^user performs \"([^\"]*)\" Trailer Gate Out in YMS$")
	public void trailerGateOut(String freightType) {
		 ymsSteps.trailerGateOUT(freightType);	
			
	}
	
	@Then("^user performs \"([^\"]*)\" Trailer Move from Virtual Door to Yard Zone$")
    public void userPerformsTrailerBumpMoveFromVirtualDoorToYard(String freightType) throws Throwable {
		ymsSteps.trailerBumpMove(freightType);
    }
	

}
