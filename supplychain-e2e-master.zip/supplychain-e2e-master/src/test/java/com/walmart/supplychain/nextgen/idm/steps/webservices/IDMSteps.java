package com.walmart.supplychain.nextgen.idm.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import com.walmart.supplychain.nextgen.receiving.pages.mobile.ReceivingPage;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.witron.myapps.pages.MyAppsLoginPage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.yms.YmsGateOut;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.idm.pages.ui.IDMHomePage;
import com.walmart.supplychain.nextgen.idm.pages.ui.IDMLoginPage;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingSteps;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class IDMSteps extends ScenarioSteps {

	private static final long serialVersionUID = 1L;

	@Autowired(required = true)
	IDMHelper idmHelper;

	@Autowired
	YMSHelper ymsHelper;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	IDMLoginPage idmLoginPage;

	@Autowired
	IDMHomePage idmHomePage;

	@Autowired
	JsonUtils jsonUtil;
	
	@Steps
	ReceivingSteps ReceivingSteps;

	@Autowired
	ReceivingPage receivingPage;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	MyAppsLoginPage MyAppsLoginPage;

	private static final Logger LOGGER = LogManager.getLogger(IDMSteps.class);
	private Response response;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(10, 15);// 15 times with a delay of 10s
	int totalPoReceivedQtyInIDMReceiptForPO = 0;
	static final String RECEIVED_QTY_JSON_PATH = "$.pos..[?(@.poNumber=='#0#')].receivedQty";
	static final String PO_NUMBERS_JSON_PATH = "$.testFlowData.deliveryDetails[*].poNumbers[*]";
	static final String TEST_FLOW_DATA_KEY = "testFlowData";
	private static final String IDM_DELIVERY_EP = "idm_delivery_ep";
	private static final String DELIVERY_STATUS_PATH = "deliveryStatus";
	private static final String VENDORUPC_STATUS_PATH = "$..vendorUPC";
	private static final String CASEUPC_STATUS_PATH = "$..caseUPC";
	private static final String ITEM_NUMBER_JSONPATH = "$..poLineDetails[*].itemNumber";

	private static final String DELIVERY_DOOR_PATH = "doorNumber";
	private static final String STATUS_PND_FNL = "PNDFNL";
	private static final String STATUS_PND_PT = "PNDPT";
	private static final String STATUS_FNL = "FNL";
	private static final String IDM_DELIVERY_SEARCH_POST_EP = "gdm_delivery_url_post_ep";
	public static final int SUCESS_STATUS_CODE = 200;
	private static final String NEXTGEN_USER_NAME = "nextGenUserName";
	private static final String FACILITY_NUM = "facility_num";
	private static final String GDM_UI_URL = "gdm_ui_url";
	private static final String DELIVERY_JSON_PATH = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private DocumentContext parsedJson;

	private static final String DEL_STATUS = "ARV";
	int poNumberIndex = 0;
	private static final String GET_PO_NUMBER_FROM_NAME = "$..poDetails[?(@.poName=='#0#')].poNumber";
	int count = 0;
	private static final String WTMS_LOAD_EP = "wtms_load_ep";
	private static final String INBOUND_LOAD_NUMBER_JSON_PATH = "$..deliveryDetails[*].inboundLoadNumber";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String TRACKING_ID_JSON_PATH = "$..trackingId";
	private List<String> trackingId = new ArrayList<String>();
	ObjectMapper objectMapper = new ObjectMapper();

	public void createDelivery(int qtyPercentage, String status, String deliveryName) {
		createDelivery(qtyPercentage, status, deliveryName, null);
	}
	
	@Step
	public void createDeliveryRDC(int qtyPercentage, String status, String deliveryName, String loadNumber, String deliveryForRDCReceivingType) {
		try {
			if (Config.DC == DC_TYPE.RDC || Config.DC == DC_TYPE.MCC_RDC || Config.DC == DC_TYPE.ATLAS_RDC || Config.DC == DC_TYPE.ACC_RDC) {
				idmHelper.createDeliveryScheduler2RDC(qtyPercentage, status, deliveryName,loadNumber,null, deliveryForRDCReceivingType);
			}
		} catch (FailsafeException e) {
			LOGGER.info("Failed in Creating a Delivery in IDM with error:{}", e);
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the delivery", e);
		}
	}

	
	@Step
	public void createDelivery(int qtyPercentage, String status, String deliveryName, String loadNumber) {

		try {
			if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS||Config.DC == DC_TYPE.ATLAS||Config.DC == DC_TYPE.ACC||Config.DC == DC_TYPE.CATALYST || Config.DC == DC_TYPE.RDC) {
				idmHelper.createDeliveryScheduler2(qtyPercentage, status, deliveryName,loadNumber);
			} else {

				idmHelper.createDeliveryMCC(qtyPercentage, status, deliveryName, loadNumber);
				count = 0;
				Failsafe.with(retryPolicy).run(() -> {
					count++;
					response = getDeliveryResponse(deliveryName);
					LOGGER.info("Waiting for Delivery to get created");
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					LOGGER.info("Delivery Response :: " + response.asString());
					LOGGER.info("validating the delivery");
					idmHelper.validateDelivery(response);
				});

			}

		} catch (FailsafeException e) {
			LOGGER.info("Failed in Creating a Delivery in IDM with error:{}", e);
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the delivery", e);
		}

	}
	
	@Step
	public void createDeliveryForPharmcy(int qtyPercentage, String status, String deliveryName, String loadNumber, String deliveryNumber) {

		try {
			try {
				idmHelper.preRunCleanup.cleanUpGDMForPharmacy(deliveryNumber);
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while deleting the delivery", e);
			}
			idmHelper.createDeliveryScheduler2(qtyPercentage, status, deliveryName,loadNumber,deliveryNumber);

		} catch (FailsafeException e) {
			LOGGER.info("Failed in Creating a Delivery in IDM with error:{}", e);
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the delivery", e);
		}

	}
	
	@Step
	public void createDeliveryForPharmcyWithDummyLoadNumber(int qtyPercentage, String status, String deliveryName, String deliveryNumber) {

		try {
			try {
				idmHelper.preRunCleanup.cleanUpGDMForPharmacy(deliveryNumber);
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while deleting the delivery", e);
			}
			idmHelper.createDeliveryScheduler2(qtyPercentage, status, deliveryName,"11223344",deliveryNumber);
		} catch (FailsafeException e) {
			LOGGER.info("Failed in Creating a Delivery in IDM with error:{}", e);
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the delivery", e);
		}

	}

	public void createDeliveryRDCForS2S() {
		try {
			idmHelper.createDeliveryRDCS2S();
		} catch (FailsafeException e) {
			LOGGER.info("Failed in Creating a Delivery in IDM with error:{}", e);
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating the delivery", e);
		}
	}

	@Step
	public void search_and_validate_deliveryStatus(String deliveryStatus, String deliveryName) {
		try {
			LOGGER.info("Validating IDM delivery Status Code");
			Thread.sleep(2000);
			Failsafe.with(retryPolicy).run(() -> {
				response = getDeliveryResponse(deliveryName);
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				LOGGER.info("Validating IDM Status is changed to: " + deliveryStatus);

				String actualDeliveryStatus = JsonPath.read(response.asString(), DELIVERY_STATUS_PATH);
				String doorNumber = idmHelper.getDoorNumber();
				LOGGER.info("doorNumber {} : " + doorNumber);

				if (Config.isParallel && (actualDeliveryStatus.equals(STATUS_FNL)
						|| actualDeliveryStatus.equals(STATUS_PND_FNL) || actualDeliveryStatus.equals(STATUS_PND_PT))) {
					LOGGER.info("Removing door {} from occupied door list", doorNumber);
					boolean removalStatus = ymsHelper.getInboundOccupiedDoorsList().remove(doorNumber);
					if (removalStatus) {
						LOGGER.info("Removed door Number {} from the inbound door list", doorNumber);
						ymsHelper.getInboundOccupiedDoorsList().notify();
					}

				}
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_STATUS_NOT_UPDATED, deliveryStatus, actualDeliveryStatus);
				
			});
			LOGGER.info("Validating the overrage quantity in IDM delivery for all items ");
			if (Config.DC != DC_TYPE.WITRON && Config.DC != DC_TYPE.PHARMACY&&Config.DC != DC_TYPE.RDC)
				idmHelper.validateoverrage();
			else if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.RDC) {
				String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
				DocumentContext context = null;
				JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
				String poString = listOfPO.toJSONString();
				List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
				});
				
				List<PoDetail> newPOList = new ArrayList<PoDetail>();
				for (PoDetail poDetail : poList) {
					List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
					List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
					for (PoLineDetail poLineDetail : poLineList) {
						String lineNumber = poLineDetail.getPoLineNumber();
						response=getDeliveryResponseWitron(deliveryName,lineNumber);
						DocumentContext parsedtestflowJson = JsonPath.parse(response.asString());
						List<Integer> overageList = parsedtestflowJson
								.read("$.deliveryDocuments[*].deliveryDocumentLines[?(@.purchaseReferenceLineNumber=="
										+ lineNumber + ")].overageQtyLimit");
						LOGGER.info("Delivery Response =  {} ", response.asString());
						LOGGER.info("Delivery Response path  =  {} ", "$.deliveryDocuments[*].deliveryDocumentLines[?(@.purchaseReferenceLineNumber=="
								+ lineNumber + ")].overageQtyLimit");
						
						LOGGER.info("overage value  =  {} ",overageList.get(0) );
						
						
						Assert.assertTrue(ErrorCodes.WITRON_GDM_OVG_VALIDATION_FAILED, overageList.size()!=0);

						
//						Assert.assertNotEquals(ErrorCodes.WITRON_GDM_OVG_VALIDATION_FAILED, 0, Integer.parseInt(overageList.get(0)));
						poLineDetail.setOvgQty(String.valueOf(overageList.get(0)));
						newpoLineList.add(poLineDetail);
					}
					poDetail.setPoLineDetails(newpoLineList);
					newPOList.add(poDetail);
				}
				JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
				context = JsonPath.parse(parser.parse(testFlowData));
				context.set("$.testFlowData.poDetails",
						JsonPath.parse(objectMapper.writeValueAsString(newPOList)).read("$", JSONArray.class));
				String str = context.jsonString();
				threadLocal.get().put("testFlowData", str);
			}

			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			LOGGER.info(testFlowData);
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating delivery status", e);
		}

	}

	@Step
	public void validate_deliveryStatus_in_Unified_UI(String deliveryStatus, String delvryName) throws Exception {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		JSONArray delNum = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");
		String deliveryNbr = delNum.get(0).toString();
		String actualDeliveryStatus = idmHomePage.getDeliveryStatusInGDM(deliveryNbr);
		String doorNumber = idmHelper.getDoorNumber();
		LOGGER.info("doorNumber {} : " + doorNumber);
		if (actualDeliveryStatus.equals("Finalized")
				|| actualDeliveryStatus.equals(STATUS_PND_FNL) || actualDeliveryStatus.equals(STATUS_PND_PT)) {
			LOGGER.info("Removing door {} from occupied door list", doorNumber);
			String removalStatus = idmHomePage.checkDoorDetached(deliveryNbr);
			LOGGER.info("Validate door removal after delivery finalize " + removalStatus);

			if (removalStatus.equalsIgnoreCase("")) {
				LOGGER.info("Removed door Number {} from the inbound door list", doorNumber);
			}
			idmHomePage.closeDriver();
		}
		Assert.assertEquals(ErrorCodes.IDM_DELIVERY_STATUS_NOT_UPDATED, deliveryStatus, actualDeliveryStatus);
		LOGGER.info("Validated delivery Status In Unified UI for delivery number " + deliveryNbr);
	}
	
	@Step
	public void validatePOTypeForThePOs(String poType, String poNumbers, String deliveryName) {
		try {
			String[] poTypeList = poType.split(",");
			String[] poNumbersList = poNumbers.split(",");
			assertEquals("Invalid input data in the feature", poTypeList.length, poNumbersList.length);

			for (String poNum : poNumbersList) {
				Failsafe.with(retryPolicy).run(() -> {
					response = getDeliveryResponse(deliveryName);
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					LOGGER.info("Validating POtype for the PO : {}", poNum);

					List<String> actualPOType = JsonPath.read(response.asString(),
							"$.deliveryDocuments[*].deliveryDocumentLines[?(@.purchaseReferenceNumber=='" + poNum
									+ "')].purchaseRefType");
					Assert.assertEquals(ErrorCodes.IDM_POTYPE_MISMATCH, poTypeList[poNumberIndex], actualPOType.get(0));
					LOGGER.info("Validated POtype for the PO : {}", poNum);
				});
				if (!poTypeList[poNumberIndex].equalsIgnoreCase("DSDC")) {
					String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
					String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, poTypeList[poNumberIndex],
							"$..poDetails[?(@.poNumber=='" + poNum + "')].channelMethod");
					threadLocal.get().put("testFlowData", testFlowData_updated);
				}
				poNumberIndex = poNumberIndex + 1;
			}

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating POtype for the PO", e);
		}

	}

	@Step
	public void validatePalletCountForThePOs(String deliveryName) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> poNumbersList = JsonPath.read(testFlowData, PO_NUMBERS_JSON_PATH);

			for (String poNum : poNumbersList) {
				Failsafe.with(retryPolicy).run(() -> {
					LOGGER.info("Validating pallet count for the PO : {}", poNum);
					Response loadresponse = getLoadResponse();
					List<Integer> expectedPalletCount = JsonPath.read(loadresponse.asString(),
							"$.orders[?(@.poNumber=='" + poNum + "')].pallets");

					response = getDeliveryResponse(deliveryName);
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					List<Integer> actualPalletCount = JsonPath.read(response.asString(),
							"$.deliveryDocuments[?(@.purchaseReferenceNumber=='" + poNum + "')].palletQty");

					//stg-int is pointing to prod hence disabling once moved to mock we can enable
//					Assert.assertEquals(ErrorCodes.IDM_PALLETCOUNT_MISMATCH, expectedPalletCount.get(0),
//							actualPalletCount.get(0));
					LOGGER.info("Validated Pallet count for the PO : {}", poNum);
				});
			}
			poNumberIndex = poNumberIndex + 1;

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating pallet qty for the PO ", e);
		}

	}

	@Step
	public void search_and_validate_deliveryStatus_RDC(String deliveryStatus) {
		try {
			LOGGER.info("Validating IDM delivery Status Code");
			JSONArray deliveryDetails = idmHelper.getRDCDelieveries();

			IntStream.range(0, deliveryDetails.size()).forEach(delNr -> {
				String deliveryNumber = (String) deliveryDetails.get(delNr);
				Failsafe.with(retryPolicy).run(() -> {
					response = when().get(environment.getProperty("rdc_idm_delivery_ep") + deliveryNumber);
					Assert.assertEquals(ErrorCodes.IDM_RDC_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					LOGGER.info("Validating IDM Status is changed to: " + deliveryStatus);
					String actualDeliveryStatus = JsonPath.read(response.asString(), DELIVERY_STATUS_PATH);
					Assert.assertEquals(ErrorCodes.IDM_RDC_DELIVERY_STATUS_NOT_UPDATED, deliveryStatus,
							actualDeliveryStatus);
				});

			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating RDC delivery status", e);
		}
	}

	@Step
	public void search_and_validate_deliveryStatusAndDoorNumber(String deliveryStatus, String deliveryName) {
		try {
			LOGGER.info("Validating IDM delivery Status Code");
			String doorNumber = idmHelper.getDoorNumber();
			Failsafe.with(retryPolicy).run(() -> {
				response = getDeliveryResponse(deliveryName);
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				LOGGER.info("Validating IDM Status is changed to: " + deliveryStatus);
				String actualDeliveryStatus = JsonPath.read(response.asString(), DELIVERY_STATUS_PATH);
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_STATUS_NOT_UPDATED, deliveryStatus, actualDeliveryStatus);

				response.then().body(DELIVERY_STATUS_PATH, is(deliveryStatus));
				if (!doorNumber.equals("")) {
					LOGGER.info("Validating Door number is changed to:{} " + doorNumber);
					String actualDoorNumber = JsonPath.read(response.asString(), DELIVERY_DOOR_PATH);
					Assert.assertEquals(ErrorCodes.IDM_DOOR_NUMBER_NOT_UPDATED, doorNumber, actualDoorNumber);
					LOGGER.info("Succesfully validated the Inbound door Number");
				}
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating delivery", e);
		}

	}

	@Step
	public void searchAndValidateIDMForDeliveryReceipt() {
		try {

			Failsafe.with(retryPolicy).run(() -> {
				String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
				List<String> poNumbers = JsonPath.read(testFlowData, PO_NUMBERS_JSON_PATH);
				for (String poNumber : poNumbers) {
					int receivedQtyFromTestFlowData = idmHelper.getDeliveryTotalReceivedQty(poNumber);
					Response res = validateReceivedQuantity(poNumber, receivedQtyFromTestFlowData);
					validateShortDamageRejectDelvryRcpt(res, poNumber);
				}
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipt", e);
		}

	}
	
	@Step
	public void validateIDMForDeliveryReceiptForReceivedDamageAndOverageQty() {
		try {
			LOGGER.info("Validating IDM receipts for Received, Overage and Damage qty");
			Failsafe.with(retryPolicy).run(() -> {
				String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
				List<String> poNumbers = JsonPath.read(testFlowData, PO_NUMBERS_JSON_PATH);
				for (String poNumber : poNumbers) {
					int receivedQtyFromTestFlowData = idmHelper.getDeliveryTotalReceivedQty(poNumber);
					Response res = validateReceivedQuantity(poNumber, receivedQtyFromTestFlowData);
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DAMAGE_MISMATCH, true,
							idmHelper.validateDamage(response));
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_OVERAGE_MISMATCH, true,
							idmHelper.validateOverage(receivedQtyFromTestFlowData, response));
				}
			});
			LOGGER.info("Validated IDM receipts for Received, Overage and Damage qty");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipts for Overages and Damages", e);
		}
	}
	
	@Step
	public Response validateReceivedQuantity(String poNumber, int receivedQtyFromTestFlowData) {

		try {
			LOGGER.info("Total received quantity in TestFlowData for po {} is {}", poNumber,
					receivedQtyFromTestFlowData);
			Failsafe.with(retryPolicy).run(() -> {
				LOGGER.info("Waiting IDM Receipts for Status Code :{} ", Constants.SUCESS_STATUS_CODE);
				// if(Config.DC==DC_TYPE.ATLAS) {
				LOGGER.info("IDM Receipts end point ::{},", MessageFormat
						.format(environment.getProperty("gdm_delivery_receipts_ep"), idmHelper.getDeliveryNumber()));
				response = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
						.get(MessageFormat.format(environment.getProperty("gdm_delivery_receipts_ep"),
								idmHelper.getDeliveryNumber()));

				LOGGER.info("response " + response.asString());
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_RECEIPT_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				totalPoReceivedQtyInIDMReceiptForPO = 0;
				JSONArray recievedPoQuantities = JsonPath.parse(response.getBody().asString())
						.read(javaUtils.format(RECEIVED_QTY_JSON_PATH, poNumber));
				for (int qtyIndex = 0; qtyIndex < recievedPoQuantities.size(); qtyIndex++) {
					totalPoReceivedQtyInIDMReceiptForPO += (int) recievedPoQuantities.get(qtyIndex);
				}

				LOGGER.info("Total received quantity in Receipts for po {} is {}", poNumber,
						totalPoReceivedQtyInIDMReceiptForPO);
				Assert.assertEquals(ErrorCodes.IDM_RECEIPT_QTY_NOT_MATCHING, receivedQtyFromTestFlowData,
						totalPoReceivedQtyInIDMReceiptForPO);
			});
			return response;

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipt qty", e);
		}

	}

	public void validateShortDamageRejectDelvryRcpt(Response res, String poNumber) {

		try {

			if (Config.DC == DC_TYPE.WITRON) {
				String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

				parsedJson = JsonPath.parse(testFlowData);
				List<String> poNumberList = new ArrayList<String>();
				List<String> poVnpkQty = new ArrayList<String>();
				List<String> shortQty = new ArrayList<String>();
				List<String> damageQty = new ArrayList<String>();
				List<String> rejectQty = new ArrayList<String>();

				poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

				for (String poNum : poNumberList) {

					LOGGER.info("PO " + poNum);

					poVnpkQty = parsedJson.read(
							"$.testFlowData.poDetails[?(@.poNumber == '" + poNum + "')].poLineDetails[*].poVnpkQty");

					shortQty = parsedJson.read(
							"$.testFlowData.poDetails[?(@.poNumber == '" + poNum + "')].poLineDetails[*].shortQty");
					damageQty = parsedJson.read(
							"$.testFlowData.poDetails[?(@.poNumber == '" + poNum + "')].poLineDetails[*].damageQty");

					rejectQty = parsedJson.read(
							"$.testFlowData.poDetails[?(@.poNumber == '" + poNum + "')].poLineDetails[*].rejectQty");

				}

				LOGGER.info("Size of povnpk " + poVnpkQty.size());

				int fbq = 0;
				int shrt = 0;
				int dmg = 0;
				int rjct = 0;

				for (int i = 0; i < poVnpkQty.size(); i++) {

					fbq = fbq + Integer.parseInt(poVnpkQty.get(i).toString());
					shrt = shrt + Integer.parseInt(shortQty.get(i).toString());
					dmg = shrt + Integer.parseInt(damageQty.get(i).toString());
					rjct = shrt + Integer.parseInt(rejectQty.get(i).toString());

				}

				JSONArray fbqQTY = JsonPath.parse(response.getBody().asString())
						.read(javaUtils.format("$.pos..[?(@.poNumber=='#0#')].fbQty", poNumber));

				JSONArray rejectQtys = JsonPath.parse(response.getBody().asString())
						.read(javaUtils.format("$.pos..[?(@.poNumber=='#0#')].polines[*].rejectQty", poNumber));
				JSONArray shortQtys = JsonPath.parse(response.getBody().asString())
						.read(javaUtils.format("$.pos..[?(@.poNumber=='#0#')].polines[*].shortQty", poNumber));

				JSONArray damageQtys = JsonPath.parse(response.getBody().asString())
						.read(javaUtils.format("$.pos..[?(@.poNumber=='#0#')].polines[*].damageQty", poNumber));

				int shrtFromRcpt = 0;
				int dmgFromRcpt = 0;
				int rjctFromRcpt = 0;

				for (int i = 0; i < rejectQtys.size(); i++) {
					shrtFromRcpt = shrtFromRcpt + Integer.parseInt(shortQtys.get(i).toString());
					dmgFromRcpt = dmgFromRcpt + Integer.parseInt(damageQtys.get(i).toString());
					rjctFromRcpt = rjctFromRcpt + Integer.parseInt(rejectQtys.get(i).toString());

				}

				LOGGER.info("receipt FBQ validation successfully " + fbq + fbqQTY.get(0));

				Assert.assertEquals(ErrorCodes.GDM_FBQ_QTY_NOT_MATCHING, fbq, fbqQTY.get(0));

				LOGGER.info("receipt SHORT validation successfully " + shrt, shrtFromRcpt);

				Assert.assertEquals(ErrorCodes.GDM_SHORT_QTY_NOT_MATCHING, shrt, shrtFromRcpt);

				LOGGER.info("receipt DAMAGE validation successfully " + dmg, dmgFromRcpt);

				Assert.assertEquals(ErrorCodes.GDM_DAMAGE_QTY_NOT_MATCHING, dmg, dmgFromRcpt);

				LOGGER.info("receipt REJECT validation successfully " + rjct, rjctFromRcpt);

				Assert.assertEquals(ErrorCodes.GDM_REJECT_QTY_NOT_MATCHING, rjct, rjctFromRcpt);

			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipt qty", e);
		}

	}

	@Step
	public void validateCtrsRDCDelivery() {
		try {
			LOGGER.info("Validating Container details on the delivery");
			JSONArray deliveryDetails = idmHelper.getRDCDelieveries();

			IntStream.range(0, deliveryDetails.size()).forEach(delNr -> {
				String deliveryNumber = (String) deliveryDetails.get(delNr);
				Failsafe.with(retryPolicy).run(() -> {
					response = when().get(environment.getProperty("rdc_idm_delivery_ep") + deliveryNumber);
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,response.getStatusCode());
					response.then().statusCode(Constants.SUCESS_STATUS_CODE);
				});
				LOGGER.info("Sucess status received from IDM for delivery:{} at RDC", deliveryNumber);
				Assert.assertEquals(ErrorCodes.IDM_RDC_DELIVERY_CONTAINERS_NOT_MATCHED, true,
						idmHelper.validateRDCDeliveries(deliveryNumber, response));
				LOGGER.info("Sucessfully validated the containers present in IDM for delivery:{} at RDC",
						deliveryNumber);
			});
		} catch (AssertionError e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Containers in RDC Delivery", e);
		}

	}

	public Response getDeliveryResponse(String delvryName) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		JSONArray delNum = JsonPath.read(testFlowData,
				"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");
		LOGGER.info("Delivery number " + delNum.get(0));
		Response responseIdm = null;

		if (Config.DC == DC_TYPE.ACC) {
			responseIdm = given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when().get(
					environment.getProperty(IDM_DELIVERY_EP) + delNum.get(0) + "?includeActiveChannelMethods=true");
		} else {
			responseIdm = given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
					.get(environment.getProperty(IDM_DELIVERY_EP) + delNum.get(0));

		}
		return responseIdm;
	}
	
	public Response getDeliveryResponseWitron(String delvryName,String poLineNumner) {
		try {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
				JSONArray delNum = JsonPath.read(testFlowData,
						"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");		
		
			Failsafe.with(retryPolicy).run(() -> {
				response = given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
						.get(environment.getProperty(IDM_DELIVERY_EP) + delNum.get(0));
				DocumentContext parsedtestflowJson = JsonPath.parse(response.asString());

				List<Integer> overageList = parsedtestflowJson
						.read("$.deliveryDocuments[*].deliveryDocumentLines[?(@.purchaseReferenceLineNumber=="
								+ poLineNumner + ")].overageQtyLimit");
				Assert.assertTrue(ErrorCodes.WITRON_PO_NOT_ATTACHED, overageList.size()!=0);
			});

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipt", e);
		}
		
	
		return response;
	}

	@Step
	public void validateIDMForDeliveryReceiptShortage() {

		try {
			Failsafe.with(retryPolicy).run(() -> {
				LOGGER.info("Waiting IDM Receipts for Status Code :{} ", Constants.SUCESS_STATUS_CODE);
				if (Config.DC == DC_TYPE.ATLAS) {
					LOGGER.info("IDM Receipts end point ::{},", MessageFormat.format(
							environment.getProperty("gdm_delivery_receipts_ep"), idmHelper.getDeliveryNumber()));
					response = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
							.get(MessageFormat.format(environment.getProperty("gdm_delivery_receipts_ep"),
									idmHelper.getDeliveryNumber()));
				} else
					response = when()
							.get(environment.getProperty("idm_delivery_receipts_ep") + idmHelper.getDeliveryNumber());
				LOGGER.info("response " + response.asString());
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_RECEIPT_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_SHORTAGE_MISMATCH, true,
						idmHelper.validateShortage(response));
			});

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipt", e);
		}

	}

	public void searchAndValidateIDMForDamageDeliveryReceipt() {

		LOGGER.info("Waiting Damage IDM Receipts for Status Code :{} ", Constants.SUCESS_STATUS_CODE);

		try {
			Failsafe.with(retryPolicy).run(() -> {
				response = when()
						.get(environment.getProperty("idm_delivery_receipts_ep") + idmHelper.getDeliveryNumber());
				LOGGER.info("response " + response.asString());
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_RECEIPT_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());

				DocumentContext parsedJson;
				parsedJson = JsonPath.parse(response.getBody().asString());

				List<Integer> damageQty = parsedJson.read("$..polines[*].damageQty");
				LOGGER.info("Damage qty " + damageQty.get(0));

				// Currently pre-receiving damage is filed for 6 qty only hence
				// matching the value in receipts with this qty
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DAMAGE_MISMATCH, 6, damageQty.get(0));

			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating damage receipt", e);
		}

	}

	public void verifyPOLineAdd(String itmNum, String caseUPC) {
		idmHelper.poLineAdd(itmNum, caseUPC);
	}

	public void verifyPOLineUpdate(String itmNum) {
		idmHelper.poLineUpdate(itmNum);
	}

	public void validateUpcUpdateGDM(String itemNumUpc, String deliveryName) {
		// $..deliveryDocuments[*].deliveryDocumentLines[?(@.itemNbr == 556233560)]

		try {
			LOGGER.info("Validating IDM delivery Response Code");
			Failsafe.with(retryPolicy).run(() -> {
				response = getDeliveryResponse(deliveryName);
				LOGGER.info("Delivery status code is " + response.getStatusCode());
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());

				JSONArray vendorUPCupdated = JsonPath.read(response.asString(), VENDORUPC_STATUS_PATH);
				LOGGER.info("Delivery status vendor UPC is " + vendorUPCupdated.get(0));
				Assert.assertEquals(ErrorCodes.IDM_VENDOR_UPC_NOT_UPDATED, itemNumUpc, vendorUPCupdated.get(0));
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating updated UPC in GDM", e);
		}
	}

	public boolean validateUpcMisMatch(String itemUPC, String deliveryName) {
		try {
			LOGGER.info("Validating IDM delivery Response Code");
			response = getDeliveryResponse(deliveryName);
			LOGGER.info("Delivery status code is " + response.getStatusCode());
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());

			JSONArray caseUPC = JsonPath.read(response.asString(), CASEUPC_STATUS_PATH);
			LOGGER.info("Delivery status vendor UPC is " + caseUPC.get(0));

			if (caseUPC.get(0).equals(itemUPC)) {
				return false;
			} else {
				return true;
			}

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating updated UPC in GDM", e);
		}

	}

	@Step
	public void validateItemAttributes(String deliveryName) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();

			LOGGER.info("testFlowDataBefore Item Validation : {}", testFlowData);

			List<String> poList = JsonPath.read(testFlowData, "$.testFlowData.poDetails[*].poNumber");
			List<String> delNumList = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + deliveryName + "')].deliveryNumber");
			String delvryNum = delNumList.get(0).toString();
			for (String poNum : poList) {
				List<String> poLineUPCList = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[*].itemUpc");

				for (int i = 0; i < poLineUPCList.size(); i++) {
					String itemUPC = poLineUPCList.get(i).toString();
					LOGGER.info("UPC : {}", itemUPC);

					response = getItemAttributeFromDelivery(delvryNum, itemUPC);
					LOGGER.info("Delivery response : {}", response.asString());

					DocumentContext parsedDeliveryResp = JsonPath.parse(response.asString());
					DocumentContext parsedTestflowData = JsonPath.parse(testFlowData);

					List<String> expectedWarehouseGroupCodeList = parsedTestflowData.read(
							"$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemUpc=='"
									+ itemUPC + "')].witronItemDetails.warehouseGroupCode");
					List<String> expectedWarehouseAreaCodeList = parsedTestflowData.read(
							"$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemUpc=='"
									+ itemUPC + "')].witronItemDetails.warehouseAreaCode");
					List<String> expectedProfiledWarehouseAreaList = parsedTestflowData.read(
							"$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemUpc=='"
									+ itemUPC + "')].witronItemDetails.profiledWarehouseArea");
					List<String> expectedWarehouseRotationTypeCodeList = parsedTestflowData.read(
							"$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemUpc=='"
									+ itemUPC + "')].witronItemDetails.warehouseRotationTypeCode");

					//// will add again
					// List<String> expectedIsVariableWeightList = parsedTestflowData.read(
					// "$.testFlowData.poDetails[?(@.poNumber=='" + poNum +
					// "')].poLineDetails[?(@.itemUpc=='"
					// + itemUPC + "')].witronItemDetails.isVariableWeight");
					List<String> expectedWarehouseMinLifeRemainingToReceiveList = parsedTestflowData.read(
							"$.testFlowData.poDetails[?(@.poNumber=='" + poNum + "')].poLineDetails[?(@.itemUpc=='"
									+ itemUPC + "')].witronItemDetails.warehouseMinLifeRemainingToReceive");

					//// Following also needs to be changed
					//// "https://stg-wtr.gdm.prod.us.walmart.net/document/v2/deliveries/45332537/deliveryDocuments/itemupcs/00655778358251"
					List<String> actualWarehouseGroupCodeList = parsedDeliveryResp
							.read("$..deliveryDocumentLines[*].additionalInfo.warehouseGroupCode");
					List<String> actualWarehouseAreaCodeList = parsedDeliveryResp
							.read("$..deliveryDocumentLines[*].additionalInfo.warehouseAreaCode");
					List<String> actualProfiledWarehouseAreaList = parsedDeliveryResp
							.read("$..deliveryDocumentLines[*].additionalInfo.profiledWarehouseArea");
					List<String> actualWarehouseRotationTypeCodeList = parsedDeliveryResp
							.read("$..deliveryDocumentLines[*].additionalInfo.warehouseRotationTypeCode");
					// List<Boolean> actualIsVariableWeightList = parsedDeliveryResp
					// .read("$..deliveryDocumentLines[*].additionalInfo.isVariableWeight");
					List<Integer> actualWarehouseMinLifeRemainingToReceiveList = parsedDeliveryResp
							.read("$..deliveryDocumentLines[*].additionalInfo.warehouseMinLifeRemainingToReceive");

					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							actualWarehouseGroupCodeList.get(0).trim());
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							actualWarehouseAreaCodeList.get(0).trim());
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							actualProfiledWarehouseAreaList.get(0).trim());
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							actualWarehouseRotationTypeCodeList.get(0).trim());
					// LOGGER.info("Validated Item attribute for the Item UPC : {}",
					// String.valueOf(actualIsVariableWeightList.get(0)));
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							String.valueOf(actualWarehouseMinLifeRemainingToReceiveList.get(0)));
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							expectedWarehouseGroupCodeList.get(0).trim());
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							expectedWarehouseAreaCodeList.get(0).trim());
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							expectedProfiledWarehouseAreaList.get(0).trim());
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							expectedWarehouseRotationTypeCodeList.get(0).trim());
					// LOGGER.info("Validated Item attribute for the Item UPC : {}",
					// String.valueOf(expectedIsVariableWeightList.get(0)));
					LOGGER.info("Validated Item attribute for the Item UPC : {}",
							String.valueOf(expectedWarehouseMinLifeRemainingToReceiveList.get(0)));

					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH,
							"WarehouseGroupCode : " + expectedWarehouseGroupCodeList.get(0).trim(),
							"WarehouseGroupCode : " + actualWarehouseGroupCodeList.get(0).trim());
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH,
							"WarehouseAreaCode : " + expectedWarehouseAreaCodeList.get(0).trim(),
							"WarehouseAreaCode : " + actualWarehouseAreaCodeList.get(0).trim());
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH,
							"ProfiledWarehouseArea : " + expectedProfiledWarehouseAreaList.get(0).trim(),
							"ProfiledWarehouseArea : " + actualProfiledWarehouseAreaList.get(0).trim());
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH,
							"RotationTypeCode : " + expectedWarehouseRotationTypeCodeList.get(0).trim(),
							"RotationTypeCode : " + actualWarehouseRotationTypeCodeList.get(0).trim());
					// Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH,
					// "IsVariableWeight : " + String.valueOf(expectedIsVariableWeightList.get(0)),
					// "IsVariableWeight : " + String.valueOf(actualIsVariableWeightList.get(0)));
					Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH,
							"MinLifeRemainingToReceive : "
									+ String.valueOf(expectedWarehouseMinLifeRemainingToReceiveList.get(0)),
							"MinLifeRemainingToReceive : "
									+ String.valueOf(actualWarehouseMinLifeRemainingToReceiveList.get(0)));
					LOGGER.info("Validated Item attribute for the Item UPC : {}", itemUPC);

				}

			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Item attributes", e);
		}

	}

	public Response retriveDeliverySearchResponse(String delNum) throws JSONException {

		String mssgBody = "{\"deliveryNumbers\" : [" + delNum + "]}";
		LOGGER.info("Delivery number {}", delNum);
		Failsafe.with(retryPolicy).run(() -> {
			response = given().relaxedHTTPSValidation().body(mssgBody).headers(idmHelper.getIDMHeaders()).when()
					.post(environment.getProperty(IDM_DELIVERY_SEARCH_POST_EP));
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, SUCESS_STATUS_CODE, response.getStatusCode());
		});
		return response;
	}

	public Response getItemAttributeFromDelivery(String deliveryNum, String itemUPC) {

		String dgemItemAttributeURL = MessageFormat.format(environment.getProperty("gdmItemAttributeFetch"),
				deliveryNum, itemUPC);

		LOGGER.info("GDM URL  : {}", dgemItemAttributeURL);

		try {
			Failsafe.with(retryPolicy).run(() -> {

				response = given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
						.get(dgemItemAttributeURL);

				Assert.assertEquals(ErrorCodes.GDM_ITEM_ATTRIBURTE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			});
			return response;
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting delivery item attribute", e);
		}
	}

	@Step
	public void setFBQQtyOnUI(String deliveryName) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> delNumList = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + deliveryName + "')].deliveryNumber");
			List<String> expectedPoList = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryNumber=='" + delNumList.get(0) + "')].poNumbers[*]");
			LOGGER.info("Setting FBQ for the delivery  : {}", delNumList.get(0));
			idmLoginPage.getURL(environment.getProperty(GDM_UI_URL));
			idmLoginPage.enterUserName(environment.getProperty(NEXTGEN_USER_NAME));
			idmLoginPage.enterPassword(environment.getProperty("nextGen"));
			idmLoginPage.selectDCNumber(environment.getProperty(FACILITY_NUM));
			idmLoginPage.selectdomain();
			idmLoginPage.clickOnSignInButton();
			Failsafe.with(retryPolicy).run(() -> {
				idmHomePage.searchForDelivery(delNumList.get(0));
				idmHomePage.clickOnDeliveryListTab(delNumList.get(0));
			});
			List<WebElement> actualPoListOnUI = idmHomePage.getPOListfromUI();
			Assert.assertEquals(ErrorCodes.IDM_PO_COUNT_MISMATCH, actualPoListOnUI.size() - 1, expectedPoList.size());
			idmHomePage.clickOnArrowDownLink(actualPoListOnUI.size());
			for (String po : expectedPoList) {
				LOGGER.info("Setting FBQ for the PO  : {}", po);
				idmHomePage.clickOnPoLink(po);
				idmHomePage.clickOnLinesLink();
				List<WebElement> actualPoLineListOnUI = idmHomePage.getPoLineListfromUI();
				List<String> expectedPoLineListOnUI = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber=='" + po + "')].poLineDetails[*]");
				List<String> poLineQty = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber=='" + po + "')]..poVnpkQty");
				Assert.assertEquals(ErrorCodes.IDM_PO_LINE_COUNT_MISMATCH, expectedPoLineListOnUI.size(),
						actualPoLineListOnUI.size());
				for (int lineNum = 0; lineNum < actualPoLineListOnUI.size(); lineNum++) {
					idmHomePage.clickOnFBQEditButton(lineNum + 1);
					idmHomePage.enterFBQ(poLineQty.get(lineNum));
					idmHomePage.clickOnFBQSaveButton();
					String fbqOnUI = idmHomePage.getSettedFBQValue(lineNum + 1);
					Assert.assertEquals(ErrorCodes.IDM_FBQ_NOT_UPDATED, poLineQty.get(lineNum), fbqOnUI);
				}
				idmHomePage.clickOnBackButton();

			}
			idmLoginPage.clickOnInboudDocMenu();
			idmLoginPage.clickOnLogoutButton();
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while setting FBQ in GDM UI", e);
		}
	}

	@Step
	public void validateUpdatedFBQQty(String deliveryName) {
		try {

			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> delNumList = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + deliveryName + "')].deliveryNumber");
			List<String> poList = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryNumber=='" + delNumList.get(0) + "')].poNumbers[*]");

			response = retriveDeliverySearchResponse(delNumList.get(0));
			// DocumentContext parsedDeliveryResp = JsonPath.parse(response.asString());
			for (String po : poList) {
				LOGGER.info("Validating updated FBQ qty for the PO : {}", po);
				List<String> itemList = JsonPath.read(testFlowData,
						"$.testFlowData..poDetails[?(@.poNumber=='" + po + "')]..itemNumber");
				for (String itemNum : itemList) {
					LOGGER.info("Validating updated FBQ qty for the item : {}", itemNum);
					List<String> expectedPoQtyList = JsonPath.read(testFlowData,
							"$.testFlowData..poDetails[?(@.poNumber=='" + po + "')]..poLineDetails[?(@.itemNumber=='"
									+ itemNum + "')].poVnpkQty");
					List<Integer> actualFBQQtyList = JsonPath.read(response.asString(),
							"$.content..deliveryDocuments[?(@.purchaseReferenceNumber=='" + po
									+ "')].deliveryDocumentLines[?(@.itemNbr=='" + itemNum + "')].freightBillQty");
					Assert.assertEquals(ErrorCodes.IDM_FBQ_QTY_MISMATCH, expectedPoQtyList.get(0),
							String.valueOf(actualFBQQtyList.get(0)));
					LOGGER.info("Validated for the item {} : {}", expectedPoQtyList.get(0),
							String.valueOf(actualFBQQtyList.get(0)));
				}
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating updated FBQ qty", e);
		}
	}

	@Step
	public void deliveryArrivedUpdate() {

		LOGGER.info("Updating the delivery status to ARV in GDM");
		int updateStatusCode = idmHelper.updateDeliveryStatus(DEL_STATUS);
		Assert.assertEquals(ErrorCodes.IDM_GATE_IN_FAILED, Constants.SUCESS_STATUS_CODE, updateStatusCode);
	}

	
	@Step
	public void updateLastLimitedQtyVerificationDate() {
		try {
		LOGGER.info("Updating the Limited Qty Last Verification Date less than a year from current date in GDM");
		idmHelper.updateLastLimitedQtyVerificationDateInGDM();	
		}catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating the Limited Qty Last Verification Date", e);
		}
		
	}
	
	@Step
	public void updateLastLithiumIonVerificationDate() {
		try {
		LOGGER.info("Updating the Lithium Ion Last Verification Date less than a year from current date in GDM");
		idmHelper.updateLastLithiumIonVerificationDateInGDM();	}
		catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating the Lithium Ion Last Verification Date", e);
		}
	}
	
	@Step
	public void deliveryDoorAssignGDM() {

		LOGGER.info("Assigning a door for the delivery using GDM");
		int updateStatusCode = idmHelper.assignDoorFromGdm();
		Assert.assertEquals(ErrorCodes.IDM_DOOR_ASSIGN_UPDATE_ERROR, Constants.SUCESS_STATUS_CODE, updateStatusCode);
	}

	@Step
	public void updateFbqAndVariableWeight(String poName) {

		LOGGER.info("Updating FBQ and calculating and updating Varibale weight for the item ");
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		List<String> poNumber = JsonPath.read(testFlowData, javaUtils.format(GET_PO_NUMBER_FROM_NAME, poName));
		idmHelper.croUpdateForFbqVariableWeight(poNumber.get(0));

	}

	public void validateFbqAndVariableWeightInDeliveryDocument(String poName) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		List<String> poNumber = JsonPath.read(testFlowData, javaUtils.format(GET_PO_NUMBER_FROM_NAME, poName));
		idmHelper.validateFbqVariableWtInDelivery(poNumber.get(0));
	}

	public void validatePOLineStatusAfterReject(String poLine, String poName) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		List<String> poNumber = JsonPath.read(testFlowData, javaUtils.format(GET_PO_NUMBER_FROM_NAME, poName));
		idmHelper.validatePOLineStatus(poNumber.get(0), poLine);
	}

	@Step
	public void searchAndValidateIDMForDeliveryReceipt(String poName) {

		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testFlowData);
			List<String> poNumber = parsedItemDetailsJson.read("$..poDetails[?(@.poName=='" + poName + "')].poNumber");
			vaildateReceivedQty(poNumber.get(0));
			validateShortages(poNumber.get(0));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating receipt", e);
		}

	}

	public void rejectPoLine(String poName, String lineNumber) {

		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		List<String> poNumber = JsonPath.read(testFlowData, javaUtils.format(GET_PO_NUMBER_FROM_NAME, poName));
		idmHelper.rejectPoLine(poNumber.get(0), lineNumber);
	}

	public void vaildateReceivedQty(String poNumber) {

		Failsafe.with(retryPolicy).run(() -> {

			LOGGER.info("Waiting IDM Receipts for Status Code :{} ", Constants.SUCESS_STATUS_CODE);
			LOGGER.info("IDM Receipts end point ::{},", MessageFormat
					.format(environment.getProperty("gdm_delivery_receipts_ep"), idmHelper.getDeliveryNumber()));
			response = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
					.get(MessageFormat.format(environment.getProperty("gdm_delivery_receipts_ep"),
							idmHelper.getDeliveryNumber()));

			LOGGER.info("response " + response.asString());
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_RECEIPT_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());

			int receivedQtyFromTestFlowData = idmHelper.getDeliveryTotalReceivedQty(poNumber);
			validateReceivedQuantity(poNumber, receivedQtyFromTestFlowData);
		});
	}

	public void validateShortages(String poNumber) {

		Failsafe.with(retryPolicy).run(() -> {

			LOGGER.info("Validating shortages in GDM receipts");
			if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.SAMS) {
				LOGGER.info("IDM Receipts end point ::{},", MessageFormat
						.format(environment.getProperty("gdm_delivery_receipts_ep"), idmHelper.getDeliveryNumber()));
				response = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
						.get(MessageFormat.format(environment.getProperty("gdm_delivery_receipts_ep"),
								idmHelper.getDeliveryNumber()));
			} else
				response = when()
						.get(environment.getProperty("idm_delivery_receipts_ep") + idmHelper.getDeliveryNumber());
			LOGGER.info("response " + response.asString());
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_RECEIPT_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_SHORTAGE_MISMATCH, true,
					idmHelper.validateShortage(response, poNumber));
		});
	}

	public void sendActiveChannelMethodAsSSTK() {

		LOGGER.info("Simulatig channel flip for CROSSMU freight");

		try {
			JSONObject channelFlip;
			channelFlip = new JSONObject(jsonUtil.readFile("src//test//resources//TestData//acc//channel_update.json"));

			JSONArray itemNumber = JsonPath.read(String.valueOf(threadLocal.get().get(TEST_FLOW_DATA_KEY)),
					"$.testFlowData.poDetails[*].poLineDetails[*].itemNumber");

			channelFlip.put("deliveryNumber", idmHelper.getDeliveryNumber());
			channelFlip.put("itemNumber", itemNumber.get(0));

			LOGGER.info("Channel flip payload: " + channelFlip.toString(2));

			idmHelper.simulateChannelFlip(channelFlip.toString());

		} catch (JSONException | IOException e) {
			throw new AutomationFailure("Failed to publish channel flip event", e);
		}

	}

	@Step
	public void udpatePOLineQty(int poQty) {
		try {
			idmHelper.publishPOLineUpdate(poQty);
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while attaching po line to delivery", e);
		}
	}

	public Response getLoadResponse() {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
		List<String> loadNumberList = JsonPath.read(testFlowData, INBOUND_LOAD_NUMBER_JSON_PATH);
		LOGGER.info("Getting load details for the load " + loadNumberList.get(0));
		Response loadResponse = SerenityRest.given().accept("application/json")
				.get(environment.getProperty(WTMS_LOAD_EP) + loadNumberList.get(0));
		Assert.assertEquals(ErrorCodes.IDM_WTMS_LOAD_DETAILS_NOT_FOUNT, Constants.SUCESS_STATUS_CODE,
				loadResponse.getStatusCode());
		return loadResponse;
	}

	@Step
	public void validateOSDRforCP() {
		try {
			LOGGER.info("Validating OSDR");
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> poNumbers = JsonPath.read(testFlowData, PO_NUMBERS_JSON_PATH);
			for (String poNumber : poNumbers) {
				Response osdrResponse = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).when()
						.get(MessageFormat.format(environment.getProperty("get_osdr"),
								idmHelper.getDeliveryNumber()));
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DAMAGE_MISMATCH, true,
						idmHelper.validateDamageQty(osdrResponse, poNumber));
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_OVERAGE_MISMATCH, true,
						idmHelper.validateOverageQty(osdrResponse, poNumber));
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_SHORTAGE_MISMATCH, true,
						idmHelper.validateShortageQty(osdrResponse, poNumber));

			}
			LOGGER.info("Validated IDM for Received, Overage, shortage and Damage qty");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating OSDR", e);
		}
	}
	@Step
	public void setTransportationModeInGDM(String lithiumIonOrLimitedQty) {
		try{LOGGER.info("Updating the transportation mode for Limited Qty");
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> itemNumberArray = JsonPath.parse(testFlowData).read(ITEM_NUMBER_JSONPATH);
			idmHelper.updateTransportationModeInGDM(itemNumberArray.get(0), lithiumIonOrLimitedQty);
			LOGGER.info("Transportation mode has been updated in DB");}
		catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating the transportation mode", e);
		}

	}

}
