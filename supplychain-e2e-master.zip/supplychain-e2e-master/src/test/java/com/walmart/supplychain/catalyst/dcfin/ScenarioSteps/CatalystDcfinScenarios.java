package com.walmart.supplychain.catalyst.dcfin.ScenarioSteps;

import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.witron.dcfinwitron.scenariosteps.WitronDCFINScenarios;
import com.walmart.supplychain.witron.dcfinwitron.steps.WitronDCFINSteps;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;
//nOT Required 
@ContextConfiguration(classes = SpringTestConfiguration.class)
public class CatalystDcfinScenarios {
	@Steps
	WitronDCFINSteps catalystDcfinSteps;
	
	@Given("^User validates Catalyst purchase in DCFIN$")
	public void userValidatesPurchaseInDCFIN() throws JsonProcessingException
	{		
		catalystDcfinSteps.validatePurchaseInDCFIN();
	}
	
	@Then("^User validates Catalyst average cost average weight and Balance on Hand$")
	public void UserValidatesWacWawBoh() throws JsonProcessingException
	{
		catalystDcfinSteps.validateBOHWacWawAndTotalWeight();
	}
}
