package com.walmart.supplychain.nextgen.problem.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.thucydides.core.pages.PageObject;

public class ProblemLoginPage extends SerenityHelper{

	@FindBy(id = "uname")
	private WebElement userIdField;

	@FindBy(id = "j_password")
	private WebElement passwordField;

	@FindBy(id = "domain")
	private WebElement selectDomainField;
	
	@FindBy(xpath = "//button[text()='Sign in']")
	private WebElement signInButton;
	
	public void enterLoginField(String LoginId) {
		element(userIdField).waitUntilVisible();
		element(userIdField).click();
		element(userIdField).type(LoginId);
	}

	public void enterPasswordField(String password) {
		element(passwordField).waitUntilVisible();
		element(passwordField).click();
		element(passwordField).type(password);
	}

	public void selectDomain(String domainValue) {
		element(selectDomainField).waitUntilVisible();
		element(selectDomainField).selectByVisibleText(domainValue);
	}

	public void clickLogInButton() {
		element(signInButton).waitUntilVisible();
		element(signInButton).click();
	}
	
	public void getUrl(String url) {
		getDriverInstance().get(url);
	}
	
}
