package com.walmart.supplychain.catalyst.by.steps.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystByMobilePage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingHelper;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;

import io.strati.libs.commons.configuration.ConfigurationException;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystByMobileSteps extends ScenarioSteps{
	@Autowired
	Environment environment;
	
	@Autowired
	CatalystByMobilePage catalystByMobilePage;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	CatalystReceivingPage catalystReceivingPage;
	
	@Autowired
	CatalystReceivingHelper catalystReceivingHelper;
	
	@Autowired
	PreRunCleanup preRunCleanup;

	@Autowired
	JavaUtils javaUtils;

	RetryPolicy retryPolicy_5s = JavaUtils.getRetryPolicy(1,5);
	Logger logger = LogManager.getLogger(this.getClass());
	
	List<String> doorList = new ArrayList<String>();
	List<String> lpnList = new ArrayList<String>();
	List<String> lpnStatus = new ArrayList<String>();
	
	static String LPN="";
	private static int putawayCount = 0;
	
	private static final String GET_LPN_NUMBER = "$..receivingInstructions..parentContainer";
	private static final String TEST_FLOW_DATA = "testFlowData";
	
	
	@Step
	public void performPartialInventoryMove() {
	try {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray listOfLpns = JsonPath.read(testFlowData, GET_LPN_NUMBER);
		JSONArray vnpkQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
		//JSONArray damageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..receivingInstructions..damageQty");
		Integer ltcQtyInEaches= Integer.parseInt((String)vnpkQty.get(0))/2;
		
		LPN="LPN"+ javaUtils.randonNumberGenerator(5)+javaUtils.randonNumberGenerator(5);
		
		catalystByMobilePage.clickOnInventoryMenuOption();
		catalystByMobilePage.clickOnPartialInvMoveMenuOption();
		catalystByMobilePage.enterSourceIDValue(listOfLpns.get(0).toString());
		catalystByMobilePage.clickOnDownButton();
		catalystByMobilePage.verifyLoadTranferHeadingIsDisplayed();
		catalystByMobilePage.clickOnLoadTransferDownButton();
		catalystByMobilePage.clickOnLoadTransferDownButton();
		
		catalystByMobilePage.enterValueInQuantityField(Integer.toString(ltcQtyInEaches));
		catalystByMobilePage.clickOnLoadTransferDownButton();
		catalystByMobilePage.clickOnLoadTransferDownButton();
		//catalystByMobilePage.clickOnLoadTransferDownButton();
		//catalystByMobilePage.clickOnLoadTransferDownButton();
		catalystByMobilePage.enterDestinationIDValue(LPN);
		catalystByMobilePage.clickOnLoadTransferDownButton();
		catalystByMobilePage.clickOnLoadButton();
		
	 } 
	catch (Exception e) {
//		catalystReceivingHelper.updateConfig("false"); 
		preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
		throw new AutomationFailure("Failed to perform Partial Inventory Move", e);
	}
		
	}			
	
	@Step
	public void performInventoryStatusChange(String newStatus) throws ConfigurationException, InterruptedException {
		try {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray listOfLpns = JsonPath.read(testFlowData, GET_LPN_NUMBER);
//		List<Integer> vnpkQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
//		List<String> damageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..damageQty");
//		int totalQtyInEaches=Integer.valueOf( vnpkQty.get(0))*Integer.valueOf(damageQty.get(0));
		
		catalystByMobilePage.clickOnActionsButton();
		catalystByMobilePage.clickOnToolsOption();
		catalystByMobilePage.clickOnMaintenanceMenu();
		catalystByMobilePage.clickOnStatusChange();
		catalystByMobilePage.enterInventoryIdentifierUnderInvStsChange(LPN);
		catalystByMobilePage.clickOnDownButton();
		catalystByMobilePage.enterNewStatusValue(newStatus);
		catalystByMobilePage.clickOnDownButton();
		catalystByMobilePage.enterReasonCodeValue(newStatus);
		catalystByMobilePage.clickOnDownButton();
		catalystByMobilePage.clickOnYesButton();
		catalystByMobilePage.verifyStatusChangedDialogBoxIsDisplayed();
		catalystByMobilePage.clickOnOkButton();
		catalystReceivingPage.clickOnNavigateUpButton();
		catalystReceivingPage.clickOnNavigateUpButton();
		catalystReceivingPage.clickOnNavigateUpButton();
		catalystReceivingPage.clickOnNavigateUpButton();
		catalystReceivingPage.clickOnNavigateUpButton();
		catalystByMobilePage.verifyUndirectedMenuHeadingIsDisplayed();
		}
		 catch (InterruptedException e) {
//			 catalystReceivingHelper.updateConfig("false");
			 preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new TestCaseFailure(e);
			}
		catch (Exception e) {
//			catalystReceivingHelper.updateConfig("false"); 
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new AutomationFailure("Failed to perform Inventory Status Change", e);
		}
	}		
	

	@Step
	public void performManualPutaway(String desiredLocation) throws InterruptedException, ConfigurationException {	
		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			String desiredPutawayLocationId="";
			String manualPutawayLpn="";
			catalystByMobilePage.clickOnInventoryMenuOption();
			catalystByMobilePage.clickOnNextOption();
			catalystByMobilePage.clickOnPutawayOption();
			switch(desiredLocation){
			case("Ripening Room Reserve"):{
				manualPutawayLpn=lpnList.get(0);
				desiredPutawayLocationId=environment.getProperty("RipeningRoomLocation");
				catalystByMobilePage.enterInventoryIdentifier(manualPutawayLpn);
				catalystByMobilePage.clickOnDownButton();
				break;	
			}
			case("Less Than Case"):{
				manualPutawayLpn=LPN;
				desiredPutawayLocationId=environment.getProperty("LessThanCaseLocation");
				catalystByMobilePage.enterPutawayInventoryIdentifier(manualPutawayLpn);
				catalystByMobilePage.clickOnDownButton();
				catalystByMobilePage.clickOnOkButton();
				break;	
			}
				
			}
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyInventoryDepositDialogIsDisplayed();
			catalystByMobilePage.clickOnOkButton();
			catalystByMobilePage.verifyMrgProductDepositHeadingIsDisplayed();
			catalystByMobilePage.enterDesiredPutawayLocationTextBox(desiredPutawayLocationId);
			catalystByMobilePage.clickOnDownButton();

		}
		catch (AssertionError | FailsafeException e) {
//			catalystReceivingHelper.updateConfig("false"); 
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new TestCaseFailure(e);

		} catch (Exception e) {
//			catalystReceivingHelper.updateConfig("false"); 
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new AutomationFailure("Failed to add perform Manual Putaway", e);
		}
	}
	
	
	@Step
	public void performsDirectedPutaway(String expectedLocation) {
		
		try {
			logger.info("Putaway count: {}", putawayCount);
			String testFlowData = String.valueOf(threadLocal.get().get(TEST_FLOW_DATA));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			lpnStatus = JsonPath.read(testFlowData, "$..receivingInstructions..receivedStatus");
			
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyPickUpProductAtHeadingIsDisplayed();
			catalystByMobilePage.verifySourceLocationLabelIsDisplayed();
			catalystByMobilePage.verifySourceLocationValueIsDisplayed(doorList.get(0));
			catalystByMobilePage.clickOnNextButton();
			catalystByMobilePage.enterInventoryIdentifier(lpnList.get(putawayCount));
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.sleep(2);
			
			Failsafe.with(retryPolicy_5s).run(() -> {
				catalystReceivingPage.clickOnNavigateUpButton();
				Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_BY_APP_DIRECTED_WORK_OPTION_NOT_VISIBLE, true, catalystByMobilePage.directedWorkOptionIsVisible());
			});
			
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyInventoryDepositDialogIsDisplayed();
			catalystByMobilePage.clickOnOkButton();		
			catalystByMobilePage.verifyMrgProductDepositHeadingIsDisplayed();
			
			String desiredLocation = "";
			switch(expectedLocation.toLowerCase()) {
			
				case "destination" :
					desiredLocation = catalystByMobilePage.getPutawayDepositeLocation();
					break;
				
				case "coldpnd" :
					desiredLocation = environment.getProperty("ColdPNDLocation");
					break;	
				
				case "penalty" :
					catalystByMobilePage.verifyProblemItemHeadingIsDisplayed();
			    	catalystByMobilePage.verifyReworkLocationDisplayedForProblemItem();
					desiredLocation = environment.getProperty("penaltyBoxLocation");
					break;	
			}
			
			catalystByMobilePage.enterDesiredPutawayLocationTextBox(desiredLocation);
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.verifyUndirectedMenuHeadingIsDisplayed();
			
			logger.info("Successfully performed directed putaway to desired location");
			putawayCount++;
			logger.info("Putaway count for next work assignment: {}", putawayCount);
			
		} catch (AssertionError | FailsafeException e) {
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new AutomationFailure("Something went wrong while performing directed putaway", e);
		}
		
	}
	
}
