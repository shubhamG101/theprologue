package com.walmart.supplychain.acc.acl.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.QueryHelper;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ACLDBSteps {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	Environment environment;

	@Autowired
	DbUtils dbUtils;

	JsonUtils jsonUtils = new JsonUtils();
	QueryHelper queryHelper = new QueryHelper();
	Logger logger = LogManager.getLogger(this.getClass());
	private static final String SELECT_ITEM_LABEL = "select_item_label";
	private static final String FAILED_MSG = "Failed in : ";
	private static final String SELECT_LANE_DOOR = "select_lane_door";
	private static final String SELECT_LANE_DOOR_DIVERSION = "select_lane_door_diversion";
	private static final String SELECT_DOOR_DATA = "select_door_data";
	private static final String SELECT_LANE_NBR_NORMAL_STATUS = "select_lane_nbr_normal_status";
	private static final String SELECT_LANE_NBR_EXP_STATUS = "select_lane_nbr_exp_status";
	private static final String SELECT_LABEL_DATA_FOR_ITEMLABELID = "select_label_data_For_ItemLabelId";
	private static final String SELECT_EXCEPTIONURL_DELIVERYNBR = "select_acl_exception_url";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	private String exceptionURL;

	public int getLabelCountFromACL(List lpns) {

		Object[] lpnArr = new Object[lpns.size()];
		for (int i = 0; i < lpns.size(); i++) {

			lpnArr[i] = lpns.get(i);
		}
		List<Map<String, Object>> lpnIds;
		logger.info("Label count query {}", environment.getProperty("select_lpn_data_acl"));
		lpnIds = dbUtils.selectFrom(Config.DC,
				dbUtils.transformIntoSpringQuery(environment.getProperty("select_lpn_data_acl"), lpns.size()), lpnArr);
		return lpnIds.size();

	}

	public List getItemLabelsForDelivery(String delivery) {

		List itemLabelList = new ArrayList();
		logger.info("Get item labels for delivery {}", environment.getProperty(SELECT_ITEM_LABEL));
		List<Map<String, Object>> labelDataMap = dbUtils.selectFrom(Config.DC,
				environment.getProperty(SELECT_ITEM_LABEL), delivery);
		try {
			if (labelDataMap.size() > 0) {
				for (Map<String, Object> data : labelDataMap) {
					int itemLabel = (int) data.get("item_label_id");
					itemLabelList.add(Integer.toString(itemLabel));
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + environment.getProperty(SELECT_ITEM_LABEL));
		}
		return itemLabelList;

	}

	public Map<String, String> getLanesForDoor(List<String> doorsList) {

		Object[] lpnArr = new Object[doorsList.size()];
		for (int i = 0; i < doorsList.size(); i++) {

			lpnArr[i] = doorsList.get(i);
		}
		Map<String, String> laneDoorMap = new HashMap();
		List<Map<String, Object>> laneDoorMapQuery;
		logger.info("Get lanes for the door {}", environment.getProperty(SELECT_LANE_DOOR));
		laneDoorMapQuery = dbUtils.selectFrom(Config.DC,
				dbUtils.transformIntoSpringQuery(environment.getProperty(SELECT_LANE_DOOR), doorsList.size()), lpnArr);

		try {
			if (laneDoorMapQuery.size() > 0) {
				for (Map<String, Object> data : laneDoorMapQuery) {
					String door = (String) data.get("ship_door_nbr");
					String lane = (String) data.get("sorter_lane_nbr");
					laneDoorMap.put(door.trim(), lane.trim());
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + environment.getProperty(SELECT_LANE_DOOR));
		}
		return laneDoorMap;
	}

	public String getDestinationForDoorDiversion(String door) {

		int dest = 0;
		try {
			logger.info("Get destination for door {}", environment.getProperty(SELECT_LANE_DOOR_DIVERSION));
			List<Map<String, Object>> doorLaneMap = dbUtils.selectFrom(Config.DC,
					environment.getProperty(SELECT_LANE_DOOR_DIVERSION), door);
			if (doorLaneMap.size() > 0) {
				dest = (int) doorLaneMap.get(0).get("destination");
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + environment.getProperty(SELECT_LANE_DOOR_DIVERSION));
		}
		return String.valueOf(dest);
	}

	public String getExceptionURl(String deliveryNumber){
		
		try {
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Get exception URL for deliveryNbr {}" + deliveryNumber + " : "
						+ environment.getProperty(SELECT_EXCEPTIONURL_DELIVERYNBR));
				List<Map<String, Object>> doorLaneMap = dbUtils.selectFrom(Config.DC,
						environment.getProperty(SELECT_EXCEPTIONURL_DELIVERYNBR), deliveryNumber);

				Assert.assertTrue(ErrorCodes.EXCEPTION_URL_LABEL, doorLaneMap.size() > 0);
				logger.info("Exception URL fetched for delivery {}", deliveryNumber);

				if (doorLaneMap.size() > 0) {
					exceptionURL = (String) doorLaneMap.get(0).get("exception_url");
					logger.info("Exception URL is " + exceptionURL);
				}
			});
		} catch (Exception e) {
			logger.info(FAILED_MSG + environment.getProperty(SELECT_EXCEPTIONURL_DELIVERYNBR));
		}
		return exceptionURL;	
	}
	
	public void deleteDestMappingForDoor(String door) {
		try {

			Object[] objArr = new Object[1];
			objArr[0] = door;
			int deleteCount;
			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_dest_door"), objArr[0]);
			logger.info("deleted:{} rows from destination_door_assignment table as part of sorter cleanup", deleteCount);
		} catch (Exception e) {
			logger.info("DELETE:"+FAILED_MSG + environment.getProperty("delete_dest_door"));
		}

	}

	public List<Map<String, Object>> validateStopDiversionForDoor(String door) {

		logger.info("Get destination for door {}", environment.getProperty(SELECT_LANE_DOOR_DIVERSION));
		return dbUtils.selectFrom(Config.DC,
				environment.getProperty(SELECT_LANE_DOOR_DIVERSION), door);

	}

	public String getDoorNumber(String deliveryNbr) {

		logger.info("Get door for delivery from acl table {}", environment.getProperty(SELECT_DOOR_DATA));
		List<Map<String, Object>> doorNbr = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_DOOR_DATA),
				deliveryNbr);
		String doorNumber = null;
		try {
			if (doorNbr.size() > 0) {
				doorNumber = (String) doorNbr.get(0).get("location_id");
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + environment.getProperty(SELECT_DOOR_DATA));
		}
		return doorNumber;

	}

	public int getLabelGrpMappingCount(String deliveryNbr) {

		logger.info("Get door for delivery count from acl table {}", environment.getProperty(SELECT_DOOR_DATA));
		List<Map<String, Object>> doorNbr = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_DOOR_DATA),
				deliveryNbr);
		return doorNbr.size();

	}

	public int getLabelDataCount(List itemLabelList) {

		Object[] lpnArr = new Object[itemLabelList.size()];
		for (int i = 0; i < itemLabelList.size(); i++) {

			lpnArr[i] = itemLabelList.get(i);
		}
		Map<String, String> laneDoorMap = new HashMap();
		List<Map<String, Object>> laneDoorMapQuery;
		logger.info("Get labels for item label ID {}", environment.getProperty(SELECT_LABEL_DATA_FOR_ITEMLABELID));
		laneDoorMapQuery = dbUtils.selectFrom(Config.DC, dbUtils.transformIntoSpringQuery(
				environment.getProperty(SELECT_LABEL_DATA_FOR_ITEMLABELID), itemLabelList.size()), lpnArr);
		return laneDoorMapQuery.size();

	}

	// Get count for lpn to lane
	public List getLaneNumberForLPNs(List<String> lpnList, String labelStatus) {
		Object[] rdcArr = new Object[lpnList.size()];
		Map<String, String> rdcDoorMap = new HashMap();
		for (int i = 0; i < lpnList.size(); i++) {

			rdcArr[i] = lpnList.get(i);
		}
		List<Map<String, Object>> laneNums;
		List laneList = new ArrayList();
		String checkLaneQuery=null;
		if (labelStatus.equalsIgnoreCase("normal")) {
			checkLaneQuery=environment.getProperty(SELECT_LANE_NBR_NORMAL_STATUS);
		}
		else
		{
			checkLaneQuery=environment.getProperty(SELECT_LANE_NBR_EXP_STATUS);
		}
		logger.info("Get count for lpn to lane ", checkLaneQuery);
		laneNums = dbUtils.selectFrom(Config.DC,
				dbUtils.transformIntoSpringQuery(checkLaneQuery, lpnList.size()), rdcArr);
		try {
			if (laneNums.size() > 0) {
				for (Map<String, Object> data : laneNums) {
					String lane = (String) data.get("current_lane");
					laneList.add(lane.trim());
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + checkLaneQuery);
		}
		return laneList;
	}

	public Map getLanesForDoors(List doorsList) {

		Object[] rdcArr = new Object[doorsList.size()];
		Map<String, String> rdcDoorMap = new HashMap();
		Map<String, String> doorLaneMap = new HashMap();
		for (int i = 0; i < doorsList.size(); i++) {

			rdcArr[i] = doorsList.get(i);
		}
		List<Map<String, Object>> laneNums;
		logger.info("Get lanes for doors {}", environment.getProperty(SELECT_LANE_DOOR));
		laneNums = dbUtils.selectFrom(Config.DC,
				dbUtils.transformIntoSpringQuery(environment.getProperty(SELECT_LANE_DOOR), doorsList.size()), rdcArr);
		try {
			if (laneNums.size() > 0) {
				for (Map<String, Object> data : laneNums) {
					String laneNbr = (String) data.get("sorter_lane_nbr");
					String doorNbr = (String) data.get("ship_door_nbr");
					doorLaneMap.put(doorNbr.trim(), laneNbr.trim());
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + environment.getProperty(SELECT_LANE_DOOR));
		}
		return doorLaneMap;

	}

	public void updateACCLoading(String door) {

		logger.info("Updating load_door loading table for ACC {}", environment.getProperty("select_wm_location"));
		List<Map<String, Object>> doorNbr = dbUtils.selectFrom(Config.DC, environment.getProperty("select_wm_location"),
				door);
		int locationId = (int) doorNbr.get(0).get("wm_location_id");
		Object[] objArr = new Object[1];
		objArr[0] = locationId;
		int updateCount;
		updateCount = dbUtils.updateFrom(Config.DC, environment.getProperty("update_load_door"), objArr[0]);
		logger.info("updated load_door table to enable ACC Loading" + updateCount);

	}

	public String getRejectCode(String deliveryNum) {
		
		logger.info("Get reject code for delivery from acl table {}", environment.getProperty("select_item_label"));
		List<Map<String, Object>> rejectCode = dbUtils.selectFrom(Config.DC, environment.getProperty("select_item_label"),
				deliveryNum);
		String rejectCodeValue = null;
		try {
			if (rejectCode.size() > 0) {
				rejectCodeValue = (String) rejectCode.get(0).get("reject_code");
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.info(FAILED_MSG + environment.getProperty("select_item_label"));
		}
		logger.info("Reject code from ACL DB "+rejectCodeValue);
		return rejectCodeValue;
	}
	
	public void updateACLLableStatusCode(List lpns) {

		Object[] lpnArr = new Object[lpns.size()];
		for (int i = 0; i < lpns.size(); i++) {

			lpnArr[i] = lpns.get(i);
		}
		dbUtils.updateFrom(Config.DC, dbUtils.transformIntoSpringQuery(environment.getProperty("update_status_code_lpn_data_acl"), lpns.size()), lpnArr);
	}

}
