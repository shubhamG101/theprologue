package com.walmart.supplychain.catalyst.by.ui.steps;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tools.ant.taskdefs.Sleep;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.framework.utilities.selenium.UiActionsHelper;
import com.walmart.supplychain.catalyst.by.ui.pages.BYReceivingPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYLoginPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmSteps;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import scala.annotation.meta.field;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYUiHelper extends SerenityHelper{
	


	WebDriver driver;
	Logger logger = LogManager.getLogger(this.getClass());
	
	
	@Autowired
	Environment endPoint;
		
	@Autowired
	BYLoginPage byLoginPage;
	
	@Autowired
	BYReceivingPage byReceivingPage;
	
	@Autowired
	BYOutboundPage byOutboundPage;
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	GDMPharmSteps gdmPharmSteps;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	IDMSteps idmSteps;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	GDMPharmHelper gdmPharmHelper;
	
	@Autowired
	UiActionsHelper uiActionsHelper;
	
	JavaUtils javaUtils = new JavaUtils();
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 
			Constants.RETRY_EXECUTION_COUNT);
	
	private static final String TEST_FLOW_DATA = "testFlowData";
	
	
	
	public void navigateToMentionedMenu(String menuItem) throws InterruptedException {
		
		getDriverInstance().switchTo().defaultContent();
		
		Failsafe.with(retryPolicy).run(() -> {
			byReceivingPage.clickOnMenuDropdownIcon();
			byReceivingPage.selectMentionedMenuOption(menuItem);
		});
		
	}
	
	public void navigateToMentionedTab(String tabName) {
		
		getDriver().switchTo().defaultContent();
		
		Failsafe.with(retryPolicy).run(() -> {
			byReceivingPage.clickOnMentionedTab(tabName);
		});
		
	}
	
	public void switchToFrameWithElement(WebElement element) {
		getDriver().switchTo().frame(element);
		logger.info("Switched to working frame {} -----> ", element);
	}

	public void switchToParentFrame() {
		getDriver().switchTo().parentFrame();
		logger.info("Switched to Parent Content {} -----> ");
	}

	public void switchToDefaultContent() {
		getDriver().switchTo().defaultContent();
		logger.info("Switched to DefaultContent {} -----> ");
	}
	
	
	// updating test flow data with latest outbound field details
	@SuppressWarnings("unchecked")
	public void updateTestFlowDataForOutboundDetails(String fieldName, String fieldValue) throws IOException, ParseException {
		
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		
		JSONArray jsonArrayOfOBDetails = JsonPath.read(runTimeData, "$.testFlowData.outboundDetails[*]");
		
		List<OutboundDetail> outboundDetailObj = (List<OutboundDetail>) jsonUtils
				.getPojoListfromPath(jsonArrayOfOBDetails.toJSONString(), OutboundDetail.class);

		switch(fieldName) {
		
			case "waveNumber_BY":
				outboundDetailObj.get(0).setWaveNumber_BY(fieldValue);
				break;
				
			
			case "loadID_BY":
				outboundDetailObj.get(0).setLoadID_BY(fieldValue);
				break;
				
				
			case "sourceLocationForPicking":
				outboundDetailObj.get(0).setSourceLocationForPicking(fieldValue);
				break;
				
				
			case "destinationLocationForPicking":
				outboundDetailObj.get(0).setDestinationLocationForPicking(fieldValue);
				break;
				
				
			case "operationNumForPicking":
				outboundDetailObj.get(0).setoperationNumForPicking(fieldValue);
				break;
			
			case "outboundYardZone":
				outboundDetailObj.get(0).setOutboundYardZone(fieldValue);
				break;
			
			case "outboundDoorNumber":
				outboundDetailObj.get(0).setOutboundDoorNumber(fieldValue);
				break;
			
			case "trailerNumber":
				outboundDetailObj.get(0).setTrailerNumber(fieldValue);
				break;
		}

		JSONArray outboundDetailsList = jsonUtils.converyListToJsonArray(outboundDetailObj);

		JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
		String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), outboundDetailsList,
				"$.testFlowData.outboundDetails");
		
		threadLocal.get().put(TEST_FLOW_DATA, testFlowData);
		logger.info("Updated {} field under outbound details as {} value in test flow data!!", fieldName, fieldValue);
		logger.info("testFlowData after updating outbound details:{}", testFlowData);
		
	}
	
	
	@SuppressWarnings("unchecked")
	public void updateTestFlowDataForPoLineDetails(String fieldName, String fieldValue) throws IOException, ParseException {
		
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		
		JSONArray jsonArrayOfPOLineDetails = JsonPath.read(runTimeData, "$.testFlowData.poDetails..poLineDetails[*]");
		
		/*This is to create a new array inside existing array while setting up the TFD
		 * List<PoLineDetail> poLineDetailObj = (List<PoLineDetail>) jsonUtils
		 * .getPojoListfromPath(jsonArrayOfPOLineDetails.toJSONString(),
		 * PoLineDetail.class); JSONArray poLineDetailsList =
		 * jsonUtils.converyListToJsonArray(poLineDetailObj); JSONObject parentObject =
		 * jsonUtils.convertStringToMinidevJsonObject(runTimeData); String testFlowData
		 * = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), poLineDetailsList,
		 * "$.testFlowData.poDetails..poLineDetails[*]"); JSONObject poLIneObject =
		 * jsonUtils.convertToJsonObject(poLineObj);
		 */

		PoLineDetail poLineObj = (PoLineDetail) jsonUtils.getPojofromJsonObject(jsonArrayOfPOLineDetails.get(0), PoLineDetail.class);

		switch(fieldName) {
		
			case "primeLocation":
				poLineObj.setPrimeLocation(fieldValue);
				break;
		}
		
		String testFlowDataUpdated = jsonUtils.setJsonAtJsonPath(runTimeData, poLineObj,"$.testFlowData.poDetails..poLineDetails[*]");
		
		threadLocal.get().put(TEST_FLOW_DATA, testFlowDataUpdated);
		logger.info("Updated {} field under poLineDetails as {} value in test flow data!!", fieldName, fieldValue);
		logger.info("testFlowData after updating poLineDetails :{}", testFlowDataUpdated);
		
	}
	
	
}
