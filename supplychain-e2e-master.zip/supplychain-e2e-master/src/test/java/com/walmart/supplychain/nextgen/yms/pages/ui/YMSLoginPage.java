package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.thucydides.core.pages.PageObject;

import java.io.Serializable;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class YMSLoginPage extends SerenityHelper  {


	PropertyResolver propertyResolver = new PropertyResolver();

	@FindBy(id = "userID")
	private WebElement userIdField;

	@FindBy(id = "password")
	private WebElement passwordField;

	@FindBy(id = "dcNbr")
	private WebElement dcNbrField;

	@FindBy(id = "loginButton")
	private WebElement loginButton;

	@FindBy(xpath = "//a[contains(text(),'Logout')]")
	private WebElement logoutButton;

	public void getUrl(String url) {
		getDriverInstance().get(url);
	}

	public void enteruserIdField(String LoginId) {
		element(userIdField).waitUntilVisible();
		element(userIdField).click();
		element(userIdField).type(LoginId);
	}

	public void enterPasswordField(String password) {
		element(passwordField).waitUntilVisible();
		element(passwordField).click();
		element(passwordField).type(password);
	}

	public void selectDCNumber(String dcNumber) {
		element(dcNbrField).waitUntilVisible();
		element(dcNbrField).selectByVisibleText(dcNumber);
	}

	public void clickLogInButton() {
		element(loginButton).waitUntilVisible();
		element(loginButton).click();
	}

	public void clickLogoutButton() {
		element(logoutButton).waitUntilVisible();
		element(logoutButton).click();
	}
}