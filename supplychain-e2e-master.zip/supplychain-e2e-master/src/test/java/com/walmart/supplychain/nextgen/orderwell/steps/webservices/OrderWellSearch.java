package com.walmart.supplychain.nextgen.orderwell.steps.webservices;

public class OrderWellSearch {

    private long srcnumber, itemNumber;

    public long getSrcnumber() {
        return srcnumber;
    }

    public void setSrcnumber(long srcnumber) {
        this.srcnumber = srcnumber;
    }

    public long getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(long itemNumber) {
        this.itemNumber = itemNumber;
    }
}
