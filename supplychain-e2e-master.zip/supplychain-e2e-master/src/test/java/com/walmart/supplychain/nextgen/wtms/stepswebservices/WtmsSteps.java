package com.walmart.supplychain.nextgen.wtms.stepswebservices;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;
import io.restassured.response.Response;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class WtmsSteps extends ScenarioSteps {

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtil;

	Logger logger = LogManager.getLogger(this.getClass());

	ObjectMapper objectMapper = new ObjectMapper();

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(30, 15);

	@SuppressWarnings("unchecked")
	@Step
	public void validateSto() {
		Boolean isTMSIDUpdateReq=false;
		isTMSIDUpdateReq = Boolean.valueOf(environment.getProperty("is_TMSID_update_required"));
		if (!isTMSIDUpdateReq) {
			logger.info("Validating STO details in WTMS system");
			String testFlowData = (String) threadLocal.get().get("testFlowData");
			JSONArray listOfLoads = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*]");
			String outboundJson = null;
			List<OutboundDetail> outboundDetailList = new ArrayList();
			try {
				outboundJson = objectMapper.writeValueAsString(listOfLoads);
				outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
						OutboundDetail.class);
			} catch (Exception e) {
				logger.error(e);
			}

			for (OutboundDetail outbound : outboundDetailList) {

				if (!outbound.getstoNumbers().isEmpty()) {
					String tmsLoadId = outbound.getTmsLoadId();
					logger.info("TMS Load Id for which STO is going to be validated is:{}", tmsLoadId);
					Response response = SerenityRest.given().contentType("application/json").when()
							.get(MessageFormat.format(environment.getProperty("get_wtms_sto_url"), tmsLoadId));
					Assert.assertEquals(ErrorCodes.WTMS_INCORRECT_REESPONSE, 200, response.getStatusCode());
					verifyStoNumbers(response, testFlowData, tmsLoadId);
				}
			}
		}
		else {
			logger.info("Skipped STO details validation in WTMS, as WTMS is manually setted in Loading");
		}
		
	}

	private void verifyStoNumbers(Response response, String testFlowData, String tmsLoadId) {

		List<String> stoNumbersTfd = JsonPath.read(testFlowData,
				"$..outboundDetails[?(@.loadId == '" + tmsLoadId + "')].stoNumbers[*]");
		List<String> stoNumbersWtms = JsonPath.read(response.toString(), "$..poNumber");
		for (String stoNumber : stoNumbersTfd) {

			Assert.assertTrue(ErrorCodes.WTMS_STO_NOT_PRESENT, stoNumbersWtms.contains(stoNumber));
		}

		logger.info("Verified the STO numbers in the WTMS system succesfully for wtms load :{}", tmsLoadId);
	}

}
