package com.walmart.supplychain.nextgen.problem.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import net.thucydides.core.pages.PageObject;

public class ProblemSearchPage extends PageObject{

	@FindBy(xpath = "//div[@ng-show='!searchResultsShown']//input[@ng-model='searchBody.deliveryNbr']") 
	private WebElement deliveryField;
	@FindBy(xpath = "//div[@ng-show='!searchResultsShown']//input[@ng-model='searchBody.itemNbr']") 
	private WebElement itemField;
	@FindBy(xpath = "//div[@ng-show='!searchResultsShown']//span[contains(text(),'Search')]")
	private WebElement searchButton;
	
	public void enterDeliveryNumber(String deliveryNumber) {
		element(deliveryField).waitUntilVisible();
		element(deliveryField).click();
		element(deliveryField).type(deliveryNumber);
	}
	
	public void enterItemNumber(String itemNumber) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(itemField).waitUntilClickable();
		element(itemField).click();
		element(itemField).sendKeys(itemNumber);
	}
	public void clickOnSearch() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(searchButton).waitUntilClickable();
		element(searchButton).click();
	}

}
