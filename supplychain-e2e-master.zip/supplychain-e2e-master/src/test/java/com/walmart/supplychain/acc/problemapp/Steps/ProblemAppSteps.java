package com.walmart.supplychain.acc.problemapp.Steps;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import io.restassured.response.Response;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.acc.ProblemResolution;
import com.walmart.framework.supplychain.domain.acc.ProblemResolutionDetail;
import com.walmart.framework.supplychain.domain.acc.ProblemResolve;
import com.walmart.framework.supplychain.domain.acc.ProblemSearch;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ProblemContainer;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ProblemDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACCMongoSteps;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.acc.problemapp.pages.ProblemAppPage;
import com.walmart.supplychain.acc.sorter.steps.webservices.SorterHelper;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.receiving.pages.mobile.ReceivingPage;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ProblemAppSteps {

	@Steps
	ProblemAppPage problemAppPage;

	@Steps
	ReceivingPage receivingPage;

	@Steps
	ACLDBSteps aCLDBSteps;

	@Steps
	InventorySteps invSteps;

	Logger logger = LogManager.getLogger(this.getClass());
	PropertyResolver propertyResolver = new PropertyResolver();

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	TextParser textParser;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	@Autowired
	ACCMongoSteps accMongoSteps;

	@Autowired
	SorterHelper sorterHelper;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	JsonUtils jsonUtils;
	
	@Autowired
	InventoryHelper inventoryHelper;

	public static final String CTR_LIST = "containerList";
	public static final String CTR_TAG_ID = "containerTagId";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String INVENTORY_ENDPOINT_KEY = "inventory_ep";
	private static final String INVENTORY_QUERYPARAM_KEY = "inventory_ep_qp";
	private static final String PROBLEM_SEARCH_URL = "problem_search_url";
	private static final String PROBLEM_ACTION_URL = "problem_action_url";
	private static final String PROBLEM_RESOLV_URL = "problem_resolv_url";
	private static final String PROBLEM_GET_URL = "get_problem_url";
	private static final String PROBLEM_STATUS = "ANSWERED_AND_READY_TO_RECEIVE";
	private static final String PROBLEM_STATUS_RESOLV = "RESOLVED";
	private static final String DC_NUM = "dcNumber";
	private static final String GET_LABEL_COLLECTION = "containers";
	private static final String MONGO_SCHEMA = "receive_container";
	private static final String JSON_PATH_DELIVERY = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private static final String INVENTORY_LOCATION_PATH = "$.locationName";
	private static final String LPN_SORTERRESPONSE_JSONPATH = "$.lpnFoundList[*].containerUUID";
	private static final String DELIVERY_NUMBER="$.testFlowData.deliveryDetails[*].deliveryNumber";
	ObjectMapper om = new ObjectMapper();
	Response response;
	String probLpn = null;

	public void openProblemAppPage() {
		logger.info("problem app url:{}", environment.getProperty("problem_app_url"));
		problemAppPage.getUrl(environment.getProperty("problem_app_url"));

	}

	public void openReceivingAppPage() {
		logger.info("Receiving app url:{}", environment.getProperty("receivingapp_webui_url"));
		receivingPage.getUrl(environment.getProperty("receivingapp_webui_url"));
	}

	@Step
	public void createProblemContainers(String problemType) {
		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			List<ProblemDetail> problemDetailList = new ArrayList<ProblemDetail>();
			openProblemAppPage();
			Thread.sleep(5000);
			problemAppPage.handleProblemPopup();
			JSONArray listOfDeliveries = JsonPath.read(testData, DELIVERY_NUMBER);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> deliveryList = om.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = deliveryList.get(0);

			JSONArray listOfProblemLPNs = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType == \""
							+ problemType + "\")].parentContainer");
			String listOfProblemLPNString = listOfProblemLPNs.toJSONString();
			logger.info("Problem LPN List {}", listOfProblemLPNString);
			List<String> problemLPNList = null;
			problemLPNList = om.readValue(listOfProblemLPNString, new TypeReference<List<String>>() {
			});

			for (int i = 0; i < problemLPNList.size(); i++) {
				if (i < problemLPNList.size() / 2) {
					String probCntr = null;
					problemAppPage.scanProblemLPN(problemLPNList.get(i));
					if (i == 0) {
						problemAppPage.clickCreateProbTkt();
						problemAppPage.clickManualPrinter();
						problemAppPage.selectEmulatorPrinter();
						problemAppPage.clickPrinterDone();
					} else {

						ProblemSearch probSearch = new ProblemSearch();
						probSearch.setDcNumber(Integer.parseInt(environment.getProperty(DC_NUM)));
						probSearch.setDeliveryNbr(Integer.parseInt(deliveryNum));
						probSearch.setIncludeDc(false);

						logger.info("containers search url :{}", environment.getProperty(PROBLEM_SEARCH_URL));
						logger.info("payload :{}", om.writeValueAsString(probSearch));
						Failsafe.with(retryPolicy).run(() -> {
							response = SerenityRest.given().contentType("application/json")
									.body(om.writeValueAsString(probSearch)).when()
									.post(environment.getProperty(PROBLEM_SEARCH_URL)).andReturn();
							Assert.assertEquals(ErrorCodes.PROBLEM_INVALID_STATUS, 200, response.getStatusCode());
						});
						logger.info("Get Problem Details Response: {}", response.asString());
						JSONArray searchOfProbCntrs = JsonPath.read(response.asString(),
								"$..containers[*].containerId");
						String probCntrString = searchOfProbCntrs.toJSONString();
						List<String> probCntrList = om.readValue(probCntrString, new TypeReference<List<String>>() {
						});
						probCntr = probCntrList.get(0);
						problemAppPage.clickContainerAssociateBtn();
						problemAppPage.clickContainerAssociateNextBtn(probCntr);
						problemAppPage.scanProblemLPN(probCntr);
					}

				} else {
					problemAppPage.scanProblemLPN(problemLPNList.get(i));
					String probCntr = null;
					if (i == problemLPNList.size() / 2) {
						problemAppPage.clickCreateContainerBtn();
						problemAppPage.clickCreateContainerBtnTwice();
					} else {
						ProblemSearch probSearch = new ProblemSearch();
						probSearch.setDcNumber(Integer.parseInt(environment.getProperty(DC_NUM)));
						probSearch.setDeliveryNbr(Integer.parseInt(deliveryNum));
						probSearch.setIncludeDc(false);

						logger.info("containers search url :" + environment.getProperty(PROBLEM_SEARCH_URL));
						logger.info("payload :" + om.writeValueAsString(probSearch));
						response = SerenityRest.given().contentType("application/json")
								.body(om.writeValueAsString(probSearch)).when()
								.post(environment.getProperty(PROBLEM_SEARCH_URL)).andReturn();
						Failsafe.with(retryPolicy).run(() -> {
							Assert.assertEquals(ErrorCodes.PROBLEM_INVALID_STATUS, 200, response.getStatusCode());
						});
						logger.info("Get Problem Details Response:{}", response.asString());
						JSONArray searchOfProbCntrs = JsonPath.read(response.asString(),
								"$..containers[*].containerId");
						String probCntrString = searchOfProbCntrs.toJSONString();
						List<String> probCntrList = om.readValue(probCntrString, new TypeReference<List<String>>() {
						});
						probCntr = probCntrList.get(1);

						problemAppPage.clickContainerAssociateBtn();
						problemAppPage.clickContainerAssociateNextBtn(probCntr);
						problemAppPage.scanProblemLPN(probCntr);

					}
				}
				probLpn = problemLPNList.get(i);
				Failsafe.with(retryPolicy).run(() -> {
					
					response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
							.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + probLpn
									+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					
//					response = when().get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + probLpn
//							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_RESPONSE, 404, response.getStatusCode());
				});
				Thread.sleep(5000);

			}

			ProblemSearch probSearch = new ProblemSearch();
			probSearch.setDcNumber(Integer.parseInt(environment.getProperty(DC_NUM)));
			probSearch.setDeliveryNbr(Integer.parseInt(deliveryNum));
			probSearch.setIncludeDc(false);

			logger.info("containers search url :" + environment.getProperty(PROBLEM_SEARCH_URL));
			logger.info("payload :" + om.writeValueAsString(probSearch));
			Failsafe.with(retryPolicy).run(() -> {
				response = SerenityRest.given().contentType("application/json").body(om.writeValueAsString(probSearch))
						.when().post(environment.getProperty(PROBLEM_SEARCH_URL)).andReturn();
				Assert.assertEquals(ErrorCodes.PROBLEM_INVALID_STATUS, 200, response.getStatusCode());
			});
			logger.info("Get Problem Details Response:{}", response.asString());
			JSONArray searchOfProbTkt = JsonPath.read(response.asString(), "$..problemCode");
			String probTktsString = searchOfProbTkt.toJSONString();
			List<String> probTktsList = om.readValue(probTktsString, new TypeReference<List<String>>() {
			});
			String prbTkt = probTktsList.get(0);
			ProblemDetail probDetail = new ProblemDetail();
			probDetail.setProblemTicketNumber(prbTkt);

			JSONArray searchOfProbCntrs = JsonPath.read(response.asString(), "$..containers[*]");
			String probCntrString = searchOfProbCntrs.toJSONString();
			List<ProblemContainer> probCntrList = om.readValue(probCntrString,
					new TypeReference<List<ProblemContainer>>() {
					});

			List<ProblemContainer> probCntrsList = new ArrayList<ProblemContainer>();

			for (int i = 0; i < probCntrList.size(); i++) {
				
				response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
						.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + problemLPNList.get(i)
								+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				
//				response = when().get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + problemLPNList.get(i)
//						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_RESPONSE, 404, response.getStatusCode());
				
				ProblemContainer probObj = probCntrList.get(i);
				ProblemContainer probCntr = new ProblemContainer();
				probCntr.setContainerId(probObj.getContainerId());
				probCntr.setContainerQty(probObj.getContainerQty());
				probCntrsList.add(probCntr);

			}
			probDetail.setProblemContainersList(probCntrsList);
			problemDetailList.add(probDetail);
			logger.info(om.writeValueAsString(probDetail));

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(problemDetailList);
			context.set("$.testFlowData.problemDetails",
					JsonPath.parse(om.writeValueAsString(problemDetailList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating problem Details::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating a problem container", e);
		}

	}

	public void resolveProblemTicket() {

		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray listOfProblemTkts = JsonPath.read(testData, "$.testFlowData.problemDetails[*]");
			String problemTktsString = listOfProblemTkts.toJSONString();
			List<ProblemDetail> problemTktsList = om.readValue(problemTktsString,
					new TypeReference<List<ProblemDetail>>() {
					});

			JSONArray listOfPos = JsonPath.read(testData, "$.testFlowData.poDetails[*].poNumber");
			String listOfPosString = listOfPos.toJSONString();
			List<String> poList = om.readValue(listOfPosString, new TypeReference<List<String>>() {
			});
			String poNumber = poList.get(0);

			JSONArray listOfPoLines = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].poLineNumber");
			String poLinesString = listOfPoLines.toJSONString();
			List<String> poLineList = om.readValue(poLinesString, new TypeReference<List<String>>() {
			});
			String poLineNbr = poLineList.get(0);

			for (int i = 0; i < problemTktsList.size(); i++) {
				List problemResolutionDetailList = new ArrayList();
				ProblemDetail problrmTkt = problemTktsList.get(i);

				JSONArray listOfProblemQty = JsonPath.read(testData,
						"$.testFlowData.problemDetails[?(@.problemTicketNumber == \""
								+ problrmTkt.getProblemTicketNumber() + "\")].problemContainersList[*].containerQty");
				String listOfProblemQtyString = listOfProblemQty.toJSONString();
				List<String> problemQtyList = om.readValue(listOfProblemQtyString, new TypeReference<List<String>>() {
				});
				int problemTicketQty = 0;
				for (int j = 0; j < problemQtyList.size(); j++) {
					problemTicketQty = problemTicketQty + Integer.parseInt(problemQtyList.get(j));
				}

				ProblemResolutionDetail resDetail = new ProblemResolutionDetail();
				resDetail.setPoLineNbr(Integer.parseInt(poLineNbr));
				resDetail.setPoNbr(poNumber);
				resDetail.setProblemResolutionType("RECEIVE_AGAINST_ORIGINAL_LINE");
				resDetail.setResolutionQty(problemTicketQty);
				problemResolutionDetailList.add(resDetail);
				ProblemResolution probResolv = new ProblemResolution();
				probResolv.setProblemResolutions(problemResolutionDetailList);
				probResolv.setVersionNbr(1);
				probResolv.setLastChangeUserId("v0k003c");
				logger.info(probResolv.toString());
				logger.info(om.writeValueAsString(probResolv));
				logger.info(environment.getProperty(PROBLEM_ACTION_URL) + problrmTkt.getProblemTicketNumber());
				Failsafe.with(retryPolicy).run(() -> {
					response = SerenityRest.given().contentType("application/json")
							.body(om.writeValueAsString(probResolv)).when()
							.put(environment.getProperty(PROBLEM_ACTION_URL) + problrmTkt.getProblemTicketNumber())
							.andReturn();
					Assert.assertEquals(ErrorCodes.PROBLEM_INVALID_STATUS, 200, response.getStatusCode());
				});
				Failsafe.with(retryPolicy).run(() -> {
					response = response = when()
							.get(environment.getProperty(PROBLEM_GET_URL) + problrmTkt.getProblemTicketNumber());
					Assert.assertEquals(ErrorCodes.PROBLEM_INVALID_STATUS, 200, response.getStatusCode());

					logger.info(response.asString());
					String actualProblemStatus = JsonPath.read(response.asString(), "problemStatus");
					logger.info("Problem Status :" + actualProblemStatus);
					Assert.assertEquals(ErrorCodes.PROBLEM_RESOLVE_STATUS, PROBLEM_STATUS, actualProblemStatus);
				});
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went while Resolving the problem", e);
		}

	}

	public void problemreReceive() {
		try {
			if (Config.DC == DC_TYPE.ACC) {
				Thread.sleep(50000);
			}
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfProblemCntrs = JsonPath.read(testData,
					"$.testFlowData.problemDetails[*].problemContainersList[*]");
			String problemCntrsString = listOfProblemCntrs.toJSONString();
			List<ProblemContainer> problemCntrsList = om.readValue(problemCntrsString,
					new TypeReference<List<ProblemContainer>>() {
					});

			openReceivingAppPage();
			receivingPage.clickOnReceiveMenu();
			receivingPage.clickOnProbrecvBtn();
			for (int i = 0; i < problemCntrsList.size(); i++) {
				ProblemContainer cntrObj = problemCntrsList.get(i);
				int cntrQty = cntrObj.getContainerQty();
				receivingPage.scanProblemContainer(cntrObj.getContainerId());
				receivingPage.clickOnReceiveProbCntr();
				receivingPage.inputReceiveQty(Integer.toString(cntrQty));
				receivingPage.clickOnProbrecv();
				if (i == 0) {
					receivingPage.inputPrinterName();
					receivingPage.selectPrinter();
					receivingPage.clickOnProceedButton();
					receivingPage.clickOnProbrecv();
				}
				receivingPage.clickOnFinishPallet();

			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went while re - receiving problem containers", e);
		}

	}

	public void validateContainerCreationAfterProblemreceiving() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfDeliveries = JsonPath.read(testData, JSON_PATH_DELIVERY);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> delNumberList = om.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = delNumberList.get(0);
			logger.info("Delivery number is " + deliveryNum);

			List containerList = accMongoSteps.getProblemReceivedCntrs(MONGO_SCHEMA, GET_LABEL_COLLECTION, deliveryNum);

			JSONArray listOfProblemCntrs = JsonPath.read(testData,
					"$.testFlowData.problemDetails[*].problemContainersList[*]");
			String problemCntrsString = listOfProblemCntrs.toJSONString();
			List<ProblemContainer> problemCntrsList = om.readValue(problemCntrsString,
					new TypeReference<List<ProblemContainer>>() {
					});

			int probCntrsSum = 0;
			for (int i = 0; i < problemCntrsList.size(); i++) {
				ProblemContainer probObj = problemCntrsList.get(i);
				probCntrsSum = probCntrsSum + probObj.getContainerQty();
				Failsafe.with(retryPolicy).run(() -> {
					
				response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
							.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + probObj.getContainerId()
									+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					
//					response = when().get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + probObj.getContainerId()
//							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					Assert.assertEquals(ErrorCodes.INVENTORY_PROBLEM_CNTR_CONTAINER_RESPONSE, 404, response.getStatusCode());
				});

			}

			Assert.assertEquals(ErrorCodes.PROBLEM_RECEIVE_CNTRS, probCntrsSum, containerList.size());
			for (int i = 0; i < containerList.size(); i++) {
				
				response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
						.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + containerList.get(i)
								+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				
//				response = when().get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + containerList.get(i)
//						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_RESPONSE, 200, response.getStatusCode());
				logger.info(response.asString());
				String actualLocation = JsonPath.read(response.asString(), INVENTORY_LOCATION_PATH);
				Assert.assertEquals(ErrorCodes.INVENTORY_LOCATION_MISMATCH, "OF2", actualLocation);
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went while re - receiving problem containers", e);
		}

	}

	public void validateSorterAfterProblemreceiving() {
		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			List<String> cntrList = new ArrayList<String>();
			JSONArray listOfProblemCntrs = JsonPath.read(testData,
					"$.testFlowData.problemDetails[*].problemContainersList[*]");
			String problemCntrsString = listOfProblemCntrs.toJSONString();
			List<ProblemContainer> problemCntrsList = om.readValue(problemCntrsString,
					new TypeReference<List<ProblemContainer>>() {
					});

			JSONArray listOfDeliveries = JsonPath.read(testData, JSON_PATH_DELIVERY);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> delNumberList = om.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = delNumberList.get(0);
			logger.info("Delivery number is " + deliveryNum);
			List<String> containerList = accMongoSteps.getProblemReceivedCntrs(MONGO_SCHEMA, GET_LABEL_COLLECTION,
					deliveryNum);
			Assert.assertNotEquals(ErrorCodes.RECEIVING_PROBLEM_LOCATION_MISMATCH, 0, containerList.size());
			for (int i = 0; i < containerList.size(); i++) {
				String cntrString = "\"" + containerList.get(i) + "\"";
				cntrList.add(cntrString);
			}

			String sorterLpnSearchResponse = sorterHelper.getLPNtoRDCMapResponse(cntrList);
			logger.info("sorter response :" + sorterLpnSearchResponse);
			DocumentContext parsedResponse = JsonPath.parse(sorterLpnSearchResponse);
			List<String> lpnSearchResLPNList = parsedResponse.read(LPN_SORTERRESPONSE_JSONPATH);

			int probCntrsSum = 0;
			for (int i = 0; i < problemCntrsList.size(); i++) {
				ProblemContainer probObj = problemCntrsList.get(i);
				probCntrsSum = probCntrsSum + probObj.getContainerQty();
			}

			Assert.assertEquals(ErrorCodes.SORTER_LPN_COUNT_MISMATCH, probCntrsSum, lpnSearchResLPNList.size());

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went while re - receiving problem containers", e);
		}

	}

	public void validateProblemStatus() {
		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			List<String> cntrList = new ArrayList<String>();
			JSONArray listOfProblemTkts = JsonPath.read(testData, "$.testFlowData.problemDetails[*]");
			String problemTktsString = listOfProblemTkts.toJSONString();
			List<ProblemDetail> problemTktsList = om.readValue(problemTktsString,
					new TypeReference<List<ProblemDetail>>() {
					});

			for (int i = 0; i < problemTktsList.size(); i++) {
				List problemResolutionDetailList = new ArrayList();
				ProblemDetail problrmTkt = problemTktsList.get(i);
				logger.info("Problem url:" + environment.getProperty(PROBLEM_GET_URL));
				logger.info("Problem url:" + problrmTkt.getProblemTicketNumber());

				Failsafe.with(retryPolicy).run(() -> {
					response = when()
							.get(environment.getProperty(PROBLEM_GET_URL) + problrmTkt.getProblemTicketNumber());
					Assert.assertEquals(ErrorCodes.PROBLEM_INVALID_STATUS, 200, response.getStatusCode());
					logger.info(response.asString());
					String actualProblemStatus = JsonPath.read(response.asString(), "problemStatus");
					logger.info("Problem Status :" + actualProblemStatus);
					Assert.assertEquals(ErrorCodes.PROBLEM_RESOLVE_STATUS, PROBLEM_STATUS_RESOLV, actualProblemStatus);
				});
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went while re - receiving problem containers", e);
		}
	}

}
