package com.walmart.supplychain.dpb.gls.steps.mobile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.dpb.gls.scenariosteps.mobile.GLSTripSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class GLSTripScenarios {

	@Steps
	GLSTripSteps glsTripSteps;

	@Given("^User creates a GLS Trip for \"([^\"]*)\" and \"([^\"]*)\"$")
	public void userCreatesGLSTrip(String itemNumbers, String noOfContainers) throws JsonProcessingException {
		glsTripSteps.createTripFromGLS(itemNumbers, noOfContainers);
	}

	@Then("^AP gets Trip Details from GLS$")
	public void apHitsGLSToGetTripDetails() throws JsonProcessingException {
		glsTripSteps.validateTripDetailsAP();
	}

	@Then("^user validates Optimizer for trip details$")
	public void userValidatesOptimizerForTripDetails() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^FES gets Trip Details from AP$")
	public void userValidatesFESForTripDetails() throws InterruptedException {
		glsTripSteps.validateTripDetailsFES(1);
	}

	@Given("^Trip is assigned to order-filler$")
	public void tripAssigned() throws JsonProcessingException {
		 glsTripSteps.changeTripStatus("Assigned");
	}

	@Given("^User validates FES for trip assignment$")
	public void validateTripAssigned() throws InterruptedException {
		glsTripSteps.validateTripDetailsFES(2);
	}

	@Given("^User validates FES for trip pause$")
	public void validateTripPaused() throws InterruptedException {
		glsTripSteps.validateTripDetailsFES(3);
	}

	@Given("^User validates FES for trip resume$")
	public void validateTripResumed() throws InterruptedException {
		glsTripSteps.validateTripDetailsFES(2);
	}

	@Given("^user logs in to Vision$")
	public void userLogsInToVision() throws JsonProcessingException {
		 glsTripSteps.loginToVisionApp();
	}

	@Given("^User validates FES for trip completion$")
	public void validateTripCompleted() throws InterruptedException {
		glsTripSteps.validateTripDetailsFES(4);
	}

	@Given("^user starts the trip$")
	public void userStartsTheTrip() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^user verifies trip status is changed to \"([^\"]*)\" in GLS$")
	public void userVerifiesTripStatus(String status) throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^Vision Keeps showing pick orientation and user completes \"([^\"]*)\" picks$")
	public void visionKeepsShowingPickOrientationAnduserCompletesPicks(String allOrShort) throws JsonProcessingException {
		 glsTripSteps.confirmPicks(allOrShort);
	}

	@Given("^Vision Keeps showing pick orientation$")
	public void visionKeepsShowingPickOrientation() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^user completes the trip via voice command$")
	public void userCompletesTheTrip() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user receives the Quantity Cut message from GLS $")
	public void user_receives_the_quantity_cut_message_from_gls() {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^User will short the quantity through change quantity$")
	public void shortThroughChangeQuantity() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^user will short the quantity$")
	public void shortQuantity() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^user will pick remaining changed quantity$")
	public void userPickEverythingThroughChangeQuantity() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^user will report short quantity$")
	public void userReportShortQuantity() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Given("^user validates the integration issue$")
	public void userValidateIntegrationIssues() throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}


	@Given("^Vision should give an error$")
	public void visionShouldGiveAnError () throws JsonProcessingException {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user verifies the required Quantity on slot is not available$")
	public void user_verifies_the_required_quantity_on_slot_is_not_available() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user updates Quantity cut and completes the trip with via voice command$")
	public void user_updates_quantity_cut_and_completes_the_trip_with_via_voice_command() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user will pause the ongoing trip$")
	public void user_will_pause_the_ongoing_trip() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user logs in to Vision again$")
	public void user_logs_in_to_vision_again() {
		 glsTripSteps.loginToVisionApp();
	}

	@Then("^user will resume the trip from where user left off and completes the picks$")
	public void user_will_resume_the_trip_from_where_user_left_off_and_completes_the_picks() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user verifies the required items are not available in slot to pick$")
	public void user_verifies_the_required_items_are_not_available_in_slot_to_pick() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user will wait until remaining Quantity are filled on slot$")
	public void user_will_wait_until_remaining_quantity_are_filled_on_slot() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^Manager puts trip on Hold$")
	public void manager_puts_trip_on_hold() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^Manager Split existing trip$")
	public void manager_split_existing_trip() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user validates the first trip will completed$")
	public void user_validates_the_first_trip_will_completed() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user start the second the trip$")
	public void user_start_the_second_the_trip() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^Manager will put a trip on Hold and split the ongoing trip$")
	public void manager_will_put_a_trip_on_hold_and_split_the_ongoing_trip() {
		// GLSTripSteps.loginToMyApps();

	}

	@Then("^user completes the trip$")
	public void user_will_complete_the_first_trip_via_voice_command() {
		 glsTripSteps.changeTripStatus("Completed");

	}

	@Then("^user will resume the trip from current location$")
	public void user_will_resume_the_trip_from_current_location() {
		// GLSTripSteps.loginToMyApps();
	}

	@Then("^user validate the trip is not assigned$")
	public void user_validate_trip_not_assigned() {
		glsTripSteps.validateTripDetailsFES(1);
	}

	@Then("^GLS will publish unassigned trip message$")
	public void glsSendsunassignedTriptoAP() {
		glsTripSteps.changeTripStatus("Unassigned");
	}

	@Then("^GLS will publish pause trip message$")
	public void glsSendsPauseTriptoFES() {
		glsTripSteps.changeTripStatus("Paused");
	}

	@Then("^GLS will publish resume trip message$")
	public void glsSendsResumeTriptoFES() {
		glsTripSteps.changeTripStatus("Resume");
	}
	
	@Then("^AP receives the Quantity Cut message from GLS$")
	public void apReceivedQtyCutMessageFromGLS() {
		glsTripSteps.qtyCutFromGLS();
	}
	
	@Then("^user will validate the trip is unassigned$")
	public void user_validate_trip_is_unassigned() throws InterruptedException {
		glsTripSteps.validateTripDetailsFES(1);
	}
	
	@Then("^User cancels the trip$")
	public void user_cancels_trip() {
		glsTripSteps.changeTripStatus("Cancel");
	}
	
	
	@Then("^GLS publish the Cancelled trip details$")
	public void gls_publishes_cancelled_trip_details() {
		// GLSTripSteps.loginToMyApps();
	}
	
	@Then("^user validates the trip and trip units are cancelled in FES$")
	public void user_validate_trip_is_cancelled() {
		glsTripSteps.validateTripDetailsFES(6);
	}
	
	@Then("^user will face the network issue$")
	public void user_faces_network_issues() {
		// GLSTripSteps.loginToMyApps();
	}
	
	
	
	




}
