package com.walmart.supplychain.nextgen.mm.pages.ui;

import net.thucydides.core.pages.PageObject;
import spring.SpringTestConfiguration;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.selenium.SerenityHelper;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class MMLoginPage extends SerenityHelper{
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//input[@id='username-input']")
	private WebElement userIdField;

	@FindBy(xpath = "//input[@id='password-input']")
	private WebElement passwordField;

	@FindBy(xpath = "//span[text()='Login']")
	private WebElement loginButton;
	
	@FindBy(xpath = "//div[contains(text(),'Move Management')]/..//button[@type='button']")
	private WebElement leftToggleButton;
		
	
	@FindBy(xpath = "//input[@id='login']")
	private WebElement userId;
	
	@FindBy(xpath = "//input[@id='password']")
	private WebElement password;
	
	@FindBy(xpath = "//input[@id='siteNumber']")
	private WebElement siteNum;
	
	@FindBy(xpath = "//*[@id='country']")
	private WebElement country;
	
	@FindBy(xpath = "//ul/li[1]")
	private WebElement selectCountryCode;
	
	
	@FindBy(xpath = "//span[text()='Sign in']")
	private WebElement signIn;

	
	@FindBy(xpath = "//div[text()='Move Management']")
	private WebElement validateHomePage;
	
	@FindBy(xpath = "//label[text()='Container ID']/..//input")
	private WebElement enterContainerNumber;
	
	@FindBy(xpath = "//button[text()='Find Moves']")
	private WebElement moveButton;
	
	@FindBy(xpath = "//tbody/tr[1]/td[7]")
	private WebElement cancelStatusForHoldContainer;  //get OPEN and CANCEllED status
	
	@FindBy(xpath = "//*[@id='root']/div[2]/div/div[1]/form/div[7]/div/div/input")
	private WebElement removeContainerFromSearch;
	
//	@FindBy(xpath = "//*[@id='menu-button']/span[1]")
	@FindBy(xpath = "//span[text()='Action']")
	private WebElement actionButton;
	
	@FindBy(xpath = "//*[@id='actions']/div[3]/ul/li[4]")
	private WebElement forceComplete;
	//html/body/div[2]/div[3]/div[1]/div/div
	@FindBy(xpath = "//label[text()='Select a reason...']/..")
	private WebElement selectDropDownAction;
		
	@FindBy(xpath = "//li[text()='Prime Slot Full']")
	private WebElement selectCompleteReason;
	
	//html/body/div[2]/div[3]/div[3]/button[2]/span[1]
	@FindBy(xpath = "//span[text()='Update']")
	private WebElement updateButtom;
	
	
	@FindBy(xpath = "//table/tbody/tr/td[7]")
	private WebElement verifyCompleteStatus;
	
	@FindBy(xpath = "//table/tbody/tr/td")
	private WebElement selectLpn;
	
	@FindBy(xpath = "//input[@placeholder='Search for container']")
	private WebElement enterContainerNumberUI;
	
	@FindBy(xpath = "//span[text()='Search']")
	private WebElement searchBtn;
	
	@FindBy(xpath = "//span[text()='Action']")
	private WebElement actionButtonUI;
	
	@FindBy(xpath = "//span[text()='Prime Slot Full']")
	private WebElement selectCompleteReasonUI;
	
	public void enteruserIdField(String LoginId) {
		element(userIdField).waitUntilVisible();
		element(userIdField).click();
		element(userIdField).type(LoginId);
	}

	public void enterPasswordField(String password) {
		element(passwordField).waitUntilVisible();
		element(passwordField).click();
		element(passwordField).type(password);
	}

	public void clickLogInButton() {
		element(loginButton).waitUntilVisible();
		element(loginButton).click();
	}
	
	public void getUrl(String url) {
		logger.info(url);
		getDriverInstance().get(url);
	}
	
	public void clickOnLeftToggleButton() {
		waitFor(ExpectedConditions.elementToBeClickable(leftToggleButton));
		element(leftToggleButton).waitUntilVisible();
		element(leftToggleButton).click();
	}
	
	public void loginIntoMM(String LoginId,String pval,String siteNumber,String countryCode) {
		element(userId).waitUntilVisible();
		element(userId).click();
		element(userId).sendKeys(LoginId);
		sleep(1);
		element(password).waitUntilVisible();
		element(password).click();
		element(password).sendKeys(pval);
		sleep(1);

		element(siteNum).waitUntilVisible();
		element(siteNum).click();
		element(siteNum).sendKeys(siteNumber);
		sleep(1);
		
		element(country).waitUntilVisible();
		element(country).waitUntilClickable();
		element(country).click();
		sleep(1);

		element(selectCountryCode).waitUntilVisible();
		element(selectCountryCode).waitUntilClickable();
		element(selectCountryCode).click();
		sleep(1);

		element(signIn).waitUntilVisible();
		element(signIn).waitUntilClickable();
		element(signIn).click();
		element(validateHomePage).waitUntilVisible();
		sleep(1);

	}

	
	public void validateContainerStatus(List<String> containerId ,String value) {
		String b = Keys.BACK_SPACE.toString();

		for(String containerNum:containerId) {
			sleep(3);
		logger.info("containerNum "+containerNum);	
		element(enterContainerNumberUI).waitUntilVisible();
		element(enterContainerNumberUI).sendKeys(b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b +b + b + b + b + b + b + b + b );
		element(enterContainerNumberUI).sendKeys(containerNum);
		sleep(3);
		logger.info("waiting for the visibility of search btn");	
		element(searchBtn).waitUntilVisible();
		element(searchBtn).click();
		logger.info("clicked on search btn");	

		sleep(1);
		element(cancelStatusForHoldContainer).waitUntilVisible();
		sleep(1);
		String cancelStatus=element(cancelStatusForHoldContainer).getText();
		if(value.contains("hold"))
		Assert.assertEquals(ErrorCodes.MM_CONTAINER_CANCELLED_STATUS, "CANCELLED",
				cancelStatus);
		else if (value.contains("received")) {
			Assert.assertEquals(ErrorCodes.MM_CONTAINER_OPEN_STATUS, "OPEN",
					cancelStatus);
			element(selectLpn).waitUntilVisible();
			element(selectLpn).waitUntilClickable();
			element(selectLpn).click();
			sleep(1);
			element(actionButtonUI).waitUntilEnabled();
			element(actionButtonUI).waitUntilClickable();
			sleep(1);
			element(actionButtonUI).click();

			element(forceComplete).waitUntilVisible();
			element(forceComplete).waitUntilClickable();
			element(forceComplete).click();
			sleep(1);
			element(selectDropDownAction).waitUntilVisible();
			element(selectDropDownAction).waitUntilClickable();
			element(selectDropDownAction).click();
			sleep(1);
			element(selectCompleteReasonUI).waitUntilVisible();
			element(selectCompleteReasonUI).waitUntilClickable();
			element(selectCompleteReasonUI).click();
			sleep(1);
			element(updateButtom).waitUntilEnabled();
			element(updateButtom).waitUntilClickable();
			sleep(1);
			element(updateButtom).click();
			
			element(verifyCompleteStatus).waitUntilVisible();
			sleep(1);

			String complateStatus=element(verifyCompleteStatus).getText();
			Assert.assertEquals(ErrorCodes.MM_CONTAINER_COMPLETED_STATUS, "COMPLETED",
					complateStatus);
			
		}
		else
			Assert.assertEquals(ErrorCodes.MM_CONTAINER_CANCELLED_STATUS, "CANCELLED",
					cancelStatus);
	


		}
	}
}
