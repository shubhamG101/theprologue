package com.walmart.supplychain.nextgen.rdcs2s.steps.db;

import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class S2SSteps {

	private int actualFulfillmentRecordCount=0;
	private String deliveryStatusFromOfFullDB=null;
	private String containerStatusFulfillCollInFMDBAfterRec=null;
	private String containerStatusFulfillUnitCollInFMDBAfterSorter=null;
	private int conStatusCodeAfterReceive=0;
	private static final String RDCDELIVERYJSONPATH = "$.testFlowData.outboundDetails..rdcDeliveryDetail.deliveryNumber";
	private static final String RDCCONTAINERSJSONPATH = "$.testFlowData.outboundDetails..containerIds[*]";
	private static final String RDCBOLJSONPATH = "$.testFlowData.outboundDetails..bolNumber";
	private static final String RDCASNDOCIDJSONPATH = "$.testFlowData.outboundDetails..asnDocID";
	private static final String TESTFLOW_DATA="testFlowData";
	private static final String CONTAINER_STATUS_FUL_COL_AFTER_REC="CREATED";
	private static final String CONTAINER_STATUS_FUL_UNIT_COL_AFTER_REC="PLANNED";
	private static final String CONTAINER_STATUS_FUL_COL_AFTER_POSTING_SORTER_MSG="COMPLETED";
	private static final String CONTAINER_STATUS_FUL_UNIT_COL_AFTER_POSTING_SORTER_MSG="PICKED";
	private static final String CONTIANER_STATUS_S2SUPDATE_AFTER_REC="RECEIVED";
	private static final String CONTIANER_STATUS_S2SUPDATE_AFTER_SORTER="SORTED";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(30,
			20);
	
	private String deliveryNumber;
	private List<String> containerList;
	private String bolNumber;
	private String asnDocId;

	@Autowired
	S2SHelper s2sHelper;

	@Autowired
	MongoUtil mongoUtil;

	@Autowired
	JsonUtils jsonUtil;
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	Logger logger = LogManager.getLogger(this.getClass());

	public void readJSONThreadLocal() {
		String testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		DocumentContext parsedJson = JsonPath.parse(testFlowData);
		logger.info("Testflow data before IDM DB update : {}",testFlowData);
		List<String> deliveryNumberList = parsedJson.read(RDCDELIVERYJSONPATH);
		deliveryNumber = deliveryNumberList.get(0);
		containerList = parsedJson.read(RDCCONTAINERSJSONPATH);
		List<String> bolList = parsedJson.read(RDCBOLJSONPATH);
		bolNumber = bolList.get(0);
		List<String> asnDocIdList = parsedJson.read(RDCASNDOCIDJSONPATH);
		asnDocId = asnDocIdList.get(0);
	}
	
	@Step
	public void s2sPrepareTestFlowData() {
		try {
		s2sHelper.prepareTestFLowData();
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while prepareing Test flow data",e);
		}	
	}
	
	@Step
	public void s2sPlaceEcomFileInLinuxLocation() {
		try {
		s2sHelper.placeEcomFlieInLinuxLocation();
	}catch(AssertionError e) {
		throw new TestCaseFailure(e);
	}catch(Exception e) {
		throw new AutomationFailure("Something went wrong while while placing ecom file into Linux location",e);
	}	
	}
	
	@Step
	public void s2sValidateOfflineFulfillmentRecordCount(){
		try {
			logger.info("RDC S2S :: Validating Offline Fulfillment record count for the delivery : {} ",deliveryNumber);
			Failsafe.with(retryPolicy).run(() -> {
				actualFulfillmentRecordCount=(int)s2sHelper.getCountofXDOCRecords(deliveryNumber);
				Assert.assertEquals(ErrorCodes.RDC_S2S_OFFLINE_FULLFILMENT_COUNT,containerList.size(),actualFulfillmentRecordCount);
			});
			logger.info("RDC S2S :: Validated Offline Fulfillment record count for the delivery : {}",deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating offline fulfillment records for the s2s delivery",e);
		}

	}

	@Step
	public void s2sValidateOfflineDeliveryStatus(String deliveryStatus){
		try {
		logger.info("RDC S2S :: Validating Offline Delivery status for the delivery : {} ",deliveryNumber);
		Failsafe.with(retryPolicy).run(() -> {
			deliveryStatusFromOfFullDB= s2sHelper.getdeliveryStatus(deliveryNumber);
			Assert.assertEquals(ErrorCodes.RDC_S2S_OFFLINE_DELILVERY_DB_DELIVERY_STATUS_MISMATCH,deliveryStatus, deliveryStatusFromOfFullDB);
		});
		logger.info("RDC S2S :: Validated Offline Delivery status for the delivery : {} "+deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating offline delivery status s2s delivery",e);
		}
	}

	@Step
	public void s2sValidateContainerStatusInFMAfterRec(){
		try {
		logger.info("RDC S2S :: Validating container status after RECEIVE in FM for the delivery : {}",deliveryNumber);
		for (String container : containerList) {
			logger.info("RDC S2S :: Validating container status in fulfillment_collection DB for the container : {}",container);
			Failsafe.with(retryPolicy).run(() -> {
				containerStatusFulfillCollInFMDBAfterRec= s2sHelper.getContainerFulfillmentColStatusFMDB(deliveryNumber,container);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,CONTAINER_STATUS_FUL_COL_AFTER_REC, containerStatusFulfillCollInFMDBAfterRec);
			});
			logger.info("RDC S2S :: Validated container status in fulfillment_collection DB for the container : {}",container);
		}

		for (String container : containerList) {
			logger.info("RDC S2S :: Validating container status in fulfillment_unit_collection DB for the container : {}",container);
			Failsafe.with(retryPolicy).run(() -> {
				containerStatusFulfillCollInFMDBAfterRec= s2sHelper.getContainerFulfillmentUnitColStatusFMDB(deliveryNumber,container);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,CONTAINER_STATUS_FUL_UNIT_COL_AFTER_REC, containerStatusFulfillCollInFMDBAfterRec);
			});
			logger.info("RDC S2S :: Validated container status in fulfillment_unit_collection DB for the container : {}",container);
		}
		logger.info("RDC S2S :: Validated container status after RECEIVE in FM for the delivery : {}",deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status for in FM after Receiving for s2s delivery",e);
		}
	}

	@Step
	public void s2sValidateContainerStatusInFMAfterPublishingSorterMsg(){
		try {
		logger.info("RDC S2S :: Validating container status after publishing SORTER message in FM for the delivery : {}",deliveryNumber);
		for (String container : containerList) {
			logger.info("RDC S2S :: Validating container status in fulfillment_collection DB for the container : {}",container);
			Failsafe.with(retryPolicy).run(() -> {
				containerStatusFulfillUnitCollInFMDBAfterSorter= s2sHelper.getContainerFulfillmentColStatusFMDB(deliveryNumber,container);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,CONTAINER_STATUS_FUL_COL_AFTER_POSTING_SORTER_MSG, containerStatusFulfillUnitCollInFMDBAfterSorter);
			});
			logger.info("RDC S2S :: Validated container status in fulfillment_collection DB for the container : {}",container);
		}

		for (String container : containerList) {
			logger.info("RDC S2S :: Validating container status in fulfillment_unit_collection DB for the container : {}",container);
			Failsafe.with(retryPolicy).run(() -> {
				containerStatusFulfillUnitCollInFMDBAfterSorter= s2sHelper.getContainerFulfillmentUnitColStatusFMDB(deliveryNumber,container);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,CONTAINER_STATUS_FUL_UNIT_COL_AFTER_POSTING_SORTER_MSG, containerStatusFulfillUnitCollInFMDBAfterSorter);
			});
			logger.info("RDC S2S :: Validated container status in fulfillment_unit_collection DB for the container : {}",container);
		}
		logger.info("RDC S2S :: Validated container status after publishing SORTER message in FM for the delivery : {}",deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status for in FM after publishing sorter for s2s delivery",e);
		}
	}

	@Step
	public void s2sValidateContainerStatusInS2SupdateAftreRec(){
		try {
		logger.info("RDC S2S :: Validating container status in S2S_update after RECEIVING for the delivery : {}",deliveryNumber);
		for (String container : containerList) {
			logger.info("RDC S2S :: Validating container status in S2S_update DB for the container : {}",container);
			Failsafe.with(retryPolicy).run(() -> {
				conStatusCodeAfterReceive= s2sHelper.gets2sUpdateStatusCode(container,CONTIANER_STATUS_S2SUPDATE_AFTER_REC);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,conStatusCodeAfterReceive, 3);
			});
			logger.info("RDC S2S :: Validated container status in S2S_update DB for the container : {}",container);
		}
		logger.info("RDC S2S :: Validated container status in S2S_update after RECEIVING for the delivery : {}",deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status in S2S_update after Receiving for s2s delivery",e);
		}
	}

	@Step
	public void s2sValidateContainerStatusInS2SupdateAftrePublishingSorterMssg(){
		try {
		logger.info("RDC S2S :: Validating container status in S2S_update after publishing SORTER message for the delivery : {}",deliveryNumber);
		for (String container : containerList) {
			logger.info("RDC S2S :: Validating container status in S2S_update DB for the container : {}",container);
			Failsafe.with(retryPolicy).run(() -> {
				conStatusCodeAfterReceive= s2sHelper.gets2sUpdateStatusCode(container,CONTIANER_STATUS_S2SUPDATE_AFTER_SORTER);
				Assert.assertEquals(ErrorCodes.RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS,conStatusCodeAfterReceive, 13);
			});
			logger.info("RDC S2S :: Validated container status in S2S_update DB for the container : {}",container);
		}
		logger.info("RDC S2S :: Validated container status in S2S_update after publishing SORTER message for the delivery : {}",deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status in S2S_update after publishing Sorter message for s2s delivery",e);
		}
	}

	@Step
	public void s2sPublishSorterMessg(){
		try {
		for (String container : containerList) {
			logger.info("RDC S2S :: Publishing Sorter message to the Sorter topic for the container: {}",container);
			s2sHelper.publishSorterMssgOnSorterTopic(s2sHelper.contstructSorterMsg(container));
			logger.info("RDC S2S :: Published Sorter message to the Sorter topic for the container: {}",container);
		}
	}catch(AssertionError e) {
		throw new TestCaseFailure(e);
	}catch(Exception e) {
		throw new AutomationFailure("Something went wrong while publishing Sorter messages for s2s delivery",e);
	}
	}

	@Step
	public void s2svalidateIDOCshipmentDetails() {
		try {
			readJSONThreadLocal();
				logger.info("IDOC :: Validating ASN for asnDocID: {}",asnDocId);
				Response shipmentResponseIDOC = s2sHelper.s2sgetShipmentDetails(asnDocId);
				String strResponseIDOC=shipmentResponseIDOC.asString();
				logger.info("IDOC :: ASN Resp:{}",strResponseIDOC);
				List<String> containerListIDOC = new ArrayList<>();
				if (strResponseIDOC!=null) {

					JSONArray jsonArrayResponseASN = new JSONArray(strResponseIDOC);
					for (int asnIndex = 0; asnIndex < jsonArrayResponseASN.length(); asnIndex++) {
						containerListIDOC.add(jsonArrayResponseASN.getJSONObject(asnIndex).getString("packNumber"));
					}
				}
				for(String containerId:containerList) {
						logger.info("validate container id {}",containerId);
						logger.info("Checking loading container {} in ASN of IDOC");
						Assert.assertTrue(ErrorCodes.IDOC_LOADED_NOT_FOUND_IN_IDOC, 
								containerListIDOC.contains(containerId));
				}
				logger.info("IDOC :: Container count of ecom(Expected):{} and Containers in ASN(Acutual) {} for asnDocId: {}",containerList.size(),containerListIDOC.size(),asnDocId);
				Assert.assertEquals(ErrorCodes.RDC_S2S_CONTAINER_COUNT_MISMATCH,containerList.size(),containerListIDOC.size());
				logger.info("IDOC :: Validated ASN for asnDocID: {}",asnDocId);
				s2sHelper.s2sPostShipmentDetails(bolNumber, asnDocId); 
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validatig ASN for S2S",e);
		}
	}
	
	@Step
	public void validateCtrsRDCS2SDelivery() {
		try {
			readJSONThreadLocal();
			logger.info("Validating S2S IDM delivery in RDC: {}",deliveryNumber);
			Response response = when().get(environment.getProperty("rdc_idm_delivery_ep") + deliveryNumber);
			response.then().statusCode(Constants.SUCESS_STATUS_CODE);
			logger.info("Sucess status received from IDM for S2S delivery:{} at RDC", deliveryNumber);
			Assert.assertEquals(ErrorCodes.RDC_S2S_DELIVERY_CONTAINERS_NOT_MATCHED, true,
					s2sHelper.validateRDCS2SDeliveries(deliveryNumber, response ,containerList));
			logger.info("Sucessfully validated the containers present in S2S IDM delivery in RDC: {}", deliveryNumber);
		}catch(AssertionError e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating Containers in RDC Delivery",e);
		}
	}
}