package com.walmart.supplychain.catalyst.receiving.steps.mobile;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.CatalystItemDetails;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.javautils.JsonPathHelper;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.strati.libs.commons.configuration.ConfigurationException;
import io.strati.libs.commons.configuration.PropertiesConfiguration;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.webdriver.WebDriverFacade;

public class CatalystReceivingHelper extends PageObject  {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	JsonUtils jsonUtils;
	
	@Autowired
	Environment environment;
	
	@Autowired
	CatalystUtil catalystUtil;
	
	@Autowired
	JsonPathHelper jsonPathHelper;

	
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	ObjectMapper om = new ObjectMapper();
	
	 Logger logger = LogManager.getLogger();
	 

	 
	public void setReceiveAndShortageQty(int recvQty) {
		try {
			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPOList = new ArrayList<PoDetail>();
			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {
					if(lineDetail.equals(poLineList.get(0))) {
					lineDetail.setRecvQty(recvQty);
					lineDetail.setRecvType("");
					int shortageQty=Integer.parseInt(lineDetail.getPoVnpkQty())-lineDetail.getRecvQty();
					lineDetail.setShortQty(Integer.toString(shortageQty));
					}
					newpoLineList.add(lineDetail);
				}
				poDetail.setPoLineDetails(newpoLineList);
				newPOList.add(poDetail);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			threadLocal.get().put(TEST_FLOW_DATA, str);
			logger.info((String) threadLocal.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to set Receive Quantity", e);
		}
	}
	
	public void setReceivingInstruction(String LPN, int receiveQty, String receivedStatus) {
		try {
			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<String> item = new ArrayList();
			List<PoDetail> newPOList = new ArrayList<PoDetail>();
			List<ReceivingInstruction> receivingInstructions=new ArrayList<ReceivingInstruction>();
			 
			
			ReceivingInstruction recInstruction = new ReceivingInstruction();
			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				
				for (PoLineDetail lineDetail : poLineList) {
//					String itemNumber=	lineDetail.getItemNumber();
//					item.add(itemNumber);
					if(lineDetail.equals(poLineList.get(0))) {
					recInstruction.setParentContainer(LPN);
					recInstruction.setReceivedQuantity(Integer.toString(receiveQty));
					recInstruction.setReceivedStatus(receivedStatus);
					receivingInstructions.add(recInstruction);
					lineDetail.setReceivingInstructions(receivingInstructions);}
					newpoLineList.add(lineDetail);
				}
				poDetail.setPoLineDetails(newpoLineList);
				newPOList.add(poDetail);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			threadLocal.get().put(TEST_FLOW_DATA, str);
			logger.info((String) threadLocal.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to set Receive Quantity", e);
		}
	}
	
	
	public void setItemReceiveAndRotateDate(String rotateDate) {
		try {
		String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		DocumentContext context = null;
		JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
		String poString = listOfPO.toJSONString();
		List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
		});
		List<PoDetail> newPOList = new ArrayList<PoDetail>();
		
		List<CatalystItemDetails> catalystItemDetails=new ArrayList<CatalystItemDetails>();;
		CatalystItemDetails catalystItemDetail = new CatalystItemDetails();
		for (PoDetail poDetail : poList) {
			List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
			List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
			
			for (PoLineDetail lineDetail : poLineList) {
				if(lineDetail.equals(poLineList.get(0))) {
				catalystItemDetail.setReceiveDate(LocalDate.now().toString());
				catalystItemDetail.setRotateDate(rotateDate);
				lineDetail.setCatalystItemDetails(catalystItemDetail);
				}
				newpoLineList.add(lineDetail);
			}
			poDetail.setPoLineDetails(newpoLineList);
			newPOList.add(poDetail);
		}
		JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
		context = JsonPath.parse(parser.parse(testFlowData));
		context.set("$.testFlowData.poDetails",
				JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
		String str = context.jsonString();
		threadLocal.get().put(TEST_FLOW_DATA, str);
		logger.info((String) threadLocal.get().get(TEST_FLOW_DATA));

	} catch (Exception e) {
		throw new AutomationFailure("Failed to set Receive Quantity", e);
	}
	}
	
	
	public void setOverageReceivingInstruction(String LPN, String receiveQty) {
		try {
			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<String> item = new ArrayList();
			List<PoDetail> newPOList = new ArrayList<PoDetail>();

			JSONArray jsonArrayOfRcvDetails = JsonPath.read(testFlowData, "$.testFlowData..receivingInstructions[*]");

			List<ReceivingInstruction> receivingObjDetail = (List<ReceivingInstruction>) jsonUtils
					.getPojoListfromPath(jsonArrayOfRcvDetails.toJSONString(), ReceivingInstruction.class);

			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();

				for (PoLineDetail lineDetail : poLineList) {

					ReceivingInstruction recInstruction = new ReceivingInstruction();

					if (lineDetail.equals(poLineList.get(0))) {

						recInstruction.setOverrageLPN(LPN);
						recInstruction.setOverrageReceiveQty(receiveQty);
						receivingObjDetail.add(recInstruction);
						lineDetail.setReceivingInstructions(receivingObjDetail);
					}
					newpoLineList.add(lineDetail);
				}
				poDetail.setPoLineDetails(newpoLineList);
				newPOList.add(poDetail);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			threadLocal.get().put(TEST_FLOW_DATA, str);
			logger.info((String) threadLocal.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to set Receive Quantity", e);
		}
	}
	
	
	public void updateRecInstructionPartcularFieldUnderTestflowdata(String fieldName, String fieldValue, String lpn) {
		
		try {
			
			String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			
			LinkedHashMap<String, String> receivingInstructionsDetail = jsonPathHelper.getFirst(runTimeData, 
					"$.testFlowData..receivingInstructions[?(@.parentContainer=='"+lpn+"')]");
			ReceivingInstruction receivingInstructionObj =  (ReceivingInstruction) jsonUtils.getPojofromJsonObject(receivingInstructionsDetail, ReceivingInstruction.class);

			switch(fieldName) {
			
				case "channel":
					receivingInstructionObj.setChannelType(fieldValue);
					break;
				
			}
			
			JSONObject recInstructionJsonObject = jsonUtils.convertToJsonObject(receivingInstructionObj);
			String testFlowDataUpdated = jsonUtils.setJsonAtJsonPath(runTimeData, recInstructionJsonObject,
					"$.testFlowData..receivingInstructions[?(@.parentContainer=='"+lpn+"')]");
			
			threadLocal.get().put(TEST_FLOW_DATA, testFlowDataUpdated);
			logger.info("Updated {} field under Receiving instruction as {} value in test flow data!!", fieldName, fieldValue);
			logger.info("testFlowData after updating Receiving instruction:{}", testFlowDataUpdated);
			
		} catch (Exception e) {
			throw new AutomationFailure("Failed to update particular fields for Receiving instruction under test flow data", e);
		}
	}
	
	
	public ReceivingInstruction setRecInstructions(HashMap<String, String> instructionsData) {
		
		ReceivingInstruction recInstruction = new ReceivingInstruction();
		recInstruction.setParentContainer(instructionsData.get("lpn"));
		recInstruction.setReceivedQuantity(instructionsData.get("recievedQty"));
		recInstruction.setReceivedStatus(instructionsData.get("receivedStatus"));
		
		switch(instructionsData.get("receivedStatus")) {
			
			case "Return On Carrier" :
				recInstruction.setReasonForReceivedStatus(instructionsData.get("receivedStatus_Reason"));
				break;
				
			case "Problems" :
				recInstruction.setReasonForReceivedStatus(instructionsData.get("receivedStatus_Reason"));
				break;
			
			case "Damage" :
				recInstruction.setReasonForReceivedStatus(instructionsData.get("receivedStatus_Reason"));
				recInstruction.setDamageQty(Integer.parseInt(instructionsData.get("damageQty")));
				recInstruction.setIsDamage(Boolean.getBoolean(instructionsData.get("isDamage")));
				break;
			
			case "Available" 	:
				logger.info("Status reason not required to be set in testflowdata");
				break;
				
			case "QC Inspect" :
				logger.info("Status reason not required to be set in testflowdata");
				break;
		}
		
		return recInstruction;
	}
	
	
	public void addFullReceivingInstructionUnderTestflowdata(List<ReceivingInstruction> instructionList, String poNumber, String itemNumber) {
		
		try {
			JSONArray instructJSONArry;
			String testFlowData = String.valueOf(threadLocal.get().get(TEST_FLOW_DATA));
			instructJSONArry = jsonUtils.converyListToJsonArray(instructionList);

			JSONArray existingRecvInstruc = JsonPath.read(testFlowData,
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.itemNumber=='"+itemNumber+"')].receivingInstructions[*]");

			for (int i = 0; i < instructJSONArry.size(); i++) {
				JSONObject obj = new JSONObject();
				obj = (JSONObject) instructJSONArry.get(i);
				existingRecvInstruc.add(obj);
			}
			
			logger.info("UPDATED RECV INSTC:" + existingRecvInstruc.toJSONString());
			
			
			String testFlowDataUpdated = jsonUtils.setJsonAtJsonPath(testFlowData, existingRecvInstruc,
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.itemNumber=='"+itemNumber+"')].receivingInstructions");
			
			threadLocal.get().put("testFlowData", testFlowDataUpdated);
			logger.info("TestFlowData after updating receive instruction:" + testFlowDataUpdated);
			
		} catch (ParseException | JsonProcessingException e) {
			logger.info("Error while updating receive instruction");
			throw new AutomationFailure("Error while adding receive instruction under test flow data", e);
		}
		
	}
	
	public void updatePOLineDetailsSpecificFieldUnderTestflowdata(String poNumber, String itemNumber, String fieldName, String fieldValue) {
		
		try {
			String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			
			//these commented code can also be used for to set poLine details
			/*JSONArray jsonArrayOfPOLineDetails = JsonPath.read(runTimeData, 
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')]..poLineDetails[?(@.itemNumber=='"+itemNumber+"')]");
			PoLineDetail poLineDetailObj = (PoLineDetail) jsonUtils.getPojofromJsonObject(jsonArrayOfPOLineDetails.get(0), PoLineDetail.class);*/
			
			LinkedHashMap<String, String> poLineDetail = jsonPathHelper.getFirst(runTimeData, 
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')]..poLineDetails[?(@.itemNumber=='"+itemNumber+"')]");
			PoLineDetail poLineDetailObj =  (PoLineDetail) jsonUtils.getPojofromJsonObject(poLineDetail, PoLineDetail.class);

			switch(fieldName) {
			
				case "boh":
					
					List<String> itemList = new ArrayList<String>();
					itemList.add(itemNumber);
					String inventoryBOHResponse = catalystUtil.getItemBOH(itemList);
					logger.info("Inventory BOh Response is :"+inventoryBOHResponse);
					JSONArray listOfBOH = JsonPath.read(inventoryBOHResponse, "$.itemBohDistribution[?(@.itemNumber == '"+itemNumber+ "')].groupByAttrBohDistribution[*].bohQty");
					String bohString = listOfBOH.toJSONString();
					List<String> bohList = om.readValue(bohString, new TypeReference<List<String>>() {
					});
					int bohQty = 0;
					for (String qty : bohList) {
						bohQty += Integer.parseInt(qty);
					}
					poLineDetailObj.setBoh(bohQty);
					break;
					
				
				case "wac" :
					poLineDetailObj.setWac(Double.parseDouble(poLineDetailObj.getWhpkSellPrice()));
					break;
					
				
				case "recvQty" :
					poLineDetailObj.setRecvQty(Integer.parseInt(fieldValue));
					break;
					
				
				case "shortQty" :
					int shortageQty=Integer.parseInt(poLineDetailObj.getPoVnpkQty())-poLineDetailObj.getRecvQty();
					poLineDetailObj.setShortQty(Integer.toString(shortageQty));
					break;
					
				
				case "rejectQty" :
					poLineDetailObj.setRejectQty(fieldValue);
					break;
					
				case "damageQty" :
					poLineDetailObj.setDamageQty(fieldValue);
					break;
				
			}
			
			JSONObject poLIneJsonObject = jsonUtils.convertToJsonObject(poLineDetailObj);
			String testFlowDataUpdated = jsonUtils.setJsonAtJsonPath(runTimeData, poLIneJsonObject,
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')]..poLineDetails[?(@.itemNumber=='"+itemNumber+"')]");
			
			threadLocal.get().put(TEST_FLOW_DATA, testFlowDataUpdated);
			logger.info("Updated {} field under PO line as {} value in test flow data!!", fieldName, fieldValue);
			logger.info("testFlowData after updating PO line details:{}", testFlowDataUpdated);
			
		} catch (Exception e) {
			throw new AutomationFailure("Error while updating PO line details under test flow data", e);
		}
	}
	
	
	public void updateCatalystItemsDetailsSpecificFieldUnderTestflowdata(String poNumber, String itemNumber, String fieldName, String fieldValue) {
		
		try {
			String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			
			LinkedHashMap<String, String> catalystItemDetail = jsonPathHelper.getFirst(runTimeData, 
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.itemNumber=='"+itemNumber+"')].catalystItemDetails");
			CatalystItemDetails catalystItemDetailObj =  (CatalystItemDetails) jsonUtils.getPojofromJsonObject(catalystItemDetail, CatalystItemDetails.class);

			switch(fieldName) {
			
				case "receiveDate" :
					catalystItemDetailObj.setReceiveDate(fieldValue);
					break;
					
				
				case "rotateDate" :
					catalystItemDetailObj.setRotateDate(fieldValue);
					break;
					
				//further cases will be added based on requirements
				
			}
			
			JSONObject catalystItemJsonObject = jsonUtils.convertToJsonObject(catalystItemDetailObj);
			String testFlowDataUpdated = jsonUtils.setJsonAtJsonPath(runTimeData, catalystItemJsonObject,
					"$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.itemNumber=='"+itemNumber+"')].catalystItemDetails");
			
			threadLocal.get().put(TEST_FLOW_DATA, testFlowDataUpdated);
			logger.info("Updated {} field under Catalyst item as {} value in test flow data!!", fieldName, fieldValue);
			logger.info("testFlowData after updating Catalyst item details:{}", testFlowDataUpdated);
			
		} catch (Exception e) {
			throw new AutomationFailure("Error while updating catalyst item details for particular PO line under test flow data", e);
		}
	}
	
	public void updateConfig(String str) throws ConfigurationException, InterruptedException {
		PropertiesConfiguration config = null;
		config = new PropertiesConfiguration(environment.getProperty("env_file_path"));
		String configValue = (String) config.getProperty("webdriver.drivertype");
		try {
			if (getDriver() != null) {
				getDriver().quit();
			}
			if ((str.equals("false")) && (configValue.equals("appium"))) {
				config.setProperty("webdriver.drivertype", "notappium");
				config.save();
				Thread.sleep(10000);
			}
			else if ((str.equals("true")) && (configValue.equals("notappium"))) {
				config.setProperty("webdriver.drivertype", "appium");
				config.save();
				Thread.sleep(10000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	public AndroidDriver<AndroidElement> getAndroidDriver() {
//		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
//		}
	
	public void setPutawayToLocationUnderReceivingInstruction(String putawayToLocation) {
		try {
			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<String> item = new ArrayList();
			List<PoDetail> newPOList = new ArrayList<PoDetail>();
			List<ReceivingInstruction> receivingInstructions=new ArrayList<ReceivingInstruction>();
			 
			
			ReceivingInstruction recInstruction = new ReceivingInstruction();
			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {
					if(lineDetail.equals(poLineList.get(0))) {
					recInstruction.setPutawayToLocation(putawayToLocation);
					receivingInstructions.add(recInstruction);
					lineDetail.setReceivingInstructions(receivingInstructions);}
					newpoLineList.add(lineDetail);
				}
				poDetail.setPoLineDetails(newpoLineList);
				newPOList.add(poDetail);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			threadLocal.get().put(TEST_FLOW_DATA, str);
			logger.info((String) threadLocal.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to set Putaway To Location ", e);
		}
	}
}
