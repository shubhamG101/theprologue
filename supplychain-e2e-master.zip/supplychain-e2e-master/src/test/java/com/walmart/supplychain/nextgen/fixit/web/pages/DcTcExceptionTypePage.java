package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class DcTcExceptionTypePage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(xpath = "//*[text()='Wrong Pack']")
	private WebElement wrongPack_Link;
	
	@FindBy(xpath = "//*[text()='Overage']")
	private WebElement overrage_Link;
	
	@FindBy(xpath = "//*[text()='Hazmat']")
	private WebElement hazmat_Link;
	
	@FindBy(xpath = "//*[text()='Quality Issue']")
	private WebElement quality_Link;
	
	@FindBy(xpath = "//*[contains(text(),'Date')]")
	private WebElement date_Link;
	
	@FindBy(xpath = "//*[text()='Inboud Damage']")
	private WebElement inboundDamage_Link;
	
	@FindBy(xpath = "//*[text()='Not on PO']")
	private WebElement nop_Link;
	
	@FindBy(xpath = "//*[text()='Not Walmart freight']")
	private WebElement notWalmartFreight_Link;
	
	@FindBy(xpath = "//*[text()='Wrong DC']")
	private WebElement wrongShipment_Link;
	
	@FindBy(xpath = "//*[@for='damage']")
	private WebElement damage_Link;
	
	@FindBy(xpath = "//*[text()='Recall']")
	private WebElement recall_Link;

	//WFS
//	@FindBy(xpath = "//*[text()='Missing Po']")
//	private WebElement missingPo_Link;
//
//	@FindBy(xpath = "//*[text()='3P Rcv Damage']")
//	private WebElement rcvDamage_Link;
//
//	@FindBy(xpath = "//*[text()='Rework']")
//	private WebElement rework_Link;
//
//	@FindBy(xpath = "//*[text()='Unidentified Item']")
//	private WebElement unidentifiedItem_Link;
//
//	@FindBy(xpath = "//*[text()='Cancelled PO/POlines']")
//	private WebElement cancelledPo_Link;
//
//	@FindBy(xpath = "//*[text()='Wrong DC/FC']")
//	private WebElement wrongDcFc_Link;
	
	public void selectNotWalmartFreight() {
		element(notWalmartFreight_Link).waitUntilClickable();
		element(notWalmartFreight_Link).click();
	}
	
	public void clickHazmat() {
		element(hazmat_Link).waitUntilClickable();
		click(hazmat_Link);
	}
	
	public void clickWrongShipment() {
		element(wrongShipment_Link).waitUntilClickable();
		click(wrongShipment_Link);
	}
	
	public void clickWrongPack() {
		element(wrongPack_Link).waitUntilClickable();
		click(wrongPack_Link);
	}
	
	public void clickOverrage() {
		element(overrage_Link).waitUntilClickable();
		click(overrage_Link);
	}
	
	public void clickNOP() {
		click(nop_Link);
	}
	
	public void clickDamage() {
		click(damage_Link);
	}
	
	public void clickDateIssue() {
		click(date_Link);
	}

	public void clickQualityIssue() {
		click(quality_Link);
	}

	public void clickRecall() {
		click(recall_Link);
	}
	
//	public void clickMissingPo() {
//		click(missingPo_Link);
//	}
//
//	public void click3pRcvDamage() {
//		click(rcvDamage_Link);
//	}
//
//	public void clickRework() {
//		click(rework_Link);
//	}
//
//	public void clickUnidentifiedItem() {
//		click(unidentifiedItem_Link);
//	}
//
//	public void clickCancelledPo() {
//		click(cancelledPo_Link);
//	}
//
//	public void clickWrongDcFc() {
//		click(wrongDcFc_Link);
//	}
}
