package com.walmart.supplychain.thor.podetails.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import net.jodah.failsafe.RetryPolicy;

public class ThorTokenPage extends SerenityHelper {

	WebDriver driver;
	Logger logger = LoggerFactory.getLogger(ThorTokenPage.class);
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	PropertyResolver propertyResolver = new PropertyResolver();

	@FindBy(xpath = "//h5[@class='col-sm-12']")
	private WebElement token;

	@FindBy(xpath = "//button[contains(text(),'Copy to Clipboard')]")
	private WebElement copyBtn;

	@FindBy(xpath = "//input[@name='loginfmt']")
	private WebElement username;

	@FindBy(xpath = "//input[@id='idSIButton9']")
	private WebElement userNextBtn;

	@FindBy(xpath = "//input[@id='i0118']")
	private WebElement password;

	@FindBy(xpath = "//input[@value='Sign in']")
	private WebElement signin;

	@FindBy(xpath = "//input[@value='Yes']")
	private WebElement popupYes;

	public String getSecurityToken() {
		element(token).waitUntilVisible();
		for (int i = 0; 1 < 4; i++) {
			if (token.getText().length() > 10) {
				return token.getText();
			}
		}
	}

	public void loginToThor(String user, String pass,boolean loginFlag) {
		if(loginFlag) {
		element(username).waitUntilVisible();
		element(username).type(user);
		click(userNextBtn);
		element(password).waitUntilVisible();
		element(password).type(pass);
		click(signin);
		click(popupYes);
		}
	}

	public void getUrl(String url) {
		try {
			getDriver().get(url);
			Thread.sleep(3000);
		} catch (Exception e) {

			throw new AutomationFailure("Failed to Load Thor security url:", e);
		}
	}

	public Headers getAuthenticationHeader(String url, String userName, String password,boolean loginFlag) {

		getUrl(url);
		loginToThor(userName, password,loginFlag);
		String securirtToken = getSecurityToken();
		logger.info("security token"+securirtToken);
		Header authorization = new Header("Authorization", securirtToken);
		Header contentType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(authorization);
		headerList.add(contentType);
		return new Headers(headerList);
	}
}