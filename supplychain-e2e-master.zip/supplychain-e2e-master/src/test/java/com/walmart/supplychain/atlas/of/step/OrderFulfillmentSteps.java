package com.walmart.supplychain.atlas.of.step;

import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.of.pages.webservices.OrderFulfillmentHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderFulfillmentSteps {
	Response[] response;
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	OrderFulfillmentHelper ofHelper;
	@Autowired
	JavaUtils javaUtils;
	@Autowired
	JsonUtils jsonUtils;
	@Autowired
	Environment environment;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	Logger logger = LogManager.getLogger(this.getClass());

	@Step
	public void verifySoftAllocation() throws JSONException {
		try {
			Failsafe.with(retryPolicy).run(() -> {
			ofHelper.verifySoftAllocationPicks();
			});
			logger.info("Soft Aloocation verfified");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with Soft Aloocation verfifies	", e);
		}

	}

}
