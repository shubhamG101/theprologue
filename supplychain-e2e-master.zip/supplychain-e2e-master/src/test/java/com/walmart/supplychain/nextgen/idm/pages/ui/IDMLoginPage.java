package com.walmart.supplychain.nextgen.idm.pages.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.selenium.SerenityHelper;

public class IDMLoginPage extends SerenityHelper {
	@FindBy(xpath="//div[span[label[contains(text(),'Username')]]]/input")
	private WebElement userNameTextBox;
	
	@FindBy(xpath="//div[span[label[contains(text(),'Password')]]]/input")
	private WebElement passwordTextBox;
	
	@FindBy(xpath="//mat-select[@placeholder='Business Unit']")
	//label[contains(text(),'Business Unit')]
	private WebElement businessUnitSelectBox;
	
	@FindBy(xpath="//mat-select[@placeholder='Domain']")
	private WebElement domainSelectBox;
	
	@FindBy(xpath="//mat-option[span[contains(text(),'local')]]")
	private WebElement localDomainOption;
	
	@FindBy(xpath="//span[contains(text(),'SIGN IN')]")
	private WebElement signInbutton;
	
	@FindBy(xpath="//i[text()='menu']")
	private WebElement inboudDocMenu;
	
	@FindBy(xpath="//div[contains(text(),'Logout')]")
	private WebElement logoutButton;
	
	public void getURL(String url) {
		getDriverInstance().get(url);
	}
	
	public void enterUserName(String userName) {
		element(userNameTextBox).waitUntilVisible();
		element(userNameTextBox).waitUntilClickable();
		element(userNameTextBox).type(userName);
	}
	
	public void enterPassword(String password) {
		element(passwordTextBox).waitUntilVisible();
		element(passwordTextBox).waitUntilClickable();
		element(passwordTextBox).type(password);
	}

	public void selectDCNumber(String dcNumber) {
		element(businessUnitSelectBox).waitUntilVisible();
		element(businessUnitSelectBox).waitUntilClickable();
		element(businessUnitSelectBox).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		getDriverInstance().findElement(By
				.xpath("//mat-option[span[contains(text(),'"+dcNumber+"')]]"))
				.click();
	}
	
	public void selectdomain() {
		element(domainSelectBox).waitUntilVisible();
		element(domainSelectBox).waitUntilClickable();
		element(domainSelectBox).click();
		element(localDomainOption).waitUntilClickable();
		element(localDomainOption).click();
	}
	
	public void clickOnSignInButton() {
		element(signInbutton).waitUntilVisible();
		element(signInbutton).waitUntilClickable();
		element(signInbutton).click();
	}
	
	public void clickOnInboudDocMenu() {
		element(inboudDocMenu).waitUntilVisible();
		element(inboudDocMenu).waitUntilClickable();
		element(inboudDocMenu).click();
	}
	
	public void clickOnLogoutButton() {
		element(logoutButton).waitUntilVisible();
		element(logoutButton).waitUntilClickable();
		element(logoutButton).click();
	}
}
