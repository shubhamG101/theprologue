package com.walmart.supplychain.catalyst.loading.steps.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.loading.pages.mobile.CatalystLoadingPage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystByMobilePage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;

import net.jodah.failsafe.FailsafeException;
import net.thucydides.core.steps.ScenarioSteps;

public class CatalystLoadingSteps extends ScenarioSteps {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	CatalystLoadingPage catalystLoadingPage;

	
	@Autowired
	Environment environment;
	
	
	
	public void performWrapping() throws InterruptedException {	
		try {
			catalystLoadingPage.verifySelectJobTextIsDisplayed();
			catalystLoadingPage.clickOnWrappingOption();
			catalystLoadingPage.clickOnSaveButton();
			catalystLoadingPage.verifyWrappingTitleIsDisplayed();
			catalystLoadingPage.clickOnHandheldKeyLpnLink();
			catalystLoadingPage.verifyHandheldKeyTitleIsDisplayed();
			catalystLoadingPage.enterLpn(environment.getProperty("wrapingLPN"));
			catalystLoadingPage.clickOnDialogYesButton();
			catalystLoadingPage.clickOnHaulMoveSingleLink();
			catalystLoadingPage.verifyHandheldLocationTitleIsDisplayed();
			catalystLoadingPage.enterLocation(environment.getProperty("loadingLocation"));
			catalystLoadingPage.clickOnDialogYesButton();
			catalystLoadingPage.clickOnSignOutButton();
			catalystLoadingPage.verifyDoneForDayTitleIsDisplayed();
			catalystLoadingPage.clickOnDialogYesButton();
		
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to add Location and Dock door details", e);
		}
	}
		public void performLoading() throws InterruptedException {	
			try {
				
				catalystLoadingPage.verifySelectJobTextIsDisplayed();
				catalystLoadingPage.clickOnLoadingOption();
				catalystLoadingPage.clickOnSaveButton();
				catalystLoadingPage.verifyScanStagingLaneTitleIsDisplayed();
				catalystLoadingPage.clickOnHandheldKeyLpnLink();
				catalystLoadingPage.verifyHandheldLocationTitleIsDisplayed();
				catalystLoadingPage.enterLocation(environment.getProperty("loadingLocation"));
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.clickOnLoadButton();
				catalystLoadingPage.verifyEmptyPalletStackTextIsDisplayed();
				
				catalystLoadingPage.clickOnHandheldKeyLpnLink();
				catalystLoadingPage.verifyHandheldLocationTitleIsDisplayed();
				catalystLoadingPage.enterLocation(environment.getProperty("outboundDoor"));
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyDoorSafetyChecklistTitleDisplayed();
				catalystLoadingPage.verifyCorrectDockDoorSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyDockPlateSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyTrailerLightSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyFloorBoardsSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyFloorFreeOfSpilledLiquidSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyTrailerDockDoorHeightSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyConfirmEmptyPalletStackDialogIsDisplayed();
				catalystLoadingPage.clickOnConfirmButton();
				catalystLoadingPage.clickOnHandheldKeyLpnLink();
				catalystLoadingPage.verifyHandheldKeyTitleIsDisplayed();
				catalystLoadingPage.enterLpn(environment.getProperty("wrapingLPN"));
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.clickOnHandheldKeyLpnLink();
				catalystLoadingPage.verifyHandheldLocationTitleIsDisplayed();
				catalystLoadingPage.enterLocation(environment.getProperty("outboundDoor"));
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyHandheldKeyTitleIsDisplayed();
				catalystLoadingPage.enterLpn(environment.getProperty("wrapingLPN"));
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyShipmentReadyToCloseTextIsDisplayed();
				catalystLoadingPage.clickOnCloseShipmentButton();
				catalystLoadingPage.verifyTrailerZoneTempMsgIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyDoorSafetyChecklistTitleDisplayed();
				catalystLoadingPage.verifyIsLoadSecureSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifyDockPlateRetractedSafetyQuestionIsDisplayed();
				catalystLoadingPage.clickOnDialogYesButton();
				catalystLoadingPage.verifySwingDoorTrailerQuestionIsDisplayed();
				catalystLoadingPage.clickOnYesSwingDoorButton();
				catalystLoadingPage.clickOnOkButton();
				catalystLoadingPage.enterSealNumber("Seal1234");
				catalystLoadingPage.clickOnDialogYesButton();
			   catalystLoadingPage.verifyCloseAndLatchDockDoorDialogIsDisplayed();
			   catalystLoadingPage.clickOnDialogYesButton();
			   catalystLoadingPage.verifyShipmentCompletedMsgIsDisplayed();
			}
			catch (AssertionError | FailsafeException e) {
				throw new TestCaseFailure(e);
			} catch (Exception e) {
				throw new AutomationFailure("Failed to add Location and Dock door details", e);
			}
	}
}
