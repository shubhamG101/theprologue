package com.walmart.supplychain.baja.inventory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.XmlParser;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;

import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BajaInventorysteps {

	@Steps
	XmlParser xmlParser;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
		
	@Steps
	InventorySteps invSteps;
	
	@Autowired
	SpringJmsUtils springJmsUtils;
	
	@Value("${inventoryCreateQueue}")
	String inventoryQueueBaja;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BajaInventorysteps.class);
	JsonUtils jsonUtil = new JsonUtils();

	
	public void createInventory() throws ParseException, InterruptedException, IOException{
		/**
		 * This is for parsing the xml and populating the container Details in testFlow json
		 */
		
		xmlParser.parseInventoryXml(FileNames.BAJA_INVENTORY_CREATION_80);
		xmlParser.parseInventoryXml(FileNames.BAJA_INVENTORY_CREATION_81);
		xmlParser.updateInventoryDetails();
		
		/** 
		 * This is for publishing xml for inventory creation
		*/
		LOGGER.info("Publishing message for Load unit creation "+FileNames.BAJA_INVENTORY_CREATION_80);
		LOGGER.info("File content is" + jsonUtil.readFile("src//test//resources//TestData//Baja//InventoryCreation80.xml"));
		
		springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ,
							Config.DC, inventoryQueueBaja, jsonUtil.readFile("src//test//resources//TestData//Baja//InventoryCreation80.xml"));
		
		Thread.sleep(5000);
		
		LOGGER.info("Publishing message for Load unit creation "+FileNames.BAJA_INVENTORY_CREATION_81);
		springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ,
				Config.DC, inventoryQueueBaja, jsonUtil.readFile("src//test//resources//TestData//Baja//InventoryCreation81.xml"));

	}

	public void validateInventory() {
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> lpnIds = JsonPath.read(testFlowData, "$..loadUnitId"); 
		Assert.assertNotEquals(ErrorCodes.BAJA_LOADUNITS_NOT_CREATED, 0, lpnIds.size());

		for(int i=0;i<lpnIds.size();i++) {
			invSteps.validateAndGetContainerResponse(lpnIds.get(i));	
		}
	}
}
