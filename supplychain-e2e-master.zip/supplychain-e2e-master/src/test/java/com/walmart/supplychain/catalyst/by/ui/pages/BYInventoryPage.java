package com.walmart.supplychain.catalyst.by.ui.pages;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.framework.utilities.selenium.UiActionsHelper;

import spring.SpringTestConfiguration;

import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.parser.ParseException;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYInventoryPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;

	@Autowired
	UiActionsHelper uiActionsHelper;

	@Autowired
	BYOutboundPage byOutboundPage;

	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	CatalystUtil catalystUtil;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String IB_ITEM_NUMBER_JSON_PATH = "$.testFlowData.ordersDetails..itemNumber";
	

	// ######################################### Generic Elements #################################

	@FindBy(xpath = "//table[contains(@class,'x-autocontainer')]//input[@placeholder='Search']")
	private WebElement headerSearchBox;

	@FindBy(xpath = "//div[@role='presentation'][text()='Loading']")
	public WebElement loadingIndicator;
	
	
	@FindBy(xpath = "//div[contains(@id,'lpn')]//tr/td/div/div[@class='x-grid-row-checker']")
	public WebElement lpnCheckBox;
	
	
	@FindBy(xpath = "//span[text()='Actions']/parent::span[contains(@id,'wmMultiViewActionButton')]")
	public WebElement actionsButton;
	
	@FindBy(xpath = "//span[text()='Change Inventory Status']")
	public WebElement changeInventoryStatusOption;
	
	
	@FindBy(xpath = "//label[text()='Status']/ancestor::tbody//table//div[contains(@class,'rp-icon-expanded')]")
	public WebElement StatusExpandButton;

	@FindBy(xpath = "//div[contains(@id,'InventoryStatusChangeWindow')]//span[text()='OK']/ancestor::a[1]//span[contains(@id,'btnIconEl')]")
	public WebElement okButtonInventoryStatusChangeWindow;
	
	@FindBy(xpath = "//div[contains(@id,'window')]//span[text()='OK']/ancestor::a[1]//span[contains(@id,'btnIconEl')]")
	public WebElement resultsOkButton;
	
	
	@FindBy(xpath = "//span[text()='LPNs']/ancestor::a[1]//span[contains(@id,'btnIconEl')]")
	public WebElement lpnsTab;
	
	@FindBy(xpath = "//label[contains(text(),'Inventory status changed')]")
	public WebElement inventoryStatusChangedLabel;
	
	
	private WebElement inputFilterBox(String tabName) {
		return getDriver()
				.findElement(By.xpath("//div[contains(@id,'" + tabName + "')]//input[contains(@id,'Filter')][@style]"));
	}

	public WebElement inboundWorkingFrame(String frameName) {
		return getDriver().findElement(By.xpath("//iframe[contains(@name,'wm." + frameName + "')]"));
	}
	
	public WebElement inboundPartialFrameName(String partialFrameName) {
		return getDriver().findElement(By.xpath("//iframe[contains(@name,'" + partialFrameName + "')]"));
	}
	
	private WebElement getButtonByText(String buttonText) {
		return getDriver().findElement(By.xpath("//a[normalize-space()='" + buttonText + "'][contains(@id,'button')]"));
	}
	
	private WebElement textOfDropDownOption(String text) {
		return getDriver().findElement(By.xpath("//div/ul/li[contains(text(),'" + text + "')]"));
	}
	
	public WebElement selectOptionFromDropDownContainsText(String text) {

		return getDriver().findElement(By.xpath("//div/ul/li[contains(text(),'" + text + "')]"));
	}

	
	// ######################################### Generic Methods#################################

	public void enterValueUnderFilterTB(String tabName, String fieldName, String value) {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(inputFilterBox(tabName)).waitUntilVisible();

		String filterCriteria = fieldName + "=" + value;
		element(inputFilterBox(tabName)).clear();
		element(inputFilterBox(tabName)).sendKeys(filterCriteria + Keys.ENTER);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		logger.info("Entered the value {} to be filtered in filter box under {} tab ==========", value, fieldName);
	}

	//This will use to filter with the operator [=/Or/And]
	/*
	 * public void enterValueUnderFilterTB(String tabName, String fieldName, String
	 * operator, String value) {
	 * element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120,
	 * TimeUnit.SECONDS); element(inputFilterBox(tabName)).waitUntilVisible();
	 * 
	 * String filterCriteria = fieldName + operator + value;
	 * element(inputFilterBox(tabName)).clear();
	 * element(inputFilterBox(tabName)).sendKeys(filterCriteria + Keys.ENTER);
	 * element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120,
	 * TimeUnit.SECONDS); logger.
	 * info("Entered the value {} to be filtered in filter box under {} tab =========="
	 * , value, fieldName); }
	 */

	public void switchToFrame(String frameName) {
		getDriver().switchTo().frame(inboundWorkingFrame(frameName));
		logger.info("Switched to working frame {} -----> ", frameName);
	}
	
	public void switchToFrameByPartialName(String partialFrameName) {
		getDriver().switchTo().frame(inboundPartialFrameName(partialFrameName));
		logger.info("Switched to working frame {} -----> ", partialFrameName);
	}

	public void switchToFrameWithElement(WebElement element) {
		getDriver().switchTo().frame(element);
		logger.info("Switched to working frame {} -----> ", element);
	}

	private WebElement textboxContainsName(String name) {
		return getDriver().findElement(By.xpath("//input[contains(@name,'" + name + "')]"));
	}

	public void switchToParentFrame() {
		getDriver().switchTo().parentFrame();
		logger.info("Switched to Parent Content {} -----> ");
	}

	public void switchToDefaultContent() {
		getDriver().switchTo().defaultContent();
		logger.info("Switched to DefaultContent {} -----> ");
	}

	// ######################################### Walmart Inventory - Prime Location Elements #################################

	@FindBy(xpath = "//iframe[contains(@name,'refs-Search')]")
	private WebElement switchingToFrame;

	@FindBy(xpath = "//td[contains(text(),'Walmart - Inventory -> Slotting -> Prime Locations')]")
	private WebElement getPrimeLocationLink;

	@FindBy(xpath = "//iframe[contains(@name,'Prime-Locations')]")
	private WebElement frameSwitch;

	@FindBy(xpath = "//div[contains(@class,'pagebuilder')]//tr[contains(@id,'record-ext')]//td[count(//div[contains(@class,'pagebuilder')]//div[normalize-space()='Location'][not(contains(@class,'inner'))]//preceding-sibling::div)]/div")
	private WebElement emptyPrimeLocation;
	
	// ######################################### Walmart Inventory - Problems tab Elements #################################
	
	@FindBy(xpath = "//td[text()='Inventory -> Problems']")
	private WebElement getInventoryProblemsLink;

	// ######################################### Walmart Inventory - Configuration(Replenishment) Elements #################################

	@FindBy(xpath = "//span[contains(text(),'Configuration')]")
	private WebElement configurationTab;

	@FindBy(xpath = "//a/span[contains(text(),'Replenishment Settings')]")
	private WebElement repleSettings;

	@FindBy(xpath = "//iframe[contains(@name,'config.inventory')]")
	private WebElement repleFrame;

	@FindBy(xpath = "//span[text()='Define the items that will allow demand replenishments to be created']")
	private WebElement demandReplenish;

	@FindBy(xpath = "//a[normalize-space()='Add']")
	private WebElement btnAdd;

	@FindBy(xpath = "//td/input[contains(@id,'itemLookup') and @name='itemNumber']")
	private WebElement itemTB;

	private WebElement itemNumberFromDD(String itemNumber) {
		return getDriver()
				.findElement(By.xpath("//div[contains(@class,'x-boundlist') and text()='" + itemNumber + "']"));
	}
	
	private WebElement statusOption(String status) {
		return getDriver()
				.findElement(By.xpath("//ul[@class='x-list-plain']/li[text()='"+status+"']"));
	}
	
	

	@FindBy(xpath = "//td/input[contains(@id,'combobox') and @name='inventoryStatus']")
	private WebElement inventoryStatusTB;

	// Enter the value into TextBox and select from the dropdown list.
	private WebElement invStatusFromDD(String invStatus) {
		return getDriver()
				.findElement(By.xpath("//div/ul/li[contains(@class,'-item') and text()='" + invStatus + "']"));
	}

	@FindBy(xpath = "//label[contains(text(),'Minimum/Maximum')]/../following-sibling::div//label[contains(@id,'radiofield') and contains(text(),'Percentage')]")
	private WebElement percentageRadioBtn;

	private WebElement primeLocFromDD(String primeLoc) {
		return getDriver().findElement(By.xpath("//li[normalize-space()='" + primeLoc + "']"));
	}

	@FindBy(xpath = "//div[contains(@id,'replenitemsform')]//span[text()='Save']/../../..")
	private WebElement btnSave;

	// ######################################### Walmart Inventory - Configuration(Replenishment) Methods #################################

	public void selectReplanishmentSettings() {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		switchToDefaultContent();
		uiActionsHelper.moveToElement(configurationTab);
		element(repleSettings).click();
		logger.info("Selected Replanishment Settings through MouseHover Event =====");

	}
	
	public void headerSearchByText(String textNeedToBeSearch) {
		Failsafe.with(retryPolicy).run(() -> {
		switchToDefaultContent();
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(headerSearchBox).waitUntilPresent();
		element(headerSearchBox).waitUntilVisible();
		element(headerSearchBox).waitUntilClickable();		
		uiActionsHelper.jsClear(headerSearchBox);

		element(headerSearchBox).sendKeys(textNeedToBeSearch + Keys.ENTER);
		logger.info("Entered the value into Header Search box =====");
		});
	}
	
	
	private WebElement selectLinkFromResult(String linkName) {
		return getDriver().findElement(By.xpath("//td[contains(text(),'"+ linkName +"')]"));
		}
	
	public void selectLinkFromSearchResults(String linkName) {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		switchToFrameWithElement(switchingToFrame);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		element(selectLinkFromResult(linkName)).click();

		logger.info("Select the {} Link from the Result =====", selectLinkFromResult(linkName).getText());
	}

	public void selectDemandReplanishment() {
		Failsafe.with(retryPolicy).run(() -> {
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
//		switchToFrame("inventorydisplay");
			switchToDefaultContent();
			switchToFrame("config.inventory");
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			element(demandReplenish).waitUntilVisible();
			element(demandReplenish).waitUntilClickable();
			uiActionsHelper.moveToElementAndClick(demandReplenish);
			logger.info("Selected Demand Replanishment =====");
		});
	}

	public void clickAddButton() {
		element(btnAdd).waitUntilVisible();
		element(btnAdd).click();
		logger.info("Clicked on Add Button =====");
	}

	public void enterItemNumberandSelectFromDD(String itemNumber) {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(itemTB).clear();
		element(itemTB).sendKeys(itemNumber);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		element(itemNumberFromDD(itemNumber)).click();
		logger.info("Entered Item Number and selected from Dropdown {} =====", itemNumber);
	}

	public void enterInventoryStatusandSelectFromDD(String invStatus) {

		element(inventoryStatusTB).waitUntilClickable();
		element(inventoryStatusTB).clear();
		element(inventoryStatusTB).sendKeys(invStatus);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		element(invStatusFromDD(invStatus)).click();
		logger.info("Entered Inventory Status and selected from Dropdown {}=====", invStatus);
	}

	public void enterMinMaxPercentages(String min, String max) {

		element(percentageRadioBtn).waitUntilVisible();
		if (!element(percentageRadioBtn).isSelected()) {
			element(percentageRadioBtn).click();
		}
		element(textboxContainsName("maximumUnits")).sendKeys(min);
		element(textboxContainsName("minimumUnits")).sendKeys(max);
		logger.info("Selects Percentage Radio Button =====");
		logger.info("Entered Min Percentages  ===== {} ", min);
		logger.info("Entered Max Percentages  ===== {} ", max);
	}

	public void enterReleasePercent(String releasePercent) {
		element(textboxContainsName("releasePercentage")).waitUntilClickable();
		element(textboxContainsName("releasePercentage")).clear();
		element(textboxContainsName("releasePercentage")).sendKeys(releasePercent);
		logger.info("Entered Release Percent  ====={} ", releasePercent);
	}

	public void enterPrimeLocationandSelectFromDD(String primeLoc) {

		element(textboxContainsName("storageLocation")).waitUntilClickable();
		element(textboxContainsName("storageLocation")).clear();
		element(textboxContainsName("storageLocation")).sendKeys(primeLoc);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		element(primeLocFromDD(primeLoc)).click();
		logger.info("Entered Empty Prime Location and selected from Dropdown {}===== ", primeLoc);
	}

	public void clickSaveButton() {

		element(btnSave).waitUntilVisible();
		element(btnSave).waitUntilClickable();
		element(btnSave).click();
		logger.info("Clicked on Save Button  =====");
	}

	// ######################################### Walmart Inventory - Prime Location Methods #################################

	public void headerSearchPrimeLocation() {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(headerSearchBox).waitUntilPresent();
		element(headerSearchBox).waitUntilVisible();
		element(headerSearchBox).waitUntilClickable();
		element(headerSearchBox).sendKeys("Prime Location" + Keys.ENTER);
		logger.info("Entered the value 'Prime Location' into Header Search box =====");
	}
	
	public void headerSearchPrimeLocation(String textNeedToBeSearch) {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(headerSearchBox).waitUntilPresent();
		element(headerSearchBox).waitUntilVisible();
		element(headerSearchBox).waitUntilClickable();
//		element(headerSearchBox).sendKeys("Prime Location" + Keys.ENTER);
		element(headerSearchBox).sendKeys(textNeedToBeSearch + Keys.ENTER);
		logger.info("Entered the value 'Prime Location' into Header Search box =====");
	}


	
	public void headerSearchProblemsTab() {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(headerSearchBox).waitUntilPresent();
		element(headerSearchBox).waitUntilVisible();
		element(headerSearchBox).waitUntilClickable();
		element(headerSearchBox).sendKeys("Problems" + Keys.ENTER);
		logger.info("Entered the value 'Problems' into Header Search box =====");
	}

	public void selectPrimeLocationLinkFromResults() {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		switchToFrameWithElement(switchingToFrame);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		logger.info("Select the Prime Location Link from the Result {}=====", getPrimeLocationLink.getText());
		element(getPrimeLocationLink).click();

	}
	
	public void selectInventoryProblemsLinkFromResults() {

		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		switchToFrameWithElement(switchingToFrame);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
		logger.info("Select the Problems Location Link from the Result: {}", getInventoryProblemsLink.getText());
		element(getInventoryProblemsLink).click();
		logger.info("Selected the Problems Location Link from the Result above");

	}

	public void filterWithRequiredFields() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		switchToDefaultContent();
		switchToFrameWithElement(frameSwitch);
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
//		byOutboundPage.enterValueUnderFilterTextBox("ext", "Location Enabled", "True");
//		byOutboundPage.enterValueUnderFilterTextBox("ext", "Location Status", "Empty");
//		byOutboundPage.enterValueUnderFilterTextBox("ext", "Item", "null");
		logger.info("Switched to working frame =====");
	}

	// This will return the empty Prime Location and Set it in TFD
	public String setEmptyPrimeLocation() throws IOException, ParseException {

		String primeLocation = element(emptyPrimeLocation).getText();
		logger.info("Picked Prime Location is =====" + primeLocation);

		byUiHelper.updateTestFlowDataForPoLineDetails("primeLocation", primeLocation);
		logger.info("set the Empty Prime Location {} in TestFlowData", primeLocation);

		return primeLocation;
	}

	public void clickLpnCheckboxButton() {
		element(lpnCheckBox).waitUntilVisible();
		element(lpnCheckBox).waitUntilClickable();
		element(lpnCheckBox).click();
		logger.info("Clicked on lpn CheckBox Button =====");
	}
	
	public void clickOnActionsButton() {
		element(actionsButton).waitUntilVisible();
		element(actionsButton).waitUntilClickable();
		element(actionsButton).click();
		logger.info("Clicked on Actions Button in BY UI ==========");
	}
	
	public void clickOnChangeInventoryStatusOption() {
		element(changeInventoryStatusOption).waitUntilVisible();
		element(changeInventoryStatusOption).waitUntilClickable();
		element(changeInventoryStatusOption).click();
		logger.info("Clicked on Change Inventory Status Option under Actions in BY UI ==========");
	}
	
	public void clickOnStatusExpandButton() {
		element(StatusExpandButton).waitUntilVisible();
		element(StatusExpandButton).waitUntilClickable();
		element(StatusExpandButton).click();
		logger.info("Clicked on Status Expand Button in BY UI ==========");
	}
	
	public void selectStatus(String status) {
		element(statusOption(status)).click();
		logger.info("Selected Status from Dropdown {} =====", status);
	}
	
	public void clickOnOkButtonOnInventoryStatusChangeWindow() {
		element(okButtonInventoryStatusChangeWindow).waitUntilVisible();
		element(okButtonInventoryStatusChangeWindow).waitUntilClickable();
		element(okButtonInventoryStatusChangeWindow).click();
		logger.info("Clicked on Ok Button to change Status ==========");
	}
	
	
	public void clickOnLpnsTab() {
		element(lpnsTab).waitUntilVisible();
		element(lpnsTab).waitUntilClickable();
		element(lpnsTab).click();
		logger.info("Clicked on LPns tab ==========");
	}
	
	public void clickResultsOkButton() {
		element(resultsOkButton).waitUntilVisible();
		element(resultsOkButton).waitUntilClickable();
		element(resultsOkButton).click();
		logger.info("Clicked on Results Ok Button ==========");
	}
	
	public void verifyInventoryStatusChangedMessage() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
		element(inventoryStatusChangedLabel).waitUntilVisible();
		element(inventoryStatusChangedLabel).waitUntilClickable();
		catalystUtil.verifyElementValue1(element(inventoryStatusChangedLabel),"Inventory status changed for 1 LPNs successfully.");
		logger.info("Clicked on Results inventory Status Changed Label ==========");
	}
	
	
	//###################################################### Holds Elements  ########################################
	
		@FindBy(xpath = "//div[normalize-space()='Holds']")
		private WebElement pageTitleHolds;
		
		@FindBy(xpath = "//div[contains(@class,'x-panel-default') and contains(@id,'wm-inventoryholds-activeHoldGridView')]//span[text()='Actions']/../../..")
		private WebElement holdActionButton;
		
		@FindBy(xpath = "//a[contains(@id,'menuitem')]/span[contains(text(),'Add Hold')]")
		private WebElement addHoldMenuItem;
		
		@FindBy(xpath = "//div[contains(@id,'wm-common-holds')]//span[contains(@id,'wm-common-holds_header_hd-textEl') and contains(text(),'Add New Hold')]")
		private WebElement addNewHoldTitle;
		
		@FindBy(xpath = "//td[contains(@id,'textarea')]//textarea[contains(@name,'noteText')]")
		private WebElement enterNotesForFH;
		
		@FindBy(xpath = "//div/ul/li[contains(text(),'Allocation and Shipping Hold')]")
		private WebElement allocationAndShippingOptionDD;
		
		@FindBy(xpath = "//div/ul/li[contains(text(),'Severity Level 3')]")
		private WebElement SeverityLvlOptionDD;
		
		@FindBy(xpath = "//td[contains(@id,'rpToggle')]//label[contains(text(),'Inventory Status')]/../..//input[contains(@class,'toggle_switch')]")
		private WebElement inventoryStatusToggleSwitch;

		@FindBy(xpath = "//td[contains(@id,'rpToggle')]//label[contains(text(),'Apply to Inbound')]/../..//input[contains(@class,'toggle_switch')]")
		private WebElement applyToInboundInventoryToggleSwitch;
		
		@FindBy(xpath = "//div/ul/li[contains(text(),'Home Office Directed ')]")
		private WebElement reasonOptionDD;
		
		@FindBy(xpath = "//span[text()='Enter the criteria for inventory that will have this hold applied at receipt.']")
		private WebElement selectInventoryCriteriaTab;
		
		@FindBy(xpath = "//td[contains(@id,'rpToggle')]//label[contains(text(),'Allocation')]/../..//input[contains(@class,'toggle_switch')]")
		private WebElement allocationToggleSwitch;
		
		@FindBy(xpath = "//td[contains(@id,'enableToggle')]//input[contains(@class,'toggle_switch')]")
		private WebElement enableHoldToggleSwitch;
		
		@FindBy(xpath = "//a[contains(@class,'x-btn-default-toolbar-small-noicon')]//span[text()='Save']/../../..")
		private WebElement saveButton;
		
	
	//###################################################### Holds Methods  ########################################
	
		public void clickOnHoldActionButton() {
			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				switchToDefaultContent();
				switchToFrame("inventorydisplay");
				element(holdActionButton).waitUntilVisible();
				element(holdActionButton).waitUntilClickable();
				element(holdActionButton).click();
			});
			logger.info("Clicked on Hold Action Button ===>");
		}	

		public void clickOnAddHoldButton() {

			element(addHoldMenuItem).waitUntilVisible();
			element(addHoldMenuItem).waitUntilClickable();
			element(addHoldMenuItem).click();
			logger.info("Clicked on Add Hold Menu Button ===>");
		}

		public void verifyAddNewHoldPageHeading() {

			// getDriverInstance().switchTo().frame(addNewHoldTitle);
			element(addNewHoldTitle).waitUntilVisible();
			element(addNewHoldTitle).waitUntilPresent();
			catalystUtil.verifyElementIsDisplayed(addNewHoldTitle);
			logger.info(" Verified: Add New Hold Page Heading ===>");
		}
		
		
		public void verifyFutureHoldsPageHeading() {

			// getDriverInstance().switchTo().frame(pageTitleHolds);
//			switchToFrame();
			switchToDefaultContent();
			switchToFrame("inventorydisplay");
			element(pageTitleHolds).waitUntilVisible();
			element(pageTitleHolds).waitUntilPresent();
			catalystUtil.verifyElementIsDisplayed(pageTitleHolds);
			logger.info(" Verified: Future Hold Page Heading ===>");
		}

		public void enterTextInHoldTextbox(String holdNumber) {

			element(textboxContainsName("holdNumber")).waitUntilVisible();
			element(textboxContainsName("holdNumber")).waitUntilClickable();
			element(textboxContainsName("holdNumber")).clear();
			element(textboxContainsName("holdNumber")).sendKeys(holdNumber);
			logger.info("Entered Hold Number ===>", holdNumber);
		}

		public void enterNotesForFutureHold(String enterNotes) {

			element(enterNotesForFH).waitUntilVisible();
			element(enterNotesForFH).waitUntilClickable();
			element(enterNotesForFH).sendKeys(enterNotes);
			logger.info("Enter the Notes for Future Hold");
		}

		public void enterFHDescription(String holdDescription) {

			element(textboxContainsName("longDescription")).waitUntilVisible();
			element(textboxContainsName("longDescription")).waitUntilClickable();
			element(textboxContainsName("longDescription")).clear();
			element(textboxContainsName("longDescription")).sendKeys(holdDescription);
			logger.info("Entered Hold Description ===>", holdDescription);
		}

		public void enterFutureHoldTypeAndSelectFromDD(String holdType) {

			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(textboxContainsName("holdType")).waitUntilVisible();
				element(textboxContainsName("holdType")).waitUntilClickable();
				element(textboxContainsName("holdType")).clear();
				element(textboxContainsName("holdType")).sendKeys(holdType);
				logger.info("Entered {} in Textbox=====", holdType);

				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
				element(textOfDropDownOption(holdType)).click();
				logger.info("Selected {} from Dropdown =====", holdType);
			});
		}

		public void enterSeverityLevelAndSelectFromDD(String holdSeverity) {

			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(textboxContainsName("severity")).waitUntilVisible();
				element(textboxContainsName("severity")).waitUntilClickable();
				element(textboxContainsName("severity")).clear();
				element(textboxContainsName("severity")).sendKeys(holdSeverity);
				logger.info("Entered {} in Textbox=====", holdSeverity);

				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
				element(textOfDropDownOption(holdSeverity)).click();
				logger.info("Selected {} from Dropdown =====", holdSeverity);
			});
		}

		public void applyInboundInventoryToggleSwitch() {
			Failsafe.with(retryPolicy).run(() -> {
				element(applyToInboundInventoryToggleSwitch).waitUntilVisible();
				element(applyToInboundInventoryToggleSwitch).waitUntilClickable();
				element(applyToInboundInventoryToggleSwitch).click();
				logger.info("Clicked on Apply To Inbound Inventory - Toggle Switch  ====>");
			});
		}

		public void enterHoldReasonAndSelectFromDD(String holdReason) {

			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(textboxContainsName("reasonCode")).waitUntilVisible();
				element(textboxContainsName("reasonCode")).waitUntilClickable();
				element(textboxContainsName("reasonCode")).clear();
				element(textboxContainsName("reasonCode")).sendKeys(holdReason);
				logger.info("Entered {} in Textbox=====", holdReason);

				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(60, TimeUnit.SECONDS);
				element(textOfDropDownOption(holdReason)).click();
				logger.info("Selected {} from Dropdown =====", holdReason);
			});
		}

		public void selectInventoryCriteriaTab() {
			Failsafe.with(retryPolicy).run(() -> {
				element(selectInventoryCriteriaTab).waitUntilVisible();
				element(selectInventoryCriteriaTab).waitUntilClickable();
				element(selectInventoryCriteriaTab).click();
			});
		}

		public void enterFHItemNumber(String holdItemNumber) {

			element(textboxContainsName("itemNumber")).waitUntilVisible();
			element(textboxContainsName("itemNumber")).waitUntilClickable();
			element(textboxContainsName("itemNumber")).clear();
			element(textboxContainsName("itemNumber")).sendKeys(holdItemNumber);
			logger.info("Entered Hold Item Number ===> {}", holdItemNumber);
		}

		public void enterFHItemLotNumber(String holdItemLotNumber) {

			element(textboxContainsName("lotNumber")).waitUntilVisible();
			element(textboxContainsName("lotNumber")).waitUntilClickable();
			element(textboxContainsName("lotNumber")).clear();
			element(textboxContainsName("lotNumber")).sendKeys(holdItemLotNumber);
			logger.info("Entered Hold Item Lot Number ===> {}", holdItemLotNumber);
		}

		public void clickOnApplyButton() {
			getButtonByText("Apply").click();
			logger.info("Clicked on Apply Button ===>");
		}

		public void allocationToggleSwitch() {
			Failsafe.with(retryPolicy).run(() -> {
				element(enableHoldToggleSwitch).waitUntilVisible();
				element(enableHoldToggleSwitch).waitUntilClickable();
				element(enableHoldToggleSwitch).click();
				logger.info("Clicked on Allocation - Toggle Switch  ====>");
			});
		}

		public void enableHoldToggleSwitch() {
			Failsafe.with(retryPolicy).run(() -> {

				element(enableHoldToggleSwitch).waitUntilVisible();
				element(enableHoldToggleSwitch).waitUntilClickable();

				if (element(enableHoldToggleSwitch).isEnabled()) {

				} else {
					element(enableHoldToggleSwitch).click();
				}
				logger.info("Clicked on Enable Hold - Toggle Switch  ====>");
			});
		}

		public void clickOnSaveButton() {

			element(saveButton).waitUntilVisible();
			element(saveButton).waitUntilClickable();
			element(saveButton).click();
			logger.info("Clicked on Save Button  ====>");
		}
	
	
	
}
