package com.walmart.supplychain.nextgen.idm.scenariosteps.webservices;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

import org.json.JSONException;
import spring.SpringTestConfiguration;

import org.springframework.stereotype.Component;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;

import java.awt.*;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class IDMScenarios {

	@Steps
	IDMSteps idmSteps;

	@Steps
	PreRunCleanup preRunCleanup;

	@When("^user creates \"([^\"]*)\" delivery with \"([^\"]*)\" status$")
	public void user_creates_delivery_with_status( String deliveryName,String deliveryStatus) {
		if (!deliveryStatus.equals("CNL")) {
			idmSteps.createDelivery(100, "Create_Delivery", deliveryName);
			idmSteps.search_and_validate_deliveryStatus(deliveryStatus, deliveryName);

		} else {
			idmSteps.createDelivery(100, "CANCEL_DELIVERY", deliveryName);
			idmSteps.search_and_validate_deliveryStatus(deliveryStatus, deliveryName);

		}
	}

	@When("^user creates a delivery$")
	public void user_creates_a_delivery_MCC() {

		idmSteps.createDelivery(100, "Create_Delivery", "D1");
	}
	
	@When("^user creates a delivery with loadnumber \"([^\"]*)\"$")
	public void user_creates_a_delivery_MCC_with_loadnumber(String loadNumber) {

		idmSteps.createDelivery(100, "Create_Delivery", "D1", loadNumber);
	}
	
	@When("^user creates a delivery with loadnumber \"([^\"]*)\" for \"([^\"]*)\"$")
	public void user_creates_a_delivery_RDC_with_loadnumber(String loadNumber, String deliveryForRDCReceivingType) {
		idmSteps.createDeliveryRDC(100, "Create_Delivery", "D1", loadNumber, deliveryForRDCReceivingType);
	}
	
	@When("^user creates a delivery with deliverynumber \"([^\"]*)\" and loadnumber \"([^\"]*)\"$")
	public void user_creates_a_delivery_pharmacy(String deliveryNumber,String loadNumber) {

		idmSteps.createDeliveryForPharmcy(100, "Create_Delivery", "D1", loadNumber, deliveryNumber);
	}
	
	@When("^user creates a delivery with deliverynumber \"([^\"]*)\"$")
	public void user_creates_a_delivery_pharmacy(String deliveryNumber) {

		idmSteps.createDeliveryForPharmcyWithDummyLoadNumber(100, "Create_Delivery", "D1", deliveryNumber);
	}
	
	@When("^user creates a delivery using scheduler 2.0 with eventType \"([^\"]*)\"$")
	public void user_creates_a_delivery_Scheduler2(String eventType) {

		idmSteps.createDelivery(100, eventType, "D1");
	}
	
	@Given("^user Gates in the delivery without door$") 
		public void user_gates_in_the_delivery_without_door() {
		
			
		}

	@When("^user creates a delivery with \"([^\"]*)\" % of po qty$")
	public void user_creates_a_delivery_MCC(String qtyPercentage) {

		idmSteps.createDelivery(Integer.parseInt(qtyPercentage), "A", "D1");
	}

	@Then("^user verifies delivery is created in IDM with \"([^\"]*)\" status$")
	public void user_verifies_delivery_is_created_in_IDM_with_status(String deliveryStatus) {

		idmSteps.search_and_validate_deliveryStatus(deliveryStatus, "D1");

	}

	@Then("^user verifies delivery status is \"([^\"]*)\" in Unified UI$")
	public void user_verifies_delivery_status_in_unified_UI(String deliveryStatus) throws Exception {

		idmSteps.validate_deliveryStatus_in_Unified_UI(deliveryStatus, "D1");

	}
	
	@Then("^user verifies potype \"([^\"]*)\" for the pos \"([^\"]*)\" in IDM$")
	public void user_verifies_potype_for_the_pos(String poType, String poNumbers) {

		idmSteps.validatePOTypeForThePOs(poType, poNumbers,"D1");

	}
	
	@Then("^user validates Pallet quantity for each PO$")
	public void user_verifies_palletqty_for_the_pos() {
		idmSteps.validatePalletCountForThePOs("D1");
	}

	@Then("^user verifies RDC delivery is created in IDM with \"([^\"]*)\" status$")
	public void user_verifies_RDC_delivery_is_created_in_IDM_with_status(String deliveryStatus) {

		idmSteps.search_and_validate_deliveryStatus_RDC(deliveryStatus);

	}

	@Then("^user verifies delivery status is changed to \"([^\"]*)\" in IDM$")
	public void user_verifies_delivery_status_is_changed_to_in_IDM(String deliveryStatus) {

		idmSteps.search_and_validate_deliveryStatus(deliveryStatus, "D1");

	}

	@Then("^user verifies RDC delivery status is changed to \"([^\"]*)\" in IDM$")
	public void user_verifies_delivery_status_in_RDC_is_changed_to_in_IDM(String deliveryStatus) {

		idmSteps.search_and_validate_deliveryStatus_RDC(deliveryStatus);

	}

	@Then("^user verifies delivery status is changed to \"([^\"]*)\" in IDM with the door number$")
	public void user_verifies_delivery_status_is_changed_to_in_IDM_with_the_door_number(String deliveryStatus) {

		 idmSteps.search_and_validate_deliveryStatusAndDoorNumber(deliveryStatus, "D1");

	}

	@Given("^user verifies the receipts in IDM$")
	public void user_verifies_the_receipts_in_IDM() {

		idmSteps.searchAndValidateIDMForDeliveryReceipt();
		

	}
	@Given("^user verifies the receipts in IDM for PO \"([^\"]*)\"$")
	public void user_verifies_the_receipts_in_IDM_For_PO(String poName) {

		idmSteps.searchAndValidateIDMForDeliveryReceipt(poName);

	}

	@Given("^user verifies the damage receipts in IDM$")
	public void user_verifies_damage_receipts_in_IDM() {
		idmSteps.searchAndValidateIDMForDamageDeliveryReceipt();

	}

	@Given("^user creates RDC delivery for WTMS load number in IDM$")
	public void user_creates_a_delivery_RDC() {
		if (Config.DC == DC_TYPE.MCC) {
			Config.DC = DC_TYPE.MCC_RDC;
		} else if (Config.DC == DC_TYPE.ATLAS) {
			Config.DC = DC_TYPE.ATLAS_RDC;
		} else if (Config.DC == DC_TYPE.ACC) {
			Config.DC = DC_TYPE.ACC_RDC;
		}
		preRunCleanup.cleanUpopRDC();
		idmSteps.createDelivery(100, "A", "D1");
	}

	@Given("^user creates RDC delivery for BOL in IDM$")
	public void userCreatesDeliveryRDCForBOL() {
		if (Config.DC == DC_TYPE.MCC) {
			Config.DC = DC_TYPE.MCC_RDC;
		} else if (Config.DC == DC_TYPE.ATLAS) {
			Config.DC = DC_TYPE.ATLAS_RDC;
		} else if (Config.DC == DC_TYPE.ACC) {
			Config.DC = DC_TYPE.ACC_RDC;
		}
		idmSteps.createDeliveryRDCForS2S();
	}

	@Then("^user verifies all the containers are attached in the delivery$")
	public void user_verifies_all_the_containers_are_attahced_in_the_delivery() {

		idmSteps.validateCtrsRDCDelivery();

	}

	@Then("^IBD should update the delivery receipts as per the delta provided by OF$")
	public void ibdShouldUpdateDeliveryReceiptsAsPerDeltaProvidedByOF() {
		idmSteps.searchAndValidateIDMForDeliveryReceipt();
	}

	@Given("^user verifies receipts in IDM for Shortage$")
	public void user_verifies_receipts_in_IDM_for_Shortage() {

		idmSteps.validateIDMForDeliveryReceiptShortage();

	}
	
	@Given("^user verifies receipts in IDM for Overage, Damage and Received qty$")
	public void user_verifies_receipts_in_IDM_for_Overage_Damage_Received() {
		idmSteps.validateIDMForDeliveryReceiptForReceivedDamageAndOverageQty();
	}
	
	@When("^user verifies the po line add for item \"([^\"]*)\"$")
	public void user_verifies_the_po_line_add_for_item(String itmNum) {
		String[] arr=itmNum.split("-");
		idmSteps.verifyPOLineAdd(arr[1],arr[2]);
	}
	
	@When("^user verifies the po line update for item \"([^\"]*)\"$")
	public void user_verifies_the_po_line_update_for_item(String itmNum) {
		String[] arr=itmNum.split("-");
		idmSteps.verifyPOLineUpdate(arr[5]);
	}
	
	@Then("^user verifies the item attributes in delivery document$")
	public void user_verifies_the_item_ttributes_in_delivery_documnet() {
		idmSteps.validateItemAttributes("D1");
	}
	
	@Then("user updates the freight bill quantity of each PO Line from the GDM UI")
	public void user_updates_the_freight_bill_quantity_of_each_PO_Line_from_the_GDM_UI() {
		idmSteps.setFBQQtyOnUI("D1");
	}
	
	@Then("user validates the freight bill quantity in the delivery document")
	public void user_validates_the_freight_bill_quantity_in_the_delivery_document() {
		idmSteps.validateUpdatedFBQQty("D1");
	}
	
	@Given("^user perform \"([^\"]*)\" from GDM$")
	public void user_perform_gate_in_gdm(String gdmAction) {
		
		if (gdmAction.contains("Gate"))
			idmSteps.deliveryArrivedUpdate();
		else
			idmSteps.deliveryDoorAssignGDM();
	}
	
	
	 @Then("^user updates the FBQ quantity and variable weight for PO \"([^\"]*)\"$")
	 public void user_updates_fbq_qty_variable_weight(String poName) {
		 
		 idmSteps.updateFbqAndVariableWeight(poName);
		 
	 }
	 
	 @Then("^user verifies that FBQ quantity and variable weight should be updated in the delivery document for PO \"([^\"]*)\"$")
	 public void user_validates_fbq_qty_variable_weight(String poName) {
		 
		 idmSteps.validateFbqAndVariableWeightInDeliveryDocument(poName);
		 
	 }
	 
	 @Then("^user verifies the POLine \"([^\"]*)\" status in GDM for PO \"([^\"]*)\"$")
	 public void userValidatesThePoLineStatusInGDMAfterRejection(String poLinr, String poName) {
		 
		 idmSteps.validatePOLineStatusAfterReject(poLinr, poName);
		 
	 }
	 
	
	 @Then("^user rejects line \"([^\"]*)\" of PO \"([^\"]*)\"from the GDM$")
	 public void user_rejects_line_of_po_from_GDM(String lineNumber, String poName) {
		   
		 
		 idmSteps.rejectPoLine(poName,lineNumber);
		 
		}
	
	 @And("order-well triggers channel flip for CROSSMU freight type")
		public void channelFlip_CrossMu() {
			idmSteps.sendActiveChannelMethodAsSSTK();
		}

	 @When("^user updates PO qty to \"([^\"]*)\"$")
		public void updatePO(String poQty) {
			idmSteps.udpatePOLineQty(Integer.valueOf(poQty));
		}
	 
	 
	 @Then("^user changes the last limited qty verification date in GDM$")
		public void userChangesLastLimitedQtyVerificationDate() {
		 idmSteps.updateLastLimitedQtyVerificationDate();	
			
		}
	 
	 @Then("^user changes the last lithium-ion qty verification date in GDM$")
		public void userChangesLastLithiumIonVerificationDate() {
		 idmSteps.updateLastLithiumIonVerificationDate();	
			
		}

	@Given("^user verifies osdr$")
	public void user_verifies_osdr() {
		idmSteps.validateOSDRforCP();
	}

	@Then("^user updates the transportation mode in GDM for \"([^\"]*)\"$")
	public void updateTransportationMode(String lithiumIonOrLimitedQty) {
		idmSteps.setTransportationModeInGDM(lithiumIonOrLimitedQty);

	}
}
