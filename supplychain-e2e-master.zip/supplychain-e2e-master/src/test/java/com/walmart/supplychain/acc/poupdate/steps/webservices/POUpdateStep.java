package com.walmart.supplychain.acc.poupdate.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACCMongoSteps;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class POUpdateStep {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			15);
	boolean retry = false;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ACLDBSteps aclDBSteps;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	SpringJmsUtils springJmsUtils;

	@Autowired
	JavaUtils javaUtils;

	@Value("${beumertosortertopic}")
	String beumerTopivACC;

	Response response;

	@Autowired
	Environment env;

	@Autowired
	ACCMongoSteps accMongoSteps;
	
	@Autowired
	IDMHelper idmHelper;
	
	@Autowired
	IDMSteps idmSteps;
	
	@Autowired
	Environment environment;

	private static final Map<String, String> poUpdateMap = new HashMap<>();
	Map lpnLabelsMap;

	ObjectMapper objmapper = new ObjectMapper();
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_LABEL_COLLECTION = "deliverydocumentsbylpns";
	private static final String MONGO_SCHEMA = "receive";
	private static final String OPEN_QTY_LPN_JSON_PATH="$..[?(@.labelType=='ORDERED')].lpns";
	private static final String OVERAGE_QTY_LPN_JSON_PATH="$..[?(@.labelType=='OVERAGE')].lpns";
	private static final String EXCEPTION_QTY_LPN_JSON_PATH="$..[?(@.labelType=='EXCEPTION')].lpns";
	private static final String WMT_USER_ID = "system";
	private Response aclLabelResponse=null;

	@Step
	public void publishPOUpdate(String poDeltaQty) {
		try {
			
			DocumentContext context = null;
			ObjectMapper om = new ObjectMapper();
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
				
			JSONArray listOfPO = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = null;
			//this piece of code will only work for single PO line in a delivery
			//otherwise make this varaible local rather then global
			int poQty=0;
			poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			Map<String, List> laneLpnMapping = new HashMap();
			//String originalPoQty = null;
			List<PoDetail> poObjList = new ArrayList<PoDetail>();
			for (PoDetail poObj : poList) {

				poUpdateMap.put("poNumber", poObj.getPoNumber());
				//poUpdateMap.put("omsPoNumber", poObj.getOmsPONumber());
				List<PoLineDetail> poLineObjList = poObj.getPoLineDetails();
				for (int j = 0; j < poLineObjList.size(); j++) {
					PoLineDetail poLinrObj = poLineObjList.get(j);
					if (j == 0) {
						poUpdateMap.put("poLineNumber", poLinrObj.getPoLineNumber());
						//originalPoQty = poLinrObj.getPoVnpkQty();
						poQty = Integer.parseInt(poDeltaQty) + Integer.parseInt(poLinrObj.getPoVnpkQty());
						poLineObjList.get(j).setPoUpdateQty(String.valueOf(poQty));
						poUpdateMap.put("poQty", Integer.toString(poQty));
						poUpdateMap.put("itemNum", poLinrObj.getItemNumber());
//						poUpdateMap.put("vnpkRatio", poLinrObj.getVnpk());
//						poUpdateMap.put("whpkratio", poLinrObj.getWhpk());
						poUpdateMap.put("overage", poLinrObj.getOvgQty());
					}
				}
				poObj.setPoLineDetails(poLineObjList);
				poObjList.add(poObj);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(poObjList);
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(poObjList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating po qty::{}", tl.get().get(TEST_FLOW_DATA));

			JSONObject poUpdatejson = new JSONObject(
					jsonUtil.readFile("src//test//resources//TestData//acc//po_update.json"));
			poUpdatejson.put("purchaseReferenceNumber", poUpdateMap.get("poNumber"));
			poUpdatejson.put("purchaseLineNumber", poUpdateMap.get("poLineNumber"));
			poUpdatejson.put("orderQty", poQty);

			//poUpdatejson.put("xrefNbr", poUpdateMap.get("poNumber"));
			//JSONObject omsPurchaseOrderObj = poUpdatejson.getJSONObject("omsPurchaseOrder");
			//org.json.JSONArray omsPoLinesList = omsPurchaseOrderObj.getJSONArray("omsPoLines");
			//JSONObject lineObj = (JSONObject) omsPoLinesList.get(0);
//			lineObj.put("omsPoLineNbr", poUpdateMap.get("poLineNumber"));
//			lineObj.put("itemNbr", poUpdateMap.get("itemNum"));
//			lineObj.put("vnpkQty", poUpdateMap.get("vnpkRatio"));
//			lineObj.put("whpkQty", poUpdateMap.get("whpkratio"));
//			lineObj.put("vnpkOrdQty", poUpdateMap.get("poQty"));
//			org.json.JSONArray poEditObjList = poUpdatejson.getJSONArray("poEditSummary");
//			JSONObject editObj = (JSONObject) poEditObjList.get(0);
//			editObj.put("newValue", poUpdateMap.get("poQty"));
//			editObj.put("oldValue", originalPoQty);
//			editObj.put("omsPoLineNbr", poUpdateMap.get("poLineNumber"));

			logger.info("po update payload: " + poUpdatejson.toString(2));
			logger.info("po update url:"+env.getProperty("poUpdate_url"));
			response = given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders()).contentType("application/json").
					body(poUpdatejson.toString(2)).when()
					.put(env.getProperty("poUpdate_url")+poUpdateMap.get("poNumber")+"/lines/"+poUpdateMap.get("poLineNumber")).andReturn();
					
//			SerenityRest.given().contentType("application/json").body(poUpdatejson.toString(2)).when()
//					.put(env.getProperty("poUpdate_url") + poUpdateMap.get("poNumber")).andReturn();
			Assert.assertEquals(ErrorCodes.POUPDATE_INVALID_STATUS, 200, response.getStatusCode());
		
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish po update event", e);
		}
	}

	public void validatePOUpdate() {
		try {
			List totalLPNLabelsList = new ArrayList();
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfDeliveries = JsonPath.read(testData, "$.testFlowData.deliveryDetails[*].deliveryNumber");
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> vtrCntrList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = vtrCntrList.get(0);

			response = idmSteps.getDeliveryResponse("D1");
			//response = when().get(env.getProperty("idm_delivery_ep") + deliveryNum);
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());

			JSONArray deliveryexpectedQty = JsonPath.read(response.getBody().asString(),
					"$.deliveryDocuments[*].deliveryDocumentLines[?(@.itemNbr == \"" + poUpdateMap.get("itemNum")
							+ "\")].expectedQty");
			String deliveryexpectedString = deliveryexpectedQty.toJSONString();
			List<String> deliveryexpectedQtyList = objectMapper.readValue(deliveryexpectedString,
					new TypeReference<List<String>>() {
					});
			
			logger.info("PO update map  "+poUpdateMap.get("poQty"));
			logger.info("PO update json  "+deliveryexpectedQtyList.get(0));
			
			Assert.assertEquals(ErrorCodes.POUPDATE_QTY_MISMATCH, poUpdateMap.get("poQty"),
					deliveryexpectedQtyList.get(0));

			Failsafe.with(retryPolicy).run(() -> {
				aclLabelResponse = given().relaxedHTTPSValidation().headers(getReceivingHeaders()).when()
						.get(environment.getProperty("get_acl_labels_for_delivery") + deliveryNum);
				Assert.assertEquals(ErrorCodes.RECEIVING_ACL_LABEL_DATA_NOTFOUND, Constants.SUCESS_STATUS_CODE, aclLabelResponse.getStatusCode());
				
//				});
				DocumentContext aclLabelResponseJson = JsonPath.parse(aclLabelResponse.getBody().asString());
				List<String> opnLpnlist = aclLabelResponseJson.read(OPEN_QTY_LPN_JSON_PATH);
				List<String> ovgLpnlist = aclLabelResponseJson.read(OVERAGE_QTY_LPN_JSON_PATH);
				List<String> expLpnlist = aclLabelResponseJson.read(EXCEPTION_QTY_LPN_JSON_PATH);
				
				String opnLpnStr=opnLpnlist.get(0).replace("\\", "");
				opnLpnStr=opnLpnStr.replace("\"", "");
				opnLpnStr=opnLpnStr.replace("[", "");
				opnLpnStr=opnLpnStr.replace("]", "");
				String ovgLpnStr=ovgLpnlist.get(0).replace("\\", "");
				ovgLpnStr=ovgLpnStr.replace("\"", "");
				ovgLpnStr=ovgLpnStr.replace("[", "");
				ovgLpnStr=ovgLpnStr.replace("]", "");
				String expLpnStr=expLpnlist.get(0).replace("\\", "");
				expLpnStr=expLpnStr.replace("\"", "");
				expLpnStr=expLpnStr.replace("[", "");
				expLpnStr=expLpnStr.replace("]", "");
				
				List lpnLabels = Arrays.asList(opnLpnStr.split(","));
				List ovgLabels = Arrays.asList(ovgLpnStr.split(","));
				List exceptionLabels = Arrays.asList(expLpnStr.split(","));;
			
//			Failsafe.with(retryPolicy).run(() -> {
//				String status = accMongoSteps.getProcessedLabelsForDelivery(MONGO_SCHEMA, GET_LABEL_COLLECTION,
//						deliveryNum, poUpdateMap.get("poNumber"), poUpdateMap.get("itemNum"));
//				Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_NORMAL, "PROCESSED", status);
//				lpnLabelsMap = accMongoSteps.getLabelsForDelivery(MONGO_SCHEMA, GET_LABEL_COLLECTION, deliveryNum,
//						poUpdateMap.get("poNumber"), poUpdateMap.get("itemNum"));
//				Assert.assertNotNull(ErrorCodes.LABEL_ERROR_MAP, lpnLabelsMap);
//		//	});
//
//			List lpnLabels = (List) lpnLabelsMap.get("lpnLabels");
//			List ovgLabels = (List) lpnLabelsMap.get("ovgLabels");
//			List exceptionLabels = (List) lpnLabelsMap.get("exceptionLabels");

			logger.info("Normal lpn labels:" + lpnLabels);
			logger.info("Allowable Overage lpn labels:" + ovgLabels);
			logger.info("Exception lpn labels:" + exceptionLabels);

//			Failsafe.with(retryPolicy).run(() -> {
			Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_NORMAL, Double.parseDouble(poUpdateMap.get("poQty")),
					(double) lpnLabels.size());
			Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_OVERAGE, Integer.parseInt(poUpdateMap.get("overage")),
					ovgLabels.size());
			totalLPNLabelsList.addAll(lpnLabels);
			totalLPNLabelsList.addAll(ovgLabels);
			totalLPNLabelsList.addAll(exceptionLabels);
			});

			Failsafe.with(retryPolicy).run(() -> {
				int dbLabelsCnt = aclDBSteps.getLabelCountFromACL(totalLPNLabelsList);

				Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_ACL, totalLPNLabelsList.size(), dbLabelsCnt);
				logger.info("Labels are persisted successfully in ACL labels DB");
			});
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate po update event", e);
		}
	}

	public Headers getReceivingHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		Header appType = new Header("Content-Type", "application/json");
		
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);
		return new Headers(headerList);
	}
}
