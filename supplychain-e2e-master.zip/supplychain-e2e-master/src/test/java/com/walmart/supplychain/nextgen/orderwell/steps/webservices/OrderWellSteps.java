package com.walmart.supplychain.nextgen.orderwell.steps.webservices;

import com.fasterxml.jackson.core.JsonProcessingException;
import static com.jayway.jsonpath.JsonPath.parse;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang3.RandomUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.ow.OrdersSearch;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.*;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OrdersDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.KafkaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.oms.gluecode.webservices.DestOrderCharacteristics;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OrderWellSteps extends ScenarioSteps {

	@Autowired
	KafkaUtils kafkaUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	OrderWellMock orderWellMock;
	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Steps
	PreRunCleanup preRunCleanup;

	final int ZERO = 0;
	final int ONE = 1;
	final int TWO = 2;
	final int THREE = 3;
	private static final String ITEM_NUMEBR_JSON_PATH="$..ordersDetails[*].itemNumber";
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	private static final Logger LOGGER = LoggerFactory.getLogger(OrderWellSteps.class);
	private String getOrderWellManualPOUrl() {
		if(Config.DC==DC_TYPE.SAMS) {
			return environment.getProperty("ow_sams_manual_fetch");
		}else {
			return environment.getProperty("ow_manual_fetch");
		}
		
	}
	private void clearOrderWell(JSONArray ja) throws JSONException {

		List<String> uniqueDeleteKeys = createUniqueDeleteKeys(ja);

		for (int i = 0; i < uniqueDeleteKeys.size(); i++) {

			String deleteKey = uniqueDeleteKeys.get(i);
			String[] deleteKeys = deleteKey.split(";");
			String sourceNumber = deleteKeys[0];
			String itemNumber = deleteKeys[1];
			String poNumber = deleteKeys[2];
			String poType = deleteKeys[3];

			String ow_fetch_ep;
			Response response;

			/*
			 * This portion of code can be refactored out into a separate method as it is
			 * repeating in fetch alloc.
			 */
			if (poType.equals("3") || poType.equals("53")) {
				ow_fetch_ep = getOrderWellManualPOUrl();

				/*
				 * Construction of the search payload
				 */

				JSONObject baseSearchObj = new JSONObject();
				JSONArray poNbrsArr = new JSONArray();
				poNbrsArr.add(poNumber);
				baseSearchObj.put("poNumbers", poNbrsArr);

				response = SerenityRest.given().body(baseSearchObj.toJSONString()).post(ow_fetch_ep);

			} else {

				ow_fetch_ep = MessageFormat.format(environment.getProperty("ow_fetch"), sourceNumber, itemNumber,
						String.valueOf(Integer.MAX_VALUE));

				response = SerenityRest.when().get(ow_fetch_ep);
			}

			if (response.getBody().asString().length() > 4) {
				JSONArray otnArray = JsonPath.parse(response.asString()).read("$..orderTrackingNumber");

				LOGGER.info("The otns of the orders to be deleted in OW are :" + otnArray.toJSONString());

				JSONObject jo = new JSONObject();
				JSONArray baseArrElement = new JSONArray();
				for (int j = 0; j < otnArray.size(); j++) {
					JSONObject otnElement = new JSONObject();
					String otn = otnArray.get(j).toString();
					otnElement.put("orderTrackingNumber", otn);
					otnElement.put("status", "Complete");
					baseArrElement.add(otnElement);
				}

				jo.put("updateList", baseArrElement);

				Response updateResponse = SerenityRest.given().body(jo.toString())
						.put(environment.getProperty("ow_status_change"));

				Assert.assertEquals(ErrorCodes.OW_DELETION_UNSUCCESSFUL, 200, updateResponse.getStatusCode());

			}
		}

	}

	private List createUniqueDeleteKeys(JSONArray ja) {

		List<String> uniqueSearchKeyArr = new ArrayList<>();

		for (int i = 0; i < ja.size(); i++) {

			String sourceNumber = ((net.minidev.json.JSONObject) ja.get(i)).get("sourceNumber").toString();
			String wmtItemNumber = ((net.minidev.json.JSONObject) ja.get(i)).get("wmtItemNumber").toString();
			String poNumber = ((net.minidev.json.JSONObject) ja.get(i)).get("poNumber").toString();
			String poType = ((net.minidev.json.JSONObject) ja.get(i)).get("poType").toString();

			String uniqueSearchKey = sourceNumber + ";" + wmtItemNumber + ";" + poNumber + ";" + poType;

			uniqueSearchKeyArr.add(uniqueSearchKey);
		}

		List<String> uniqueList = uniqueSearchKeyArr.stream().distinct().collect(Collectors.toList());

		LOGGER.info("The unique keys combination that can be cleared is : " + uniqueList);
		tl.get().put("uniqueDeleteKeys", uniqueList);
		return uniqueList;
	}

	@Step
	public void verifyOrdersAvailability() throws JSONException, InterruptedException {
		try {
			if (Config.isOrderWellMocked) {
				LOGGER.info("Order well is mocked..No Validation required");
				return;
			}
			Thread.sleep(5000);

			List<String> uniqueDeleteKeys = (List<String>) tl.get().get("uniqueDeleteKeys");
			JSONArray orderWellLines = (JSONArray) tl.get().get("orderWellOrders");

			for (int i = 0; i < uniqueDeleteKeys.size(); i++) {

				String deleteKey = uniqueDeleteKeys.get(i);
				String[] deleteKeys = deleteKey.split(";");

				String sourceNumber = deleteKeys[0];
				String itemNumber = deleteKeys[1];
				String poNumber = deleteKeys[2];
				String poType = deleteKeys[3];

				String ow_fetch_ep;
				LOGGER.info("Validating for item :{}",itemNumber);
				JSONArray expectedOtns = parse(orderWellLines.toJSONString()).read("$.[?(@.wmtItemNumber=='"
							+ itemNumber+ "' && @.poNumber=='" + poNumber + "' && @.sourceNumber=='" + sourceNumber + "')].orderTrackingNumber",
						JSONArray.class);
				if(expectedOtns!=null&&!expectedOtns.isEmpty())
					LOGGER.info("Expected otns :{}",expectedOtns.toJSONString());
				if (poType.equals("3") || poType.equals("53") || poType.equals("43")) {

					ow_fetch_ep = getOrderWellManualPOUrl();

					/*
					 * Construction of the search payload
					 */
					JSONObject baseSearchObj = new JSONObject();
					JSONArray poNbrsArr = new JSONArray();
					poNbrsArr.add(poNumber);
					baseSearchObj.put("poNumbers", poNbrsArr);
					Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 20)).run(() -> {
						Response response = SerenityRest.given().body(baseSearchObj.toJSONString()).post(ow_fetch_ep);
						Assert.assertEquals(ErrorCodes.OW_STATUS_INVALID, 200, response.getStatusCode());

						// JSONArray otnFromResponse =
						// parse(response.getBody().asString()).read("$.orders[?(@.status=='New_DA_M')].orderTrackingNumber",
						// JSONArray.class);
						boolean areExpectedOtnsAvailable = parse(response.getBody().asString())
								.read("$.orders[*].orderTrackingNumber", JSONArray.class).containsAll(expectedOtns);
						// boolean areExpectedOtnsAvailable =
						// otnFromResponse.containsAll(expectedOtns);

						LOGGER.info("Verifying OW for downloaded orders : " + ow_fetch_ep + " with body : "
								+ baseSearchObj.toJSONString());

						Assert.assertTrue(ErrorCodes.OW_SOME_OR_ALL_OTN_NOT_AVAILABLE, areExpectedOtnsAvailable);
					});

				} else {

					ow_fetch_ep = MessageFormat.format(environment.getProperty("ow_fetch"), sourceNumber, itemNumber,
							String.valueOf(Integer.MAX_VALUE));

					Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 20)).run(() -> {

						LOGGER.info("Searching OW for new orders to be created : " + ow_fetch_ep);

						Response response = SerenityRest.when().get(ow_fetch_ep);

						JSONArray orderArr = parse(response.getBody().asString()).read("$.orders", JSONArray.class);
						LOGGER.info("waiting for orders to get created...response from ow:{}",
								response.getBody().asString());
						Assert.assertTrue(ErrorCodes.OW_ORDERS_NOT_AVAILABLE, orderArr.size() > 0);

						JSONArray actualOtnArray = JsonPath.parse(response.asString()).read("$..orderTrackingNumber");
						String jiraDesc="sourceNumber:"+sourceNumber+"\nItem Number:"+itemNumber+"\nExpected otns:"+expectedOtns.toJSONString()+"\nActual otns:"+actualOtnArray.toJSONString();
						boolean areExpectedOtnsAvailable = actualOtnArray.containsAll(expectedOtns);
						Assert.assertTrue(ErrorCodes.OW_SOME_OR_ALL_OTN_NOT_AVAILABLE, areExpectedOtnsAvailable,jiraDesc);
						if(Config.DC==DC_TYPE.ATLAS&& sourceNumber.equals(environment.getProperty("facility_num"))) {
							Assert.assertEquals(ErrorCodes.OW_EXTRA_ORDERS_FOUND, expectedOtns.size(),actualOtnArray.size(),jiraDesc);
						}else if(Config.DC==DC_TYPE.ATLAS&&!sourceNumber.equals(environment.getProperty("facility_num"))) {
							if(expectedOtns.size()!=actualOtnArray.size()) {
								LOGGER.info("*** OW_STALE_DATA- Source Number;{},Item Number:{},Expected otns:{}\nActual otns:{}",sourceNumber,itemNumber,expectedOtns.toJSONString(),actualOtnArray.toJSONString());
							}
						}
					});
				}
			}

			LOGGER.info("Verified that all orders are created in OW");
		} catch (AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating orders", e);
		}
	}

	@Step
	public void usingPoLineDataCreateOrderWellOrders(String distributions, String poPercentages, String itemNum) {
		usingPoLineDataCreateOrderWellOrders(distributions, poPercentages, false, itemNum);
	}

	@Step
	public void usingPoLineDataCreateOrderWellOrders(String distributions, String poPercentages,
			boolean isOverageOrdersRequired, String itemNum) {
		boolean isManualOrderExistsInOrderWell = false;
		try {
			String owMock = environment.getProperty("ow_mock");
			if (owMock != null && Boolean.parseBoolean(owMock)) {
				Config.isOrderWellMocked = true;
			}
			ArrayList<String> sourceNumberList = new ArrayList<>();

			ObjectMapper om = new ObjectMapper();
			String poLineItemDetail[] = itemNum.split("-");

			String[] distPoArr = distributions.split(";");
			HashMap<String, List<DestOrderCharacteristics>> poDetails = new HashMap<>();
			String tdf = (String) tl.get().get("testFlowData");
			JSONArray poNumbersArr = JsonPath.parse(tdf).read("$.testFlowData.poDetails..poNumber");
			if (poNumbersArr.size() < distPoArr.length) {
				LOGGER.info("Number of POs is less than order distribution. PO size {} order distribution size{}",
						poNumbersArr.size(), distPoArr.length);
				int poNumberSize = poNumbersArr.size();
				for (int i = 0; i < distPoArr.length - poNumberSize; i++) {
					LOGGER.info("Adding po {} to po arraylist for order creation", poNumbersArr.get(i));
					poNumbersArr.add(poNumbersArr.get(0));
				}
			}
			for (int i = ZERO; i < distPoArr.length; i++) {

				String[] poOrderTypeArr = distPoArr[i].split("-");

				String orderLinePercentage = poOrderTypeArr[ONE];
				String[] poPercentageArr = poPercentages.split(",");
				String srcDest = poOrderTypeArr[TWO];
				if (srcDest != null && srcDest.equalsIgnoreCase("SOURCE_DC") ) {
					if(environment.getProperty("order_well_src_number")!= null) {
						srcDest = environment.getProperty("order_well_src_number");
					} else {
						srcDest = environment.getProperty("facility_num");
					}
				}else if (srcDest != null && srcDest.equalsIgnoreCase("IMPORTS_DC") ) {
					srcDest = environment.getProperty("order_well_import_dc_src_number");
				}
				LOGGER.info("OrderWell Source Destination: {}", srcDest);
				sourceNumberList.add(srcDest);
				String orderLineDest = poOrderTypeArr[THREE];

				String[] poLineNumbers = poOrderTypeArr[ZERO].split(",");

				for (int j = 0; j < poLineNumbers.length; j++) {

					List<DestOrderCharacteristics> docl;

					docl = poDetails.containsKey(poLineNumbers[j]) ? poDetails.get(poLineNumbers[j])
							: new ArrayList<>();

					DestOrderCharacteristics doc = new DestOrderCharacteristics();

					doc.setPoPercentage(poPercentageArr[i]);
					doc.setOrderLinePercentage(orderLinePercentage);
					doc.setDestination(orderLineDest);
					doc.setSource(srcDest);

					docl.add(doc);

					if (!poDetails.containsKey(poLineNumbers[j]))
						poDetails.put(poLineNumbers[j], docl);
				}
			}

			if (tl.get().get("sourceNumberList") == null) {
				tl.get().put("sourceNumberList", sourceNumberList);
				LOGGER.info(sourceNumberList+":: added sourceNumberList into Test flow data");
			}

			HashMap<String, List<DestOrderCharacteristics>> poDetailsHash = replaceIndexWithPoNumbers(poDetails,
					poNumbersArr);
			List<PoDetail> poDetailsArr = (List<PoDetail>) jsonUtils.getPojoListfromPath(
					((JSONArray) JsonPath.read(tl.get().get("testFlowData").toString(), "$.testFlowData.poDetails[*]"))
							.toJSONString(),
					PoDetail.class);
			if (poDetailsArr.size() < distPoArr.length) {
				int poNumberSize = poDetailsArr.size();
				for (int i = 0; i < distPoArr.length - poNumberSize; i++) {
					poDetailsArr.add(poDetailsArr.get(0));
				}
			}
			JSONArray ja = null;
			if(Config.DC!=DC_TYPE.ATLAS) {
				ja = (tl.get().get("orderWellOrders") != null) ? (JSONArray) tl.get().get("orderWellOrders")
						: new JSONArray();
			}else {
				ja = new JSONArray();
			}

			List<OrdersDetail> ordersDetails;

			if (JsonPath.parse(tl.get().get("testFlowData").toString()).read("$..ordersDetails", JSONArray.class)
					.size() > 0) {

				ordersDetails = om.readValue(
						JsonPath.parse(tl.get().get("testFlowData").toString())
								.read("$..ordersDetails", JSONArray.class).get(0).toString(),
						new TypeReference<List<OrdersDetail>>() {
						});
			} else {
				ordersDetails = new ArrayList<>();
			}
			String poNumber = null;
			for (int i = 0; i < poDetailsArr.size(); i++) {

				PoDetail poDetail = poDetailsArr.get(i);

				poNumber = poDetail.getPoNumber();
				String sourceNumber = poDetail.getSourceNumber();
				String baseDiv = poDetail.getBaseDiv();
				String sourceCountryCode = poDetail.getSrcCountryCode();
				boolean isChannelFlipped = Boolean.parseBoolean(poDetail.getIsChannelFlipRequired());
				Boolean isPlannedPo = Boolean.parseBoolean(poDetail.getIsPlannedPo());

				List<PoLineDetail> poLineDetails = poDetail.getPoLineDetails();

				List<DestOrderCharacteristics> docl = poDetailsHash.get(i + "-" + poNumber);

				if (poDetail.getChannelMethod().equalsIgnoreCase("CROSSMU")) {

					JSONArray manualExistingPos = parse(tl.get().get("testFlowData").toString()).read(
							"$.testFlowData.ordersDetails[?(@.channelMethod=='CROSSMU')].plannedPo", JSONArray.class);

					if(System.getProperty("invalidDest") == null) {
					if (manualExistingPos.contains(poNumber))
						continue;
					}

					String ow_fetch_ep = getOrderWellManualPOUrl();

					JSONObject baseSearchObj = new JSONObject();
					JSONArray poNbrsArr = new JSONArray();
					poNbrsArr.add(poNumber);
					baseSearchObj.put("poNumbers", poNbrsArr);

					Response response = SerenityRest.given().body(baseSearchObj.toJSONString()).post(ow_fetch_ep);

					if (response.getBody().asString().length() > 4) {
						JSONArray ordersArr = parse(response.getBody().asString()).read("$.orders[*]", JSONArray.class);

						for (int j = 0; j < ordersArr.size(); j++) {

							LinkedHashMap orders = (LinkedHashMap) ordersArr.get(j);
							JSONArray ordersMatchingItem = JsonPath.parse(om.writeValueAsString(poLineDetails)).read(
									"$[*].[?(@.itemNumber=='" + orders.get("wmtItemNumber").toString() + "')]",
									JSONArray.class);

							if (!ordersMatchingItem.isEmpty()) {

								LinkedHashMap lineDet = (LinkedHashMap) ordersMatchingItem.get(0);

								OrdersDetail od = new OrdersDetail();
								od.setDestinationNum(orders.get("destinationNumber").toString());
								od.setSourceNumber(orders.get("sourceNumber").toString());
								od.setOrderTrackingNumber(orders.get("orderTrackingNumber").toString());

								String cm = poDetail.getChannelMethod();

								OrderReference or = null;

								if (cm.equals("CROSSMU")) {
									or = OrderReference.MANUAL_3;
								}

								od.setOrderRecordType(or.orderRecordType);
								od.setPriority(orders.get("priorityNbr").toString());

								od.setQuantity(orders.get("quantity").toString());
								od.setItemNumber(orders.get("wmtItemNumber").toString());
								od.setChannelMethod(poDetail.getChannelMethod());
								od.setWhpk(lineDet.get("whpk").toString());
								od.setVnpk(lineDet.get("vnpk").toString());

								od.setPlannedPo(String.valueOf(isPlannedPo));
								od.setWhpkSellPrice(lineDet.get("whpkSellPrice").toString());
								od.setOmsChannelMethod(orders.get("poType").toString());
								od.setPlannedPo(poNumber);
								
								if(System.getProperty("invalidDest") != null) {
									List<String> ordersListOnTestFLowData = JsonPath.read(tdf,
											"$.testFlowData.ordersDetails[*]..orderTrackingNumber");
									if (ordersListOnTestFLowData.contains(od.getOrderTrackingNumber())) {
										continue;
									}
								}

								ordersDetails.add(od);
								if (orders.get("poNumber").equals(poNumber)) {
									LOGGER.info("PO {} already exists in OW,No need to publish", poNumber);
									isManualOrderExistsInOrderWell = true;
								}
								net.minidev.json.JSONObject jo = new net.minidev.json.JSONObject();
								jo = populateExistingOrders(jo, orders);
								jo.put("poNumber", poNumber);
								ja.add(jo);
							}
						}
						continue;
					}
				}

				for (int j = 0; j < poLineDetails.size(); j++) {

					PoLineDetail poLineDetail = poLineDetails.get(j);

					String channelMethod = poLineDetail.getChannelMethod();

					DestOrderCharacteristics doc = docl.get(j % docl.size());

					String destination = doc.getDestination();
					String orderLinePercentage = doc.getOrderLinePercentage();
					String poPercentage = doc.getPoPercentage();
					JSONArray destinationArray = null;

					if (channelMethod.equalsIgnoreCase("CROSSMU")) {
						destinationArray = parse(poLineDetail.getDestNumber()).read("$", JSONArray.class);
					}

					String poLineNumber;
					String itemNumber;
					if (itemNum.isEmpty() || itemNum.contentEquals("")) {
						LOGGER.info("Item VALUEEEE:{}", itemNum);
						itemNumber = poLineDetail.getItemNumber();
						poLineNumber = poLineDetail.getPoLineNumber();

					} else {
						itemNumber = poLineItemDetail[1];
						poLineNumber = poLineItemDetail[0];

					}
					String whpkSellPrice = poLineDetail.getWhpkSellPrice();
					String poVnpkQty = poLineDetail.getPoVnpkQty();
					String poWhpkQty = poLineDetail.getPoWhpkQty();
					String vnpk = poLineDetail.getVnpk();
					String destCountryCode = "US"/*
													 * poLineDetail. getDestCountryCode()TODO
													 */;

					String whpk = poLineDetail.getWhpk();
					String departmentNumber = poLineDetail.getDepartmentNumber();

					String omsChannelMethod = poLineDetail.getOmsChannelMethod();

					OrderReference orderReference;
					String cm = omsChannelMethod.toLowerCase();

					orderReference = setOrderRefernceOnOmsChannel(cm);
					if (isChannelFlipped) {
						orderReference = (orderReference == OrderReference.DA) ? OrderReference.SSTK
								: OrderReference.DA;
					}
					String ti = poLineDetail.getTi();
					String isConveyable = poLineDetail.getIsConveyable();
					String itemUpc;
					int ovgQtyVal;
					if (itemNum.isEmpty() || itemNum.contentEquals("")) {
						itemUpc = poLineDetail.getItemUpc();

					} else
						itemUpc = poLineItemDetail[2];
					// String itemUpc = poLineDetail.getItemUpc();
					String POMATCH = "$.testFlowData.poDetails[?(@.poNumber == '";
					String ITMMATCH = "')].poLineDetails[?(@.itemNumber==";
					String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
					DocumentContext parsedJson = JsonPath.parse(testFlowData);
					int poVnpkQtyVal;
					if (itemNum.isEmpty() || itemNum.contentEquals("")) {
						List<String> ovgQty = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNumber + ")].ovgQty");
						ovgQtyVal = Integer.parseInt(ovgQty.get(0));
						poVnpkQtyVal = Integer.parseInt(poVnpkQty);
					} else {
						ovgQtyVal = Integer.parseInt(poLineItemDetail[4]);
						poVnpkQtyVal = Integer.parseInt(poLineItemDetail[4]);
					}

					int sum = 0;
					int requiredPoQty = (poVnpkQtyVal * Integer.parseInt(poPercentage)) / 100;
					LOGGER.info("Total PO Order Quantity:{}", poVnpkQtyVal);
					LOGGER.info("Total Required Order Quantity:{}", requiredPoQty);
					LOGGER.info("Total Overage Order Quantity:{}", ovgQtyVal);
					LOGGER.info("Is Overage qty to be created ?:{}", isOverageOrdersRequired);
					int remainingQtyVnpk = requiredPoQty;
					LOGGER.info("	remaining QTY:{}", remainingQtyVnpk);

					int currentOrderVnpk = 0;
					for (int k = 0; remainingQtyVnpk > 0; k++) {

						ti = ti == null || ti.equals("null") ? "8" : ti;

						if (orderLinePercentage.toLowerCase().contains("pbyl")) {
							if (requiredPoQty <= 10) {
								currentOrderVnpk = 1;
							} else {
								currentOrderVnpk = RandomUtils.nextInt(1, Integer.parseInt(ti));
							}
							/*
							 * if(requiredPoQty<Integer.parseInt(ti)) { currentOrderVnpk=requiredPoQty;
							 * }else { currentOrderVnpk = RandomUtils.nextInt(1, Integer.parseInt(ti)); }
							 */
						} else if (orderLinePercentage.toLowerCase().contains("%")) {
							String olp = orderLinePercentage.split("%")[ZERO];
							currentOrderVnpk = (requiredPoQty * Integer.parseInt(olp)) / 100;
						} else if (orderLinePercentage.toLowerCase().contains("gtl")) {

							if (Integer.parseInt(ti) > remainingQtyVnpk) {
								currentOrderVnpk = remainingQtyVnpk;
							} else {
								currentOrderVnpk = RandomUtils.nextInt(Integer.parseInt(ti), requiredPoQty + 1);
							}
						}

						if (currentOrderVnpk > remainingQtyVnpk) {
							currentOrderVnpk = remainingQtyVnpk;
						}

						OrdersDetail od = new OrdersDetail();
						od.setIsOverage(false);
						if (isOverageOrdersRequired || (Integer.parseInt(poPercentage) > 100&& Config.DC==DC_TYPE.ATLAS)) {
							if (sum == 0) {// This is the first order
								if (requiredPoQty <= poVnpkQtyVal) {// if the
																	// required
																	// qty is
																	// less than
																	// or equal
																	// po qty
									remainingQtyVnpk = requiredPoQty + ovgQtyVal;
									currentOrderVnpk = requiredPoQty;
								} else {
									currentOrderVnpk = poVnpkQtyVal;// Create
																	// the first
																	// order
																	// with
																	// povnpk
																	// qty
								}
							} else {

								od.setIsOverage(true);

								if (remainingQtyVnpk > ovgQtyVal)
									currentOrderVnpk = ovgQtyVal;
								else
									currentOrderVnpk = remainingQtyVnpk;// all the orders after first order should be
																		// created with
								// order qty overageqty
							}
						}
						LOGGER.info("Order Quantity in Order{}:{}", (k + 1), currentOrderVnpk);
						net.minidev.json.JSONObject jo = new net.minidev.json.JSONObject();

						/*
						 * This was earlier being taken from the PO. Don't delete this.
						 */
						// jo.put("sourceNumber", sourceNumber);

						jo.put("sourceNumber", doc.getSource());
						jo.put("orderDate", System.currentTimeMillis());
						jo.put("wmtItemNumber", itemNumber);
						if(Config.DC==DC_TYPE.SAMS&&channelMethod.equalsIgnoreCase("CROSSMU")) {
							String storeNumber;
							if(destinationArray.isEmpty()) {
								throw new AutomationFailure("No destinations found in the manual PO");
							}
							if(k<destinationArray.size()) {
								storeNumber= destinationArray.get(k).toString();
							}else {
								storeNumber= destinationArray.get(destinationArray.size()-1).toString();
							}
							LOGGER.info("Destination:{} quantity:{}", storeNumber,currentOrderVnpk);
							od.setDestinationNum(storeNumber);
							jo.put("destinationNumber", storeNumber);
						}
						else if (channelMethod.equalsIgnoreCase("CROSSMU")) {

							String storeNumber = destinationArray.get(k % destinationArray.size()).toString();
							od.setDestinationNum(storeNumber);
							jo.put("destinationNumber", storeNumber);
							// remove if does not work
							if(System.getProperty("invalidDest") != null) {
								jo.put("destinationNumber", doc.getDestination());
							}

						} else {
							jo.put("destinationNumber", destination);
							od.setDestinationNum(destination);
						}

						UUID uuid = UUID.randomUUID();
						jo.put("orderTrackingNumber", uuid.toString());
						if(Config.DC==DC_TYPE.SAMS) {
							jo.put("externalPoNumber",poNumber);
						}
						jo.put("baseDivNumber", baseDiv);
						jo.put("departmentNumber", departmentNumber);
						jo.put("destCountryCode", destCountryCode);
						jo.put("needType", "");

						jo.put("messageType", "%");
						jo.put("orderRecordType", orderReference.orderRecordType);
						jo.put("packType", "C");
						jo.put("poLineNumber", poLineNumber);
						jo.put("poNumber", poNumber);

						jo.put("poType", orderReference.poType);
						jo.put("priorityReason", "");
						jo.put("priorityNbr", k + 1);
						jo.put("processName", "gls_end_to_end");
						jo.put("quantity", (currentOrderVnpk * Integer.parseInt(vnpk)));

						jo.put("reason", "");
						jo.put("sourceCountryCode", sourceCountryCode);
						jo.put("status", orderReference.status);
						jo.put("whseAreaCode", "0");// This can be changed to be
													// dynamic
						jo.put("upcNumber", itemUpc);
						jo.put("vnpkQuantity", vnpk);
						jo.put("whpkQuantity", whpk);

						od.setOrderTrackingNumber(uuid.toString());
						od.setOrderRecordType(orderReference.orderRecordType);
						od.setPriority(String.valueOf(k + 1));

						od.setQuantity(String.valueOf(currentOrderVnpk * Integer.parseInt(vnpk)));
						od.setItemNumber(itemNumber);
						od.setChannelMethod(channelMethod);
						od.setWhpk(whpk);
						od.setVnpk(vnpk);
						od.setPlannedPo(String.valueOf(isPlannedPo));
						od.setWhpkSellPrice(whpkSellPrice);
						od.setOmsChannelMethod(omsChannelMethod);
						od.setPlannedPo(poNumber);

						od.setSourceNumber(doc.getSource());
						if(System.getProperty("invalidDest") != null) {
							od.setDestinationNum(doc.getDestination());
							List<String> ordersListOnTestFLowData = JsonPath.read(testFlowData,
									"$.testFlowData.ordersDetails[*]..orderTrackingNumber");
							if (ordersListOnTestFLowData.contains(od.getOrderTrackingNumber())) {
								continue;
							}
						}

						ja.add(jo);
						ordersDetails.add(od);

						sum += currentOrderVnpk;
						remainingQtyVnpk = remainingQtyVnpk - currentOrderVnpk;

					}
				}
			}

			if (!Config.isOrderWellMocked) {
				if (!isManualOrderExistsInOrderWell) {
					clearOrderWell(ja);
					LOGGER.info("The Order Well messages that are ready to publish is : " + ja.toJSONString());
					kafkaUtils.publish(ja);
				} else {
					createUniqueDeleteKeys(ja);
				}
			} else {
				orderWellMock.createOrders(ja);
			}

			if (!poPercentages.equals("259")) {
				// TestFlowDataMain testFlowData_ = parse((String)
				// tl.get().get("testFlowData")).read("$",
				// TestFlowDataMain.class);
				// TestFlowData testFlowData = testFlowData_.getTestFlowData();
				JSONArray orderDetailsList = jsonUtils.converyListToJsonArray(ordersDetails);

				JSONObject testFlowData = jsonUtils
						.convertStringToMinidevJsonObject(tl.get().get("testFlowData").toString());
				String testData = jsonUtils.setJsonAtJsonPath(testFlowData.toJSONString(), orderDetailsList,
						"$.testFlowData.ordersDetails");
				if (itemNum.isEmpty() || itemNum.contentEquals("")) {
					tl.get().put("testFlowData", testData);

				} else {
					JSONArray poLine = JsonPath.parse(testData)
							.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[*]");

					List<PoLineDetail> listOfDeliveries = (List<PoLineDetail>) jsonUtils
							.getPojoListfromPath(poLine.toJSONString(), PoLineDetail.class);

					PoLineDetail newLine = new PoLineDetail();
					PoLineDetail existingLine = new PoLineDetail();
					existingLine = listOfDeliveries.get(0);

					newLine.setItemNumber(poLineItemDetail[1]);
					newLine.setPoLineNumber(poLineItemDetail[0]);
					newLine.setItemUpc(poLineItemDetail[2]);
					newLine.setChannelMethod(existingLine.getChannelMethod());
					newLine.setVnpk(existingLine.getVnpk());

					newLine.setDepartmentNumber(existingLine.getDepartmentNumber());
					newLine.setWhpk(existingLine.getWhpk());
					newLine.setWhpkSellPrice(poLineItemDetail[3]);
					newLine.setOvgQty(existingLine.getOvgQty());
					// newLine.setPoVnpkQty(existingLine.getPoVnpkQty());
					newLine.setPoVnpkQty(poLineItemDetail[4]);

					newLine.setIsConveyable(existingLine.getIsConveyable());
					newLine.setOmsChannelMethod(existingLine.getOmsChannelMethod());

					listOfDeliveries.add(newLine);
					JSONArray poLineArr = jsonUtils.converyListToJsonArray(listOfDeliveries);

					LOGGER.info("Po LIne JsonArray : " + poLineArr.toJSONString());

					String updatedTestFlow = jsonUtils.setJsonAtJsonPath(testData, poLineArr, "$..poLineDetails");
					tl.get().put("testFlowData", updatedTestFlow);
					LOGGER.info("Po LIne Test FLow : " + tl.get().get("testFlowData"));
					preRunCleanup.cleanUpOPForItemAtlas(Integer.parseInt(poLineItemDetail[1]));
				}

			}
			tl.get().put("orderWellOrders", ja);
		} catch (AssertionError e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating orders", e);
		}

	}
	
	private OrderReference setOrderRefernceOnOmsChannel(String cm) throws Exception {

		OrderReference orderReference;

		if (cm.equals("33")) {
			orderReference = OrderReference.DA;
		} else if (cm.equals("20")) {
			orderReference = OrderReference.SSTK;
		} else if (cm.equals("3")) {
			orderReference = OrderReference.MANUAL_3;
		} else if (cm.equals("43")) {
			orderReference = OrderReference.MANUAL_43;
		}  else if (cm.equals("53")) {
			orderReference = OrderReference.MANUAL_53;
		} else
			throw new Exception("Invalid channel Method : " + cm);

		return orderReference;
	}

	private JSONObject populateExistingOrders(JSONObject jo, LinkedHashMap orders) {

		jo.put("sourceNumber", orders.get("sourceNumber"));
		jo.put("orderDate", System.currentTimeMillis());
		jo.put("wmtItemNumber", orders.get("wmtItemNumber"));

		jo.put("destinationNumber", orders.get("destinationNumber"));
		jo.put("orderTrackingNumber", orders.get("orderTrackingNumber"));
		if(Config.DC==DC_TYPE.SAMS) {
			jo.put("externalPoNumber", orders.get("poNumber"));
			
		}
		jo.put("baseDivNumber", orders.get("baseDivNumber"));
		jo.put("departmentNumber", orders.get("departmentNumber"));
		jo.put("destCountryCode", orders.get("destCountryCode"));
		jo.put("needType", orders.get("needType"));

		jo.put("messageType", orders.get("messageType"));
		jo.put("orderRecordType", orders.get("orderRecordType"));
		jo.put("packType", orders.get("packType"));
		jo.put("poLineNumber", orders.get("poLineNumber"));

		jo.put("poType", orders.get("poType"));
		jo.put("priorityReason", orders.get("priorityReason"));
		jo.put("priorityNbr", orders.get("priorityNbr"));
		jo.put("processName", orders.get("processName"));
		jo.put("quantity", orders.get("quantity"));

		jo.put("reason", orders.get("reason"));
		jo.put("sourceCountryCode", orders.get("sourceCountryCode"));
		jo.put("status", orders.get("status"));
		jo.put("whseAreaCode", orders.get("whseAreaCode"));// This can be
															// changed to be
															// dynamic
		jo.put("upcNumber", orders.get("upcNumber"));
		jo.put("vnpkQuantity", orders.get("vnpkQuantity"));
		jo.put("whpkQuantity", orders.get("whpkQuantity"));

		return jo;

	}

	@Step
	public void verifyThatBajaOrdersAreCreatedInOrderWell() {
		try {
			if (Config.isOrderWellMocked) {
				return;
			}
			String testFlowData = threadLocal.get().get("testFlowData").toString();
			List<String> otns = JsonPath.read(testFlowData, "$..orderTrackingNumber");
			LOGGER.info("otns:{}", otns);

			ObjectMapper om = new ObjectMapper();
			// creating object of a class

			OrdersSearch os = new OrdersSearch();
			// os.setOrders(origTrackingNbrs);
			os.setOrderTrackingNum(otns);

			String requestBody = om.writeValueAsString(os);
			LOGGER.info("Request Payload for searching in OW:{}", requestBody);
			String requestBodyFailSafe = requestBody;

			LOGGER.info("Validating if orders are created in Order Well: {}");
			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 10)).run(() -> {

				Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
						.post(environment.getProperty("ow_otn_search"));
				Assert.assertEquals(ErrorCodes.OW_OTN_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			});

			Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
					.post(environment.getProperty("ow_otn_search"));
			JSONArray searchedOtns = JsonPath.parse(response.getBody().asString()).read("$.orders", JSONArray.class);
			Assert.assertEquals(ErrorCodes.OW_SOME_OR_ALL_OTN_NOT_AVAILABLE, otns.size(), searchedOtns.size());
		} catch (AssertionError e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating orders in order well", e);
		}

	}

	@Step
	public void verifyOrderStatusInOrderWell(String expStatus) {
		try {
			String testFlowData = threadLocal.get().get("testFlowData").toString();
			List<String> otns = JsonPath.read(testFlowData, "$..orderTrackingNumber");
			LOGGER.info("otns:{}", otns);
			ObjectMapper om = new ObjectMapper();
			OrdersSearch os = new OrdersSearch();
			os.setOrderTrackingNum(otns);
			String requestBody = om.writeValueAsString(os);
			LOGGER.info("Request Payload for searching in OW:{}", requestBody);
			String requestBodyFailSafe = requestBody;
			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 10)).run(() -> {
				Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
						.post(environment.getProperty("ow_otn_search"));
				Assert.assertEquals(ErrorCodes.OW_OTN_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				JSONArray status = JsonPath.read(response.asString(), "$.orders..status");
				String actualStatus=status.get(0).toString();
				Assert.assertEquals(ErrorCodes.OW_ORDER_STATUS_NOT_UPDATED, expStatus,
						actualStatus);
				LOGGER.info("The current status of OTN: {} in OW is : {}", otns,actualStatus);
			});
		} catch (AssertionError e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating order status in order well", e);
		}

	}


	enum OrderReference {

		SSTK("20", "SSTK", "New"), SSTK_SHORTAGE("20", "STAPLE_SHORTAGE", "New"), DA("33", "XDOCK", "New"), DA_SHORTAGE(
				"33", "XDOCK_SHORTAGE",
				"New"), MANUAL_3("3", "XDOCK_Manual", "New_DA_M"), MANUAL_53("53", "XDOCK_Manual", "New_DA_M"),MANUAL_43("43", "XDOCK_Manual", "New_DA_M");

		String poType, status, orderRecordType;

		OrderReference(String poType, String orderRecordType, String status) {
			this.poType = poType;
			this.orderRecordType = orderRecordType;
			this.status = status;
		}
	}

	private HashMap<String, List<DestOrderCharacteristics>> replaceIndexWithPoNumbers(
			HashMap<String, List<DestOrderCharacteristics>> poDetails, JSONArray poNumbersArr) {

		HashMap<String, List<DestOrderCharacteristics>> poNamedHashMap = new HashMap<>();

		Set<String> indexes = poDetails.keySet();
		Iterator<String> indexIterator = indexes.iterator();

		int count = 0;
		while (indexIterator.hasNext() && count < poNumbersArr.size()) {
			String index = indexIterator.next();
			poNamedHashMap.put(count + "-" + poNumbersArr.get(count).toString(), poDetails.get(index));
			count++;
		}

		return poNamedHashMap;
	}

	public void resetOrderDetails() {
		try {
			tl.get().put("orderWellOrders", null);
		} catch (Exception e) {

			throw new AutomationFailure("Failed to re-set orderWellOrders", e);

		}

	}

	/*
	 * Baja Order creation
	 */

	public void createOrderWellOrders(String wmtItemNumber, String quantity, String whpkQuantity, String Store,
			String vnpkQuantity) throws JSONException {

		JSONArray ja = new JSONArray();

		String[] allItem = wmtItemNumber.split(",");
		LOGGER.info("allItem:{}", allItem.length);

		List<OrdersDetail> listOfOTNs = new ArrayList<>();
		for (int i = 0; i < allItem.length; i++) {

			OrdersDetail orderDetail = new OrdersDetail();
			net.minidev.json.JSONObject jo = new net.minidev.json.JSONObject();

			jo.put("upcNumber", "7874215903");
			jo.put("whseAreaCode", "0");// This can be changed to be dynamic

			LOGGER.info("Item for order :{}", allItem[i]);

			jo.put("wmtItemNumber", allItem[i]);// to be added in feature
			jo.put("quantity", quantity);// to be added in feature
			jo.put("packType", "C");
			jo.put("sourceNumber", "7390");
			jo.put("whpkQuantity", whpkQuantity);// to be added in feature 12
			jo.put("destinationNumber", Store);// to be added in feature
			jo.put("destCountryCode", "US");
			jo.put("sourceCountryCode", "US");
			jo.put("messageType", "95");
			jo.put("vendorNumber", 810986900);
			jo.put("processName", "GLS-Test");
			UUID uuid = UUID.randomUUID();
			jo.put("orderTrackingNumber", uuid.toString());
			jo.put("baseDivNumber", 1);
			jo.put("orderDate", System.currentTimeMillis() - (86400000 * 2));
			jo.put("vnpkQuantity", vnpkQuantity);// to be added in feature
			jo.put("status", "new");
			jo.put("departmentNumber", 90);
			jo.put("orderRecordType", "GRS System Picks");

			ja.add(jo);

			// Adding data in testFlow json
			orderDetail.setOrderTrackingNumber(uuid.toString());
			orderDetail.setItemNumber(allItem[i]);
			orderDetail.setWhpk(whpkQuantity);
			orderDetail.setVnpk(vnpkQuantity);
			orderDetail.setDestinationNum(Store);
			orderDetail.setQuantity(quantity);
			orderDetail.setReleaseNbr("");

			listOfOTNs.add(orderDetail);
		}

		kafkaUtils.publish(ja);
		TestFlowDataMain main = new TestFlowDataMain();
		TestFlowData testFlowData = new TestFlowData();
		testFlowData.setOrdersDetails(listOfOTNs);
		main.setTestFlowData(testFlowData);
		try {
			String testFlowDataVal = new ObjectMapper().writeValueAsString(main);
			threadLocal.get().put("testFlowData", testFlowDataVal);
			LOGGER.info("testFlowData:{}", testFlowDataVal);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

	}

	public void sendTriggerForBajaOrdersDownload() {
		kafkaUtils.sendTriggerBajaToDownloadOrders();
	}
	
	@Step
	public void updateOrderStatus(String status) {
		try {
			String testFlowData = threadLocal.get().get("testFlowData").toString();
			List<String> itemNumbers = JsonPath.parse(testFlowData).read(ITEM_NUMEBR_JSON_PATH);
			List<String> uniqueItemNumbers = new ArrayList<>();
			for(int itemNumber =0;itemNumber<itemNumbers.size();itemNumber++) {
				if (!uniqueItemNumbers.contains(itemNumbers.get(itemNumber))) {
					uniqueItemNumbers.add(itemNumbers.get(itemNumber));
				}
			}
			for (String itemNum : uniqueItemNumbers) {
				LOGGER.info("Updating order status for an item: {} in OW to: {}",itemNum, status);
				JSONArray otnArray = JsonPath.parse(testFlowData).read("$..ordersDetails[?(@.itemNumber=="+itemNum+")].orderTrackingNumber");
				JSONObject jo = new JSONObject();
				JSONArray baseArrElement = new JSONArray();
				for (int j = 0; j < otnArray.size(); j++) {
					JSONObject otnElement = new JSONObject();
					otnElement.put("orderTrackingNumber", otnArray.get(j).toString());
					otnElement.put("status", status);
					baseArrElement.add(otnElement);
				}
				jo.put("updateList", baseArrElement);
				Failsafe.with(retryPolicy).run(() -> {
				Response updateStatusResponse = SerenityRest.given().body(jo.toString())
						.put(environment.getProperty("ow_status_change"));
				Assert.assertEquals(ErrorCodes.OW_UNABLE_TO_UPDATE_ORDER_STATUS, Constants.SUCESS_STATUS_CODE, updateStatusResponse.getStatusCode());
				});
				LOGGER.info("Updated order status for an item: {} in OW to: {}",itemNum, status);
			}
		}catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while updating order status in OW",e);
		}
	}
}
