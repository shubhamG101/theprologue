package com.walmart.supplychain.thor.DCFIN.scenariosteps;

import com.walmart.supplychain.thor.DCFIN.steps.DCFINSteps;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class DCFINScenarios {
	
	@Steps
	DCFINSteps dCFINSteps;
	
	@When("^user verifies Warehouse Average cost and Balance On Hand for the item in DCfFin$")
	public void userValidatesWareHouseAverageCostAndBalanceOnHand()
	{
		dCFINSteps.validateWavandBOH();
	}

}
