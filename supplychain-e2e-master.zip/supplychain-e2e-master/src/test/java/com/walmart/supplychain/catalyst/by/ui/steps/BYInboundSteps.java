package com.walmart.supplychain.catalyst.by.ui.steps;

import java.util.HashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.supplychain.catalyst.by.ui.pages.BYExtensionsPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYInventoryPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYProblemsPage;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYQcDashboardPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYReceivingPage;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYInboundSteps  extends ScenarioSteps {

	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	BYReceivingPage byReceivingPage;
	
	@Autowired
	BYQcDashboardPage byQcDashboardPage;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	BYProblemsPage byProblemsPage;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	BYInventoryPage byInventoryPage;
	
	@Autowired
	BYExtensionsPage byExtensionsPage;
	
	String TEST_FLOW_DATA = "testFlowData";
	
	private static final String GET_LPN_NUMBER = "$..receivingInstructions..parentContainer";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	
	@Step
	public void changeQcStatus(String newStatus) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray listOfLpns = JsonPath.read(testFlowData, GET_LPN_NUMBER);
		byQcDashboardPage.clickOnFreightDashboardExpansionButton();
		byQcDashboardPage.verifyFreightDashboardHeading();		
		byQcDashboardPage.selectLpn(listOfLpns.get(0).toString());			
		byQcDashboardPage.clickOnActionsButton();
		byQcDashboardPage.clickOnChangeInventoryStatusOption();		
		byQcDashboardPage.clickOnInventoryStatusCodeDropdown();
		byQcDashboardPage.selectNewInventoryStatusFromDropdownList(newStatus);
		byQcDashboardPage.clickOnExecuteActionButton();	
		Failsafe.with(retryPolicy).run(() -> {
		byQcDashboardPage.clickFreightDashboardCloseButton();
		});
	}


	@Step
	public void createProblemTicketForUnexpectedItem() throws Exception {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray listOfLpns = JsonPath.read(testFlowData, GET_LPN_NUMBER);
		getDriver().switchTo().defaultContent();
		byInventoryPage.switchToFrameByPartialName("Problems");
		byProblemsPage.verifyProblemsPageHeading();
		byExtensionsPage.enterValueUnderFilterBox("rpFilter", "Any", "=", listOfLpns.get(0).toString());
		byProblemsPage.selectLpn(listOfLpns.get(0).toString());
		byProblemsPage.clickOnActionsButton();
		byProblemsPage.clickUpdateReasonCodeAndTicketNumber();
		byProblemsPage.toggleProblemTicketFlag();
		byProblemsPage.verifyProblemTicketTextBoxIsEnabled();
		byProblemsPage.enterProblemTicket();
		byProblemsPage.clickProblemTypeDropdown();
//		byProblemsPage.selectProblemType();
		byProblemsPage.clickOnExecuteActionButton();
	}

	
	@Step
	public void changeInventoryStatus(String newStatus) {
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray listOfLpns = JsonPath.read(testFlowData, GET_LPN_NUMBER);
		byInventoryPage.switchToFrame("receiving");
		byInventoryPage.enterValueUnderFilterTB("rpFilterableViews", "LPN", listOfLpns.get(0).toString());
		byInventoryPage.clickOnLpnsTab();
		byInventoryPage.clickLpnCheckboxButton();
		byInventoryPage.clickOnActionsButton();
		byInventoryPage.clickOnChangeInventoryStatusOption();
		byInventoryPage.clickOnStatusExpandButton();
		byInventoryPage.selectStatus(newStatus);
		byInventoryPage.clickOnOkButtonOnInventoryStatusChangeWindow();
		byInventoryPage.clickResultsOkButton();
	}	

}

