package com.walmart.supplychain.catalyst.by.webservices.steps;

import static net.serenitybdd.rest.SerenityRest.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;

import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYWebservicesHelper {
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	JavaUtils javaUtils;
	
	
	private Response responseBY;
	private static Cookies cookies;
	
	
	
	public Cookies getAuthorization() {
		
		responseBY = given().relaxedHTTPSValidation().when().get(environment.getProperty("by_api_baseUrl") + environment.getProperty("by_auth_ep"),
				environment.getProperty("receiving_p"), environment.getProperty("userName"));
		
		cookies = responseBY.getDetailedCookies();
		Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_NOT_AUTHORIZED, Constants.SUCESS_STATUS_CODE, responseBY.getStatusCode());
		return cookies;
		
	}
	
	
	public Response getInboundShipmentResponse(String delNum) {
		
		responseBY = given().cookies(cookies).relaxedHTTPSValidation().when().get(environment.getProperty("by_api_baseUrl") + 
				environment.getProperty("by_ibd_shipment_ep"), delNum, environment.getProperty("dcNumber"));
		
		return responseBY;
	}
	
	
	public Response getTransportEqipmentResponse(String delNum) {
		
		responseBY = given().cookies(cookies).relaxedHTTPSValidation().when().get(environment.getProperty("by_api_baseUrl") + 
				environment.getProperty("by_transport_equipment_ep"), delNum, environment.getProperty("dcNumber"));
		
		return responseBY;
	}
	
	
	public Response getPO_ItemResponse(String delNum) {
		
		responseBY = given().cookies(cookies).relaxedHTTPSValidation().when().get(environment.getProperty("by_api_baseUrl") + 
				environment.getProperty("by_PO_Line_ep"), delNum, environment.getProperty("dcNumber"));
		
		return responseBY;
	}
	
	
	public Response getContainerDetailsResponse(String resourceId) {
		
		responseBY = given().cookies(cookies).relaxedHTTPSValidation().when().get(environment.getProperty("by_api_baseUrl") + 
				environment.getProperty("by_containerDetails_ep"), resourceId);
		
		return responseBY;
	}
	
   public Response getPOResponse(String delNum) {
		
		responseBY = given().cookies(cookies).relaxedHTTPSValidation().when().get(environment.getProperty("by_api_baseUrl") + 
				environment.getProperty("by_PO_ep"), delNum, environment.getProperty("dcNumber"));
		
		return responseBY;
	}

}
