package com.walmart.supplychain.nextgen.of.scenariosteps.webservices;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import org.json.JSONException;

import com.walmart.supplychain.nextgen.of.steps.webservices.OrderFulfillmentSteps;

public class OrderFulfillmentScenario {

	@Steps
	OrderFulfillmentSteps ofSteps;

	@Then("^user verifies the fulfillment status$")
	public void user_verifies_the_fulfillment_status() throws JSONException {
//		ofSteps.fetchOfFulFillmentResponse();
	}
	
	@Then("^user verifies the fulfillment status in OF$")
	public void user_verifies_the_fulfillment_statusOF() throws JSONException {
		ofSteps.fetchOfFulFillmentResponseACC();
	}
	
	@Then("^OF should change the container status to \"([^\"]*)\"$")
	public void user_verifies_the_fulfillment_status_after_vtr(String status) throws JSONException {
		ofSteps.validateFulfillmentResponseAfterVTR(status);
	}
	
	@Then("^OF should change the damage container status to \"([^\"]*)\"$")
	public void user_verifies_the_damage_fulfillment_status_after_vtr(String status) throws JSONException {
		ofSteps.validateFulfillmentResponseAfterDamage(status);
	}
	
	@And("^user verifies Delivery finalization in OF$")
	public void user_verifies_Delivery_finalization_in_of() throws JSONException {
		ofSteps.validateDeliveryFinalization();
	}
	
	@Then("^user verifies the fulfillment status in OF for partial receiving$")
	public void user_verifies_the_fulfillment_status_in_OF_for_partial_receiving() throws JSONException {
		ofSteps.validatePartialReceiving();
	}
	
	
	@And("^user verifies that label data for cancelled pallet in OF$")
	public void verifyCancelledLabelData() {
		ofSteps.checkCancelledLabels();
	}
	
}
