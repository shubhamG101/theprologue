package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class ReceivingItemQtyPage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/tv_item_number_rdc']")
	private WebElement itemNbr;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_palletQtyReceiveEntry']")
	private WebElement recvTxt;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/mbtn_upcReceive']")
	private WebElement recvBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/button1']")
	private WebElement cnfrmSlotBtn;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_slot_size']")
	private WebElement slotSizeTxt;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_primaryAction']")
	private WebElement slotCnfrmBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/button1']")
	private WebElement ovgWarningBtn;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/action_cancel_pallet']")
	private WebElement cancelPalletBtn;

	@FindBy(xpath = ".//*[@text='Yes, cancel pallet']")
	private WebElement cancelPalletConfirmBtn;

	public String getItemNbr() {
		String item = null;
		try {
			element(itemNbr).waitUntilVisible();
			item = element(itemNbr).getText();
		} catch (Exception e) {

		}
		return item;

	}

	public void enterReceiveQtyAndReceive(String recvQty) {
		try {

			element(recvTxt).waitUntilVisible();
			element(recvTxt).type(recvQty);

			element(recvBtn).waitUntilVisible();
			element(recvBtn).click();

		} catch (Exception e) {

		}
	}

	public void clickReceiveBtn() {
		try {

			element(recvBtn).waitUntilVisible();
			element(recvBtn).click();

		} catch (Exception e) {

		}
	}

	public void clickOvgWarningBtn() {
		try {

			element(ovgWarningBtn).waitUntilVisible();
			element(ovgWarningBtn).click();

		} catch (Exception e) {

		}
	}

	public void confirmSlotSizeForPartialReceiving(String slotSize) {
		try {

			element(cnfrmSlotBtn).waitUntilVisible();
			element(cnfrmSlotBtn).click();

			element(slotSizeTxt).waitUntilVisible();
			element(slotSizeTxt).type(slotSize);

			element(slotCnfrmBtn).waitUntilVisible();
			element(slotCnfrmBtn).click();

			logger.info("successfully added the slot size");

		} catch (Exception e) {

		}
	}

	public void performPalletCancel() {
		try {
			element(cancelPalletBtn).waitUntilVisible();
			element(cancelPalletBtn).click();
			Thread.sleep(1000);
			element(cancelPalletConfirmBtn).waitUntilVisible();
			element(cancelPalletConfirmBtn).click();
		} catch (Exception e) {

		}
	}

}
