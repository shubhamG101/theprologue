package com.walmart.supplychain.acc.acl.scenariosteps.webservices;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.acc.acl.steps.webservices.ACCDoorAssignStep;
import com.walmart.supplychain.acc.sorter.steps.webservices.ACCSorterIntegrationStep;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;

public class ACCDoorAssign {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Autowired
    ReceivingHelper receivingHelper;
	
	@Steps
	ACCDoorAssignStep accDoorAssignStep;
	
	@Steps
	ACCSorterIntegrationStep aCCSorterIntegrationStep;

	Logger logger = LogManager.getLogger(this.getClass());

	WebDriver driver;

	@And("^user verifies Label data present in ACL interface for \"([^\"]*)\" labels$")
	public void userVerifiesLabelDataPresentInACLInterface(String labelType) {
		accDoorAssignStep.validateLabels(labelType);		
	}
	
	@And("^user verifies getting additional exception label from receiving by accessing exception url$")
	public void userVerifiesExceptionURl() {
		accDoorAssignStep.getExceptionLabels();		
	}
	
	@And("^user verifies that Door to ACL mapping happend in ACL interface$")
	public void userVerifiesThatDoorToACLMappingHappendInACLInterface() {
		accDoorAssignStep.validateDoorNumber();	
		
	}
	
	@And("^user verifies that Door to ACL mapping happend in ACL interface for Floor line$")
	public void userVerifiesThatDoorToACLMappingHappendInACLInterfaceForFloorLine() {
		accDoorAssignStep.validateFloorNumber();		
	}
	
	@And("^user verifies that data is cleared from acl tables for the delivery$")
	public void userVerifiesThatDataIsClearedFromAclTablesForTheDelivery() {
		accDoorAssignStep.validateCompleteDeliveryForACL();
	}
	
	@And("^user verifies that Door to ACL mapping happend in ACL interface for SSTK and NonCon$")
	public void userVerifiesThatDoorToACLMappingHappendInACLInterfaceForSSTKAndNonCon() {
		accDoorAssignStep.validateNonConveyableFrieghts();		
	}

	@And("^user verifies that labels are \"([^\"]*)\" in ACL on channel flip$")
	public void userVerifiesRejectLabels(String labelStatus) {
		accDoorAssignStep.verifyLabelRejected(labelStatus);		
	}
	
}

