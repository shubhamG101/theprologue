package com.walmart.supplychain.catalyst.ei.scenarioSteps;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.catalyst.ei.steps.CatalystEISteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class CatalystEIScenarios {
	
	
	@Steps
	CatalystEISteps catalystEISteps;
	
	
	
	
	@Then("^user hits EI service to get current inventory details available in EI$")
	public void userHitsEIServiceToGetCurrentInventoryDetails() {
		catalystEISteps.getEIInventoryDetails();
	}
	
	
	@Then("^user verifies inventory \"([^\"]*)\" transaction to EI$")
	public void userHitsEIServiceToGeturrentInventoryDetails(String eventType) {
		catalystEISteps.validateInventoryTrasactionEI(eventType);
	}
	
	

}
