package com.walmart.supplychain.thor.podetails.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.thor.POStatus;
import com.walmart.framework.supplychain.domain.thor.SearchThorPO;
import com.walmart.framework.supplychain.domain.thor.StatusRequest;
import com.walmart.framework.supplychain.domain.thor.ThorItemDetails;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.thor.podetails.pages.ThorTokenPage;

import io.restassured.response.Response;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class PODetailsStep {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String GET_POLINES = "$.testFlowData.poDetails[*].poLineDetails[*]";
	private static final String GET_THORITEMS = "$.items[*]";
	private static final String GET_THOR_PO = "$..poNumber";
	private static final String THOR_PO_EP = "thor_po_url";
	private static final String THOR_PO_DETAILS = "thor_po_details";
	private static final String GET_THOR_PO_DETAILS = "$";
	private static final String SECURITY_URL = "security_token_url";
	private static final String THOR_USER = "thor_user";
	private static final String THOR = "thor";
	private static final String PO_STATUS_ACKNOWLEDGED = "VendorAcknowledged";
	private static final String PENDING_ISSUE = "Pending";
	private static final String RESOLVED_ISSUE = "Resolved";
	private static final String DELIVERED_STATUS = "Delivered";
	private static final String CHANGE_PO_STATUS_EP = "status_change_url";
	private static final String ERROR_MESSAGE_PO_CANCEL = "Unable to edit PurchaseOrder|poNumber=";
	private int retryCount = 0;
	private boolean loginFlag = true;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";
	String poNumber = null;
	Response response;

	ThorTokenPage thorTokenPage;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired(required = true)
	ThorHelper thorHelper;

	@Autowired
	Environment environment;

	@Step
	public void validatePODetailsInThor(String status) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});

			for (PoDetail poObj : poList) {
				poNumber = poObj.getPoNumber();
				SearchThorPO searchpo = new SearchThorPO();
				searchpo.setAltPoNumber(poNumber);
				Failsafe.with(retryPolicy).run(() -> {
					if (retryCount > 0) {
						loginFlag = false;
					}
					retryCount++;
					logger.info("get Thor po url:" + environment.getProperty(THOR_PO_EP));
					logger.info("get Thor po body:" + objectMapper.writeValueAsString(searchpo));
					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
									environment.getProperty(THOR_USER), environment.getProperty(THOR),
									loginFlag))
							.body(objectMapper.writeValueAsString(searchpo)).when()
							.post(environment.getProperty(THOR_PO_EP));
					Assert.assertEquals(ErrorCodes.THOR_PO_SEARCH, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());

					Object thorObject = JsonPath.read(response.asString(), GET_THOR_PO);
					String thorPO = objectMapper.writeValueAsString(thorObject);
					thorPO = thorPO.replace("[", "").replace("]", "");
					logger.info(environment.getProperty(THOR_PO_DETAILS) + thorPO);

					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
									environment.getProperty(THOR_USER), environment.getProperty(THOR), false))
							.when().get(environment.getProperty(THOR_PO_DETAILS) + thorPO);
					Assert.assertEquals(ErrorCodes.THOR_PO_DETAILS, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					Object thorStatus = JsonPath.read(response.asString(), "status");
					Assert.assertEquals(ErrorCodes.THOR_STATUS_CHANGE, status, thorStatus);

					Object thorPoResponseObj = JsonPath.read(response.asString(), "poId");
					String thorPoResponse = objectMapper.writeValueAsString(thorPoResponseObj);
					Assert.assertEquals(ErrorCodes.THOR_PO_DETAILS, thorPO, thorPoResponse);

					validateThorPoDetails(response);
				});

			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to fetch po details in thor", e);
		}

	}

	public void validateThorPoDetails(Response thorpoDetailsresponse) {
		DocumentContext context = null;
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("testflow json:" + testData);
			ObjectMapper om = new ObjectMapper();

			Object thorPoResponseObj = JsonPath.read(response.asString(), "poId");
			String thorPO = om.writeValueAsString(thorPoResponseObj);

			JSONArray listOfPoLines = JsonPath.read(testData, GET_POLINES);
			String poLineString = listOfPoLines.toJSONString();
			List<PoLineDetail> poLineList = objectMapper.readValue(poLineString,
					new TypeReference<List<PoLineDetail>>() {
					});

			JSONArray listOfThorPoLines = JsonPath.read(thorpoDetailsresponse.asString(), GET_THORITEMS);
			String thorpoLineString = listOfThorPoLines.toJSONString();
			List<ThorItemDetails> thorpoLineList = objectMapper.readValue(thorpoLineString,
					new TypeReference<List<ThorItemDetails>>() {
					});

			Assert.assertEquals(ErrorCodes.THOR_ITEMS_MIS_MATCH, poLineList.size(), thorpoLineList.size());

			JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toJSONString();
			List newPOList = new ArrayList();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});

			for (PoDetail poDetail : poList) {
				poLineList = poDetail.getPoLineDetails();
				List newPoLineList = new ArrayList();
				for (int i = 0; i < poLineList.size(); i++) {
					String itemBarCode = poLineList.get(i).getCaseUpc();
					logger.info("case upc :" + itemBarCode);
					PoLineDetail polineobj = poLineList.get(i);

					JSONArray listOfThorLines = JsonPath.read(response.asString(),
							"$.items[?(@.barcode == \"" + itemBarCode + "\")]");
					String thorLineString = listOfThorLines.toJSONString();
					List<ThorItemDetails> thorLineList = objectMapper.readValue(thorLineString,
							new TypeReference<List<ThorItemDetails>>() {
							});
					Assert.assertEquals(ErrorCodes.THOR_QUANTITY_MIS_MATCH, thorLineList.get(0).getItemNbr(),
							polineobj.getItemNumber());
					Assert.assertEquals(ErrorCodes.THOR_QUANTITY_MIS_MATCH, thorLineList.get(0).getQuantity(),
							Integer.parseInt(polineobj.getPoVnpkQty()) * Integer.parseInt(poLineList.get(i).getVnpk()));
					Assert.assertEquals(ErrorCodes.THOR_UNITS_MIS_MATCH, thorLineList.get(0).getThorUnitsPer(),
							Integer.parseInt(polineobj.getVnpk()));
					Assert.assertEquals(ErrorCodes.THOR_PRICE_MIS_MATCH, thorLineList.get(0).getUnitPrice(),
							Double.parseDouble(polineobj.getWhpkSellPrice()));
					Assert.assertNotNull(ErrorCodes.THOR_SKU_NULL, thorLineList.get(0).getThorSkuId());

					polineobj.setThorSKU(thorLineList.get(0).getThorSkuId());
					polineobj.setThorUnitsPer(thorLineList.get(0).getThorUnitsPer());
					newPoLineList.add(polineobj);
				}
				poDetail.setPoLineDetails(newPoLineList);
				poDetail.setThorPO(thorPO);
				newPOList.add(poDetail);
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(poList);
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after publishing the Receiving Receipts::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate po details in thor", e);
		}

	}

	public void validatePOStatus(String status, String item) {
		try {
			Thread.sleep(50000);
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("testflow json:" + testData);
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});

			for (PoDetail poDetail : poList) {
				Failsafe.with(retryPolicy).run(() -> {
					if (retryCount > 0) {
						loginFlag = false;
					}
					retryCount++;
					SearchThorPO searchpo = new SearchThorPO();
					searchpo.setAltPoNumber(poDetail.getPoNumber());

					logger.info(om.writeValueAsString(searchpo));
					logger.info(THOR_PO_EP);

					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
									environment.getProperty(THOR_USER), environment.getProperty(THOR),
									loginFlag))
							.body(objectMapper.writeValueAsString(searchpo)).when()
							.post(environment.getProperty(THOR_PO_EP));
					Assert.assertEquals(ErrorCodes.THOR_PO_SEARCH, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());

					Object thorObject = JsonPath.read(response.asString(), GET_THOR_PO);
					String thorPO = objectMapper.writeValueAsString(thorObject);
					thorPO = thorPO.replace("[", "").replace("]", "");

					StatusRequest request = new StatusRequest();
					request.setFcIssues(PENDING_ISSUE);
					request.setScIssues(PENDING_ISSUE);
					request.setSkuIssues(PENDING_ISSUE);
					request.setVendorIssues(PENDING_ISSUE);
					request.setPoStatus(DELIVERED_STATUS);
					request.setSmallParcel(false);

					POStatus statusObj = new POStatus();
					statusObj.setPoNumber(Integer.parseInt(thorPO));
					statusObj.setPoStatusUpdateRequest(request);
					logger.info("po status change body:" + om.writeValueAsString(statusObj));
					logger.info("change po status url:" + environment.getProperty(CHANGE_PO_STATUS_EP));

					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
									environment.getProperty(THOR_USER), environment.getProperty(THOR), false))
							.body(om.writeValueAsString(statusObj)).when()
							.post(environment.getProperty(CHANGE_PO_STATUS_EP));
					Assert.assertEquals(ErrorCodes.THOR_CANCEL_STATUS, Constants.BAD_STATUS_CODE,
							response.getStatusCode());
					Object errors = JsonPath.read(response.asString(), "errors");
					String errorString = om.writeValueAsString(errors);
					errorString = errorString.substring(2, 40) + thorPO;
					Assert.assertEquals(ErrorCodes.THOR_CANCEL_STATUS, ERROR_MESSAGE_PO_CANCEL + thorPO, errorString);

				});
			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Thor po status", e);
		}
	}

}