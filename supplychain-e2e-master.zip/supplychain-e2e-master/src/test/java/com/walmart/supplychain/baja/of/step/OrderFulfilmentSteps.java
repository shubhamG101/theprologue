package com.walmart.supplychain.baja.of.step;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderFulfilmentSteps {

	@Autowired
	Environment environment;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	private String TEST_FLOW_DATA = "testFlowData";

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	@Step
	public Response verifyBulkPick() {

		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray releaseNumber = JsonPath.parse(testData).read("$..releaseNumber");

			String requestBody = "{\"releaseRequestIds\":[\"";
			for (int i = 0; i < releaseNumber.size(); i++) {
				requestBody += i == 0 ? releaseNumber.get(i) : ",\"" + releaseNumber.get(i);
				requestBody += "\"";
			}
			requestBody += "]}";
			logger.info("Request Body for searching in OF services is  : " + requestBody);

			String requestBodyFailSafe = requestBody;
			Failsafe.with(retryPolicy).run(() -> {
				Response response = SerenityRest.given().contentType("application/json")
						.body(requestBodyFailSafe.toString()).post(environment.getProperty("of_bulk_pick"));
				Assert.assertEquals(ErrorCodes.BAJA_BULK_PICK_FAIL, response.getStatusCode(),
						Constants.SUCESS_STATUS_CODE);
				
			});
			
			Response response = SerenityRest.given().contentType("application/json")
					.body(requestBodyFailSafe.toString()).post(environment.getProperty("of_bulk_pick"));
			Assert.assertEquals(ErrorCodes.BAJA_BULK_PICK_FAIL, response.getStatusCode(),
					Constants.SUCESS_STATUS_CODE);
			
			return response;

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting container status", e);
		}
	}
	
	
	@Step
	public void verifyNOBulkPick() {

		try {
			
			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray releaseNumber = JsonPath.parse(testData).read("$..releaseNumber");

			String requestBody = "{\"releaseRequestIds\":[\"";
			for (int i = 0; i < releaseNumber.size(); i++) {
				requestBody += i == 0 ? releaseNumber.get(i) : ",\"" + releaseNumber.get(i);
				requestBody += "\"";
			}
			requestBody += "]}";
			logger.info("Request Body for searching in OF services is  : " + requestBody);

			String requestBodyFailSafe = requestBody;
			Failsafe.with(retryPolicy).run(() -> {
				Response response = SerenityRest.given().contentType("application/json")
						.body(requestBodyFailSafe.toString()).post(environment.getProperty("of_bulk_pick"));
				Assert.assertEquals(ErrorCodes.BAJA_BULK_PICK_FAIL,Constants.NO_BULKPICK_RESPONSE, response.asString());
				logger.info("Check the response{}",response.asString());
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while BulkPick", e);
		}
	}
}
