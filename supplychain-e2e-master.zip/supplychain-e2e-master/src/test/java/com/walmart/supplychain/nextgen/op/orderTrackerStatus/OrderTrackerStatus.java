package com.walmart.supplychain.nextgen.op.orderTrackerStatus;

import java.util.HashMap;
import java.util.Map;

public class OrderTrackerStatus {
	
	private Map<Integer, String> valueToTextMapping = new HashMap<>();
	
	public OrderTrackerStatus() {
		valueToTextMapping.put(0, "NEW");
		valueToTextMapping.put(1, "EXCEPTION");
		valueToTextMapping.put(2,"REJECTED");
		valueToTextMapping.put(3,"RELEASE IN PROGRESS");
		valueToTextMapping.put(4,"RELEASED");
		valueToTextMapping.put(5,"PICKED");
		valueToTextMapping.put(6,"LOADED");
		valueToTextMapping.put(7,"SHIPPED");
		valueToTextMapping.put(8,"OUTED");
		valueToTextMapping.put(9,"REVERSE IN PROGRESS");
		valueToTextMapping.put(-1,"INACTIVE");
	}
	
	public String getValue(int key){
        return valueToTextMapping.get(key);
    }

}
