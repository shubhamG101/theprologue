package com.walmart.supplychain.nextgen.outbound.pages.ui;

import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.selenium.SerenityHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OutboundTableHelper  extends SerenityHelper{
	
	@FindAll({@FindBy(css = "th.md-column")})
	public List<WebElement> headers;
	
	@FindAll({@FindBy(css = "tr.md-row")})
	public List<WebElement> rowElements;

	private List<String> getHeaders(){
		List<String> list=new ArrayList<>();
		int index=0;
		for(WebElement header:headers) {
			String headerData=header.getText();
			if(headerData==null||headerData.equals("")) {
				headerData="EMPTY_DATA_"+index;
			}
			list.add(headerData);

		}
		return list;

	}
	public Map<String,String>  getTableDataFirstRow() throws Exception {
		return getTableRowData(1);
	}
	public Map<String,String>  getTableRowData(int rowIndex) throws Exception {
		Map<String,String> tableData=new HashMap<String, String>();
		List<String> tableHeaderList=getHeaders();
		List<WebElement> columnElements=rowElements.get(rowIndex).findElements(By.cssSelector("td.md-cell"));
		if(tableHeaderList.size()!=columnElements.size()) {
			throw new Exception("header and Data columns does not match");
		}

		for(int index=0;index<tableHeaderList.size();index++) {
			tableData.put(tableHeaderList.get(index), columnElements.get(index).getText());

		}
		return tableData;

	}
}
