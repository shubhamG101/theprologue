package com.walmart.supplychain.nextgen.oms.gluecode.webservices;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.ThreadLocalFactory;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.logging.LoggingUtils;
import com.walmart.framework.utilities.restclient.SpringRestClient;
import cucumber.api.java.en.Given;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@ContextConfiguration(classes = SpringTestConfiguration.class)
public class Oms2 {

    @Value("${fetch_allocations}")
    String fetch_allocations;

    @Autowired
    ThreadLocalFactory threadLocalFactory;

    @Autowired
    SpringRestClient springRestClient;

    @Autowired
    LoggingUtils loggingUtils;

    @Autowired
    DbUtils dbUtils;

    @Autowired
    Environment environment;

    @Autowired
    JsonUtils jsonUtils;

    @Given("^User again hits OMS for the po (\\d+)$")
    public void user_hits_OMS_for_the_po(long poNumber) throws IOException, ParseException {

        ThreadLocal<String> tl = threadLocalFactory.getThreadLocalInstance();

        String testDataString = tl.get();

        List<ReceivingInstruction> ria = new ArrayList<>();

        ReceivingInstruction ri = new ReceivingInstruction();
        ri.setMessageId("9213892-393939-499494");

        ReceivingInstruction ri2 = new ReceivingInstruction();
        ri2.setMessageId("9213892-393939-499495");

        ria.add(ri);
        ria.add(ri2);

        JSONArray receivingInstruction = jsonUtils.converyListToJsonArray(ria);
        JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(testDataString);

        String testFlowData = jsonUtils.setJsonAtJsonPath(testDataString, receivingInstruction, "$.poDetails[0].poLineDetails[0].receivingInstructions");

        tl.set(testFlowData);


        String updatedtestFlow = tl.get();

        /*
        This is way 1 to do the fetch
         */

        ReceivingInstruction[] lri = JsonPath.parse(updatedtestFlow).read("$.poDetails[0].poLineDetails[0].receivingInstructions", ReceivingInstruction[].class);

        ReceivingInstruction li = JsonPath.parse(updatedtestFlow).read("$.poDetails[0].poLineDetails[0].receivingInstructions[0]", ReceivingInstruction.class);


        System.out.println();

//
//        tl.set(dc.jsonString());

        //Now construct your specific component pojo's as in OMS.java and set it
        //at a specific path using JsonPath.


//        String sampleStr = MessageFormat.format(fetch_allocations, "Dev");


//        System.out.println("******************** " + sampleStr + "******************** ");

//        Object[] oArr = new Object[]{1, 10};
//
//        dbUtils.selectFrom("select first 10 order_id from order_alloc:alloc_order where alloc_order_status_code > ? and pre_alloc_each_qty > ?", oArr);


//        ChangeLogLevel cll = new ChangeLogLevel();
//        cll.setLogLevel("DEBUG");
//        ObjectMapper om = new ObjectMapper();
//        String changeLogLevel = om.writeValueAsString(cll);
//
//        System.out.println("The log level default object is : " + changeLogLevel);

//        loggingUtils.changeLogLevels(LogLevels.ALL, Project.BAJA);


//        ResponseEntity responseEntity;
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Accept", "application/json");


//        System.out.println("*********** Get Call *****************");
//responseEntity = getResource("http://www.google.com", String.class);
//        System.out.println(responseEntity.getBody().toString());
//
//
//        System.out.println("*********** Get Call with Headers *****************");
//
//
//        responseEntity = getResource("http://www.google.com",headers, String.class);
//        System.out.println(responseEntity.getBody().toString());



//        System.out.println("*********** Post Call *****************");
//        responseEntity = springRestClient.postResource("https://jsonplaceholder.typicode.com/posts", "{\n      title: \'foo\',\n      body: \'bar\',\n      userId: 1\n    }", String.class);
//        System.out.println(responseEntity.getBody().toString());
//
//
//        System.out.println("*********** Post Call with Headers *****************");
//
//
//        responseEntity = springRestClient.postResource("http://devcicweb1.wal-mart.com:58022/GENERIC/OMSPubSubGenericRead2/3857760045?LegacyPO=Y",headers,"{\n      title: \'foo\',\n      body: \'bar\',\n      userId: 10001\n    }", String.class);
//        System.out.println(responseEntity.getBody().toString());


        //        Response omsResponse = RestAssured.given().accept("application/json").get("http://devcicweb1.wal-mart.com:58022/GENERIC/OMSPubSubGenericRead2/" + poNumber + "?LegacyPO=Y");
//
//
//        String omsRespStr = omsResponse.getBody().asString();
//
//
//        System.out.println();
//        int vnpkQty = JsonPath.parse(omsRespStr).read("$.OMPSRJ.Data..omspo.omspol..vnpkqty");
//
//        int whpkQty = JsonPath.parse(omsRespStr).read("$.OMPSRJ.Data..omspo.omspol..whpkqty");



    }

}
