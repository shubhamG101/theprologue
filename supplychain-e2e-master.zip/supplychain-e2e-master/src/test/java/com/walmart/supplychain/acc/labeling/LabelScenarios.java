package com.walmart.supplychain.acc.labeling;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import cucumber.api.java.en.And;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class LabelScenarios {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	Environment environment;
	
	@Autowired
	LabelSteps labelSteps;

	Logger logger = LogManager.getLogger(this.getClass());

	@And("^user verifies that label data is present in labeling with user \"([^\"]*)\"$")
	public void verifyLabelData(String clientID) {
		labelSteps.checkLabels(clientID);
	}

}
