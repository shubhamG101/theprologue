package com.walmart.supplychain.rdc.receiving.pages;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.google.common.collect.ImmutableMap;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.webdriver.WebDriverFacade;

public class ReceivingOveragePage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_overageQtyReceiveEntry']")
	private WebElement overageInput;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/mbtn_upcReceive']")
	private WebElement ovgSubmitBtn;

	public void createOverageProblem(String problemQty) {
		try {

			element(overageInput).waitUntilVisible();
			element(overageInput).type(problemQty);

			element(ovgSubmitBtn).waitUntilVisible();
			element(ovgSubmitBtn).click();
		} catch (Exception e) {

		}
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
	}

}
