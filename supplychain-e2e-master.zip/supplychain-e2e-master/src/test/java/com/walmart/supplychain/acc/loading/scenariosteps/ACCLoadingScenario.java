package com.walmart.supplychain.acc.loading.scenariosteps;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.nextgen.loading.steps.db.LoadingDBSteps;
import com.walmart.supplychain.nextgen.loading.steps.mobile.LoadingAppSteps;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingSteps;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ACCLoadingScenario {
	
	@Steps
	LoadingAppSteps loadingAppSteps;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Steps
	LoadingSteps loadingSteps;

	@Steps
	LoadingDBSteps loadingDBSteps;

	@Steps
	YMSSteps ymsSteps;

	@Steps
	ACCLoadingSteps aCCLoadingSteps;

	Logger logger = LogManager.getLogger(this.getClass());

	WebDriver driver;

	@When("^user creates a load with \"([^\"]*)\"$")
	public void userCreatesAloadByScanningTheProcurmentCase(String loadType) {
		aCCLoadingSteps.loadContainers(loadType);
	}
	
	@When("^user loads another \"([^\"]*)\" container in the load to overload the container$")
	public void user_load_another_container(String typeOfCntr) {
		aCCLoadingSteps.loadOverLoadContainer();
	}
	
	@When("^user stops divertion and unloads the securement cases with loadType \"([^\"]*)\"$")
	public void userStopsDivertionAndUnloadsTheSecurementCases (String loadType) {
		aCCLoadingSteps.stopDivertUnloadSecurementCase(loadType);
	}
	
	@Then("^user verifies stop diversion$")
	public void userVerifiesStopDiversion () {
		aCCLoadingSteps.verifySorterTableStopDiversion();
	}
	
	@Then("^user verifies status of the Loaded Containers is \"([^\"]*)\"$")
	public void userVerifiesStatusOfTheLoadedContainers (String status) {
		aCCLoadingSteps.verifyContainerStatus(status);
	}
	
	@Then("^user verifies the load status as \"([^\"]*)\" and Container status as \"([^\"]*)\" in acc Loading$")
	public void userVerifiesStatusOfTheLoadAndLoadedContainers (String loadStatus,String status) {
		loadingSteps.validateloadStatusAfterCloseLoad(loadStatus);
		aCCLoadingSteps.verifyContainerStatus(status);
	}
	
	
	@Then("^user verifies that door to RDC mapping is removed in sorter table$")
	public void doorToLaneMapping () {
		aCCLoadingSteps.verifyStopDivertInSorter();
	}
	
	@Then("^user deletes the load$")
	public void userDeletesTheLoad () {
		loadingSteps.deleteLoad();
	}
	
//	@And("^user verifies the load status as \"([^\"]*)\" and Container status as \"([^\"]*)\" in acc Loading API$")
//	public void userVerifiesStatusOfTheLoadAndLoadedContainers_API(String loadStatus,String status) {
//		loadingSteps.validateloadStatusAfterCloseLoadThroughAPI(loadStatus);
//		aCCLoadingSteps.verifyContainerStatusThroughAPI(status);
//	}

}
