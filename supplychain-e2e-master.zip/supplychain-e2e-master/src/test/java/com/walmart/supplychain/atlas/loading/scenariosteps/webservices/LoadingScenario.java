package com.walmart.supplychain.atlas.loading.scenariosteps.webservices;

import java.io.IOException;
import java.net.URISyntaxException;

import org.json.JSONException;

import com.walmart.supplychain.nextgen.loading.steps.mobile.LoadingAppSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class LoadingScenario {
	@Steps
	LoadingAppSteps loadingAppSteps;

	
	@When("^user starts Loading by creating a Load$")
	public void user_starts_Loading_by_scanning_all_containers_Door_and_Trailer() throws JSONException, URISyntaxException, IOException {
		loadingAppSteps.createLoad();

	}
	
	@When("^load is closed in Loading$")
	public void when_user_closes_the_load_in_Loading() {

		loadingAppSteps.closeLoad();
	}
	
	@Given("^user verifies the load status as \"([^\"]*)\" in Loading$")
	public void user_verifies_the_load_status_in_Loading(String loadStatus)   {
	   
		loadingAppSteps.validateLoadStatus(loadStatus);
		
	}

	
}
