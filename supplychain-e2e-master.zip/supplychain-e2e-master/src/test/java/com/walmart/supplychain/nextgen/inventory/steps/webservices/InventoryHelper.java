package com.walmart.supplychain.nextgen.inventory.steps.webservices;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;

import org.apache.logging.log4j.LogManager;
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.inventory.VtrMessage;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.javautils.JsonPathHelper;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.inventory.pages.mobile.InventoryVtr;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import ch.qos.logback.classic.Logger;
import cucumber.api.java8.Tl;

import com.walmart.framework.supplychain.domain.inventory.MessageHeader;
import spring.SpringTestConfiguration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;
import static org.hamcrest.CoreMatchers.is;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class InventoryHelper {

	@Autowired
	Environment environment;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	@Autowired
	TextParser textParser;

	@Autowired
	JavaUtils javautil;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	InventoryVtr invPage;

	@Autowired
	ReceivingHelper receivingHelper;
	
	@Autowired
	IDMHelper idmHelper;
	
	@Autowired
	JsonPathHelper jsonPath;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	private static final String INVENTORY_QUERYPARAM_KEY = "inventory_ep_qp";
	private Response response;

	org.apache.logging.log4j.Logger logger = LogManager.getLogger(this.getClass());
	private static final String QUEUE = "queue";

	private static final String ITEM_NR_PATH_CON = "childContainersList[CtrNr].containerInventoryList[0].itemNumber";
	private static final String TOTAL_QTY_PATH_CON = "childContainersList[CtrNr].containerInventoryList[0].totalQuantity";
	private static final String ITEM_NR_PATH_NON_CON = "containerInventoryList[0].itemNumber";
	private static final String TOTAL_QTY_PATH_NON_CON = "containerInventoryList[0].totalQuantity";
	private static final String IS_SHIPPABLE_FLAG = "isShippable";
	private static final int VTR_REASON_CODE = 28;
	private static final String INVENTORY_ENDPOINT_KEY = "inventory_ep";
	private static final String VNPK_TFD_JSON_PATH ="$..poLineDetails[?(@.itemNumber==\"#0#\")].vnpk";
	private static final String TOTAL_QTY_TFD_JSON_PATH ="$..receivingInstructions[?(@.parentContainer==\"#0#\")].receivedQuantity";
	private static final String WAREHOUSE_AREA_CODE_TFD_JSON_PATH ="$..poLineDetails[?(@.itemNumber==\"#0#\")].warehouseArea";
	private static final String DEST_TFD_JSON_PATH ="$..receivingInstructions[?(@.parentContainer==\"#0#\")].destNumber";
	private static final String CONTAINER_TYPE_TFD_JSON_PATH ="$..receivingInstructions[?(@.parentContainer==\"#0#\")].containerType";
	private static final String ROTATE_DATE_TFD_JSON_PATH ="$..receivingInstructions[?(@.parentContainer==\"#0#\")].rotateDate";
	private static final String BASE_JSONPATH= "$.";
	private static final String ITEM_NUMBER_BASE_JSONPATH= "$.containerInventoryList[?(@.itemNumber==#0#)].";
	private static final String TRACKING_ID = "trackingId";
	private static final String CONTAINER_STATUS= "containerStatus";
	private static final String CONTAINER_TYPE= "containerTypeAbbr";
	private static final String LOCATION_NAME= "locationName";
	private static final String WAREHOUSEAREACODE= "warehouseAreaCode";
	private static final String NET_WEIGHT= "netWeight";
	private static final String TOTAL_QTY= "totalQuantity";
	private static final String ITEM_NUMBER= "itemNumber";
	private static final String DEST_LOCATION= "destinationLocationId";
	private static final String ROTATE_DATE= "rotateDate";

	private DocumentContext parsedJson;

	public boolean validateContainerDetails(Response response, int receivedQty, String vnpk, String itemNumber,
			String channelType) {
		double netWeight=jsonPath.get(response.asString(), BASE_JSONPATH+NET_WEIGHT);
		if (channelType.equalsIgnoreCase(CHANNELS.CROSSU.getValue())
				|| channelType.equalsIgnoreCase(CHANNELS.CROSSMU.getValue())) {

//			if (!(Config.DC == DC_TYPE.MCC))
//				response.then().body(IS_SHIPPABLE_FLAG, is(false));

			List<String> locationList = JsonPath.read(response.asString(),
					"$..locationName");
			if(!locationList.get(0).equalsIgnoreCase("Conveyor")) {
			
				IntStream.range(0, receivedQty).forEach(index -> {
				response.then().body(ITEM_NR_PATH_CON.replace("CtrNr", Integer.toString(index)),
						is(Integer.parseInt(itemNumber)));
				response.then().body(TOTAL_QTY_PATH_CON.replace("CtrNr", Integer.toString(index)),
						is(Integer.parseInt(vnpk)));

				});
			}
			
			Assert.assertNotEquals(ErrorCodes.INVENTORY_ZERO_WT_CONTAINER,0.0, netWeight);			
		} else {

			if (Config.DC != DC_TYPE.MCC)
				response.then().body(IS_SHIPPABLE_FLAG, is(true));
			if (channelType.equalsIgnoreCase(CHANNELS.POCON.getValue())) {
				Integer itemNum = JsonPath.read(response.asString(), ITEM_NR_PATH_NON_CON);
				Integer totalQty = JsonPath.read(response.asString(), TOTAL_QTY_PATH_NON_CON);
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_POCON_RESPONSE,-1, itemNum);
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_POCON_RESPONSE,receivedQty, totalQty);
				
			}
			else if (channelType.equalsIgnoreCase(CHANNELS.DSDC.getValue())) {
				receivedQty=0;
				String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
				DocumentContext parsedJson = JsonPath.parse(testFlowData);
				List<String> receivedQtyList = parsedJson.read("$.testFlowData..poLineDetails[?(@.itemNumber =='"+itemNumber+"')]..receivedQuantity");
				for (String rcvQty : receivedQtyList) {
					receivedQty=receivedQty+Integer.valueOf(rcvQty);
				}
				Integer itemNum = JsonPath.read(response.asString(), ITEM_NR_PATH_NON_CON);
				Integer totalQty = JsonPath.read(response.asString(), TOTAL_QTY_PATH_NON_CON);
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_DSDC_RESPONSE,-1, itemNum);
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_DSDC_RESPONSE,receivedQty, totalQty);
				
			}
			else {
				response.then().body(ITEM_NR_PATH_NON_CON, is(Integer.parseInt(itemNumber)));
				response.then().body(TOTAL_QTY_PATH_NON_CON, is(Integer.parseInt(vnpk) * receivedQty));
			}
			Assert.assertNotEquals(ErrorCodes.INVENTORY_ZERO_WT_CONTAINER,0.0, netWeight);
		}

		return true;

	}
	public int getTotalReceivedQtyInEachesForContainerFromTFD(String container,String item) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		String qtyVal=jsonPath.getFirst(testFlowData,TOTAL_QTY_TFD_JSON_PATH,container);
		int qty=Integer.parseInt(qtyVal);
		String vnpkVal=jsonPath.getFirst(testFlowData,VNPK_TFD_JSON_PATH,item);
		int vnpk=Integer.parseInt(vnpkVal);
		qty*=vnpk;
		logger.info("Tota qty received for container:{} in eaches :{}",container,qty);
		return qty;
	}
	public String getItemWarehouseAreaCodeFromTFD(String itemNumber) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		String wareHouseAreaCode=jsonPath.getFirst(testFlowData,WAREHOUSE_AREA_CODE_TFD_JSON_PATH,itemNumber);
		logger.info("WarehouseAreaCode:{}",wareHouseAreaCode);
		return wareHouseAreaCode;
	}
	public String getDestForContainerFromTFD(String container) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		return jsonPath.getFirst(testFlowData,DEST_TFD_JSON_PATH,container);
	}
	public String getRotateDateForContainerFromTFD(String container) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		String rotateDate= jsonPath.getFirst(testFlowData,ROTATE_DATE_TFD_JSON_PATH,container);
		if(rotateDate==null)
			return rotateDate;
		else
			return rotateDate+"T00:00:00.000+0000";
	}
	public String getContainerTypeForContainerFromTFD(String container) {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		return jsonPath.getFirst(testFlowData,CONTAINER_TYPE_TFD_JSON_PATH,container);
	}
	
	public Map<String,Object> getExpectedContainerDetails(String container,String itemNumber) {
		
		String doorNumber=idmHelper.getDoorNumber();
		Map<String,Object> expectedData=new HashMap<>();
		expectedData.put(TRACKING_ID, container);
		expectedData.put(CONTAINER_STATUS, "PICKED");
		expectedData.put(LOCATION_NAME, doorNumber);
		expectedData.put(ITEM_NUMBER, itemNumber);
		expectedData.put(TOTAL_QTY, getTotalReceivedQtyInEachesForContainerFromTFD(container,itemNumber));
		expectedData.put(DEST_LOCATION, getDestForContainerFromTFD(container));
		expectedData.put(WAREHOUSEAREACODE, getItemWarehouseAreaCodeFromTFD(itemNumber));
		expectedData.put(ROTATE_DATE, getRotateDateForContainerFromTFD(container));
		//expectedData.put(CONTAINER_TYPE, getRotateDateForContainerFromTFD(container));
		return expectedData;
		
	}
	public Map<String,Object> getActualContainerDetails(Response response,String itemNumber) {
		String resp=response.asString();
		Map<String,Object> actualData=new HashMap<>();
		String itemBaseJsonPath =  javautil.format(ITEM_NUMBER_BASE_JSONPATH, itemNumber);
		actualData.put(TRACKING_ID, jsonPath.get(resp, BASE_JSONPATH + TRACKING_ID));
		actualData.put(CONTAINER_STATUS, jsonPath.get(resp, BASE_JSONPATH + CONTAINER_STATUS));
		actualData.put(LOCATION_NAME, jsonPath.get(resp, BASE_JSONPATH + LOCATION_NAME));
		actualData.put(DEST_LOCATION, jsonPath.get(resp, BASE_JSONPATH + DEST_LOCATION));
		//actualData.put(CONTAINER_TYPE, jsonPath.get(resp, BASE_JSONPATH + CONTAINER_TYPE));

		actualData.put(ITEM_NUMBER, jsonPath.getFirst(resp, itemBaseJsonPath + ITEM_NUMBER));
		actualData.put(TOTAL_QTY, jsonPath.getFirst(resp, itemBaseJsonPath + TOTAL_QTY));
		actualData.put(WAREHOUSEAREACODE, jsonPath.getFirst(resp, itemBaseJsonPath + WAREHOUSEAREACODE));
		actualData.put(ROTATE_DATE, jsonPath.getFirst(resp, itemBaseJsonPath + ROTATE_DATE));
		
		return actualData;
		
	}
	
	public JSONObject bohBody(List<Integer> itemList) {
		JSONObject bohObject = new JSONObject();
		try {
			JSONArray itemListArr = jsonUtil.converyListToJsonArray(itemList);
			JSONArray poTypeListArr = new JSONArray();
			poTypeListArr.add("TURN");
			poTypeListArr.add("DISTRO");

			bohObject.put("groupByAttr", "rotateDate");
			bohObject.put("groupByAttrOrderBy", "asc");
			bohObject.put("itemList", itemListArr);
			bohObject.put("poTypeList", poTypeListArr);
			bohObject.put("baseDivisionCode", "WM");
			bohObject.put("financialReportingGroup", "US");
			bohObject.put("bohQtyUom", "EA");

		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return bohObject;

	}

	public VtrMessage constructVtrMessage(String vtrContainer, String vtrItemNumber, int adjQty, int reasonCode) {

		VtrMessage vtrMessage = new VtrMessage();
		MessageHeader messageHeader = new MessageHeader();
		vtrMessage.setTrackingId(vtrContainer);
		vtrMessage.setItemNumber(Integer.parseInt(vtrItemNumber));
		vtrMessage.setAdjustBy(adjQty);
		vtrMessage.setReasonCode(reasonCode);
		messageHeader.setUserId("admin");
		messageHeader.setTimeStamp(new Date().getTime());
		vtrMessage.setMessageHeader(messageHeader);
		vtrMessage.setFinancialReportingGroup("US");
		vtrMessage.setBaseDivisionCode("WM");
		return vtrMessage;
	}

	public Headers getInventoryHeaders() {

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header appType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(appType);

		return new Headers(headerList);

	}

	public void validateAndGetContainerResponse(String lpnId) {

		try {
			Failsafe.with(retryPolicy).run(() -> {
				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC) {
					response = given().relaxedHTTPSValidation().headers(getInventoryHeaders()).when()
							.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + lpnId
									+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				}else {
				
					response = when().get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + lpnId
							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				}
				logger.info("Waiting for Status 200 for Container Id:{}", lpnId);
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_RESPONSE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				logger.info("Validated the response status returned for the LPN " + lpnId + " in Inventory");
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting inventory response", e);
		}
	}

	public void getGFCSContainer() {
		File file = new File(FileNames.GFCS_FILES);
		File[] files = file.listFiles();
		JSONParser parser = new JSONParser();

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		String delNumber = deliveryNumberList.get(0);
		List<ReceivingInstruction> instructionList = new ArrayList<>();
		String poNum = null;
		String itemNbr = null;

		for (File f : files) {
			String fileData = "";
			JSONArray updateJson;
			JSONObject updateParChild;
			JSONArray arr;
			String gfcsContainer = null;
			String gfcsChildContainer = null;
			ReceivingInstruction recInstruction = new ReceivingInstruction();
			try {
				fileData = textParser.readTextFile(FileNames.GFCS_MESSAGE_FILE_ATLAS);

				updateJson = JsonPath.parse(fileData).read("$..eventObject");
				JSONArray destinationId = JsonPath.parse(fileData).read("$..eventObject.destinationLocationId");
				String destNum = destinationId.get(0).toString();
				logger.info("Event Object JsonArray " + updateJson.toJSONString());
				JSONArray poNumber = JsonPath.parse(fileData).read("$..eventObject.itemList[*].poNum");
				poNum = poNumber.get(0).toString();
				JSONArray itemNumber = JsonPath.parse(fileData).read("$..eventObject.itemList[*].itemNumber");
				itemNbr = itemNumber.get(0).toString();
				arr = (JSONArray) parser.parse(updateJson.toJSONString());

				updateParChild = (JSONObject) arr.get(0);

				logger.info("Event Object Json Obj " + updateParChild);

				updateParChild.put("deliveryNbr", delNumber);

				if (FileNames.GFCS_MESSAGE_FILE_ATLAS.contains("Child")) {
					logger.info("In Child ");
					
					long parNumber = (long) Math.floor(Math.random() * 900000000000000000L) + 100000000000000000L;
					gfcsContainer = "PL" + String.valueOf(parNumber);
					long childNumber = (long) Math.floor(Math.random() * 900000000000000000L) + 100000000000000000L;
					gfcsChildContainer = "PL" + String.valueOf(childNumber);

					updateParChild.put("trackingId", gfcsChildContainer);
					updateParChild.put("parentTrackingId", gfcsContainer);
					logger.info("Parent Container " + gfcsContainer);
					logger.info("child container " + gfcsChildContainer);

				} else {
					logger.info("In Parent ");
					//WILL ENABLE ONCE LOAD WEB DEPLOYMENT IS DONE
//					long parNumber = (long) Math.floor(Math.random() * 900000000000000000L) + 100000000000000000L;
//					gfcsContainer = "PL" + String.valueOf(parNumber);
//					updateParChild.put("trackingId", gfcsContainer);
//					logger.info("Parent Container " + gfcsContainer);

				}

				String testFlowData_updated = jsonUtil.setJsonAtJsonPath(fileData, updateParChild, "$..eventObject");

				logger.info("Final GFCS Json " + testFlowData_updated);

				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC) {

					synchronized (stratiConnectionUtil) {
						logger.info("Publishing GFCS Message");
						stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_gfcs_queue"),
								testFlowData_updated, QUEUE, environment.getProperty("connection_factory"),
								environment.getProperty("inv_starti_username"),
								environment.getProperty("inv_starti_password"));
					}

				}

				if (FileNames.GFCS_MESSAGE_FILE_ATLAS.contains("Child")) {
                    List<String> child= new ArrayList<String>();
					validateAndGetContainerResponse(gfcsChildContainer);
					child.add(gfcsChildContainer);
					recInstruction.setIsGFCS(true);
					recInstruction.setParentContainer(gfcsContainer);
					recInstruction.setDestNumber(destNum);
					recInstruction.setChildContainers(child);
					instructionList.add(recInstruction);

				} else {
					//WILL ENABLE ONCE LOAD WEB DEPLOYMENT IS DONE

//					validateAndGetContainerResponse(gfcsContainer);
//					recInstruction.setIsGFCS(true);
//					recInstruction.setParentContainer(gfcsContainer);
//					recInstruction.setDestNumber(destNum);
//					instructionList.add(recInstruction);

				}

			} catch (URISyntaxException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		receivingHelper.updateRcvInstruc(instructionList, itemNbr, poNum);
	}


}
