package com.walmart.supplychain.catalyst.by.ui.steps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.by.ui.pages.BYInventoryPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;

import net.jodah.failsafe.FailsafeException;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYInventorySteps extends ScenarioSteps {

	WebDriver driver;
	Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	BYOutboundPage byOutboundPage;

	@Autowired
	BYInventoryPage byInventoryPage;

	@Autowired
	BYUiHelper byUiHelper;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtil;
	
	@Autowired
	DbUtils dbUtils;
	
	@Autowired
	Environment queries;
	
	

	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String IB_ITEM_NUMBER_JSON_PATH = "$..poLineDetails..itemNumber";
	private static final String IB_PRIME_LOCATION_JSON_PATH = "$..poDetails..primeLocation";

	@Step
	public void performReplenishmentForAnItem() throws InterruptedException, IOException, ParseException {

		try {

			String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			List<String> itemNumber = JsonPath.read(runTimeData, IB_ITEM_NUMBER_JSON_PATH);
			List<String> primeLocation = JsonPath.read(runTimeData, IB_PRIME_LOCATION_JSON_PATH);

			
			byInventoryPage.headerSearchByText("Replenishment Settings");
			byInventoryPage.selectLinkFromSearchResults("Walmart - Inventory -> Configuration -> Replenishment Settings");
			
			// This will return the empty prime location
			// String getEmptyPrimeLocation = getEmptyPrimeLocation();
//			byInventoryPage.selectReplanishmentSettings();
			byInventoryPage.selectDemandReplanishment();
			byInventoryPage.clickAddButton();
			byInventoryPage.enterItemNumberandSelectFromDD(itemNumber.get(0));
			byInventoryPage.enterInventoryStatusandSelectFromDD(environment.getProperty("inventory_status"));
			byInventoryPage.enterMinMaxPercentages(environment.getProperty("min_percentage"),
					environment.getProperty("max_percentage"));
			byInventoryPage.enterReleasePercent(environment.getProperty("release_percentage"));
			byInventoryPage.enterPrimeLocationandSelectFromDD(primeLocation.get(0));

			/*
			 * This is for Properties file
			 * byUiHelper.updateTestFlowDataForPoLineDetails("primeLocation",
			 * getEmptyPrimeLocation);
			 * logger.info("set the Empty Prime Location {} in TestFlowData",
			 * getEmptyPrimeLocation);
			 */
			logger.info("set the Empty Prime Location {} for an Item ", primeLocation.get(0));
			byInventoryPage.clickSaveButton();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing full receive", e);
		}
	}

	// Get the Prime location from the Properties file
	/*
	 * public String getPropertiesDetails(int index) { try { String randomItems =
	 * environment.getProperty("primeLocation");
	 * 
	 * // logger.info(environment.getProperty("primeLocation"));
	 * logger.info(randomItems + " Before split");
	 * 
	 * String[] splitItems = randomItems.split(","); int a =
	 * javaUtil.randonNumberGenerator(1);
	 * 
	 * return splitItems[a]; }catch (AssertionError | FailsafeException e) { throw
	 * new TestCaseFailure(e); } catch (Exception e) { throw new
	 * AutomationFailure("Something went wrong while performing full receive", e); }
	 * }
	 */

	@Step
	public String getEmptyPrimeLocation(String locationFirstThreeChar) throws IOException, ParseException {

		try {
			byInventoryPage.headerSearchPrimeLocation("Prime Location");
			byInventoryPage.selectPrimeLocationLinkFromResults();
			byInventoryPage.filterWithRequiredFields();

			byInventoryPage.enterValueUnderFilterTB("ext", "Location Enabled", "True");
			byInventoryPage.enterValueUnderFilterTB("ext", "Location Status", "Empty");
			byInventoryPage.enterValueUnderFilterTB("ext", "Item", "null");
			byInventoryPage.enterValueUnderFilterTB("ext", "Location", locationFirstThreeChar);

			String emptyPrimeLocation = byInventoryPage.setEmptyPrimeLocation();
			return emptyPrimeLocation;
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing full receive", e);
		}
	}
	
	@Step
	public void navigateToProblemsTab() throws IOException, ParseException {

		try {
			byInventoryPage.headerSearchProblemsTab();
			byInventoryPage.selectInventoryProblemsLinkFromResults();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while navigating to problems page", e);
		}
	}
	
	@Step
	public void applyFutureHold() {

		try {
			String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			// Item Number Json path
			List<String> itemNumber = JsonPath.read(runTimeData, IB_ITEM_NUMBER_JSON_PATH);

			byInventoryPage.verifyFutureHoldsPageHeading();
			byInventoryPage.clickOnHoldActionButton();
			byInventoryPage.clickOnAddHoldButton();
			byInventoryPage.verifyAddNewHoldPageHeading();
			byInventoryPage.enterTextInHoldTextbox(environment.getProperty("fh_name"));
			byInventoryPage.enterNotesForFutureHold(environment.getProperty("fh_notes"));
			byInventoryPage.enterFHDescription(environment.getProperty("fh_description") + " " + itemNumber.get(0));
			byInventoryPage.enterFutureHoldTypeAndSelectFromDD(environment.getProperty("fh_type"));
			byInventoryPage.enterSeverityLevelAndSelectFromDD(environment.getProperty("fh_severity"));
			byInventoryPage.applyInboundInventoryToggleSwitch();
			byInventoryPage.enterHoldReasonAndSelectFromDD(environment.getProperty("fh_reason"));
			byInventoryPage.selectInventoryCriteriaTab();
			byInventoryPage.enterItemNumberandSelectFromDD(itemNumber.get(0));
			byInventoryPage.enterFHItemLotNumber("LOT" + itemNumber.get(0));
			byInventoryPage.clickOnApplyButton();
			byInventoryPage.allocationToggleSwitch();
			byInventoryPage.enableHoldToggleSwitch();
			byInventoryPage.clickOnSaveButton();
			byInventoryPage.verifyFutureHoldsPageHeading();

			logger.info("Future Hold has been applied to an Item {} ====", itemNumber.get(0));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing Future Hold", e);
		}
	}
	
	public void preCleanUpFutureHold() {

		logger.info("Entered query ==== {} " + queries.getProperty("delete_futureHold")
				+ environment.getProperty("fh_name"));
		int updadtedCount = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_futureHold"),
				environment.getProperty("fh_name"));

//		Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_RECEIVED_CASES, 1, updadtedCount);
		logger.info(" Future Hold is {} deleted ====", environment.getProperty("fh_name"));
	}

}
