package com.walmart.supplychain.thor.podetails.scenariosteps.webservices;

import com.walmart.supplychain.thor.podetails.steps.webservices.PODetailsStep;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class PoDetailsScenarios {
	
	@Steps
	PODetailsStep podetailstep;
	
	@And("^user validates PO details in Thor \"([^\"]*)\"$")
	public void userValidatesPODetailsInThor(String status)
	{
		podetailstep.validatePODetailsInThor(status);
	}
	
	@Then("^validate status of the po line is changed to \"([^\"]*)\" in thor for item \"([^\"]*)\"$")
	public void validateStatusOfThePoLineIsChanged(String poStatus,String item) {
		podetailstep.validatePOStatus(poStatus,item);
	}

}
