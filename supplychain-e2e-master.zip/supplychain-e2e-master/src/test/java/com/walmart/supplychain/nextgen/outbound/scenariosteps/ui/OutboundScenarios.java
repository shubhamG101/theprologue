package com.walmart.supplychain.nextgen.outbound.scenariosteps.ui;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.outbound.steps.ui.OutboundSteps;
import com.walmart.supplychain.nextgen.outbound.steps.webservices.OutboundServices;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class OutboundScenarios {
	@Steps
	OutboundSteps outboundSteps;
	@Steps
	OutboundServices outboundServiceSteps;

	@Then("^user verifies BOL generation, seal details for the load in OBD$")
	public void userVerifiesBolInOutboundUi() {
		outboundSteps.validateOutbound();
	}
	@Then("^user mocks sto and verifies BOL generation, seal details for the load in OBD$")
	public void userMocksAndVerifiesBolInOutboundUi() {
		if (Config.DC==DC_TYPE.ATLAS) {
			outboundServiceSteps.mockSto();
		}
		outboundSteps.validateOutbound();
	}
}
