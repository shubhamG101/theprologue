package com.walmart.supplychain.catalyst.wavePlanning.steps;

import static com.jayway.jsonpath.JsonPath.parse;
import static com.jayway.jsonpath.JsonPath.read;
import static net.serenitybdd.rest.SerenityRest.given;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.opencsv.CSVReader;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.witron.ExpectedAllocation;
import com.walmart.framework.supplychain.domain.witron.ExpectedPicks;
import com.walmart.framework.supplychain.domain.witron.OTNList;
import com.walmart.framework.supplychain.domain.witron.OrderWellTrigger;
import com.walmart.framework.supplychain.domain.witron.ResponseObj;
import com.walmart.framework.supplychain.domain.witron.UpdateOrderwell;
import com.walmart.framework.supplychain.domain.witron.WitronOrders;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OrdersDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.WitronItemDetails;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.KafkaUtilities;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.witronutilities.WitronUtil;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.thor.manifestservices.steps.webservices.ManifestServicesHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystOrdersStep {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*].poNumber";
	private static final String GET_WAREHOUSE_CODES = "$.testFlowData.ordersDetails[*].wareHouseAreaCode";
	private static final String GET_ORDERS = "$.testFlowData.ordersDetails[*]";
	private static final String GET_OUTBOUND = "$.testFlowData.outboundDetails[*]";
	private static final String BASE_FILE_PATH = "/src/test/resources/orders/expected_orders.csv";
	private static final String CATALYST_BASE_FILE_PATH = "/src/test/resources/TestData/Catalyst/orders/expected_orders.csv";
	private static final String BATCH_PLANNER_FILE_PATH = "/src/test/resources/orders/batch_planner_expected_orders.csv";
	private static final String WAVE_REVERSAL_FILE_PATH = "/src/test/resources/orders/wave_reverse_orders.csv";
	private static final String INVOICE_FILE_PATH = "/src/test/resources/orders/invoice_orders.csv";
	private static final String WITRON_OUT_FILE_PATH = "/src/test/resources/orders/witron_outs_orders.csv";
	private static final String GET_RELEASE_NBR = "$.testFlowData.outboundDetails[*].releaseNbr";
	private static final String GET_ROTATE_DATE = "$.testFlowData.poDetails[*].rotateDate";
	private static final String GET_FULFILLED_ITEMS = "$.testFlowData.ordersDetails[*].expectedAllocation.expectedPicks[*].fulfilledItemNbr";
	boolean orderFlag;
	private static List<Map<String, Object>> allocOrdersPicks = null;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String JSON_FORMAT = "application/json";

	List itemLabelList = null;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	@Autowired
	Environment environment;

	Response apiResponse;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	ManifestServicesHelper manifestServicesHelper;

	ObjectMapper om = new ObjectMapper();

	@Autowired
	PreRunCleanup preRunCleanup;

	@Autowired
	TextParser textParser;

	@Autowired
	WitronUtil witronUtil;

	@Autowired
	KafkaUtilities kafkaUtilities;

	Response response;

	private static String wireMockUrl = "http://10.34.153.9:8080";
	private static final String mockurlPattern = "/NEXTGEN/OMSPubSubGenericRead2/0";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String OMSMOCKURL = "omsurl";
	private static final String TOPIC = "topic";
	private static final String topicName = "ow_us_18_orders";



	public List createOrdersInOW(List<PoLineDetail> poLineList) {
		try {

			List orderList = new ArrayList();
			List orderDetailList = new ArrayList();
			ResponseObj jsonOrderObj = new ResponseObj();
			Date currDate = new Date();
			DateFormat destDf = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
			DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
			String dateStr = destDf.format(currDate);
			String dateUrlStr = desturl.format(currDate);
			int source = Integer.parseInt(environment.getProperty("facility_num"));
			String wac = "";

			int i = 0;
			for (int j = 0; j < poLineList.size(); j++) {

				PoLineDetail poLineObj = poLineList.get(j);
				int vnpk = Integer.parseInt(poLineObj.getVnpk());
				int whpk = Integer.parseInt(poLineObj.getWhpk());
				WitronOrders orderObj = new WitronOrders();
				OrdersDetail orders = new OrdersDetail();
				orderObj.setSourceNumber(source);
				orderObj.setOrderDate(dateStr + " UTC");
				orderObj.setWmtItemNumber(Integer.parseInt(poLineObj.getItemNumber()));
				orders.setItemNumber(poLineObj.getItemNumber());
				orderObj.setDestinationNumber(1600);
				orders.setDestinationNum("1600");
				orders.setSourceNumber(String.valueOf(source));
				String uuid = UUID.randomUUID().toString();
				orderObj.setOrderTrackingNumber(uuid);
				orders.setOrderTrackingNumber(uuid);
				orderObj.setDepartmentNumber(1);
				orderObj.setDestCountryCode("us");
				orderObj.setMessageType("T");
				orderObj.setOrderRecordType("SSTK");
				orderObj.setPackType("C");
				orderObj.setPoLineNumber(1);
				orderObj.setPoNumber(null);
				orderObj.setPoType(4);
				orderObj.setPriorityNbr(j + 1);
				orders.setPriority(String.valueOf(j + 1));
				orderObj.setQuantity(Integer.parseInt(poLineObj.getPoVnpkQty()) * vnpk);
				orders.setQuantity(String.valueOf(Integer.parseInt(poLineObj.getPoVnpkQty()) * vnpk));
				orderObj.setSourceCountryCode("us");
				orderObj.setVnpkQuantity(vnpk);
				orderObj.setWhpkQuantity(whpk);
				orders.setVnpk(String.valueOf(vnpk));
				orders.setWhpk(String.valueOf(whpk));
				orders.setChannelMethod("SSTK");
				orderObj.setStatus("New");
				orderObj.setQuantityUOM("EA");
				orderObj.setSubstitutable(true);
				orders.setSubstitutionFlag(true);
				orderObj.setOrderType("turn");
				orders.setOrderType("turn");
				orderObj.setWhseAreaCode("");
				orders.setWareHouseAreaCode("");

				String upc = poLineObj.getItemUpc();
				if (upc.length() < 14) {
					upc = upc.substring(0, upc.length() - 1);
					int diff = 13 - upc.length();
					for (int m = 0; m < diff; m++) {
						upc = "0" + upc;
					}
				} else {
					upc = upc.substring(0, upc.length() - 1);
				}
				orderObj.setUpcNumber(upc);
				wac = "";
				orderList.add(orderObj);
				orderDetailList.add(orders);
			}

			jsonOrderObj.setNextPage(null);
			jsonOrderObj.setOrders(orderList);
			String UUid = UUID.randomUUID().toString();

			JSONObject finalJsonObj = new JSONObject(jsonUtils.readFile("src/test/resources/ordersjson/finalobj.json"));
			String mockBody = finalJsonObj.toString(2);
			mockBody = mockBody.replace("#uuid", UUid);
			mockBody = mockBody.replace("#mockurl", "/orderwell/US/1/orders.*by=sourcedate&sourcenbr=" + source
					+ "&orderdate=" + dateUrlStr + "&wac=" + wac + "&status=New");
			String body = om.writeValueAsString(jsonOrderObj);
			mockBody = mockBody.replace("\"#mockbody\"", body);

			Response mockResponse = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT).body(mockBody)
					.post(wireMockUrl + "/__admin/mappings");
			Assert.assertEquals(ErrorCodes.WITRON_CREATE_ORDERS, Constants.CREATE_SUCESS_STATUS_CODE,
					mockResponse.getStatusCode());
			logger.info("Mock response:" + mockResponse.getBody().asString());
			JSONObject mockObject = new JSONObject(mockResponse.getBody().asString());
			logger.info(mockObject.getString("id"));
			logger.info("completed order creation for the ware house area code:" + wac);
			return orderDetailList;

		} catch (Exception e) {
			throw new AutomationFailure("Failed to Mock Witron Orders", e);
		}
	}

	public void witronMockPreCleanUp() {

		try {
			Response response = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT)
					.delete(wireMockUrl + "/__admin/mappings");
			Assert.assertEquals(ErrorCodes.WITRON_DELETE_MOCK, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
		} catch (Exception e) {
			throw new AutomationFailure("Failed to clean up Witron Mock", e);
		}

	}

	public void validateOrdersInOW() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			List orderDetailList = new ArrayList();
			JSONArray listOfWAC = JsonPath.read(testData, GET_WAREHOUSE_CODES);
			String wacString = listOfWAC.toJSONString();
			List<String> wacList = objectMapper.readValue(wacString, new TypeReference<List<String>>() {
			});
			Set<String> wacSet = new HashSet();
			for (String wac : wacList) {
				wacSet.add(wac);
			}
			List wareHouseAreaCodeList = new ArrayList();
			for (String wac : wacSet) {
				wareHouseAreaCodeList.add(wac);
			}
			Date currDate = new Date();
			DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
			String dateUrlStr = desturl.format(currDate);
			for (int i = 0; i < wareHouseAreaCodeList.size(); i++) {
				String wac = (String) wareHouseAreaCodeList.get(i);
				String orderWellUrl = environment.getProperty("orderwell_get_url")
						+ environment.getProperty("facility_num") + "&orderdate=" + dateUrlStr + "&wac=" + wac
						+ "&status=New";
				// logger.info(environment.getProperty("witron_ow_mock") + dateUrlStr + "&wac="
				// + wac);
				Failsafe.with(retryPolicy).run(() -> {
					logger.info("checking for orders in OW");
					// orderwell mock
					// response =
					// given().relaxedHTTPSValidation().accept(JSON_FORMAT).contentType(JSON_FORMAT).when()
					// .get(environment.getProperty("witron_ow_mock") + dateUrlStr + "&wac=" + wac);
					// ***********
					response = given().relaxedHTTPSValidation().accept(JSON_FORMAT).contentType(JSON_FORMAT).when()
							.get(orderWellUrl);
					Assert.assertEquals(ErrorCodes.WITRON_OW_GET_ORDERS_FAILED, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
				});

				JSONArray ordersArray = JsonPath.read(response.asString(), "$.orders");
				String ordersString = ordersArray.toJSONString();
				List<WitronOrders> ordersList = objectMapper.readValue(ordersString,
						new TypeReference<List<WitronOrders>>() {
						});

				JSONArray testFlowOrders = JsonPath.read(testData,
						"$.testFlowData.ordersDetails[?(@.wareHouseAreaCode==" + wac + ")]");
				String testFlowOrdersString = testFlowOrders.toJSONString();
				List<OrdersDetail> testFlowOrdersList = objectMapper.readValue(testFlowOrdersString,
						new TypeReference<List<OrdersDetail>>() {
						});

				Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, ordersList.size(), testFlowOrdersList.size());
				for (int j = 0; j < ordersList.size(); j++) {
					WitronOrders orderObj = ordersList.get(j);

					String otn = orderObj.getOrderTrackingNumber();
					JSONArray testFlowOrders2 = JsonPath.read(testData,
							"$.testFlowData.ordersDetails[?(@.orderTrackingNumber=='" + otn + "')]");
					String testFlowOrdersString2 = testFlowOrders2.toJSONString();
					List<OrdersDetail> testFlowOrdersList2 = objectMapper.readValue(testFlowOrdersString2,
							new TypeReference<List<OrdersDetail>>() {
							});
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getWmtItemNumber(),
							Integer.parseInt(testFlowOrdersList2.get(0).getItemNumber()));
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getQuantity(),
							Integer.parseInt(testFlowOrdersList2.get(0).getQuantity()));
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getVnpkQuantity(),
							Integer.parseInt(testFlowOrdersList2.get(0).getVnpk()));
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getWhpkQuantity(),
							Integer.parseInt(testFlowOrdersList2.get(0).getWhpk()));
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getPriorityNbr(),
							Integer.parseInt(testFlowOrdersList2.get(0).getPriority()));
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getOrderTrackingNumber(),
							testFlowOrdersList2.get(0).getOrderTrackingNumber());
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.isSubstitutable(),
							testFlowOrdersList2.get(0).getSubstitutionFlag());
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getOrderType(),
							testFlowOrdersList2.get(0).isOrderType());
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH, orderObj.getDestinationNumber(),
							Integer.parseInt(testFlowOrdersList2.get(0).getDestinationNum()));
				}

			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate order in OW", e);

		}

	}

	public void publishOWTrigger() {
		try {

			logger.info(tl.get().get(TEST_FLOW_DATA));
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testData);

			List<String> wacs = parsedItemDetailsJson.read("$.testFlowData.ordersDetails[*].wareHouseAreaCode");

			Set<String> wacSet = new HashSet();
			List<String> wacsUnique = new ArrayList();
			for (String wac : wacs) {
				wacSet.add(wac);
			}
			logger.info(wacSet);
			for (String wac : wacSet) {

				Date currDate = new Date();
				DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");
				String dateStr = destDf.format(currDate);
				OrderWellTrigger orderWellTrigger = new OrderWellTrigger();
				orderWellTrigger.setOrderDate(dateStr);
				orderWellTrigger.setWhseAreaCodes(wac);
				String trigger = om.writeValueAsString(orderWellTrigger);

				logger.info(trigger);
//				synchronized (stratiConnectionUtil) {
//					stratiConnectionUtil.publishStartiMessage(environment.getProperty("witron_ow_trigger_topic"),
//							trigger, TOPIC, environment.getProperty("idm_connection_factory"),
//							environment.getProperty("idm_starti_username"), environment.getProperty("idm_starti"),
//							null);
//				}
				kafkaUtilities.publishKafkaMessage(environment.getProperty("kafka_ow_topic"), trigger,
						KafkaUtilities.Server.CLUSTER1);

			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish OW trigger", e);

		}

	}

	public void validateDownloadedOrder() {
		try {
			
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testFlowData);

			JSONArray listOfWAC = JsonPath.read(testFlowData, GET_ORDERS);
			String wacString = listOfWAC.toJSONString();
			List<OrdersDetail> wacList = objectMapper.readValue(wacString, new TypeReference<List<OrdersDetail>>() {
			});

			List orderList = new ArrayList();
			Object[] wacArr = new Object[wacList.size()];
			List<OrdersDetail> neworderList = new ArrayList<OrdersDetail>();
			for (int i = 0; i < wacList.size(); i++) {
				OrdersDetail order = wacList.get(i);
				Object[] wacOrderArr = new Object[1];
				wacOrderArr[0] = order.getOrderTrackingNumber();
				List<Map<String, Object>> whseRecords = dbUtils.selectFrom(PRODUCT_NAME.OP, dbUtils
						.transformIntoSpringQuery(environment.getProperty("op_select_whse_order"), wacOrderArr.length),
						wacOrderArr);
				logger.info("whseRecords size " + whseRecords.size());
				order.setOrderId(whseRecords.get(0).get("whse_order_id").toString());
				wacArr[i] = order.getOrderTrackingNumber();
				neworderList.add(order);
			}
			orderFlag = false;
			Failsafe.with(retryPolicy).run(() -> {
				List<Map<String, Object>> whseRecords = dbUtils.selectFrom(PRODUCT_NAME.OP, dbUtils
						.transformIntoSpringQuery(environment.getProperty("op_select_whse_order"), wacArr.length),
						wacArr);
				List<Map<String, Object>> waveRecords = dbUtils
						.selectFrom(PRODUCT_NAME.OP,
								dbUtils.transformIntoSpringQuery(
										environment.getProperty("op_select_wave_plan_enrich_order"), wacArr.length),
								wacArr);
				logger.info("waveRecords.size() " + waveRecords.size());
				logger.info("wacList.size() " + wacList.size() + " whseRecords size " + whseRecords.size());
				Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_IN_OM, wacList.size(), whseRecords.size());
				Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_IN_WAVE, wacList.size(), waveRecords.size());
				orderFlag = true;
			});

			Assert.assertTrue(ErrorCodes.WITRON_ORDERS_MISMATCH_IN_WAVE, orderFlag);
			logger.info("testData {}", tl.get().get(TEST_FLOW_DATA));
			JSONArray listofOrderJson = jsonUtil.converyListToJsonArray(neworderList);
			testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofOrderJson, "$.testFlowData.ordersDetails");
			tl.get().put(TEST_FLOW_DATA, testFlowData);
			logger.info("testData {}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish OW trigger", e);
		}
	}

	public void validatePicksAfterRelease() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testData);

			JSONArray listOfWAC = JsonPath.read(testData, GET_ORDERS);
			String wacString = listOfWAC.toJSONString();
			List<OrdersDetail> orderList = objectMapper.readValue(wacString, new TypeReference<List<OrdersDetail>>() {
			});
			for (OrdersDetail order : orderList) {
				String orderTrackingNbr = order.getOrderTrackingNumber();
				String orderQty = order.getQuantity();
				int expectedFulfilledQty = 0;
				List<ExpectedPicks> expectedPicks = order.getExpectedAllocation().getExpectedPicks();
				for (int j = 0; j < expectedPicks.size(); j++) {
					expectedFulfilledQty += Integer.parseInt(expectedPicks.get(j).getFulfilledQty());
				}

				List<Map<String, Object>> allocOrders = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_alloc_order_fulfilled"), orderTrackingNbr);
				int fulfilledQty = (Integer) allocOrders.get(0).get("pre_alloc_each_qty");
				logger.info("Checking if there are any allocation outs........");
				logger.info("ordered qty:" + orderQty);
				logger.info("fulfilled qty:" + fulfilledQty);
				logger.info("out qty:" + order.getOutQty());
				Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_FULFILLED_QTY,
						expectedFulfilledQty + Integer.parseInt(order.getOutQty()),
						fulfilledQty + Integer.parseInt(order.getOutQty()));
			}
		} catch (Exception e) {
			throw new AutomationFailure("Picks are not generated for the orders", e);
		}
	}
	// op_select_cntr

	public void validateCntrsAfterRelease() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			DocumentContext parsedtestflowJson = JsonPath.parse(testData);

			List<String> itemList = parsedtestflowJson.read(GET_FULFILLED_ITEMS);
			Set<String> itemSet = new HashSet();

			for (String item : itemList) {
				itemSet.add(item);
			}

			JSONArray listOfOutbound = JsonPath.read(testData, GET_OUTBOUND);
			String outboundString = listOfOutbound.toJSONString();
			List<OutboundDetail> outboundList = objectMapper.readValue(outboundString,
					new TypeReference<List<OutboundDetail>>() {
					});
			String releaseNbr = outboundList.get(0).getReleaseNbr();
			for (String item : itemSet) {

				List<String> qtyList = parsedtestflowJson.read(
						"$.testFlowData.ordersDetails[*].expectedAllocation.expectedPicks[?(@.fulfilledItemNbr == '"
								+ item + "')].fulfilledQty");
				int itemQty = 0;
				for (int i = 0; i < qtyList.size(); i++) {
					itemQty += Integer.parseInt(qtyList.get(i));
				}
				List<Map<String, Object>> allocOrders = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_cntr_distribution"), releaseNbr, item);
				int fulfilledQty = (Integer) allocOrders.get(0).get("orderSum");
				logger.info("Checking containers table........");
				Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_CNTRS_PICK_QTY, itemQty, fulfilledQty);
			}

			List<Map<String, Object>> containerList = dbUtils.selectFrom(PRODUCT_NAME.OP,
					environment.getProperty("op_select_cntr"), releaseNbr);
			outboundList.get(0).setContainersCount(String.valueOf(containerList.size()));

			String FulfillmentId = (String) containerList.get(0).get("fulfillment_id");
			logger.info("Fulfillment_Id is" + FulfillmentId);
			outboundList.get(0).setFulfillmentId(FulfillmentId);

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			context.set("$.testFlowData.outboundDetails",
					JsonPath.parse(om.writeValueAsString(outboundList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating load ID::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Quantity mismatch in the containers table", e);
		}

	}

	public void createOrdersInOWForAllocationAlgorithm(String flow) {

		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		try {
			ObjectMapper om = new ObjectMapper();
			JsonUtils jsonUtils = new JsonUtils();
			List orderDetailList = new ArrayList();

			String[] wacList = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

			for (int j = 0; j < wacList.length; j++) {

				Reader reader = null;
				if (Config.DC == DC_TYPE.WITRON) {
					if (flow.equals("baseFlow")) {
						logger.info(System.getProperty("user.dir") + BASE_FILE_PATH);
						reader = new FileReader(System.getProperty("user.dir") + BASE_FILE_PATH);
					} else if (flow.equals("batchplannerFlow")) {
						logger.info(System.getProperty("user.dir") + BATCH_PLANNER_FILE_PATH);
						reader = new FileReader(System.getProperty("user.dir") + BATCH_PLANNER_FILE_PATH);
					} else if (flow.equals("waveReversalFlow")) {
						logger.info(System.getProperty("user.dir") + WAVE_REVERSAL_FILE_PATH);
						reader = new FileReader(System.getProperty("user.dir") + WAVE_REVERSAL_FILE_PATH);
					} else if (flow.equals("invoice")) {
						logger.info(System.getProperty("user.dir") + INVOICE_FILE_PATH);
						reader = new FileReader(System.getProperty("user.dir") + INVOICE_FILE_PATH);
					} else if (flow.equals("witronOut")) {
						logger.info(System.getProperty("user.dir") + WITRON_OUT_FILE_PATH);
						reader = new FileReader(System.getProperty("user.dir") + WITRON_OUT_FILE_PATH);
					}
				} else if ((Config.DC == DC_TYPE.CATALYST)) {
					logger.info(System.getProperty("user.dir") + CATALYST_BASE_FILE_PATH);
					reader = new FileReader(System.getProperty("user.dir") + CATALYST_BASE_FILE_PATH);
				}

				CSVReader csvReader = new CSVReader(reader);
				int i = 0;
				int m = 1;
				String wac = null;
				String[] line;
				ResponseObj jsonOrderObj = new ResponseObj();
				Date currDate = new Date();
				DateFormat destDf = new SimpleDateFormat("yyyy/MM/dd");
				DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
				String dateStr = destDf.format(currDate);

				String inputRaw = dateStr + " 00:00:00";
				logger.info(inputRaw);
				String input = inputRaw.replace("/", "-").replace(" ", "T");
				DateTimeZone zone = DateTimeZone.forID("UTC"); // Or DateTimeZone.UTC
				DateTime dateTime = new DateTime(input, zone);
				long millisecondsSinceUnixEpoch = dateTime.getMillis();
				System.out.println(millisecondsSinceUnixEpoch);

				String dateUrlStr = desturl.format(currDate);
				List orderList = new ArrayList();
				while ((line = csvReader.readNext()) != null) {
					if (i == 0 || !(wacList[j].equals(line[0]))) {
						i++;
						continue;
					}
					logger.info(line[1]);
					String itemresponse = witronUtil.getItemMDMDetails(line[1]);
					DocumentContext parsedItemDetailsJson = JsonPath.parse(itemresponse);
					PoLineDetail lineDetail = new PoLineDetail();
					WitronItemDetails itemDetails = new WitronItemDetails();

					List<String> vnpkList = parsedItemDetailsJson
							.read("$.foundSupplyItems..dcProperties..orderableQuantity.amount");
					List<String> whpkList = parsedItemDetailsJson
							.read("$.foundSupplyItems..dcProperties..warehousePackQuantity.amount");
					List<String> wareHouseList = parsedItemDetailsJson
							.read("$.foundSupplyItems..dcProperties..warehouseRotationType.code");
					logger.info(wareHouseList.get(0));
					logger.info(vnpkList);
					String vnpk = String.valueOf(vnpkList.get(0));
					String whpk = String.valueOf(whpkList.get(0));
					WitronOrders orderObj = new WitronOrders();
					OrdersDetail orders = new OrdersDetail();
					orderObj.setSourceNumber(Integer.parseInt(environment.getProperty("facility_num")));
					orderObj.setOrderDate(String.valueOf(millisecondsSinceUnixEpoch));
					orderObj.setWmtItemNumber(Integer.parseInt(line[1]));
					orders.setItemNumber(line[1]);
					orderObj.setDestinationNumber(Integer.parseInt(line[2]));
					orders.setDestinationNum(line[2]);
					orders.setSourceNumber(environment.getProperty("facility_num"));
					String uuid = UUID.randomUUID().toString();
					orderObj.setOrderTrackingNumber(uuid);
					orders.setOrderTrackingNumber(uuid);
					orderObj.setDepartmentNumber(1);
					orderObj.setDestCountryCode("us");
					orderObj.setMessageType("T");
					orderObj.setOrderRecordType("SSTK");
					orderObj.setPackType("C");
					orderObj.setPoLineNumber(1);
					orderObj.setPoNumber(null);
					orderObj.setPoType(4);
					orderObj.setPriorityNbr(m);
					orderObj.setPriorityNbrLong(m);
					orders.setPriority(String.valueOf(m));
					double qtyInEaches = Double.parseDouble(line[4]) * Double.parseDouble(vnpk);
					String qtyString = String.valueOf(qtyInEaches);
					String[] qtyArr = qtyString.split("\\.");
					orderObj.setQuantity(Integer.parseInt(qtyArr[0]));
					orders.setQuantity(qtyArr[0]);
					orderObj.setSourceCountryCode("us");
					orderObj.setVnpkQuantity(Integer.parseInt(vnpk));
					orderObj.setWhpkQuantity(Integer.parseInt(whpk));
					orders.setVnpk(String.valueOf(vnpk));
					orders.setWhpk(String.valueOf(whpk));
					orders.setChannelMethod("SSTK");
					orderObj.setStatus("New");
					orderObj.setQuantityUOM("EA");
					orderObj.setSubstitutable(Boolean.valueOf(line[6]));
					orders.setSubstitutionFlag(Boolean.valueOf(line[6]));
					orderObj.setOrderType(line[7]);
					orders.setOrderType(line[7]);
					orderObj.setWhseAreaCode(line[0]);
					orders.setWareHouseAreaCode(line[0]);
					orders.setOutQty(String.valueOf(Integer.parseInt(line[13]) * Integer.parseInt(vnpk)));

					String upc = line[5];
					if (upc.length() < 14) {
						upc = upc.substring(0, upc.length() - 1);
						int diff = 13 - upc.length();
						for (int k = 0; k < diff; k++) {
							upc = "0" + upc;
						}
					} else {
						upc = upc.substring(0, upc.length() - 1);
					}
					orderObj.setUpcNumber(upc);
					wac = line[0];
					orderList.add(orderObj);
					orders.setExpectedAllocation(
							buildExpectedPayload(line[10], line[11], line[12], line[14], wareHouseList.get(0)));
					orderDetailList.add(orders);
					i++;
					m++;
				}
				if (orderList.size() != 0) {
					logger.info(orderList);
					logger.info(om.writeValueAsString(orderDetailList));
					jsonOrderObj.setNextPage(null);
					logger.info(om.writeValueAsString(orderList));
					jsonOrderObj.setOrders(orderList);

					// Invalidate the existing orders in OW
					invalidateExistingOrders(wac, dateUrlStr);

					// Order well api to create orders

					Response createOrderResponse = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT)
							.body(om.writeValueAsString(orderList))
							.put(environment.getProperty("orderwell_create_url"));
					Assert.assertEquals(ErrorCodes.CATALYST_CREATE_ORDER_FAILED, Constants.SUCESS_STATUS_CODE,
							createOrderResponse.getStatusCode());

					// kafka ow
					// Producer<String, String> producer = new KafkaProducer<String,
					// String>(getProducerProperties());
					// producer.send(new ProducerRecord<String, String>(topicName,
					// Integer.toString(0), jsonOrderObj.toString()));
					// //kafka ow

					// *******mock code
					// String UUid = UUID.randomUUID().toString();
					//
					// JSONObject finalJsonObj = new JSONObject(
					// jsonUtils.readFile("src/test/resources/ordersjson/finalobj.json"));
					// String mockBody = finalJsonObj.toString(2);
					// mockBody = mockBody.replace("#uuid", UUid);
					// mockBody = mockBody.replace("#mockurl",
					// "/orderwell/US/1/orders.*by=sourcedate&sourcenbr=32612&orderdate=" +
					// dateUrlStr + "&wac="
					// + wac);
					// String body = om.writeValueAsString(jsonOrderObj);
					// mockBody = mockBody.replace("\"#mockbody\"", body);
					//
					// Response mockResponse =
					// SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT)
					// .body(mockBody).post(wireMockUrl + "/__admin/mappings");
					// Assert.assertEquals(ErrorCodes.WITRON_CREATE_ORDERS,
					// Constants.CREATE_SUCESS_STATUS_CODE,
					// mockResponse.getStatusCode());
					// logger.info("Mock response:" + mockResponse.getBody().asString());
					// JSONObject mockObject = new JSONObject(mockResponse.getBody().asString());
					// logger.info(mockObject.getString("id"));
					// logger.info("completed order creation for the ware house area code:" + wac);
					// ******mock code
					logger.info(orderDetailList);
				}
			}
			JSONArray orderDetailsList = jsonUtils.converyListToJsonArray(orderDetailList);

			net.minidev.json.JSONObject testFlowData = jsonUtils
					.convertStringToMinidevJsonObject(tl.get().get(TEST_FLOW_DATA).toString());
			String orderData = jsonUtils.setJsonAtJsonPath(testFlowData.toJSONString(), orderDetailsList,
					"$.testFlowData.ordersDetails");
			tl.get().put(TEST_FLOW_DATA, orderData);
			logger.info(tl.get().get(TEST_FLOW_DATA));
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Mock Catalyst Orders", e);
		}
	}

	public ExpectedAllocation buildExpectedPayload(String qty, String date, String fulfilledItemNbr,
			String pickOrderType, String rotateType) {
		ExpectedAllocation expectedAllocation = new ExpectedAllocation();
		List expectedAllocationList = new ArrayList();
//		Calendar calendar = Calendar.getInstance();
//		calendar.add(Calendar.MONTH, 9);
//		int year = calendar.get(Calendar.YEAR);
//		int month = calendar.get(Calendar.MONTH);
//		String monthString = null;
//		if (String.valueOf(month).length() == 1) {
//			monthString = "0" + String.valueOf(month);
//		} else {
//			monthString = String.valueOf(month);
//		}
//		String yearMonth = String.valueOf(year) + "-" + monthString + "-";
//
		Date currDate = new Date();
		DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr = desturl.format(currDate);

		if (!qty.equals("0")) {
			String[] qtyArr = qty.split("#");
			String[] dateArr = date.split("#");
			String[] fulfilledItemArr = fulfilledItemNbr.split("#");
			String[] pickOrderTypeArr = pickOrderType.split("#");
			for (int i = 0; i < qtyArr.length; i++) {
				String itemresponse = witronUtil.getItemMDMDetails(fulfilledItemArr[i]);
				DocumentContext parsedItemDetailsJson = JsonPath.parse(itemresponse);
				List<String> vnpkList = parsedItemDetailsJson
						.read("$.foundSupplyItems..dcProperties..orderableQuantity.amount");
				String vnpk = String.valueOf(vnpkList.get(0));
				ExpectedPicks pick = new ExpectedPicks();
				pick.setFulfilledItemNbr(fulfilledItemArr[i]);
				pick.setFulfilledQty(String.valueOf(Integer.parseInt(qtyArr[i]) * Integer.parseInt(vnpk)));
				pick.setExpectedVnpk(vnpk);
				if (rotateType.equals("3")) {
					logger.info("Rotate date type equals 3");
//					pick.setRotateDate(String.valueOf(year)+ "-" +monthString + "-" + dateArr[i]);
					pick.setRotateDate(GET_ROTATE_DATE);

				} else {
					pick.setRotateDate(GET_ROTATE_DATE);

				}
				pick.setPickOrderType(pickOrderTypeArr[i]);
				expectedAllocationList.add(pick);
			}
		}
		expectedAllocation.setExpectedPicks(expectedAllocationList);
		return expectedAllocation;
	}

	public void validateAlocationAlgorithm() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			JSONArray listOfWAC = JsonPath.read(testFlowData, GET_ORDERS);
			String wacString = listOfWAC.toJSONString();
			List<OrdersDetail> orderList = objectMapper.readValue(wacString, new TypeReference<List<OrdersDetail>>() {
			});
			List<OrdersDetail> orderListDB = new ArrayList();
			for (OrdersDetail order : orderList) {
				String allocOrderId = order.getAllocationOrderId();
				logger.info("alloc orderId:" + allocOrderId);
				ExpectedAllocation expectedAlloc = order.getExpectedAllocation();
				List<ExpectedPicks> pickList = expectedAlloc.getExpectedPicks();
				List<Map<String, Object>> allocOrdersPicks = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_alloc_order_pick"), allocOrderId);
				logger.info("validating allocation algorithm for OTN:" + order.getOrderTrackingNumber());
				Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_PICK_COUNT, pickList.size(),
						allocOrdersPicks.size());
				List pickListDB = new ArrayList();
				if (order.getOutQty().equals(order.getQuantity())) {
					List<Map<String, Object>> allocOrders = dbUtils.selectFrom(PRODUCT_NAME.OP,
							environment.getProperty("op_select_alloc_order_by_alloc_order_Id"), allocOrderId);
					Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_OUT_QTY, 0,
							(Integer) allocOrders.get(0).get("pre_alloc_each_qty"));
				} else {
					Collections.sort(pickList);
					for (int i = 0; i < allocOrdersPicks.size(); i++) {
						ExpectedPicks pick = pickList.get(i);

						String bohRotateDate = String.valueOf(allocOrdersPicks.get(i).get("boh_rotate_date"));
						Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_PICK_QTY,
								Integer.parseInt(pick.getFulfilledQty()),
								(Integer) allocOrdersPicks.get(i).get("alloc_each_qty"));
						Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_PICK_ITEM,
								Integer.parseInt(pick.getFulfilledItemNbr()),
								(Integer) allocOrdersPicks.get(i).get("item_nbr"));
						logger.info("pick" + pick.getRotateDate());
						logger.info("boh" + bohRotateDate);

//					    Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_PICK_ROTATE_DATE,
//								pick.getRotateDate().substring(0, 10), bohRotateDate.substring(0, 10));

						pick.setPickId((String) allocOrdersPicks.get(i).get("alloc_order_pick_id"));
						pickListDB.add(pick);
					}
				}
				expectedAlloc.setExpectedPicks(pickListDB);
				order.setExpectedAllocation(expectedAlloc);
				orderListDB.add(order);
				logger.info("Allocation algorithm is validated for OTN:" + order.getOrderTrackingNumber());
			}
			JSONArray listofOrderJson = jsonUtil.converyListToJsonArray(orderListDB);
			testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofOrderJson, "$.testFlowData.ordersDetails");
			tl.get().put(TEST_FLOW_DATA, testFlowData);
			logger.info("testData {}", tl.get().get(TEST_FLOW_DATA));
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating allocation algorithm", e);
		}
	}

	public void validateProcessStatus() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> releaseList = parsedtestflowJson.read(GET_RELEASE_NBR);

			JSONArray listOfBatch = JsonPath.read(testFlowData, GET_OUTBOUND);
			String outBoundString = listOfBatch.toJSONString();
			List<OutboundDetail> outboundList = null;
			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});

			Failsafe.with(retryPolicy).run(() -> {
				allocOrdersPicks = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_process_status"), releaseList.get(0));
				Assert.assertEquals(ErrorCodes.WITRON_MISMATCH_OP_PROCESS_STATUS, 1, allocOrdersPicks.size());
			});
			outboundList.get(0).setScoreJobId((String) allocOrdersPicks.get(0).get("job_id"));

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.outboundDetails",
					JsonPath.parse(om.writeValueAsString(outboundList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating release number::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_MISMATCH_OP_PROCESS_STATUS, e);
		}
	}

//	public void validateProcessStatusAfterRouteRelease() {
//		try {
//			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
//			DocumentContext context = null;
//			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
//
//			List<String> releaseList = parsedtestflowJson.read(GET_RELEASE_NBR);
//
//			JSONArray listOfBatch = JsonPath.read(testFlowData, GET_OUTBOUND);
//			String outBoundString = listOfBatch.toJSONString();
//			List<OutboundDetail> outboundList = null;
//			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
//			});
//
//			Failsafe.with(retryPolicy).run(() -> {
//				allocOrdersPicks = dbUtils.selectFrom(PRODUCT_NAME.OP,
//						environment.getProperty("op_select_process_status_router_release"), releaseList.get(0));
//				Assert.assertEquals(ErrorCodes.WITRON_MISMATCH_OP_PROCESS_STATUS, 1, allocOrdersPicks.size());
//			});
//
//			logger.info("testData after updating release number::{}", tl.get().get(TEST_FLOW_DATA));
//
//		} catch (Exception e) {
//			throw new TestCaseFailure(ErrorCodes.WITRON_MISMATCH_OP_PROCESS_STATUS, e);
//		}
//	}

	public void populateAllocOrderId() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testFlowData);

			JSONArray listOfWAC = JsonPath.read(testFlowData, GET_ORDERS);
			String wacString = listOfWAC.toJSONString();
			List<OrdersDetail> wacList = objectMapper.readValue(wacString, new TypeReference<List<OrdersDetail>>() {
			});

			// List<OrdersDetail> wacs = parsedItemDetailsJson.read(GET_ORDERS);
			List orderList = new ArrayList();
			Object[] wacArr = new Object[wacList.size()];
			for (int i = 0; i < wacList.size(); i++) {
				OrdersDetail order = wacList.get(i);
				wacArr[i] = order.getOrderTrackingNumber();
				List<Map<String, Object>> allocOrdersRecords = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_alloc_order_fulfilled"),
						order.getOrderTrackingNumber().toString());
				order.setAllocationOrderId(allocOrdersRecords.get(0).get("alloc_order_id").toString());
				order.setOrderId(allocOrdersRecords.get(0).get("order_id").toString());
				orderList.add(order);
			}

			List<Map<String, Object>> allocRecords = dbUtils.selectFrom(PRODUCT_NAME.OP,
					dbUtils.transformIntoSpringQuery(environment.getProperty("op_select_alloc_order"), wacArr.length),
					wacArr);

			Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_IN_WAVE, wacList.size(), allocRecords.size());

			JSONArray listofOrderJson = jsonUtil.converyListToJsonArray(orderList);
			testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofOrderJson, "$.testFlowData.ordersDetails");
			tl.get().put(TEST_FLOW_DATA, testFlowData);
			logger.info("testData {}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish OW trigger", e);
		}

	}

	@Step
	public void validateCntrs() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> releaseList = parsedtestflowJson.read(GET_RELEASE_NBR);
			logger.info(System.getProperty("user.dir") + BATCH_PLANNER_FILE_PATH);
			Reader reader = new FileReader(System.getProperty("user.dir") + BATCH_PLANNER_FILE_PATH);
			CSVReader csvReader = new CSVReader(reader);
			int i = 0;
			int m = 1;
			String[] line;
			while ((line = csvReader.readNext()) != null) {
				if (i == 0) {
					i++;
					continue;
				}
				List<Map<String, Object>> cntrs = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_cntr"), releaseList.get(0));
				Assert.assertEquals(ErrorCodes.WITRON_CNTRS_COUNT_RELEASE_MISMATCH, Integer.parseInt(line[15]),
						cntrs.size());

				List<Map<String, Object>> cntrsFull = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_cntr_full"), releaseList.get(0));
				Assert.assertEquals(ErrorCodes.WITRON_CNTRS_COUNT_MISMATCH_FULL, Integer.parseInt(line[16]),
						cntrsFull.size());

				List<Map<String, Object>> cntrsMixed = dbUtils.selectFrom(PRODUCT_NAME.OP,
						environment.getProperty("op_select_cntr_mix"), releaseList.get(0));
				Assert.assertEquals(ErrorCodes.WITRON_CNTRS_COUNT_MISMATCH_MIX, Integer.parseInt(line[17]),
						cntrsMixed.size());
				break;
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate containers disribution", e);
		}
	}

	public Properties getProducerProperties() {
		// create instance for properties to access producer configs
		Properties props = new Properties();

		// props.put("bootstrap.servers",
		// "kafkav10.stg.ow-kafka0.replflow.prod.walmart.com:9092");
		props.put("bootstrap.servers",
				"kafka-520016960-5-532141789.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"
						+ "kafka-520016960-1-532141777.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"
						+ "kafka-520016960-6-532141792.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"
						+ "kafka-520016960-3-532141783.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"
						+ "kafka-520016960-2-532141780.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"
						+ "kafka-520016960-4-532141786.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092");

		// Set acknowledgements for producer requests.
		props.put("acks", "all");
		// If the request fails, the producer can automatically retry,
		props.put("retries", 0);
		// Specify buffer size in config
		props.put("batch.size", 16384);
		// Reduce the no of requests less than 0
		props.put("linger.ms", 1);
		// The buffer.memory controls the total amount of memory available to
		// the producer for buffering.
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		return props;

	}

	public void invalidateExistingOrders(String wareHouseAreaCode, String date) {
		try {

			String orderWellUrl = environment.getProperty("orderwell_get_url") + environment.getProperty("facility_num")
					+ "&orderdate=" + date + "&wac=" + wareHouseAreaCode + "&status=New";
			logger.info("orderwell get url:" + orderWellUrl);

			Response owResponse = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT).get(orderWellUrl);
			Assert.assertEquals(ErrorCodes.WITRON_GET_ORDERS_FAILED, Constants.SUCESS_STATUS_CODE,
					owResponse.getStatusCode());

			DocumentContext parsedOWJson = JsonPath.parse(owResponse.asString());
			logger.info("parsedOWJson" + parsedOWJson);
			List<String> ordersList = parsedOWJson.read("$.orders[*].orderTrackingNumber");
			logger.info("ordersList-->" + ordersList);
			List<OTNList> updateList = new ArrayList();

			for (String otn : ordersList) {
				OTNList otnList = new OTNList();
				otnList.setOrderTrackingNumber(otn);
				otnList.setStatus("Invalid");
				updateList.add(otnList);
			}
			logger.info("updateList" + updateList);

			UpdateOrderwell updateOW = new UpdateOrderwell();
			if (!updateList.isEmpty()) {
				updateOW.setUpdateList(updateList);
				logger.info(om.writeValueAsString(updateOW));

				Response owStatusResponse = SerenityRest.given().relaxedHTTPSValidation()
						.body(om.writeValueAsString(updateOW))
						.put(environment.getProperty("orderwell_change_status_url"));
				Assert.assertEquals(ErrorCodes.WITRON_UPDATE_ORDER_STATUS_FAILED, Constants.SUCESS_STATUS_CODE,
						owStatusResponse.getStatusCode());
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to In validate existing orders in OW", e);
		}
	}

}
