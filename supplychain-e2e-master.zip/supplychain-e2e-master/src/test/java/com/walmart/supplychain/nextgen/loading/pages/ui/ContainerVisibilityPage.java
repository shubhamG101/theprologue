package com.walmart.supplychain.nextgen.loading.pages.ui;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;

public class ContainerVisibilityPage extends SerenityHelper {

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	//WebDriver driver;

	@FindBy(xpath = "//table[@ng-model='selectedContainers']/tbody/tr[1]/td[4]")
	private WebElement ContainerStatus;

	@FindBy(xpath = "//table[@ng-model='selectedContainers']/tbody/tr[1]/td[1]")
	private WebElement container;

	@FindBy(xpath = "//div[p[text()='Load Management']]/h1/button")
	private WebElement leftToggleButton;

	@FindBy(xpath = "//input[@ng-model='vm.selectedContainerIds']")
	private WebElement containerIdTextField;

	@FindBy(id = "searchIcon")
	private WebElement searchIconinContainerVisibility;

	@FindBy(xpath = "//md-table-container//table[@ng-model='selectedContainers']//tbody/tr")
	private List<WebElement> cntrTableCount;

	@FindBy(xpath = "//md-table-container//table[@ng-model='selectedContainers']//tbody/tr")
	private WebElement tableContainer;

	@FindBy(xpath = "//md-table-container//table[@ng-model='selectedContainers']//tbody/tr")
	private WebElement tableContainerStatus;

	@FindBy(id = "loadId")
	private WebElement loadIdTxt;

	@FindBy(xpath = "//span[@md-highlight-text='vm.searchLoadId']/span")
	private WebElement selectLoadId;

	@FindBy(xpath = "//span[div[text()='Picked']]")
	private WebElement selectStatusMenu;
	
	@FindBy(xpath = "//div[@role='presentation']//div[text()='Loaded']")
	private WebElement selectLoaded;
		
	@FindBy(id = "searchIcon")
	private WebElement searchIcon;

	@FindBy(xpath = "//md-table-container//table[@ng-model='selectedContainers']//tbody/tr")
	private List<WebElement> rowCount;

	public void waitForSpinner() {
		try {
			WebDriverWait wait = new WebDriverWait(getDriverInstance(), 5);
			logger.info("wait for loader");
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.cssSelector("md-progress-circular[md-mode='indeterminate']")));
			logger.info("found loader");
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.cssSelector("md-progress-circular[md-mode='indeterminate']")));
			logger.info("loader disappeared");
		} catch (TimeoutException ex) {
			logger.info("Exceeded the timeout for loader.Proceeding");
		}
	}

	public void validateCntrStatus(List cntrList, String cntrStatus) throws InterruptedException {

		// waitForSpinner();
		Assert.assertEquals(cntrTableCount.size(), cntrList.size());
		WebDriver driver = getDriverInstance();
		for (int i = 0; i < cntrTableCount.size(); i++) {
			String container = driver.findElement(By.xpath(
					"//md-table-container//table[@ng-model='selectedContainers']//tbody/tr[" + (i + 1) + "]//td[1]"))
					.getText();
			String containerStatusui = driver.findElement(By.xpath(
					"//md-table-container//table[@ng-model='selectedContainers']//tbody/tr[" + (i + 1) + "]//td[4]"))
					.getText();
			Assert.assertTrue("checking container in the outbound container list", cntrList.contains(container));
			Assert.assertEquals("checking container status", cntrStatus, containerStatusui);
			logger.info("container status expected:" + cntrStatus + "|container status ui" + containerStatusui);
			Thread.sleep(1000);
		}

	}

	public int searchLoadId(String loadId) {
		logger.info("Searching loadID: {}", loadId);
		element(loadIdTxt).waitUntilVisible();
		element(loadIdTxt).type(loadId);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		click(selectLoadId);
		element(searchIcon).waitUntilEnabled();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		click(searchIcon);
		// waitForSpinner();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int noOfRows = rowCount.size();
		logger.info("Number of rows found in load id search:" + noOfRows);
		return noOfRows;

	}

	public void clickOnLeftToggleButton() {
		element(leftToggleButton).waitUntilVisible();
		element(leftToggleButton).click();
		logger.info("clicked toggle button");
	}

	public void enterContainerIdandClickonSearchIcon(String containerId) throws InterruptedException {
		element(containerIdTextField).waitUntilVisible();
		element(containerIdTextField).type(containerId);
		logger.info("Entering container in search text" + containerId);
		Thread.sleep(2000);
		element(searchIconinContainerVisibility).waitUntilVisible();
		element(searchIconinContainerVisibility).click();
		logger.info("clicking on search in container visibility");
	}

	public void validateContainerStatusByCntrId(List cntrIds, String cntrStatus) {
		try {
			element(loadIdTxt).waitUntilVisible();
			for (int i = 0; i < cntrIds.size(); i++) {
				String cntr = (String) cntrIds.get(i);
				element(containerIdTextField).type(cntr);
				element(searchIcon).waitUntilEnabled();
				click(searchIcon);

				WebDriver driver=getDriverInstance();
				String containerStatusui = driver
						.findElement(By.xpath("//md-table-container//table[@ng-model='selectedContainers']//tbody/tr[1]//td[4]"))
						.getText();
				Assert.assertEquals("validate container status", cntrStatus, containerStatusui);
			}
		} catch (Exception e) {
          logger.error(e);
          throw new TestCaseFailure("Validating contsiner status failed in loading UI", e);
		}

	}

	public void getUrl(String url) {
		getDriverInstance().get(url);

	}

	public void selectLoaded() throws InterruptedException {
		element(selectStatusMenu).waitUntilVisible();
		element(selectStatusMenu).click();
		logger.info("clicked on status drop down");
		
		Thread.sleep(2000);
		
		element(selectLoaded).click();
		logger.info("clicked on loaded status to search on the UI");
		
		Thread.sleep(3000); //waiting for search to finish
		
	}
}
