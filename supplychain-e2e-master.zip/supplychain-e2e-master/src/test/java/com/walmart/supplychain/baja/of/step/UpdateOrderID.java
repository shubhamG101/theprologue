package com.walmart.supplychain.baja.of.step;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class UpdateOrderID {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	Environment environment;
	
	@Autowired
	SpringJmsUtils springJmsUtils;
	
	@Value("${opcAllocated}")
	String opcAllocated;
	
	JsonUtils jsonUtil = new JsonUtils();

	private String TEST_FLOW_DATA = "testFlowData";
	Logger logger = LogManager.getLogger(this.getClass());

	 String file = FileNames.BAJA_ORDER_ID_FILE;
 
    @Step
    public void updateOrderID() throws InterruptedException {
 
        try {
        	
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray messageID = JsonPath.parse(testData).read("$..messageId");

        	logger.info("Retriving the xml file path",file);
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(file);
 
            Node orderStatusChangeNotificationMessageRequest = document.getElementsByTagName("orderStatusChangeNotificationMessageRequest").item(0);
 
           //loop the orderStatusChangeNotificationMessageRequest node and update OrderID Value
            NodeList nodes = orderStatusChangeNotificationMessageRequest.getChildNodes();
            logger.info("Getting all the child nodes of:{}",orderStatusChangeNotificationMessageRequest);
            for (int i = 0; i < nodes.getLength(); i++) {
            	
            	Node element = nodes.item(i);
            	if ("orderId".equals(element.getNodeName())) {
            		 element.setTextContent(messageID.get(0).toString());
                    logger.info("Value is updated with new Order ID");
                }
               }
 
            // write the DOM object to the file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
 
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
 
            StreamResult streamResult = new StreamResult(new File(file));
            transformer.transform(domSource, streamResult);
            logger.info("The XML File is updated ");
 
            Thread.sleep(5000);

            logger.info("Allocated message published for messageID "+messageID.get(0).toString());
            springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ,
					Config.DC, opcAllocated, jsonUtil.readFile("src//test//resources//TestData//Baja//OrderStatusChangeName.xml"));

            
        } catch (ParserConfigurationException | TransformerException | IOException | SAXException pce) {
        	throw new AutomationFailure("Something went wrong while updating the Order ID", pce);
        }  
    }
}