package com.walmart.supplychain.acc.mcb.steps.webservices;

import java.io.IOException;
import java.util.List;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.TextParser;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import com.walmart.framework.utilities.javautils.JavaUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.walmart.framework.supplychain.domain.acc.AssociateNextPalletsOnMCB;
import com.walmart.framework.supplychain.domain.acc.CompleteMCB;
import com.walmart.framework.supplychain.domain.acc.CreateMCBPallet;
import com.walmart.framework.supplychain.domain.acc.MCBBuildInputBody;
import com.walmart.framework.supplychain.domain.acc.RemoveChildFromMCB;
import com.walmart.framework.supplychain.domain.acc.ScanFirstPalletForMCB;

import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

public class MCBHelper {

	@Autowired
	TextParser textParser;

	@Autowired
	JavaUtils javaUtils;

	public String constructFirstPalletScanPayload(String container) throws IOException {
		ScanFirstPalletForMCB scanFirstPalletPayload = new ScanFirstPalletForMCB();
		scanFirstPalletPayload.setScannedLabel(container);
		scanFirstPalletPayload.setValidateInventory(false);
		scanFirstPalletPayload.setGenerateMasterLabel(true);
		return constructBuildInput(scanFirstPalletPayload);
	}

	public String constructFirstPalletScanPayload(String container, String storeGroupName, int storeGroupId) throws IOException {
		ScanFirstPalletForMCB scanFirstPalletPayload = new ScanFirstPalletForMCB();
		scanFirstPalletPayload.setScannedLabel(container);
		scanFirstPalletPayload.setStoreGroupId(storeGroupId);
		scanFirstPalletPayload.setStoreGroupName(storeGroupName);
		scanFirstPalletPayload.setValidateInventory(false);
		scanFirstPalletPayload.setGenerateMasterLabel(true);
		return constructBuildInput(scanFirstPalletPayload);
	}

	public String constructAssociateNextPalletPayload(String newLabel, String oldLabel, int storeNumber) throws IOException {
		AssociateNextPalletsOnMCB associatePalletsPayload = new AssociateNextPalletsOnMCB();
		associatePalletsPayload.setChildLabel(newLabel);
		associatePalletsPayload.setScannedInput(oldLabel);
		associatePalletsPayload.setStoreNumber(storeNumber);
		return constructBuildInput(associatePalletsPayload);
	}

	public String constructAssociateNextPalletPayload(String newLabel, String oldLabel, int storeNumber, String storeGroupName, String storeGroupId) throws IOException {
		AssociateNextPalletsOnMCB associatePalletsPayload = new AssociateNextPalletsOnMCB();
		associatePalletsPayload.setChildLabel(newLabel);
		associatePalletsPayload.setScannedInput(oldLabel);
		associatePalletsPayload.setStoreGroupName(storeGroupName);
		associatePalletsPayload.setStoreGroupId(storeGroupId);
		associatePalletsPayload.setStoreNumber(storeNumber);
		return constructBuildInput(associatePalletsPayload);
	}

	public String constructCreateMCBPalletPayload(String mcbPalletName, String childLabel) throws IOException {
		CreateMCBPallet createMCBPalletPayload = new CreateMCBPallet();
		createMCBPalletPayload.setMasterLabel(mcbPalletName);
		createMCBPalletPayload.setChildLabel(childLabel);
		createMCBPalletPayload.setGenerateMasterLabel(false);
		return constructBuildInput(createMCBPalletPayload);
	}

	public String constructCreateMCBPalletPayload(String mcbPalletName, String childLabel, String storeGroupName, int storeGroupId) throws IOException {
		CreateMCBPallet createMCBPalletPayload = new CreateMCBPallet();
		createMCBPalletPayload.setMasterLabel(mcbPalletName);
		createMCBPalletPayload.setChildLabel(childLabel);
		createMCBPalletPayload.setStoreGroupName(storeGroupName);
		createMCBPalletPayload.setStoreGroupId(storeGroupId);
		createMCBPalletPayload.setGenerateMasterLabel(false);
		return constructBuildInput(createMCBPalletPayload);
	}

	public String constructCompleteMCBPalletPayload(String mcbPalletName, int storeNumber) throws IOException {
		CompleteMCB completeMCBPalletPayload = new CompleteMCB();
		completeMCBPalletPayload.setScannedInput(mcbPalletName);
		completeMCBPalletPayload.setStoreNumber(storeNumber);
		return constructBuildInput(completeMCBPalletPayload);
	}

	public String constructCompleteMCBPalletPayload(String mcbPalletName, int storeNumber, String storeGroupName, int storeGroupId) throws IOException {
		CompleteMCB completeMCBPalletPayload = new CompleteMCB();
		completeMCBPalletPayload.setScannedInput(mcbPalletName);
		completeMCBPalletPayload.setStoreNumber(storeNumber);
		completeMCBPalletPayload.setStoreGroupName(storeGroupName);
		completeMCBPalletPayload.setStoreGroupId(storeGroupId);
		return constructBuildInput(completeMCBPalletPayload);
	}

	public String constructRemoveChildContainersPayload(List<String> Childs) throws IOException {
		RemoveChildFromMCB removeChildFromMCBPayload = new RemoveChildFromMCB();
		removeChildFromMCBPayload.setChildIds(Childs);
		removeChildFromMCBPayload.setActionType("remove");
		return constructMasterInput(removeChildFromMCBPayload);
	}

	public String constructBuildInput(Object innerData) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		JSONObject json = new JSONObject();
		json.put("buildInput", innerData);
		return mapper.writeValueAsString(json);
	}
	public String constructMasterInput(Object innerData) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		JSONObject json = new JSONObject();
		json.put("masterInput", innerData);
		return mapper.writeValueAsString(json);
	}

	public String mcbCreateNewPayload(String trackingId, String destinationNum) throws Exception {

		String mcbCreate = "";
		String mcbCreateData = null;
		mcbCreateData = textParser.readTextFile(FileNames.MCB_CREATE_FILE);
		mcbCreate = javaUtils.format(mcbCreateData, trackingId, destinationNum);
		return mcbCreate;
	}

	public String mcbCompleteStartPayload(String masterTrackingId) throws Exception {
		String mcbCompleteStartPayload = "";
		String mcbCompleteStart = null;
		mcbCompleteStart = textParser.readTextFile(FileNames.MCB_COMPLETE_START);
		mcbCompleteStartPayload = javaUtils.format(mcbCompleteStart, masterTrackingId);
		return mcbCompleteStartPayload;

	}

	public String mcbCompleteFinishPayload(String masterTrackingId) throws Exception {
		String mcbCompleteFinishPayload = "";
		String mcbCompleteFinish = null;
		mcbCompleteFinish = textParser.readTextFile(FileNames.MCB_COMPLETE_FINISH);
		mcbCompleteFinishPayload = javaUtils.format(mcbCompleteFinish, masterTrackingId);
		return mcbCompleteFinishPayload;
	}

	public String mcbCreateRegularNewPayload(String trackingId, String groupId, String destinationNum) throws Exception {

		String mcbCreate = "";
		String regularMCBCreateData = null;
		regularMCBCreateData = textParser.readTextFile(FileNames.MCB_CREATE_FILE_FOR_REGULAR_FLOW);
		mcbCreate = javaUtils.format(regularMCBCreateData, trackingId, destinationNum,groupId );
		return mcbCreate;
	}
}
