package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class PalletCorrectionUpdatePage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_quantity']")
	private WebElement updateQtyInput;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_print']")
	private WebElement printBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/button1']")
	private WebElement updateConfirmBtn;

	@FindBy(xpath = ".//*[@text='Connect printer']")
	private WebElement connectPrinterBtn;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.printing.printingandroidapp:id/imageSearchButton']")
	private WebElement printerSearchIcon;

	@FindBy(xpath = ".//*[@text='RDC-STG-23']")
	private WebElement selectPrinter;

	@FindBy(xpath = ".//*[@content-desc='Navigate up']")
	private WebElement backBtn;

	public void updatePalletQuantity(String updatedQty) {

		try {

			element(updateQtyInput).waitUntilVisible();
			element(updateQtyInput).type(updatedQty);

			element(printBtn).waitUntilVisible();
			element(printBtn).click();

			if (updatedQty.equals("0")) {
				element(updateConfirmBtn).waitUntilVisible();
				element(updateConfirmBtn).click();
			}

			element(connectPrinterBtn).waitUntilVisible();
			element(connectPrinterBtn).click();

			element(printerSearchIcon).waitUntilVisible();
			element(printerSearchIcon).click();

			element(selectPrinter).waitUntilVisible();
			element(selectPrinter).click();

			Thread.sleep(3000);
			navigateToDoorScanPage();
		} catch (Exception e) {

		}
	}

	public void navigateToDoorScanPage() {
		element(backBtn).waitUntilVisible();
		element(backBtn).click();
	}
}
