package com.walmart.supplychain.nextgen.orderwell.gluecode;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.op.steps.webservices.OpSteps;
import com.walmart.supplychain.nextgen.orderwell.steps.webservices.OrderWellSteps;

import spring.SpringTestConfiguration;


@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OrderWell {
	private static final Logger LOGGER = LoggerFactory.getLogger(OrderWell.class);
    @Steps
    OrderWellSteps orderWellSteps;
    
    @Steps
    OpSteps opSteps;
    

    @Steps
	PreRunCleanup preRunCleanup;

    @Given("^user verifies orders are available for download in OW$")
    public void user_verifies_orders_are_available_for_download_in_OW() throws JSONException, InterruptedException {


        orderWellSteps.verifyOrdersAvailability();
       //orderWellSteps.verifyThatOrdersAreCreatedInOrderWell();
    }
    
    @Given("^Creates orders with \"([^\"]*)\" and \"([^\"]*)\" for invalid destination \"([^\\\"]*)\"\\.$")
    public void creates_orders_with_for_DC_s_for_invalidDest(String distributions, String poPercentages, String destination)  {

    	System.setProperty("invalidDest", destination);
        orderWellSteps.usingPoLineDataCreateOrderWellOrders(distributions, poPercentages,"");
    }
    
    @Given("^Creates orders with \"([^\"]*)\" and \"([^\"]*)\"\\.$")
    public void creates_orders_with_for_DC_s(String distributions, String poPercentages)  {

        orderWellSteps.usingPoLineDataCreateOrderWellOrders(distributions, poPercentages,"");
    }
    
    @Given("^Creates orders with \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void creates_orders_with_for_DC_for_new_item(String distributions, String poPercentages,String itemNum)  {

        orderWellSteps.usingPoLineDataCreateOrderWellOrders(distributions, poPercentages,itemNum);
    }
    
    @Given("^Creates orders with \"([^\"]*)\" and \"([^\"]*)\" with \"([^\"]*)\"$")
    public void creates_orders_with_for_DC_s(String distributions, String poPercentages,String ovgFlag) throws Exception {

    	LOGGER.info("In the glue code step for creating OW orders based on OMS po lines");

    	orderWellSteps.usingPoLineDataCreateOrderWellOrders(distributions, poPercentages,Boolean.parseBoolean(ovgFlag),"");
    }
    
    @Then("^user resets order details$")
	public void userResetsOrderDetails () {
    	orderWellSteps.resetOrderDetails();
	}
  
    @Given("^user creates order in OW with \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void createsOrders(String wmtItemNumber, String quantity,String whpkQuantity,String Store,String vnpkQuantity) throws Exception {

    	LOGGER.info("In the glue code step for creating OW orders");
    	orderWellSteps.createOrderWellOrders(wmtItemNumber,quantity,whpkQuantity,Store,vnpkQuantity);
    	
    	preCleanUpBaja();

    }
 
 
	@Then("^user verifies orders are available in OW$")
    public void verifyOrdersInOw()
    {
    	orderWellSteps.verifyThatBajaOrdersAreCreatedInOrderWell();
    }
    
    @Given("^user sends a trigger to download orders from Order well$")
    public void sendTriggerForBajaOrdersDOwnload()
    {
    	orderWellSteps.sendTriggerForBajaOrdersDownload();
    }
    
    @Given("^user updates order status to \"([^\"]*)\" in OW$")
    public void updateOrderStatus(String Status) {
    	orderWellSteps.updateOrderStatus(Status);
    	orderWellSteps.verifyOrderStatusInOrderWell(Status);
    }
  
    
    private void preCleanUpBaja() {
    	preRunCleanup.cleanUpOPBaja();
		preRunCleanup.cleanUpInventoryBaja();
		preRunCleanup.cleanUpLoading();
	}  
}
