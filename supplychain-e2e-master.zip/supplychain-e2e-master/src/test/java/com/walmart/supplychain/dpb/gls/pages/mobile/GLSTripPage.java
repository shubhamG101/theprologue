package com.walmart.supplychain.dpb.gls.pages.mobile;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class GLSTripPage extends SerenityHelper {
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	final String RECEIVING_MOBILE_ID = "com.walmart.move.nim.receiving.mobile:id/";
	final String POPUP_MESSAGE = "android:id/message";
	final String IMPLICIT_TIMEOUT = "webdriver.timeouts.implicitlywait";
	final String WAIT_TIMEOUT = "webdriver.wait.for.timeout";
	
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = "//*[@text='Associate ID']")
	private WebElement userName;

	@FindBy(xpath = "//*[@text='Sync authentication']")
	private WebElement syncAuthenticationBtn;

	public void closeBrowser() {
		getDriver().quit();
	}

	WebDriver driver = null;

	public void loginToVision(String user) {
//		driver = getDriver();
//		try {
//			Thread.sleep(10000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		getAndroidDriver().startActivity(new Activity("com.walmart.csis.vision", "com.walmart.csis.vision.MainActivity"));
//
//		element(userName).waitUntilVisible();
//		element(userName).type(user);
//
//		element(syncAuthenticationBtn).waitUntilVisible();
//		element(syncAuthenticationBtn).click();

		logger.info("Logged in to Vision with User ID {}", user);
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
}
