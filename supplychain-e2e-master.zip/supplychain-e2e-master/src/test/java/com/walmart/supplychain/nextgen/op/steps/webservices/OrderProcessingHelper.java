package com.walmart.supplychain.nextgen.op.steps.webservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.utilities.db.PRODUCT_NAME;

import io.restassured.http.Header;
import io.restassured.http.Headers;


public class OrderProcessingHelper {
	@Autowired
	Environment environment;
	public Headers getOpHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum",environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		return new Headers(headerList);
	}

}
