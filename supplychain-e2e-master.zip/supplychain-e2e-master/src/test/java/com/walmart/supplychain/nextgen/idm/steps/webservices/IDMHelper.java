package com.walmart.supplychain.nextgen.idm.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;

import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.yms.YmsGateOut;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetailsRDC;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.RDCDeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.WitronItemDetails;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SchedulerConnectionUtil;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.oms.gluecode.webservices.Oms;

import android.R.integer;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class IDMHelper {
	@Value("${schedular_queue_mcc}")
	String schedularQueue_MCC;

	@Value("${schedular_queue_rdc}")
	String schedularQueue_RDC;

	@Value("${schedular_topic}")
	String schedularTopic;

	@Value("${maas_schedular_queue}")
	String maasSchedularQueue;

	@Autowired
	SpringJmsUtils springJmsUtils;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	TextParser textParser;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	Environment environment;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;
	
	@Autowired
	SchedulerConnectionUtil schedulerConnectionUtil;
	
	@Autowired
	PreRunCleanup preRunCleanup;
	
	@Autowired
	IDMSteps idmSteps ;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	Environment queries;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String PO_NUMBER_JSONPATH = "$.testFlowData.poDetails[*].poNumber";
	private static final String PO_NAME = "$.testFlowData.poDetails[*].poName";
	private static final String INBOUND_DOOR_JSONPATH = "$.testFlowData.deliveryDetails[0].inboundDoorNumber";
	private static final String RECEIVED_QTY_JSONPATH = "$.testFlowData..poDetails[?(@.poNumber=='#0#')]..receivedQuantity";
	private static final String RECEIVED_QTY_JSONPATH_WITRON = "$.testFlowData..poDetails[?(@.poNumber=='#0#')]..receivingInstructions[?(@.isVTR==false)].receivedQuantity";
	private static final String RECEIVED_QTY_JSONPATH_ACC = "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails[*].receivingInstructions[?(@.labelType=='normal')].receivedQuantity";
	private static final String ITEM_NR_DELIVERY_JSONPATH = "$..poLineDetails[*].itemNumber";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String RDC_DELIVERY_JSONPATH = "$..deliveryDetailsRDC[*].deliveryNumber";
	private static final String GET_DELIVERY_NUM = "$..deliveryDetails[*].deliveryNumber";
	private String receivingInstructionReceivedQty = "$..receivingInstructions[?(.isVTR=true)].receivedQuantity";
	private static final String WMT_USER_ID = "system";
	private static final String DOOR_TYPE = "online";
	private static final String TESTDATA_ISCONVEYABLE_JSONPAH = "$.testFlowData.poDetails[*].poLineDetails[*].isConveyable";
	private static final String DELIVERY_ISCONVEYABLE_JSONPAH = "$.deliveryDocuments[*].deliveryDocumentLines[*].isConveyable";
	private static final String PO_REJECT = "REJECTED";
	private static final String GET_PO_NUMBER_FROM_NAME = "$..poDetails[?(@.poName=='#0#')].poNumber";
	private static final String RECEIVED_QTY_FROM_TESTFLOWDATA_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails[0].receivingInstructions[0].receivedQuantity";
	private static final String RECEIVED_QTY_FROM_OSDR_RESPONSE_JSON_PATH = "$.purchaseOrders[?(@.poNumber=='#0#')]...received.quantity";
	private static final String PO_VNPK_QTY_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber == '#0#')].poLineDetails[0].poVnpkQty";
	private static final String SHORTAGE_QTY_FROM_OSDR_JSON_PATH = "$.purchaseOrders[?(@.poNumber=='#0#')]..shortage.quantity";
	private static final String DAMAGE_QTY_FROM_TESTFLOWDATA_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber == '#0#')].poLineDetails[0].damageQty";
	private static final String DAMAGE_QTY_FROM_OSDR_JSON_PATH ="$.purchaseOrders[?(@.poNumber=='#0#')]..damage.quantity";
	private static final String OVERAGE_QTY_FROM_OSDR_JSON_PATH = "$.purchaseOrders[?(@.poNumber== '#0#')]..overage.quantity";

	private DocumentContext parsedJson;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	Config config = new Config();

	private final String deliveryStatusPath = "deliveryStatus";
	private final String deliveryDoorPath = "doorNumber";
	private String recQtyPath = "pos.<po>.receivedQty";
	private String inboundDoorNumber = "";
	private Response response;
	private List<String> itemNumberList = new ArrayList();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();

	private final String wtmsLoadIdJsonPath = "$.testFlowData.outboundDetails..tmsLoadId";
	private static final String QUEUE = "queue";
	private final String PONUMBER_PATH = "$.testFlowData.poDetails[0].poNumber";
	private static final String BOL_JSON_PATH = "$.testFlowData.outboundDetails..rdcDeliveryDetail.bolNumber";
	private static final String RDC_DELIVERYDETAILS_PATH_S2S = "$.testFlowData.outboundDetails..rdcDeliveryDetail.deliveryNumber";

	private static final int MIN_DOOR_RANGE = 100;

	private static final int MAX_DOOR_RANGE = 99999;
	private static Instant hazmatVerifiedOn = Instant.now().minus( 367L, ChronoUnit.DAYS);
	private static Instant limitedQtyVerifiedOn = Instant.now().minus( 367L, ChronoUnit.DAYS);
	private static Instant lithiumIonVerifiedOn = Instant.now().minus( 367L, ChronoUnit.DAYS);
	private static final String GET_LINE_DETAILS_PATH = "$..poDetails[?(@.poNumber=='#0#')].poLineDetails[*]";
	private final String simple_date_time_format = "yyyy-MM-dd HH:mm:ss:SSS";

	@SuppressWarnings("unused")
	public void createDeliveryMCC(int qtyPercentage, String status, String delvryName, String loadNum)
			throws URISyntaxException, IOException, ParseException {
		String runTimeData;
		String deliveryNumber;
		String delMesgFormat;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		delMesgFormat = textParser.readTextFile(FileNames.DELIVERY_MESSAGE_FILE_ATLAS);
		if (status.contains("C")) {
			JSONArray delNum = JsonPath.read(runTimeData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");
			deliveryNumber = (String) delNum.get(0);
		} else {
			deliveryNumber = Integer.toString(javaUtils.randonNumberGenerator(8));
		}
		String stringSplitData[] = delMesgFormat.split("\\$");
		logger.info("RunTimeData:{}", runTimeData);
		List<String> poNumbers = JsonPath.parse(runTimeData).read(PO_NUMBER_JSONPATH);
		int poQty = 0;
		if (loadNum==null || loadNum.trim().isEmpty()) {
			loadNum = "11223344";
		}

		JSONArray qtyArray;
		JSONArray ovgFlag;
		JSONArray ovgQty;
		for (int i = 0; i < poNumbers.size(); i++) {
			poQty = 0;
			qtyArray = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[" + Integer.toString(i) + "].poLineDetails..poVnpkQty");
			ovgFlag = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[" + Integer.toString(i) + "].poLineDetails..overageFlag");
			ovgQty = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[" + Integer.toString(i) + "].poLineDetails..ovgQty");
			for (int k = 0; k < qtyArray.size(); k++) {

				poQty = poQty + Integer.parseInt((String) qtyArray.get(k));
			}
			logger.info("Total PO Qty:{}", poQty);
			logger.info("Percentage of po qty to be added in delivery:{}", qtyPercentage);
			poQty = poQty * qtyPercentage / 100;
			logger.info("Total PO Qty to be created in this delivery:{}", poQty);
			String dcNumber = environment.getProperty("facility_num");
			logger.info("Site Id:{} ", dcNumber);
			String deliveryMessage = stringSplitData[0] + deliveryNumber + stringSplitData[1] + loadNum
					+ stringSplitData[2] + dcNumber + stringSplitData[3] + (String) poNumbers.get(i)
					+ stringSplitData[4] + Integer.toString(poQty) + stringSplitData[5] + "" + stringSplitData[6];

			deliveryMessage = deliveryMessage.replaceAll("#current_date#", javaUtils.getCurrentDate());
			deliveryMessage = deliveryMessage.replaceAll("#current_time#", javaUtils.getCurrentTime("."));
			deliveryMessage = deliveryMessage.replaceAll("#status#", status);

			logger.info("deliveryMessage:{} ", deliveryMessage);

			// publishDeliveryMessageToTopic(deliveryMessage); -- Currently publishing to
			// Maas queue
			logger.info("Publishing Delivery Message");
			synchronized (stratiConnectionUtil) {
				stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_schedular_queue"),
						deliveryMessage, QUEUE, environment.getProperty("idm_connection_factory"),
						environment.getProperty("idm_starti_username"), environment.getProperty("idm_starti"));
			}
		}

		JSONArray listOfDel = JsonPath.read(runTimeData, "$.testFlowData.deliveryDetails[*]");
		List<DeliveryDetail> listOfDeliveries = (List<DeliveryDetail>) jsonUtils
				.getPojoListfromPath(listOfDel.toJSONString(), DeliveryDetail.class);

		DeliveryDetail deliveryDetail = new DeliveryDetail();
		deliveryDetail.setDeliveryNumber(deliveryNumber);
		deliveryDetail.setDoorType(DOOR_TYPE);
		deliveryDetail.setPoNumbers(poNumbers);
		deliveryDetail.setDeliveryName(delvryName);
		deliveryDetail.setDeliveryStatus(status);
		deliveryDetail.setInboundLoadNumber(loadNum);

		for (int j = 0; j < listOfDeliveries.size(); j++) {
			DeliveryDetail delDtl = listOfDeliveries.get(j);
			if ((status.contains("C")) && delDtl.getDeliveryName().toString().contentEquals(delvryName)) {
				logger.info("del name :{}", listOfDeliveries.get(j).getDeliveryName().toString());
				listOfDeliveries.remove(j);
				break;
			}

		}
		listOfDeliveries.add(deliveryDetail);

		JSONArray deliveryDetailsList = jsonUtils.converyListToJsonArray(listOfDeliveries);

		JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
		String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), deliveryDetailsList,
				"$.testFlowData.deliveryDetails");
		tl.get().put(TEST_FLOW_DATA, testFlowData);
		logger.info("testFlowData after updating delivery details:{}", testFlowData);
	}
	
	public void createDeliveryScheduler2(int qtyPercentage, String eventType, String delvryName, String loadNumber) throws URISyntaxException, IOException, ParseException, InterruptedException {
		createDeliveryScheduler2(qtyPercentage, eventType, delvryName, loadNumber, null);
	}

	public void createDeliveryScheduler2(int qtyPercentage, String eventType, String delvryName, String loadNumber, String deliveryNumber)
			throws URISyntaxException, IOException, ParseException, InterruptedException {
		/*       Will delete it later  */
		
//		tl.get().put(TEST_FLOW_DATA,
//				"{\"testFlowData\": {\"poDetails\": [{\"poNumber\": \"0412367917\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"9316739\", \"poVnpkQty\": \"100\", \"vnpk\": \"1\", \"whpk\": \"1\", \"whpkSellPrice\": \"13.9000\", \"ti\": \"10\", \"hi\": \"10\", \"itemUpc\": \"00207718000005\", \"caseUpc\": \"00000000838757\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"ovgQty\": \"58\", \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10018\", \"isMergeable\": true, \"weight\": \"17.7007334\", \"height\": \"6.417322834645669\", \"width\": \"10.590551181102363\", \"depth\": \"17.007874015748033\", \"warehouseGroupCode\": \"M\", \"warehouseAreaCode\": \"1\", \"acceptableTemperatureHigh\": \"32.0\", \"temperatureUOM\": \"FA\", \"samePalletIndicator\": \"1\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"mergeable\": true, \"acceptableTemperatureLow\": \"0.0\", \"receiveDate\": \"2020-06-01\", \"overageFlag\": false, \"warehouseMinLifeRemainingToReceive\": \"45\", \"isVariableWeight\": false } }, {\"poLineNumber\": \"2\", \"itemNumber\": \"567162075\", \"poVnpkQty\": \"100\", \"vnpk\": \"1\", \"whpk\": \"1\", \"whpkSellPrice\": \"13.9000\", \"ti\": \"10\", \"hi\": \"10\", \"itemUpc\": \"00655778358244\", \"caseUpc\": \"10655778358241\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"ovgQty\": \"58\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10018\", \"isMergeable\": true, \"weight\": \"17.7007334\", \"height\": \"6.417322834645669\", \"width\": \"10.590551181102363\", \"depth\": \"17.007874015748033\", \"warehouseGroupCode\": \"F\", \"warehouseAreaCode\": \"4\", \"acceptableTemperatureHigh\": \"32.0\", \"temperatureUOM\": \"FA\", \"samePalletIndicator\": \"1\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"OPM\", \"mergeable\": true, \"acceptableTemperatureLow\": \"0.0\", \"receiveDate\": \"2020-06-01\", \"overageFlag\": false, \"warehouseMinLifeRemainingToReceive\": \"180\", \"isVariableWeight\": false } }, {\"poLineNumber\": \"3\", \"itemNumber\": \"567162076\", \"poVnpkQty\": \"100\", \"vnpk\": \"1\", \"whpk\": \"1\", \"whpkSellPrice\": \"13.9000\", \"ti\": \"10\", \"hi\": \"10\", \"itemUpc\": \"00655778358251\", \"caseUpc\": \"10655778358258\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"ovgQty\": \"58\", \"overageFlag\": false, \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10018\", \"isMergeable\": true, \"weight\": \"17.7007334\", \"height\": \"6.417322834645669\", \"width\": \"10.590551181102363\", \"depth\": \"17.007874015748033\", \"warehouseGroupCode\": \"F\", \"warehouseAreaCode\": \"4\", \"acceptableTemperatureHigh\": \"32.0\", \"temperatureUOM\": \"FA\", \"samePalletIndicator\": \"1\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"OPM\", \"mergeable\": true, \"acceptableTemperatureLow\": \"0.0\", \"receiveDate\": \"2020-06-01\", \"warehouseMinLifeRemainingToReceive\": \"180\", \"isVariableWeight\": false } } ], \"uuid\": [] } ], \"ordersDetails\": [], \"deliveryDetails\": [], \"outboundDetails\": [], \"problemDetails\": [], \"containerDetails\": [], \"releaseDetails\": [] } }");

//		preRunCleanup.cleanupReceivingAtlas();
//		preRunCleanup.cleanUpWitronInventory();		
		String runTimeData;
		String baseDeliveryMssg;
		String deliveryStatus;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> poNumbers = JsonPath.parse(runTimeData).read(PO_NUMBER_JSONPATH);
		List<String> poName = JsonPath.parse(runTimeData).read(PO_NAME);
		String loadNum = "11223344";
		if (eventType.equalsIgnoreCase("CANCEL_DELIVERY")) {
			JSONArray delNum = JsonPath.read(runTimeData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");
			deliveryNumber = (String) delNum.get(0);
			deliveryStatus="Cancelled";
		} else {
			if (deliveryNumber==null) {
				if(Config.DC==DC_TYPE.RDC) {
					if(!poName.get(0).equals("asn")) {
					deliveryNumber=environment.getProperty(poNumbers.get(0));
					}
					else {
						deliveryNumber = Integer.toString(javaUtils.randonNumberGenerator(8));
						loadNum = String.valueOf(javaUtils.randonNumberGenerator(8));
					}
				}
				else {
				deliveryNumber = Integer.toString(javaUtils.randonNumberGenerator(8));
				}
			}
			deliveryStatus="Scheduled";
		}
		logger.info("RunTimeData:{}", runTimeData);
//		List<String> poNumbers = JsonPath.parse(runTimeData).read(PO_NUMBER_JSONPATH);
		int poQty = 0;
		
		String trailerNumber="";
		JSONArray qtyArray;
		JSONArray ovgFlag;
		JSONArray ovgQty;
		
		if (loadNumber!=null) {
			loadNum = loadNumber;
		}
		
		for (int i = 0; i < poNumbers.size(); i++) {
			

			if(Config.DC==DC_TYPE.RDC) {
				baseDeliveryMssg = textParser.readTextFile(FileNames.RDC_CREATE_DELIVERY_SCHEDULER2_MESSAGE);
			}
			else {
			baseDeliveryMssg = textParser.readTextFile(FileNames.CREATE_DELIVERY_SCHEDULER2_MESSAGE);
			}
			String addPoList = "";
			String updatePoList = "";
			String removePoList = "";
			String cancelPoList = "";

			if (i != 0) {
				eventType = "UPDATE_DELIVERY";
			}

			if (eventType.equalsIgnoreCase("UPDATE_DELIVERY")) {
				addPoList = "\"" + poNumbers.get(i) + "\"";
			} else if (eventType.equalsIgnoreCase("CANCEL_DELIVERY")) {
				cancelPoList = "\"" + poNumbers.get(i) + "\"";
			}

			poQty = 0;
			qtyArray = JsonPath.parse(runTimeData).read(
					"$.testFlowData.poDetails[?(@.poNumber=='" + poNumbers.get(i) + "')].poLineDetails..poVnpkQty");
			ovgFlag = JsonPath.parse(runTimeData).read(
					"$.testFlowData.poDetails[?(@.poNumber=='" + poNumbers.get(i) + "')].poLineDetails..overageFlag");
			ovgQty = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[?(@.poNumber=='" + poNumbers.get(i) + "')].poLineDetails..ovgQty");
			for (int k = 0; k < qtyArray.size(); k++) {

				poQty = poQty + Integer.parseInt((String) qtyArray.get(k));
			}
			logger.info("Total PO Qty:{}", poQty);
			logger.info("Percentage of po qty to be added in delivery:{}", qtyPercentage);
			poQty = poQty * qtyPercentage / 100;
			logger.info("Total PO Qty to be created in this delivery:{}", poQty);
			String dcNumber = environment.getProperty("facility_num");
			logger.info("Site Id:{} ", dcNumber);

//			if (Config.DC==DC_TYPE.SAMS) {
				trailerNumber="TL"+deliveryNumber;
//			}
			String deliveryMessage = javaUtils.format(baseDeliveryMssg, eventType.toUpperCase(), deliveryNumber, dcNumber, loadNum,
					poNumbers.get(i), String.valueOf(poQty), addPoList, updatePoList, removePoList, cancelPoList,
					javaUtils.getCurrentDate(), javaUtils.getCurrentDateAndTime(), trailerNumber, deliveryStatus);
			logger.info("deliveryMessage:{} ", deliveryMessage);

			// publishDeliveryMessageToTopic(deliveryMessage); -- Currently publishing to
			// Maas queue
			logger.info("Publishing Delivery Message");
			if(Config.DC!=DC_TYPE.WITRON && Config.DC!=DC_TYPE.ATLAS && Config.DC!=DC_TYPE.ACC && Config.DC!=DC_TYPE.PHARMACY && Config.DC!=DC_TYPE.CATALYST&&Config.DC!=DC_TYPE.RDC) {
			synchronized (stratiConnectionUtil) {
				if(Config.DC==DC_TYPE.SAMS&&Config.ENV==ENVIRONMENT.PROD&&!Config.isPipeline) {
					Response resp = SerenityRest.given().relaxedHTTPSValidation().headers(getIDMHeaders(eventType)).body(deliveryMessage).post(environment.getProperty("gdm_delivery_create_ep"));
					logger.info("Delivery Creation response code:{} for eventType:{}",resp.getStatusCode(),eventType);
				}else {
					stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_schedular_queue"),
							deliveryMessage, QUEUE, environment.getProperty("idm_connection_factory"),
							environment.getProperty("idm_starti_username"), environment.getProperty("idm_starti"),
							eventType.toUpperCase());
				}
			}
		}
			else {
				synchronized (stratiConnectionUtil) {
					schedulerConnectionUtil.publishCreateDeliveryMessage(
							environment.getProperty("maas_schedular_queue"), deliveryMessage, QUEUE,
							eventType.toUpperCase());

				}
			}
			Thread.sleep(5000);
		}

		JSONArray listOfDel = JsonPath.read(runTimeData, "$.testFlowData.deliveryDetails[*]");
		List<DeliveryDetail> listOfDeliveries = (List<DeliveryDetail>) jsonUtils
				.getPojoListfromPath(listOfDel.toJSONString(), DeliveryDetail.class);

		DeliveryDetail deliveryDetail = new DeliveryDetail();
		deliveryDetail.setDeliveryNumber(deliveryNumber);
		deliveryDetail.setDoorType(DOOR_TYPE);
		deliveryDetail.setPoNumbers(poNumbers);
		deliveryDetail.setDeliveryName(delvryName);
		deliveryDetail.setDeliveryStatus(eventType);
		deliveryDetail.setInboundLoadNumber(loadNum);
		if (Config.DC == DC_TYPE.SAMS) {
			deliveryDetail.setInboundTrailerNumber(trailerNumber);
		}

		for (int j = 0; j < listOfDeliveries.size(); j++) {
			DeliveryDetail delDtl = listOfDeliveries.get(j);
			if ((eventType.contains("CANCEL_DELIVERY"))
					&& delDtl.getDeliveryName().toString().contentEquals(delvryName)) {
				logger.info("del name :{}", listOfDeliveries.get(j).getDeliveryName().toString());
				listOfDeliveries.remove(j);
				break;
			}

		}
		listOfDeliveries.add(deliveryDetail);

		JSONArray deliveryDetailsList = jsonUtils.converyListToJsonArray(listOfDeliveries);

		JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
		String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), deliveryDetailsList,
				"$.testFlowData.deliveryDetails");
		tl.get().put(TEST_FLOW_DATA, testFlowData);
		logger.info("testFlowData after updating delivery details:{}", testFlowData);
	}

	public void createDeliveryScheduler2RDC(int qtyPercentage, String eventType, String delvryName, String loadNumber, String deliveryNumber, String deliveryForRDCReceivignType)
			throws URISyntaxException, IOException, ParseException, InterruptedException {
		String runTimeData;
		String baseDeliveryMssg;
		String deliveryStatus;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		if (eventType.equalsIgnoreCase("CANCEL_DELIVERY")) {
			JSONArray delNum = JsonPath.read(runTimeData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");
			deliveryNumber = (String) delNum.get(0);
			deliveryStatus="Cancelled";
		} else {
			if (deliveryNumber==null) {
				deliveryNumber = Integer.toString(javaUtils.randonNumberGenerator(8));
			}
			deliveryStatus="Scheduled";
		}
		logger.info("RunTimeData:{}", runTimeData);
		List<String> poNumbers = new LinkedList<String>();
		if (deliveryForRDCReceivignType!=null) {
			if (deliveryForRDCReceivignType.equalsIgnoreCase("OFFLINE_RECEIVE")) {
				poNumbers.add("9999999999");
			}
		}
		else {
			List<String> poNumbersList=JsonPath.parse(runTimeData).read(PO_NUMBER_JSONPATH);
			poNumbers.addAll(poNumbersList);
		}
		int poQty = 0;
		String loadNum = "11223344";
		String trailerNumber="";
		JSONArray qtyArray;
		JSONArray ovgFlag;
		JSONArray ovgQty;
		
		if (loadNumber!=null) {
			loadNum = loadNumber;
		}
		
		for (int i = 0; i < poNumbers.size(); i++) {

			baseDeliveryMssg = textParser.readTextFile(FileNames.CREATE_DELIVERY_SCHEDULER2_MESSAGE);
			String addPoList = "";
			String updatePoList = "";
			String removePoList = "";
			String cancelPoList = "";

			if (i != 0) {
				eventType = "UPDATE_DELIVERY";
			}

			if (eventType.equalsIgnoreCase("UPDATE_DELIVERY")) {
				addPoList = "\"" + poNumbers.get(i) + "\"";
			} else if (eventType.equalsIgnoreCase("CANCEL_DELIVERY")) {
				cancelPoList = "\"" + poNumbers.get(i) + "\"";
			}

			poQty = 0;
			qtyArray = JsonPath.parse(runTimeData).read(
					"$.testFlowData.poDetails[?(@.poNumber=='" + poNumbers.get(i) + "')].poLineDetails..poVnpkQty");
			ovgFlag = JsonPath.parse(runTimeData).read(
					"$.testFlowData.poDetails[?(@.poNumber=='" + poNumbers.get(i) + "')].poLineDetails..overageFlag");
			ovgQty = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[?(@.poNumber=='" + poNumbers.get(i) + "')].poLineDetails..ovgQty");
			for (int k = 0; k < qtyArray.size(); k++) {

				poQty = poQty + Integer.parseInt((String) qtyArray.get(k));
			}
			logger.info("Total PO Qty:{}", poQty);
			logger.info("Percentage of po qty to be added in delivery:{}", qtyPercentage);
			poQty = poQty * qtyPercentage / 100;
			logger.info("Total PO Qty to be created in this delivery:{}", poQty);
			String dcNumber = environment.getProperty("facility_num");
			logger.info("Site Id:{} ", dcNumber);

			String deliveryMessage = javaUtils.format(baseDeliveryMssg, eventType.toUpperCase(), deliveryNumber, dcNumber, loadNum,
					poNumbers.get(i), String.valueOf(poQty), addPoList, updatePoList, removePoList, cancelPoList,
					javaUtils.getCurrentDate(), javaUtils.getCurrentDateAndTime(), trailerNumber, deliveryStatus);
			logger.info("deliveryMessage:{} ", deliveryMessage);

			// publishDeliveryMessageToTopic(deliveryMessage); -- Currently publishing to
			// Maas queue
			logger.info("Publishing Delivery Message");
			Map<String, Object> hm = new HashMap<>();
			hm.put("facilityNum", environment.getProperty("facility_num"));
			hm.put("facilityCountryCode", environment.getProperty("country_code").toUpperCase());
			hm.put("eventType", eventType.toUpperCase());
			try {
				springJmsUtils.sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ,
						Config.DC, schedularQueue_RDC, deliveryMessage, hm);
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Thread.sleep(5000);
		}

		JSONArray listOfDel = JsonPath.read(runTimeData, "$.testFlowData.deliveryDetailsRDC[*]");
		List<DeliveryDetailsRDC> listOfDeliveries = (List<DeliveryDetailsRDC>) jsonUtils
				.getPojoListfromPath(listOfDel.toJSONString(), DeliveryDetailsRDC.class);
		
		if (Config.DC==DC_TYPE.RDC) {
			DeliveryDetail deliveryDetail = new DeliveryDetail();
		}
		else {
			
		}
		DeliveryDetailsRDC deliveryDetailRDC = new DeliveryDetailsRDC();
		deliveryDetailRDC.setDeliveryNumber(deliveryNumber);
		deliveryDetailRDC.setPoNumbers(poNumbers);
		deliveryDetailRDC.setDeliveryName(delvryName);
		deliveryDetailRDC.setDeliveryStatus(eventType);

		for (int j = 0; j < listOfDeliveries.size(); j++) {
			DeliveryDetailsRDC delDtl = listOfDeliveries.get(j);
			if ((eventType.contains("CANCEL_DELIVERY"))
					&& delDtl.getDeliveryName().toString().contentEquals(delvryName)) {
				logger.info("del name :{}", listOfDeliveries.get(j).getDeliveryName().toString());
				listOfDeliveries.remove(j);
				break;
			}

		}
		listOfDeliveries.add(deliveryDetailRDC);

		JSONArray deliveryDetailsList = jsonUtils.converyListToJsonArray(listOfDeliveries);

		JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
		String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), deliveryDetailsList,
				"$.testFlowData.deliveryDetailsRDC");
		tl.get().put(TEST_FLOW_DATA, testFlowData);
		
		logger.info("testFlowData after updating delivery details:{}", testFlowData);
	}

	public void createDeliveryRDC() throws URISyntaxException, IOException, ParseException {
		String runTimeData;
		String deliveryNumber;
		String delMesgFormat = textParser.readTextFile(FileNames.DELIVERY_MESSAGE_FILE);

		int poQty = 0;
		String poNumber = "9999999999";
		String stringSplitData[] = delMesgFormat.split("\\$");
		runTimeData = (String) tl.get().get("testFlowData");
		String dcNumber = environment.getProperty("rdc_facility_num");
		logger.info("Site Id:{} ", dcNumber);

		logger.info("RunTimeData:{}", runTimeData);
		List<String> loadIDList = JsonPath.parse(runTimeData).read(wtmsLoadIdJsonPath);
		if (loadIDList.isEmpty()) {
			throw new AutomationFailure("WTMS Load list is empty");
		}
		for (String loadNum : loadIDList) {
			deliveryNumber = Integer.toString(javaUtils.randonNumberGenerator(8));

			String deliveryMessage = stringSplitData[0] + deliveryNumber + stringSplitData[1] + loadNum
					+ stringSplitData[2] + dcNumber + stringSplitData[3] + poNumber + stringSplitData[4] + poQty
					+ stringSplitData[5] + "" + stringSplitData[6];

			logger.info(deliveryMessage);

			publishDeliveryMessage("RDC", deliveryMessage);

			RDCDeliveryDetail rdcDelievryDetail = new RDCDeliveryDetail();
			rdcDelievryDetail.setDeliveryNumber(deliveryNumber);

			OutboundDetail obdDetails = new OutboundDetail();
			obdDetails.setRdcDelievryDetails(rdcDelievryDetail);

			JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
			String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), rdcDelievryDetail,
					"$.testFlowData.outboundDetails[?(@.tmsLoadId == '" + loadNum + "')].rdcDeliveryDetail");
			tl.get().put("testFlowData", testFlowData);
			runTimeData = (String) tl.get().get("testFlowData");
			logger.info(runTimeData);
		}
	}

	public void createDeliveryRDCS2S() throws URISyntaxException, IOException, ParseException {
		String runTimeData;
		String deliveryNumber;
		String delMesgFormat = textParser.readTextFile(FileNames.DELIVERY_MESSAGE_FILE);

		int poQty = 0;
		String poNumber = "9999999989";
		String stringSplitData[] = delMesgFormat.split("\\$");
		runTimeData = (String) tl.get().get("testFlowData");
		String dcNumber = environment.getProperty("rdc_facility_num");
		logger.info("Site Id:{} ", dcNumber);

		logger.info("RunTimeData:{}", runTimeData);
		List<String> bolList = JsonPath.parse(runTimeData).read(BOL_JSON_PATH);
		if (bolList.isEmpty()) {
			throw new AutomationFailure("BOL list is empty");
		}
		for (String bol : bolList) {
			deliveryNumber = Integer.toString(javaUtils.randonNumberGenerator(8));

			String deliveryMessage = stringSplitData[0] + deliveryNumber + stringSplitData[1] + 0 + stringSplitData[2]
					+ dcNumber + stringSplitData[3] + poNumber + stringSplitData[4] + poQty + stringSplitData[5] + bol
					+ stringSplitData[6];

			logger.info(deliveryMessage);

			publishDeliveryMessage("RDC", deliveryMessage);

			JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
			String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), deliveryNumber,
					RDC_DELIVERYDETAILS_PATH_S2S);
			tl.get().put("testFlowData", testFlowData);
			runTimeData = (String) tl.get().get("testFlowData");
			logger.info(runTimeData);
		}
	}

	public void publishDeliveryMessage(String dcType, String delMessage) {

		logger.info("Starting jms publisher...");

		if (dcType.equalsIgnoreCase("MCC") || dcType.equalsIgnoreCase("ACC")) {
			springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ, Config.DC,
					schedularQueue_MCC, delMessage);
		}
		if (dcType.equalsIgnoreCase("RDC")) {
			springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ, Config.DC,
					schedularQueue_RDC, delMessage);
		}

		logger.info("Published Delievery message to the Queue");

	}

	public String getDoorNumber() {
		try {
			String runTimeData;
			runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			if (runTimeData != null) {
				inboundDoorNumber = JsonPath.parse(runTimeData).read(INBOUND_DOOR_JSONPATH);
				return inboundDoorNumber;
			}
		} catch (PathNotFoundException e) {
			logger.info("Door is not yet assigned in Inbound");
		}
		return "";
	}

	public int getDeliveryTotalReceivedQty(String poNumber) {
		String runTimeData;
		int totalReceivedQty = 0;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONArray receivedQtyArray = null;

		if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.SAMS) {
			receivedQtyArray = JsonPath.parse(runTimeData).read(javaUtils.format(RECEIVED_QTY_JSONPATH, poNumber));
		} else if(Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.PHARMACY) {
			receivedQtyArray = JsonPath.parse(runTimeData).read(javaUtils.format(RECEIVED_QTY_JSONPATH_WITRON, poNumber));

		}else {
		
			receivedQtyArray = JsonPath.parse(runTimeData).read(javaUtils.format(RECEIVED_QTY_JSONPATH_ACC, poNumber));
		}

		for (int recdQty = 0; recdQty < receivedQtyArray.size(); recdQty++) {
			if(Config.DC == DC_TYPE.PHARMACY) {
				totalReceivedQty += (int) Math.ceil(Double.parseDouble(receivedQtyArray.get(recdQty).toString()));
			} else {
				totalReceivedQty += Integer.parseInt(receivedQtyArray.get(recdQty).toString());
			}
		}
		logger.info("Total received Quantity by receiever for this delivery is : {}", totalReceivedQty);
		return totalReceivedQty;
	}

	public String getDeliveryNumber() {
		return getDeliveryNumber(0);
	}

	public String getDeliveryNumber(int index) {
		JSONArray deliveryNumbers = JsonPath.read(String.valueOf(tl.get().get(TEST_FLOW_DATA)),
				"$.testFlowData.deliveryDetails[*].deliveryNumber");
		return (String) deliveryNumbers.get(index);
	}

	public void deleteDelivery() {
		List<String> deliveryNumbers = JsonPath.read(String.valueOf(tl.get().get(TEST_FLOW_DATA)),
				"$.testFlowData.deliveryDetails[*].deliveryNumber");
		for (String deliveryNumber : deliveryNumbers) {
			deleteDelivery(deliveryNumber);
		}
	}

	public void deleteDelivery(String del) {
		Response response;

		String deleteUrl = MessageFormat.format(environment.getProperty("idm_delivery_delete"), del);
		logger.info("Delivery deletion url:{}", deleteUrl);
		response = SerenityRest.given().relaxedHTTPSValidation().headers(getIDMHeaders()).delete(deleteUrl);
		response.then().statusCode(Constants.SUCESS_STATUS_CODE);
		logger.info("Successfully deleted the Delivery from GDM:{}", del);
	}

	public void validateoverrage() throws InterruptedException {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> itemNumbersArray = JsonPath.parse(runTimeData).read(ITEM_NR_DELIVERY_JSONPATH);
		Thread.sleep(20000);
		for (String itemNumber : itemNumbersArray) {
			Failsafe.with(retryPolicy).run(() -> {
				Response delResponse = idmSteps.getDeliveryResponse("D1");
				
				JSONArray overageQtyArray = JsonPath.parse(runTimeData)
						.read("$..poLineDetails[?(@.itemNumber==" + itemNumber + ")].ovgQty");
				int overrageQtyTestData = Integer.parseInt(overageQtyArray.get(0).toString());
				logger.info("The overrage for itemNumber:{} in testFlowData is :{}", itemNumber, overrageQtyTestData);
				JSONArray overageIDMQtyArray = null;
				if (Config.DC == DC_TYPE.ATLAS ) {
					overageIDMQtyArray = JsonPath.read(delResponse.asString(),
							"$..deliveryDocumentLines[?(@.itemNbr==" + itemNumber + ")].overageQtyLimit");
				} else {
					overageIDMQtyArray = JsonPath.read(delResponse.asString(),
							"$..deliveryDocumentLines[?(@.itemNbr==" + itemNumber + ")].overageThresholdQty");
				}
						
				Assert.assertNotEquals(ErrorCodes.IDM_OVG_FLAG_NOT_FOUND, 0, overageIDMQtyArray.size());
				int overrageQtyIdm = (int) overageIDMQtyArray.get(0);
				
				// Assert.assertEquals(ErrorCodes.IDM_OVG_QTY_NOT_MATCHING,overrageQtyTestData,overrageQtyIdm);
				logger.info("Validated the overage Quantity in IDM");
			});
		}

	}

	public JSONArray getRDCDelieveries() {
		String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		return JsonPath.parse(runTimeData).read(RDC_DELIVERY_JSONPATH);
	}

	public boolean validateRDCDeliveries(String deliveryNumber, Response response) {
		String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		;
		logger.info("Validating containers in IDM for delivery:{} at RDC", deliveryNumber);
		
		//FOR Mocked ASN
		List<String> containersLoadedArray = JsonPath.parse(runTimeData).read(
				"$.testFlowData.deliveryDetailsRDC[?(@.deliveryNumber=='"+deliveryNumber+"')].containersOnShipment[*]");
			
		//FOR E2E from MCC/ACC
//		List<String> containersLoadedArray = JsonPath.parse(runTimeData).read(
//				"$..outboundDetails[?(@.rdcDeliveryDetail.deliveryNumber==" + deliveryNumber + ")].containerIds[*]");
		List<String> containersDeliveryArray = JsonPath.read(response.asString(), "$..containerLabels[*]");
		if ((containersLoadedArray.size() != containersDeliveryArray.size())) {
			logger.info("Mismatch in contianer count in the delivery:{} at RDC", deliveryNumber);
			logger.info("Number of containers loaded:{}", containersLoadedArray.size());
			logger.info("Number of containers in delivery:{}", containersDeliveryArray.size());
			return false;

		}

		else {
			for (String container : containersLoadedArray) {
				if (!containersDeliveryArray.contains(container)) {
					logger.info("Mismatch in containers in the delivery:{} at RDC", deliveryNumber);
					logger.info("Container {} is not present in Delivery response", container);
					return false;
				}
			}
			return true;

		}

	}

	public int getReceivedQtyOfVTRContainer() {
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		JSONArray receivingInstructReceivedQtyjsonArray = JsonPath.read(testFlowData, receivingInstructionReceivedQty);
		int totalReceivedQtyOfVTRContainer = 0;
		if (receivingInstructReceivedQtyjsonArray.isEmpty())
			return 0;
		else {
			for (int receivingInstructCount = 0; receivingInstructCount < receivingInstructReceivedQtyjsonArray
					.size(); receivingInstructCount++) {
				totalReceivedQtyOfVTRContainer += Integer
						.parseInt(receivingInstructReceivedQtyjsonArray.get(receivingInstructCount).toString());
			}
			logger.info("Total received Quantity of VTR Conatiner is : {}", totalReceivedQtyOfVTRContainer);

			return totalReceivedQtyOfVTRContainer;
		}
	}

	public Headers getIDMHeaders() {

		return getIDMHeaders(null); 

	}
	public Headers getIDMHeaders(String eventType) {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		Header appType = new Header("Content-Type", "application/json");

		
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);

		if(eventType!=null) {
			Header eventTypeHeader = new Header("eventType", eventType.toUpperCase());
			headerList.add(eventTypeHeader);
		}
		if (Config.DC == DC_TYPE.WITRON) {
			Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
			headerList.add(contentType);
		}
		return new Headers(headerList);
	}

	public Headers getIDMLithiumIonHeaders() {
		Header contentType = new Header("Content-Type", "application/vnd.UpdateItemVerifiedOn1+json");
		Header acceptType = new Header("accept", "application/json");
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		logger.info("Headers\n" + contentType + ", " + countryCode + ", " + facilityNum + ", " + userId+ ", " + acceptType);
		List<Header> headerList = new ArrayList<>();
		headerList.add(acceptType);
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		return new Headers(headerList);
	}
	
	
	private void publishDeliveryMessageToTopic(String deliveryMessage) {

		logger.info("Starting jms publisher for Schedular Topic...");
		springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ, Config.DC, schedularTopic,
				deliveryMessage);
		logger.info("Published Delievery message to the Topic");

	}

	public void validateDelivery(Response response) {
		String runTimeData;
		JSONArray delDocuments = JsonPath.read(response.asString(), "$.deliveryDocuments");
		Assert.assertEquals(ErrorCodes.IDM_DELIVERY_DOCUMENTS_EMPTY, false, delDocuments.isEmpty());
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> poNumbers = JsonPath.parse(runTimeData).read(PO_NUMBER_JSONPATH);
		logger.info("Number of PO's present in delivery inside validateDelivery method:: " + delDocuments.size());
		Assert.assertEquals(ErrorCodes.IDM_DELIVERY_PO_COUNT_MISMATCH, poNumbers.size(), delDocuments.size());
		/*
		 * JSONArray isConveyableField=
		 * JsonPath.parse(runTimeData).read(TESTDATA_ISCONVEYABLE_JSONPAH); JSONArray
		 * delDocumentLines
		 * =JsonPath.read(response.asString(),DELIVERY_ISCONVEYABLE_JSONPAH);
		 * if(!isConveyableField.isEmpty())
		 * Assert.assertEquals(ErrorCodes.IDM_DELIVERY_ISCONVEYABLE_FIELD_MISMATCH,
		 * isConveyableField.get(0), delDocumentLines.get(0).toString());
		 */

	}

	public void createDeliveryUsingRest() {
		String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> poNumbers = JsonPath.parse(runTimeData).read(PO_NUMBER_JSONPATH);
		for (String poNumber : poNumbers) {
			String url = "https://global-delivery-manager-core-test.prod.us.walmart.net/test/" + getDeliveryNumber()
					+ "/" + poNumber + "/7/8/3/5";
			logger.info("rest url for delivery creation{}", url);
			Response response = SerenityRest.given().relaxedHTTPSValidation().get(url);
			logger.info("response for rest url:{}", response.getStatusCode());
		}
	}

	public boolean validateShortage(Response response) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		int receivedQtyFromTestFlowData = Integer.parseInt(JsonPath.read(runTimeData,
				"$.testFlowData.poDetails[0].poLineDetails[0].receivingInstructions[0].receivedQuantity"));
		int poVnpkQtyTestflowData = Integer
				.parseInt(JsonPath.read(runTimeData, "$.testFlowData.poDetails[0].poLineDetails[0].poVnpkQty"));
		int shortageFromReceipts = JsonPath.read(response.asString(), "$.pos[0].shortQty");
		return shortageFromReceipts == (poVnpkQtyTestflowData - receivedQtyFromTestFlowData);
	}
	
	public boolean validateOverage(int receivedQtyFromTestFlowData, Response response) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		int damageQtyTestflowData = Integer
				.parseInt(JsonPath.read(runTimeData, "$.testFlowData.poDetails[0].poLineDetails[0].damageQty"));
		int poVnpkQtyTestflowData = Integer
				.parseInt(JsonPath.read(runTimeData, "$.testFlowData.poDetails[0].poLineDetails[0].poVnpkQty"));
		int overageFromReceipts = JsonPath.read(response.asString(), "$.pos[0].overageQty");
		return overageFromReceipts == ((receivedQtyFromTestFlowData+damageQtyTestflowData) - poVnpkQtyTestflowData);
	}
	
	public boolean validateDamage(Response response) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		int damageQtyTestflowData = Integer
				.parseInt(JsonPath.read(runTimeData, "$.testFlowData.poDetails[0].poLineDetails[0].damageQty"));
		int damageFromReceipts = JsonPath.read(response.asString(), "$.pos[0].damageQty");
		return damageFromReceipts == damageQtyTestflowData;
	}
	
	public boolean validateShortage(Response response, String poNum) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		
		DocumentContext parsedItemDetailsJson = JsonPath.parse(runTimeData);

		int recvQty=0;
		List<String> receiveQty = parsedItemDetailsJson
				.read("$.testFlowData.poDetails[?(@.poNumber == '"+poNum+"')].poLineDetails[*].receivingInstructions[*].receivedQuantity");
		
		for(String recqty:receiveQty) {
			recvQty+=Integer.parseInt(recqty);
		}
		
		int orderQty=0;
		List<String> orderQuantity = parsedItemDetailsJson
				.read("$.testFlowData.poDetails[?(@.poNumber == '"+poNum+"')].poLineDetails[*].poVnpkQty");
		
		for(String ordqty:orderQuantity) {
			orderQty+=Integer.parseInt(ordqty);
		}
		
		int shortageFromReceipts = JsonPath.read(response.asString(), "$.pos[?(@.poNumber == '"+poNum+"')].shortQty");
		return shortageFromReceipts == (orderQty - recvQty);
	}

	public void poLineAdd(String itmNum, String caseUPC) {

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));

		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		String delNumber = deliveryNumberList.get(0);
		List<String> poNumberList = parsedJson.read("$..poDetails[*].poNumber");
		String poNum = poNumberList.get(0);

		String fileData = "";

		try {
			fileData = textParser.readTextFile(FileNames.ATLAS_PO_LINE_ADD_FILE);
			logger.info("po line payload " + fileData);

			JSONObject poLineObj = jsonUtils.convertStringToMinidevJsonObject(fileData);

			logger.info("po line Object " + poLineObj);

			//poLineObj.put("deliveryNumber", delNumber);
			poLineObj.put("purchaseReferenceNumber", poNum);

			JSONObject itmLine = (JSONObject) poLineObj.get("line");

			JSONObject itemObj = (JSONObject) itmLine.get("item");

			itemObj.put("number", itmNum);
			itemObj.put("caseUPC", caseUPC);

			poLineObj.put("line", itmLine);
			
			String poLineAddResourceUrl= poNum + "/lines/"  +  itmLine.getAsString("purchaseLineNumber");
			logger.info("po line resourceUrl " + poLineAddResourceUrl);

			logger.info("po line payload " + poLineObj.toJSONString());
			Failsafe.with(retryPolicy).run(() -> {
				Response res;

				logger.info("payload link from file " + environment.getProperty("po_line_add")+poLineAddResourceUrl);
				res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
						.contentType("application/json").headers(getIDMHeaders()).body(poLineObj.toJSONString()).when()
						.post(environment.getProperty("po_line_add")+poLineAddResourceUrl);

				logger.info("response " + res.statusCode());

				Assert.assertEquals(ErrorCodes.PO_LINE_ADD_RESPONSE, Constants.SUCESS_STATUS_CODE, res.getStatusCode());

			});
			
			//Adding delay since intermittently adding PO Line takes time on GDM side
			Thread.sleep(8000);

			Response delvryResponse = given().relaxedHTTPSValidation().headers(getIDMHeaders()).when()
					.get(environment.getProperty("idm_delivery_ep") + delNumber);
			Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					delvryResponse.getStatusCode());
			logger.info("Validating IDM response for POLine Add " + delvryResponse.getBody().asString());
			
			List<String> arr = JsonPath.parse(delvryResponse.getBody().asString())
					.read("$.deliveryDocuments[?(@.deliveryNumber=='" + delNumber + "')].deliveryDocumentLines[*]");
			JSONArray dlvryResponsePoLineChk = jsonUtils.converyListToJsonArray(arr);
			logger.info("Arr size= " + dlvryResponsePoLineChk.size());
			int count = 0;
			for (int i = 0; i < dlvryResponsePoLineChk.size(); i++) {
				JSONObject obj = (JSONObject) dlvryResponsePoLineChk.get(i);
				String ItemNumber = String.valueOf(obj.get("itemNbr"));
				logger.info("item num= " + ItemNumber);

				if (ItemNumber.contains(itmNum)) {
					logger.info("Po Line Added Successdully ");
					count++;
					break;
				}

			}
			if (count == 0)
				Assert.fail(ErrorCodes.PO_LINE_ADD_FAILED);

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while attaching po line to delivery", e);
		}

	}

	public void poLineUpdate(String itmNum) {

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		String delNumber = deliveryNumberList.get(0);
		List<String> poNumberList = parsedJson.read("$..poDetails[*].poNumber");
		String poNum = poNumberList.get(0);
		List<String> poLineNumberList = parsedJson.read("$..poLineDetails[*].poLineNumber");
		int poLineNumber = Integer.valueOf(poLineNumberList.get(0));

		String fileData = "";

		try {
			fileData = textParser.readTextFile(FileNames.ATLAS_PO_LINE_UPDATE);
			logger.info("po line payload " + fileData);

			JSONObject poLineObj = jsonUtils.convertStringToMinidevJsonObject(fileData);

			logger.info("po line Object " + poLineObj);

//			poLineObj.put("deliveryNumber", delNumber);
			poLineObj.put("purchaseReferenceNumber", poNum);
			poLineObj.put("purchaseLineNumber", poLineNumber);

			logger.info("po line payload " + poLineObj.toJSONString());
			Failsafe.with(retryPolicy).run(() -> {
				Response res;
				String poLineUpdateEp=environment.getProperty("po_line_update")+poNum+"/lines/"+poLineNumber;
				logger.info("payload link from file " + poLineUpdateEp);

				res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
						.contentType("application/json").headers(getIDMHeaders()).body(poLineObj.toJSONString()).when()
						.put(poLineUpdateEp);

				logger.info("response for PO line Update " + res.statusCode());

				Assert.assertEquals(ErrorCodes.PO_LINE_ADD_RESPONSE, Constants.SUCESS_STATUS_CODE, res.getStatusCode());

			});

			Failsafe.with(retryPolicy).run(() -> {
				response = given().relaxedHTTPSValidation().headers(getIDMHeaders()).when()
						.get(environment.getProperty("idm_delivery_ep") + delNumber);
				Assert.assertEquals(ErrorCodes.IDM_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				logger.info("Validating IDM response for Po Line update " + response.getBody().asString());
			});

			List<String> itemQtyBeforeLineUpdate = JsonPath.parse(testFlowData)
					.read("$..poDetails[*].poLineDetails[?(@.itemNumber=='" + itmNum + "')].poVnpkQty");
			JSONArray itemQtyBefore = jsonUtils.converyListToJsonArray(itemQtyBeforeLineUpdate);
			int qtyValBfr = Integer.parseInt(itemQtyBefore.get(0).toString());

			List<String> itemQtyPostLineUpdate = JsonPath.parse(response.getBody().asString())
					.read("$.deliveryDocuments[?(@.deliveryNumber=='" + delNumber
							+ "')].deliveryDocumentLines[?(@.itemNbr=='" + itmNum + "')].expectedQty");
			JSONArray itemQtyAfter = jsonUtils.converyListToJsonArray(itemQtyPostLineUpdate);
			int qtyValAft = Integer.parseInt(itemQtyAfter.get(0).toString());
			Assert.assertTrue(ErrorCodes.PO_LINE_UPDATE_FAILED, qtyValAft > qtyValBfr);
			int qtyDiff = qtyValAft - qtyValBfr;

			List<String> testFlowUpdate = JsonPath.parse(testFlowData)
					.read("$..poDetails[*].poLineDetails[?(@.itemNumber=='" + itmNum + "')]");
			JSONArray testFlowArr = jsonUtils.converyListToJsonArray(testFlowUpdate);
			JSONObject testFlowObj = (JSONObject) testFlowArr.get(0);
			testFlowObj.put("poVnpkQty", String.valueOf(qtyValAft));
			logger.info("PO Line Update Test Flow before : " + testFlowObj.toJSONString());

			String updatedTestFlow = jsonUtils.setJsonAtJsonPath(testFlowData, testFlowObj,
					"$..poDetails[*].poLineDetails[?(@.itemNumber=='" + itmNum + "')]");
			logger.info("PO Line Update Test Flow : " + tl.get().get("testFlowData"));

			tl.get().put("testFlowData", updatedTestFlow);
			logger.info("Actual Test FLow : " + tl.get().get("testFlowData"));

			String updatedTestFlowAfterOrderDetail = tl.get().get("testFlowData").toString();
			List<String> ordDetailUpdate = JsonPath.parse(updatedTestFlowAfterOrderDetail).read("$..ordersDetails[*]");
			JSONArray ordDetailUpdateArr = jsonUtils.converyListToJsonArray(ordDetailUpdate);
			JSONObject[] ordObj = new JSONObject[ordDetailUpdateArr.size()];

			for (int i = 0; i < ordDetailUpdateArr.size(); i++) {
				ordObj[i] = (JSONObject) ordDetailUpdateArr.get(i);
				int qty = Integer.parseInt(ordObj[i].get("quantity").toString());
				int vnpk = Integer.parseInt(ordObj[i].get("vnpk").toString());
				int qtyEch = qtyDiff * vnpk;

				logger.info("QTY : " + qty + qtyEch);

				if (qty == qtyEch) {
					ordObj[i].put("isOverage", false);
				}
			}
			logger.info("Updated Order Detail arr : " + ordDetailUpdateArr.toJSONString());
			String updatedOrderDetail = jsonUtils.setJsonAtJsonPath(updatedTestFlowAfterOrderDetail, ordDetailUpdateArr,
					"$..ordersDetails");

			tl.get().put("testFlowData", updatedOrderDetail);
			logger.info("Order Detail Updated Test Flow : " + tl.get().get("testFlowData"));

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while attaching po line to delivery", e);
		}

	}

	public int updateDeliveryStatus(String delStatus) {

		JSONObject updateDeliveryStatusPayload = new JSONObject();
		updateDeliveryStatusPayload.put("deliveryStatus", delStatus);
		logger.info("Delivery status upate  payload::{}", updateDeliveryStatusPayload.toString());

		String gdmUpdateStatusUrl = MessageFormat.format(environment.getProperty("gdm_delivery_status_update"),
				getDeliveryNumber());
		Response res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
				.contentType("application/json").headers(getIDMHeaders())
				.body(updateDeliveryStatusPayload.toJSONString()).when().put(gdmUpdateStatusUrl);
		return res.getStatusCode();

	}

	public int assignDoorFromGdm() {

		JSONObject assignDoorPayload = new JSONObject();
		int randomDoorNumber = javaUtils.randomNrGeneratorRange(MIN_DOOR_RANGE, MAX_DOOR_RANGE);
		assignDoorPayload.put("doorNumber", String.valueOf(randomDoorNumber));
		String gdmDoorAssignUrl = MessageFormat.format(environment.getProperty("gdm_door_assign"), getDeliveryNumber());
		Response res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
				.contentType("application/json").headers(getIDMHeaders()).body(assignDoorPayload.toJSONString()).when()
				.put(gdmDoorAssignUrl);
		updateTestFlowDatawithDoor(randomDoorNumber);
		return res.getStatusCode();
	}

	private void updateTestFlowDatawithDoor(int randomDoorNumber) {

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		List<DeliveryDetail> deliveryDetailObj = null;
		JSONArray deliveryDetailsArray = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[*]");
		logger.info("deliveryDetailsArrayYMS:{}", deliveryDetailsArray.toJSONString());
		try {
			deliveryDetailObj = (List<DeliveryDetail>) jsonUtils
					.getPojoListfromPath(deliveryDetailsArray.toJSONString(), DeliveryDetail.class);

			deliveryDetailObj.get(0).setInboundDoorNumber(String.valueOf(randomDoorNumber));

			JSONArray listOfDeliveryDetail = jsonUtils.converyListToJsonArray(deliveryDetailObj);
			testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listOfDeliveryDetail,
					"$.testFlowData.deliveryDetails");
			tl.get().put("testFlowData", testFlowData);
			logger.info("testFlowData after Door assign {}", tl.get().get("testFlowData"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void croUpdateForFbqVariableWeight(String poNumber) {

		try {

			logger.info("The PO for which the Variable weight and FBQ is going to get updated is :{}", poNumber);
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfPoLines = JsonPath.parse(testFlowData)
					.read(javaUtils.format(GET_LINE_DETAILS_PATH, poNumber));
			String poLinesJson = objectMapper.writeValueAsString(listOfPoLines);
			List<PoLineDetail> poLineDetailList = (List<PoLineDetail>) jsonUtil.getPojoListfromPath(poLinesJson,
					PoLineDetail.class);

			for (PoLineDetail poLine : poLineDetailList) {

				if (poLine.getIsVariableWeight() == true)
					performFbqVariableWeightUpdate(poNumber, poLine);
				
			}
		} catch (Exception ex) {
			throw new AutomationFailure("Outbound Load Validation is failed for load:", ex);
		}

	}

	private void performFbqVariableWeightUpdate(String poNumber, PoLineDetail poLine) {

		String polineNumber = poLine.getPoLineNumber();
		String fbqQty = poLine.getPoVnpkQty();
		Double itemWeight = poLine.getWeight();
		Double variableWeight = calculateVariableWeight(fbqQty, itemWeight);
		DecimalFormat df = new DecimalFormat("#.##");
		variableWeight = Double.valueOf(df.format(variableWeight));
		String payload = constructCroUpdatePayload(poNumber, polineNumber, fbqQty, variableWeight);
		String croUpdateUrl = MessageFormat.format(environment.getProperty("gdm_cro_update_reject"), getDeliveryNumber(),
				poNumber);
		logger.info("Cro Update url is:{}", croUpdateUrl);
		Response res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
				.contentType("application/json").headers(getIDMHeaders()).body(payload).when().put(croUpdateUrl);
		Assert.assertEquals(ErrorCodes.IDM_CRO_UPDATE_ERROR, Constants.SUCESS_STATUS_CODE, res.getStatusCode());

	}

	private Double calculateVariableWeight(String fbqQty, Double itemWeight) {

		return Integer.parseInt(fbqQty) * itemWeight;
	}

	private String constructCroUpdatePayload(String poNumber, String polineNumber, String fbqQty,
			Double variableWeight) {

		JSONObject lineObj = new JSONObject();
		lineObj.put("purchaseLineNumber", Integer.parseInt(polineNumber));
		lineObj.put("freightBillQty", Integer.parseInt(fbqQty));
		lineObj.put("variableWeight", variableWeight);

		JSONArray linesArray = new JSONArray();
		linesArray.add(lineObj);

		JSONObject purchaseOrder = new JSONObject();
		purchaseOrder.put("purchaseReferenceNumber", poNumber);
		purchaseOrder.put("lines", linesArray);

		JSONObject updatePayload = new JSONObject();
		updatePayload.put("purchaseOrder", purchaseOrder);

		String payLoad = updatePayload.toString();
		logger.info("Payload for CRO updation for variable weight is: {} ", payLoad);
		return payLoad;

	}

	public void validateFbqVariableWtInDelivery(String poNumber) {
		try {
			boolean isVariable = false;
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfPoLines = JsonPath.parse(testFlowData)
					.read(javaUtils.format(GET_LINE_DETAILS_PATH, poNumber));
			String poLinesJson = objectMapper.writeValueAsString(listOfPoLines);
			List<PoLineDetail> poLineDetailList = (List<PoLineDetail>) jsonUtil.getPojoListfromPath(poLinesJson,
					PoLineDetail.class);
			for (PoLineDetail poLine : poLineDetailList) {
				if (poLine.getIsVariableWeight()) {
					validateFbqVariableWeightUpdate(poNumber, poLine);
					isVariable = true;
				}
			}
			Assert.assertEquals(ErrorCodes.IDM_NO_VARIABLE_ITEM_FOUND, true, isVariable);
		}
		catch (Exception e) {
			throw new AutomationFailure("Failed to validate fbq qty and variable weight in delivery:", e);
		}

	}

	public void validateFbqVariableWeightUpdate(String poNumber, PoLineDetail poLine) {

		try {

			String lineNum = poLine.getPoLineNumber();
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			JSONArray listOfDelivery = JsonPath.read(testFlowData, GET_DELIVERY_NUM);
			String deliveryString = listOfDelivery.toJSONString();
			List<String> deliveryList = null;
			deliveryList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = deliveryList.get(0);

			response = given().relaxedHTTPSValidation().headers(getIDMHeaders()).when()
					.get(environment.getProperty("idm_delivery_ep") + deliveryNum);

			JSONArray listOfWeight = JsonPath.read(response.asString(),
					"$..deliveryDocumentLines[?(@.purchaseReferenceNumber == '" + poNumber
							+ "' && @.purchaseReferenceLineNumber == '" + lineNum + "')].vnpkWgtQty");
			String weightString = listOfWeight.toJSONString();
			List<String> weightList = null;
			weightList = objectMapper.readValue(weightString, new TypeReference<List<String>>() {
			});

			JSONArray listOfFbq = JsonPath.read(response.asString(),
					"$..deliveryDocumentLines[?(@.purchaseReferenceNumber == '" + poNumber
							+ "' && @.purchaseReferenceLineNumber == '" + lineNum + "')].freightBillQty");
			String fbqString = listOfFbq.toJSONString();
			List<String> fbqList = null;
			fbqList = objectMapper.readValue(fbqString, new TypeReference<List<String>>() {
			});

			String itemFbq = fbqList.get(0);
			Assert.assertEquals(ErrorCodes.IDM_FBQ_QTY_MISMATCH, itemFbq, poLine.getPoVnpkQty());

			double itemMdmWeight = poLine.getWeight();

			Double variableWeight = calculateVariableWeight(itemFbq, itemMdmWeight) / Integer.parseInt(itemFbq);
			DecimalFormat df = new DecimalFormat("#.##");
			variableWeight = Double.valueOf(df.format(variableWeight));

			Double itemWeight = Double.valueOf(weightList.get(0));
			DecimalFormat df2 = new DecimalFormat("#.##");
			Double variableWeightActual = Double.valueOf(df2.format(itemWeight));

			Assert.assertEquals(ErrorCodes.IDM_VARIABLE_QTY_MISMATCH, variableWeight, variableWeightActual);

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate fbq qty and variable weight in delivery:", e);
		}

	}

	public void validatePOLineStatus(String poNbr, String poLine) {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfDelivery = JsonPath.read(testFlowData, GET_DELIVERY_NUM);
			String deliveryString = listOfDelivery.toJSONString();
			List<String> deliveryList = null;
			deliveryList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = deliveryList.get(0);

			response = given().relaxedHTTPSValidation().headers(getIDMHeaders()).when()
					.get(environment.getProperty("idm_delivery_ep") + deliveryNum);
			
			DocumentContext parsedItemDetailsJson = JsonPath.parse(response.asString());

			List<String> status = parsedItemDetailsJson
					.read("$..deliveryDocumentLines[?(@.purchaseReferenceNumber == '"+poNbr+"' && @.purchaseReferenceLineNumber == '"+poLine+"')].operationalInfo.state");

			Assert.assertEquals(ErrorCodes.IDM_REJECT_STATUS_MISMATCH, PO_REJECT, status.get(0));

		} catch (Exception e) {
			throw new AutomationFailure("PO Line status is not updated Rejected after PO Line Reject:", e);
		}
	}

	public void rejectPoLine(String poNumber, String lineNumber) {
		
		try {
			logger.info("The line number :{} of the PO :{} will be rejected from GDM",lineNumber, poNumber);
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfPoLines = JsonPath.parse(testFlowData)
					.read(javaUtils.format(GET_LINE_DETAILS_PATH, poNumber));
			String poLinesJson;
	
				poLinesJson = objectMapper.writeValueAsString(listOfPoLines);
		
			List<PoLineDetail> poLineDetailList;
		
				poLineDetailList = (List<PoLineDetail>) jsonUtil.getPojoListfromPath(poLinesJson,
						PoLineDetail.class);
			
			boolean isLinePresent = false;
			for (PoLineDetail poLine : poLineDetailList) {

				if (poLine.getPoLineNumber().equals(lineNumber) ) {
					performPoLineReject(poNumber, poLine);
					isLinePresent = true;
				}
					
			}
			if(!isLinePresent){
				throw new AutomationFailure("Required POLine not available to perform reject operation");
				}
		}
		
		catch(Exception e) {
			
			throw new AutomationFailure("something went wrong while rejecting the POLine");
		}

		
	}

	private void performPoLineReject(String poNumber, PoLineDetail poLine) {
		
		String polineNumber = poLine.getPoLineNumber();
		String fbqQty = poLine.getPoVnpkQty();
		Double itemWeight = poLine.getWeight();
		Double variableWeight = calculateVariableWeight(fbqQty, itemWeight);
		DecimalFormat df = new DecimalFormat("#.##");
		variableWeight = Double.valueOf(df.format(variableWeight));
		String payload = constructPoLineRejectPayload(poNumber, polineNumber, fbqQty, variableWeight);
		String poRejectUrl = MessageFormat.format(environment.getProperty("gdm_cro_update_reject"), getDeliveryNumber(),
				poNumber);
		logger.info("POline reject payload is:{}", poRejectUrl);
		Response res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
				.contentType("application/json").headers(getIDMHeaders()).body(payload).when().put(poRejectUrl);
		Assert.assertEquals(ErrorCodes.IDM_REJECT_POLINE_ERROR, Constants.SUCESS_STATUS_CODE, res.getStatusCode());
		
	}

	private String constructPoLineRejectPayload(String poNumber, String polineNumber, String fbqQty,
			Double variableWeight) {
		
		JSONObject lineObj = new JSONObject();
		lineObj.put("purchaseLineNumber", Integer.parseInt(polineNumber));
		lineObj.put("freightBillQty", Integer.parseInt(fbqQty));
		lineObj.put("variableWeight", variableWeight);
		JSONObject operationalInfo = new JSONObject();
		operationalInfo.put("state", "REJECTED" );
		operationalInfo.put("userId", "e2eTest" );
		lineObj.put("operationalInfo", operationalInfo);
		
		JSONArray linesArray = new JSONArray();
		linesArray.add(lineObj);

		JSONObject purchaseOrder = new JSONObject();
		purchaseOrder.put("purchaseReferenceNumber", poNumber);
		purchaseOrder.put("lines", linesArray);

		JSONObject updatePayload = new JSONObject();
		updatePayload.put("purchaseOrder", purchaseOrder);

		String payLoad = updatePayload.toString();
		logger.info("Payload for PO line reject is: {} ", payLoad);
		return payLoad;
		
		
	}

	public void simulateChannelFlip(String channelUpdateMessage) {
		
		String eventType ="CHANNEL_UPDATE";
		
		stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_idm_channelupdate_queue"),
				channelUpdateMessage, QUEUE, environment.getProperty("connection_factory"),
				environment.getProperty("idm_starti_username"),
				environment.getProperty("idm_starti"),eventType);
		logger.info("Published channel update message to Loading");
		
	}
	
	public void publishPOLineUpdate(int poQty) throws URISyntaxException, IOException, ParseException {

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		String delNumber = deliveryNumberList.get(0);
		List<String> poNumberList = parsedJson.read("$..poDetails[*].poNumber");
		String poNum = poNumberList.get(0);
		List<String> poLineNumberList = parsedJson.read("$..poLineDetails[*].poLineNumber");
		int poLineNumber = Integer.valueOf(poLineNumberList.get(0));
		
		String fileData = "";

			fileData = textParser.readTextFile(FileNames.ATLAS_PO_LINE_UPDATE);
			logger.info("po line payload " + fileData);

			JSONObject poLineObj = jsonUtils.convertStringToMinidevJsonObject(fileData);

			logger.info("po line Object " + poLineObj);

//			poLineObj.put("deliveryNumber", delNumber);
			poLineObj.put("purchaseReferenceNumber", poNum);
			poLineObj.put("orderQty", poQty);
			poLineObj.put("purchaseLineNumber", poLineNumber);

			logger.info("po line payload " + poLineObj.toJSONString());
			Failsafe.with(retryPolicy).run(() -> {
				Response res;
				String poLineUpdateEp=environment.getProperty("po_line_update")+poNum+"/lines/"+poLineNumber;
				logger.info("payload link from file " + poLineUpdateEp);

				res = SerenityRest.given().relaxedHTTPSValidation().accept("application/json")
						.contentType("application/json").headers(getIDMHeaders()).body(poLineObj.toJSONString()).when()
						.put(poLineUpdateEp);

				logger.info("response for PO line Update " + res.statusCode());

				Assert.assertEquals(ErrorCodes.PO_LINE_UPDATE_FAILED, Constants.SUCESS_STATUS_CODE, res.getStatusCode());

			});
		
	}
	
	public void updateLastLimitedQtyVerificationDateInGDM() {
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		List<String> itemNumberArray = JsonPath.parse(testFlowData).read(ITEM_NR_DELIVERY_JSONPATH);
		JSONObject updateLimitedQtyVerifiedOn = new JSONObject();
		updateLimitedQtyVerifiedOn.put("limitedQtyVerifiedOn", limitedQtyVerifiedOn.toString());
	
		String gdmUpdateLimitedQtyVerifiedOnDateUrl = environment.getProperty("update_VerifiedOn_date")+ itemNumberArray.get(0);
		logger.info("URL : "+gdmUpdateLimitedQtyVerifiedOnDateUrl);
		logger.info("Body Hazrat: "+updateLimitedQtyVerifiedOn.toJSONString());
		Failsafe.with(retryPolicy).run(() -> {Response res = SerenityRest.given().relaxedHTTPSValidation().headers(getIDMLithiumIonHeaders()).body(updateLimitedQtyVerifiedOn.toJSONString()).when()
				.put(gdmUpdateLimitedQtyVerifiedOnDateUrl);
		Assert.assertEquals(ErrorCodes.IDM_LIMITED_QTY_LAST_VALIDATION_DATE_CHANGE_FAILED, Constants.SUCESS_STATUS_CODE, res.getStatusCode());
	
		});
	}

	public String getTransportationModeJson(String limitedQtyOrLithiumIon) throws URISyntaxException, IOException {
		try{
		String limitedIonJson = textParser.readTextFile(FileNames.TRANSPORTATION_MODE_JSON_FOR_LIMITED_ION);
		String lithiumIonJson = textParser.readTextFile(FileNames.TRANSPORTATION_MODE_JSON_FOR_LITHIUM_ION);
		String lithiumAndLimitedJson = textParser.readTextFile(FileNames.TRANSPORTATION_MODE_JSON_FOR_LITHIUM_AND_LIMITED_ION);


		if (limitedQtyOrLithiumIon.equalsIgnoreCase("limitedQty"))
			return limitedIonJson;
		else if (limitedQtyOrLithiumIon.equalsIgnoreCase("lithiumAndLimitedIon"))
			return lithiumAndLimitedJson;
		else
			return lithiumIonJson;}
		catch (Exception e) {
			throw new AutomationFailure("Something went wrong while getting the Transportation Mode data", e);
		}
	}

	public void updateTransportationModeInGDM(String itemNumber, String limitedQtyOrLithiumIon) throws URISyntaxException, IOException {
		try {
			String transportationModeJson = getTransportationModeJson(limitedQtyOrLithiumIon);
			dbUtils.UpdateFrom(PRODUCT_NAME.IDM, queries.getProperty("update_transportation_modes"), transportationModeJson, itemNumber);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating the Transportation Mode In GDM", e);
		}
	}

	public void updateLastLithiumIonVerificationDateInGDM() {
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));
		List<String> itemNumberArray = JsonPath.parse(testFlowData).read(ITEM_NR_DELIVERY_JSONPATH);
		JSONObject updateLithiumIonVerifiedOn = new JSONObject();
		updateLithiumIonVerifiedOn.put("lithiumIonVerifiedOn", lithiumIonVerifiedOn.toString());
	
		String gdmUpdateLimitedQtyVerifiedOnDateUrl = environment.getProperty("update_VerifiedOn_date")+ itemNumberArray.get(0);
		logger.info("URL : "+gdmUpdateLimitedQtyVerifiedOnDateUrl);
		logger.info("Body Hazrat: "+updateLithiumIonVerifiedOn.toJSONString());
		Failsafe.with(retryPolicy).run(() -> {Response res = SerenityRest.given().relaxedHTTPSValidation().headers(getIDMLithiumIonHeaders()).body(updateLithiumIonVerifiedOn.toJSONString()).when()
				.put(gdmUpdateLimitedQtyVerifiedOnDateUrl);
		Assert.assertEquals(ErrorCodes.IDM_Lithium_ION_LAST_VALIDATION_DATE_CHANGE_FAILED, Constants.SUCESS_STATUS_CODE, res.getStatusCode());
	
		});
	}

	public boolean validateShortageQty(Response response, String poNumber) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> receivedQtyFromTestFlowData = JsonPath.read(runTimeData,
				javaUtils.format(RECEIVED_QTY_FROM_TESTFLOWDATA_JSON_PATH, poNumber));
		List<String>  poVnpkQtyTestflowData =  parsedJson.read(javaUtils.format(PO_VNPK_QTY_JSON_PATH, poNumber));
		List<Integer> shortageQty = JsonPath.read(response.asString(), javaUtils.format(SHORTAGE_QTY_FROM_OSDR_JSON_PATH, poNumber));
		int actualShortageQty = shortageQty.get(0);
		int expPOVnpkQty = Integer.parseInt(poVnpkQtyTestflowData.get(0));
		int expReceivedQty =Integer.parseInt(receivedQtyFromTestFlowData.get(0));
		logger.info(actualShortageQty + ":: Actual Shortage Qty");
		logger.info(expPOVnpkQty - expReceivedQty + ":: Expected Shortage Qty");
		return actualShortageQty == (expPOVnpkQty - expReceivedQty);
	}

	public boolean validateOverageQty(Response response, String poNumber) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> receivedQtyFromTestFlowData = JsonPath.read(runTimeData,
				javaUtils.format(RECEIVED_QTY_FROM_TESTFLOWDATA_JSON_PATH, poNumber));
		List<String> damageQtyTestflowData = parsedJson.read(javaUtils.format(DAMAGE_QTY_FROM_TESTFLOWDATA_JSON_PATH, poNumber));
		List<String>  poVnpkQtyTestflowData =  parsedJson.read(javaUtils.format(PO_VNPK_QTY_JSON_PATH, poNumber));
		List<Integer> overage = JsonPath.read(response.asString(), javaUtils.format(OVERAGE_QTY_FROM_OSDR_JSON_PATH, poNumber));
		int actualOverageQty = overage.get(0);
		int expReceivedQty =Integer.parseInt(receivedQtyFromTestFlowData.get(0));
		int expdamageQty = Integer.parseInt(damageQtyTestflowData.get(0));
		int expPOVnpkQty = Integer.parseInt(poVnpkQtyTestflowData.get(0));
		logger.info(actualOverageQty + " :: Actual OverageQty");
		logger.info((expReceivedQty + expdamageQty) - expPOVnpkQty + " :: Expected OverageQty");
		return actualOverageQty == ((expReceivedQty + expdamageQty) - expPOVnpkQty);
	}

	public boolean validateDamageQty(Response response, String poNumber) {
		String runTimeData;
		runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		parsedJson = JsonPath.parse(runTimeData);
		List<String> damageQtyTestflowData = parsedJson.read(javaUtils.format(DAMAGE_QTY_FROM_TESTFLOWDATA_JSON_PATH, poNumber));
		List<Integer> damageQty = JsonPath.read(response.asString(), javaUtils.format(DAMAGE_QTY_FROM_OSDR_JSON_PATH, poNumber));
		int actualdamageQty = damageQty.get(0);
		logger.info("Expected damage Qty for PO number "+poNumber+"::" +  damageQtyTestflowData.get(0));
		logger.info("Actual damage Qty:: " + actualdamageQty);
		return Integer.valueOf(actualdamageQty) == Integer.valueOf(damageQtyTestflowData.get(0));
	}
}
