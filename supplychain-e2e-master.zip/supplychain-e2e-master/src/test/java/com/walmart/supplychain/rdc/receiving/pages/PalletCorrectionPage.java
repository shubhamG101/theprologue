package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class PalletCorrectionPage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/et_label']")
	private WebElement palletCorrectionLabelInput;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_search_label']")
	private WebElement palletCorrectionNxtBtn;
	
	@FindBy(xpath = ".//*[@content-desc='Navigate up']")
	private WebElement backBtn;

	public void scanThePallet(String cntrId) {

		element(palletCorrectionLabelInput).waitUntilVisible();
		element(palletCorrectionLabelInput).type(cntrId);

		element(palletCorrectionNxtBtn).waitUntilVisible();
		element(palletCorrectionNxtBtn).click();

		logger.info("Scanned Label for Pallet correction");
	}
	
	public void navigateToDoorScanPage() {
		element(backBtn).waitUntilVisible();
		element(backBtn).click();
	}
}
