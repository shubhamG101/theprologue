package com.walmart.supplychain.thor.manifestservices.scenariosteps.webservices;

import com.walmart.supplychain.thor.manifestservices.steps.webservices.ManifestServicesSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class ManifestServicesScenario {

	@Steps
	ManifestServicesSteps manifestServicesSteps;
	
	@Given("^user creates po in OMS for item \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
	public void userCreatesPO(String itemNumber, String poLineQty, String vnpkQty, String whpkQty, String whpkSellCost){
		manifestServicesSteps.createPO(itemNumber, poLineQty, vnpkQty, whpkQty, whpkSellCost);
	}
	
	@Given("^user adds a po line in OMS for item \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
	public void userAddsANewPOLine(String lineTwoItemNumber, String lineTwoPoLineQty, String lineTwoVnpkQty, String lineTwoWhpkQty, String lineTwoWhpkSellCost){
		manifestServicesSteps.addPOLine(lineTwoItemNumber, lineTwoPoLineQty, lineTwoVnpkQty, lineTwoWhpkQty, lineTwoWhpkSellCost);
	}
	
	@Then("^user validates PO details in GDM$")
	public void userValidatesPOInManifest(){
		manifestServicesSteps.validatePOInManifest();
	}
	
	@Given("^oms sends PO line quantity update \"([^\"]*)\" event to GDM \"([^\"]*)\"$")
	public void updatePOQuantityForThePOLine(String updateQty, String status) {
		manifestServicesSteps.updatePOlineQty(updateQty,status);
	}
	
	@Given("^oms sends PO line status update \"([^\"]*)\" event to GDM$")
	public void updatePOlineStatus(String lineSatus) {
		manifestServicesSteps.updatePOlineStatus(lineSatus);
	}
	


}
