package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MoveCreationPage extends PageObject {

	PropertyResolver propertyResolver = new PropertyResolver();
	YMSHelper ymsHelper = new YMSHelper();
	Logger logger = LogManager.getLogger(this.getClass());

	@FindBy(xpath = "//*[starts-with(@href,'ManualMove.action?param=Dock')]")
	private WebElement manualMoveLink;

	@FindBy(id = "dcNumber")
	private WebElement dcNumberDropDown;

	@FindBy(id = "subcenterId")
	private WebElement subCenterDropDown;

	@FindBy(id = "trailerId")
	private WebElement trailerNumberField;

	@FindBy(id = "retrieveButton")
	private WebElement retrieveButton;

	@FindBy(id = "toDcNumber")
	private WebElement toDcNumberDropDown;

	@FindBy(id = "subcenterId")
	private WebElement tosubcenterIdDropDown;

	@FindBy(id = "toDoorId")
	private WebElement toDoorIdField;

	@FindBy(id = "createButton")
	private WebElement createButton;

	@FindBy(xpath = "//div[@id='success']/ul/li")
	private WebElement successMessage;

	@FindBy(xpath = "//div[@id='errorMessage']/ul/li")
	private WebElement errorMessage;

	public void clickManualMove() {
		element(manualMoveLink).waitUntilVisible();
		logger.info("Clicking on Manual Move link");
		element(manualMoveLink).click();
	}

	public String createManualMove(String dockView, String trailerNumber, String doorNumber) {
		String message = "";
		String door = "";
		String trailer="";
		
		if ("Inbound".equalsIgnoreCase(dockView)) {
			trailer = trailerNumber;
			door = doorNumber;
		}
		else if ("Outbound".equalsIgnoreCase(dockView)) {
			//update later to use one trailer for both inbound and outbound
			/*if(RunTimeData.getOutBoundTrailer()==null||RunTimeData.getOutBoundTrailer().equals("")) {
	            RunTimeData.setOutBoundTrailer(RunTimeData.getInboundTrailer());
	        }*/
			trailer = trailerNumber;
			door = doorNumber;
		}
		element(dcNumberDropDown).waitUntilVisible();
		element(dcNumberDropDown).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number", true));
		element(subCenterDropDown)
				.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "sub_center", true));
		element(trailerNumberField).clear();
		element(trailerNumberField).type(trailer);
		element(retrieveButton).click();
		element(toDcNumberDropDown).waitUntilVisible();
		element(toDcNumberDropDown).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number", true));
		element(tosubcenterIdDropDown)
				.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "sub_center", true));
		element(toDoorIdField).clear();
		element(toDoorIdField).type(door );
		logger.info(door + " door number is entered");
		logger.info("Clicking on Create Button");
		element(createButton).click();
//		if (ymsHelper.isElementVisible("//strong[contains(text(),'Search Criteria')]")) {
//			if (ymsHelper.isElementVisible("//div[@id='errorMessage']/ul/li"))
//				message = errorMessage.getText().trim();
//			else
				message = successMessage.getText().trim();
//		}
		logger.info(message);
		return message;
	}
}
