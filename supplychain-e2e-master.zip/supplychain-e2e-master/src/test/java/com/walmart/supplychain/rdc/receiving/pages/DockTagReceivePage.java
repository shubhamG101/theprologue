package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class DockTagReceivePage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_complete_dock_tag']")
	private WebElement completDockTagBtn;

	@FindBy(xpath = ".//*[@resource-id='android:id/button1']")
	private WebElement confirmCompletDockTagBtn;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/summary_message']")
	private WebElement completDockTagMsg;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/summary_close']")
	private WebElement closeDockTagConfirmation;
	
	public String completeDockTag() {
		String dockTagCompleteMsg = null;
		try {
			element(completDockTagBtn).waitUntilVisible();
			element(completDockTagBtn).click();

			Thread.sleep(1000);
			element(confirmCompletDockTagBtn).waitUntilVisible();
			element(confirmCompletDockTagBtn).click();

//			Thread.sleep(1000);
//			element(completDockTagMsg).waitUntilVisible();
//			dockTagCompleteMsg = element(completDockTagMsg).getText();
			Thread.sleep(2000);
			element(closeDockTagConfirmation).waitUntilVisible();
			element(closeDockTagConfirmation).click();

			logger.info("completed the docktag");
		} catch (Exception e) {

		}

		return dockTagCompleteMsg;
	}

}
