package com.walmart.supplychain.acc.acl.scenariosteps.webservices;

import com.walmart.supplychain.acc.acl.steps.webservices.ACLSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class ACLScenarios {
	@Steps
	ACLSteps aclSteps;
	
	@And("^user verifies ACL verification message sent to receiving$")
	public void sendAclVerificcationMessageToReceiving()
	{
		aclSteps.sendVerificationFromACLtoRec();
	}
	
	@And("^sorter publish backward flow message to ACL$")
	public void publishBackwardFlowMessageToACL() {
		aclSteps.triggerBackwardFlowforSorter();
	}
}
