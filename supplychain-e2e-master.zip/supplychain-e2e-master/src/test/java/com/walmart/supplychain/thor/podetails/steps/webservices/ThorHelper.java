package com.walmart.supplychain.thor.podetails.steps.webservices;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.thor.podetails.pages.ThorTokenPage;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ThorHelper {
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	Environment environment;
	
	ThorTokenPage thorTokenPage;
	
	public Headers getDCFINHeaders() {

		Header facilityNum = new Header("facilityNum", "6086");
		Header facilityCountryCode = new Header("facilityCountryCode", "US");
		Header contentType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(facilityNum);
		headerList.add(facilityCountryCode);
		headerList.add(contentType);
		return new Headers(headerList);

	}
	
	public void openReceivingAppPage() {
		logger.info("Security token url:{}", environment.getProperty("security_token_url"));
		thorTokenPage.getUrl(environment.getProperty("security_token_url"));
	}
	
	
	
}