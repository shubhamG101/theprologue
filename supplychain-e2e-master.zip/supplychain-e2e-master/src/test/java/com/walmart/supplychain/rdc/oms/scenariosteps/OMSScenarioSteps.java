package com.walmart.supplychain.rdc.oms.scenariosteps;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.rdc.gdm.steps.webservices.RDCGdmSteps;
import com.walmart.supplychain.rdc.oms.steps.RDCOmsStep;
import com.walmart.supplychain.witron.oms.steps.WitronCreatePO;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class OMSScenarioSteps {

	@Steps
	RDCOmsStep rdcOmsStep;

	@Steps
	WitronCreatePO witronCreatePO;

	@Given("user creates a PO in OMS for \"([^\"]*)\" flow")
	public void userCreatesAPOInOMSForFlow(String flowType) {
		rdcOmsStep.createOMSPO(flowType);

	}

	@Then("^User hits RDC OMS to validate the PO$")
	public void userHitsOMSForThePo() {

		rdcOmsStep.rdcPreCleanUp();
		witronCreatePO.populateOMSResponse();
	}

}
