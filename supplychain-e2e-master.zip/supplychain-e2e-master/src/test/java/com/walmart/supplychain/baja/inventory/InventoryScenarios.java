package com.walmart.supplychain.baja.inventory;

import java.io.IOException;

import cucumber.api.java.en.Given;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;

public class InventoryScenarios {

	@Steps
	BajaInventorysteps inventorySteps;
	
	 @Given("^user creates container in inventory system$")
	 public void inventoryCreation() throws ParseException, InterruptedException, IOException {
		inventorySteps.createInventory();
	 }
	 
	 @Given("^user verifies containers are created in the inventory$")
	 public void inventoryValidation() {
			inventorySteps.validateInventory();
	 }
	 
}
