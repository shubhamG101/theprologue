package com.walmart.supplychain.acc.sorter.scenariosteps.webdervices;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.acc.acl.steps.webservices.ACCDoorAssignStep;
import com.walmart.supplychain.acc.sorter.steps.webservices.ACCSorterIntegrationStep;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;

public class ACCSorterIntegration {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Autowired
    ReceivingHelper receivingHelper;
	
	@Steps
	ACCSorterIntegrationStep aCCSorterIntegrationStep;
	
	@Steps
	ACCDoorAssignStep accDoorAssignStep;

	Logger logger = LogManager.getLogger(this.getClass());

	WebDriver driver;

	@And("^Beumer publishes the verification message \"([^\"]*)\"$")
	public void userVerifiesLabelDataPresentInACLInterface(String labelStatus) {
		aCCSorterIntegrationStep.publishDispositionMsg(labelStatus);
		aCCSorterIntegrationStep.publishExceptionDispositionMsg(labelStatus);
	}
	
	@And("^user verifies the disposition message \"([^\"]*)\"$")
	public void userVerifiesTheDispositionmessage(String labelStatus) {
		aCCSorterIntegrationStep.verifySorterDBForLanes(labelStatus);
		aCCSorterIntegrationStep.verifyExceptionLPNsForLanes(labelStatus);
	}
	

	@And("^Beumer publishes the verification message for single container$")
	public void userSendsDispositionMessageForSingleContainer(){
		aCCSorterIntegrationStep.publishDispositionMsgSingleContainerManually();
	}
	
}

