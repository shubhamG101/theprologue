package com.walmart.supplychain.thor.adjustments.steps;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.thor.ThorAdjustment;
import com.walmart.framework.supplychain.domain.thor.WAC;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.thor.podetails.pages.ThorTokenPage;
import com.walmart.supplychain.thor.podetails.steps.webservices.ThorHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ThorAdjustmentSteps {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String GET_POLINES = "$.testFlowData.poDetails[*].poLineDetails[*]";
	private static final String ELEMENT = "Unit";
	private static final String REASON = "LostFound";
	private static final String WORKFLOW = "InventoryException";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String ADJUSTMENT_EP = "thor_adjustment_url";
	private static final String GET_WAC_EP = "get_wac_url";
	private static final String BASE_DIV_CODE = "WM";
	private static final String FINANCIAL_REPORTING_GROUP_CODE = "US";
	private static final String BALANCEONHAND = "$.foundItemsCostDetail[*].balanceOnHandQuantity";
	List itemLabelList = null;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired(required = true)
	ThorHelper thorHelper;

	@Autowired
	Environment environment;

	Response response;

	@Autowired
	JavaUtils javaUtil;

	ThorTokenPage thorTokenPage;

	ObjectMapper om = new ObjectMapper();

	@Step
	public void publishAdjustments(String adjustmentFlag) {
		DocumentContext context = null;
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List newPoList = new ArrayList();

			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List newPoLineList = new ArrayList();
				for (PoLineDetail lineDetail : poLineList) {
					String thorSKU = lineDetail.getThorSKU();
					List<ReceivingInstruction> recvList = lineDetail.getReceivingInstructions();
					String receivedQty = recvList.get(0).getReceivedQuantity();
					String tote = recvList.get(0).getTote();
					int adjustmentQty = 0;
					int remainingQty = 0;
					if (adjustmentFlag.equals("true")) {
						adjustmentQty = -Integer.parseInt(receivedQty) / 4;
						remainingQty = Integer.parseInt(receivedQty) + adjustmentQty;
					} else {
						adjustmentQty = Integer.parseInt(receivedQty) / 4;
						remainingQty = Integer.parseInt(receivedQty) + adjustmentQty;
					}

					ThorAdjustment adjustments = new ThorAdjustment();
					adjustments.setElement(ELEMENT);
					adjustments.setIcReason(REASON);
					adjustments.setIcWorkflow(WORKFLOW);
					adjustments.setThorSku(thorSKU);
					adjustments.setTotalUnitCount(remainingQty);
					logger.info("Thor adjustment payload:" + objectMapper.writeValueAsString(adjustments));
					logger.info("thor Adjustment url:" + environment.getProperty(ADJUSTMENT_EP) + tote);

					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(
									environment.getProperty("security_token_url"), environment.getProperty("thor_user"),
									environment.getProperty("thor"), false))
							.body(om.writeValueAsString(adjustments)).when()
							.post(environment.getProperty(ADJUSTMENT_EP) + tote);
					Assert.assertEquals(ErrorCodes.THOR_RECEIVING, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());

					recvList.get(0).setAdjustedQty(adjustmentQty);
					recvList.get(0).setAdjustmentCode("1");
					lineDetail.setReceivingInstructions(recvList);
					lineDetail.setBoh(lineDetail.getBoh() + adjustmentQty);
					newPoLineList.add(lineDetail);

				}
				poDetail.setPoLineDetails(poLineList);
				newPoList.add(poDetail);
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			om.writeValueAsString(poList);
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(poList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after publishing the Inventory Receipts::{}", tl.get().get(TEST_FLOW_DATA));
		} catch (Exception e) {
			throw new AutomationFailure("Failed to publish adjustments", e);
		}

	}

	public void validateAdjustments() {
		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfPoLines = JsonPath.read(testData, GET_POLINES);
			String poLineString = listOfPoLines.toJSONString();
			List<PoLineDetail> poLineList = objectMapper.readValue(poLineString,
					new TypeReference<List<PoLineDetail>>() {
					});
			for (PoLineDetail lineDetail : poLineList) {
				List wacList = new ArrayList();
				String item = lineDetail.getItemNumber();
				WAC wac = new WAC();
				wac.setBaseDivCode(BASE_DIV_CODE);
				wac.setFinancialReportingGroupCode(FINANCIAL_REPORTING_GROUP_CODE);
				wac.setItemNumber(item);
				wacList.add(wac);
				logger.info("wac body:" + om.writeValueAsString(wacList));
				logger.info("wac url:" + environment.getProperty(GET_WAC_EP));
				Failsafe.with(retryPolicy).run(() -> {
					response = given().relaxedHTTPSValidation().headers(thorHelper.getDCFINHeaders())
							.body(om.writeValueAsString(wacList)).when().post(environment.getProperty(GET_WAC_EP));
					Assert.assertEquals(ErrorCodes.THOR_WAC_ADJUSTMENT, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());

					JSONArray bohArray = JsonPath.read(response.asString(), BALANCEONHAND);
					String bohString = bohArray.toJSONString();
					List<String> bohList = objectMapper.readValue(bohString, new TypeReference<List<String>>() {
					});

					String bohDB = bohList.get(0);
					Assert.assertEquals(ErrorCodes.THOR_WAC_ADJUSTMENT, lineDetail.getBoh(), Integer.parseInt(bohDB));
				});
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate adjustments", e);

		}
	}
}
