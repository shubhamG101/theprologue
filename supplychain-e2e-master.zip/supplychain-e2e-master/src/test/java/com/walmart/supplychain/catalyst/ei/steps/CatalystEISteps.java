package com.walmart.supplychain.catalyst.ei.steps;

import static net.serenitybdd.rest.SerenityRest.given;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.catalyst.by.webservices.steps.BYWebservicesHelper;
import com.walmart.supplychain.catalyst.by.webservices.steps.BYWebservicesSteps;

import io.restassured.RestAssured;
import io.restassured.http.Cookies;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystEISteps extends ScenarioSteps {
	
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;
	
	@Autowired
	JavaUtils javaUtils;
	
	
	@Autowired
	BYWebservicesHelper byWebservicesHelper;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	
	
	private Response response;
	private static final String TEST_FLOW_DATA = "testFlowData";
	
	
	private static final String PO_NUMBER_JSONPATH = "$.testFlowData.poDetails..poNumber";
	
	private static List<String> poNumber = new ArrayList<String>();
	private static List<String> itemNumbers = new ArrayList<String>();
	private static Map<String, Double> itemsWithTurnQuantity = new HashMap<String, Double>();
	
	
	@Step
	public void getEIInventoryDetails() {
		
		try {
			
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			
			//fetching PO number
			poNumber.clear();
			poNumber = JsonPath.read(testFlowData, PO_NUMBER_JSONPATH);
			logger.info("Expected PO number : {} ", poNumber);
			itemsWithTurnQuantity.clear();
			
			for(String currentPONumber : poNumber) {
				
				itemNumbers.clear();
				itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..itemNumber");
				logger.info("Expected Item numbers to fetch EI inventory details corrosponding to PO number {} : {}", currentPONumber, itemNumbers);
				
				for(String currentItem : itemNumbers) {
					
					logger.info("Current item: {}", currentItem);
					Failsafe.with(retryPolicy).run(() -> {
						response = getEIResponse(currentItem);
						logger.info("Staus code after hitting EI service: {}", response.getStatusCode());
						Assert.assertEquals(ErrorCodes.CATALYST_EI_INVENTORY_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
						logger.info("Response after hitting EI service: {}", response.asString());
					});
					
					//getting inventory present in EI and storing in a map for further use
					List<Double> availableTurnQuantityForItem = JsonPath.read(response.asString(), "$..turnQuantity");
					logger.info("Available EI inventory for item {} is : {}", currentItem, availableTurnQuantityForItem.get(0));
					String key = currentPONumber + "_" + currentItem;
					logger.info("Key to store in items with quantity hashmap : {}", key);
					itemsWithTurnQuantity.put(key, availableTurnQuantityForItem.get(0));
				}
			}	
			
			logger.info("Stored turn quantity respective for each items : {}", itemsWithTurnQuantity);
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching Inventory details from EI service", e);
		}
		
	}
	
	public Response getEIResponse(String itemNumber) {
		
		response = SerenityRest.given().relaxedHTTPSValidation().when().get(environment.getProperty("ei_inventory_details_ep"), itemNumber, environment.getProperty("dcNumber"));
		return response;
	}
	
	
	@Step
	public void validateInventoryTrasactionEI(String eventType) {
		
		try {
			
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			
			for(String currentPONumber : poNumber) {
				
				for(String currentItem : itemNumbers) {
					
					logger.info("Current item: {}", currentItem);
					List<String> expectedReceivedLPNs = JsonPath.read(testFlowData,
							"$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')]..receivingInstructions..parentContainer");
					logger.info("Expected Received LPNs: {}", expectedReceivedLPNs);
					
					if(!expectedReceivedLPNs.isEmpty()) {
						
						if(eventType.equalsIgnoreCase("receipt")) {
							
							List<String> vnpkQty = JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')].vnpk");
							List<Integer> recvQty=JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')].recvQty");
							logger.info("Balance quantity in EI for PO {} and item {} is : {}", currentPONumber, currentItem, itemsWithTurnQuantity.get(currentPONumber + "_" + currentItem));
							int receivedQuantityInEaches = recvQty.get(0) * Integer.parseInt(vnpkQty.get(0));
							
							//getting expected quantity to validate in EI
							double expectedQuantityToVerifyInEiInventory = itemsWithTurnQuantity.get(currentPONumber + "_" + currentItem) + receivedQuantityInEaches;
							logger.info("Expected quantity to validate in EI for PO {} and item {} is : {}", currentPONumber, currentItem, expectedQuantityToVerifyInEiInventory);
							
							validateReceiptTransaction(expectedQuantityToVerifyInEiInventory, currentItem);
						}
					}
					
					else
						logger.info("There were no expected received LPNs to validate EI inventory for item {}", currentItem);
				}
			}
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Inventory details after receiving the item from EI service", e);
		}
		
	}
	
	
	public void validateReceiptTransaction(double expectedQuantity, String itemNumber) {
		
		Failsafe.with(retryPolicy).run(() -> {
			
			response = getEIResponse(itemNumber);
			logger.info("Staus code after hitting EI service: {}", response.getStatusCode());
			Assert.assertEquals(ErrorCodes.CATALYST_EI_INVENTORY_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			logger.info("Response after hitting EI service: {}", response.asString());
			
			//Validating turn quantity is getting updated in EI or not
			List<Double> actualTurnQuantityForItem = JsonPath.read(response.asString(), "$..turnQuantity");
			logger.info("Actual EI inventory for item {} is : {}", itemNumber, actualTurnQuantityForItem.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_EI_MISMATCH_IN_TURN_QUANTITY, expectedQuantity, actualTurnQuantityForItem.get(0));
		});
		
		//Validating inventory status
		List<String> actualInventoryStatus = JsonPath.read(response.asString(), "$..inventoryState");
		logger.info("Actual inventory status for item {} is : {}", itemNumber, actualInventoryStatus.get(0));
		Assert.assertEquals(ErrorCodes.CATALYST_EI_MISMATCH_IN_INVENTORY_STATUS, "AVAILABLE", actualInventoryStatus.get(0));
		
		//Validating last update date for turn quantity
		LocalDate currentDate = LocalDate.now();
		logger.info("Current date: {}", currentDate.toString());
		List<String> actualLastUpdateForTurnQuantity = JsonPath.read(response.asString(), "$..lastUpdateTimeForTurn");
		logger.info("Actual last updated date of turn quantity for item {} is : {}", itemNumber, actualLastUpdateForTurnQuantity.get(0));
		Assert.assertTrue(ErrorCodes.CATALYST_EI_MISMATCH_IN_INVENTORY_LAST_UPDATED_DATE, actualLastUpdateForTurnQuantity.get(0).contains(currentDate.toString()));
	}
	
}
