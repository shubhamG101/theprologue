package com.walmart.supplychain.catalyst.gdm.scenarioSteps.webservices;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

import spring.SpringTestConfiguration;

import org.springframework.stereotype.Component;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.catalyst.gdm.steps.webservices.CatalystGDMSteps;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class CatalystGDMScenarios {

	@Steps
	CatalystGDMSteps gdmSteps;

//	@Steps
//	PreRunCleanup preRunCleanup;

	
	@Then("^user verifies delivery is created in GDM with \"([^\"]*)\" status$")
	public void user_verifies_delivery_is_created_in_GDM_with_status(String deliveryStatus) {

		gdmSteps.search_and_validate_deliveryStatus(deliveryStatus, "D1");    //deliveryStatus as D1

	}	

	
	 
}
