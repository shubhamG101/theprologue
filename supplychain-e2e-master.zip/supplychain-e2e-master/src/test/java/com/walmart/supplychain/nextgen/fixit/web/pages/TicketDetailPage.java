package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class TicketDetailPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20,10);//15 times with a delay of 10s
	boolean problemTicketDisplayed=false;
	
	@FindBy(xpath = "//*[@class='problem-status']")
	private WebElement status_Text;

	@FindBy(xpath = "//*[@class='damage-status']")
	private WebElement damage_status_Text;
	
	@FindBy(xpath = "//*[@class='td-ticket-detail']")
	private WebElement ticketId_Text;
	
	@FindBy(xpath = "//*[@class='assignedgroup element']//div[2]")
	private WebElement assignedGroup_Text;
	
	@FindBy(xpath = "//*[@class='exception-qty element']//div[2]")
	private WebElement exceptionQty_Text;
	
	@FindBy(xpath = "")
	private WebElement userGroup_Text;
	
	@FindBy(xpath = "")
	private WebElement userId_Text;
	
	@FindBy(xpath = "//*[@name='id']")
	private WebElement containerId_Text;
	
	@FindBy(xpath = "")
	private WebElement deliveryNum_Text;
	
	//cancel
	@FindBy(xpath="//*[@class='MuiIconButton-label']")
	private WebElement cancel_Dropdown;
	
	@FindBy(xpath="//*[@id='select']")
	private WebElement reason_Dropdown;
	
	@FindBy(xpath="//*[@id='cancel-comment']")
	private WebElement commentCancel_Text;
	
	@FindBy(xpath="//button[text()='Cancel Ticket']")
	private WebElement cancel_Button;
	
	@FindBy(xpath="//*[@class='MuiSvgIcon-root back-button hover']")
	private WebElement back_Link;
	
	@FindBy(xpath="//*[@data-name='attachments']")
	private WebElement attachment_Link;
	
	@FindBy(xpath="//*[@id='attach']")
	private WebElement addFile_Link;
	
	@FindBy(xpath="//button[text()='Assign']")
	private WebElement assign_Button;
	
	@FindBy(xpath="//*[text()='Home Office']")
	private WebElement homeoffice_Button;
	
	@FindBy(xpath="//*[text()='Replenishment']")
	private WebElement replenishment_Button;
	
	@FindBy(xpath="//*[text()='DC']")
	private WebElement dc_Button;
	
	@FindBy(xpath="//*[@name='assignedUser']")
	private WebElement addUser_Textbox;
	
	@FindBy(xpath=".//*[@class='actions']//*[text()='Assign']")
	private WebElement assignToHo_Button;
	
	@FindBy(xpath=".//*[text()='Edit']")
	private WebElement edit_Button;
	
	@FindBy(xpath=".//*[@id='poevent']")
	private WebElement poEventCode_Textbox;
	
	@FindBy(xpath=".//*[@id='vendorname']")
	private WebElement vendorName_Textbox;
	
	@FindBy(xpath=".//*[text()='Save']")
	private WebElement save_Button;
	
	@FindBy(xpath="//*[@id='poline']")
	private WebElement poLine_Textbox;
	
	@FindBy(xpath="//*[text()='Reassign']")
	private WebElement reassign_Button;
	
	@FindBy(xpath="//*[@role='menu']//li[1]")
	private WebElement cancelTicket_Link;
	
	@FindBy(xpath = "//*[@class='title']//div[2]")
	private WebElement active_Text;
	
	@FindBy(xpath = "//*[@class='td-damage-detail']//div[11]//div[2]")
	private WebElement claimStatus_Text;

	@FindBy(xpath= "//*[@id=\"select\"]")
	private WebElement cancelReason_Link;

	@FindBy(xpath="//*[@id='moreInfoComment']")
	private WebElement comment_Textbox;

	@FindBy(xpath="//*[text()='Post']")
	private WebElement post_Button;

	@FindBy(xpath="//*[text()='More Info']")
	private WebElement moreInfo_Link;

	@FindBy(xpath="//*[text()='Yes']")
	private WebElement yes_Button;

	@FindBy(xpath="//*[text()='DC/FC']")
	private WebElement dcfc_Button;

	//WFS
	@FindBy(xpath="//*[text()='WFS Program']")
	private WebElement wfsProgram_Button;
	
	public String getTicketId() {
		element(ticketId_Text).waitUntilVisible();
		String str= element(ticketId_Text).getText();
		String[] ticketDetails=str.split(":");
		String[] ticketId=ticketDetails[1].split(" ");
		return ticketId[1];
	}
	
	public String getTicket() {
		element(status_Text).waitUntilVisible();
		return element(status_Text).getText();
	}
	
	public String getAssignedGroup() {
		element(assignedGroup_Text).waitUntilVisible();
		return element(assignedGroup_Text).getText();
	}
	
	public String getExceptionQty() {
		element(exceptionQty_Text).waitUntilVisible();
		return element(exceptionQty_Text).getText();
	}
	
	public String getContainerId() {
		element(containerId_Text).waitUntilVisible();
		return element(containerId_Text).getText();
	}
	
	public String getDeliveryNum() {
		element(deliveryNum_Text).waitUntilVisible();
		return element(deliveryNum_Text).getText();
	}
	
	public void cancelWebTicket() {
		try {
			element(cancel_Dropdown).waitUntilVisible();
			element(cancel_Dropdown).click();
			AppiumHelper.selectFromDropDown("Cancel Ticket", getCancelElements());
			Thread.sleep(2000);
			click(cancelReason_Link);
			AppiumHelper.selectFromDropDown("Other", getCancelComments());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(commentCancel_Text).waitUntilVisible();
		element(commentCancel_Text).type("Cancel ticket from web dashboard");
		click(cancel_Button);
	}

	public void cancelDamageWebTicket() {
		try {
			element(cancel_Dropdown).waitUntilVisible();
			element(cancel_Dropdown).click();
			Thread.sleep(1000);
			AppiumHelper.selectFromDropDown("Cancel Ticket", getCancelElements());
			Thread.sleep(2000);
			element(yes_Button).waitUntilVisible();
			element(yes_Button).click();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private List<WebElement> getCancelElements() {
		return getDriver().findElements(By.xpath("//*[@role='menu']/li"));
	}
	
	private List<WebElement> getCancelComments() {
		return getDriver().findElements(By.xpath("//*[@role='listbox']//li"));
	}
	
	public void goBackToListView() {
		getDriver().navigate().back();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		/*element(back_Link).waitUntilVisible();
		element(back_Link).waitUntilClickable();
		new Actions(getDriver()).moveToElement(back_Link).click().build().perform();
		element(back_Link).click();*/
	}
	
	public String getTicketStatus() {
		element(status_Text).waitUntilVisible();
		return element(status_Text).getText();
	}

	public String getDamageStatus() {
		element(damage_status_Text).waitUntilVisible();
		return element(damage_status_Text).getText();
	}
	
	public void clickAttachment() {
		click(attachment_Link);
		element(addFile_Link).waitUntilVisible();
		element(addFile_Link).type("/Users/b0n00kf/Desktop/SSO.png");
	}
	
	public void assignToHo() {
		logger.info("inside assign function");
		element(assign_Button).waitUntilVisible();
		element(assign_Button).click();
		element(homeoffice_Button).waitUntilVisible();
		element(homeoffice_Button).click();
		element(addUser_Textbox).waitUntilVisible();
		element(addUser_Textbox).type("test1");
		element(assignToHo_Button).waitUntilClickable();
		element(assignToHo_Button).click();
		//click(assignToHo_Button);
	}

	public void assignToWfsProgram() {
		click(assign_Button);
		click(wfsProgram_Button);
		element(addUser_Textbox).waitUntilVisible();
		element(addUser_Textbox).type("test1");
		click(assignToHo_Button);
	}
	
	public void editTicket() {
		click(edit_Button);
		element(poEventCode_Textbox).waitUntilVisible();
		element(poEventCode_Textbox).type("event1");
		element(vendorName_Textbox).waitUntilVisible();
		element(vendorName_Textbox).type("vendor1`");
		click(save_Button);
	}
	
	public void editPOline() {
		click(edit_Button);
		element(poLine_Textbox).waitUntilVisible();
		element(poLine_Textbox).waitUntilClickable();
		element(poLine_Textbox).type("01");
		click(save_Button);
	}
	
	public void assignToReplenishment() {
		click(assign_Button);
		click(replenishment_Button);
		element(addUser_Textbox).waitUntilVisible();
		element(addUser_Textbox).type("test1");
		click(assignToHo_Button);
	}
	
	public void assignToDC() {
		click(assign_Button);
		click(dc_Button);
		click(assignToHo_Button);
	}
	
	public void clickBackLink() {
		click(back_Link);
	}
	
	public void clickReAssign() {
		click(reassign_Button);
	}
	
	public void clickAssign() {
		click(assignToHo_Button);
	}
	
	public String getReceivingDmgTicketStatus() {
		element(active_Text).waitUntilVisible();
		return element(active_Text).getText();
	}
	
	public String getClaimStatus() {
		element(claimStatus_Text).waitUntilVisible();
		return element(claimStatus_Text).getText();
	}

	public void getMoreInfo(){
		try {
			element(moreInfo_Link).waitUntilVisible();
			element(moreInfo_Link).click();
			Thread.sleep(2000);
			element(dcfc_Button).waitUntilVisible();
			element(dcfc_Button).click();
			element(addUser_Textbox).waitUntilVisible();
			element(addUser_Textbox).type("e2e test user");
			element(comment_Textbox).waitUntilVisible();
			element(comment_Textbox).type("e2e comment for awaiting info");
			element(post_Button).waitUntilClickable();
			element(post_Button).click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
