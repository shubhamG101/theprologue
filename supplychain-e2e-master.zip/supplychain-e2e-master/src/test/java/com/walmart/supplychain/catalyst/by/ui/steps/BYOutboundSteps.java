package com.walmart.supplychain.catalyst.by.ui.steps;


import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.DRIVER_TYPE;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.UiActionsHelper;
import com.walmart.supplychain.catalyst.by.ui.pages.BYReceivingPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYLoginPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmSteps;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYOutboundSteps extends ScenarioSteps{
	
	WebDriver driver;
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	Environment endPoint;
	
	@Autowired
	BYLoginPage byLoginPage;
	
	@Autowired
	BYReceivingPage byReceivingPage;
	
	@Autowired
	BYOutboundPage byOutboundPage;
	
	@Autowired
	BYReceivingSteps byReceivingSteps;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;
	
	@Autowired
	UiActionsHelper uiActionsHelper;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY_20S, 
			Constants.RETRY_EXECUTION_COUNT);


	
	public static String waveNumber;
	public String currentWaveNumber_BY;
	private static final String TEST_FLOW_DATA = "testFlowData";
	
	
	private static final String BY_ORDER_FULFILLMENT_ID_JSONPATH = "$.testFlowData.outboundDetails..fulfillmentID_order";
	private static final String BY_LOADID_JSONPATH = "$.testFlowData.outboundDetails..loadID_BY";
	private static final String BY_WAVE_NUMBER_JSONPATH = "$.testFlowData.outboundDetails..waveNumber_BY";
	
	
	@Step
	public void verifyOrderAsActiveStatusInBY() {
		
		try {
			
			String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			List<String> order_fulfillmentID = JsonPath.read(runTimeData, BY_ORDER_FULFILLMENT_ID_JSONPATH);
			logger.info("Fetched BY order id from testflowdata is : {} ", order_fulfillmentID.get(0));
			
			String orderIDToBeSearched = order_fulfillmentID.get(0).replaceAll("-", "");
			
			filterOrderBasedOnStatus(orderIDToBeSearched, "Active");
			navigateToOrderAndStoreLoadID(orderIDToBeSearched);
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying order with active status in BY UI", e);
		}
	}
	
	public void filterOrderBasedOnStatus(String orderID, String status) throws InterruptedException {
		
		byOutboundPage.switchToFrame("outboundplanner");
		byOutboundPage.enterValueUnderFilterTextBox("outbound", orderID, "Order");
		byOutboundPage.selectQuickFilter(status);
		
		Failsafe.with(retryPolicy).run(() -> {
			
			byOutboundPage.clickRefreshIconForDifferentOutboundTabs("outbound");
			uiActionsHelper.sync(getDriver(), byReceivingPage.shipmentRecordBasedOnSpecificValue(orderID));
			Assert.assertTrue(ErrorCodes.CATALYST_WRONG_ORDER_RECORD, byReceivingPage.shipmentRecordBasedOnSpecificValue(orderID).isDisplayed());
			logger.info("Proper order {} with status {} got filtered successfully !", orderID, status);
			
		});
		
	}
	
	
	public void navigateToOrderAndStoreLoadID(String orderID) throws IOException, ParseException {
		
		byReceivingPage.clickOnShipmentRecordLink(orderID);
		
		//Fetching BY load id
		String loadID = byOutboundPage.getLoadValue();
		logger.info("Shown load value : {}", loadID);
		
		String byLoadID = loadID.substring(0, loadID.indexOf("|")).trim();
		logger.info("BY Load id to be used further : {}", byLoadID);
		
		
		//Store the BY load ID in testFlowData
		byUiHelper.updateTestFlowDataForOutboundDetails("loadID_BY", byLoadID);
		
	}
	
	@Step
	public void planWaveUsingLoadId() {
		
		try {
			
			byOutboundPage.switchToFrame("outboundplanner");
			
			String currentLoadID_BY = getCurrentLoadIDInBY();
			String loadIdToBeConcatedToWaveNumber = currentLoadID_BY.substring(2);
			waveNumber = "E2EAuto" + loadIdToBeConcatedToWaveNumber;
			
			
			
			byOutboundPage.selectOptionsFromActionsDropdownUnderWave_PicksTab("Plan Wave");
			byOutboundPage.enterLoadId(currentLoadID_BY);
			byOutboundPage.clickButtonByText("Search");
			
			if(byOutboundPage.getSearchedRecordForLoad().isEnabled())
				byOutboundPage.clickButtonByText("Plan Wave");
			
			byOutboundPage.enterWaveNumberAndClickOkButton(waveNumber);
			
			
			//Store the BY wave number in testFlowData
			byUiHelper.updateTestFlowDataForOutboundDetails("waveNumber_BY", waveNumber);
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while planning wave in BY UI", e);
		}
	}
	
	
	@Step
	public void validatePlannedWaveIsSuccessful() {
		
		try {
			
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			currentWaveNumber_BY = getCurrentWaveNumberInBY();
			
			uiActionsHelper.sync(driver, byReceivingPage.shipmentRecordBasedOnSpecificValue(currentWaveNumber_BY));
			Assert.assertTrue(ErrorCodes.CATALYST_WRONG_WAVE_RECORD, byReceivingPage.shipmentRecordBasedOnSpecificValue(currentWaveNumber_BY).isDisplayed());
			logger.info("Proper wave number {} got filtered successfully !", currentWaveNumber_BY);
			
			
			byReceivingPage.clickOnShipmentRecordLink(currentWaveNumber_BY);
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			verifyWaveStatusInBY_Wave_PicksTab("Planned");
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating planned wave in BY UI", e);
		}
	}
	
	@Step
	public void allocateWave() {
		
		try {
			
			byOutboundPage.selectOptionsFromActionsDropdown_waveSpecific("Allocate Wave");
			byOutboundPage.selectChechboxUnderAllocateWavePopup("Each");
			byOutboundPage.selectChechboxUnderAllocateWavePopup("Case");
			byOutboundPage.selectChechboxUnderAllocateWavePopup("Pallet");
			byOutboundPage.clickButtonByText("OK");
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while allocating wave in BY UI", e);
		}
	}
	
	
	public String getCurrentLoadIDInBY() {
		
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		List<String> loadId_BY = JsonPath.read(runTimeData, BY_LOADID_JSONPATH);
		logger.info("Fetched BY_LoadID from testflowdata is {} ", loadId_BY.get(0));
		return loadId_BY.get(0);
	}
	
	
	public String getCurrentWaveNumberInBY() {
		
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		List<String> waveNumber_BY = JsonPath.read(runTimeData, BY_WAVE_NUMBER_JSONPATH);
		logger.info("Fetched BY_WaveNumber from testflowdata is {} ", waveNumber_BY.get(0));
		return waveNumber_BY.get(0);
	}
	
	
	@Step
	public void validateAllocatedWaveIsSuccessful(String expectedWaveStatus) {
		
		try {
			
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			verifyWaveStatusInBY_Wave_PicksTab(expectedWaveStatus);
			logger.info("Verified wave is allocated successfully ======");
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating allocated wave in BY UI", e);
		}
		
	}
	
	
	@Step
	public void validateAllocatedPercentage() {
		
		try {
			
			String allocationPercentage = byOutboundPage.getWaveActivityPercentage("Allocated");
			logger.info("Shown load value : {}", allocationPercentage);
			Assert.assertEquals(ErrorCodes.CATALYST_WRONG_WAVE_ALLOCATION_PERCENTAGE, true, allocationPercentage.contains("100"));
			logger.info("Verified wave allocated percentage as 100 successfully ======");
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating allocated wave percentage in BY UI", e);
		}
		
	}
	
	

	@Step
	public void releaseWave() {
		
		try {
			
			byOutboundPage.clickOnMentionedTabGridForSpecificWave("Picks");
			byOutboundPage.selectCheckboxForPicksRecord();
			byOutboundPage.selectOptionsFromPicksGridActionsDropdown("Release Picks");
			
			if(byOutboundPage.getOKButtonUnderReleasePicksPopup()) {
				String failedCountInReleasePicksconfirmationPopup = byOutboundPage.getFailedCountUnderReleasePickPopup();
				logger.info("Failed count in popup: {}", failedCountInReleasePicksconfirmationPopup);
				
				Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_TASK_COUNT_FOR_PICKS_GRID, true, failedCountInReleasePicksconfirmationPopup.contains("0"));
				logger.info("Validated failed count as {} in release pick popup successfully!!", failedCountInReleasePicksconfirmationPopup);
				
				byOutboundPage.clickOKButtonUnderReleasePicksPopup();
				logger.info("Released the wave successfully !!");
			}
			
			else {
				byOutboundPage.clickButtonByText("OK");
				logger.info("Wave has been released with scheduled job before clicking on release picks !!");
			}
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while releasing wave in BY UI", e);
		}
		
		
	}

	
	@Step
	public void validateWaveStatus(String expectedWaveStatus) {
		
		try {
			
			Failsafe.with(retryPolicy).run(() -> {
				
				byOutboundPage.clickRefreshIconForDifferentOutboundTabs("picks");
				
				//fetching wave status
				String waveStatus = byOutboundPage.getWaveStatus();
				logger.info("Wave status in BY: {}", waveStatus);
				
				Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_WAVE_STATUS, expectedWaveStatus, waveStatus);
				logger.info("Validated wave status as {} successfully!!", expectedWaveStatus);
				
			});
			
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating wave status in BY UI", e);
		}
		
		
	}
	
	public void verifyWaveStatusInBY_Wave_PicksTab(String expectedWaveStatus) {
		
		Failsafe.with(retryPolicy).run(() -> {
			
			//fetching wave status
			String waveStatus = byOutboundPage.getWaveStatus();
			logger.info("Wave status in BY: {}", waveStatus);
			
			Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_WAVE_STATUS, expectedWaveStatus, waveStatus);
			logger.info("Validated wave status as {} successfully!!", expectedWaveStatus);
		});
		
	}

	@Step
	public void verifyWorkAssignmentUnderPicksTab() {
		
		try {
			
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			
			validateGeneratedPicksTaskCount();
			uiActionsHelper.sync(getDriver(), byOutboundPage.workAssignmentLinkUnderPicksRecord);
			Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_TASK_COUNT_FOR_PICKS_GRID, true, byOutboundPage.workAssignmentLinkUnderPicksRecord.isDisplayed());
			logger.info("Validated work assignment under picks task successfully =====");
			
			//Fetching source and destination for picks generated and storing in testflowdata
			String source = byOutboundPage.getColumnValueUnderPicksGrid("Source");
			String destination = byOutboundPage.getColumnValueUnderPicksGrid("Destination");
			String operationNumber = byOutboundPage.getOperationColumnTextUnderPicksGrid();
			logger.info("Source : {} , Destination : {} and Opetaion : {} for picks generated", source, destination, operationNumber);
			
			byUiHelper.updateTestFlowDataForOutboundDetails("sourceLocationForPicking", source);
			byUiHelper.updateTestFlowDataForOutboundDetails("destinationLocationForPicking", destination);
			byUiHelper.updateTestFlowDataForOutboundDetails("operationNumForPicking", operationNumber);
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying work assignement under picks tab in BY UI", e);
		}
		
	}
	
	
	public void validateGeneratedPicksTaskCount() {
		
		String picksCount = byOutboundPage.getTaskCountForSpecificTabGrid("Picks");
		logger.info("Task count for Picks grid is : {}", picksCount);
		Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_TASK_COUNT_FOR_PICKS_GRID, "1", picksCount);
		logger.info("Validated picks task count as {} successfully!!", picksCount);
		
	}	
	
}
