package com.walmart.supplychain.thor.receiving.steps;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.thor.CreateTote;
import com.walmart.framework.supplychain.domain.thor.POStatus;
import com.walmart.framework.supplychain.domain.thor.StatusRequest;
import com.walmart.framework.supplychain.domain.thor.ThorReceiving;
import com.walmart.framework.supplychain.domain.thor.ToteDetail;
import com.walmart.framework.supplychain.domain.thor.ToteIterator;
import com.walmart.framework.supplychain.domain.thor.WAC;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACCMongoSteps;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.acc.docktag.steps.mobile.DockTagHelper;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.dcfin.scenariosteps.db.DcFinSteps;
import com.walmart.supplychain.thor.podetails.pages.ThorTokenPage;
import com.walmart.supplychain.thor.podetails.steps.webservices.ThorHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ThorReceivingStep {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_LABEL_COLLECTION = "deliverydocumentsbylpns";
	private static final String MONGO_SCHEMA = "receive";
	private static final String GET_TOTE_EP = "create_tote_url";
	private static final String CHANGE_PO_STATUS_EP = "status_change_url";
	private static final String THOR_RECEIVING = "thor_receiving";
	private static final int TOTE_DIMENSION = 1000;
	private static final String TOTE_AREACODE = "T";
	private static final String TOTE_AREANAME = "Tote";
	private static final int TOTE_INCREMENT = 1;
	private static final String EXPIRATION_DATE = "2020-05-20T23:59:59-04:00";
	private static final String LPNID = "LPJ1235";
	private static final String RECEIVING_STATION = "R1";
	private static final String THOR_PO_DETAILS = "thor_po_details";
	private static final String DELIVERED_STATUS = "Delivered";
	private static final String CLOSED_STATUS = "Closed";
	private static final String PENDING_ISSUE = "Pending";
	private static final String RESOLVED_ISSUE = "Resolved";
	private static final String GET_WAC_EP = "get_wac_url";
	private static final String BASE_DIV_CODE = "WM";
	private static final String FINANCIAL_REPORTING_GROUP_CODE = "US";
	private static final String BALANCEONHAND = "$.foundItemsCostDetail[*].balanceOnHandQuantity";
	private static final String WAREHOUSECOST = "$.foundItemsCostDetail[*].weightedAverageCost";
	private static final String SECURITY_URL = "security_token_url";
	private static final String THOR_USER = "thor_user";
	private static final String THOR = "thor";
	private static DecimalFormat df = new DecimalFormat("0.0000");
	DecimalFormat round = new DecimalFormat("0.00"); //Make new decimal format
	
	List itemLabelList = null;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired(required = true)
	ThorHelper thorHelper;

	@Autowired
	Environment environment;

	Response response;

	@Autowired
	JavaUtils javaUtil;

	ThorTokenPage thorTokenPage;

	ObjectMapper om = new ObjectMapper();

	@Steps
	DcFinSteps dcfinStep;

	@Autowired
	PreRunCleanup preRunCleanup;

	@Step
	public void receiveThorSKUs() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List newpoList = new ArrayList();
			for (PoDetail poDetail : poList) {
				String thorPO = poDetail.getThorPO();
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				
				List newPoLineList = new ArrayList();
				for (PoLineDetail polineDetail : poLineList) {
					String thorSKU = polineDetail.getThorSKU();
					int qty = Integer.parseInt(polineDetail.getPoVnpkQty()) * Integer.parseInt(polineDetail.getVnpk());
					Map wacMap = getWAC(polineDetail.getItemNumber());
					double wacDB = (double) wacMap.get("wac");
					int oldboh = (int) wacMap.get("boh");
					int boh = (int) wacMap.get("boh") + qty;
					double wac = ((wacDB * oldboh) + (qty * Double.parseDouble(polineDetail.getWhpkSellPrice())))
							/ (oldboh + qty);
//					wac = Double.parseDouble(round.format(wac));
					df.setRoundingMode(RoundingMode.UP);
					wac = Double.parseDouble(df.format(wac));
					String tote = getNewTote();
					ThorReceiving receiving = new ThorReceiving();
					receiving.setExpirationDate(EXPIRATION_DATE);
					receiving.setLpnId(LPNID);
					receiving.setPurchaseOrderId(Integer.parseInt(thorPO));
					receiving.setReceivingStationId(RECEIVING_STATION);
					receiving.setThorSku(thorSKU);
					receiving.setTotalUnitCount(qty);
					receiving.setReceivingIntoLocationId(tote);

					logger.info("Thor Receiving payload:" + objectMapper.writeValueAsString(receiving));
					logger.info("Thor receiving url:" + environment.getProperty(THOR_RECEIVING));

					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
									environment.getProperty(THOR_USER), environment.getProperty(THOR), false))
							.body(om.writeValueAsString(receiving)).when()
							.post(environment.getProperty(THOR_RECEIVING));
					Assert.assertEquals(ErrorCodes.THOR_RECEIVING, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());

					ReceivingInstruction recv = new ReceivingInstruction();
					List receivingInstructionList = new ArrayList();
					recv.setReceivedQuantity(String.valueOf(qty));
					recv.setTote(tote);
					receivingInstructionList.add(recv);
					polineDetail.setReceivingInstructions(receivingInstructionList);
					polineDetail.setBoh(boh);
					polineDetail.setWac(wac);
					newPoLineList.add(polineDetail);
				}
				poDetail.setPoLineDetails(poLineList);
				newpoList.add(poDetail);
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newpoList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after publishing the Receiving Receipts::{}", tl.get().get(TEST_FLOW_DATA));
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Receive Thor SKUs", e);
		}

	}

	public String getNewTote() {
		int randonToteNum = javaUtil.randonNumberGenerator(5);
		try {

			ToteDetail detail = new ToteDetail();
			detail.setAvailableForReplen(true);
			detail.setAvailableForSale(true);
			detail.setDepth(TOTE_DIMENSION);
			detail.setHeight(TOTE_DIMENSION);
			detail.setWidth(TOTE_DIMENSION);

			ToteIterator iterator = new ToteIterator();
			iterator.setAreaCode(TOTE_AREACODE);
			iterator.setAreaName(TOTE_AREANAME);
			iterator.setPositionIncrement(TOTE_INCREMENT);
			iterator.setAreaStart(randonToteNum);
			iterator.setAreaThrough(randonToteNum);

			CreateTote tote = new CreateTote();
			tote.setDetail(detail);
			tote.setIterator(iterator);
			
			logger.info("Create tote url:"+environment.getProperty(GET_TOTE_EP));
			logger.info("Create tote body:"+om.writeValueAsString(tote));

			//Disabled Proxy
			System.setProperty("java.net.useSystemProxies", "false");
			response = given().relaxedHTTPSValidation()
					.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
							environment.getProperty(THOR_USER), environment.getProperty(THOR), false))
					.body(om.writeValueAsString(tote)).when().post(environment.getProperty(GET_TOTE_EP));
			Assert.assertEquals(ErrorCodes.THOR_CREATE_TOTE, Constants.CREATE_SUCESS_STATUS_CODE,
					response.getStatusCode());
			//Enabled Proxy
			System.setProperty("java.net.useSystemProxies", "true");
		} catch (Exception e) {
			throw new AutomationFailure("Failed to create Thor Tote", e);
		}
		return TOTE_AREACODE + randonToteNum;
	}

	public void preCleanUpForThor(String itemNbr) {
		try {
			dcfinStep.deleteThorDCFIN(itemNbr);
			preRunCleanup.cleanUpDCFINWACForItemThor(Integer.parseInt(itemNbr));
		} catch (Exception e) {
			throw new AutomationFailure("Failed to do Thor cleanup", e);
		}

	}

	public void changePOStatus(String poStatus) {
		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPo = JsonPath.read(testData, GET_PONUMBERS);
			String poString = listOfPo.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			for (PoDetail poDetail : poList) {
				String thorPO = poDetail.getThorPO();

				StatusRequest request = new StatusRequest();
				if (poStatus.equals(DELIVERED_STATUS)) {
					request.setFcIssues(PENDING_ISSUE);
					request.setScIssues(PENDING_ISSUE);
					request.setSkuIssues(PENDING_ISSUE);
					request.setVendorIssues(PENDING_ISSUE);
					request.setPoStatus(DELIVERED_STATUS);
					request.setSmallParcel(false);
				} else if (poStatus.equals(CLOSED_STATUS)) {
					request.setFcIssues(RESOLVED_ISSUE);
					request.setScIssues(RESOLVED_ISSUE);
					request.setSkuIssues(RESOLVED_ISSUE);
					request.setVendorIssues(RESOLVED_ISSUE);
					request.setPoStatus(CLOSED_STATUS);
					request.setSmallParcel(false);
				}
				POStatus status = new POStatus();
				status.setPoNumber(Integer.parseInt(thorPO));
				status.setPoStatusUpdateRequest(request);
				logger.info("po status change body:" + om.writeValueAsString(status));
				logger.info("change po status url:" + environment.getProperty(CHANGE_PO_STATUS_EP));

				response = given().relaxedHTTPSValidation()
						.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
								environment.getProperty(THOR_USER), environment.getProperty(THOR), false))
						.body(om.writeValueAsString(status)).when().post(environment.getProperty(CHANGE_PO_STATUS_EP));
				Assert.assertEquals(ErrorCodes.THOR_STATUS_CHANGE, Constants.UPDATE_SUCESS_STATUS_CODE,
						response.getStatusCode());
				Failsafe.with(retryPolicy).run(() -> {
					response = given().relaxedHTTPSValidation()
							.headers(thorTokenPage.getAuthenticationHeader(environment.getProperty(SECURITY_URL),
									environment.getProperty(THOR_USER), environment.getProperty(THOR), false))
							.when().get(environment.getProperty(THOR_PO_DETAILS) + thorPO);
					Assert.assertEquals(ErrorCodes.THOR_PO_DETAILS, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					Object thorStatus = JsonPath.read(response.asString(), "status");
					Assert.assertEquals(ErrorCodes.THOR_STATUS_CHANGE, poStatus, thorStatus);
				});
			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to change the PO status", e);

		}
	}

	public Map getWAC(String itemNbr) {
		Map wacMap = new HashMap();
		try {
			WAC wac = new WAC();
			List wacList = new ArrayList();
			wac.setBaseDivCode(BASE_DIV_CODE);
			wac.setFinancialReportingGroupCode(FINANCIAL_REPORTING_GROUP_CODE);
			wac.setItemNumber(itemNbr);
			wacList.add(wac);
			logger.info("wac body:" + om.writeValueAsString(wacList));
			logger.info("wac url:" + environment.getProperty(GET_WAC_EP));
			Failsafe.with(retryPolicy).run(() -> {
				response = given().relaxedHTTPSValidation().headers(thorHelper.getDCFINHeaders())
						.body(om.writeValueAsString(wacList)).when().post(environment.getProperty(GET_WAC_EP));
				if (response.getStatusCode() == Constants.SUCESS_STATUS_CODE) {
					logger.info(response.asString());

					JSONArray bohArray = JsonPath.read(response.asString(), BALANCEONHAND);
					String bohString = bohArray.toJSONString();
					List<String> bohList = objectMapper.readValue(bohString, new TypeReference<List<String>>() {
					});

					JSONArray wacArray = JsonPath.read(response.asString(), WAREHOUSECOST);
					String wacString = wacArray.toJSONString();
					List<String> wacListDB = objectMapper.readValue(wacString, new TypeReference<List<String>>() {
					});
					String boh = bohList.get(0);
					String wacDB = wacListDB.get(0);
					wacMap.put("wac", Double.parseDouble(wacDB));
					wacMap.put("boh", Integer.parseInt(boh));
				} else {
					wacMap.put("wac", 0.0);
					wacMap.put("boh", 0);
				}
			});
		} catch (Exception e) {
			throw new AutomationFailure("Failed to get WAC and BOH", e);
		}
		return wacMap;
	}

}