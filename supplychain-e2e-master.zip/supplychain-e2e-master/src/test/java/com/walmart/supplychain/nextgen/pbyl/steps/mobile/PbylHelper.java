package com.walmart.supplychain.nextgen.pbyl.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes={SpringTestConfiguration.class})
public class PbylHelper {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtils;
	
	@Autowired
	JavaUtils javaUtils;
	
	@Autowired
	private ObjectMapper objmapper;
	
	@Autowired
	Environment environment;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String PLANNEDLOCATION_JSONPATH ="$..fulfillmentUnits[?(@.fulfillmentUnitStatus!='DELETED'&&@.plannedLocation == '";
	private static final String PO_NUMBER_JSONPATH ="$.testFlowData.poDetails[?(@.poNumber == '";
	private static final String PARENT_LEVEL_STATUS_JSON_PATH="$.fulfillmentSearchOnReceiveContainer[*].fulfillmentStatus";
	private static final String PBYL_DESTINATION="pbyl_destination";
	private static final int TOTAL_NO_OF_LOADS_REQUIRED=2;
	private static final String OVERAGE_KEY_JSONPATH="$..excessWhpkCount";
	private static final String CHILD_CONTAINER_KEY_JSONPATH_FOR_LABEL_PRINTED_SLOT="$..fulfillmentUnits[?(@.fulfillmentUnitStatus==\"LABEL_PRINTED\"&&@.plannedLocation==\"#0#\")].destCtnrTrckgId";
	private static final String CHILD_CONTAINER_KEY_JSONPATH_FOR_SLOT="$..fulfillmentUnits[?(@.fulfillmentUnitStatus!=\"DELETED\"&&@.plannedLocation==\"#0#\")].destCtnrTrckgId";
	private static final String ALL_CHILD_CONTAINERS_KEY_JSONPATH_FOR_TRIP="$..fulfillmentUnits[?(@.fulfillmentUnitStatus!=\"DELETED\")].destCtnrTrckgId";
	private static final String CHILD_CONTAINER_STATUS_KEY_JSONPATH="$..fulfillmentUnits[?(@.destCtnrTrckgId=='#0#')].fulfillmentUnitStatus";
	private static final String CHILD_CONTAINER_PLANNED_LOCATION_KEY_JSONPATH="$..fulfillmentUnits[?(@.destCtnrTrckgId=='#0#')].plannedLocation";
	public Set<String> getDistinctSlots(String ofresponse) {
		JSONArray slotDetails = JsonPath.read(ofresponse,
				"$.fulfillmentSearchOnReceiveContainer[*].fulfillmentUnits[?(@.fulfillmentUnitStatus!='DELETED')].plannedLocation");
		Set<String> disctinctSlots = new HashSet<>();
		for (int i = 0; i < slotDetails.size(); i++) {
			disctinctSlots.add(slotDetails.get(i).toString());
		}
		logger.info("Distinct Slots are :{}", disctinctSlots);
		return disctinctSlots;
	}
	public String ofServiceResponseForLpn(String inductPallet) {

		String ofResponse = null;
		
		String ofPbylUrl = MessageFormat.format(environment.getProperty("of_pbyl_ep"), inductPallet);

		Response response;
		if(Config.DC==DC_TYPE.ATLAS) {
			response= given().relaxedHTTPSValidation().headers(getAtlasHeaders()).accept("application/json").contentType("application/json").get(ofPbylUrl);
		}else {
			response= given().accept("application/json").contentType("application/json").get(ofPbylUrl);
		}

		ofResponse = response.getBody().asString();
		logger.info("ofResponse {}",ofResponse);
		return ofResponse;
	}
	public String ofInductLabelStatus(String inductPallet) {
		String response=ofServiceResponseForLpn(inductPallet);
		List<String> statusArr=JsonPath.read(response, PARENT_LEVEL_STATUS_JSON_PATH);
		return statusArr.get(0);
	}
	
	public void createInstrcutionObject(String inductPallet, String poNumber,String itemNumber) {
		String testFlowData = String.valueOf(threadLocal.get().get(TEST_FLOW_DATA));
		String ofServiceResponseForLpn;
		ReceivingInstruction recInstruction = null;
		objmapper.enable(SerializationFeature.INDENT_OUTPUT);
		JSONArray receivingInstructionArray=null;
		receivingInstructionArray=JsonPath.read(testFlowData, PO_NUMBER_JSONPATH + poNumber + "')].poLineDetails[?(@.itemNumber=="+ itemNumber +")].receivingInstructions[*]");
		logger.info("InductPallet in instruction object::{}",inductPallet);
		JSONArray childContainersJsonArray;
		JSONArray destinationArray;
		JSONArray messageIdArray;
		JSONArray channelTypeArray;
		JSONArray plannedQtyArray;
		int receivedQty = 0;
		ofServiceResponseForLpn=ofServiceResponseForLpn(inductPallet);
		Set<String> distinctSlots = getDistinctSlots(ofServiceResponseForLpn);
		List<String> slots= new ArrayList<>();
		for(String slot:distinctSlots)
		{
			slots.add(slot);
		}
		for(int i=0;i<slots.size();i++) {
			List<String> childContainers = new ArrayList<>();
			childContainersJsonArray = JsonPath.read(ofServiceResponseForLpn,
					PLANNEDLOCATION_JSONPATH+ slots.get(i) +"')].destCtnrTrckgId");
			destinationArray = JsonPath.read(ofServiceResponseForLpn,
					PLANNEDLOCATION_JSONPATH+ slots.get(i) +"')].destBUNumber");
			messageIdArray = JsonPath.read(ofServiceResponseForLpn,
					PLANNEDLOCATION_JSONPATH+ slots.get(i) +"')].fulfillmentId");
			channelTypeArray = JsonPath.read(ofServiceResponseForLpn,
					PLANNEDLOCATION_JSONPATH+ slots.get(i) +"')].outboundChannelMethod");
			plannedQtyArray = JsonPath.read(ofServiceResponseForLpn,
					PLANNEDLOCATION_JSONPATH+ slots.get(i) +"')].plannedQty");
			recInstruction= new ReceivingInstruction();
			for (int j = 0; j < childContainersJsonArray.size(); j++) {
				childContainers.add(childContainersJsonArray.get(j).toString());
			}
			recInstruction.setChildContainers(childContainers);
			recInstruction.setDestNumber((String) destinationArray.get(0));
			recInstruction.setChannelType((String) channelTypeArray.get(0));
			recInstruction.setMessageId((String) messageIdArray.get(0));
			recInstruction.setIsShipOut(isShipout(poNumber, recInstruction.getDestNumber()));
			receivedQty=0;
			for (int j = 0; j < plannedQtyArray.size(); j++) {
				receivedQty += (int) plannedQtyArray.get(j);
			}
			recInstruction.setReceivedQuantity(String.valueOf(receivedQty));
			String reUsableContainer="PC"+slots.get(i).substring(slots.get(i).length()-2);
			recInstruction.setParentContainer(reUsableContainer);
			recInstruction.setIsPbyl(false);
			receivingInstructionArray.add(receivingInstructionArray.size(), recInstruction);
			
			JSONArray instructJSONArray;
			try {
				instructJSONArray = jsonUtils.converyListToJsonArray(receivingInstructionArray);
				logger.info("InstructJSONArray::{} ",instructJSONArray);
						String updatedtestflowdata = jsonUtils.setJsonAtJsonPath(testFlowData, instructJSONArray,
								PO_NUMBER_JSONPATH +poNumber + "')].poLineDetails[?(@.itemNumber=="
										+ itemNumber+ ")].receivingInstructions");
						threadLocal.get().put(TEST_FLOW_DATA, updatedtestflowdata);
						logger.info("testData after updating for PO {} and ::{}",poNumber,threadLocal.get().get(TEST_FLOW_DATA));
			} catch (JsonProcessingException e) {
				logger.error(e.toString());
			} catch (ParseException e1) {
				logger.error(e1.toString());
			}
		}
	}
	public boolean isShipout(String poNumber,String dest) {
		List<String> listOfPOAndDestPair=threadLocal.get().get(PBYL_DESTINATION)==null?null:(List<String>)threadLocal.get().get(PBYL_DESTINATION);
		if(listOfPOAndDestPair==null) {
			listOfPOAndDestPair=new ArrayList<>();
			listOfPOAndDestPair.add(poNumber+";"+dest);
			threadLocal.get().put(PBYL_DESTINATION,listOfPOAndDestPair);
		}else {
			boolean isShippout=true;
			for(String keyPair:listOfPOAndDestPair) {
				if(keyPair.contains(poNumber)||keyPair.contains(dest)) {
					isShippout=false;
					logger.info("PO Number:{}/Destination:{} already available in {}",poNumber,dest,keyPair);
					break;
				}
			}
			if(!isShippout) {
				logger.info("Setting isShippout to false");
				return false;//Ship out only one Parent container from each PO
			}else {
				logger.info("Combination of PO Number:{} and Dest:{} is not already available",poNumber,dest);
				logger.info("This combination {} will be shipped out",poNumber+";"+dest);
				listOfPOAndDestPair.add(poNumber+";"+dest);
				threadLocal.get().put(PBYL_DESTINATION,listOfPOAndDestPair);
			}
		}
		return true;
	}
	
	
	public void deleteInventoryforspecificContainer(String lpn) {
		if(Config.DC==DC_TYPE.ATLAS) {
			Response resp=given().relaxedHTTPSValidation().headers(getAtlasHeaders()).delete(environment.getProperty("inventory_ep") + lpn + environment.getProperty("inventory_delete_qp"));
			logger.error("Response code for inventory deletion:{}",resp.getStatusCode());
		}else {
			when().delete(environment.getProperty("inventory_ep") + lpn + environment.getProperty("inventory_ep_qp"));
		}
	}
	
	public int getInventoryforspecificContainer(String lpn) {
		if(Config.DC==DC_TYPE.ATLAS) {
			return given().relaxedHTTPSValidation().headers(getAtlasHeaders()).get(environment.getProperty("inventory_ep") + lpn + environment.getProperty("inventory_ep_qp")).andReturn().statusCode();
		}else {
			return when().get(environment.getProperty("inventory_ep") + lpn + environment.getProperty("inventory_ep_qp")).andReturn().statusCode();
		}
	}
	public Headers getAtlasHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum",environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		return new Headers(headerList);
	}
	public int getOverageCount(String inductPallet) {
		String ofResponse = ofServiceResponseForLpn(inductPallet);
		List<Integer> overageVal=JsonPath.read(ofResponse, OVERAGE_KEY_JSONPATH);
		if(overageVal.isEmpty())
			return -1;
		return overageVal.get(0);
	}
	public List<String> getLabelPrintedContainersForSlot(String ofResponse,String slot) {
		String jsonPath=javaUtils.format(CHILD_CONTAINER_KEY_JSONPATH_FOR_LABEL_PRINTED_SLOT,slot);
		List<String> childContainers=JsonPath.read(ofResponse, jsonPath);
		logger.info("List of containers planned for Slot:{} ==>{}",slot,childContainers);
		return childContainers;
	}
	public List<String> getAllChildContainersForTrip(String ofResponse) {
		List<String> childContainers=JsonPath.read(ofResponse, ALL_CHILD_CONTAINERS_KEY_JSONPATH_FOR_TRIP);
		logger.info("List of child containers ==>{}",childContainers);
		return childContainers;
	}
	public String getFulfillmentUnitStatus(String ofResponse,String childContainer) {
		String jsonPath=javaUtils.format(CHILD_CONTAINER_STATUS_KEY_JSONPATH,childContainer);
		List<String> statusVal=JsonPath.read(ofResponse, jsonPath);
		if(statusVal.isEmpty()) {
			return "";
		}
		logger.info("Container:{} status ==>{}",childContainer,statusVal.get(0));
		return statusVal.get(0);
	}
	public String getSlotForCase(String ofResponse,String childContainer) {
		String jsonPath=javaUtils.format(CHILD_CONTAINER_PLANNED_LOCATION_KEY_JSONPATH,childContainer);
		List<String> slotVal=JsonPath.read(ofResponse, jsonPath);
		String slotName=slotVal.get(0);
		logger.info("Slot planned for Container:{} ==>{}",childContainer,slotName);
		return slotName;
	}
	public List<String> getChildContainerIdsForSlot(String ofResponse,String slotName) {
		String jsonPath=javaUtils.format(CHILD_CONTAINER_KEY_JSONPATH_FOR_SLOT,slotName);
		List<String> childContainerIds=JsonPath.read(ofResponse, jsonPath);
		logger.info("Child container Ids for Slot:{} ==>{}",slotName,childContainerIds);
		return childContainerIds;
	}
	
	}
