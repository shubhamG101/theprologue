package com.walmart.supplychain.catalyst.by.ui.pages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.framework.utilities.selenium.UiActionsHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYReceivingPage extends SerenityHelper {
	
	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;
	
	@Autowired
	Environment endPoint;
	
	@Autowired
	UiActionsHelper uiActionsHelper;
	

	@Autowired
	CatalystUtil catalystUtil;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	
	//  #######   For BY Home page ####################################################
	
	
	@FindBy(xpath = "//div[contains(@id,'header')]//span[contains(@id,'ext-comp')][contains(@id,'Inner')]")
	public WebElement userRoleText;	
	
	
	@FindBy(xpath = "//a[contains(@class,'top-level')]")
	private WebElement byMenuDropdownIcon;
	
	@FindBy(xpath = "//div[@role='presentation'][text()='Loading']")
	public WebElement loadingIndicator;
	
	
	@FindBy(xpath = "//iframe[contains(@name,'wm.appointments')]")
	public WebElement workingFrame;
	

	
	
	
	
	
	private WebElement menuItem_BY(String menuItem) {
		return getDriver().findElement(By.xpath("//a[contains(@id,'menuitem')][normalize-space()='"+menuItem+"']")); 
	}
	
	
	private WebElement headerTab_BY(String tabName) {
		return getDriver().findElement(By.xpath("//a[contains(@class,'tab-button')][contains(normalize-space(),'"+tabName+"')]")); 
	}
	
	
	
	
	
	// ########  Actions on page elements   ######
	
	
	public void waitUntillLoadingIndicatorNotVisible() {
		element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
	}
	
	public void clickOnMenuDropdownIcon() throws InterruptedException {
		uiActionsHelper.pageLoadWait(getDriver());
		waitUntillLoadingIndicatorNotVisible();
		uiActionsHelper.sync(getDriver(),element(byMenuDropdownIcon));
		element(byMenuDropdownIcon).waitUntilVisible();
		element(byMenuDropdownIcon).waitUntilClickable();
		element(byMenuDropdownIcon).click();
		//waitUntillLoadingIndicatorNotVisible();
		
	}
	
	public void selectMentionedMenuOption(String menuItem) {
		element(menuItem_BY(menuItem)).waitUntilVisible();
		element(menuItem_BY(menuItem)).click();
		waitUntillLoadingIndicatorNotVisible();
		logger.info("{} menu item is selected==========", menuItem);
	}
	
	public void clickOnMentionedTab(String tabName) {
		waitUntillLoadingIndicatorNotVisible();
		element(headerTab_BY(tabName)).waitUntilVisible();
		element(headerTab_BY(tabName)).click();
		waitUntillLoadingIndicatorNotVisible();
		logger.info("{} tab is clicked==========", tabName);
	}
	
	
//	public void clickOnMenuToggleArrow() {
//		element(clickMenuToggle).waitUntilVisible();
//		element(clickMenuToggle).click();
//		sleep();
//		logger.info("Clicked on menu toggle arrow under inventory tab in BY UI ==========");
//	}
	
	
	
	
	
	
	//   #######   For Inbound shipment page ####################################################
	
	
	
	@FindBy(xpath = "//a[@data-qtip='Delete']/span")
	private List<WebElement> appliedFiltersClearIcon;
	
	@FindBy(xpath = "//span[text()='Inbound Orders']/ancestor::div[contains(@class,'inner')]//input[contains(@id,'Filter')]")
	private WebElement filterBoxUnderInboundShipmentTab;
	
	@FindBy(xpath = "//a[contains(@class,'shipment')]")
	private List<WebElement> poNumbersInBYUi;
	
	@FindBy(xpath = "//td[contains(@class,'templatecolumn')]//span/div[1]")
	private List<WebElement> itemsInBYUi;
	
	@FindBy(xpath = "//div[contains(@id,'inboundloads')]//div[contains(@class,'breadcrumb-button')]/span")
	private WebElement backBtnIconUnderInboundShipmentTab;
	
	@FindBy(xpath = "//div[contains(@id,'inboundloads')]//a[contains(@class,'refresh-embedded')]")
	private WebElement refreshIconUnderInboundShipment;
	
	
	
	
	
	
	
	
	private WebElement filterOptionDropdown(String filterOption) {
		return getDriver().findElement(By.xpath("//span[normalize-space()='"+filterOption+"']")); 
	}
	
	public WebElement shipmentRecordBasedOnSpecificValue(String valueToBeSearched) {
		return getDriver().findElement(By.xpath("//td[contains(normalize-space(),'"+valueToBeSearched+"')]//span")); 
	}
	
	public WebElement inboundShipment_Equipment_Status(String fieldName) {
		return getDriver().findElement(By.xpath("//span[contains(normalize-space(),'"+fieldName+"')]/following-sibling::span")); 
	}
	
	
	
	
	
	// ##### Actions on page elements   ########
	
	

	public void clickOnAppliedFiltersClearIcon() {
		
		sleep();
		int numberOfFiltersApplied = appliedFiltersClearIcon.size();
		logger.info("number of filters applied: {}", numberOfFiltersApplied);
		
		for(int i=0; i<numberOfFiltersApplied; i++) {
			element(appliedFiltersClearIcon.get(0)).waitUntilVisible();
			appliedFiltersClearIcon.get(0).click();
			waitUntillLoadingIndicatorNotVisible();
		}
		
		logger.info("Cleared the applied filters ==========");
		
	}
	
	public void enterValueUnderFilterBox(String shipmentNumber) {
		
		element(filterBoxUnderInboundShipmentTab).waitUntilVisible();
		element(filterBoxUnderInboundShipmentTab).sendKeys(shipmentNumber);		//entering shipment number in filter box
		element(filterBoxUnderInboundShipmentTab).click();
		logger.info("Entered the shipment number in filter box ==========");
	}
	
	public void selectFilterOptionDropdown(String filterOption) {
		
		sleep();
//		element(filterOptionDropdown(filterOption)).waitUntilVisible();
		uiActionsHelper.scrollToElement(filterOptionDropdown(filterOption));
		element(filterOptionDropdown(filterOption)).click();
		waitUntillLoadingIndicatorNotVisible();
		logger.info("Selected appropiate filter option from dropdown ==========");
	}
	
	public void clickOnShipmentRecordLink(String shipmentNumber) {
		
		uiActionsHelper.sync(getDriver(), shipmentRecordBasedOnSpecificValue(shipmentNumber));
		shipmentRecordBasedOnSpecificValue(shipmentNumber).click();
		waitUntillLoadingIndicatorNotVisible();
		logger.info("Clicked on {} filtered record link ==========", shipmentNumber);
	}
	
	public List<WebElement> getPoNumbers(){
		return poNumbersInBYUi;
	}
	
	public List<WebElement> getItemNumbers(){
		return itemsInBYUi;
	}
	
	public void clickOnBackButtonIconUnderShipmentTab() {
		element(backBtnIconUnderInboundShipmentTab).waitUntilVisible();
		element(backBtnIconUnderInboundShipmentTab).click();
		sleep();
		logger.info("Clicked on back button under shipment tab in BY UI ==========");
	}
	
	
	public void clickOnRefreshIconUnderShipmentPage() {
		waitUntillLoadingIndicatorNotVisible();
		element(refreshIconUnderInboundShipment).waitUntilVisible();
		element(refreshIconUnderInboundShipment).waitUntilClickable();
		element(refreshIconUnderInboundShipment).click();
		waitUntillLoadingIndicatorNotVisible();
		logger.info("Clicked on refresh icon under shipment tab in BY UI ==========");
	}
	
	
	
	
	
	//  #######   For Door Activity page ####################################################
	
	public List<WebElement> specificTrailerBasedOnDoorOrYardLocation(String location) {
		return getDriver().findElements(By.xpath("//tr[contains(@id,'"+location+"')]//div[@class='outer']")); 
	}
	
	
	public WebElement specificTralierTagsBaesOnDoorLocation(String doorLocation,String trailerNumber, String tagName) {
		return getDriver().findElement(By.xpath("//tr[contains(@id,'"+doorLocation+"')]//div[@class='outer'][contains(normalize-space(),'"+trailerNumber+"')]/../../following-sibling::div//span[normalize-space()='"+tagName+"']")); 
	}
	
	
	// ######################################## For Inventory page Elements ####################################################

		@FindBy(xpath = "//div[contains(@id,'inventorydisplay_header')]//span[contains(text(),'Inventory')]")
		private WebElement inventoryHeader;

		@FindBy(xpath = "//div[contains(text(),'Hold')]")
		private WebElement tagHold;

		@FindBy(xpath = "//span[text()='Actions']/../../../../a[contains(@id,'wmMultiViewActionButton')]")
		private WebElement actionsButton;

		@FindBy(xpath = "//span[contains(text(),'Release Hold')]/../../a")
		private WebElement releaseHold;

		@FindBy(xpath = "//div[contains(@id,'wm-common-holdsoperations-holdsGrid')]//tr[contains(@id,'record')]/td//div[contains(@class,'x-grid-row-checker')]")
		private WebElement getLpnCheckBox;

		@FindBy(xpath = "//span[text()='Release']/../../..")
		private WebElement releaseHoldButton;

		@FindBy(xpath = "//div[contains(@class,'rp-icon-expanded x-form-arrow-trigger-click x-form-trigger-click')]")
		private WebElement reasonExpandButton;

		@FindBy(xpath = "//td/input[contains(@name,'reasonCode')]")
		private WebElement reasonTextBox;

		@FindBy(xpath = "//div[contains(@id,'wm-holdFormWindow')]//span[contains(text(),'Release Hold')]")
		private WebElement releaseHoldPopup;

		@FindBy(xpath = "//li[contains(text(),'Home Office Directed ')]")
		private WebElement selectHomeOfficeDirectedOption;

//		@FindBy(xpath = "//a[contains(@class,'x-btn x-unselectable rp-important-btn')]//span[contains(text(),'OK')]")
		@FindBy(xpath = "//a[contains(@class,'x-btn x-unselectable rp-important-btn')]//span[contains(text(),'OK')]/../../..")
		private WebElement releaseHoldOkButton;

		@FindBy(xpath = "//div[contains(@class,'x-window wm-InventoryAdjustmentWithoutFailures x-layer x-window-default x-border-box rp-floating rp-shadow-sides')]//span[text()='Results']")
		private WebElement resultPopup;

		@FindBy(xpath = "//div[contains(@id,'container')]/label[text()='Hold released for 1 LPNs successfully.']")
		private WebElement verifyHoldReleaseSuccess;

		@FindBy(xpath = "//div[contains(@class,'rp-icon-expanded x-form-arrow-trigger-click x-form-trigger-click')]")
		private WebElement releaseHoldPopupDropdownButton;

		// ######################################## For Inventory page Generic Methods ####################################################

		private WebElement inputFilterBox(String tabName) {
			return getDriver()
					.findElement(By.xpath("//div[contains(@id,'" + tabName + "')]//input[contains(@id,'Filter')][@style]"));
		}

		public WebElement inputTabByText(String tabName) {
			
			logger.info("Clicking on Tab {}",tabName);
			return getDriver()
					.findElement(By.xpath("//span[contains(@id,'btnText')][text()='" + tabName + "']/ancestor::a"));
		}

//		@FindBy(xpath = "//div[normalize-space()='"+lpn+"']/parent::td/preceding-sibling::td/preceding-sibling::td/div/div[contains(@class,'x-grid-row-checker')]");
		public WebElement selectLpnCheckBox(String lpn) {
			return getDriver().findElement(By.xpath("//div[normalize-space()='" + lpn
					+ "']/parent::td/preceding-sibling::td/preceding-sibling::td/div/div[contains(@class,'x-grid-row-checker')]"));
		}

		private WebElement xpathContainsText(String text) {
			return getDriver().findElement(
					By.xpath("//tbody[contains(@id,'rpMultiLevelGridView')]//div[contains(text(),'" + text + "')]"));
		}

		public boolean isElementPresentBasedOnExactText(String elementText) {
			element(xpathContainsText(elementText)).waitUntilVisible();
			if (xpathContainsText(elementText).isDisplayed())
				return true;
			else
				return false;
		}

		public boolean elementPresentBasedOnExactText(String text) {
			List<WebElement> elementList = getDriver().findElements(
					By.xpath("//tbody[contains(@id,'rpMultiLevelGridView')]//div[contains(text(),'" + text + "')]"));
			if (elementList.size() > 0)
				return true;
			else
				return false;
		}

		public WebElement inboundWorkingFrame(String frameName) {
			return getDriver().findElement(By.xpath("//iframe[contains(@name,'wm." + frameName + "')]"));
		}

		public void switchToFrame(String frameName) {
			getDriver().switchTo().frame(inboundWorkingFrame(frameName));
			logger.info("Switched to working frame {} -----> ", frameName);
		}

		// ######################################## For Inventory page Methods ####################################################

		public void verifyInventoryPageHeading() throws InterruptedException {

			// getDriverInstance().switchTo().frame(pageTitleHolds);
//			switchToFrame();
			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			uiActionsHelper.switchToDefaultContent();
			switchToFrame("receiving");
			element(inventoryHeader).waitUntilVisible();
			element(inventoryHeader).waitUntilPresent();
			catalystUtil.verifyElementIsDisplayed(inventoryHeader);
			logger.info(" Verified: Inventory Page Heading ===>");

		}

		public void enterValueUnderFilterTB(String tabName, String fieldName, String value) {

			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(inputFilterBox(tabName)).waitUntilVisible();

				String filterCriteria = fieldName + "=" + value;
				element(inputFilterBox(tabName)).clear();
				element(inputFilterBox(tabName)).sendKeys(filterCriteria + Keys.ENTER);
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				logger.info("Entered the value {} to be filtered in filter box under {} tab ==========", value, fieldName);
			});
		}

		public void clickOnLpnCheckBox(String lpn) {

			element(selectLpnCheckBox(lpn)).waitUntilVisible();
			element(selectLpnCheckBox(lpn)).waitUntilClickable();
			element(selectLpnCheckBox(lpn)).click();

			logger.info("Selected the LPN{} checkbox ==========", lpn);
		}

		public String getHoldTagText() {

			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			WebElement holdElement = getDriver()
					.findElement(By.xpath("//tr[contains(@class,'rpux-tag-container')]//div[contains(text(),'Hold')]"));
			element(holdElement).waitUntilVisible();
			String holdElementText = uiActionsHelper.getElementText(holdElement);
			return holdElementText;
		}

		public void clickOnActionsButton() {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(actionsButton).waitUntilVisible();
				element(actionsButton).waitUntilClickable();
//				uiActionsHelper.switchToDefaultContent();
//				switchToFrameWithElement(switchToQcFrame);
				uiActionsHelper.moveToElementAndClick(actionsButton);
				logger.info("Clicked on Actions Button ==========");
			});
		}

		public void selectReleaseHoldLink() {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(releaseHold).waitUntilVisible();
				element(releaseHold).waitUntilClickable();
				element(releaseHold).click();
				logger.info("Clicked on Release Hold ==========");
			});
		}

		public void selectLpnCheckBox() {

			element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
			element(getLpnCheckBox).waitUntilVisible();
			element(getLpnCheckBox).waitUntilClickable();
			element(getLpnCheckBox).click();
			logger.info("Clicked on LPN Check Box ==========");
		}

		public void clickOnReleaseButton() {

			element(releaseHoldButton).waitUntilVisible();
			element(releaseHoldButton).waitUntilClickable();
			element(releaseHoldButton).click();
			logger.info("Clicked on Release Button ==========");
		}

		public void clickedOnReasonExpandButton(String releaseReason) {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(loadingIndicator).waitUntilNotVisible().withTimeoutOf(120, TimeUnit.SECONDS);
				element(reasonTextBox).waitUntilVisible();
				element(reasonTextBox).waitUntilClickable();
				uiActionsHelper.moveToElementAndClick(reasonTextBox);
				element(reasonTextBox).sendKeys(releaseReason);
				logger.info("Entered text {} on Reason Textbox ==========", releaseReason);
//				element(reasonExpandButton).click();
			});
		}

		public void clickOnDropDownButton() {

			Failsafe.with(retryPolicy).run(() -> {
				element(releaseHoldPopupDropdownButton).waitUntilVisible();
				element(releaseHoldPopupDropdownButton).waitUntilClickable();
				element(releaseHoldPopupDropdownButton).click();
				logger.info("Clicked on Release Hold Drop-Down Button ==========");
			});
		}

		public void verifyReleaseHoldsPopupHeading() {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(releaseHoldPopup).waitUntilVisible();
				element(releaseHoldPopup).waitUntilPresent();
				String releaseHldPopup = element(releaseHoldPopup).getText();
				catalystUtil.verifyElementIsDisplayed(releaseHoldPopup);
				logger.info(" Verified: {} PopUp Heading ===>", releaseHldPopup);
			});
		}

		public void selectHomeOfficeDirectedOption() {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(selectHomeOfficeDirectedOption).waitUntilVisible();
				element(selectHomeOfficeDirectedOption).waitUntilPresent();
				element(selectHomeOfficeDirectedOption).click();
				catalystUtil.verifyElementIsDisplayed(inventoryHeader);
				logger.info("Selected Home Office Directed Option from Drop-down ========== ");
			});
		}

		public void clickOnReleaseHoldOkButton() {

			element(releaseHoldOkButton).waitUntilVisible();
			element(releaseHoldOkButton).waitUntilClickable();
//			element(releaseHoldOkButton).click();
			uiActionsHelper.moveToElementAndClick(releaseHoldOkButton);
			logger.info("Clicked on Release Hold Popup - Ok button ========== ");
		}

		public void verifyResultPopupHeading() {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(resultPopup).waitUntilVisible();
				element(resultPopup).waitUntilPresent();
				catalystUtil.verifyElementIsDisplayed(resultPopup);
				logger.info(" Verified: Result Popup Heading ===>");
			});
		}

		public void verifyHoldReleaseSuccessMessage() {
			
			Failsafe.with(retryPolicy).run(() -> {
				element(verifyHoldReleaseSuccess).waitUntilVisible();
				element(verifyHoldReleaseSuccess).waitUntilPresent();
				catalystUtil.verifyElementIsDisplayed(verifyHoldReleaseSuccess);
				logger.info(" Verified: Hold Release Success Message ===>");
			});
		}
	
	
}
