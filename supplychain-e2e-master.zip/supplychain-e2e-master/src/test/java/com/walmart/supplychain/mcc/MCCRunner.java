/*
 * Please use FeatureList.java to add/remove feature
 */


/*package com.walmart.supplychain.mcc;

import com.walmart.framework.supplychain.constants.FileNames;
import cucumber.api.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(com.walmart.supplychain.CustomSerenityRunner.class)
@CucumberOptions(features= {
		FileNames.DA_CON,
		FileNames.DA_NON_CON,
		FileNames.SSTK,
//		FileNames.VTR,
//		FileNames.DAMAGE,
		FileNames.DA_CON_MANUAL,
		FileNames.DA_NON_CON_MANUAL,
		FileNames.RECEIVE_FULL,
		FileNames.RECEIVE_PARTIAL,
//		FileNames.DA_CON_PBYL
		},monochrome=true,
		glue = { "com.walmart.supplychain.nextgen","com.walmart.supplychain.mcc"})
public class MCCRunner {
	
	@BeforeClass
    public static void executeBeforeAllTests() {

        System.out.println("This will run before all the test features triggered by this runner");
		
    }


    @AfterClass
    public static void executeAfterAllTests() {

        System.out.println("This will run after all the test features triggered by this runner");

    }
	
}
*/