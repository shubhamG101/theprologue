package com.walmart.supplychain.nextgen.yms.steps.db;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.constants.Queries;
import com.walmart.framework.utilities.db.QueryHelper;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

public class YMSSteps extends ScenarioSteps {
	QueryHelper queryHelper;
	PropertyResolver propertyResolver;
	JavaUtils utils;
	Logger logger = LogManager.getLogger(this.getClass());
	@Step
	public void insertDeliveryData(String poNumber, String deliveryNumber) {
		try {
			propertyResolver = new PropertyResolver();
			queryHelper = new QueryHelper();
			utils = new JavaUtils();
			String trailerNumber = "T" + deliveryNumber;
			queryHelper.setQueryParam("del", deliveryNumber);
			queryHelper.setQueryParam("po", "" + poNumber);
			queryHelper.setQueryParam("trailer", trailerNumber);
			//RunTimeData.setInboundTrailer(trailerNumber);
			queryHelper.setQueryParam("date", utils.getCurrentDateAndTime().split("\\s")[0]);
			queryHelper.setQueryParam("dateTime", utils.getCurrentDateAndTime());
			queryHelper.setQueryParam("dc",
					"" + propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number"));
			String queryAppointment = queryHelper.getSQLQueryParam(Queries.YMS_APPOINTMENT_QUERY);
			String queryAppointmentPO = queryHelper.getSQLQueryParam(Queries.YMS_APPOINTMENT_PO_QUERY);
			/*logger.info(queryAppointment);
			logger.info(queryAppointmentPO);
			Informix.establishDbConnection(DBConstants.YMS_INFORMIX_DB);
			Informix.insert(queryAppointment);
			Informix.insert(queryAppointmentPO);
			Informix.closeDbConnection();*/
		} catch (Exception e) {
			Assert.fail("Unable to insert delivery data " + e.getMessage());
			e.printStackTrace();
		}

	}
}
