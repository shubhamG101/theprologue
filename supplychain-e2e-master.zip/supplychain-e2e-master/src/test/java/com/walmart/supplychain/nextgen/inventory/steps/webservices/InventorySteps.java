package com.walmart.supplychain.nextgen.inventory.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import com.walmart.supplychain.nextgen.inventory.pages.web.InventoryWebVtrPage;
import net.minidev.json.parser.ParseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.inventory.VtrMessage;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.nextgen.inventory.pages.mobile.InventoryVtr;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class InventorySteps extends ScenarioSteps {

	private static final long serialVersionUID = 1L;

	@Autowired
	InventoryVtr invPage;

	@Autowired
	InventoryWebVtrPage invWebPage;

	@Autowired
	InventoryHelper inventoryHelper;

	@Autowired
	TextParser textParser;

	@Autowired
	Environment environment;

	@Autowired
	private ObjectMapper objmapper;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	ACLDBSteps aclDBSteps;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	private Response response;
	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);
	// private String runTimeData;
	private static final String ITEM_NR_JSONPATH = "$.testFlowData..poLineDetails[*].itemNumber";
	private static final String CTR_ID_JSONPATH = "$.testFlowData..parentContainer";
	private String lpn = "";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final int DA_QTY_VTR = 1;
	private static final int DA_QTY_DAMAGE = 1;
	private static final String QTY_AFTER_BULK_VTR ="0";
	private static final String TOPIC = "topic";
	private static final String QUEUE = "queue";

	private static final String TOTAL_QTY_PATH = "$.containerInventoryList[0].totalQuantity";
	private static final String ORDERID_PATH = "$..orderId";
	private static final String RECEIVED_QTY_SSTK_AFTER_VTR = "0";
	private static final String RECEIVED_QTY_SSTK_AFTER_DAMAGE = "1";
	private static final String RECEIVED_QTY_DA_AFTER_DAMAGE = "1";

	private static final String INVENTORY_ENDPOINT_KEY = "inventory_ep";
	private static final String INVENTORY_SEARCH_ENDPOINT_KEY = "inventory_search_ep";
	private static final String ITEM_NUMBER_PATH = "$.testFlowData..poLineDetails[?(@.itemNumber ==#0#)].vnpk";
	private static final String PARENT_CONTAINER_PATH = "$.testFlowData..poLineDetails[?(@.itemNumber ==#0#)].receivingInstructions[?(@.isPbyl == false)].parentContainer";
	public static final Map<String, String> destContainerMap = new HashMap<>();
	private static final String LOADING_CONTAINER_ENDPOINT_KEY = "loading_create_cntr_ep";
	private static final String INVENTORY_CHILD_CNTR_PATH = "childContainersList";

	private static final String WITRON_INVENTORY_CONTAINER_ENDPOINT = "witron_inv_container_validation_ep";

	private static final String WITRON_INVENTORY_BOH_ENDPOINT = "witron_inv_boh_validation_ep";
	private static final String INVENTORY_QUERYPARAM_KEY = "inventory_ep_qp";
	boolean retry = false;
	private static final String JSON_FORMAT = "application/json";
	private static final String WORK_IN_PROGRESS = "WORK_IN_PROGRESS";
	private static final String PICKED = "PICKED";
	private static final String MCB_CONTAINER_IN_TESTFLOWDATA_XPATH = "$.testFlowData.outboundDetails.[*].mcbContainerID";
	private static final String CONTAINER_LIST_IN_TESTFLOWDATA_XPATH = "$.testFlowData.poDetails.[*].poLineDetails.[*].receivingInstructions[*].parentContainer";
	private static final String MCB_CONTAINERSTATUS_XPATH = "$..containerInventories[*].containerStatus";
	private static final String MCB_CHILD_CONTAINER_XPATH = "$..childContainerIds[*]";
	private static final String PARENT_CONTAINER_XPATH = "$..parentTrackingId";

	List itemLabelList = null;
	List<Integer> splitQty;
	DocumentContext parsedJson;
	private DocumentContext bohJson;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ObjectMapper objectMapper;

	Response responseInv;

	@Step
	public Response validateAndGetContainerResponse(String lpnId)  {
		try {
			Failsafe.with(retryPolicy).run(() -> {
//				if (Config.isCloud) {
				response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
						.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + lpnId
								+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
//				} else {
//					response = when().get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + lpnId
//							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
//				}
				logger.info("Waiting for Status 200 for Container Id:{}", lpnId);
				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_RESPONSE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				logger.info("Validated the response status returned for the LPN " + lpnId
						+ " in Inventory and response {} ", response.asString());
			});
			return response;
		} 
		catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting inventory response", e);
		}
	}

	@Step
	public void validateAndGetContainerResponseForVTR(String lpnId) {
		inventoryCntrDelete(lpnId, ErrorCodes.INVENTORY_CONTAINER_DELETED_AFTER_VTR);
	}

	@Step
	public void validateAndGetContainerResponseForDamage(String lpnId) {

		inventoryCntrDelete(lpnId, ErrorCodes.INVENTORY_CONTAINER_DELETED_AFTER_DAMAGE);

	}

	@Step
	public void validateDeletedContrForRTC() {
		String testFlowData = String.valueOf(tl.get().get("testFlowData"));

		parsedJson = JsonPath.parse(testFlowData);
		List<String> containerList = parsedJson
				.read("$.testFlowData.poDetails..poLineDetails.[*].receivingInstructions[*].parentContainer");

		for (String cntr : containerList) {
			logger.info("Inventory container to be deleted:{} ", cntr);

			inventoryCntrDelete(cntr, ErrorCodes.INVENTORY_CONTAINER_DELETED_RTC);

		}
	}

	@Step
	public void validateDeletedContrForVTR() {

		List<String> poNumberList = new ArrayList<String>();
		List<String> containerList = new ArrayList<String>();

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));

		parsedJson = JsonPath.parse(testFlowData);

		poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
		for (String poNumber : poNumberList) {

			List<String> poLineNumbers = parsedJson
					.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
			for (String poLineNumber : poLineNumbers) {
				logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

				List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
						+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
						+ "')].receivingInstructions[*].parentContainer");
				logger.info("Pallet count: {} ", contrList.size());

				containerList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
						+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
						+ "')].receivingInstructions[?(@.isVTR == true)].parentContainer");

			}
		}

		for (String cntr : containerList) {
			logger.info("Inventory container to be deleted:{} ", cntr);

			inventoryCntrDelete(cntr, ErrorCodes.INVENTORY_CONTAINER_DELETED_VTR);

		}
	}

	@Step
	public void validateDeletedContrFromPalletCorrection() {

		List<String> poNumberList = new ArrayList<String>();
		List<String> containerList = new ArrayList<String>();

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));

		parsedJson = JsonPath.parse(testFlowData);

		poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
		for (String poNumber : poNumberList) {

			List<String> poLineNumbers = parsedJson
					.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
			for (String poLineNumber : poLineNumbers) {
				logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

				List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
						+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
						+ "')].receivingInstructions[*].parentContainer");
				logger.info("Pallet count: {} ", contrList.size());

				containerList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
						+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
						+ "')].receivingInstructions[?(@.isVTR==true&&@.vtrQty==0)].parentContainer");

			}
		}

		for (String cntr : containerList) {
			logger.info("Inventory container to be deleted:{} ", cntr);

			inventoryCntrDelete(cntr, ErrorCodes.INVENTORY_CONTAINER_DELETED_VTR);

		}
	}

	@Step
	public void validateContainerData() {
		try {

			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray itemNumbers = JsonPath.parse(runTimeData).read(ITEM_NR_JSONPATH);
			for (int itemNrIndex = 0; itemNrIndex < itemNumbers.size(); itemNrIndex++) {
				String itemNumber = (String) itemNumbers.get(itemNrIndex);
				logger.info("Processing Item Number:{}", itemNumber);
				JSONArray vnpkAray = JsonPath.parse(runTimeData).read(javaUtils.format(ITEM_NUMBER_PATH, itemNumber));
				String vnpk = (String) vnpkAray.get(0);

				JSONArray parentCtrAray = JsonPath.parse(runTimeData)
						.read(javaUtils.format(PARENT_CONTAINER_PATH, itemNumber));
				for (int parentCtr = 0; parentCtr < parentCtrAray.size(); parentCtr++) {
					String parentContainer = (String) parentCtrAray.get(parentCtr);
					logger.info("Processing Container:{}", parentContainer);
					String recQtyPath = "$.testFlowData..poLineDetails[?(@.itemNumber ==" + itemNumber
							+ ")].receivingInstructions[?(@.parentContainer ==\"" + parentContainer
							+ "\")].receivedQuantity";
					JSONArray receivedQty = JsonPath.parse(runTimeData).read(recQtyPath);
					int qty = Integer.parseInt(receivedQty.get(0).toString());
					JSONArray channelMethod = JsonPath.parse(runTimeData)
							.read("$.testFlowData..poLineDetails[?(@.itemNumber ==" + itemNumber
									+ ")].receivingInstructions[?(@.parentContainer ==\"" + parentContainer
									+ "\")].channelType");
					String channelType = (String) channelMethod.get(0);
					logger.info("Channel Type:{}", channelType);
					Response responseCtr = validateAndGetContainerResponse(parentContainer);
					if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.ACC) {
						Assert.assertTrue(ErrorCodes.INVENTORY_CONTAINER_VALIDATION, inventoryHelper
								.validateContainerDetails(responseCtr, qty, vnpk, itemNumber, channelType));
					} else if (Config.DC == DC_TYPE.SAMS) {
						Map<String, Object> expectedData = inventoryHelper.getExpectedContainerDetails(parentContainer,
								itemNumber);
						Map<String, Object> actualData = inventoryHelper.getActualContainerDetails(responseCtr,
								itemNumber);
						logger.info("{} Expected Map:{}", parentContainer, expectedData);
						logger.info("{} Actual Map:{}", parentContainer, actualData);
						Assert.assertMaps(ErrorCodes.INVENTORY_CONTAINER_VALIDATION, expectedData, actualData);
					}
				}

			}
			logger.info("Succesfully validated the data of the Inventory Containers/LPNs");
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container data in inventory", e);
		}
	}

	@Step
	public void validateContainerOnHold(String onHold) {
		try {
//			
//			tl.get().put("testFlowData",
//					"{\"testFlowData\":{\"ordersDetails\":[],\"releaseDetails\":[],\"problemDetails\":[],\"poDetails\":[{\"poLineDetails\":[{\"itemNumber\":\"553416891\",\"hi\":\"5\",\"receivingInstructions\":[{\"parentContainer\":\"E32612000020006119\",\"isDamage\":false,\"isPbylTripExecuted\":false,\"isPbyl\":false,\"messageId\":\"b65acce5-9b16-4108-b186-3c252e58c32d\",\"channelType\":\"SSTKU\",\"destNumber\":\"32612\",\"rotateDate\":\"2020-07-01\",\"onHoldStatus\":true,\"vtrQty\":0,\"damageQty\":0,\"vtrContainerOrderIds\":[],\"receivedQuantity\":\"60\",\"isVTR\":false,\"isShipOut\":true,\"salesQty\":0,\"orderIds\":[],\"isGFCS\":false,\"palletHoldQty\":\"60\",\"adjustedQty\":0,\"childContainers\":[]},{\"parentContainer\":\"E32612000020006120\",\"isDamage\":false,\"isPbylTripExecuted\":false,\"isPbyl\":false,\"messageId\":\"abe04b8c-8abd-4e99-8b23-e27dd4c52c45\",\"channelType\":\"SSTKU\",\"destNumber\":\"32612\",\"rotateDate\":\"2020-07-01\",\"onHoldStatus\":false,\"vtrQty\":0,\"damageQty\":0,\"vtrContainerOrderIds\":[],\"receivedQuantity\":\"60\",\"isVTR\":false,\"isShipOut\":true,\"salesQty\":0,\"orderIds\":[],\"isGFCS\":false,\"adjustedQty\":0,\"childContainers\":[]},{\"parentContainer\":\"E32612000020006121\",\"isDamage\":false,\"isPbylTripExecuted\":false,\"isPbyl\":false,\"messageId\":\"0399a873-56ba-4972-be0f-bb29136a703f\",\"channelType\":\"SSTKU\",\"destNumber\":\"32612\",\"rotateDate\":\"2020-07-01\",\"onHoldStatus\":false,\"vtrQty\":0,\"damageQty\":0,\"vtrContainerOrderIds\":[],\"receivedQuantity\":\"60\",\"isVTR\":false,\"isShipOut\":true,\"salesQty\":0,\"orderIds\":[],\"isGFCS\":false,\"adjustedQty\":0,\"childContainers\":[]},{\"parentContainer\":\"E32612000020006122\",\"isDamage\":false,\"isPbylTripExecuted\":false,\"isPbyl\":false,\"messageId\":\"b19ecd11-826a-40ce-ac53-fcd5bb15606b\",\"channelType\":\"SSTKU\",\"destNumber\":\"32612\",\"rotateDate\":\"2020-07-01\",\"onHoldStatus\":false,\"vtrQty\":0,\"damageQty\":0,\"vtrContainerOrderIds\":[],\"receivedQuantity\":\"20\",\"isVTR\":false,\"isShipOut\":true,\"salesQty\":0,\"orderIds\":[],\"isGFCS\":false,\"adjustedQty\":0,\"childContainers\":[]}],\"vnpk\":\"10\",\"whpkSellPrice\":\"13.9\",\"poLineNumber\":\"1\",\"weight\":0.0,\"caseUpc\":\"10715141613053\",\"thorUnitsPer\":0,\"witronItemDetails\":{\"shipGroupId\":\"10010\",\"wareHouseAreaCode\":\"2\",\"wareHouseGroupCode\":\"DD\",\"warehouseRotationTypeCode\":\"3\",\"weight\":\"26.5\",\"receiveDate\":\"2020-07-01\",\"maxWeight\":\"2736.0\",\"xrefId\":\"770286\",\"samePalletIndicator\":\"1\",\"maxCube\":\"75.0\",\"mergeable\":true,\"depth\":\"12.9\",\"outboundStackGroup\":\"Intact\",\"maxHeight\":\"90.0\",\"isMergeable\":true,\"profiledWarehouseArea\":\"OPM\",\"width\":\"12.5\",\"height\":\"14.4\"},\"ti\":\"12\",\"itemUpc\":\"00715141113563\",\"promoInd\":\"N\",\"poVnpkQty\":\"200\",\"wac\":0.0,\"boh\":0,\"whpk\":\"10\",\"isVariableWeight\":false}],\"srcCountryCode\":\"US\",\"poStatus\":\"Active\",\"sourceNumber\":\"32612\",\"baseDiv\":\"1\",\"poNumber\":\"073280809\",\"uuid\":[\"0c1eb469-fc70-41c5-ab3c-9ae26eeeb9df\"]}],\"deliveryDetails\":[{\"inboundDoorNumber\":\"245\",\"itemLabelId\":[],\"inboundTrailerNumber\":\"T43235075\",\"poNumbers\":[\"073280809\"],\"dockTags\":[],\"doorType\":\"online\",\"deliveryName\":\"D1\",\"deliveryNumber\":\"43235075\",\"deliveryStatus\":\"CREATE_DELIVERY\"}],\"outboundDetails\":[],\"containerDetails\":[]}}");

			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray itemNumbers = JsonPath.parse(runTimeData).read(ITEM_NR_JSONPATH);
			for (int itemNrIndex = 0; itemNrIndex < itemNumbers.size(); itemNrIndex++) {
				String itemNumber = (String) itemNumbers.get(itemNrIndex);
				logger.info("Processing Item Number:{}", itemNumber);

				JSONArray holdCntrList = JsonPath.parse(runTimeData).read(
						"$.testFlowData.poDetails..poLineDetails..receivingInstructions[?(@.onHoldStatus==true)].parentContainer");

				logger.info("Processing pallet hold size :{} ", holdCntrList.size());

				String holdContr = holdCntrList.get(0).toString();
				logger.info("Container to be put on Hold : {} ", holdContr);

				Response responseCtr = validateAndGetContainerResponse(holdContr);

				String cntrStatus = JsonPath.parse(responseCtr.asString()).read("$.containerStatus");

				logger.info("Container to be put on Hold : {} has status as : {} ", holdContr, cntrStatus.toString());

				Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_HOLD_STATUS, cntrStatus.toString(), onHold);

			}
			logger.info("Succesfully validated LPN status");
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container data in inventory", e);
		}
	}

	@Step
	public void validateAndGetBOHResponse() {
		List<String> poNumberList;

//		tl.get().put("testFlowData",
//				"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"042608807\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"300\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"30\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020046643\", \"messageId\": \"3861728c-11e9-4dc2-9d87-1c4409565515\", \"childContainers\": [], \"receivedQuantity\": \"252\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2020-09-14\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] }, {\"parentContainer\": \"A67389000020047975\", \"messageId\": \"64c121e0-44fb-41fe-84b4-caf56024fb11\", \"childContainers\": [], \"receivedQuantity\": \"48\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2020-09-14\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 12300, \"wac\": 14.9, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.8\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-14\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 3.8, \"croInd\": \"cro\", \"recvQty\": 300, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"100\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"10\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020045311\", \"messageId\": \"d264076d-2785-4537-bd24-d1ac761c85e7\", \"childContainers\": [], \"receivedQuantity\": \"81\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2021-03-02\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] }, {\"parentContainer\": \"A67389000020046642\", \"messageId\": \"828e32b9-8e00-4560-a970-05e5cdd5dc5f\", \"childContainers\": [], \"receivedQuantity\": \"19\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2021-03-02\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 4000, \"wac\": 268.71, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.9\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-03-02\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 15.9, \"totalWeight\": 3180, \"averageWeightPerCase\": 15.9, \"croInd\": \"cro\", \"recvQty\": 100, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"3\", \"itemNumber\": \"570367405\", \"poVnpkQty\": \"48\", \"vnpk\": \"5\", \"whpk\": \"5\", \"whpkSellPrice\": \"13.9\", \"ovgQty\": \"4\", \"ti\": \"16\", \"hi\": \"3\", \"itemUpc\": \"00841152001985\", \"caseUpc\": \"10841152001982\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020047976\", \"messageId\": \"7cb61f6a-87ed-4102-b406-2540e0e0a7e6\", \"childContainers\": [], \"receivedQuantity\": \"40\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2020-09-14\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 600, \"wac\": 13.9, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.3245368\", \"height\": \"3.11023622047244\", \"width\": \"9.88188976377953\", \"depth\": \"14.6850393700787\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"728806\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-14\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 3.325, \"croInd\": \"cro\", \"recvQty\": 40, \"osdrInd\": \"o\"} ], \"uuid\": [\"19c64654-fcb9-4c9c-ba03-7876257f1de7\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"120\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T73261030\", \"poNumbers\": [\"042608807\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"73261030\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");
//
//	
		String testFlow = String.valueOf(tl.get().get("testFlowData"));
		logger.info("Testflow data before receiving start : {}", testFlow);

		parsedJson = JsonPath.parse(testFlow);
		List<Integer> itemNumberList = parsedJson.read(ITEM_NR_JSONPATH);

		logger.info("list valie: {}", itemNumberList.size());

		try {
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("inside failsafe" + inventoryHelper.bohBody(itemNumberList).toJSONString());

				response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders())
						.body(inventoryHelper.bohBody(itemNumberList).toJSONString())
						.post(environment.getProperty(WITRON_INVENTORY_BOH_ENDPOINT));

				Assert.assertEquals(ErrorCodes.WITRON_INVENTORY_BOH_RESPONSE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				logger.info("Validated the response status returned for the LPN response " + response.asString());
			});
			bohJson = JsonPath.parse(response.asString());

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			int recvQty = 0;

			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					String itemNumber;

					logger.info("Po Number{} " + poLineNumber);

					List<String> totalQtyForItem = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[?(@.isVTR==false&&@.onHoldStatus==false)].receivedQuantity");

					List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemNumber");
					itemNumber = itemList.get(0).toString();

					List<String> vnpk = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')]"
							+ ".poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].vnpk");

					List<Integer> recvQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].recvQty");
					recvQty = recvQtyList.get(0);
					if (recvQty == 0) {
						continue;
					}

					int totalQty = 0;
					for (String qty : totalQtyForItem) {
						totalQty = totalQty + Integer.parseInt(qty);
					}
					int finalTotalQty = Integer.parseInt(vnpk.get(0)) * (totalQty);
					logger.info("total test flow qty " + finalTotalQty);

//					List<Integer> totalQtyForItemInventory = bohJson
//							.read("$.itemBohDistribution.[?(@.itemNumber == '" + itemNumber + "')].bohQty");
//
//					logger.info("total inventory BOH qty " + totalQtyForItemInventory.get(0));
//
//					Assert.assertEquals(ErrorCodes.WITRON_INVENTORY_TOTAL_BOH_QTY, finalTotalQty,
//							totalQtyForItemInventory.get(0));

					JSONArray rechArr = JsonPath.read(testFlow,
							"$.testFlowData.poDetails..poLineDetails[?(@.itemNumber == '" + itemNumber
									+ "')].receivingInstructions[*]");

					List<ReceivingInstruction> recvInstc = new ArrayList();

					for (int i = 0; i < rechArr.size(); i++) {

						recvInstc.add((ReceivingInstruction) jsonUtils.getPojofromJsonObject(rechArr.get(i),
								ReceivingInstruction.class));

						logger.info("instrc size " + recvInstc.size() + rechArr.get(i).toString());

					}

					int count = 0;
					List<Integer> bohQtyByDate = null;
					String rotateDate = null;
					Map<String, Integer> dateQty = new HashMap<String, Integer>();

					for (ReceivingInstruction rec : recvInstc) {
						rotateDate = rec.getrotateDate();
						bohQtyByDate = bohJson.read("$.itemBohDistribution.[?(@.itemNumber == '" + itemNumber
								+ "')].groupByAttrBohDistribution[?(@.groupByAttrValue == '" + rotateDate
								+ "')].bohQty");

						if (dateQty.containsKey(rotateDate)) {
							count = count
									+ (Integer.parseInt(rec.getReceivedQuantity()) * Integer.parseInt(vnpk.get(0)));

							// dateQty.put(rec.getrotateDate(),count);
						} else {
							if (rec.getOnHoldStatus() == true) {
								count = 0;
								dateQty.put(rec.getrotateDate(), count);

							} else {
								count = Integer.parseInt(rec.getReceivedQuantity()) * Integer.parseInt(vnpk.get(0));
								dateQty.put(rec.getrotateDate(), count);
							}
						}
						logger.info("rec qty {}  ",
								Integer.parseInt(rec.getReceivedQuantity()) * Integer.parseInt(vnpk.get(0)));

					}
					logger.info("total inventory BOH qty {} for Date {} and for Item {} and TestFlow {}  ",
							bohQtyByDate.get(0), rotateDate, itemNumber, count);
					Assert.assertEquals(ErrorCodes.WITRON_INVENTORY_TOTAL_BOH_QTY_BY_DATE, bohQtyByDate.get(0), count);

				} // item loop previous
			}

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting inventory BOH response", e);
		}

	}

	@Step
	public void witronSendRTC() {
		try {

			String rtcMessage = textParser.readTextFile(FileNames.RTC_MESSAGE);
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));

			parsedJson = JsonPath.parse(testFlowData);
			List<String> containerList = parsedJson
					.read("$.testFlowData.poDetails..poLineDetails.[*].receivingInstructions[*].parentContainer");

			for (String cntr : containerList) {
				logger.info("Inventory container to be deleted:{} ", cntr);

				String rtcMessageFinal = javaUtils.format(rtcMessage, cntr);
				logger.info("RTC Message:{} ", rtcMessageFinal);

				logger.info("Publishing RTC Message");
				synchronized (stratiConnectionUtil) {
					stratiConnectionUtil.publishStartiMessage(environment.getProperty("witron_putaway_queue"),
							rtcMessageFinal, QUEUE, environment.getProperty("adjustments_connection_factory"),
							environment.getProperty("adjustments_strati_username"),
							environment.getProperty("adjustments_strati"));
				}
			}

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while deleting Inventory data", e);
		}

	}

	@Step
	public void validateInventory() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			ObjectMapper om = new ObjectMapper();
			om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			JSONArray listOfReceiving = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?((@.isPbyl == false) &&(@.isShipOut == true) && (@.isVTR == false || (@.channelType != \""
							+ CHANNELS.STAPLESTOCK.getValue().toUpperCase() + "\" && @.channelType != \""
							+ CHANNELS.CROSSNA.getValue().toUpperCase() + "\" && @.channelType != \""
							+ CHANNELS.CROSSNMA.getValue().toUpperCase() + "\")))]");
			String receivingString = listOfReceiving.toJSONString();
			List<ReceivingInstruction> receivingList = null;
			receivingList = om.readValue(receivingString, new TypeReference<List<ReceivingInstruction>>() {
			});

			for (int i = 0; i < receivingList.size(); i++) {
				ReceivingInstruction recvObj = receivingList.get(i);
				String channel = recvObj.getChannelType();
				logger.info("Channel " + channel + "ISGFCS " + recvObj.getIsGFCS() + "Size "
						+ recvObj.getChildContainers() + "Channelstatus" + (channel != null));

				if ((recvObj.getIsGFCS() && recvObj.getChildContainers().size() == 0)
						|| ((channel != null) && (channel.equalsIgnoreCase(CHANNELS.STAPLESTOCK.getValue())
								|| channel.equalsIgnoreCase(CHANNELS.CROSSNA.getValue())
								|| channel.equalsIgnoreCase(CHANNELS.CROSSNMA.getValue())))) {
					String parentCntr = recvObj.getParentContainer();
					Failsafe.with(retryPolicy).run(() -> {
						response = validateAndGetContainerResponse(parentCntr);
						logger.info("Validating Loaded parent containers in Inventory" + response.asString());
						io.restassured.path.json.JsonPath jsonPathEvaluator = response.jsonPath();
						String containerStatus = jsonPathEvaluator.get("containerStatus");
						logger.info("Expected Status:{}", "LOADED");
						logger.info("Actual Status:{}", containerStatus);

						Assert.assertEquals(ErrorCodes.INVENTORY_CONTAINER_VALIDATION_FOR_LOADED_STATUS, "LOADED",
								containerStatus);
					});
				} else {

					List<String> childCntrList = recvObj.getChildContainers();
					for (int j = 0; j < childCntrList.size(); j++) {

						String chilCntr = childCntrList.get(j);
						Failsafe.with(retryPolicy).run(() -> {
							response = validateAndGetContainerResponse(chilCntr);
							logger.info("Validating Loaded child containers in Inventory" + response.asString());
							io.restassured.path.json.JsonPath jsonPathEvaluator = response.jsonPath();
							String containerStatus = jsonPathEvaluator.get("containerStatus");
							logger.info("Expected Status:{}", "LOADED");
							logger.info("Actual Status:{}", containerStatus);
							Assert.assertEquals(ErrorCodes.INVENTORY_CONTAINER_VALIDATION_FOR_LOADED_STATUS, "LOADED",
									containerStatus);
						});

					}

				}

			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Loading Containers in Inventory", e);
		}
	}

	@Step
	public void deleteInventoryData() {
		try {
			ObjectMapper om = new ObjectMapper();
			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray containerIds = JsonPath.parse(runTimeData).read(CTR_ID_JSONPATH);
			String cntrString = containerIds.toJSONString();
			List<String> cntrList = null;
			cntrList = om.readValue(cntrString, new TypeReference<List<String>>() {
			});
			Set<String> disctinctcontainers = new HashSet<>();
			for (int i = 0; i < cntrList.size(); i++) {
				disctinctcontainers.add(cntrList.get(i));
			}
			List<String> containerList = new ArrayList<>();
			for (String container : disctinctcontainers) {
				containerList.add(container);
			}
			IntStream.range(0, containerList.size()).forEach(lpnIndex -> {

				lpn = containerList.get(lpnIndex);
				logger.info("Deleting LPN:{}", lpn);
				response = when().delete(environment.getProperty(INVENTORY_ENDPOINT_KEY) + lpn
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				response.then().statusCode(Constants.SUCESS_STATUS_CODE);
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while deleting Inventory data", e);
		}

	}

	@Step
	public void performVtr(int reasonCode) {
		try {
			ReceivingInstruction receivingInstructionObjDa = null;
			ReceivingInstruction receivingInstructionObjSstk = null;
			String vtrConatinerSstk;
			String vtrContainerDa;
			List<String> vtrContainers = new ArrayList();
//			tl.get().put("testFlowData",
//			"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"066429589\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"252\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"25\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"B32610000020090484\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"5ed89374-7a6f-4a18-b1be-4be53bb47c73\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-22\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"242\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] }, {\"parentContainer\": \"B32610000020094032\", \"adjustmentCode\": null, \"vtrContainer\": null, \"labelType\": null, \"channelType\": \"SSTKU\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageOrderIds\": null, \"containerName\": null, \"isVTR\": false, \"tote\": null, \"damageContainer\": null, \"isGFCS\": false, \"palletHoldQty\": null, \"orderIds\": [], \"adjustedQty\": 0, \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": null, \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-22\", \"damageQty\": 0, \"receivedQuantity\": \"10\", \"isShipOut\": true, \"salesQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 213180, \"wac\": 14.9811, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.8\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-22\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 3.8, \"croInd\": \"cro\", \"recvQty\": 252, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"81\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"8\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [{\"parentContainer\": \"B32610000020090485\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"12a237ed-50c9-419f-b34a-6b3b8d1bdd58\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2021-03-02\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"71\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] }, {\"parentContainer\": \"B32610000020094033\", \"adjustmentCode\": null, \"vtrContainer\": null, \"labelType\": null, \"channelType\": \"SSTKU\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageOrderIds\": null, \"containerName\": null, \"isVTR\": false, \"tote\": null, \"damageContainer\": null, \"isGFCS\": false, \"palletHoldQty\": null, \"orderIds\": [], \"adjustedQty\": 0, \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": null, \"destNumber\": \"32610\", \"rotateDate\": \"2021-03-02\", \"damageQty\": 0, \"receivedQuantity\": \"10\", \"isShipOut\": true, \"salesQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 231420, \"wac\": 244.4322, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.9\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-03-02\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 15.9, \"totalWeight\": 183978.8998, \"averageWeightPerCase\": 15.9, \"croInd\": \"cro\", \"recvQty\": 81, \"osdrInd\": \"s\"} ], \"uuid\": [\"df4d724e-a239-4660-a4ec-887a8b33423f\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"117\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T78479372\", \"poNumbers\": [\"066429589\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"78479372\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			
			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			objmapper.enable(SerializationFeature.INDENT_OUTPUT);
			JSONArray receivingInstructionArrayDa = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.channelType==\""
							+ CHANNELS.CROSSU.getValue().toUpperCase() + "\")]");
			JSONArray receivingInstructionArraySstk = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.channelType==\""
							+ CHANNELS.STAPLESTOCK.getValue().toUpperCase() + "\")]");

			JSONArray receivingInstructionArraySstkWitron = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.channelType==\""
							+ CHANNELS.SSTKU.getValue().toUpperCase() + "\")]");

			JSONArray vtrItemNumberDa = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[?(@.channelMethod==\""
							+ CHANNELS.CROSSU.getValue().toUpperCase() + "\")].itemNumber");
			JSONArray vtrItemNumberSStk = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[?(@.channelMethod==\""
							+ CHANNELS.SSTK.getValue().toUpperCase() + "\")].itemNumber");

			if (!receivingInstructionArrayDa.isEmpty()) {
				receivingInstructionObjDa = (ReceivingInstruction) jsonUtils
						.getPojofromJsonObject(receivingInstructionArrayDa.get(0), ReceivingInstruction.class);
			}
			if (!receivingInstructionArraySstk.isEmpty()) {
				receivingInstructionObjSstk = (ReceivingInstruction) jsonUtils
						.getPojofromJsonObject(receivingInstructionArraySstk.get(0), ReceivingInstruction.class);
			} else if (!receivingInstructionArraySstkWitron.isEmpty()) {
				receivingInstructionObjSstk = (ReceivingInstruction) jsonUtils
						.getPojofromJsonObject(receivingInstructionArraySstkWitron.get(0), ReceivingInstruction.class);
			}

			if (receivingInstructionObjSstk != null) {
				int sstkQtyVtr = 0;
				vtrConatinerSstk = receivingInstructionObjSstk.getParentContainer();
				logger.info("SSTK CONT === " + vtrConatinerSstk);
				vtrContainers.add(vtrConatinerSstk);
				receivingInstructionObjSstk.setVtrContainer(vtrContainers.get(0));
				receivingInstructionObjSstk.setIsVTR(true);
				int receivedQty=Integer.parseInt(receivingInstructionObjSstk.getReceivedQuantity());
				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC) {
					receivingInstructionObjSstk.setOrderIds(containerToOrderIdMapping(vtrConatinerSstk));
				}
				Response responseSstk = validateAndGetContainerResponse(vtrConatinerSstk);
				sstkQtyVtr = JsonPath.read(responseSstk.asString(), TOTAL_QTY_PATH);
				logger.info("Total Qty in eaches to be VTRed:{}", sstkQtyVtr);
				receivingInstructionObjSstk
						.setvtrQty(Integer.parseInt(receivingInstructionObjSstk.getReceivedQuantity()));
				receivingInstructionObjSstk.setReceivedQuantity(RECEIVED_QTY_SSTK_AFTER_VTR);
				logger.info("Triggering VTR for SSTK Container:{}", vtrConatinerSstk);

				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC) {
					invPage.scanContainer(vtrConatinerSstk);
					int vtrqty = invPage.getVtrQty();
					invPage.fileVtrAgainstContainer();
					Assert.assertEquals(ErrorCodes.INVENTORY_QTY_AFTER_VTR, sstkQtyVtr, -vtrqty);
				} else if (Config.DC == DC_TYPE.WITRON) {
					invPage.scanContainer(vtrConatinerSstk);
					int vtrqty = invPage.getVtrQty();
					Assert.assertEquals(ErrorCodes.INVENTORY_QTY_AFTER_VTR, sstkQtyVtr, -vtrqty);
					invPage.fileVtrAgainstContainer();

				} else {

					triggerVtr(vtrConatinerSstk, (String) vtrItemNumberSStk.get(0), -sstkQtyVtr, reasonCode);
				}
				runTimeData = setReceivingData(receivingInstructionObjSstk);

			} else {
				logger.info("No SSTK pallets received for performing VTR");
			}
			if (receivingInstructionObjDa != null) {
				List<String> daChildCtrs = receivingInstructionObjDa.getChildContainers();
				for (String child : daChildCtrs) {
					logger.info("No of children== " + child);
				}
				vtrContainerDa = daChildCtrs.get(0);
				vtrContainers.add(vtrContainerDa);
				for (String vtrTobeDoneOn : vtrContainers) {
					logger.info("Identify Vtr Container == " + vtrTobeDoneOn);
				}
				receivingInstructionObjDa.setVtrContainer(vtrContainers.get(0));
				if (daChildCtrs.size()==1) {
					receivingInstructionObjDa.setIsVTR(true);
				}
				receivingInstructionObjDa.setOrderIds(containerToOrderIdMapping(vtrContainerDa));
				daChildCtrs.remove(0);
				receivingInstructionObjDa.setChildContainers(daChildCtrs);
				int receivedQtyAfterVtr = Integer.parseInt(receivingInstructionObjDa.getReceivedQuantity()) - 1;
				Response responseDa = validateAndGetContainerResponse(vtrContainerDa);
				int daQtyVtr = JsonPath.read(responseDa.asString(), TOTAL_QTY_PATH);
				logger.info("Total Qty in eaches to be VTRed:{}", daQtyVtr);
				receivingInstructionObjDa.setvtrQty(DA_QTY_VTR);
				receivingInstructionObjDa.setReceivedQuantity(Integer.toString(receivedQtyAfterVtr));
				logger.info("Triggering VTR for DA Container:{}", vtrContainerDa);

				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC) {
					invPage.scanContainer(vtrContainerDa);
					int vtrqty = invPage.getVtrQty();
					invPage.fileVtrAgainstContainer();
					Assert.assertEquals(ErrorCodes.INVENTORY_QTY_AFTER_VTR, daQtyVtr, -vtrqty);
				} else {
					triggerVtr(vtrContainerDa, (String) vtrItemNumberDa.get(0), -daQtyVtr, reasonCode);
				}

				runTimeData = setReceivingData(receivingInstructionObjDa);
			} else {

				logger.info("No DA Containers received for performing VTR");
			}

			tl.get().put(TEST_FLOW_DATA, runTimeData);
			logger.info("testFlowData after VTR {}", tl.get().get(TEST_FLOW_DATA));
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to perform VTR", e);
		}

	}

	@Step
	public void performSplitPallet() {
		List<String> poNumberList;

		try {
//
//			tl.get().put("testFlowData",
//					"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"011312728\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"252\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"25\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020072950\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"7b8e1bff-a0b0-4916-a087-7654f7f37914\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-18\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"242\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 40008, \"wac\": 14.9223, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.8\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-18\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 3.8, \"croInd\": \"cro\", \"recvQty\": 252, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"81\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"8\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020071623\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"e8a17480-1301-49d8-92e1-8b25db2af846\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2021-03-02\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"71\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 39000, \"wac\": 236.91, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.9\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-03-02\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 15.9, \"totalWeight\": 31004.9998, \"averageWeightPerCase\": 15.9, \"croInd\": \"cro\", \"recvQty\": 81, \"osdrInd\": \"s\"} ], \"uuid\": [\"c5a94d92-de4f-4002-9b15-65432b7a130d\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"116\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T21464199\", \"poNumbers\": [\"011312728\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"21464199\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");
////
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));
			logger.info("Testflow data before Split Pallet : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);
			String splitQty = "10";
			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					parsedJson = JsonPath.parse(testFlowData);
					logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

					List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[*].parentContainer");

					List<String> rotateDateList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[*].rotateDate");
					String rotateDate = rotateDateList.get(0);

					List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemNumber");

					logger.info("Po Path: {}",
							"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
									+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
									+ "')].receivingInstructions[*].parentContainer");

					logger.info("Pallet count: {} ", contrList.size());

					String vtrCntr = contrList.get(0).toString();

					logger.info("Pallet label: {} ", vtrCntr);

					invPage.scanSplitPallet(vtrCntr);
					String splitCntr = invPage.splitContainer(vtrCntr, splitQty);
					splitContainerValidation(splitCntr, splitQty);
					receivingHelper.updateReceivingInstructionPostSplitPallet(poNumber, poLineNumber, splitCntr,
							splitQty, rotateDate);

				}
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to perform Split Pallet Functionlity", e);
		}

	}

	@Step
	private void triggerVtr(String vtrContainer, String vtrItemNumber, int adjQty, int reasonCode) {
		try {
			String vtrRequestInString = null;
			VtrMessage vtrMessage = inventoryHelper.constructVtrMessage(vtrContainer, vtrItemNumber, adjQty,
					reasonCode);
			vtrRequestInString = objectMapper.writeValueAsString(vtrMessage);
			logger.info("VTR request body is :{}", vtrRequestInString);

			response = SerenityRest.given().body(vtrRequestInString).header("Content-Type", ContentType.JSON).when()
					.put(environment.getProperty("vtr_ep"));
			response.then().statusCode(Constants.SUCESS_STATUS_CODE);
			logger.info("Succesfully performed VTR on container :{}", vtrContainer);
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to trigger VTR", e);
		}
	}

	@Step
	public void validateVTRCntrs() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfReceiving = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].vtrContainer");
			String cntrString = listOfReceiving.toJSONString();
			List<String> cntrList = om.readValue(cntrString, new TypeReference<List<String>>() {
			});
			for (int i = 0; i < cntrList.size(); i++) {
				String vtrCntr = cntrList.get(i);
				validateAndGetContainerResponseForVTR(vtrCntr);
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("VTR validation in Inventory failed", e);
		}
	}

	@Step
	public void validateDamageCntrs() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfReceiving = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].damageContainer");
			String cntrString = listOfReceiving.toJSONString();
			List<String> cntrList = om.readValue(cntrString, new TypeReference<List<String>>() {
			});
			for (int i = 0; i < cntrList.size(); i++) {
				String damageCntr = cntrList.get(i);
				validateAndGetContainerResponseForDamage(damageCntr);
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("VTR validation in Inventory failed", e);
		}
	}

	private String setReceivingData(ReceivingInstruction receivingInstructionObj) {
		String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONObject listOfReceivingInstruction;
		try {
			listOfReceivingInstruction = jsonUtils.convertToJsonObject(receivingInstructionObj);

			runTimeData = jsonUtils.setJsonAtJsonPath(runTimeData, listOfReceivingInstruction,
					"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.parentContainer==\""
							+ receivingInstructionObj.getParentContainer() + "\")]");
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while setting the receiving data", e);
		}

		return runTimeData;
	}

	public List<String> containerToOrderIdMapping(String containerId) {
		Response responseInv = validateAndGetContainerResponse(containerId);
		return JsonPath.parse(responseInv.getBody().asString()).read(ORDERID_PATH);
	}

	public void validateContainerStatus(String cntrStatus) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			Failsafe.with(retryPolicy).run(() -> {
				JSONArray cntrList = JsonPath.read(testData,
						"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType == \"normal\")].parentContainer");

				for (int i = 0; i < cntrList.size(); i++) {

					response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
							.get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + cntrList.get(i)
									+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));

//					response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + cntrList.get(i)
//							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					logger.info("Waiting for validating container Status for Container Id:{}", cntrList.get(i));
					Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_STATUS, cntrStatus.toUpperCase(),
							parseContainerStatus(response));
					logger.info("Validated the container status for  " + cntrList.get(i) + " in Inventory");
				}
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting container status", e);
		}

	}

	public String parseContainerStatus(Response response) {

		logger.info("Inside parse container status " + response.getBody().asString());
		JSONArray cntrStatus = JsonPath.read(response.getBody().asString(),
				"$.aggrInvList[*].containerInventories[*].containerStatus");
		logger.info("Outside parse container status" + cntrStatus.get(0).toString());

		return cntrStatus.get(0).toString();

	}

	@Step
	public void vtrTheContainer(String container) {
		try {

			invPage.scanContainer(container);
			invPage.fileVtrAgainstContainer();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while doing VTR", e);
		}

	}

	public void createDummyCntrs(String typeOfCntr) {
		try {
			String orderDetailsJsonPath = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.labelType == \"normal\")].destNumber";

			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("testflowdata:" + testData);
			ObjectMapper om = new ObjectMapper();
			JSONArray destinationDetails = JsonPath.read(testData, orderDetailsJsonPath);
			String destString = destinationDetails.toJSONString();
			List<String> destList = om.readValue(destString, new TypeReference<List<String>>() {
			});

			Set<String> hSet = new HashSet<String>(destList);
			hSet.addAll(destList);
			logger.info("destinations :" + hSet);
			destList.clear();
			destList.addAll(hSet);
			deleteFromDestinationTable(destList);

			for (String dest : hSet) {
				logger.info("Destination is " + dest);
				// inventoryCreation(dest);
				containerCreationLoading(dest, typeOfCntr);
			}
		} catch (IOException | URISyntaxException | JSONException e) {
			e.printStackTrace();
		}
	}

	private void inventoryCreation(String dest) throws URISyntaxException, IOException, JSONException {

		logger.info("Creating container in inventory for dest " + dest);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		org.json.JSONObject inventoryPayLoadObj = new org.json.JSONObject(
				textParser.readTextFile(FileNames.INVENTORY_CREATION_PAYLOAD));

		String container = "ACL" + timestamp.getTime();

		inventoryPayLoadObj.put("trackingId", container);
		inventoryPayLoadObj.put("destinationLocationId", dest);
		inventoryPayLoadObj.put("finalDestinationBuNumber", dest);

		logger.info("Payload for container creation " + inventoryPayLoadObj.toString());

		response = SerenityRest.given().contentType("application/json").body(inventoryPayLoadObj.toString()).when()
				.post(environment.getProperty(INVENTORY_ENDPOINT_KEY)).andReturn();
		Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_STATUS, 201, response.getStatusCode());
		destContainerMap.put(dest, container);

		logger.info("Container created");
	}

	public void containerCreationLoading(String dest, String typeOfCntr)
			throws URISyntaxException, IOException, JSONException {

		logger.info("Creating container in loading for dest " + dest);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		org.json.JSONObject loadingPayLoadObj = new org.json.JSONObject(
				textParser.readTextFile(FileNames.LOADING_CNTR_CREATION_PAYLOAD));

		String container = "ACL" + timestamp.getTime();

		loadingPayLoadObj.put("trackingId", container);
		loadingPayLoadObj.put("destinationLocationId", dest);
		if (!typeOfCntr.equalsIgnoreCase("normal")) {
			loadingPayLoadObj.put("containerCube", 190000);
			loadingPayLoadObj.put("itemNetWeight", 190000);
		}

		org.json.JSONObject childCnrt = loadingPayLoadObj.getJSONArray("childContainers").getJSONObject(0);
		String childContainer = "AC1" + timestamp.getTime();

		childCnrt.put("trackingId", childContainer);
		childCnrt.put("destinationLocationId", dest);

		if (!typeOfCntr.equalsIgnoreCase("normal")) {
			childCnrt.put("containerCube", 190000);
			childCnrt.put("itemNetWeight", 190000);
		}

		logger.info("Payload for container creation " + loadingPayLoadObj.toString());

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().contentType("application/json").body(loadingPayLoadObj.toString()).when()
					.post(environment.getProperty(LOADING_CONTAINER_ENDPOINT_KEY)).andReturn();
			Assert.assertEquals(ErrorCodes.LOADING_INVALID_CONTAINER_STATUS, 200, response.getStatusCode());
		});
		destContainerMap.put(dest, container);
		logger.info("Container created");
	}

	public void deleteFromDestinationTable(List destList) {

		for (int i = 0; i < destList.size(); i++) {
			Object[] objArr = new Object[1];
			objArr[0] = destList.get(i);
			int deleteCount;
			deleteCount = dbUtils.deleteFrom(Config.DC, environment.getProperty("delete_sorter_destination"),
					objArr[0]);
			logger.info("deleted:{} rows from destination_door_assignment table as part of sorter cleanup",
					deleteCount);
		}

	}

	@Step

	public void damagePostLoaded() {
		String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		objmapper.enable(SerializationFeature.INDENT_OUTPUT);
		JSONArray outBoundArr = JsonPath.parse(runTimeData).read("$..outboundDetails[*]");
		List<OutboundDetail> outBoundList;
		try {
			outBoundList = (List<OutboundDetail>) jsonUtils.getPojoListfromPath(outBoundArr.toJSONString(),
					OutboundDetail.class);

			for (OutboundDetail outBound : outBoundList) {
				List<String> loadedContainerList = outBound.getContainerIds();
				if (!loadedContainerList.isEmpty()) {
					for (String cntr : loadedContainerList) {
						Assert.assertTrue(ErrorCodes.INVENTORY_DAMAGE_POST_LOADED,
								invPage.scanLoadedContainerToDamage(cntr));

					}
				} else
					break;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Step
	public void performDamage() {
		try {
			ReceivingInstruction receivingInstructionObjDa = null;
			ReceivingInstruction receivingInstructionObjSstk = null;
			String damageConatinerSstk;
			String damageContainerDa;
			List<String> damageContainers = new ArrayList();
			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			objmapper.enable(SerializationFeature.INDENT_OUTPUT);
			JSONArray outBoundArr = JsonPath.parse(runTimeData).read("$..outboundDetails[*]");
			List<OutboundDetail> outBoundList = (List<OutboundDetail>) jsonUtils
					.getPojoListfromPath(outBoundArr.toJSONString(), OutboundDetail.class);
			JSONArray receivingInstructionArrayDa = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.channelType==\""
							+ CHANNELS.CROSSU.getValue().toUpperCase() + "\")]");
			JSONArray receivingInstructionArraySstk = JsonPath.parse(runTimeData)
					.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.channelType==\""
							+ CHANNELS.SSTKU.getValue().toUpperCase() + "\")]");

			if (!receivingInstructionArrayDa.isEmpty()) {
				receivingInstructionObjDa = (ReceivingInstruction) jsonUtils
						.getPojofromJsonObject(receivingInstructionArrayDa.get(0), ReceivingInstruction.class);
			}
			if (!receivingInstructionArraySstk.isEmpty()) {
				receivingInstructionObjSstk = (ReceivingInstruction) jsonUtils
						.getPojofromJsonObject(receivingInstructionArraySstk.get(0), ReceivingInstruction.class);
			}

			if (receivingInstructionObjSstk != null) {

				damageConatinerSstk = receivingInstructionObjSstk.getParentContainer();
				logger.info("SSTK CONT === " + damageConatinerSstk);
				damageContainers.add(damageConatinerSstk);
				receivingInstructionObjSstk.setDamageContainer(damageContainers.get(0));
				receivingInstructionObjSstk.setIsDamage(true);
				receivingInstructionObjSstk.setDamageOrderIds(containerToOrderIdMapping(damageConatinerSstk));
				Response responseSstk = validateAndGetContainerResponse(damageConatinerSstk);
				int sstkQtyDamage = JsonPath.read(responseSstk.asString(), TOTAL_QTY_PATH);
				logger.info("Total Qty in eaches to be DAMAGEd:{}", sstkQtyDamage);
				receivingInstructionObjSstk
						.setDamageQty(Integer.parseInt(receivingInstructionObjSstk.getReceivedQuantity()));
				receivingInstructionObjSstk.setReceivedQuantity(RECEIVED_QTY_SSTK_AFTER_DAMAGE);
				logger.info("Triggering DAMAGE for SSTK Container:{}", damageConatinerSstk);

				invPage.scanContainerDamage(damageConatinerSstk);
				int damageQty = invPage.getDamageQty();
				invPage.fileDamageAgainstContainer();
				Assert.assertEquals(ErrorCodes.INVENTORY_QTY_AFTER_DAMAGE, sstkQtyDamage, damageQty);

				runTimeData = setReceivingData(receivingInstructionObjSstk);

			} else {
				logger.info("No SSTK pallets received for performing Damage");
			}
			if (receivingInstructionObjDa != null) {

				String patentDamageContr = receivingInstructionObjDa.getParentContainer();
				logger.info("parent== " + patentDamageContr);

				List<String> daChildCtrs = receivingInstructionObjDa.getChildContainers();
				for (String child : daChildCtrs) {
					logger.info("No of children== " + child);
				}
				damageContainerDa = daChildCtrs.get(0);
				damageContainers.add(damageContainerDa);
				for (String damageTobeDoneOn : damageContainers) {
					logger.info("Identify Vtr Container == " + damageTobeDoneOn);
				}
				receivingInstructionObjDa.setDamageContainer(damageContainers.get(0));
				
				receivingInstructionObjDa.setIsDamage(true);
				receivingInstructionObjDa.setDamageOrderIds(containerToOrderIdMapping(damageContainerDa));
				daChildCtrs.remove(0);
				receivingInstructionObjDa.setChildContainers(daChildCtrs);
				int receivedQtyAfterVtr = Integer.parseInt(receivingInstructionObjDa.getReceivedQuantity());
				Response responseDa = validateAndGetContainerResponse(damageContainerDa);
				int daQtyVtr = JsonPath.read(responseDa.asString(), TOTAL_QTY_PATH);
				logger.info("Total Qty in eaches to be DAMAGEd:{}", daQtyVtr);
				receivingInstructionObjDa.setDamageQty(DA_QTY_DAMAGE);
				receivingInstructionObjDa.setReceivedQuantity(Integer.toString(receivedQtyAfterVtr));
				logger.info("Triggering Damage for DA Container:{}", damageContainerDa);

				invPage.scanContainerDamage(damageContainerDa);
				int damageQty = invPage.getDamageQty();
				invPage.fileDamageAgainstContainer();
				Assert.assertEquals(ErrorCodes.INVENTORY_QTY_AFTER_DAMAGE, daQtyVtr, damageQty);

				runTimeData = setReceivingData(receivingInstructionObjDa);
			} else {

				logger.info("No DA Containers received for performing Damage");
			}

			tl.get().put(TEST_FLOW_DATA, runTimeData);
			logger.info("testFlowData after Damage {}", tl.get().get(TEST_FLOW_DATA));
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to perform Damage", e);
		}

	}

	@Step
	public void validateContainerStatusGateOut(String ctrStatus) {

		String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
		List<String> containerIds = new ArrayList();

		List<String> containerIdsNonConveyables = JsonPath.read(runTimeData,
				"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.isPbyl == false && (@.channelType == \""
						+ CHANNELS.STAPLESTOCK.getValue().toUpperCase() + "\" || @.channelType == \""
						+ CHANNELS.CROSSNA.getValue().toUpperCase() + "\" || @.channelType == \""
						+ CHANNELS.CROSSNMA.getValue().toUpperCase() + "\"))].parentContainer");
		List<String> containerIdsConveyables = JsonPath.read(runTimeData,
				"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.isPbyl == false && (@.channelType == \""
						+ CHANNELS.CROSSU.getValue().toUpperCase() + "\" || @.channelType == \""
						+ CHANNELS.CROSSMU.getValue().toUpperCase() + "\"))]..childContainers[*]");

		if (!containerIdsNonConveyables.isEmpty()) {

			containerIds.addAll(containerIdsNonConveyables);

		}
		if (!containerIdsConveyables.isEmpty()) {
			containerIds.addAll(containerIdsConveyables);

		}

		List<String> unloadedCtrs = JsonPath.read(runTimeData,
				"$.testFlowData.outboundDetails[*].unloadedContainers[*]");
		if (!unloadedCtrs.isEmpty()) {

			logger.info("Removing unloaded containers from checking gatedOut status in inventory");
			for (String container : unloadedCtrs) {

				containerIds.remove(container);
			}
		}

		for (String ctr : containerIds) {

			Failsafe.with(retryPolicy).run(() -> {
				responseInv = validateAndGetContainerResponse(ctr);
				String cntrStatus = JsonPath.read(responseInv.getBody().asString(), "$.containerStatus");
				Assert.assertEquals(ErrorCodes.INVENTORY_STATUS_AFTER_GATEOUT, "IN_TRANSIT", cntrStatus);
			});
		}

	}

	@Step
	public void validateGFCSContainerData() {
		inventoryHelper.getGFCSContainer();
	}

	@Step
	public void validateMCBInventory() {
		try {
			String testData = (String) tl.get().get("testFlowData");
			ObjectMapper om = new ObjectMapper();
			JSONArray listOfLoads1 = JsonPath.read(testData, "$.testFlowData.outboundDetails[*].mcbContainerID");
			String outBoundString = listOfLoads1.toJSONString();
			logger.info("Outbound List {}", outBoundString);
			List<String> mcbCntrList = null;
			mcbCntrList = om.readValue(outBoundString, new TypeReference<List<String>>() {
			});

			for (String mcbCntr : mcbCntrList) {
				Failsafe.with(retryPolicy).run(() -> {
					Response response = validateAndGetContainerResponse(mcbCntr);
					String chilCntrs = JsonPath.read(response.asString(), INVENTORY_CHILD_CNTR_PATH);
					String chilCntrString = chilCntrs.replace("[", "").replace("]", "");
					Assert.assertEquals(ErrorCodes.INVENTORY_MCB_CONTAINER_VALIDATION, 0, chilCntrString.length());
				});
			}
		} catch (Exception e) {
			throw new AutomationFailure("Unable validate mcb Inventory", e);
		}
	}

	public void validateVtrOnFinalizedContainer() {

		String testFlowData = String.valueOf(tl.get().get("testFlowData"));

		JSONArray receivingInstructionArrayDa = JsonPath.parse(testFlowData).read("$..receivingInstructions[*]");

		try {
			List<ReceivingInstruction> recvInstList = (List<ReceivingInstruction>) jsonUtils
					.getPojoListfromPath(receivingInstructionArrayDa.toJSONString(), ReceivingInstruction.class);
			logger.info("Receiving Instruction Size for VTR flow finalize: {}", recvInstList);

			for (ReceivingInstruction receivingInstruction : recvInstList) {
				if (receivingInstruction.getIsVTR()) {
					logger.info("Its VTR COntainer", receivingInstruction.getParentContainer());
					continue;
				} else {
					logger.info("Its NOT VTR COntainer", receivingInstruction.getParentContainer());

					String parentCtr = receivingInstruction.getParentContainer();
					if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC) {
						logger.info("Scanning Parent container to VTRd it {}", parentCtr);
						invPage.scanContainer(parentCtr);
						boolean vtrStatus = invPage.fileVtrAgainstFinalizedContainer();
						Assert.assertTrue(ErrorCodes.INVENTORY_SUBMIT_VTR_FINALIZED_CONTAINER, vtrStatus);
					}

				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void validateCompletedMcbContainer() {
		try {
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));
			List<String> childLPNs = JsonPath.parse(testFlowData).read(CONTAINER_LIST_IN_TESTFLOWDATA_XPATH);
			List<String> mcbContianer = JsonPath.parse(testFlowData).read(MCB_CONTAINER_IN_TESTFLOWDATA_XPATH);
			logger.info("Validating inventory details for COMPLETED MCB container {}", mcbContianer.get(0));

			for (String childContainer : childLPNs) {
				response = null;
				Failsafe.with(retryPolicy).run(() -> {
					logger.info("Validating MCB mapping in the child container: {} in inventory", childContainer);
					response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + childContainer
							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					Assert.assertEquals(ErrorCodes.INVENTORY_MCB_CHILD_CONTAINER_NOT_FOUND,
							Constants.SUCESS_STATUS_CODE, response.getStatusCode());
					List<String> parentLPN = JsonPath.read(response.getBody().asString(), PARENT_CONTAINER_XPATH);
					Assert.assertEquals(ErrorCodes.INVENTORY_MCB_MAPPING_IN_CHILD_CONTAINER_VALIDATION,
							mcbContianer.get(0), parentLPN.get(0));
					logger.info("Validated MCB mapping in the child container:{} in inventory", childContainer);
				});
			}

			response = null;
			logger.info("Validating MCB container status: {} in inventory", mcbContianer.get(0));
			Failsafe.with(retryPolicy).run(() -> {
				response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + mcbContianer.get(0)
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				Assert.assertEquals(ErrorCodes.INVENTORY_MCB_CONTAINER_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			});
			List<String> mcbContainerStatus = JsonPath.read(response.getBody().asString(), MCB_CONTAINERSTATUS_XPATH);
			List<String> mcbchildContainers = JsonPath.read(response.getBody().asString(), MCB_CHILD_CONTAINER_XPATH);
			Assert.assertEquals(ErrorCodes.INVENTORY_MCB_INVALID_CONTAINER_STATUS, PICKED, mcbContainerStatus.get(0));
			logger.info("Validated MCB container status: {} in inventory", mcbContianer.get(0));

			for (String childCont : childLPNs) {
				logger.info("Validating child container: {} mapping in the MCB: {} in inventory", childCont,
						mcbContianer.get(0));
				Assert.assertTrue(ErrorCodes.INVENTORY_CHILD_CONTAINER_NOT_MAPPED_IN_PARENT_MCB,
						mcbchildContainers.contains(childCont));
				logger.info("Validated child container: {} mapping in the MCB: {} in inventory", childCont,
						mcbContianer.get(0));
			}

			logger.info("Validated inventory details for COMPLETED MCB container {}", mcbContianer.get(0));

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to validate MCB container", e);
		}
	}

	public void validateInprogressMcbContainer() {
		try {
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));
			List<String> mcbContianer = JsonPath.parse(testFlowData).read(MCB_CONTAINER_IN_TESTFLOWDATA_XPATH);

			logger.info("Validating inventory details for IN_PROGRESS MCB container {}", mcbContianer.get(0));
			Failsafe.with(retryPolicy).run(() -> {
				response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + mcbContianer.get(0)
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				Assert.assertEquals(ErrorCodes.INVENTORY_MCB_CONTAINER_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			});

			List<String> mcbContainerStatus = JsonPath.read(response.getBody().asString(), MCB_CONTAINERSTATUS_XPATH);
			Assert.assertEquals(ErrorCodes.INVENTORY_MCB_INVALID_CONTAINER_STATUS, WORK_IN_PROGRESS,
					mcbContainerStatus.get(0));

			logger.info("Validated inventory details for IN_PROGRESS MCB container {}", mcbContianer.get(0));

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to validate MCB container", e);
		}
	}

	public void inventoryCntrDelete(String lpnId, ErrorCodes a) {

		try {
			Failsafe.with(retryPolicy).run(() -> {
				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.MCC || Config.DC == DC_TYPE.WITRON) {
					response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
							.get(environment.getProperty(INVENTORY_ENDPOINT_KEY) + lpnId
									+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				}
				logger.info("Waiting for Status 404 for Container Id:{}", lpnId);
				Assert.assertEquals(a, Constants.FALIURE_STATUS_CODE, response.getStatusCode());
				logger.info("Container = " + lpnId + " deleted from Inventory");
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting inventory response", e);
		}

		// inventoryCntrDelete(lpnId,ErrorCodes.INVENTORY_CONTAINER_DELETED_RTC);

	}

	@Step
	public void splitContainerValidation(String lpnId, String qty) {
		try {
//			Failsafe.with(retryPolicy).run(() -> {
			response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders()).when()
					.get(environment.getProperty("witron_inv_container_validation_ep") + lpnId
							+ environment.getProperty("inventory_ep_qp"));

			logger.info("URL {}", environment.getProperty("witron_inv_container_validation_ep") + lpnId
					+ environment.getProperty("inventory_ep_qp"));

			logger.info("Response {}", response.asString());

			Assert.assertEquals(ErrorCodes.INVENTORY_SPLIT_INVENTORY_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
			logger.info("Split Container = " + lpnId + " Created");

			parsedJson = JsonPath.parse(response.asString());
			splitQty = parsedJson.read("$..containerInventoryList[*].warPkQuantity");

			logger.info("Split Container qty = " + splitQty.get(0));

			// });
			int splitQtyVal = Integer.parseInt(qty);
			int splitQtyFromInv = splitQty.get(0);

			Assert.assertEquals(ErrorCodes.INVENTORY_SPLIT_QTY_MATCH_FAILED, splitQtyVal, splitQtyFromInv);
			logger.info("Qty Validated successfully ");

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting inventory response", e);
		}

	}

	@Step
	public void validateDeletedMCBConatainer() {
		try {
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));

			parsedJson = JsonPath.parse(testFlowData);
			List<String> mcbContainerList = parsedJson.read(MCB_CONTAINER_IN_TESTFLOWDATA_XPATH);
			logger.info("Validating deleted MCB contanier {} in inventory", mcbContainerList.get(0));
			Failsafe.with(retryPolicy).run(() -> {
				response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + mcbContainerList.get(0)
						+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
				Assert.assertEquals(ErrorCodes.INVENTORY_MCB_CONTAINER_DELETED, Constants.NO_CONTENT_STATUS_CODE,
						response.getStatusCode());
			});
			logger.info("Validated deleted MCB contanier {} in inventory", mcbContainerList.get(0));
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating deleted MCB container", e);
		}

	}

	@Step
	public void performVtrInWeb() {
		try {
			ReceivingInstruction receivingInstructionObj = null;
			List<String> vtrContainers = new ArrayList();
			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray receivingInstructionArray = JsonPath.parse(runTimeData).
					read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.channelType=='CROSSU'|| @.channelType=='CROSSNA'|| @.channelType=='SSTKU' )]");
			List<String> deliveryNumber = JsonPath.parse(runTimeData)
					.read("$.testFlowData.deliveryDetails[*].deliveryNumber");
			List<String> poNumberList = JsonPath.parse(runTimeData)
					.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			if (!receivingInstructionArray.isEmpty()) {
				receivingInstructionObj = (ReceivingInstruction) jsonUtils
						.getPojofromJsonObject(receivingInstructionArray.get(0), ReceivingInstruction.class);
			}
			if (receivingInstructionObj != null) {
				if (!receivingInstructionObj.getChildContainers().isEmpty()) {
					vtrContainers.addAll(receivingInstructionObj.getChildContainers());
					logger.info("VTR to be performed on DA child containers :: "+vtrContainers);
				}else{
				vtrContainers.add(receivingInstructionObj.getParentContainer());
					logger.info("VTR to be performed on SSTK container :: "+vtrContainers);
				}
				for (String vtrCont : vtrContainers) {
					receivingInstructionObj.setVtrContainer(vtrCont);
					receivingInstructionObj.setIsVTR(true);
					receivingInstructionObj.setOrderIds(containerToOrderIdMapping(vtrCont));
				}
				receivingInstructionObj
						.setvtrQty(Integer.parseInt(receivingInstructionObj.getReceivedQuantity()));
				receivingInstructionObj.setReceivedQuantity(QTY_AFTER_BULK_VTR);
				runTimeData = setReceivingData(receivingInstructionObj);
			}
			for (String poNumber : poNumberList) {
				invWebPage.bulkVTRInWeb(deliveryNumber.get(0), poNumber);
			}
			tl.get().put(TEST_FLOW_DATA, runTimeData);
			logger.info("testFlowData after VTR {}", tl.get().get(TEST_FLOW_DATA));
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to perform VTR", e);

		}
	}
}

