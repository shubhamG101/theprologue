package com.walmart.supplychain.thor.receiving.scenariosteps;

import java.io.IOException;
import java.net.URISyntaxException;

import org.json.JSONException;

import com.walmart.supplychain.thor.receiving.steps.ThorReceivingStep;
import com.walmart.supplychain.thor.receiving.steps.WitronTestDataStep;

import cucumber.api.java.en.Given;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;

public class WitronTestData {
	
	@Steps
	WitronTestDataStep witronTestDataStep;
	
	@Given("^user creates the PO for Witron$")
	public void userCreatesThePOForWitro() throws JSONException, IOException, URISyntaxException, ParseException
	{
		witronTestDataStep.createWitronPO();
	}

}
