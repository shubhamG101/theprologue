package com.walmart.supplychain.thor.manifestservices.steps.webservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.vavr.collection.HashMap;
import net.jodah.failsafe.FailsafeException;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class ManifestServicesSteps {

	@Autowired
	ManifestServicesHelper manifestServicesHelper;

	@Step
	public void createPO(String itemNumber, String poLineQty, String vnpkQty, String whpkQty, String whpkSellCost) {
		try {
			manifestServicesHelper.createPO(itemNumber, poLineQty, vnpkQty, whpkQty, whpkSellCost);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating PO", e);
		}
	}

	@Step
	public void validatePOInManifest() {
		try {
			manifestServicesHelper.validatePO();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating PO in Manifest", e);
		}
	}

	@Step
	public void updatePOlineQty(String updateQty, String status) {
		try {
			manifestServicesHelper.updatePOLineQty(updateQty,status);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating PO line Quantity", e);
		}
	}

	@Step
	public void updatePOlineStatus(String updateStatus) {
		try {
			manifestServicesHelper.updatePOLineStatus(updateStatus);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating PO statsus to Cancel", e);
		}
	}

	@Step
	public void addPOLine(String lineTwoItemNumber, String lineTwoPoLineQty, String lineTwoVnpkQty, String lineTwoWhpkQty, String lineTwoWhpkSellCost) {
		try {

			manifestServicesHelper.poLineAdd(lineTwoItemNumber, lineTwoPoLineQty, lineTwoVnpkQty, lineTwoWhpkQty, lineTwoWhpkSellCost);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while adding a PO line", e);
		}
	}
}
