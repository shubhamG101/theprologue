package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class LoginPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	boolean problemTicketDisplayed = false;

	// login - username password

	// login - username password
	@FindBy(xpath = "//button[text()='Login again']")
	private WebElement loginAgain_Button;

	@FindBy(xpath = ".//*[@id='username1']")
	private WebElement userName_Textbox;

	@FindBy(xpath = ".//*[@id='password']")
	private WebElement password_Textbox;

	@FindBy(xpath = ".//*[@id='domain']")
	private WebElement domain_Dropdown;

	@FindBy(xpath = ".//*[@id='domain']/option")
	private WebElement domainList_Dropdown;

	@FindBy(xpath = ".//*[@class='ping-buttons']//a")
	private WebElement signIn_Button;

	@FindBy(xpath = ".//*[@id='dcnum-combo-box']")
	private WebElement selectDC_Dropdown;

	//idp one time sign on

	@FindBy(xpath = ".//*[@id='uname']")
	private WebElement username;

	@FindBy(xpath = ".//*[@id='j_password']")
	private WebElement password;

	@FindBy(xpath = ".//*[@id='domain']")
	private WebElement domain;

	@FindBy(xpath = "//*[@id=\"loginForm\"]/div[5]/button")
	private WebElement signin;


	public void closeBrowser() {
		getDriver().quit();
	}

	WebDriver driver = null;

	public void loginIntoFixit(String url,String user,String pass) {
		driver = getDriverInstance();
		logger.info("Fixit login URL " + url);
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		long timeOut = 5000;
		long end = System.currentTimeMillis() + timeOut;
		while (System.currentTimeMillis() < end) {
			if (String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
					.equals("complete")) {
				break;
			}
		}

		if(driver.getCurrentUrl().contains("pfedcert")){
			enterUserPass(user,pass);
		}
		logger.info("FIXit home page displayed");
		if(url.equals("https://fixit.stg.us.walmart.net/fixit/tracker")) {
			selectAtlas();
		}
	}
	
	public void loginIntoFixit(String url,String user,String pass,String dc, String userenv) throws InterruptedException {
		if(getDriver()!=null)
			getDriver().close();
		driver = getDriverInstance();
		logger.info("Fixit login URL " + url);
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		long timeOut = 5000;
		long end = System.currentTimeMillis() + timeOut;
		while (System.currentTimeMillis() < end) {
			if (String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
					.equals("complete")) {
				break;
			}
		}
		if(driver.getCurrentUrl().contains("sso.platform")){
			enterUserPass(user,pass);
		} else if(driver.getCurrentUrl().contains("pfed")){
			logger.info("Pingfed authentication screen displayed");
			enterUserPass(user,pass);
		}

		logger.info("FIXit home page displayed");
		if(!userenv.equals("RESOLVE"))
			selectDc(dc);
		Thread.sleep(2000);
		if(userenv.equals("DAMAGE")) {
			driver.get(url);
		}
	}
	
	public void navigateToTracker(String url) {
		getDriverInstance().get(url);
		long timeOut = 5000;
		long end = System.currentTimeMillis() + timeOut;
		while (System.currentTimeMillis() < end) {
			if (String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
					.equals("complete")) {
				break;
			}
		}
	}

	public void selectAtlas() {
		element(selectDC_Dropdown).waitUntilVisible();
		element(selectDC_Dropdown).selectByValue("32818");
	}

	public void selectDc(String dc) {
		click(selectDC_Dropdown);
		element(selectDC_Dropdown).type(dc);
		element(selectDC_Dropdown).sendKeys(Keys.ARROW_DOWN);
		element(selectDC_Dropdown).sendKeys(Keys.ENTER);
		
		//element(selectDC_Dropdown).waitUntilVisible();
		//element(selectDC_Dropdown).selectByValue(dc);
	}

	private void enterUserPass(String user, String pass) {
		element(username).waitUntilVisible();
		element(username).type(user);
		element(password).waitUntilVisible();
		element(password).type(pass);
		logger.info("User. and pass. entered");
		element(domain).waitUntilVisible();
		element(domain).selectByValue("lab");
		element(signin).waitUntilVisible();
		element(signin).click();
	}

	public void closeDriver() {
		getDriverInstance().close();
	}

}
