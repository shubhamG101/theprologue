package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OutboundMovePage extends PageObject {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	YMSHelper ymsHelper= new YMSHelper();
	
	@FindBy(id = "dcNbr")
	private WebElement dcNumberField;

	@FindBy(id = "subCenterId")
	private WebElement subCenterIdField;
	
	@FindBy(id = "doorId")
	private WebElement doorNumberField;

	@FindBy(id = "trailerId")
	private WebElement trailerNumberField;
	
	@FindBy(id = "hhOutboundSubmit")
	private WebElement retrieveButton;
	
	@FindBy(id = "executeTrailerMoveForm_shippingAllocationVO_destNbr")
	private WebElement destinationField;
	
	@FindBy(id = "trailerStatCode")
	private WebElement walmartStatusField;
	
	@FindBy(id = "autoFIDBatchNbr")
	private WebElement batchNumberField;
	
	@FindBy(id = "leaveDoorOpenId")
	private WebElement leaveDoorOpenField;
	
	@FindBy(id = "Move")
	private WebElement moveButton;
	
	@FindBy(xpath = "(//div[@class='errorDH'])[3]/ul/li")
	private WebElement errorMsgLabel;

	@FindBy(xpath = "//*[@class='successDH']/ul/li")
	public WebElement successMsgLabel;
	
	public void enterTrailerDetails(String doorNumber, String trailerNumber) {
		element(dcNumberField).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number", true));
		element(retrieveButton).click();
		element(subCenterIdField)
				.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "sub_center", true));
		element(doorNumberField).type(doorNumber);
		element(trailerNumberField).type(trailerNumber);
		element(retrieveButton).click();
	}
	
	public String performOutboundMove() {
		String message="";
		element(destinationField).selectByIndex(1);
		element(walmartStatusField).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "obd_trailer_wmstatus", true));
		element(batchNumberField).type(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "batch_number", true));
		element(leaveDoorOpenField).click();
		element(moveButton).click();
		if (ymsHelper.isElementDisplayed(successMsgLabel))
			message = element(successMsgLabel).getText();
		else
			message=element(errorMsgLabel).getText();
		return message;
	}
	
}
