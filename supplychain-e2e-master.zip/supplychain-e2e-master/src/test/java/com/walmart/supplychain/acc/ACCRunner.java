

/*
 * Please use FeatureList.java to add/remove feature
 */










/*package com.walmart.supplychain.acc;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.framework.supplychain.constants.FileNames;

import cucumber.api.CucumberOptions;


@RunWith(com.walmart.supplychain.CustomSerenityRunner.class)
@CucumberOptions(features= {
		FileNames.ACC_BASE_FILE,
		FileNames.ACC_SAMEPO_MULTIPLEDELIVERY,
		FileNames.ACC_NO_ALLOCATION_FILE,
		FileNames.ACC_PRE_RECEIVING_DAMAGE,
		FileNames.ACC_BASE_FILE_BREAKPACK,
		FileNames.ACC_SSTK_OFFLINE_ONLINE_DOOR_FILE,
		FileNames.ACC_OVERAGE_FILE,
		FileNames.ACC_DELIVERY_FINALIZATION_FILE,
		//FileNames.ACC_MANUALPO_BASE_FILE,
		FileNames.ACC_PO_UPDATE_FILE,
		FileNames.ACC_DOCK_TAG,
		FileNames.ACC_LABELS_GENERATION,
		FileNames.ACC_PROBLEM_NA_APP,
		FileNames.ACC_LOADING,
		FileNames.ACC_PROBLEM_OV_APP,
		FileNames.ACC_DA_NONCON_ONLINE,
		FileNames.ACC_BUMER_EXCEPTION_LPN,
		FileNames.ACC_CLOSE_LOAD_WITHOUT_STOP_DIVERSION,
		FileNames.ACC_DELETE_LOAD
		},monochrome=true,
		glue = { "com.walmart.supplychain.nextgen","com.walmart.supplychain.acc"})

public class ACCRunner {
	static Logger logger = LoggerFactory.getLogger(ACCRunner.class);
	@BeforeClass
    public static void executeBeforeAllTests() {

		logger.info("This will run before all the test features triggered by this runner");
		
    }


    @AfterClass
    public static void executeAfterAllTests() {
    	logger.info("This will run after all the test features triggered by this runner");

    }

	
}
*/