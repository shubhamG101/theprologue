package com.walmart.supplychain.rdc.location.steps;

import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;

import io.restassured.response.Response;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class LocationStep {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	RDCUtil rdcUtil;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	PreRunCleanup preRunCleanup;

	Response response;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	ObjectMapper om = new ObjectMapper();

	@Autowired
	JavaUtils javaUtil;

	Response apiResponse;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String ABSOLUTE_PATH = "/src/test/resources/TestData/rdc/";
	private static final String GET_DELIVERY_NBR = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*].poNumber";
	private static final String GET_DOOR_NBR = "$.testFlowData.deliveryDetails[*].inboundDoorNumber";
	String testFlowData;

	@Step
	public void validateDoor() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			List<String> deliveryDoorList = parsedtestflowJson.read(GET_DOOR_NBR);
			String doorNum = deliveryDoorList.get(0);

			String doorSearchResponse = rdcUtil.searchDoorInLocation(doorNum);

			JSONParser parserPojo = new JSONParser();
			net.minidev.json.JSONObject json = (net.minidev.json.JSONObject) parserPojo.parse(doorSearchResponse);
			net.minidev.json.JSONArray successTuplesArr = (net.minidev.json.JSONArray) json.get("successTuples");
			net.minidev.json.JSONObject upperresponseObj = (net.minidev.json.JSONObject) successTuplesArr.get(0);
			net.minidev.json.JSONObject responseObj = (net.minidev.json.JSONObject) upperresponseObj.get("response");
			net.minidev.json.JSONArray locationArr = (net.minidev.json.JSONArray) responseObj.get("locations");

			if (locationArr.size() == 0) {
				rdcUtil.addDoorInLocation(doorNum);
				logger.info("successfully added Door:" + doorNum + " in Location");
			} else {
				logger.info("Door is already present in Location");
			}

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_LOCATION, e);
		}
	}

}
