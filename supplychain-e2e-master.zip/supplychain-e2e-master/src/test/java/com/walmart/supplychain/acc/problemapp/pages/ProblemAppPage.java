package com.walmart.supplychain.acc.problemapp.pages;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;

public class ProblemAppPage extends SerenityHelper {

	Logger logger = LoggerFactory.getLogger(ProblemAppPage.class);
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	PropertyResolver propertyResolver = new PropertyResolver();

	@FindBy(xpath = "//button[@class='bar-buttons bar-buttons-md bar-button bar-button-md bar-button-default bar-button-default-md bar-button-menutoggle bar-button-menutoggle-md']")
	private WebElement menuBar;

	// span[text()='Scan LPN']

	@FindBy(xpath = "//span[text()='Scan LPN']")
	private WebElement problemScanBtn;

	// div[@class='scroll-content']//div//img[@src='assets/icon/group2.png']
	// span[text()='Manual Select']
	// ion-label//h2[text()='emulator']/../..//..//ion-radio//button//span
	// button[@class='bar-button bar-button-md bar-button-default
	// bar-button-default-md']//span[contains(text(),'Done')]
	// button[@class='button button-md button-default
	// button-default-md']//span[@class='button-inner']
	// ion-buttons[@class='bar-buttons bar-buttons-md']//button[@class='button
	// button-md button-default button-default-md']//span
	// searchbar-input
	//// span[text()='OK']
	////page-create-container//a[text()='Create New Container']

	@FindBy(xpath = "//a[text()='Create New Problem']")
	private WebElement createProbTktBtn;

	@FindBy(xpath = "//span[text()='Manual Select']")
	private WebElement manualPrinterBtn;

	@FindBy(xpath = "//ion-label//h2[text()='Emulator']/../..//..//ion-radio//button//span")
	private WebElement selectEmulatorPrinter;

	@FindBy(xpath = "//ion-button[@class='bar-buttons bar-buttons-md']//button[@class='bar-button bar-button-md bar-button-default bar-button-default-md']")
	private WebElement PrinterDoneBtn;

	@FindBy(xpath = "//button[@class='button button-md button-default button-default-md']//span[@class='button-inner']")
	private WebElement contrAssociateBtn;

	@FindBy(xpath = "//ion-buttons[@class='bar-buttons bar-buttons-md']//button[@class='button button-md button-default button-default-md']//span")
	private WebElement contrAssociateNextBtn;

	@FindBy(xpath = "//a[contains(text(),'Create New Container')]")
	private WebElement createContainer;
	
	@FindBy(xpath = "//page-create-container//a[text()='Create New Container']")
	private WebElement createContainerTwice;

	@FindBy(xpath = "//input[@class='searchbar-input']")
	private WebElement cntrSearchInput;

	@FindBy(xpath = "//span[text()='OK']")
	private WebElement popUpOk;

	public void clickMenuBar() {
		element(menuBar).waitUntilClickable();
		click(menuBar);
		logger.info("Clicked on menu bar");
	}

	public void clickProblemBtn() {
		element(problemScanBtn).waitUntilClickable();
		click(problemScanBtn);
		logger.info("Clicked on problemScanBtn");
	}

	public void scanProblemLPN(String lpn) {
		try {
			logger.info("scanning problem lpn ..........");
			Thread.sleep(3000);
			WebDriver driver = getDriverInstance();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '"
					+ lpn + "'; return scan;})()));");
			logger.info("scanned problem lpn ..........");
		} catch (Exception e) {

		}

	}

	public void scanInputLpn(String lpn) {
		element(cntrSearchInput).waitUntilVisible();
		element(cntrSearchInput).typeAndEnter(lpn);
	}

	public void clickCreateProbTkt() {
		element(createProbTktBtn).waitUntilClickable();
		click(createProbTktBtn);
		logger.info("Clicked on create problem ticket button");
	}

	public void clickManualPrinter() {
		try {
			Thread.sleep(3000);
			element(manualPrinterBtn).waitUntilClickable();
			click(manualPrinterBtn);
			logger.info("Clicked on manual printer button");
		} catch (Exception e) {

		}
	}

	public void selectEmulatorPrinter() {
		try {
			Thread.sleep(3000);
			element(selectEmulatorPrinter).waitUntilClickable();
			click(selectEmulatorPrinter);
			logger.info("Selected Emulator printer .......................");
		} catch (Exception e) {

		}
	}

	public void clickPrinterDone() {
		try {
			Thread.sleep(3000);
			WebDriver driver = getDriverInstance();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement done = driver.findElement(By.xpath("//span[contains(text(),'Done')]"));
			done.isDisplayed();
			js.executeScript("arguments[0].click();", done);
			logger.info("Clicked on Printer Done Button .......................");
		} catch (Exception e) {

		}
	}

	public void clickContainerAssociateBtn() {
		try {
			Thread.sleep(3000);
			element(contrAssociateBtn).waitUntilClickable();
			click(contrAssociateBtn);
			logger.info("Clicked on container associate Button .......................");
		} catch (Exception e) {

		}
	}

	public void clickContainerAssociateNextBtn(String parentCntrId) {
		try {
			Thread.sleep(3000);
			WebDriver driver=getDriverInstance();
			WebElement cntrAssociateBtn=driver.findElement(By.xpath("//h2[contains(text(),'"+parentCntrId+"')]//..//ion-buttons//button//span"));
			element(cntrAssociateBtn).waitUntilClickable();
			click(cntrAssociateBtn);
			logger.info("Clicked on container associate next Button .......................");
		} catch (Exception e) {

		}
	}

	public void clickCreateContainerBtn() {
		try {
			Thread.sleep(3000);
			element(createContainer).waitUntilClickable();
			click(createContainer);
			logger.info("Clicked on Create container Button .......................");
		} catch (Exception e) {

		}
	}
	
	public void clickCreateContainerBtnTwice() {
		try {
			Thread.sleep(3000);
			element(createContainerTwice).waitUntilClickable();
			click(createContainerTwice);
			logger.info("Clicked on Create container Button twice.......................");
		} catch (Exception e) {

		}
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);

	}

	public void handleProblemPopup() {
		element(popUpOk).waitUntilClickable();
		element(popUpOk).click();

	}
}
