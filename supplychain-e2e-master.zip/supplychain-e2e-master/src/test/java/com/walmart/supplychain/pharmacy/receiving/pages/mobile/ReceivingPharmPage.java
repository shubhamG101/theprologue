package com.walmart.supplychain.pharmacy.receiving.pages.mobile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingPharmPage extends SerenityHelper {
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s
	final String RECEIVING_MOBILE_ID = "com.walmart.move.nim.receiving.mobile:id/";
	final String POPUP_MESSAGE = "android:id/message";
	final String IMPLICIT_TIMEOUT = "webdriver.timeouts.implicitlywait";
	final String WAIT_TIMEOUT = "webdriver.wait.for.timeout";
	
	boolean problemTicketDisplayed = false;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.auth.app:id/userid']")
	private WebElement userName;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.auth.app:id/password']")
	private WebElement pass;

	@FindBy(xpath = ".//*[@resource-id='android:id/text1']")
	private WebElement dcDropdown;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.auth.app:id/site_id']")
	private WebElement site;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.auth.app:id/sign_in']")
	private WebElement signInBtn;

	@FindBy(xpath = "//android.view.View[contains(@text,'Atlas Receiving')]")
	private WebElement receivingApp;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "et_del_door")
	private WebElement doorOrDeliveryScanTextBox;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "tv_total_cases")
	private WebElement totalCasesConfirmTrailerScreen;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "tv_received_cases")
	private WebElement totalReceivedCasesConfirmTrailerScreen;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "tv_trailer_number")
	private WebElement trailerNumber;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "btn_agree_trailer_agreement")
	private WebElement agreeBtnTrailerAgreement;

	@FindBy(id = RECEIVING_MOBILE_ID + "tv_qtyLabel")
	private WebElement totalCases;

	@FindBy(id = RECEIVING_MOBILE_ID + "action_cancel_pallet")
	private WebElement cancelPalletButton;

	@FindBy(xpath = "//*[@text='Yes, cancel pallet']")
	private WebElement yesCancelPalletButton;

	@FindBy(id = RECEIVING_MOBILE_ID + "mbt_scan_each_unit")
	private WebElement scanIndividualUnitsButton;

	@FindBy(xpath = "//*[@text='Yes, scan units']")
	private WebElement yesScanUnitsButton;

	@FindBy(id = RECEIVING_MOBILE_ID + "mbtn_done_button")
	private WebElement doneButton;

	@FindBy(xpath = "//*[@text='Yes, partial case']")
	private WebElement yesPartialCaseButton;

	@FindBy(id = RECEIVING_MOBILE_ID + "cp_partial_case")
	private WebElement partialCaseText;

	@FindBy(id = RECEIVING_MOBILE_ID + "mbtn_receive")
	private WebElement receiveButton;

	@FindBy(xpath = "//*[@text='Yes, receive pallet']")
	private WebElement yesReceiveButton;

	@FindBy(xpath = "//*[@resource-id='" + RECEIVING_MOBILE_ID + "tv_scan_pallet_title'] | //*[@resource-id='" + RECEIVING_MOBILE_ID + "tv_scan_unit_title'] | //*[@resource-id='" + RECEIVING_MOBILE_ID + "tv_scan2dLabel']")
	private WebElement scanSSCCor2DBarcodeTitle;

	@FindBy(xpath = "//*[@text='Cancel']")
	private WebElement cancelReceiveButton;

	@FindBy(xpath = "//*[@text='Ok']")
	private WebElement okPopupButton;

	@FindBy(id = POPUP_MESSAGE)
	private WebElement errorMessageBox;

	@FindBy(id = RECEIVING_MOBILE_ID + "tv_unitsPerCase")
	private WebElement unitsPerCase;

	@FindBy(id = RECEIVING_MOBILE_ID + "btn_complete_del")
	private WebElement completeDeliveryButton;

	@FindBy(xpath = "//*[@text='Yes, complete delivery']")
	private WebElement yesBtnForCompleteDelivery;

	@FindBy(xpath = "//*[@text='Cancel']")
	private WebElement cancelCompleteDeliveryBtn;

	@FindBy(id = RECEIVING_MOBILE_ID + "summary_title")
	private WebElement deliveryCompleted;

	@FindBy(id = RECEIVING_MOBILE_ID + "cases_received")
	private WebElement receivedCase;

	@FindBy(id = RECEIVING_MOBILE_ID + "cases_count")
	private WebElement receivedCaseCount;

	@FindBy(xpath = "//*[@text='Close']")
	private WebElement closeButton;

	@FindBy(xpath = "//*[@text='Receiving']")
	public WebElement receivngScreen;;

	@FindBy(id = POPUP_MESSAGE)
	private WebElement errorMsgOnDoorScan;

	@FindBy(xpath = "//android.widget.ImageButton[@content-desc='Navigate up']")
	private WebElement navigateBackButton;

	@FindBy(xpath = "//*[@text='Yes, exit']")
	private WebElement exitButton;

	@FindBy(xpath = "//android.widget.ImageButton[@content-desc='Open navigation drawer']")
	private WebElement leftMenuBar;

	@FindBy(xpath="//*[@text='Label Correction']")
	private WebElement labelCorrectTitle;

	@FindBy(id = RECEIVING_MOBILE_ID + "labelCorrectionNavigation")
	private WebElement labelCorrectOption;

	@FindBy(id = RECEIVING_MOBILE_ID + "btn_cancel_label")
	private WebElement cancelLabelButton;

	@FindBy(id = RECEIVING_MOBILE_ID + "tv_caseToReceive")
	private WebElement expectedQtyToRcv;

	@FindBy(id = RECEIVING_MOBILE_ID + "et_qtyReceiveEntry")
	private WebElement enterQtyToRcv;

	@FindBy(id = RECEIVING_MOBILE_ID + "mbtn_next")
	private WebElement nextBtn;

	@FindBy(id = RECEIVING_MOBILE_ID + "cv_title")
	private WebElement upcNumber;

	@FindBy(id = RECEIVING_MOBILE_ID + "mbtn_upcReceive")
	private WebElement receiveBtn;

	@FindBy(id = RECEIVING_MOBILE_ID + "upc_caseIdentified")
	private WebElement receivableQty;

	@FindBy(id = RECEIVING_MOBILE_ID + "tv_received_cases")
	private WebElement nbrOfPalletReceived;

	@FindBy(id = RECEIVING_MOBILE_ID + "cv_title")
	private WebElement itemUpcinUI;
	
	@FindBy(xpath = "//*[@text='Update GTIN' and @class = 'android.widget.Button']")
	private WebElement updateGTINButton;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "title_bottomSheet")
	private WebElement updateGTINScreenTitle;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "rb_case2DBarcode")
	private WebElement case2DBarcodeSelectType;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "btn_receivePartialCase")
	private WebElement recivePartialCaseLink;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "btn_primaryAction")
	private WebElement continue2DBarcodeSelectButton;
	
	@FindBy(xpath = "//android.widget.ImageView[@content-desc='More options']")
	private WebElement rightSide3DotMenu;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "content")
	private WebElement printDeliveryLabelOption;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "et_deliveryLabelCount")
	private WebElement numberOFLabelsToPrintTextBox;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "btn_primaryAction")
	private WebElement printButton;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "mbtn_mark_del_unloaded")
	private WebElement markDeliveryUnloadedLink;
	
	@FindBy(xpath = "//*[@text='Delivery unloaded']")
	private WebElement deliveryUnloadConfirmationButton;
	
	@FindBy(xpath = "//*[contains(@text,'Delivery unloaded')]")
	private WebElement checkForDeliveryUnloadedText;

	@FindBy(xpath = "//*[contains(@text,' No delivery attached for Door Number')]")
	private WebElement noDeliveryAttachedForDoorErrorMssg;
	
	@FindBy(id = POPUP_MESSAGE)
	private WebElement overagePopupMessage;
	
	@FindBy(id = POPUP_MESSAGE)
	private WebElement itemNotFoundPopupMessage;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "et_item_number")
	private WebElement itemNumberTextbox;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "btn_search_item")
	private WebElement searchItemButton;
	
	@FindBy(id = RECEIVING_MOBILE_ID + "item_gtin")
	private WebElement gtinItemDetails;
	
	@FindBy(xpath = "//*[@text='Yes, receive item']")
	private WebElement yesReceiveItemButton;

	@FindBy(id = RECEIVING_MOBILE_ID+"btn_action")
	private WebElement changeSlotbtn;

	@FindBy (xpath = "//*[@resource-id='" + RECEIVING_MOBILE_ID +"cp_manual_slot']")
	private WebElement manualSlotting;

	@FindBy(id = RECEIVING_MOBILE_ID+"et_slot")
	private WebElement enterSlotId;

	@FindBy(id = RECEIVING_MOBILE_ID+"btn_primaryAction")
	private WebElement saveBtn;

	@FindBy(id = RECEIVING_MOBILE_ID+"tv_title")
	private WebElement manualSlotSelected;

	@FindBy(id = "android:id/button1")
	private WebElement reopenDeliveryBtn;

	@FindBy(xpath="(//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/title'])[2]")
	private WebElement labelCancel;

	@FindBy(xpath = "//*[@resource-id='"+RECEIVING_MOBILE_ID+"action_done']")
	private WebElement doneButtonMultiSKU;
	
	@FindBy(id = RECEIVING_MOBILE_ID+"tv_itemNumberValue")
	private WebElement itemText;
	
	@FindBy(id = RECEIVING_MOBILE_ID+"tv_newGtinValue")
	private WebElement gtinText;
	
	@FindBy(xpath = "//*[@text='Yes, leave pallet open']")
	private WebElement yesleavePalletOenButton;
	
	@FindBy(xpath = "//*[@text='See all']")
	private WebElement seeAllPallet;
	
	@FindBy(xpath = "//*[@text='Select all']")
	private WebElement selectAllPallet;
	
	@FindBy(xpath = "//*[@text='Transfer']")
	private WebElement transferPalletBtn;
	
	@FindBy(xpath = "//*[@text='Yes, transfer']")
	private WebElement clickOnYestTransferPalletBtn;
	
	@FindBy(xpath = "//*[@text='Transfer successful']")
	private WebElement transferSuccessMsg;
	
	@FindBy(xpath = "//*[@text='Ok']")
	private WebElement okBtn;
	
	@FindBy(xpath = "//*[@text='NDC']")
	private WebElement NDC;
	
	@FindBy(xpath = "//*[@text='I0766']")
	private WebElement I0766;
	
	@FindBy(xpath = "//android.widget.TextView[contains(@text,'Item')]")
	private WebElement containsitem;
	
	@FindBy(xpath = "//*[@text='Update']")
	private WebElement updateBtn;
	
	@FindBy(xpath = "//*[@text='exit_to_app Sign Out']")
	private WebElement signoutBtn;
	
	@FindBy(xpath = "//*[@text='System Admin']")
	private WebElement getUser;
	
	@FindBy(className = "android.widget.Button")
	private WebElement hamburger;

	public void closeBrowser() {
		getDriver().quit();
	}

	WebDriver driver = null;

	public boolean loginToMyapps(String user, String password, String facilityNum) {
		String implicitTimeout = System.getProperty(IMPLICIT_TIMEOUT);
		String waitTimeout = System.getProperty(IMPLICIT_TIMEOUT);
		int implicitNegativeTimeout = 5000;
		boolean isReceivingAppOpen = false;
		try {
			System.setProperty(IMPLICIT_TIMEOUT, "" + implicitNegativeTimeout);
			System.setProperty(WAIT_TIMEOUT, "" + implicitNegativeTimeout);
			
			clickOnReceivingApp();
			isReceivingAppOpen = true;
		} catch(Exception e) {
			element(userName).waitUntilVisible();
			element(userName).type(user);

			element(pass).waitUntilVisible();
			element(pass).type(password);

			element(site).waitUntilVisible();
			element(site).clear();
			element(site).type(facilityNum);

			element(signInBtn).waitUntilVisible();
			element(signInBtn).click();

			logger.info(" Rec PHARMACY ****");
		} finally {
			System.setProperty(IMPLICIT_TIMEOUT, "" + implicitTimeout);
			System.setProperty(WAIT_TIMEOUT, "" + waitTimeout);
		}
		return isReceivingAppOpen;
	}
	
	public void logoutAndThenLoginToMyApps(String nextGenUserName, String pharmacy_User_2, String nextGenPassword, String pharmacy_password_2, String facilityNum, boolean transferPallet) {
		
		element(hamburger).waitUntilVisible();		
		element(hamburger).click();		
		final String currentUser = element(getUser).getText();
		logger.info("currentUser is "+currentUser);
		element(signoutBtn).waitUntilVisible();
		element(signoutBtn).click();
		logger.info("clicked on signoutBtn");
		
		if (currentUser.equalsIgnoreCase("System Admin")){		
			element(userName).waitUntilVisible();
			element(userName).type(pharmacy_User_2);

			element(pass).waitUntilVisible();
			element(pass).type(pharmacy_password_2);		
		}
		else{
			element(userName).waitUntilVisible();
			element(userName).type(nextGenUserName);

			element(pass).waitUntilVisible();
			element(pass).type(nextGenPassword);		
		}
		
			element(site).waitUntilVisible();
			element(site).clear();
			element(site).type(facilityNum);

			element(signInBtn).waitUntilVisible();
			element(signInBtn).click();
		}
		
		public void clickOnReceivingApp() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("Clicking on Atlas Receiving Application");
		element(receivingApp).waitUntilVisible();
		element(receivingApp).click();
		logger.info("Clicked on Atlas Receiving Application");
	}
	
	public int getTotalCasesConfirmTrailerScreen() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("Getting Total No of Cases");
		element(totalCasesConfirmTrailerScreen).waitUntilVisible();
		return Integer.parseInt(element(totalCasesConfirmTrailerScreen).getText().split(" ")[0]);
	}
	
	public Integer getTotalReceivedCasesConfirmTrailerScreen() {
		logger.info("Getting Total No of Received Cases");
		element(totalReceivedCasesConfirmTrailerScreen).waitUntilVisible();
		return Integer.parseInt(element(totalReceivedCasesConfirmTrailerScreen).getText().split(" ")[0]);
	}
	
	public String getTrailerNumberText() {
		logger.info("Getting Trailer Number Text ");
		element(trailerNumber).waitUntilVisible();
		return element(trailerNumber).getText().split(" ")[1];
	}

	public void clickOnAgreeTrailerAgreement() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("Clicking on Agree Button on Trailer Agreement Screen");
		element(agreeBtnTrailerAgreement).waitUntilVisible();
		element(agreeBtnTrailerAgreement).click();
		logger.info("Clicked on Agree Button on Trailer Agreement Screen");
	}

	public int getTotalCaseCount() {
		logger.info("Getting total cases count");
		element(totalCases).waitUntilVisible();
		int totalCaseCount = Integer.parseInt(element(totalCases).getText().split(" ")[0]);
		logger.info("Total case Count=" + totalCaseCount);
		return totalCaseCount;
	}

	public void clickOnCancelPallet() {
		logger.info("Clicking on Cancel Pallet Button");
		element(cancelPalletButton).waitUntilVisible();
		element(cancelPalletButton).click();
		logger.info("Clicked on Cancel Pallet Button");
	}

	public void clickOnYesCancelPallet() {
		logger.info("Clicking on Yes, Cancel Pallet Button");
		element(yesCancelPalletButton).waitUntilVisible();
		element(yesCancelPalletButton).click();
		logger.info("Clicked on Yes, Cancel Pallet Button");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clickOnScanIndividualUnitsButton() {
		logger.info("Clicking on Scan Individual Units Button");
		element(scanIndividualUnitsButton).waitUntilVisible();
		element(scanIndividualUnitsButton).click();
		logger.info("Clicked on Scan Individual Units Button");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clickOnYesScanUnitsButton() {
		logger.info("Clicking on Yes, Scan Units Button");
		element(yesScanUnitsButton).waitUntilVisible();
		element(yesScanUnitsButton).click();
		logger.info("Clicked on Yes, Scan Units Button");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clickOnDoneButton() {
		logger.info("Clicking on Done Button");
		element(doneButton).waitUntilVisible();
		element(doneButton).click();
		logger.info("Clicked on Done Button");
	}

	public void clickOnYesPartialCaseButton() {
		logger.info("Clicking on Yes, Partial Case Button");
		element(yesPartialCaseButton).waitUntilVisible();
		element(yesPartialCaseButton).click();
		logger.info("Clicked on Yes, Partial Case Button");
		logger.info("Waiting for \"Partial case\" text to appear");
		element(partialCaseText).waitUntilVisible();
		logger.info("Waited for \"Partial case\" text to appear");
	}

	public void clickOnReceiveButton() {
		logger.info("Clicking on Receive Button");
		element(receiveButton).waitUntilVisible();
		element(receiveButton).click();
		logger.info("Clicked on Receive Button");
	}

	public void clickOnYesReceiveButton() {
		logger.info("Clicking on Yes, Receive Button");
		element(yesReceiveButton).waitUntilVisible();
		element(yesReceiveButton).click();
		logger.info("Clicked on Yes, Receive Button");
		waitForScanSSCCor2DBarcodeScreenToAppear();
	}

	public void waitForScanSSCCor2DBarcodeScreenToAppear() {
		logger.info("Waiting for \"Scan a pallet SSCC to receive\" to appear");
		element(scanSSCCor2DBarcodeTitle).waitUntilVisible();
		logger.info("Waited for \"Scan a pallet SSCC to receive\" to appear");
	}
	
	public void waitForDoorOrDeliveryScanScreenToAppear() {
		logger.info("Waiting for \"Door or Delivery Scan Textbox\" to appear");
		element(doorOrDeliveryScanTextBox).waitUntilVisible();
		logger.info("Waited for \"Door or Delivery Scan Textbox\" to appear");
	}

	public void clickOnCancelReceiveButton() {
		logger.info("Clicking on No, Receive Button");
		element(cancelReceiveButton).waitUntilVisible();
		element(cancelReceiveButton).click();
		logger.info("Clicked on No, Receive Button");
	}

	public void clickOnOkButton() {
		logger.info("Clicking on Receive Button");
		element(okPopupButton).waitUntilVisible();
		element(okPopupButton).click();
		logger.info("Clicked on Receive Button");
	}

	public boolean isErrorMessageBoxDisplayed() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return element(errorMessageBox).isDisplayed();
	}

	public String getUnitsPerCaseQty() {
		logger.info("validating total number of cases in the 2D BARCODE Scan page");
		element(unitsPerCase).waitUntilVisible();
		return element(unitsPerCase).getText();
	}

	public void clickOnCompleteDeliveryButton() {
		sleep();
		element(completeDeliveryButton).waitUntilVisible();
		element(completeDeliveryButton).click();
	}

	public void clickOnYesButtonForCompleteDelivery() {
		element(yesBtnForCompleteDelivery).waitUntilVisible();
		element(yesBtnForCompleteDelivery).click();
	}

	public void clickOnCancelButtonForCompleteDelivery() {
		element(cancelCompleteDeliveryBtn).waitUntilVisible();
		element(cancelCompleteDeliveryBtn).click();
	}

	public String getDeliveryCompleteSuccessMssg() {
		element(deliveryCompleted).waitUntilVisible();
		String completeDeleiverySuccessMssg = element(deliveryCompleted).getText();
		logger.info("Complete Delivery has been done Successfully :" + completeDeleiverySuccessMssg);
		return completeDeleiverySuccessMssg;
	}

	public String receivedCaseCountInCompltDeliveryScreen() {
		element(deliveryCompleted).waitUntilVisible();
		return element(receivedCaseCount).getText();
	}

	public String totalCaseReceivedTextMsg() {
		element(deliveryCompleted).waitUntilVisible();
		return element(receivedCase).getText();
	}

	public String clickOnCloseButton() {
		element(closeButton).waitUntilVisible();
		element(closeButton).click();
		element(receivngScreen).waitUntilVisible();
		return element(receivngScreen).getText();

	}

	public String validateErrMsgOnDoorScan() {
		element(errorMsgOnDoorScan).waitUntilVisible();
		return element(errorMsgOnDoorScan).getText();

	}

	public void navigateBack() {
		element(navigateBackButton).waitUntilVisible();
		element(navigateBackButton).click();
	}

	public void clickOnExitButton() {
		element(exitButton).waitUntilVisible();
		element(exitButton).click();
	}

	public void clickOnLeftMenuBar() {
		element(leftMenuBar).waitUntilVisible();
		element(leftMenuBar).click();
	}

	public void selectLabelCorrectionOption() {
		element(labelCorrectOption).waitUntilVisible();
		element(labelCorrectOption).click();
	}
	public String countOfPalletReceived() {
		return element(nbrOfPalletReceived).getText();
	}

	public String validateExpectedReceivableqtyInUI() {
		return expectedQtyToRcv.getText();
	}

	public String validateExpectedItemUPCInUI() {
		return itemUpcinUI.getText();
	}

	public WebElement enterQtyForReceiving() {
		return enterQtyToRcv;
	}

	public void receiveD40Item() {
		element(nextBtn).waitUntilEnabled();
		nextBtn.click();
		element(receivableQty).waitUntilVisible();
		receiveBtn.click();
		logger.info("Full Receiving done");

	}
	public void clickOnCancelLabelButtonForLabelCorrection() {
		element(cancelLabelButton).waitUntilVisible();
		element(cancelLabelButton).click();
	}

	public void checkForlabelCorrectionScreen() {
		element(labelCorrectTitle).waitUntilVisible();
	}
	
	public void clickUpdateGTINButton(boolean updateGTINScreenDisplayed) {
		logger.info("Clicking on Update GTIN Button");
		element(updateGTINButton).waitUntilVisible();
		element(updateGTINButton).click();
		logger.info("Clicked on Update GTIN Button");
		if(updateGTINScreenDisplayed) {
		logger.info("Waiting for Update GTIN Screen to appear");
		element(updateGTINScreenTitle).waitUntilVisible();
		logger.info("Waited for Update GTIN Screen to appear");
		}
	}
	
	public void selectCaseIn2DBarcodeType() {
		logger.info("Selecting Case Type 2D Barcode Button");
		element(case2DBarcodeSelectType).waitUntilVisible();
		element(case2DBarcodeSelectType).click();
		logger.info("Selected Case Type 2D Barcode Button");
		logger.info("Clicking on Case Type 2D Barcode Button");
		element(continue2DBarcodeSelectButton).waitUntilVisible();
		element(continue2DBarcodeSelectButton).click();
		logger.info("Clicked on Case Type 2D Barcode Button");
	}
	
	public void clickReceivePartialCaseLink() {
		logger.info("Clicking on 'Receive Partial Case' Link");
		element(recivePartialCaseLink).waitUntilVisible();
		element(recivePartialCaseLink).click();
		logger.info("Clicking on 'Receive Partial Case' Link");
	}
	
	public void clickOnRightSide3DotMenu() {
		element(rightSide3DotMenu).waitUntilVisible();
		element(rightSide3DotMenu).click();
	}
	
	public void clickOnPrintDeliveryLabelOption() {
		element(printDeliveryLabelOption).waitUntilVisible();
		element(printDeliveryLabelOption).click();
	}
	
	public void enterNumberOFLabelsToPrintTextBox(String numberOfLabels) {
		logger.info("Entering number of Labels to Print");
//		element(numberOFLabelsToPrintTextBox).waitUntilVisible();
//		element(numberOFLabelsToPrintTextBox).type(numberOfLabels);
//		element(numberOFLabelsToPrintTextBox).sendKeys(Keys.ENTER);
		logger.info("Entered number of Labels to Print");
	}
	
	public void clickOnPrintButton() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		element(printButton).waitUntilVisible();
		element(printButton).click();
	}

	public void clickOnMarkDeliveryUnloadedLink() {
		logger.info("Clicking on Mark Delivery Unloaded link");
		element(markDeliveryUnloadedLink).waitUntilVisible();
		element(markDeliveryUnloadedLink).click();
		logger.info("Clicked on Mark Delivery Unloaded link");
	}
	
	public void clickOnDelievryUnloadConfirmationButton() {
		element(deliveryUnloadConfirmationButton).waitUntilVisible();
		element(deliveryUnloadConfirmationButton).click();
	}
	
	public void checkForDeliveryUnloadedTextMessage() {
		element(checkForDeliveryUnloadedText).waitUntilVisible();
	}
	
	public void checkForNoDeliveryAttachedForDoorErrorMssg() {
		element(noDeliveryAttachedForDoorErrorMssg).waitUntilVisible();
	}
	
	public void clickOnOkButtonOnPopup() {
		element(okPopupButton).waitUntilVisible();
		element(okPopupButton).click();
	}
	
	public String getCaseOverageMessageText() {
		logger.info("Validating Case Overage Popup Message");
		element(overagePopupMessage).waitUntilVisible();
		return element(overagePopupMessage).getText().trim();
	}
	
	public String getItemNotFoundMessageText() {
		logger.info("Validating Item Not Found Popup Message");
		element(itemNotFoundPopupMessage).waitUntilVisible();
		return element(itemNotFoundPopupMessage).getText().trim();
	}
	
	public void enterItemNumber(String itemNumber) {
		logger.info("Entering Item Number");
		element(itemNumberTextbox).waitUntilVisible();
		element(itemNumberTextbox).sendKeys(itemNumber);
		logger.info("Entered Item Number");
	}
	
	public void clickSearchItemButton() {
		logger.info("Clicking on Search Item Button");
		element(searchItemButton).waitUntilVisible();
		element(searchItemButton).click();
		logger.info("Clicked on Search Item Button");
	}
	
	public String getGTINItemDetailsText() {
		logger.info("Getting GTINItemDetailsText");
		element(gtinItemDetails).waitUntilVisible();
		return element(gtinItemDetails).getText().split(" ")[1].trim();
	}
	
	
	public void updateButton() {
		logger.info("Clicking on Yes, Receive Item Button");
		element(updateBtn).waitUntilVisible();
		element(updateBtn).click();
		logger.info("Clicked on update Button");
	}
	
	public void clickYesReceiveItemButtonOnPopup() {
		logger.info("Clicking on Yes, Receive Item Button");
		element(yesReceiveItemButton).waitUntilVisible();
		element(yesReceiveItemButton).click();
		logger.info("Clicked on Yes, Receive Item Button");
	}

	public void setManualSlotting(String slotId) {
		logger.info("Clicking on Change btn and proceed with Manual Slotting");
		element(changeSlotbtn).click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		element(manualSlotting).waitUntilClickable();
		element(manualSlotting).click();
		element(enterSlotId).sendKeys(slotId);
		element(saveBtn).click();
		logger.info("Entered slot Number and clicked on save");

	}
	public String manualSlot()
	{return element(manualSlotSelected).getText();}

	public void reopenDelivery()
	{
		reopenDeliveryBtn.click();
	}

	public void labelCancelInsideDelivery() {
		element(rightSide3DotMenu).click();
		element(labelCancel).waitUntilVisible().click();
	}

	public void clickDoneButtonMultiSKU() {
		element(doneButtonMultiSKU).waitUntilVisible();
		element(doneButtonMultiSKU).click();
		element(scanSSCCor2DBarcodeTitle).waitUntilVisible();
	}
	
	public String validateUpdatedGtin() {
		logger.info("Getting updated gtin text");
		element(gtinText).waitUntilVisible();
		logger.info("gtin  get text "+element(gtinText).getText());
		return element(gtinText).getText();
		
	}
	
	public String validateItemInfo() {
		logger.info("Getting ItemDetailsText");
		element(itemText).waitUntilVisible();
		logger.info("item  get text "+element(itemText).getText());
		return element(itemText).getText();
		
	}
	
	public void clickOnYesLeavePalletOpenBtn() {
		logger.info("Clicking on Yes, leave Pallet open Button");
		element(yesleavePalletOenButton).waitUntilVisible();
		element(yesleavePalletOenButton).click();
		logger.info("Clicked on Yes, leave Pallet open Button");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void viewAllOpenPallet() {
		element(seeAllPallet).click();
	}
	
	public void transferOpenPallet() {
		element(selectAllPallet).click();
		element(transferPalletBtn).waitUntilEnabled();
		element(transferPalletBtn).click();
		element(clickOnYestTransferPalletBtn).waitUntilVisible();
		element(clickOnYestTransferPalletBtn).click();
		element(transferSuccessMsg).waitUntilVisible();
		element(okBtn).click();
		logger.info("Pallets transferred successfully");
		element(I0766).click();	
	}
}

