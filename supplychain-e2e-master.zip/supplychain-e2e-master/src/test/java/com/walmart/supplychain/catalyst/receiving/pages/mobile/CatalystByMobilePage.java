package com.walmart.supplychain.catalyst.receiving.pages.mobile;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingHelper;

import android.view.KeyEvent;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystByMobilePage  extends SerenityHelper  {
	Logger logger = LogManager.getLogger(this.getClass());
	
	final String IMPLICIT_TIMEOUT = "webdriver.timeouts.implicitlywait";
	final String WAIT_TIMEOUT = "webdriver.wait.for.timeout";
	
	@Autowired
	CatalystUtil catalystUtil;
	
	@Autowired
	Environment environment;
	
	final String BY_MOBILE_ID = "com.walmart.logistics.blueyonder.mobile/id/";

	@FindBy(xpath = "//*[@resource-id='username']")
	private WebElement byUserNameTextBox;
	
	@FindBy(xpath = "//*[@resource-id='password']")
	private WebElement byPasswordTextBox;
	
	@FindBy(className = "android.widget.Button")
	private WebElement bySignInButton;
	
	@FindBy(className = "android.widget.Button")
	private WebElement byMobileContinueButton;
		
	@FindBy(xpath = "//*[@resource-id='mat-input-0']")
	private WebElement terminalIdTextBox;
	
	@FindBy(xpath ="//*[@resource-id='cdk-overlay-0']//android.widget.Button")
	private WebElement dismissButton;	
	
	@FindBy(xpath = "//*[contains(@text,'Location')]/following-sibling::*[contains(@class,'EditText')]")
	private WebElement locationTextBox;
	
	@FindBy(xpath = "//*[@resource-id='mat-input-2']")
	private WebElement vehicleTypeTextBox;
	
	@FindBy(xpath = "//*[@resource-id='mat-input-3']")
	private WebElement workAreaTextBox;
	
	@FindBy(xpath = "(//*[@class='android.widget.Button'])[5]")
	private WebElement downButton;
	
	@FindBy(xpath = "//android.webkit.WebView/android.view.View[1]/android.view.View/android.widget.Button[2]")
	private WebElement loadTranferDownButton;
	
	@FindBy(xpath = "(//*[@class='android.view.View'])[2]")
	private WebElement optionsButton;
	
	@FindBy(xpath = "//*[@text='Lookup [F2]']")
	private WebElement lookUpButton;
		
	@FindBy(xpath = "//*[@text='Putaway']")
	private WebElement putawayHeading;
	
	@FindBy(xpath = "//*[@text='Pickup Product At']")
	private WebElement pickUpProductAtHeading;
	
	@FindBy(xpath = "//*[@text='Source Location:']")
	private WebElement sourceLocationLabel;
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_MENU.display.option9']")
	private WebElement directedWorkOption;
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_MENU.display.option2']")
	private WebElement inventoryMenuOption;
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_MENU.display.option3']")
	private WebElement partialInvMoveMenuOption;
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_MENU.display.option10']")
	private WebElement nextOption;
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_MENU.display.option6']")
	private WebElement putawayOption;
	
	@FindBy(xpath = "//*[contains(@text,'RCVSTG')]")
	private WebElement sourceLocationValue;
	
	@FindBy(xpath = "//*[contains(@text,'Next')]")
	private WebElement nextButton;
	
	@FindBy(xpath = "//*[@resource-id='mat-input-4']")
	private WebElement inventoryIdentifierTextBox;
	
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_PUTAWAY.invtid']//android.widget.EditText")
	private WebElement putawayInventoryIdentifierTextBox;
	
	
	@FindBy(xpath = "//*[@text='Inventory on Device must be deposited']")
	private WebElement inventoryDepositDialogMessage;
	
	@FindBy(xpath = "//*[contains(@text,'OK')]")
	private WebElement okButton;
	
	@FindBy(xpath = "//android.app.Dialog/android.view.View[2]/android.widget.Button")
	private WebElement yesButton;
	
	@FindBy(xpath = "//*[@text='MRG Product Deposit']")
	private WebElement mrgProductDepositHeading;
	
	@FindBy(xpath = "//android.webkit.WebView/android.view.View[1]/android.view.View/android.view.View[2]/android.view.View[14]/android.view.View[2]")
	private WebElement locationField;
	
	@FindBy(className = "android.widget.EditText")
	private WebElement putawayLocationTextBox;

	@FindBy(xpath = "//*[@text='Undirected Menu']")
	private WebElement undirectedMenuHeading;
	
	@FindBy(xpath = "//*[@text='Pick List At']")
	private WebElement pickListAtHeading;
	
	@FindBy(xpath = "//android.webkit.WebView/android.view.View[1]/android.view.View/android.view.View[2]/android.view.View[3]/android.view.View/android.view.View[2]")
	private WebElement listIdValue;
	
	@FindBy(xpath = "//*[@text='Work Assignment']")
	private WebElement workAssignmentHeading;
	
	@FindBy(className = "android.widget.Spinner")
	private WebElement actionsButton;
	
	@FindBy(xpath = "//*[contains(@text,'NextNum')]")
	private WebElement nextNumOption;
	
	@FindBy(xpath = "//*[contains(@text,'Back')]")
	private WebElement backOption;
	
	@FindBy(className = "android.widget.EditText")
	private WebElement posIdTextbox;
	
	@FindBy(xpath = "//*[@text='Order Pick L']")
	private WebElement orderPickHeading;
	
	@FindBy(className = "android.widget.EditText")
	private WebElement pickingLocationTextbox;
	
	@FindBy(className = "android.widget.EditText")
	private WebElement preWrapLocationTextbox;
	
	@FindBy(xpath = "//android.webkit.WebView/android.view.View[1]/android.view.View/android.view.View[2]/android.view.View[4]/android.view.View/android.view.View[2]")
	private WebElement locationValue;
	
	@FindBy(className = "android.widget.EditText")
	private WebElement pickingQuantityTextbox;
	
	@FindBy(xpath = "//android.webkit.WebView/android.view.View[1]/android.view.View/android.view.View[2]/android.view.View[6]/android.view.View[2]")
	private WebElement quantityValue;
	
	
	@FindBy(xpath = "//android.webkit.WebView/android.view.View[1]/android.view.View/android.view.View[2]/android.view.View[14]/android.view.View[2]")
	private WebElement preWrapLocationValue;

	@FindBy(xpath = "//*[@text='Problem Item']")
	private WebElement problemItemDetailsHeading;

	//Inventory Status Change ELements

	@FindBy(xpath = "//*[@text='CRREWORK']")
	private WebElement problemLocationDisplayed;

	@FindBy(xpath = "//*[contains(@text,'Tools')]")
	private WebElement toolsOption;
	
	@FindBy(xpath = "//android.view.View[3]/android.view.View/android.widget.Button")
	private WebElement maintenanceMenu;
	
	@FindBy(xpath = "//android.view.View[9]/android.widget.Button")
	private WebElement statusChangeOption;
	
	@FindBy(xpath = "//*[@resource-id='TOOLS_STS_CHANGE.invtid']//*[@class='android.widget.EditText']")
	private WebElement inventoryIdentifierUnderInvStsChangeTextBox;
	
	@FindBy(xpath = "//*[@resource-id='TOOLS_STS_CHANGE.newsts']//*[@class='android.widget.EditText']")
	private WebElement newStatusTextBox;
	
	@FindBy(xpath = "//*[@resource-id='TOOLS_STS_CHANGE.reacod']//*[@class='android.widget.EditText']")
	private WebElement reasonCodeTextBox;

	@FindBy(xpath = "//*[contains(@text, 'Status Changed')]")
	private WebElement statusChangedDialogBox;
	
	//Partial Inventory Move
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_TRANSFER.src_id']//*[@class='android.widget.EditText']")
	private WebElement sourceIDTextBox;
	
	@FindBy(xpath = "//*[contains(@text, 'Load Transfer')]")
	private WebElement loadTranferHeading;
	
	@FindBy(xpath = "//*[@resource-id='mat-input-9']")
	private WebElement quantityTextBox;
	
	@FindBy(xpath = "//*[@resource-id='UNDIR_TRANSFER.dst_id']//android.widget.EditText[1]")
	private WebElement destinationIdTextBox;
	
	@FindBy(xpath = "//*[contains(@text,'[L]')]")
	private WebElement loadButton;
	
	
	public void clickOnLoadButton() {
		element(loadButton).waitUntilVisible();
		element(loadButton).waitUntilClickable();
		element(loadButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on Load Menu");		
	}
	
	public void verifyLoadTranferHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(loadTranferHeading));
	}
	
	

	public void enterDestinationIDValue(String destinationIDValue) {
		element(destinationIdTextBox).clear();
		element(destinationIdTextBox).sendKeys(destinationIDValue);
		logger.info("WMT_BY_MOBILE : Entered Destination Identifier Value");		
	}
	
	public void enterValueInQuantityField(String quantity) {
		element(quantityTextBox).clear();
		element(quantityTextBox).sendKeys(quantity);
		logger.info("WMT_BY_MOBILE : Entered Quantity Value");		
	}
	
	public void enterSourceIDValue(String sourceIDValue) {
		element(sourceIDTextBox).clear();
		element(sourceIDTextBox).sendKeys(sourceIDValue);
		logger.info("WMT_BY_MOBILE : Entered Source Identifier Value");		
	}
	
	public void verifyStatusChangedDialogBoxIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(statusChangedDialogBox));
	}
	
	
	public void enterNewStatusValue(String newStatus) {
		element(newStatusTextBox).clear();
		element(newStatusTextBox).sendKeys(newStatus);
		logger.info("WMT_BY_MOBILE : Entered Inventory New Status");		
	}
	
	public void enterReasonCodeValue(String reasonCode) {
		element(reasonCodeTextBox).clear();
		element(reasonCodeTextBox).sendKeys(reasonCode);
		logger.info("WMT_BY_MOBILE : Entered Inventory Status Change reason Code");		
	}
	
	public void enterInventoryIdentifierUnderInvStsChange(String inventoryIndentifier) {
		element(inventoryIdentifierUnderInvStsChangeTextBox).clear();
		element(inventoryIdentifierUnderInvStsChangeTextBox).sendKeys(inventoryIndentifier);
		logger.info("WMT_BY_MOBILE : Entered Inventory Identifier Value under Inventory Status Change");		
	}
	
	public void clickOnToolsOption() {
		element(toolsOption).waitUntilVisible();
		element(toolsOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on Tools Option");		
	}
	
	public void clickOnMaintenanceMenu() {
		element(maintenanceMenu).waitUntilVisible();
		element(maintenanceMenu).click();
		logger.info("WMT_BY_MOBILE : Clicked on Maintenance Menu");		
	}
	
	public void clickOnStatusChange() {
		element(statusChangeOption).waitUntilVisible();
		element(statusChangeOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on Status Change Option");		
	}

	
	WebDriver driver = null;
	
	
	public void enterByUserName(String userName) {
		element(byUserNameTextBox).waitUntilVisible();
		element(byUserNameTextBox).sendKeys(userName);
		logger.info("BY_MOBILE : Entered BY account Username");
	}
	
	public void enterByPassword(String password) {
		element(byPasswordTextBox).waitUntilVisible();
		element(byPasswordTextBox).sendKeys(password);
		logger.info("BY_MOBILE : Entered BY account Password");
	}
	
	public void clickOnBySignInButton() {
		element(bySignInButton).waitUntilVisible();
		element(bySignInButton).click();
		logger.info("BY_MOBILE : Clicked on BY SignIn Button");
	}
	
	public void clickOnByContinueButton() {
		element(byMobileContinueButton).waitUntilVisible();
		element(byMobileContinueButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on By Mobile Continue Button");
	}
	
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return  (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriverInstance()).getProxiedDriver();
		}
	
	public void enterTerminalIdTextBox(String terminalId) {
		//element(terminalIdTextBox).clear();
	//	element(terminalIdTextBox).sendKeys(terminalId);
		element(terminalIdTextBox).sendKeys(terminalId);
		getAndroidDriver().pressKeyCode(66);
		//element(terminalIdTextBox).sendKeys(Keys.ENTER); 
		logger.info("WMT_BY_MOBILE : Entered Terminal Id");		
	}
	
	
	
	public void clickOnByDismissButton() {
		element(dismissButton).waitUntilVisible();
		element(dismissButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on Dismiss Button");		
	}
	
	public void enterLocationValue(String location) {
		element(locationTextBox).clear();
		element(locationTextBox).sendKeys(location);
		logger.info("WMT_BY_MOBILE : Entered Location Value");		
	}
	
	
	public void enterVehicleTypeValue(String vehicleType) {
		element(vehicleTypeTextBox).clear();
		element(vehicleTypeTextBox).sendKeys(vehicleType);
		logger.info("WMT_BY_MOBILE : Entered Vehicle Value {}", vehicleType);		
	}
	
	public void enterWorkAreaValue(String workArea) {
		element(workAreaTextBox).clear();
		element(workAreaTextBox).sendKeys(workArea);
		logger.info("WMT_BY_MOBILE : Entered Work Area Value");		
	}
	
	
	
	public void clickOnDownButton() {
		element(downButton).waitUntilVisible();
		element(downButton).waitUntilClickable();
		element(downButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on Down Button");		
	}
	
	public void clickOnLoadTransferDownButton() {
		element(loadTranferDownButton).waitUntilVisible();
		element(loadTranferDownButton).waitUntilClickable();
		element(loadTranferDownButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on loadTranferDownButton Button");		
	}
	
	public void clickOnOptionsButton() {
		element(optionsButton).waitUntilVisible();
		element(optionsButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on Options Button");		
	}
	
	public void clickOnLookupButton() {
		element(lookUpButton).waitUntilVisible();
		element(lookUpButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on Look Up Button");		
	}
	
	public void clickOnDirectedWorkOption() {
		element(directedWorkOption).waitUntilVisible();
		element(directedWorkOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on  Directed Work Option");		
	}
	
	public void clickOnInventoryMenuOption() {
		element(inventoryMenuOption).waitUntilClickable();
		element(inventoryMenuOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on  Inventory Menu Option");		
	}
	
	public void clickOnPartialInvMoveMenuOption() {
		element(partialInvMoveMenuOption).waitUntilClickable();
		element(partialInvMoveMenuOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on  Partial Inv Menu Option");		
	}
	
	
	public void clickOnNextOption() {
		element(nextOption).waitUntilVisible();
		element(nextOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on Next Option");		
	}
	
	
	public void clickOnPutawayOption() {
		element(putawayOption).waitUntilVisible();
		element(putawayOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on Putaway Option");		
	}
	
	
	public void verifyPutawayHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(putawayHeading));
	}
	
	public void verifyPickUpProductAtHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(pickUpProductAtHeading));
	}
	
	
	public void verifySourceLocationLabelIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(sourceLocationLabel));
	}
	
	public void verifySourceLocationValueIsDisplayed(String location) {
		driver = getDriverInstance();
		element(driver.findElement(By.xpath("//*[contains(@text,'RCVSTG"+location+"')]"))).waitUntilVisible();
		catalystUtil.verifyElementIsDisplayed(element(driver.findElement(By.xpath("//*[contains(@text,'RCVSTG"+location+"')]"))));
		//logger.info("WMT_LAUNCHER : Selected item "+siteNumber+" from the Site Select Box");}
	}
	

	public void clickOnNextButton() {
		element(nextButton).waitUntilVisible();
		element(nextButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on  Next Button");		
	}
	
	public void enterInventoryIdentifier(String inventoryIndentifier) {
		element(inventoryIdentifierTextBox).clear();
		element(inventoryIdentifierTextBox).sendKeys(inventoryIndentifier);
		logger.info("WMT_BY_MOBILE : Entered Inventory Identifier Value");		
	}
	
	public void enterPutawayInventoryIdentifier(String inventoryIndentifier) {
		element(putawayInventoryIdentifierTextBox).clear();
		element(putawayInventoryIdentifierTextBox).sendKeys(inventoryIndentifier);
		logger.info("WMT_BY_MOBILE : Entered Putaway Inventory Identifier Value");		
	}
	
	public void verifyInventoryDepositDialogIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(inventoryDepositDialogMessage));
	}
	
	public void clickOnOkButton() {
		element(okButton).waitUntilVisible();
		element(okButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on  OK Button");		
	}
	
	public void clickOnYesButton() {
		element(yesButton).waitUntilVisible();
		element(yesButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on  yes Button");		
	}
	
	
	public boolean isMrgProductScreenVisible() {
		if(mrgProductDepositHeading.isDisplayed())
			return true;
		else
			return false;
	}

	public void verifyMrgProductDepositHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(mrgProductDepositHeading));
	}
	
	public void enterPutawayLocationTextBox() {
		String putawayDepositLocation=element(locationField).getText();
		logger.info(putawayDepositLocation);
		//element(putawayLocationTextBox).waitUntilEnabled();
		//element(putawayLocationTextBox).clear();
		element(putawayLocationTextBox).sendKeys(putawayDepositLocation);
		logger.info("WMT_BY_MOBILE : Entered Putaway Deposit Location at "+ putawayDepositLocation);		
	}
	
	public void enterDesiredPutawayLocationTextBox(String putawayDepositLocation) {
		logger.info(putawayDepositLocation);
		element(putawayLocationTextBox).clear();
		element(putawayLocationTextBox).sendKeys(putawayDepositLocation);
		logger.info("WMT_BY_MOBILE : Entered Putaway Deposit Location at "+ putawayDepositLocation);		
	}
	
	public void verifyUndirectedMenuHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(undirectedMenuHeading));
	}
	
	public void verifyPickListAtHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(pickListAtHeading));
	}
	
	public void verifyListIdValue(String listIdExpectedValue) {
		catalystUtil.verifyElementValue(element(listIdValue), listIdExpectedValue);
	}
	
	public void verifyWorkAssignmentHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(workAssignmentHeading));
	}
	
	public void verifyProblemItemHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(problemItemDetailsHeading));
	}
	
	public void verifyReworkLocationDisplayedForProblemItem() {
		catalystUtil.verifyElementIsDisplayed(element(problemLocationDisplayed));
	}
	
	public void clickOnBackOption() {
		element(backOption).waitUntilVisible();
		element(backOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on Back Option");		
	}
	
	public void clickOnActionsButton() {
		element(actionsButton).waitUntilVisible();
		element(actionsButton).click();
		logger.info("WMT_BY_MOBILE : Clicked on Actions Button");		
	}
	
	public void clickOnNextNumOption() {
		element(nextNumOption).waitUntilVisible();
		element(nextNumOption).click();
		logger.info("WMT_BY_MOBILE : Clicked on NextNum Option");		
	}
	
	public void enterPosIdValue(String posId) {
		element(posIdTextbox).clear();
		element(posIdTextbox).sendKeys(posId);
		logger.info("WMT_BY_MOBILE : Entered Position Id Value");		
	}
	
	public void verifyOrderPickHeadingIsDisplayed() {
		catalystUtil.verifyElementIsDisplayed(element(orderPickHeading));
	}
	
	public void enterPickingLocationTextBox() {
		String pickingLocation=element(locationValue).getText();
		logger.info(pickingLocation);
		element(pickingLocationTextbox).clear();
		element(pickingLocationTextbox).sendKeys(pickingLocation);
		logger.info("WMT_BY_MOBILE : Entered Picking Location at "+ pickingLocation);		
	}
	
	public void enterPickingQuantityTextBox() {
		String pickingQuantity=element(quantityValue).getText();
		logger.info(pickingQuantity);
		element(pickingQuantityTextbox).clear();
		element(pickingQuantityTextbox).sendKeys(pickingQuantity.substring(0, 1));
		logger.info("WMT_BY_MOBILE : Entered Picking Quantity at "+ pickingQuantity);		
	}
	
	public void enterPrewrapLocationTextBox() {
		String preWrapLocation=element(preWrapLocationValue).getText();
		logger.info(preWrapLocation);
		element(preWrapLocationTextbox).clear();
		element(preWrapLocationTextbox).sendKeys(preWrapLocation);
		logger.info("WMT_BY_MOBILE : Entered preWrap Location at "+ preWrapLocation);		
	}
	public boolean isLocationTextBoxDisplayed() {
		 try
		    {
		        if(element(locationTextBox).isDisplayed()){
		        	logger.info("BY_MOBILE :locationTextBox is displayed ");
		            return true;
		        }else{
		        	logger.info("BY_MOBILE :locationTextBox is NOT displayed ");
		            return false;
		        }
		    }
		    catch (Exception e)
		    {
		    	logger.info("BY_MOBILE :locationTextBox is NOT displayed ");
		    	driver = getAndroidDriver();
		    	return false;
		    }
		
	}

	public void selectVehicleTypeValue(String workOperation) {
		switch(workOperation) {
		
		case("Haulput Perishable"):{
			enterVehicleTypeValue(environment.getProperty("perishableVehicleType"));
			break;
		}
		case("Haul Meat Produce"):{
			enterVehicleTypeValue(environment.getProperty("meatProduceVehicleType"));
			break;
		}
		default:
			enterVehicleTypeValue(environment.getProperty("vehicleType"));
		
		}
		
	}
	
	
	public boolean directedWorkOptionIsVisible() {
		return catalystUtil.isElementVisible(directedWorkOption);
		
		/*try {
			element(directedWorkOption).waitUntilVisible().withTimeoutOf(10, TimeUnit.SECONDS);
			return true;
//			return element(directedWorkOption).isDisplayed();
		} catch (Exception e) {
			logger.info("Directed work option is not displayed");
			return false;
		}*/
	}
	
	public String getPutawayDepositeLocation() {
		element(locationField).waitUntilVisible();
		String putawayDepositLocation = element(locationField).getText().trim();
		return putawayDepositLocation;
	}
	
}
