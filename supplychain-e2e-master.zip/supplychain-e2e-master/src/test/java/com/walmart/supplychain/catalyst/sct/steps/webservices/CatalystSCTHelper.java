package com.walmart.supplychain.catalyst.sct.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.parsing.TextParser;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystSCTHelper {

	//String TEST_FLOW_DATA = "testFlowData";


	@Autowired
	TextParser textParser;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	JavaUtils javaUtils = new JavaUtils();

	Logger LOGGER = LogManager.getLogger(this.getClass());	

	private static final String DELIVERY_JSON_PATH = "$..deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber";
	private static final String TRANSPORTATION_LOAD_JSON_PATH = "$..outboundDetails..routes..transportationLoadId";
	private static final String ALLOCATION_ORDER_ID_JSON_PATH ="$..ordersDetails..allocationOrderId";
	private static final String SO_NUMBER_JSON_PATH ="$..ordersDetails..allocationOrderId";

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	Response response;

	String sctSearchBody="";

	public Headers getSCTHeaders() {

		return getSCTHeaders(null); 

	}

	public Headers getSCTHeaders(String eventType) {

		Header appType = new Header("Content-Type", "application/json");
		Header sctClientKey=new Header("SCT_CLIENT_KEY", "SCT_CLIENT_KEY");

		List<Header> headerList = new ArrayList<>();
		headerList.add(appType);
		headerList.add(sctClientKey);

		return new Headers(headerList);
	}



	public String getSCTResponse(String eventType) throws URISyntaxException, IOException {

		String baseTemplateMssg;
		String testFlowData = threadLocal.get().get("testFlowData").toString();	
		baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_SCT_SEARCH_TEMPLATE_FILE);
		List<String> deliveryNumberList = JsonPath.read(testFlowData, DELIVERY_JSON_PATH);
		LOGGER.info("Delivery number " + deliveryNumberList.get(0));
		
		switch(eventType) {
		
			case "DELIVERY":
			case "DELIVERY_DOC_SUB_LINE_EXCEPTION":
			case "RECEIVING_ITEM" :
			case "RECEIVING_ITEM_EXCEPTION" :{
				sctSearchBody = javaUtils.format(baseTemplateMssg,eventType,"delivery_number", deliveryNumberList.get(0));
				break;
			}
			
			
			case "PICK":{
				List<String> transportationLoadList = JsonPath.read(testFlowData, TRANSPORTATION_LOAD_JSON_PATH);  
				LOGGER.info("Transportation Load number " + transportationLoadList.get(0));
				sctSearchBody = javaUtils.format(baseTemplateMssg,eventType, "assigned_load_id",transportationLoadList.get(0));	
				break;
			}

			case "AO_SO":{
				List<String> allocationOrderIdList = JsonPath.read(testFlowData, ALLOCATION_ORDER_ID_JSON_PATH);  
				LOGGER.info("Allocation Order Id " + allocationOrderIdList.get(0));
				sctSearchBody = javaUtils.format(baseTemplateMssg,eventType, "alloc_order_id",allocationOrderIdList.get(0));	
				break;
			}

			case "AO_LINE":{
				List<String> allocationOrderIdList = JsonPath.read(testFlowData, ALLOCATION_ORDER_ID_JSON_PATH);  
				LOGGER.info("Allocation Order Id " + allocationOrderIdList.get(0));
				sctSearchBody = javaUtils.format(baseTemplateMssg,eventType, "alloc_order_id",allocationOrderIdList.get(0));	
				break;
			}

			case "SO_LINE":{
				List<String> storeOrderNumberList = JsonPath.read(testFlowData, SO_NUMBER_JSON_PATH);  
				LOGGER.info("Allocation Order Id " + storeOrderNumberList.get(0));
				sctSearchBody = javaUtils.format(baseTemplateMssg,eventType, "so_number",storeOrderNumberList.get(0));	
				break;
			}

		}
		
		LOGGER.info(sctSearchBody);
		if (Config.DC == DC_TYPE.CATALYST) {
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getSCTHeaders()).body(sctSearchBody).when().post(                
					environment.getProperty("sct_validation_api_url"));
			
			LOGGER.info(response.getBody().asString());	
			LOGGER.info(response.getStatusCode());	
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_UNLOAD_USERID_MISMATCH, Constants.SUCESS_STATUS_CODE,response.getStatusCode());
		}
		return response.getBody().asString();
	}



}
