package com.walmart.supplychain.nextgen.oms.gluecode.webservices;

public enum ORDER_TYPES {

    PBYL("PBYL"),GTL("GTL");

    private String orderType;

    ORDER_TYPES(String orderTypes){
        this.orderType = orderTypes;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
}
