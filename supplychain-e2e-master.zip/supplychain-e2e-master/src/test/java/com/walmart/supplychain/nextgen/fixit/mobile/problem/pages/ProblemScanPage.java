package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableMap;
import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.annotations.findby.By;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

public class ProblemScanPage extends MobilePageObject{
	Logger logger = LogManager.getLogger(this.getClass());
	
	public ProblemScanPage(WebDriver driver){
        super(driver);
    }

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='UPC Number']")
	public WebElement upcScan_Textbox;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	public WebElement next_Button;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_upcNumber']")
	public WebElement scan_Textbox;
	
	//gdc change
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CONTINUE']")
	private WebElement continue_Button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_upcNumber']")
	private WebElement upc_Textbox;
	
	@AndroidFindBy(xpath = "//*[@text='PLU']")
	private WebElement plu_Button;

	@AndroidFindBy(xpath = "//*[@text='ASN']")
	private WebElement asn_Button;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/btn_add']")
	private WebElement add_Button;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_label']")
	public WebElement addSSCC_Textbox;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_poList']")
	private WebElement poListing_Button;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/textinput_placeholder']")
	private WebElement upc_asn_TextBox;

	//Reprint Label
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_search']")
	private WebElement ticket_searchBox;

	@AndroidFindBy(xpath = "//androidx.cardview.widget.CardView[@index='0']")
	private WebElement firstTicket;


	public void scanUPC(String upcNumber) {
		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
				"com.walmart.move.nim.fixit.mobile", "-e",
				"com.motorolasolutions.emdk.datawedge.data_string " + upcNumber, "-e",
				"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN13");
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
		try {
			Thread.sleep(3000);
			getAndroidDriver().executeScript("mobile: shell", scanEvent);
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void scanUPCForNotWalmartFreight(String upcNumber) {
		
		element(upc_Textbox).waitUntilEnabled();
		element(upc_Textbox).type(upcNumber);

		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
		
//		try {
//			Thread.sleep(4000);
//		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
//				"com.walmart.move.nim.fixit.mobile", "-e",
//				"com.motorolasolutions.emdk.datawedge.data_string " + upcNumber, "-e",
//				"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN13");
//		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
//			Thread.sleep(3000);
//			getAndroidDriver().executeScript("mobile: shell", scanEvent);
//			Thread.sleep(4000);
//			getAndroidDriver().hideKeyboard();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}

	public void scanSSCC(String upcNumber) {

		element(upc_Textbox).waitUntilEnabled();
		element(upc_Textbox).type(upcNumber);

		element(next_Button).waitUntilEnabled();
		element(next_Button).click();

//		try {
//			Thread.sleep(4000);
//		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
//				"com.walmart.move.nim.fixit.mobile", "-e",
//				"com.motorolasolutions.emdk.datawedge.data_string " + upcNumber, "-e",
//				"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN13");
//		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
//			Thread.sleep(3000);
//			getAndroidDriver().executeScript("mobile: shell", scanEvent);
//			Thread.sleep(4000);
//			getAndroidDriver().hideKeyboard();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}

	public void addSSCC() {

		Random rand = new Random();
		String upcNumber = Integer.toString(rand.nextInt(999999999));
		element(addSSCC_Textbox).waitUntilEnabled();
		element(addSSCC_Textbox).type(upcNumber);

		element(add_Button).waitUntilEnabled();
		element(add_Button).click();

		element(next_Button).waitUntilEnabled();
		element(next_Button).click();

//		try {
//			Thread.sleep(4000);
//		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
//				"com.walmart.move.nim.fixit.mobile", "-e",
//				"com.motorolasolutions.emdk.datawedge.data_string " + upcNumber, "-e",
//				"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN13");
//		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
//			Thread.sleep(3000);
//			getAndroidDriver().executeScript("mobile: shell", scanEvent);
//			Thread.sleep(4000);
//			getAndroidDriver().hideKeyboard();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
	    return (AndroidDriver<AndroidElement>)
	            ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
	
	public void enterUPCorPLU(String scanUPCorPLU) {
		element(scan_Textbox).waitUntilEnabled();
		element(scan_Textbox).type(scanUPCorPLU);
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
		
	}

	public void scanUPCForReprint(String upcNumber) {
		element(upc_asn_TextBox).waitUntilVisible();
		element(upc_asn_TextBox).type(upcNumber);
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void scanTicketForReprint(String ticketID) {
		element(ticket_searchBox).waitUntilVisible();
		element(ticket_searchBox).type(ticketID);
		element(firstTicket).waitUntilEnabled();
		element(firstTicket).click();
	}
	
	public void clickContinue() {
		element(continue_Button).waitUntilClickable();
		element(continue_Button).click();
	}

	public void clickNext() {
		element(next_Button).waitUntilEnabled();
		element(next_Button).click();
	}

	public void clickPLU() {
		element(plu_Button).waitUntilVisible();
		element(plu_Button).waitUntilClickable();
		element(plu_Button).click();
	}

	public void clickASN(){
		element(asn_Button).waitUntilVisible();
		element(asn_Button).waitUntilClickable();
		element(asn_Button).click();
	}

	public void selectPOListing() {
		element(poListing_Button).waitUntilVisible();
		element(poListing_Button).click();
	}

}
