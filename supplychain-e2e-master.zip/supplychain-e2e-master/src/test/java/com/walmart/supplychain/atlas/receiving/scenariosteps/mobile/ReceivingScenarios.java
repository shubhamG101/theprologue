package com.walmart.supplychain.atlas.receiving.scenariosteps.mobile;

import org.json.JSONException;

import com.walmart.supplychain.atlas.receiving.steps.mobile.ReceivingSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ReceivingScenarios {

	@Steps
	ReceivingSteps receivingSteps;


	@Given("^user scans door$")
	public void scanDoor() throws JSONException {

		receivingSteps.publishMessageToIDM();
		
	}

	@When("^user scans item upc$")
	public void userScansItemUPC() {
		receivingSteps.postInstructionRequest();
	}
	
	@Then("^user receives qty and complete the pallet$")
	public void userReceivesQtyAndCompletesPallet() {
		receivingSteps.userReceiveQtyAndCompletePallet();
	}

	@When("^user complete the delivery from receiving$")
	public void completesDeliveryFromReceiving() {
		receivingSteps.completeDelivery();
	}
}
