package com.walmart.supplychain.nextgen.printing.steps.webservices;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class PrintingSteps extends ScenarioSteps {
	@Autowired
	Environment environment;
	@Autowired
	PrintingHelper printingHelper;
	private static final int SUCCESS_CODE=201;

	Logger logger = LogManager.getLogger(this.getClass());
	@Step
	public void bringPrinterUp() {
		String printerName = environment.getProperty("printer_name");
		logger.info("Printer Name {}",printerName);
		int printerId=printingHelper.getPrinterId(printerName);
		logger.info("Printer Id:{}",printerId);
		if(printerId==-1) {
		logger.error("Something went wrong while getting printer Id..Looks like printing service is down");
			return;
		}
		boolean isPrinterOnline=false;
		if(printerId!=0)
			isPrinterOnline=printingHelper.isPrinterOnline(printerId);
		logger.info("Is Printer {} Online?:{}",printerName,isPrinterOnline);
		if(isPrinterOnline) {
			logger.info("Printer {} is already online",printerName);
		}else {
			String newConnectionString=printingHelper.getNewEmulatorConnectionString();
			logger.info("New Connection String {}",newConnectionString);
			if(newConnectionString==null)return;
			int status=-1;
			if(printerId==0) {
				status=printingHelper.createPrinterWithNewConnection(printerId, printerName, newConnectionString);
				if(status==SUCCESS_CODE) {
					logger.info("Created new printer '{}' successfully",printerName);
					logger.info("Waiting for 8s for the new printer to come online");
					try {
						Thread.sleep(8000);
					} catch (InterruptedException e) {
						logger.error(e);
					}
					logger.info("Is Printer {} Online?:{}",printerName,printingHelper.isPrinterOnline(printerId));
				}
				else {
					logger.error("Printer Creation is failed");
				}
			}else {
			status=printingHelper.updatePrinterWithNewConnection(printerId, printerName, newConnectionString);
			if(status==SUCCESS_CODE) {
				logger.info("Updation is successful");
				logger.info("Is Printer {} Online?:{}",printerName,printingHelper.isPrinterOnline(printerId));
			}
			else {
				logger.error("Printer Updation is failed");
			}
			}
		}

	}
	public static void main(String arg[]) {
		new PrintingSteps().bringPrinterUp();
	}
}
