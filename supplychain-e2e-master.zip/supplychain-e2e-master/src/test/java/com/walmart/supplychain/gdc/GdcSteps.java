package com.walmart.supplychain.gdc;

import net.thucydides.core.annotations.Step;

public class GdcSteps {
	
	@Step
	public void step1(String problem) {
		
	}

}
