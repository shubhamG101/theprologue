package com.walmart.supplychain.catalyst.by.ui.scenarioSteps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.jcraft.jsch.Logger;
import com.walmart.supplychain.catalyst.by.ui.steps.BYInventorySteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYOutboundSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYReceivingSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class BYInventoryScenarios {

	@Steps
	BYOutboundSteps byOutboundSteps;

	@Steps
	BYInventorySteps byInboundSteps;

	@Steps
	BYReceivingSteps byReceivingSteps;

	@Autowired
	BYUiHelper byUiHelper;

	@Then("^user generates replenishment task for an Item in BY Web UI$")
	public void user_generates_replenishment_task_for_an_item_in_by_web_ui() throws Throwable {

		byInboundSteps.performReplenishmentForAnItem();
	}

	@Given("^user get the empty prime location starting from \"([^\"]*)\"$")
	public void user_search_for_empty_prime_location(String locFirstThreeChar) throws Throwable {

		byReceivingSteps.loginToBY();
		byInboundSteps.getEmptyPrimeLocation(locFirstThreeChar);

	}
	
	@Then("^user create a Future Hold in BY Web UI$")
	public void userCreatesFutureHold() throws Throwable {
		
		//Future Hold Pre CleanUp
		byInboundSteps.preCleanUpFutureHold();
		byUiHelper.navigateToMentionedMenu("WALMART - INVENTORY");
		byUiHelper.navigateToMentionedTab("Holds");
		
		byInboundSteps.applyFutureHold();
		
	}
	
	@Then("^user navigates to Problems Tab in Inventory Menu in BY UI$")
	public void userNavigatesToProblemsTabInInventory() throws Throwable {

		byInboundSteps.navigateToProblemsTab();

	}

}
