package com.walmart.supplychain.nextgen.yms.pages.ui;

import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

public class YMSDriverPage extends PageObject {
	YardManagementMoveQueuePage yardManagementMoveQueuePage;
	YMSHelper ymsHelper= new YMSHelper();
	Logger logger = LogManager.getLogger(this.getClass());
	
	@FindBy(id = "avaInd")
	private WebElement availButton;

	@FindBy(id = "yardDriverAccept")
	private WebElement acceptButton;

	@FindBy(xpath = "//input[@id='yardDriverComplete']")
	private WebElement completeButton;

	@FindBy(id = "yardDriverForm_trailerMoveVO_trailerId")
	private WebElement trailerId;
	
	@FindBy(xpath = "//input[@name='logout']")
	private WebElement logoutButton;

	public void clickOnAvailButton() {
		element(availButton).waitUntilClickable();
		availButton.click();
	}

	public boolean acceptTrailer(String trailer,int moveCount) {
		boolean status=false;
		for (int i = 0; i <= moveCount+10; i++) {
			if (ymsHelper
					.isElementVisible("//label[@id='yardDriverForm_trailerMoveVO_trailerId']")){
				if (trailerId.getText().equalsIgnoreCase(trailer)) {
					logger.info("Clicking on Accept Button for the Trailer " + trailerId.getText());
					element(acceptButton).click();
					element(completeButton).waitUntilClickable();
					logger.info("Clicking on Complete Button for the Trailer "+trailerId.getText());
					element(completeButton).click();
					status=true;
					break;
				} else {
					logger.info("Clicking on Accept Button for the Trailer " + trailerId.getText());
					element(acceptButton).click();
					element(completeButton).waitUntilClickable();
					logger.info("Clicking on Complete Button for the Trailer " + trailerId.getText());
					element(completeButton).click();
					status=false;
				}
			} else {
				clickOnAvailButton();
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				status=false;
			}
		}
		return status;
	}

	public void clickAcceptButton() {
		if (ymsHelper.isElementDisplayed(acceptButton))
			element(acceptButton).click();
	}

	public void clickCompleteButton() {
		if (ymsHelper.isElementDisplayed(completeButton))
			element(completeButton).click();
	}
	
	public void clickLogoutButton() {
		element(logoutButton).waitUntilClickable();
		element(logoutButton).click();
	}

}