package com.walmart.supplychain.catalyst.receiving.scenariosteps.mobile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingHelper;
import com.walmart.supplychain.catalyst.receiving.steps.mobile.CatalystReceivingSteps;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.strati.libs.commons.configuration.ConfigurationException;
import net.thucydides.core.annotations.Steps;

public class CatalystReceivingcenarios {

	@Steps
	CatalystReceivingSteps catalystReceivingSteps;
	
	@Steps
	CatalystReceivingHelper catalystReceivingHelper;

	
	@Given("^user opens \"([^\"]*)\" app from Launcher$")
	public void userOpensAppFromLauncher(String appName) throws JsonProcessingException {
		catalystReceivingSteps.openAppFromLauncher(appName);
	}

	@Given("^user logins to the \"([^\"]*)\" app and enters \"([^\"]*)\" environment details$")
	public void userLoginsAndEnterEnvDetails(String appName, String taskName) throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.userLoginsAndEnterEnvDetails(appName, taskName);
	}
	
	@Given("^user logins to the BY app and enters environment details based on \"([^\"]*)\" work operation type$")
	public void userenterByLoginAndEnvDetailsBasedOnWorkOperation( String workOperation) throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.enterByLoginAndEnvDetailsBasedOnWorkOperation(workOperation);
	}
	
	
	@Given("^user performs unloading task$")
	public void userPerformsUnloading() throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.performUnloading();
	}
	
	@Given("^user scans the current location and dock door for receiving$")
	public void userScansLocationAndDockDoor() throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.scanLocationAndDockDoor();
	}
	
	@Given("^user scans LPN and Item upc and start receiving with \"([^\"]*)\" status$")
	public void userScansLpnAndUpcAndStartReceiving(String receivedStatus) throws JsonProcessingException, InterruptedException, ConfigurationException {
		catalystReceivingSteps.scanLpnAndUpcAndStartReceiving(receivedStatus);
	}
	
	@Given("^user performs putaway task$")
	public void userPerformsPutaway() throws JsonProcessingException, InterruptedException, ConfigurationException {
		catalystReceivingSteps.performPutaway();
	}
	
	
	@Given("^user performs Complete Shipment after receiving$")
	public void userPerformsCompleteShipment() throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.completeShipment();
	}
	
	
	@Given("^user scans LPN and Item upc and start Full receiving with \"([^\"]*)\" status$")
    public void userScansLpnAndItemUpcAndStartFullReceiving(String receivedStatus) throws Throwable {
		catalystReceivingSteps.performFullReceive(receivedStatus);
		catalystReceivingSteps.validateTotalCasesAndHandleMoreFreightPopupForOverages();
    }

	@Then("^user scans LPN and Item UPC to performs Overages$")
    public void userScansLpnAndItemUpcToPerformsOverages() throws Throwable {
		catalystReceivingSteps.performOverages();
    }
	
	
	@Given("^user scans LPN and UPC and start receiving HACCP items with \"([^\"]*)\" status$")
    public void userScansLpnAndUpcAndStartReceivingHaccpItems(String receivedStatus) throws Throwable {
		catalystReceivingSteps.performFullReceive(receivedStatus);
		catalystReceivingSteps.handleHACCPComponents();
    }

	@Then("^user scan LPN item UPC and perform receiving as per below data$")
	public void userScanLpnUpcAndPerformReceiving(DataTable table ) throws InterruptedException {
		catalystReceivingSteps.performReceiving(table);
	}

	@Then ("^User modifies the config to \"([^\"]*)\"$") 
	public void usermodifiesCofig(String configValueCheck) throws ConfigurationException, InterruptedException {
		catalystReceivingSteps.updateConfig(configValueCheck);
	}

	@Given("^user performs Complete Shipment for Overages$")
    public void userperformsCompleteShipmentOverage() throws Throwable {
		catalystReceivingSteps.completeShipmentForOverage();
	}
	
	
	@Then("^user performs complete shipment for \"([^\"]*)\" status after receiving$")
	public void userPerformsCompleteShipmentBasedOnStatus(String status) throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.performCompleteShipmentBasedOnStatus(status);
	}

	@Given("^user performs BY logout$")
	public void userPerformsByLogout() throws JsonProcessingException, InterruptedException {
		catalystReceivingSteps.performByLogout();
	}
	
	@Given("^user performs Receiving App logout$")
	public void userPerformsReceivingAppLogout() throws JsonProcessingException, InterruptedException, ConfigurationException {
		catalystReceivingSteps.performReceivingAppLogout();
	}
	
	@Given("^user scans LPN and UPC and start receiving as Overage$")
    public void userScansLpnAndUpcAndStartReceivingAsOverage() throws Throwable {
		catalystReceivingSteps.completeShipmentForOverage();
    }
	
	@Given("^user scans LPN and Item upc for TiHi validation with \"([^\"]*)\" status$")
    public void userScansLpnAndItemUpcForTiHiValidation(String receivedStatus) throws Throwable {
		catalystReceivingSteps.handleTiHiComponents(receivedStatus);
    }

	@Then("^user reverses LPN recevied in \"([^\"]*)\" status$")
    public void userReversesLpnReceived(String receivedStatus) throws Throwable {
		catalystReceivingSteps.reverseLPN(receivedStatus);
    }

	@Given("^user performs unloading with \"([^\"]*)\" Result of Safety Questions$")
	public void userPerformsUnloading(String parameter) throws JsonProcessingException, InterruptedException  {
		catalystReceivingSteps.performUnloadingBasedOnParams(parameter);
	}
	
	@Then("^user performs Bump Request with Infestation as Reason$")
	public void userPerformsBumpWithInfastation() throws JsonProcessingException, InterruptedException  {
		catalystReceivingSteps.performBumpRequestWithInfestationReason();
	}

}
