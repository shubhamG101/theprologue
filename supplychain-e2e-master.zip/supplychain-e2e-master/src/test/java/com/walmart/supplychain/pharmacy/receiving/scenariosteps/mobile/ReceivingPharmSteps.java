package com.walmart.supplychain.pharmacy.receiving.scenariosteps.mobile;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableMap;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmSteps;
import com.walmart.supplychain.pharmacy.receiving.pages.mobile.ReceivingPharmPage;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.strati.libs.commons.configuration.ConfigurationException;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingPharmSteps extends ScenarioSteps {

	@Autowired
	ReceivingPharmPage receivingPharmPage;

	@Autowired
	ReceivingPharmHelper receivingPharmHelper;

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	GDMPharmSteps gdmPharmSteps;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	IDMSteps idmSteps;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	GDMPharmHelper gdmPharmHelper;

	private List<String> poNumberList;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String SHIPMENT_JSON_PATH = "$.testFlowData.deliveryDetails[*].shipments";
	private static final String PO_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..poNumbers[*]";
	private static final String DELIVERY_JSON_PATH = "$..deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber";
	private static final String SELECT_QUERY_TO_GET_OSDR_DETAILS_RDS = "select_queury_to_get_osdr_details_RDS";
	private static final String SELECT_QUERY_TO_GET_PTAG_DETAILS_RDS = "select_queury_to_get_ptag_details_RDS";
	private static final String SELECT_QUERY_TO_GET_CANCELLED_PTAG_DETAILS_RDS = "select_queury_to_get_cancelled_ptag_details_RDS";
	private static final String SELECT_QUERY_POLINE_PEDIGREE_RCV_UNIT_DETAILS_RDS = "select_queury_poline_pedigree_rcv_unit_details_RDS";
	private static final String SELECT_QUERY_TO_GET_SLOT_ID_RDS="select_queury_to_get_slot_id_RDS";
	private static final String SELECT_QUERY_TO_GET_RCVR_FINAL_TS_AFTER_REOPEN_DELIVERY_RDS="select_queury_to_get_rcvr_final_ts_reopen_delivery";
	private static final String SELECT_QUERY_TO_GET_PRIME_SLOT_ID_RDS = "select_query_to_get_prime_slot_id_RDS";
	private static final String SELECT_QUERY_TO_GET_PALLET_STATUS_CODE_RDS = "select_query_to_get_pallet_status_code_RDS";


	private List<Map<String, Object>> ptagDetailsMap;
	private int totalReceivedQtyForPO;
	private int totalOverageQtyForPO;
	private int totalShortageQtyForPO;

	@Step
	public void loginToMyApps() {
		try {
			killApp();
			boolean isReceivingAlreadyOpened = receivingPharmPage.loginToMyapps(environment.getProperty("nextGenUserName"),
					environment.getProperty("nextGen"), environment.getProperty("source_number"));
			if(!isReceivingAlreadyOpened) {
			receivingPharmPage.clickOnReceivingApp();
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Login to My apps", e);
		}
	}


	@Step
	public void signoutThenloginToMyAppsForTransferPallet() {
		try {
			killApp();
			receivingPharmPage.logoutAndThenLoginToMyApps(environment.getProperty("nextGenUserName"),environment.getProperty("pharmacy_user_2"),
					environment.getProperty("nextGen"),environment.getProperty("pharmacy_password_2"), environment.getProperty("source_number"),true);
			receivingPharmPage.clickOnReceivingApp();
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Login to My apps", e);
		}
	}

	@Step
	public void performDoorScan() {
		try {
			// Door Scan
			Thread.sleep(6000);
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> doorNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			String door = doorNumber.get(0);
			receivingPharmPage.waitForDoorOrDeliveryScanScreenToAppear();
			logger.info("Scanning door:" + door);
			performScan(door);
			logger.info("Scanned door:" + door);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning", e);
		}
	}
	
	@Step
	public void validateConfirmTrailerScreen() {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> expectedQtyList = JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
			int totalExpectedQty = 0;
			for(String expectedPoPolineQty : expectedQtyList) {
				logger.info("expectedPoPolineQty=" + expectedPoPolineQty);
				totalExpectedQty += Integer.parseInt(expectedPoPolineQty);
			}
			List<String> trailerNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundTrailerNumber");
			String trailer = trailerNumber.get(0);
			Thread.sleep(6000);
			Assert.assertEquals(ErrorCodes.PHARMACY_TOTAL_CASES_VALIDATION_FAILED, totalExpectedQty, receivingPharmPage.getTotalCasesConfirmTrailerScreen());
			Assert.assertEquals(ErrorCodes.PHARMACY_RECEIVED_CASES_VALIDATION_FAILED, 0, receivingPharmPage.getTotalReceivedCasesConfirmTrailerScreen());
			Assert.assertEquals(ErrorCodes.PHARMACY_TRAILER_VALIDATION_FAILED, trailer, receivingPharmPage.getTrailerNumberText());
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Validating ConfirmTrailer Screen", e);
		}
	}
	
	@Step
	public void performDeliveryScan() {
		try {
			// Delivery Scan
			Thread.sleep(6000);
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> deliveryNumList = JsonPath.parse(testFlowData).read(DELIVERY_JSON_PATH);
			String deliveryNum = deliveryNumList.get(0);
			logger.info("Scanning Delivery:" + deliveryNum);
			performScan(deliveryNum);
			logger.info("Scanned Delivery:" + deliveryNum);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning Delivery", e);
		}
	}

	@Step
	public void clickConfirmTrailer() {
		try {
			receivingPharmPage.clickOnAgreeTrailerAgreement();
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Confirming trailer", e);
		}
	}

	@Step
	public void scanSSCCAnd2DBarcodes(String receivingType, String partialOrFull, boolean cancelPallet) {
		try {
			logger.info("Receiving Type=" + receivingType);
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> listofShipments = getListOfShipments(testFlowData);
			int shipmentSequence = -1;
			for (String shipmentNumber : listofShipments) {
				shipmentSequence++;
				logger.info("Shipment Sequence=" + shipmentSequence);
				String shipmentDetailsInJSON = getShipmentDetailsInJSON(shipmentNumber);

				ArrayList<String> listOfPacks = getListOfPacks(shipmentDetailsInJSON);

				for (String packNum : listOfPacks) {
					logger.info("Pack Number=" + packNum);
					ArrayList<Integer> listOfItems = getListOfItems(shipmentDetailsInJSON, packNum);

					// For Multi-SKU, SSCC will be scanned only once per Pack
					boolean isMultiSKU = receivingType.equalsIgnoreCase("MultiSKU");
					if(isMultiSKU){
						performSSCCScan(packNum);
					}
					for (int itemIndex=0;itemIndex<listOfItems.size();itemIndex++) {
						Integer itemNumber = listOfItems.get(itemIndex);
						boolean isCompleteReceiving = partialOrFull.equalsIgnoreCase("Complete");
						int noOfShipments = listofShipments.size();
						switch (receivingType.toUpperCase()) {
						case "CASE":
							int povnpkCaseReceiving = getPOExpectedQty(testFlowData, itemNumber);
							int aggregatedQtyCaseReceiving = getAggregatedQty(shipmentDetailsInJSON, packNum);

							int noOfSSCCScans = 1;
							int noOfTotalCasesCaseReceiving = getFinalTotalCaseCount(povnpkCaseReceiving,
									aggregatedQtyCaseReceiving);
							if (isCompleteReceiving) {
								noOfSSCCScans = noOfTotalCasesCaseReceiving;
							}
							logger.info(noOfSSCCScans + " is noOfTotalCasesCaseReceiving");

							for (int i = 0; i < noOfSSCCScans; i++) {
								performSSCCScan(packNum);
								if (i == 0) {
									validateUnitsPerCaseQty(itemNumber);
									validateTotalCaseCount(noOfTotalCasesCaseReceiving - shipmentSequence);
									perform2DBarcodeScan(
											prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber), "CA");
									logger.info("Scanning CA GIN");
								} else {
									logger.info("Scanning EA GIN");
									perform2DBarcodeScan(
											prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber), "EA");
								}
								if (cancelPallet) {
									cancelPallet();
									cancelPallet = false;
									i = -1;
									logger.info("SSCC Scan Sequence:" + i);
									validateCancelPallet();
								}
							}
							receivePallet();
							break;

						case "PALLET":
							int noOfSSCCScansPalletReceiving = 1;
							int povnpkPalletReceiving = getPOExpectedQty(testFlowData, itemNumber);
							int aggregatedQtyPalletReceiving = getAggregatedQty(shipmentDetailsInJSON, packNum);

							int noOf2DBarcodeScansPalletReceiving = 1;
							int noOfTotalCasesPalletReceiving = getFinalTotalCaseCount(povnpkPalletReceiving,
									aggregatedQtyPalletReceiving);
							noOf2DBarcodeScansPalletReceiving = noOfTotalCasesPalletReceiving;
							if(!isCompleteReceiving) {
								if(noOfShipments > 1 && shipmentSequence == 0) {
								noOf2DBarcodeScansPalletReceiving = noOf2DBarcodeScansPalletReceiving/noOfShipments;
								}else if(noOfShipments > 1 && shipmentSequence > 0){
								noOf2DBarcodeScansPalletReceiving = noOf2DBarcodeScansPalletReceiving - (noOf2DBarcodeScansPalletReceiving/noOfShipments);	
								}else {
								noOf2DBarcodeScansPalletReceiving -= 1;
								}
							}
							performSSCCScan(packNum);
							validateUnitsPerCaseQty(itemNumber);
							if(shipmentSequence == 0) {
							validateTotalCaseCount(noOfTotalCasesPalletReceiving-shipmentSequence);
							}
							boolean overageApplicable = (shipmentSequence == noOfShipments - 1);
							if(overageApplicable) {
								noOf2DBarcodeScansPalletReceiving += 1;
							}
							for (int i = 0; i < noOf2DBarcodeScansPalletReceiving; i++) {
								if (i == 0) {
									logger.info("Proceed with EA GTIN");
									perform2DBarcodeScan(
											prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber), "EA");
								} else {
									logger.info("Proceed with CA GTIN");
									perform2DBarcodeScan(
											prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber), "CA");
									if (overageApplicable && (i == (noOf2DBarcodeScansPalletReceiving - 1))) {
										validateCaseOverage();
									}
								}
							}
							receivePallet();
							break;

						case "UNIT":
							int povnpkUnitReceiving = getPOExpectedQty(testFlowData, itemNumber);
							int aggregatedQtyUnitReceiving = getAggregatedQty(shipmentDetailsInJSON, packNum);

							logger.info("aggregatedQtyPalletReceiving=" + aggregatedQtyUnitReceiving);
							int noOfSSCCScansUnitReceiving = 1;
							int noOfTotalCasesUnitReceiving = getFinalTotalCaseCount(povnpkUnitReceiving,
									aggregatedQtyUnitReceiving);
							if (isCompleteReceiving) {
								noOfSSCCScansUnitReceiving = (int) Math.round((double)noOfTotalCasesUnitReceiving/noOfTotalCasesUnitReceiving);
							}

							for (int i = 0; i < noOfSSCCScansUnitReceiving; i++) {
								performSSCCScan(packNum);
								int noOf2DBarcodesScansUnitReceiving = 1;
								if (i == 0) {
									validateUnitsPerCaseQty(itemNumber);
									if (isCompleteReceiving) {
										validateTotalCaseCount(noOfTotalCasesUnitReceiving-i);
									}
								}
								if (isCompleteReceiving) {
									noOf2DBarcodesScansUnitReceiving = getUnitsPerCaseQty(itemNumber);
									navigateToUnitReceivingFlow();
								}

								Map<String, String> itemMap = prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum,
										itemNumber);
								for (int j = 0; j < noOf2DBarcodesScansUnitReceiving; j++) {
									if (j == 0) {
										logger.info("Proceed with CA GTIN");
										perform2DBarcodeScan(itemMap, "CA");
									} else {
										logger.info("Proceed with CA GTIN");
										perform2DBarcodeScan(itemMap, "EA");
									}
								}
							}
								receivingPharmPage.clickOnDoneButton();
								if (!isCompleteReceiving) {
									receivingPharmPage.clickOnYesPartialCaseButton();
								}
								receivePallet();
								break;
							case "MULTISKU":
								int povnpk = getPOExpectedQty(testFlowData, itemNumber);
								int aggregatedQty = getAggregatedQty(shipmentDetailsInJSON, packNum);
								int noOfTotalCases = getFinalTotalCaseCount(povnpk,
										aggregatedQty);

								for (int i = 0; i < noOfTotalCases; i++) {
									if (i == 0) {
//										validateUnitsPerCaseQty(itemNumber);
//										validateTotalCaseCount(noOfTotalCases - shipmentSequence);
										perform2DBarcodeScan(
												prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber), "CA");
										logger.info("Scanning CA GIN");
									} else {
										logger.info("Scanning EA GIN");
										perform2DBarcodeScan(
												prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber), "EA");
									}
								}
								receivePallet();
								if(itemIndex==listOfItems.size()-1 && isMultiSKU) {
									receivingPharmPage.clickDoneButtonMultiSKU();
									break;
								}
							}
							if(!isMultiSKU) {
								break;
							}
						}
					}
				}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Scanning and Receiving", e);
		}

	}
	
	@Step
	public void scan2DBarcodes(String receivingType, String partialOrFull) {
		try {
			logger.info("Receiving Type=" + receivingType);
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> listofShipments = getListOfShipments(testFlowData);
			for (String shipmentNumber : listofShipments) {
				String shipmentDetailsInJSON = getShipmentDetailsInJSON(shipmentNumber);

				ArrayList<String> listOfPacks = getListOfPacks(shipmentDetailsInJSON);

				for (String packNum : listOfPacks) {
					logger.info("Pack Number=" + packNum);
					ArrayList<Integer> listOfItems = getListOfItems(shipmentDetailsInJSON, packNum);

					for (Integer itemNumber : listOfItems) {
						boolean isCompleteReceiving = partialOrFull.equalsIgnoreCase("Complete");
						boolean clickReceivePartialLink = false;
						switch (receivingType.toUpperCase()) {
						case "CASE":
							int povnpkCaseReceiving = getPOExpectedQty(testFlowData, itemNumber);
							int aggregatedQtyCaseReceiving = getAggregatedQty(shipmentDetailsInJSON, packNum);

							int noOfScans = 1;
							int noOfTotalCasesCaseReceiving = getFinalTotalCaseCount(povnpkCaseReceiving,
									aggregatedQtyCaseReceiving);
							if (isCompleteReceiving) {
								noOfScans = noOfTotalCasesCaseReceiving;
							}
							Map<String, String> barcodeMap = prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum, itemNumber);
							for (int i = 0; i < noOfScans; i++) {
								if (i == 0) {
									logger.info("proceed with CA GTIN");
									perform2DBarcodeScan(barcodeMap, "CA");
									validateUnitsPerCaseQty(itemNumber);
									validateTotalCaseCount(noOfTotalCasesCaseReceiving);
								} else if (noOfScans > 1 && i == 1  ) {
									logger.info("proceed with PK GTIN");
									perform2DBarcodeScan(barcodeMap, "PK");
								} else if (noOfScans > 2 && i == 2  ) {
									logger.info("proceed with EA GTIN");
									perform2DBarcodeScan(barcodeMap, "EA");
								}
							}
							receivePallet();
							break;

						case "UNIT":
							int povnpkUnitReceiving = getPOExpectedQty(testFlowData, itemNumber);
							int aggregatedQtyUnitReceiving = getAggregatedQty(shipmentDetailsInJSON, packNum);

							int noOfSSCCScansUnitReceiving = 1;
							int noOfTotalCasesUnitReceiving = getFinalTotalCaseCount(povnpkUnitReceiving,
									aggregatedQtyUnitReceiving);
							if (isCompleteReceiving) {
								noOfSSCCScansUnitReceiving = noOfTotalCasesUnitReceiving;
							}

							for (int i = 0; i < noOfSSCCScansUnitReceiving; i++) {
								Map<String, String> itemMap = prepare2DBarcodeDetailsMap(shipmentDetailsInJSON, packNum,
										itemNumber);
								int noOf2DBarcodesScansUnitReceiving = getUnitsPerCaseQty(itemNumber);
								if (!isCompleteReceiving) {
									noOf2DBarcodesScansUnitReceiving = noOf2DBarcodesScansUnitReceiving - 1;
								}
								if (i == 0) {
									receivingPharmPage.clickReceivePartialCaseLink();
									clickReceivePartialLink = true;
								}
								for (int j = 0; j < noOf2DBarcodesScansUnitReceiving; j++) {
									if (j == 0) {
										logger.info("proceed with CA GTIN");
										perform2DBarcodeScan(itemMap, "CA");
										validateUnitsPerCaseQty(itemNumber);
										if (isCompleteReceiving) {
											validateTotalCaseCount(noOfTotalCasesUnitReceiving - i);
										}
									} else {
										logger.info("proceed with PK unit GTIN");
										perform2DBarcodeScan(itemMap, "PK");
									}
								}
								receivingPharmPage.clickOnDoneButton();
								if (!isCompleteReceiving) {
									receivingPharmPage.clickOnYesPartialCaseButton();
								}
								receivePallet();
							}
						}
						if(clickReceivePartialLink) {
						receivingPharmPage.navigateBack();
						}
						break;
					}
				}				
				receivingPharmPage.waitForScanSSCCor2DBarcodeScreenToAppear();
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Scanning and Receiving", e);
		}

	}

	public void navigateToUnitReceivingFlow() {
		receivingPharmPage.clickOnScanIndividualUnitsButton();
		receivingPharmPage.clickOnYesScanUnitsButton();
	}
	public Map<String, String> prepare2DBarcodeDetailsMap(String shipmentDetailsInJSON, String packNum, Integer itemNumber) {
		ArrayList<String> listOfGtins = gdmPharmHelper.getAllGtinsFromSCIS(itemNumber);
		Map<String, String> itemMap = new HashMap<String, String>();
		itemMap.put("orderablePackGtin", listOfGtins.get(0));
		itemMap.put("warehousePackGtin", listOfGtins.get(1));
		itemMap.put("consumableGtin", listOfGtins.get(2));
		itemMap.put("lotNumber", getItemLotNumber(shipmentDetailsInJSON, packNum, itemNumber));
		return itemMap;
	}

	public ArrayList<Integer> getListOfItems(String shipmentDetailsInJSON, String packNum) {
		return JsonPath.read(shipmentDetailsInJSON,
				"$.shipmentDetails.packs[?(@.packNumber == \"" + packNum + "\")].items[*].itemNumber");
	}

	public ArrayList<String> getListOfPacks(String shipmentDetailsInJSON) {
		return JsonPath.read(shipmentDetailsInJSON, "$.shipmentDetails.packs[*].packNumber");
	}

	public String getShipmentDetailsInJSON(String shipmentNumber) {
		String shipmentDetailsInJSON = "{\"shipmentDetails\":" + gdmPharmSteps.getShipmentDetails(shipmentNumber) + "}";
		logger.info("Shipment Number=" + shipmentNumber);
		logger.info("Shipment Details=" + shipmentDetailsInJSON);
		return shipmentDetailsInJSON;
	}

	public List<String> getListOfShipments(String testFlowData) {
		List<List<String>> listOfShipments = JsonPath.read(testFlowData, SHIPMENT_JSON_PATH);
		logger.info("List of List of Shipments=" + listOfShipments);

		List<String> strings = listOfShipments.stream().flatMap(List::stream).collect(Collectors.toList());
		logger.info("List of Shipments=" + strings);
		return strings;
	}

	public String getItemLotNumber(String shipmentDetails, String packNum, Integer itemNumber) {
		ArrayList<String> listOfLotNumbers = JsonPath.read(shipmentDetails,
				"$.shipmentDetails.packs[?(@.packNumber == \"" + packNum + "\")].items[?(@.itemNumber == \""
						+ itemNumber + "\")].manufactureDetails[0].lotNumber");
		String lotNumber = listOfLotNumbers.get(0);
		logger.info("Lot Number=" + lotNumber);
		return lotNumber;
	}

	public ArrayList<String> getItemGtin(String shipmentDetails, String packNum, Integer itemNumber) {
		ArrayList<String> gtin = JsonPath.read(shipmentDetails, "$.shipmentDetails.packs[?(@.packNumber == \""
				+ packNum + "\")].items[?(@.itemNumber == \"" + itemNumber + "\")].gtin");
		ArrayList<String> warehouseCaseGTIN = JsonPath.read(shipmentDetails, "$.shipmentDetails.packs[?(@.packNumber == \""
				+ packNum + "\")].items[?(@.itemNumber == \"" + itemNumber + "\")].warehouseCaseGtin");

		ArrayList<String> listOfGTINs = new ArrayList<String>();
		listOfGTINs.add(gtin.get(0));
		listOfGTINs.add(warehouseCaseGTIN.get(0));
		logger.info("GTIN list is =" + listOfGTINs);
		return listOfGTINs;
	}

	public int getAggregatedQty(String shipmentDetails, String packNum) {
		ArrayList<Integer> listOfAggregatedQtys = JsonPath.read(shipmentDetails,
				"$.shipmentDetails.packs[?(@.packNumber == \"" + packNum + "\")].items[0].aggregatedItemQty");
		int aggregatedQty = listOfAggregatedQtys.get(0);
		logger.info("aggregatedQty=" + aggregatedQty);
		return aggregatedQty;
	}

	public int getPOExpectedQty(String testFlowData, Integer itemNumber) {
		ArrayList<String> listOfExpectedQtys = JsonPath.read(testFlowData,
				"$.testFlowData.poDetails..poLineDetails[?(@.itemNumber==\"" + itemNumber + "\")].poVnpkQty");
		int expectedQty = Integer.parseInt(listOfExpectedQtys.get(0));
		logger.info("POExpectedQty=" + expectedQty);
		return expectedQty;
	}

	public String performSSCCScan(String sscc) {
		try {
			Thread.sleep(6000);
			logger.info("Scanning sscc:" + sscc);
			performScan(sscc);
			logger.info("Scanned sscc:" + sscc);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning", e);
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return sscc;

	}

	public void perform2DBarcodeScan(Map<String, String> itemMap, String gtinType) {
		String orderablePackGtin = itemMap.get("orderablePackGtin");
		String warehousePackGtin = itemMap.get("warehousePackGtin");
		String consumableGtin = itemMap.get("consumableGtin");
		String lotNumber = itemMap.get("lotNumber");
		int noOfScans = 1;
		int delay = 5000;
		int serialNum = (int) (Math.random() * (9999999 - 99999 + 1) + 99999);
		LocalDate now = LocalDate.now();
		String expirationDate = now.plusYears(1).toString().substring(2).replaceAll("-","");
		String qty = "0001";
		try {
			logger.info("noOfScans is in perform2DBarcodeScan " + noOfScans);
			for (int i = 1; i <= noOfScans; i++) {
				serialNum += 1;
				String valueToScan = null;
				if (gtinType.equalsIgnoreCase("CA")) {

					valueToScan = "01" + orderablePackGtin + "21" + serialNum + "\u001D17" + expirationDate + "10" + lotNumber
							+ "\u001D30" + qty;

					logger.info("Scanning 2D Barcode: GTIN=" + orderablePackGtin + ", serialNum=" + serialNum + " and lotNumber="
							+ lotNumber);
				} else if (gtinType.equalsIgnoreCase("EA")) {
					valueToScan = "01" + consumableGtin + "21" + serialNum + "\u001D17" + expirationDate + "10" + lotNumber
							+ "\u001D30" + qty;
					logger.info("Scanning 2D Barcode: GTIN=" + consumableGtin + ", serialNum=" + serialNum + " and lotNumber="
							+ lotNumber);
				} else if (gtinType.equalsIgnoreCase("PK")) {
					valueToScan = "01" + warehousePackGtin + "21" + serialNum + "\u001D17" + expirationDate + "10" + lotNumber
							+ "\u001D30" + qty;
					logger.info("Scanning 2D Barcode: GTIN=" + warehousePackGtin + ", serialNum=" + serialNum + " and lotNumber="
							+ lotNumber);
				}
				performScan(valueToScan);
				Thread.sleep(delay);
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning", e);
		}
	}

	public int getFinalTotalCaseCount(int povnpk, int aggregatedQty) {
		return aggregatedQty <= povnpk ? aggregatedQty : povnpk;
	}

	public void validateTotalCaseCount(int finalTotalCaseCount) {
		Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_TOTAL_CASES, finalTotalCaseCount,
				receivingPharmPage.getTotalCaseCount());
	}

	public void performScan(String valueToScan) {
		logger.info("valueToScan : {}", valueToScan);
		String labelType = "LABEL-TYPE-DATAMATRIX";
		if(valueToScan.length()<=20) {
			labelType = "LABEL-TYPE-EAN128";
		}
		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
				"com.walmart.move.nim.receiving.mobile", "-e",
				"com.motorolasolutions.emdk.datawedge.data_string " + valueToScan, "-e",
				"com.motorolasolutions.emdk.datawedge.label_type " + labelType);
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
		getAndroidDriver().executeScript("mobile: shell", scanEvent);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void cancelPallet() {
		receivingPharmPage.clickOnCancelPallet();
		receivingPharmPage.clickOnYesCancelPallet();
	}

	public void receivePallet() {
		receivingPharmPage.clickOnReceiveButton();
		receivingPharmPage.clickOnYesReceiveButton();
	}

	public int validateUnitsPerCaseQty(int itemNbr) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
		logger.info("getting vnpk and whpk qty below");

		int vnpkQty = getVnpkQty(itemNbr, testFlowData);

		logger.info("Expected vnpkQty ::" + vnpkQty);
		int whpkQty = getWhpkQty(itemNbr, testFlowData);

		logger.info("Expected whpkQty ::" + whpkQty);
		int unitspercase = vnpkQty / whpkQty;
		String totalUnitspercase = unitspercase + " units per case";
		logger.info("Expected  unitspercase::" + totalUnitspercase);
		logger.info("Actual unitsPerCase " + receivingPharmPage.getUnitsPerCaseQty());

		Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_UNITS_PER_CASE, totalUnitspercase,
				receivingPharmPage.getUnitsPerCaseQty());
		return unitspercase;
	}

	public int getUnitsPerCaseQty(int itemNbr) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
		logger.info("getting vnpk and whpk qty below");
		int vnpkQty = getVnpkQty(itemNbr, testFlowData);
		logger.info("Expected vnpkQty ::" + vnpkQty);
		int whpkQty = getWhpkQty(itemNbr, testFlowData);
		logger.info("Expected whpkQty ::" + whpkQty);
		return vnpkQty / whpkQty;
	}

	public int getWhpkQty(int itemNbr, String testFlowData) {
		ArrayList<String> listOfWhpkQtys = JsonPath.read(testFlowData,
				"$.testFlowData.poDetails..poLineDetails[?(@.itemNumber==\"" + itemNbr + "\")].whpk");

		int whpkQty = Integer.parseInt(listOfWhpkQtys.get(0));
		logger.info("whpkQty=" + whpkQty);
		return whpkQty;
	}

	public int getVnpkQty(int itemNbr, String testFlowData) {
		ArrayList<String> listOfVnpkQtys = JsonPath.read(testFlowData,
				"$.testFlowData.poDetails..poLineDetails[?(@.itemNumber==\"" + itemNbr + "\")].vnpk");

		int vnpkQty = Integer.parseInt(listOfVnpkQtys.get(0));
		logger.info("vnpkQty=" + vnpkQty);
		return vnpkQty;
	}

	@Step
	public void deliveryComplete() {
		try {
			receivingPharmPage.clickOnCompleteDeliveryButton();

			receivingPharmPage.isErrorMessageBoxDisplayed();
			receivingPharmPage.clickOnYesButtonForCompleteDelivery();
			String completeDelievrySucessMssg = receivingPharmPage.getDeliveryCompleteSuccessMssg();
			Assert.assertEquals(ErrorCodes.PHARMACY_RECEIVING_FINALIZE_DELIVERY_FAILED, "Delivery Completed",
					completeDelievrySucessMssg);
			logger.info("Receiving App :: Delivery completed successfully and totalcase received is "
					+ receivingPharmPage.receivedCaseCountInCompltDeliveryScreen());
			receivingPharmPage.clickOnCloseButton();

			Assert.assertEquals(ErrorCodes.PHARMACY_CLOSE_DELIVERY_FAILED, "Receiving",
					receivingPharmPage.receivngScreen.getText());

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Finalizing the delivery", e);
		}
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
	}

	@Step
	public void validatePtags() {
		try {
			receivingPharmHelper.storePtagInstructionsIntoTestflowData();
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);
			for (String poNumber : poNumberList) {
				List<String> poLineNumbers = JsonPath.parse(testFlowData).read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String lineNumber : poLineNumbers) {
					List<String> pTagList = JsonPath.parse(testFlowData).read("$..poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails[?(@.poLineNumber=='" + lineNumber + "')].receivingInstructions[?(@.isVTR!=true)].parentContainer");
					List<String> vnpkList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber == '" + lineNumber + "')].vnpk");
					List<String> whpkList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber == '" + lineNumber + "')].whpk");
					List<String> deptNumList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber == '" + lineNumber + "')].departmentNumber");
					List<String> itemList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber == '" + lineNumber + "')].itemNumber");

					for (String pTag : pTagList) {
						ptagDetailsMap = null;
						Failsafe.with(retryPolicy).run(() -> {
							List<String> receivedQtyVendorPack= JsonPath.read(testFlowData, "$..[?(@.parentContainer=='"+pTag+"')].receivedQuantity");
							logger.info("Excuting query to get ptag details for ptag: ["+pTag+"] with query : "+environment.getProperty(SELECT_QUERY_TO_GET_PTAG_DETAILS_RDS));
							ptagDetailsMap=dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_PTAG_DETAILS_RDS),"00"+pTag, "01");
							Assert.assertEquals(ErrorCodes.PHARMACY_RDS_PTAG_DETAILS_NOT_FOUND, 1 , ptagDetailsMap.size());
							Assert.assertEquals(ErrorCodes.PHARMACY_RDS_PTAG_MISMATCH_IN_RECEIVED_QTY, (int)(Double.parseDouble(receivedQtyVendorPack.get(0))*(Integer.valueOf(vnpkList.get(0))/Integer.valueOf(whpkList.get(0)))) , ptagDetailsMap.get(0).get("whpk_qty"));
							logger.info("Validated ptag: ["+pTag+"] in RDS" );
						});
						String rcvUnitID= String.valueOf(ptagDetailsMap.get(0).get("rcv_unit_id"));
						String slotID= String.valueOf(ptagDetailsMap.get(0).get("slot_id"));
						if (Integer.valueOf(deptNumList.get(0)) != 40) {
							Failsafe.with(retryPolicy).run(() -> {
								List<String> receivedQtyVendorPack= JsonPath.read(testFlowData, "$..[?(@.parentContainer=='"+pTag+"')].receivedQuantity");
								logger.info("Executing query to get receive unit details from Poline pedigree for Ptag: ["+pTag+"] with receive unit ID: ["+rcvUnitID+"] with query : "+environment.getProperty(SELECT_QUERY_POLINE_PEDIGREE_RCV_UNIT_DETAILS_RDS));
								List<Map<String, Object>> rcvUnitDetailsMap=dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_POLINE_PEDIGREE_RCV_UNIT_DETAILS_RDS),rcvUnitID);
								Assert.assertEquals(ErrorCodes.PHARMACY_RDS_RCV_UNIT_DETAILS_NOT_FOUND_IN_PEDIGREE, 1 , rcvUnitDetailsMap.size());
								Assert.assertEquals(ErrorCodes.PHARMACY_RDS_MISMATCH_IN_RECEIVED_QTY_IN_PEDIGREE, (int)(Double.parseDouble(receivedQtyVendorPack.get(0))*(Integer.valueOf(vnpkList.get(0))/Integer.valueOf(whpkList.get(0)))) , rcvUnitDetailsMap.get(0).get("received_qty"));
								logger.info("Validated receive unit details from Poline pedigree for Ptag: ["+pTag+"] with receive unit ID: ["+rcvUnitID+"]" );
							});
						}
						logger.info("Executing query to get prime slot id");
						List<Map<String, Object>> primeSlotId = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_PRIME_SLOT_ID_RDS), itemList.get(0));
						logger.info("Executed query to get prime slot id:" + primeSlotId.get(0));
						logger.info("Excuting query to get pallet status code for ptag: ["+pTag+"] with query : "+environment.getProperty(SELECT_QUERY_TO_GET_PALLET_STATUS_CODE_RDS));

						List<Map<String, Object>> palletStatusCode = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_PALLET_STATUS_CODE_RDS), "00"+pTag);
						logger.info("Executed query to get pallet status code " + palletStatusCode.get(0));

						String palletStatus = String.valueOf(palletStatusCode.get(0).get("pallet_status_code"));
						String primeSlot = String.valueOf(primeSlotId.get(0).get("slot_id"));
						logger.info(primeSlot+" is primeSlot, "+palletStatus +" is palletStatus and " +slotID+" is slotID ");
							if (!palletStatus.equalsIgnoreCase("99")  && !primeSlot.equalsIgnoreCase(slotID)){

								List<Map<String, Object>> slotStatsMap = dbUtils.selectFrom(PRODUCT_NAME.SMARTSLOTTING, environment.getProperty("smart_slotting_get_rcv_unit_details"), rcvUnitID, slotID);
							logger.info("Executed query to get entry in Slot Item Stats Table:" + slotStatsMap);
							boolean noEntryInSlotItemStats = false;
							try {
								noEntryInSlotItemStats = slotStatsMap.isEmpty();
							} catch (Exception e) {
								logger.info("Something went wrong while Validating Slot Item Stats Table After Receiving Pallet(s)", e);
								throw e;
							}
							Assert.assertFalse(ErrorCodes.PHARMACY_SMART_SLOTTING_VALIDATION_FAILED, noEntryInSlotItemStats);
						}
					}
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating PTag", e);
		}
	}

	@Step
	public void validateOSDRInRDS() {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();

			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);
			List<String> deliveryNumList = JsonPath.parse(testFlowData).read(DELIVERY_JSON_PATH);

			for (String poNumber : poNumberList) {
				totalReceivedQtyForPO = 0;
				totalShortageQtyForPO = 0;
				totalOverageQtyForPO = 0;
				int totalExpectedQtyForPO = 0;
				List<String> poLineQtyList = null;
				List<String> vnpkList = null;
				List<String> receivedQtyForTheLineList = null;

				List<String> poLineNumbers = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String lineNumber : poLineNumbers) {
					poLineQtyList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + lineNumber + "')].poVnpkQty");
					vnpkList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + lineNumber + "')].vnpk");
					receivedQtyForTheLineList = JsonPath.parse(testFlowData)
							.read("$..poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails[?(@.poLineNumber=='"
									+ lineNumber + "')].receivingInstructions[?(@.isVTR!=true)].receivedQuantity");

					for (String receivedQtyForTheLine : receivedQtyForTheLineList) {
						totalReceivedQtyForPO = totalReceivedQtyForPO
								+ ((int) Math.ceil(Double.parseDouble((receivedQtyForTheLine))));
					}
					totalExpectedQtyForPO = totalExpectedQtyForPO
							+ (Integer.valueOf(poLineQtyList.get(0)));
				}

				totalShortageQtyForPO = (totalReceivedQtyForPO < totalExpectedQtyForPO) ? (totalExpectedQtyForPO - totalReceivedQtyForPO) : 0;
				totalOverageQtyForPO = (totalReceivedQtyForPO > totalExpectedQtyForPO) ? (totalReceivedQtyForPO - totalExpectedQtyForPO) : 0;
				logger.info("Excuting query to get OSDR for Delivery: [" + deliveryNumList.get(0) + "] with PO: [" + poNumber + "] query : " + environment.getProperty(SELECT_QUERY_TO_GET_OSDR_DETAILS_RDS));
				Failsafe.with(retryPolicy).run(() -> {
					List<Map<String, Object>> osdrDetailsMap=dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_OSDR_DETAILS_RDS),deliveryNumList.get(0), poNumber);
					Assert.assertEquals(ErrorCodes.PHARMACY_RDS_MISMATCH_IN_OSDR_RECEIVED_QTY, totalReceivedQtyForPO, osdrDetailsMap.get(0).get("units_recv_qty"));
					Assert.assertEquals(ErrorCodes.PHARMACY_RDS_MISMATCH_IN_OSDR_OVERAGE_QTY, totalOverageQtyForPO, osdrDetailsMap.get(0).get("units_over_qty"));
					Assert.assertEquals(ErrorCodes.PHARMACY_RDS_MISMATCH_IN_OSDR_SHORTAGE_QTY, totalShortageQtyForPO, osdrDetailsMap.get(0).get("units_short_qty"));
				});
				logger.info("Validated OSDR for Delivery: [" + deliveryNumList.get(0) + "] with PO: [" + poNumber + "]");
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating OSDR in RDS", e);
		}
	}

	public String performUPCScan(String upc) {
		try {
			Thread.sleep(6000);
			logger.info("Scanning UPC:" + upc);
			performScan(upc);
			logger.info("Scanned UPC:" + upc);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning", e);
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return upc;
	}

	@Step
	public void upcScanForD40orSTO(String partialOrFull, boolean catalogueReq, boolean transferPallet) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			poNumberList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {
				List<String> itemList = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				Set<String> uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				logger.info("unique Items are " + uniqueItems);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					List<String> itemUPC = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].itemUpc");
					List<String> caseUPC = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].caseUpc");
					for (int i = 0; i < itemUPC.size(); i++) {
						if (partialOrFull.equalsIgnoreCase("Complete")) {
							if (catalogueReq) {
								String catalogueUPC = itemUPC.get(i);
								int count = 0;
								do {
									catalogueUPC = "" + (Long.parseLong(catalogueUPC) + (++count));
								} while (itemUPC.contains(catalogueUPC) || caseUPC.contains(catalogueUPC));
								logger.info("Final catalogueUPC" + catalogueUPC);
								performUPCScan(catalogueUPC);
								validateAndCompleteCataloguingFlow(catalogueUPC, itemNum, itemUPC.get(0), transferPallet);
							} else {
								performUPCScan(itemUPC.get(i));
							}

							List<String> povnpkQty = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
									+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].poVnpkQty");
							receiveD40Itemreceiving(partialOrFull, itemUPC.get(i), itemNum, catalogueReq, transferPallet);
						} else if (partialOrFull.equalsIgnoreCase("Partial")) {
							performUPCScan(itemUPC.get(i));

							logger.info("Excuting query to get slot ID for manual slotting: " + environment.getProperty(SELECT_QUERY_TO_GET_SLOT_ID_RDS));
							List<Map<String, Object>> slotIds = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_SLOT_ID_RDS));
							String slotId = slotIds.get(0).get("slot_id").toString();
							List<String> povnpkQty = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
									+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].poVnpkQty");
							Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_TOTAL_CASES, povnpkQty.get(0), receivingPharmPage.validateExpectedReceivableqtyInUI());
							receivingPharmPage.setManualSlotting(slotId);
							String manualSlot = "Manual slot selected, slot " + slotId.toUpperCase();
							try {
								Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_MANUAL_SLOTTING, manualSlot,
										receivingPharmPage.manualSlot());
							} catch (AssertionError ae) {
								ae.printStackTrace();
								manualSlot = "Slot to " + slotId.toUpperCase();
								Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_MANUAL_SLOTTING, manualSlot,
										receivingPharmPage.manualSlot());
							}
							receiveD40Itemreceiving(partialOrFull, itemUPC.get(i), itemNum, catalogueReq, transferPallet);
						} else if (partialOrFull.equalsIgnoreCase("ReceivePartialCaseUsingLink")) {
							performUPCScan(itemUPC.get(0));
							Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_TOTAL_CASES, String.valueOf(validateUnitsPerCaseQty(Integer.valueOf(itemNum))),
									receivingPharmPage.validateExpectedReceivableqtyInUI());
							receiveD40Itemreceiving(partialOrFull, itemUPC.get(0), itemNum, catalogueReq, transferPallet);
							receivingPharmPage.navigateBack();
						}
					}
				}
			}
			if (!transferPallet) {
				receivingPharmHelper.storePtagInstructionsIntoTestflowData();
			}
		} catch (Exception e) {
			logger.info("Error while posting instruction request");
			throw new AutomationFailure("Error while posting instruction request", e);
		}
	}

	public void receiveD40Itemreceiving(String partialOrFull, String upc, String itemNum, boolean catalogueReq, boolean tranferPallet) {
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
		List<String> poNumber = JsonPath.read(testFlowData, "$.testFlowData.poDetails..poNumber");
		List<String> povnpkQty = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
				+ poNumber.get(0) + "')].poLineDetails[?(@.itemUpc == '" + upc + "')].poVnpkQty");

		if (!tranferPallet) {
			if (partialOrFull.equalsIgnoreCase("Complete")) {
				receivingPharmPage.enterQtyForReceiving().sendKeys(povnpkQty.get(0));
				receivingPharmPage.receiveD40Item();
				Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_PALLET_RECEIVED, povnpkQty.get(0) + " cases received",
						receivingPharmPage.countOfPalletReceived());
			} else if (partialOrFull.equalsIgnoreCase("Partial")) {
				int maxReceivableQty = Integer.parseInt(povnpkQty.get(0));
				logger.info(maxReceivableQty + " is max Receivable Qty");
				if (maxReceivableQty >= 2) {
					int qty = maxReceivableQty - 1;
					String enterQty = String.valueOf(qty);
					receivingPharmPage.enterQtyForReceiving().sendKeys(enterQty);
					receivingPharmPage.receiveD40Item();
					logger.info("received Case Count In Complete DeliveryScreen "
							+ receivingPharmPage.countOfPalletReceived());
					Assert.assertEquals(ErrorCodes.PHARMACY_VALIDATE_PALLET_RECEIVED, enterQty + " cases received",
							receivingPharmPage.countOfPalletReceived());
				}
			} else if (partialOrFull.equalsIgnoreCase("ReceivePartialCaseUsingLink")) {
				int unitspercase = getUnitsPerCaseQty(Integer.valueOf(itemNum));
				receivingPharmPage.enterQtyForReceiving().sendKeys(String.valueOf(unitspercase));
				receivingPharmPage.receiveD40Item();
			} else if (!catalogueReq) {
				int unitspercase = getUnitsPerCaseQty(Integer.valueOf(itemNum));
				receivingPharmPage.enterQtyForReceiving().sendKeys(String.valueOf(unitspercase));
				receivingPharmPage.receiveD40Item();
			}
		}
	}
//		@Step
//		public void validateReceipt() {
//			try {
//				receivingPharmHelper.storePtagInstructionsIntoTestflowData();
//				String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
//				List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);
//				for (String poNumber : poNumberList) {
//					List<String> poLineNumbers = JsonPath.parse(testFlowData).read(
//							"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
//					for (String lineNumber : poLineNumbers) {
//						List<String> pTagList = JsonPath.parse(testFlowData)
//								.read("$..poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails[?(@.poLineNumber=='"
//										+ lineNumber + "')].receivingInstructions[?(@.isVTR!=true)].parentContainer");
//						for (String pTag : pTagList) {
//							Failsafe.with(retryPolicy).run(() -> {
//								List<String> receivedQtyVendorPack = JsonPath.read(testFlowData,
//										"$..[?(@.parentContainer=='" + pTag + "')].receivedQuantity");
//								int receivedQty = Integer.valueOf(receivedQtyVendorPack.get(0));
//								Response receiptresponse = idmSteps.validateReceivedQuantity(poNumber, receivedQty);
//							});
//						}
//					}
//				}
//			} catch (Exception e) {
//				throw new AutomationFailure("Something went wrong while validating PTag", e);
//			}
//		}

	public void exitFromReceivingScreen() {
		receivingPharmPage.navigateBack();
		receivingPharmPage.clickOnExitButton();
	}

	@Step
	public void cancelLabel(boolean isLabel) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);
			if(isLabel)
				exitFromReceivingScreen();
			for (String poNumber : poNumberList) {
				List<String> poLineNumbers = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String lineNumber : poLineNumbers) {
					List<String> pTagList= JsonPath.parse(testFlowData).read("$..poDetails[?(@.poNumber=='"+poNumber+"')].poLineDetails[?(@.poLineNumber=='"+lineNumber+"')].receivingInstructions[?(@.isVTR!=true)].parentContainer");
					if(isLabel) {
						receivingPharmPage.clickOnLeftMenuBar();
						receivingPharmPage.selectLabelCorrectionOption();
						receivingPharmPage.checkForlabelCorrectionScreen();
						performScan(pTagList.get(0));
						receivingPharmPage.clickOnCancelLabelButtonForLabelCorrection();
						receivingPharmPage.clickOnYesCancelPallet();
					} else {
						cancelPallet();
					}
					testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, Boolean.valueOf("true"),
							"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + pTagList.get(0)
									+ "')].isVTR");
					threadLocal.get().put(TEST_FLOW_DATA, testFlowData);
				}
			}
			receivingPharmPage.navigateBack();
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while cancelling the Label", e);
		}
	}

	@Step
	public void validateCancelledLabelContainerStatusInReceiving(String expectedContainerStatus) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> deliveryNumberList = JsonPath.parse(testFlowData).read(DELIVERY_JSON_PATH);
			List<String> cancelledPTagList= JsonPath.parse(testFlowData).read("$..receivingInstructions[?(@.isVTR==true)].parentContainer");
			for (String cancelledPtag : cancelledPTagList) {
				Failsafe.with(retryPolicy).run(() -> {
					String containerResponse = receivingPharmHelper.getcontainerResponseForDelivery(deliveryNumberList.get(0));
					List<String> actualCancelledPtagStatus=JsonPath.parse(containerResponse)
						.read("$.[?(@.trackingId=='"+cancelledPtag+"')].containerStatus");
					Assert.assertEquals(ErrorCodes.PHARMACY_REC_MISMATCH_IN_CONTAINER_STATUS, expectedContainerStatus.toUpperCase(), actualCancelledPtagStatus.get(0).toUpperCase());
				});
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status for Cancelled label in Receiving", e);
		}
	}

	@Step
	public void validateCancelledLabelInRDS() {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> cancelledPTagList= JsonPath.parse(testFlowData).read("$..receivingInstructions[?(@.isVTR==true)].parentContainer");
			for (String cancelledPtag : cancelledPTagList) {
				logger.info("Excuting query to get Cancelled Label details for ptag: ["+cancelledPtag+"] with query : "+environment.getProperty(SELECT_QUERY_TO_GET_CANCELLED_PTAG_DETAILS_RDS));
				Failsafe.with(retryPolicy).run(() -> {
					List<Map<String, Object>>  cancelPalletPtagDetailsMap = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_CANCELLED_PTAG_DETAILS_RDS),"00"+cancelledPtag);
					Assert.assertEquals(ErrorCodes.PHARMACY_RDS_PTAG_DETAILS_NOT_FOUND, 1 , cancelPalletPtagDetailsMap.size());
					Assert.assertEquals(ErrorCodes.PHARMACY_RDS_MISMATCH_IN_PTAG_STATUS, 99 , Integer.valueOf(cancelPalletPtagDetailsMap.get(0).get("pallet_status_code").toString()));
					Assert.assertEquals(ErrorCodes.PHARMACY_RDS_MISMATCH_IN_RECEIVED_QTY, 0 , Integer.valueOf(cancelPalletPtagDetailsMap.get(0).get("whpk_qty").toString()));
				});
				logger.info("Validated Cancelled label details for ptag: ["+cancelledPtag+"] in RDS" );
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status for Cancelled label in RDS", e);
		}
	}

	@Step
	public void killApp() throws ConfigurationException, InterruptedException {
		try {
			if (getDriver() != null) {
				logger.info("Closing App=" + getDriver());
				killAppInBackground("com.walmart.move.nim.receiving.mobile");
				getDriver().quit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void killAppInBackground(String appPackage) {
		logger.info("Killing App in Background" + appPackage);
		List<String> scanAttributes = Arrays.asList(appPackage);
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am force-stop", "args", scanAttributes);
		getAndroidDriver().executeScript("mobile: shell", scanEvent);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("Killed App in Background" + appPackage);
	}
	
	@Step
	public void userUnloadsDelivery() {
		try {
			logger.info("Receiver unloading the Delivery");
			receivingPharmPage.clickOnRightSide3DotMenu();
			receivingPharmPage.clickOnPrintDeliveryLabelOption();
			receivingPharmPage.enterNumberOFLabelsToPrintTextBox("1");
			receivingPharmPage.clickOnPrintButton();
			receivingPharmPage.clickOnMarkDeliveryUnloadedLink();
			receivingPharmPage.clickOnDelievryUnloadConfirmationButton();
			receivingPharmPage.checkForDeliveryUnloadedTextMessage();
			exitFromReceivingScreen();
			logger.info("Receiver unloaded the Delivery");
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Unloading the Delivery", e);
		}
	}
	
	@Step
	public void validateWhetherDoorGotDetached() {
		try {
			logger.info("Validating whether Door got detached from the Delivery");
			performDoorScan();
			receivingPharmPage.checkForNoDeliveryAttachedForDoorErrorMssg();
			receivingPharmPage.clickOnOkButtonOnPopup();
			logger.info("Door got detached from the Delivery");
		} catch (Exception e) {
			throw new AutomationFailure("Something went validating whether door got detached for the Delivery", e);
		}
	}
	
	@Step
	public void validateCaseOverage() {
		try {
			String expectedMessage = "All expected cases have been scanned. Receive these cases and submit an overage ticket for the remaining";
			Assert.assertEquals(ErrorCodes.PHARMACY_CASE_OVERAGE_VALIDATION_FAILED, expectedMessage, receivingPharmPage.getCaseOverageMessageText());
			logger.info("Validated Case Overage Popup Message");
			receivingPharmPage.clickOnOkButton();
		} catch(Exception e) {
			throw new AutomationFailure("Something went while validating Case Overage", e);
		}
	}

	@Step
	public void clicksOnReceivePartialCase() {
		receivingPharmPage.clickReceivePartialCaseLink();
	}

	@Step
	public void validateAndCompleteCataloguingFlow(String catalogueGTIN, String itemNumber, String itemUpc, boolean transferPallet) {
		try {
			String updateGTINMessage = "GTIN " + catalogueGTIN + " was not found on this delivery. Make sure you scanned the correct barcode or you can temporarily update the GTIN.";
			Assert.assertEquals(ErrorCodes.PHARMACY_UPDATE_GTIN_MESSAGE_VALIDATION_FAILED, updateGTINMessage, receivingPharmPage.getItemNotFoundMessageText());
			receivingPharmPage.clickUpdateGTINButton(true);
			receivingPharmPage.clickSearchItemButton();
			logger.info("item no. is " + itemNumber);
			if (transferPallet) {
				performUPCScan(itemUpc);
				Assert.assertEquals(ErrorCodes.PHARMACY_GTIN_ITEM_DETAILS_VALIDATION_FAILED, itemNumber, receivingPharmPage.validateItemInfo());
				Assert.assertEquals(ErrorCodes.PHARMACY_GTIN_ITEM_DETAILS_VALIDATION_FAILED, catalogueGTIN, receivingPharmPage.validateUpdatedGtin());
				logger.info("Validated the item info and gtin populated in cataloguing screen");
				receivingPharmPage.updateButton();
				receivingPharmPage.clickYesReceiveItemButtonOnPopup();
				logger.info("Scanned Catalogued UPC");
				receivingPharmPage.navigateBack();
				receivingPharmPage.clickOnYesLeavePalletOpenBtn();

			} else {
				receivingPharmPage.enterItemNumber(itemNumber);
				receivingPharmPage.clickSearchItemButton();
				Assert.assertEquals(ErrorCodes.PHARMACY_GTIN_ITEM_DETAILS_VALIDATION_FAILED, itemNumber, receivingPharmPage.validateItemInfo());
				Assert.assertEquals(ErrorCodes.PHARMACY_GTIN_ITEM_DETAILS_VALIDATION_FAILED, catalogueGTIN, receivingPharmPage.validateUpdatedGtin());
				logger.info("Validated the item info and gtin populated in cataloguing screen");
				receivingPharmPage.updateButton();
				receivingPharmPage.clickYesReceiveItemButtonOnPopup();
				logger.info("Scanned Catalogued Item number");
				Thread.sleep(5000);
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went while Cataloguing GTIN/UPC", e);
		}
	}
	
	@Step
	public void validateCancelPallet() {
		try {
			receivingPharmHelper.validateReceivingDBAfterCancellingPallet();
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Validate Receiving DB AFter Cancelling Pallet", e);
		}
	}

	@Step
	public void reopendelivery() {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			receivingPharmPage.reopenDelivery();
			List<String> deliveryNumList = JsonPath.parse(testFlowData).read(DELIVERY_JSON_PATH);
			logger.info("Excuting query to validate reopen delivery " + environment.getProperty(SELECT_QUERY_TO_GET_RCVR_FINAL_TS_AFTER_REOPEN_DELIVERY_RDS, deliveryNumList.get(0)));
			List<Map<String, Object>> receivertimestamp = dbUtils.selectFrom(Config.DC, environment.getProperty(SELECT_QUERY_TO_GET_RCVR_FINAL_TS_AFTER_REOPEN_DELIVERY_RDS), deliveryNumList.get(0));
			logger.info("receivertimestamp is " + receivertimestamp);
			Assert.assertEquals(ErrorCodes.PHARMACY_REOPEN_DELIVERY_VALIDATION_FAILED, receivertimestamp.get(0).get("receiver_final_ts"), null);
			logger.info("Re-open delivery has been done");
		} catch (Exception e) {
			throw new AutomationFailure("Something went while Re-opening delivery", e);
		}
	}

	@Step
	public void labelCancelFromInsideDelivery() {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);

			for (String poNumber : poNumberList) {
				List<String> poLineNumbers = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String lineNumber : poLineNumbers) {
					List<String> pTagList = JsonPath.parse(testFlowData).read("$..poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails[?(@.poLineNumber=='" + lineNumber + "')].receivingInstructions[?(@.isVTR!=true)].parentContainer");
					receivingPharmPage.labelCancelInsideDelivery();
					performScan(pTagList.get(0));
					receivingPharmPage.clickOnCancelLabelButtonForLabelCorrection();
					receivingPharmPage.clickOnYesCancelPallet();
					testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, Boolean.valueOf("true"),
							"$.testFlowData..receivingInstructions[?(@.parentContainer == '" + pTagList.get(0)
									+ "')].isVTR");
					threadLocal.get().put(TEST_FLOW_DATA, testFlowData);
				}
			}
			receivingPharmPage.navigateBack();
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while cancelling the Label", e);
		}
	}

	@Step
	public void receiveAfterTransferringPallet(String partialOrFull, boolean catalogueReq, boolean tranferPallet) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);
			for (String poNumber : poNumberList) {
				List<String> itemList = JsonPath.read(testFlowData,
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				Set<String> uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				logger.info("unique Items are " + uniqueItems);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					List<String> itemUPC = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].itemUpc");
					List<String> caseUPC = JsonPath.read(testFlowData, "$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber==" + itemNum + ")].caseUpc");
					receivingPharmPage.viewAllOpenPallet();
					receivingPharmPage.transferOpenPallet();
					receiveD40Itemreceiving(partialOrFull, itemUPC.get(0), itemNum, catalogueReq, tranferPallet);
					receivingPharmHelper.storePtagInstructionsIntoTestflowData();

				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while cancelling the Label", e);
		}
	}}