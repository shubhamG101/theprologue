package com.walmart.supplychain.catalyst.by.ui.steps;


import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tools.ant.taskdefs.Sleep;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.DRIVER_TYPE;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.UiActionsHelper;
import com.walmart.supplychain.catalyst.by.ui.pages.BYReceivingPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYLoginPage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmSteps;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYReceivingSteps extends ScenarioSteps{
	
	WebDriver driver;
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	Environment endPoint;
	
	@Autowired
	BYLoginPage byLoginPage;
	
	@Autowired
	BYReceivingPage byReceivingPage;
	
	@Autowired
	BYUiHelper byReceivingHelper;
	
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	DbUtils dbUtils;
	
	@Autowired
	UiActionsHelper uiActionsHelper;


	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 
			Constants.RETRY_EXECUTION_COUNT);

	private static final String TEST_FLOW_DATA = "testFlowData";
	
	@SuppressWarnings("deprecation")
	@Step
	public void verifyInboundShipmentStatus(String expectedShipmentStatus, String expectedEquipmentStatus) {
		
		try {
			
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("data is {}" , testFlowData);
			
			//fetching PO number
			List<String> poNumbers = JsonPath.read(testFlowData, "$.testFlowData.poDetails..poNumber");
			
			for(int i=0; i<poNumbers.size();i++) {
				logger.info("PO number is: {}", poNumbers.get(i).toString());
			}
			
			//fetching delivery number
			JSONArray deliveryNumbers = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..deliveryNumber");
			
			for(int i=0; i<deliveryNumbers.size();i++) {
				logger.info("delivery number is: {}", deliveryNumbers.get(i).toString());
			}
			
			//fetching inbound yard location
			JSONArray yardLocations = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundYardZone");
			
			for(int i=0; i<yardLocations.size();i++) {
				logger.info("Inbound yard location is: {}", yardLocations.get(i).toString());
			}
			
			//fetching inbound door location
			JSONArray doorLocations = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			
			for(int i=0; i<doorLocations.size();i++) {
				logger.info("Inbound door location is: {}", doorLocations.get(i).toString());
			}
			
			//fetching item number
			JSONArray itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poLineDetails..itemNumber");
			
			for(int i=0; i<itemNumbers.size();i++) {
				logger.info("Item number is: {}", itemNumbers.get(i).toString());
			}
			
			
			logger.info("Verifying inbound shipment status in BY Web UI  ----->");
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			filterShipmentNumber(deliveryNumbers.get(0).toString());
			
			validateStatus(deliveryNumbers.get(0).toString(), expectedShipmentStatus, expectedEquipmentStatus);
			verifyPO_ItemNumbers(deliveryNumbers.get(0).toString());
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong Validating Shipmnet status in BY UI", e);
		}
	}
	
	
	@Step
	public void gateInvalidationInBy() {
		
		try {
			verifyAppropiateTrailerLocation("Checked In");
		}
		
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Yard Zone location in BY UI", e);
		}
		
	}
	
	@Step
	public void doorvalidationInBy() {
		try {
			verifyAppropiateTrailerLocation("Open For Receiving");
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Assigned door in BY UI", e);
		}
	}
	
	public void loginToBY() throws InterruptedException {
		
		byLoginPage.getUrl(endPoint.getProperty("byWeb_UI_Url"));
		byLoginPage.loginIntoBY();     //login into BY 
		
	}
	
	
	public void filterShipmentNumber(String shipmentNumber) {
		
		driver = getDriver();
		driver.switchTo().frame(byReceivingPage.workingFrame);
		
		//Clearing applied filter
		byReceivingPage.clickOnAppliedFiltersClearIcon();
		byReceivingPage.enterValueUnderFilterBox(shipmentNumber);
		byReceivingPage.selectFilterOptionDropdown("in Inbound Shipment Number");
		
		uiActionsHelper.sync(driver, byReceivingPage.shipmentRecordBasedOnSpecificValue(shipmentNumber));
		Assert.assertTrue(ErrorCodes.CATALYST_WRONG_DELIVERY_SHIPMENT_RECORD, byReceivingPage.shipmentRecordBasedOnSpecificValue(shipmentNumber).isDisplayed());
		logger.info("Proper shipment number got filtered successfully=========");
		
	}
	
	
	
	public void validateStatus(String shipmentNumber, String inboundShipmentStatus, String equipmentStatus) throws InterruptedException {
		
		uiActionsHelper.sync(driver, byReceivingPage.shipmentRecordBasedOnSpecificValue(shipmentNumber));
		byReceivingPage.clickOnShipmentRecordLink(shipmentNumber);
		
		Failsafe.with(retryPolicy).run(() -> {
			
			byReceivingPage.clickOnRefreshIconUnderShipmentPage();
			uiActionsHelper.sync(driver, byReceivingPage.inboundShipment_Equipment_Status("Inbound Shipment:"));
			uiActionsHelper.sync(driver, byReceivingPage.inboundShipment_Equipment_Status("Equipment:"));
			
			String actualInboundShipmentStatus = byReceivingPage.inboundShipment_Equipment_Status("Inbound Shipment:").getText().trim();
			String actualEquipmentStatus = byReceivingPage.inboundShipment_Equipment_Status("Equipment:").getText().trim();
			
			logger.info("Shown inbound status : {}, and equipment status : {} ", actualInboundShipmentStatus, actualEquipmentStatus);
			
			Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_STATUS, inboundShipmentStatus,actualInboundShipmentStatus);
			Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_EQUIPMENT_STATUS, equipmentStatus,actualEquipmentStatus);
			
		});
		
	}
	
	
	
	public void verifyPO_ItemNumbers(String shipmentNumber) throws InterruptedException {
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> expectedPONumbers = JsonPath.read(testFlowData, "$.testFlowData.poDetails..poNumber");
		JSONArray itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poLineDetails..itemNumber");
		
		Map<String, String> expectedItemNumbers = new HashMap<String, String>();
		
		List<String> actualPONumbers = new ArrayList<String>();
		Map<String, String> actualItemNumbers = new HashMap<String, String>();
		
		expectedItemNumbers.put(expectedPONumbers.get(0), itemNumbers.get(0).toString());
		
		uiActionsHelper.sync(driver, byReceivingPage.getPoNumbers().get(0));
		
		int totalPONumbers = byReceivingPage.getPoNumbers().size();
		
		logger.info("Total numbers of PO available in BY UI: {} ", totalPONumbers); 
		for(int i=0; i<totalPONumbers; i++) {
			String curentPONumber = byReceivingPage.getPoNumbers().get(i).getText().trim();
			logger.info("Actual PO: {} ", curentPONumber);
			actualPONumbers.add(curentPONumber);
			
			byReceivingPage.getPoNumbers().get(i).click();
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			uiActionsHelper.sync(driver, byReceivingPage.getItemNumbers().get(i));
			String currentItemNumber =  byReceivingPage.getItemNumbers().get(i).getText().trim();
			logger.info("Actual item: {} ", currentItemNumber);
			actualItemNumbers.put(curentPONumber, currentItemNumber);
			
			byReceivingPage.clickOnBackButtonIconUnderShipmentTab();
//			byReceivingPage.clickOnBackButtonIconUnderShipmentTab();
			
		}
		
		byReceivingPage.clickOnBackButtonIconUnderShipmentTab();
		
		logger.info("Actual PO numbers: {}", actualPONumbers.toString());
		logger.info("Actual Item numbers corresponding to POs: {}", actualItemNumbers.toString());
		
		//Verifying PO numbers
		Collections.sort(actualPONumbers);
		Collections.sort(expectedPONumbers);
		Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_PO_NUMBER, expectedPONumbers,actualPONumbers);
		
		//Verifying Item Numbers
		Assert.assertEquals(ErrorCodes.CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_ITEM_NUMBER, expectedItemNumbers,actualItemNumbers);
		
		driver.switchTo().defaultContent();
		
	}

	
	public void verifyAppropiateTrailerLocation(String equipmentStatus) throws InterruptedException {
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame(byReceivingPage.workingFrame);
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray yardLocations = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundYardZone");
		JSONArray doorLocations = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
		JSONArray trailerIdList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundTrailerNumber");
		
		//for equipment Expected status
		if(equipmentStatus.equalsIgnoreCase("Expected")) {
			
			
//			boolean yardLocationFlag = false;
//			boolean doorLocationFlag = false;
//			
//			//checking at yard location
//			int numberOfEquipmentAtYardLocation = specificTrailerBasedOnDoorOrYardLocation(yardLocations.get(0).toString()).size();
//			for(WebElement element : specificTrailerBasedOnDoorOrYardLocation(yardLocations.get(0).toString())) {
//				String actualTrailerNumber = element.getText().trim();
//				logger.info("Shown trailer number is: {} ", actualTrailerNumber);
//				
//				if(actualTrailerNumber.contains(trailerIdList.get(0).toString())) {
//					logger.error("Expected trailer is at yard location!!");
//					yardLocationFlag = true;
//					break;
//				}
//			}
//			
//			assertFalse("Expected trailer is at yard location!!!!", yardLocationFlag);
//			
//			//checking at door location
//			int numberOfEquipmentAtDoorLocation = specificTrailerBasedOnDoorOrYardLocation(doorLocations.get(0).toString()).size();
//			for(WebElement element : specificTrailerBasedOnDoorOrYardLocation(doorLocations.get(0).toString())) {
//				String actualTrailerNumber = element.getText().trim();
//				logger.info("Shown trailer number is: {} ", actualTrailerNumber);
//				
//				if(actualTrailerNumber.contains(trailerIdList.get(0).toString())) {
//					logger.error("Expected trailer is at door location!!");
//					doorLocationFlag = true;
//					break;
//				}
//			}
//			
//			assertFalse("Expected trailer is at door location!!!!", doorLocationFlag);
		}
		
		//for equipment Checked in status
		else if(equipmentStatus.equalsIgnoreCase("Checked In")) {
			
			boolean flag = false;
			int numberOfEquipmentUnderParticularLocation = byReceivingPage.specificTrailerBasedOnDoorOrYardLocation(yardLocations.get(0).toString()).size();
			logger.info("Number of trailers at yard location {} is : {}", yardLocations.get(0).toString(), numberOfEquipmentUnderParticularLocation);
			
			for(WebElement element : byReceivingPage.specificTrailerBasedOnDoorOrYardLocation(yardLocations.get(0).toString())) {
				String actualTrailerNumber = element.getText().trim();
				logger.info("Shown trailer number is: {} ", actualTrailerNumber);
				
				if(actualTrailerNumber.contains(trailerIdList.get(0).toString())) {
					logger.info("Expected trailer number at appropiate yard location validated successfully!!");
					flag = true;
					break;
				}
			}
			
			Assert.assertEquals(ErrorCodes.CATALYST_TRAILER_NOT_AT_PROPER_LOCATION, true, flag);
		}
		
		//for equipment Open For Receiving status
		else if(equipmentStatus.equalsIgnoreCase("Open For Receiving")) {
			
			boolean yardLocationFlag = false;
			boolean doorLocationFlag = false;
			
			//checking at yard location whether it got removed from there or not
			int numberOfEquipmentAtYardLocation = byReceivingPage.specificTrailerBasedOnDoorOrYardLocation(yardLocations.get(0).toString()).size();
			logger.info("Number of trailers at yard location {} is : {}", yardLocations.get(0).toString(), numberOfEquipmentAtYardLocation);
			
			for(WebElement element : byReceivingPage.specificTrailerBasedOnDoorOrYardLocation(yardLocations.get(0).toString())) {
				String actualTrailerNumber = element.getText().trim();
				logger.info("Shown trailer number is: {} ", actualTrailerNumber);
				
				if(actualTrailerNumber.contains(trailerIdList.get(0).toString())) {
					logger.error("Expected trailer is still at yard location!!");
					yardLocationFlag = true;
					break;
				}
			}
			
			Assert.assertEquals(ErrorCodes.CATALYST_TRAILER_AT_WRONG_LOCATION, false, yardLocationFlag);
			
			//checking at door location for presence
			int numberOfEquipmentAtDoorLocation = byReceivingPage.specificTrailerBasedOnDoorOrYardLocation(doorLocations.get(0).toString()).size();
			logger.info("Number of trailer at door location {} is : {}", doorLocations.get(0).toString(), numberOfEquipmentAtDoorLocation);
			
			for(WebElement element : byReceivingPage.specificTrailerBasedOnDoorOrYardLocation(doorLocations.get(0).toString())) {
				String actualTrailerNumber = element.getText().trim();
				logger.info("Shown trailer number is: {} ", actualTrailerNumber);
				
				if(actualTrailerNumber.contains(trailerIdList.get(0).toString())) {
					logger.info("Expected trailer is at door location!!");
					doorLocationFlag = true;
					break;
				}
			}
			
			Assert.assertEquals(ErrorCodes.CATALYST_TRAILER_NOT_AT_PROPER_LOCATION, true, doorLocationFlag);
			
			//checking trailer is at location with safety tag
			byReceivingPage.specificTralierTagsBaesOnDoorLocation(doorLocations.get(0).toString(), trailerIdList.get(0).toString(), "Safety").isDisplayed();
			logger.info("Trailer is avialable with safety tag at door location: validated successfully!!");

		}
		driver.switchTo().defaultContent();
	}
	
	@Step
	public void performReleaseHold() throws InterruptedException {

		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> expectedLpnNumber = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");

			byReceivingPage.verifyInventoryPageHeading();
			byReceivingPage.enterValueUnderFilterTB("rpFilterableViews", "LPN", expectedLpnNumber.get(0));
			Failsafe.with(retryPolicy).run(() -> {
				byReceivingPage.inputTabByText("LPNs").click();
				logger.info("Clicked on LPNs Tab...");

				Assert.assertEquals(ErrorCodes.CATALYST_HOLD_TAG_MISMATCH, true,
						byReceivingPage.isElementPresentBasedOnExactText("Hold"));
				logger.info("Hold Tag is avialable with LPN status: validated successfully!!");
			});
			byReceivingPage.clickOnLpnCheckBox(expectedLpnNumber.get(0));

			byReceivingPage.clickOnActionsButton();

			byReceivingPage.selectReleaseHoldLink();

			byReceivingPage.selectLpnCheckBox();

			byReceivingPage.clickOnReleaseButton();

			byReceivingPage.verifyReleaseHoldsPopupHeading();

			byReceivingPage.clickedOnReasonExpandButton("Home Office Directed ");

			byReceivingPage.selectHomeOfficeDirectedOption();

			byReceivingPage.clickOnReleaseHoldOkButton();

			byReceivingPage.verifyResultPopupHeading();

			byReceivingPage.verifyHoldReleaseSuccessMessage();

			byReceivingPage.clickOnReleaseHoldOkButton();

			Failsafe.with(retryPolicy).run(() -> {
				Assert.assertEquals(ErrorCodes.CATALYST_HOLD_TAG_MISMATCH, false,
						byReceivingPage.elementPresentBasedOnExactText("Hold"));
				logger.info("Hold Tag is not avialable with LPN status: validated successfully!!");
			});
		}

		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving items", e);
		}
	}
	
}
