package com.walmart.supplychain.catalyst.by.ui.scenarioSteps;

import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.supplychain.catalyst.by.ui.steps.BYReceivingSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.catalyst.by.ui.steps.BYWorkQueueSteps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class BYWorkQueueScenarios {

	@Autowired
	BYReceivingSteps byReceivingSteps;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Steps
	BYWorkQueueSteps byWorkQueueSteps;
	
	@When("^user goes to Work Queue tab and search for \"([^\"]*)\" work and user changes work Status from \"([^\"]*)\" to \"([^\"]*)\"$")
	public void userNavigateToWorkQueueAndChangesWorkStatus(String workType, String earlierWorkStatus, String workStatusToBeChanged) throws InterruptedException {
		byWorkQueueSteps.changeWorkStatus(workType, earlierWorkStatus, workStatusToBeChanged);
	}
	
	@Then("^assign work to current user and change priority as \"([^\"]*)\"$")
	public void userAssignWorkToUserAndChangesPriority(String priority) throws InterruptedException {
		
		byWorkQueueSteps.assignWorkAndChangePriority(priority);
	}
}
