package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class ResolutionPage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20,10);//15 times with a delay of 10s
	boolean problemTicketDisplayed=false;
	
	@FindBy(xpath="//*[@id='mui-component-select-resolutionType']")
	private WebElement resolution_DropDownbox;
	
	@FindBy(xpath="//*[@id='totalCost']")
	private WebElement totalCostOfItem_Textbox;
	
	@FindBy(xpath="//*[@id='totalRetail']")
	private WebElement totalRetailOfItem_Textbox;
	
	@FindBy(xpath="//*[text()='Submit Resolution']")
	private WebElement submitResolution_Button	;
	
	@FindBy(xpath="//*[@id='wmra']")
	private WebElement wmra_Textbox;
	
	@FindBy(xpath="//*[@name='transferDc']")
	private WebElement dcToSend_Textbox;
	
	@FindBy(xpath="//*[@id='resolutionPo']")
	private WebElement newPONum_Textbox;
	
	@FindBy(xpath="//*[@id='resolutionPoLine']")
	private WebElement newPOLineNum_Textbox;
	
	@FindBy(xpath="//*[text()='Close Ticket']")
	private WebElement closeTicket_Textbox;
	
	@FindBy(xpath="//*[@class='summary-detail'][1]//div[2]")
	private WebElement resolutionName_Text;
	
	@FindBy(xpath="//*[@id='resolutionQuantity']")
	private WebElement qtyToReceive_Textbox;
	
	@FindBy(xpath="//*[text()='Close Ticket']")
	private WebElement closeTicket_Button;
	
	@FindBy(xpath=".//*[@value='SUPPLIER']")
	private WebElement whosFault_Supplier_RadioButton;
	
	@FindBy(xpath=".//*[@value='WALMART']")
	private WebElement whosFault_Internal_RadioButton;
	
	@FindBy(xpath="//*[@class='comment-div']//span")
	private WebElement minimizeComments;
	
	@FindBy(xpath="//*[@id='comment']")
	private WebElement comment_Textbox;
	
	@FindBy(xpath="//*[@id='menu-resolutionType']/div[3]/ul/li[5]")
	private WebElement destroy_Link;

	@FindBy(xpath="//*[@id=\"root\"]/div/section[2]/section/section/section[2]/section/div/section/div/div[2]/section/ul/li[1]/div/div[1]/input")
	private WebElement container_checkbox;

	@FindBy(xpath="//*[@id=\"root\"]/div/section[2]/section/section/section[2]/section/div/section/div/div[1]/section/div[1]/a")
	private WebElement select_All;

	@FindBy(xpath="//*[@class='container-body']/ul/li[1]/div/div[3]/div[2]")
	private WebElement dispositionName_Text;

	@FindBy(xpath="//*[@id=\"root\"]/div/section[2]/section/section/section[2]/section/div/section/div/div[1]/section/div[2]/button[1]/span[1]")
	private WebElement disposition_Button;

	@FindBy(xpath="//*[@id='select']")
	private WebElement disposition_DropDownbox;

	@FindBy(xpath="//*[@id=\"root\"]/div/section[2]/section/section/section[2]/section/div/section/div/div[1]/section/div[2]/section/section/section[2]/div[2]/div/input")
	private WebElement wmra_Number;

	@FindBy(xpath="//*[@id=\"root\"]/div/section[2]/section/section/section[2]/section/div/section/div/div[1]/section/div[2]/section/section/section[3]/button[2]")
	private WebElement disposition_Submit;

	@FindBy(xpath="//*[@class='MuiButtonBase-root MuiIconButton-root more']//*[@class='MuiIconButton-label']")
	private WebElement moreOptions_Button;

	@FindBy(xpath="/html/body/section/div/section[2]/section/section/section[2]/section/div/section/section/div[2]/button[2]")
	private WebElement editbutton;

	@FindBy(xpath="//button[@class='button expand edit-button filled']")
	private WebElement editticketdetails;


	@FindBy(xpath ="//button[@class='button expand save-button filled']")
	private WebElement save;

	@FindBy(id="remainingQty")
	private WebElement unresolvedqty;

	@FindBy(id ="ponumber")
	private WebElement ponumber;

	@FindBy(id ="upc")
	private WebElement upc;

	@FindBy(xpath ="//section[@class='actions'] //input[@type='text' and @class='text-input']")
	private WebElement bulk_comment;

	@FindBy(xpath ="//*[text()='Send']")
	private WebElement getBulk_comment_send;

	@FindBy(xpath="//*[text()='History']")
	private WebElement history_Button	;

	@FindBy(xpath="//*[@id='slot0']")
	private WebElement slotId	;
	
	TicketDetailPage ticketDetailPage;
	
	private void selectResolution() {
		element(resolution_DropDownbox).waitUntilVisible();
		element(resolution_DropDownbox).selectByValue("SALVAGE");
	}

	public void editResolution(){

		element(editbutton).waitUntilVisible();
		element(editbutton).click();

	}
//editing ticket details hardcode
	public void editTicket() throws InterruptedException {

		element(editticketdetails).waitUntilVisible();
		element(editticketdetails).click();
		element(unresolvedqty).clear();
		element(unresolvedqty).type("8");
		Thread.sleep(2000);
		element(ponumber).clear();
		element(ponumber).type("301");
		Thread.sleep(2000);
		element(upc).clear();
		element(upc).type("00405855287857");
		Thread.sleep(5000);
		element(save).waitUntilVisible();
		element(save).click();

	}

	public void editSlot(String slot) throws InterruptedException {

		element(editticketdetails).waitUntilVisible();
		element(editticketdetails).click();
		element(slotId).click();
		element(slotId).sendKeys((Keys.chord(Keys.CONTROL,"a", Keys.DELETE)));
		element(slotId).sendKeys(slot);
		element(save).waitUntilVisible();
		element(save).click();
		Thread.sleep(1000);
		Assert.assertEquals(ErrorCodes.FIXIT_TICKET_EDIT_FAILED, element(slotId).getText(),slot);
	}



	public void provideResolution(String resolutionName,String problemTicket,String WMRA,String totalCostOfItem,String totalRetailOfItem,String dcNumber,String qtyToReceive,
			String newPONum,String newPOLineNum,String market) throws InterruptedException {
		logger.info("Resolution name : {}", resolutionName);
		switch(resolutionName.trim()) {

		case "Other":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Other",getResolutionDropDownElements());
			submitOther("comments added for e2e testing");
			break;

		case "Salvage":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Salvage",getResolutionDropDownElements());
			submitSalvage(totalCostOfItem,totalRetailOfItem);
			break;

		case "Donate":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Donate",getResolutionDropDownElements());
			submitDonateNdDestroy(totalCostOfItem, totalRetailOfItem, WMRA, market);
			break;
			
		case "Destroy":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Destroy",getResolutionDropDownElements());
			if (market.equals("gdc")) {
				 submitResolutionWithComment("comments added by e2e", market);
			} else {
				submitDonateNdDestroy(totalCostOfItem, totalRetailOfItem, WMRA, market);
			}
			break;
			
		case "Transfer to another DC":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Transfer to another DC",getResolutionDropDownElements());
			submitTransaferToAnotherDC(dcNumber);
			break;
			
		case "Return To Vendor":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Return to vendor",getResolutionDropDownElements());
			submitGdcReturnToVendor(qtyToReceive,"test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test01234567890 test0123", market);
			break;
			
		case "Added a PO Line":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			Thread.sleep(3000);
			selectFromDropDown("Added a PO Line",getResolutionDropDownElements());
			Thread.sleep(2000);
			submitAddedPOLine(qtyToReceive, newPONum, newPOLineNum, market);
			/*if(problemTicket.toLowerCase().contains("wrp")) {
				submitReceiveAgainstOriginalLine(qtyToReceive, newPONum, newPOLineNum);
			}else {
				submitAddedPOLineAnotherPOOriginalLine(qtyToReceive, newPONum, newPOLineNum);
			}*/
			break;
			
		case "Receive Against Original Line":
			if(problemTicket.toLowerCase().contains("nop")) {
				ticketDetailPage.editPOline();
				getDriver().navigate().refresh();
			} 
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			Thread.sleep(2000);
			selectFromDropDown("Receive Against Original Line",getResolutionDropDownElements());
			submitAgainstOriginalLine(qtyToReceive, newPONum, newPOLineNum, market);
			/*if(problemTicket.toLowerCase().contains("nop")) {
				//submitReceiveAgainstOriginalLine(qtyToReceive, newPONum, newPOLineNum);
				submitAddedPOLineAnotherPOOriginalLine(qtyToReceive, newPONum, newPOLineNum);
			}else if(problemTicket.toLowerCase().contains("wrp")) {
				submitAddedPOLineAnotherPOOriginalLine(qtyToReceive, newPONum, "1");
			}else {
			submitReceiveAgainstOriginalLine(qtyToReceive, newPONum, newPOLineNum);
			}*/
			break;

		case "Receive Against Another PO":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Receive Against Another PO",getResolutionDropDownElements());
			submitReceiveAgainstAnotherPO(qtyToReceive,newPONum,newPOLineNum,market);
			break;

		case "Rework and Receive":
			element(resolution_DropDownbox).waitUntilVisible();
			element(resolution_DropDownbox).click();
			selectFromDropDown("Rework and Receive",getResolutionDropDownElements());
			submitReworkAndReceive("comments added for e2e testing");
			break;


			
		default: 
			logger.info("Resolution type not available...");
		}
		Thread.sleep(2000);
	}

	public void provideDispositionForDamage(String dispositionName,String WMRA) throws InterruptedException {
		logger.info("Disposition name : {}", dispositionName);
		element(container_checkbox).click();
		element(select_All).waitUntilVisible();
		element(select_All).click();
		element(disposition_Button).waitUntilClickable();
		element(disposition_Button).click();
		element(disposition_DropDownbox).waitUntilVisible();
		element(disposition_DropDownbox).click();
		switch(dispositionName.trim()) {
			case "Salvage":
				selectFromDropDown("Salvage",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Donate":
				selectFromDropDown("Donate",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Destroy":
				selectFromDropDown("Destroy",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Sent to reclaims":
				selectFromDropDown("Sent to reclaims",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Return To vendor":
				selectFromDropDown("Return to vendor",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Return to carrier":
				selectFromDropDown("Return to carrier",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Less Than a Case":
				selectFromDropDown("Less Than a Case",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			case "Recoup":
				selectFromDropDown("Recoup",getResolutionDropDownElements());
				element(wmra_Number).type(WMRA);
				element(disposition_Submit).click();
				break;

			default:
				logger.info("Disposition type not available...");
		}
		Thread.sleep(3000);
	}

	public void cancelContainersFromWeb(){
		logger.info("Cancel containers");
		element(container_checkbox).click();
		element(moreOptions_Button).waitUntilVisible();
		element(moreOptions_Button).click();
		selectFromDropDown("Cancel Containers",getResolutionDropDownElements());

	}

	private List<WebElement> getResolutionDropDownElements() {
		return getDriver().findElements(By.xpath("//*[@class='MuiList-root MuiMenu-list MuiList-padding']/li"));
	}
	
	private void selectFromDropDown(String strToSelect,List<WebElement> listOfElements) {
		List<WebElement> listOfWebElements = listOfElements;
		for (WebElement webElement : listOfWebElements) {
			String str=webElement.getText().trim();
			if (webElement.getText().trim().equalsIgnoreCase(strToSelect.trim())) {
				element(webElement).click();
				break;
			}
		}
	}
	
	private void submitSalvage(String totalCost,String totalRetail) {
		element(totalCostOfItem_Textbox).waitUntilVisible();
		element(totalCostOfItem_Textbox).type(totalCost);
		element(totalRetailOfItem_Textbox).waitUntilVisible();
		element(totalRetailOfItem_Textbox).type(totalRetail);
		Actions action=new Actions(getDriver());
		action.moveToElement(submitResolution_Button).click().build().perform();
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}
		
	private void submitDonateNdDestroy(String totalCost,String totalRetail,String wmra, String market) throws InterruptedException {
		Thread.sleep(5000);
		element(wmra_Textbox).waitUntilVisible();
		element(wmra_Textbox).type(wmra);
		element(totalCostOfItem_Textbox).waitUntilVisible();
		element(totalCostOfItem_Textbox).type(totalCost);
		element(totalRetailOfItem_Textbox).waitUntilVisible();
		element(totalRetailOfItem_Textbox).type(totalRetail);
		if(!market.equalsIgnoreCase("wfs") && !market.equalsIgnoreCase("imports"))
			click(whosFault_Supplier_RadioButton);
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}
	
	private void submitTransaferToAnotherDC(String dcNumber) {
		element(dcToSend_Textbox).waitUntilVisible();
		element(dcToSend_Textbox).type(dcNumber);
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}
	
	private void submitAgainstOriginalLine(String qty,String poNumber,String poLineNumber, String market) throws InterruptedException {
		Thread.sleep(5000);
		element(qtyToReceive_Textbox).waitUntilVisible();
		click(qtyToReceive_Textbox);
		element(qtyToReceive_Textbox).type(qty);
		/*element(newPOLineNum_Textbox).waitUntilVisible();
		element(newPOLineNum_Textbox).waitUntilClickable();
		element(newPOLineNum_Textbox).type(poLineNumber);*/
		if(!market.equalsIgnoreCase("wfs") && !market.equalsIgnoreCase("imports"))
			click(whosFault_Supplier_RadioButton);
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}
	
	private void submitAddedPOLine(String qty,String poNumber,String poLineNumber, String market) throws InterruptedException {
		//Thread.sleep(5000);
		element(qtyToReceive_Textbox).waitUntilVisible();
		click(qtyToReceive_Textbox);
		element(qtyToReceive_Textbox).type(qty);
		/*element(newPONum_Textbox).waitUntilVisible();
		element(newPONum_Textbox).type(poNumber);*/
		element(newPOLineNum_Textbox).waitUntilVisible();
		element(newPOLineNum_Textbox).type(poLineNumber);
		if(!market.equalsIgnoreCase("wfs") && !market.equalsIgnoreCase("imports"))
			click(whosFault_Supplier_RadioButton);
		click(submitResolution_Button);
	}

	private void submitReceiveAgainstAnotherPO(String qty,String poNumber,String poLineNumber, String market) throws InterruptedException {
		Thread.sleep(1000);
		element(qtyToReceive_Textbox).waitUntilVisible();
		click(qtyToReceive_Textbox);
		element(qtyToReceive_Textbox).type(qty);
		element(newPONum_Textbox).waitUntilVisible();
		element(newPONum_Textbox).type(poNumber);
		element(newPOLineNum_Textbox).waitUntilVisible();
		element(newPOLineNum_Textbox).type(poLineNumber);
		if(!market.equalsIgnoreCase("wfs") && !market.equalsIgnoreCase("imports"))
			click(whosFault_Supplier_RadioButton);
		click(submitResolution_Button);
	}


		
	public String getResolutionText() {
		element(resolutionName_Text).waitUntilVisible();
		return element(resolutionName_Text).getText();
	}

	public String getDispositionText() {
		element(dispositionName_Text).waitUntilVisible();
		return element(dispositionName_Text).getText();
	}
	
	public void clickCloseTicket() throws InterruptedException {
		click(closeTicket_Button);
		Thread.sleep(5000);
		//getDriver().close();
	}
	
	private void submitGdcReturnToVendor(String qty,String comments, String market) {
		element(comment_Textbox).waitUntilVisible();
		element(comment_Textbox).type(comments);
		if(!market.equalsIgnoreCase("wfs") && !market.equalsIgnoreCase("imports"))
			click(whosFault_Supplier_RadioButton);
		click(submitResolution_Button);
	}
	
	public void submitResolutionWithComment(String comment, String market) throws InterruptedException {
		Thread.sleep(2000);
		element(comment_Textbox).waitUntilVisible();
		element(comment_Textbox).type(comment);
		if(!market.equalsIgnoreCase("wfs") && !market.equalsIgnoreCase("imports"))
			click(whosFault_Supplier_RadioButton);
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}

	public void submitReworkAndReceive(String comment) throws InterruptedException {
		Thread.sleep(2000);
		element(comment_Textbox).waitUntilVisible();
		element(comment_Textbox).type(comment);
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}

	//newly added
	public void submitOther(String comment) throws InterruptedException {
		Thread.sleep(2000);
		element(comment_Textbox).waitUntilVisible();
		element(comment_Textbox).type(comment);
		element(submitResolution_Button).waitUntilVisible();
		element(submitResolution_Button).click();
	}


	public void addBulkResolution(String resolution,String wmra,String totalCostOfItem,String totalRetailOfItem,String market) throws InterruptedException {
		element(resolution_DropDownbox).waitUntilVisible();
		element(resolution_DropDownbox).click();
		selectFromDropDown(resolution,getResolutionDropDownElements());
		Thread.sleep(2000);
		if(market.equalsIgnoreCase(DC_TYPE.IMPORTS.getValue())) {
			element(whosFault_Supplier_RadioButton).waitUntilClickable();
			click(whosFault_Supplier_RadioButton);
		}
		submitDonateNdDestroy(totalCostOfItem, totalRetailOfItem, wmra, market);
	}

	//adding bulk comment
	public void addBulkComment() throws InterruptedException {
        element(bulk_comment).waitUntilVisible();
        element(bulk_comment).click();
        element(bulk_comment).clear();
		element(bulk_comment).sendKeys("bulk comment testing");
		element(getBulk_comment_send).waitUntilVisible();
        element(getBulk_comment_send).click();
	}

	public void verifyHistoryButton(){
		String market = Config.DC.getValue();
		Boolean isEnabled = !element(history_Button).getAttribute("class").contains("disabled");
		logger.info("Is history enabled : {} ", isEnabled);
		if(market.equalsIgnoreCase(DC_TYPE.RDC.getValue()) || market.equalsIgnoreCase(DC_TYPE.WFS.getValue())){
			Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_HISTORY_DATA_NOT_DISPLAYED, isEnabled);
		} else{
			Assert.assertFalse(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_HISTORY_DATA_NOT_DISPLAYED, isEnabled);
		}
	}

}
