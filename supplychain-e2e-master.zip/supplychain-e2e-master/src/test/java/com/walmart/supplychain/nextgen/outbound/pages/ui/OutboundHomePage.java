package com.walmart.supplychain.nextgen.outbound.pages.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.nextgen.outbound.steps.ui.OutboundHelper;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OutboundHomePage extends OutboundTableHelper {
	OutboundHelper outboundHelper = new OutboundHelper();
	Logger logger = LogManager.getLogger(this.getClass());
	@Autowired
	Environment environment;
	@FindBy(xpath = "//*[contains(@class,'md-dialog']")
	private WebElement spinner;

	@FindBy(css = "button[aria-label='documentButton']")
	private WebElement printDocuments;

	@FindBy(css = "button[aria-label='sealButton']")
	private WebElement sealLabel;

	@FindBy(css = "button[aria-label='printButton']")
	private WebElement printButton;

	@FindBy(css = "input[ng-model='destination.sealNbr']")
	private WebElement sealInput;

	@FindBy(id = "searchIcon")
	private WebElement searchIcon;

	@FindBy(css = "input[name='loadId']")
	private WebElement loadIdInput;

	@FindBy(xpath = "//p[text()='Container Visibility']")
	private WebElement containerVisibilityOption;

	@FindBy(xpath = "//input[@ng-model='vm.selectedContainerIds']")
	private WebElement containerIdTextField;

	@FindBy(id = "searchIcon")
	private WebElement searchIconinContainerVisibility;

	@FindBy(xpath = "(//table[@ng-model='selectedContainers'])[2]/tbody//td[4]")
	private WebElement containerStatus;

	public void waitForSpinner() {
		try {
			WebDriverWait wait = new WebDriverWait(getDriverInstance(), 5);
			logger.debug("wait for loader");
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.cssSelector("md-progress-circular[md-mode='indeterminate']")));
			logger.debug("found loader");
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.cssSelector("md-progress-circular[md-mode='indeterminate']")));
			logger.debug("loader disappeared");
		} catch (TimeoutException ex) {
			logger.info("Exceeded the timeout for loader.Proceeding");
		}
	}

	public void waitForFetchingLoadsCompletion() {
		try {
			sleep();
			String body = (String) executeScript("return document.documentElement.innerHTML;");
			logger.debug("Body Text:{}", body);
			int retryCount = 0;
			int maxRetry = 15;
			logger.info("Checking for Fetch Loads spinner");
			while (retryCount < maxRetry && body.contains("Fetching Loads")) {
				logger.info("Fetching Loads spinner is not yet disappeared");
				retryCount++;
				if (retryCount == maxRetry) {
					logger.info("spinner is not getting disappeared", retryCount);
					logger.info("Body Text:{}", body);
				}
				sleep();
				body = (String) executeScript("return document.documentElement.innerHTML;");
			}
			if(retryCount < maxRetry) {
				logger.info("Fetching Loads spinner is disappeared");
			}
		} catch (Exception ex) {
			logger.info("Unable to get body text");
		}
	}

	public void inputLoadNumber(String loadNo) {
		element(loadIdInput).waitUntilEnabled();
		waitForSpinner();
		element(loadIdInput).clear();
		logger.info("Entering load id {}", loadNo);
		waitForSpinner();
		element(loadIdInput).sendKeys(loadNo);

	}

	public void waitForOutboundLoadSearchInputTextBox() {
		element(loadIdInput).waitUntilVisible();
	}

	public void clickOnSearch() {
		waitFor(ExpectedConditions.elementToBeClickable(searchIcon));
		element(searchIcon).waitUntilVisible();
		element(searchIcon).click();
		waitForSpinner();
		waitForFetchingLoadsCompletion();

	}

	public void clickOnTrailerNum(String trailerNum) {
		logger.info("Verifying trailer number");
		WebElement trailerInfoRecord = element(
				By.xpath("//td[contains(@class, 'md-cell') and text() = '" + trailerNum + "']"));
		waitFor(ExpectedConditions.elementToBeClickable(trailerInfoRecord));
		element(trailerInfoRecord).waitUntilVisible();
		element(trailerInfoRecord).click();
		logger.info("Clicked on trailer number");
		waitForSpinner();
	}

	public void clickOnSealLabel() {
		waitFor(ExpectedConditions.elementToBeClickable(sealLabel));
		element(sealLabel).waitUntilVisible();
		element(sealLabel).click();

		waitForSpinner();
	}

	public void clickOnPrintDocuments() {
		waitFor(ExpectedConditions.elementToBeClickable(printDocuments));
		element(printDocuments).waitUntilVisible();
		element(printDocuments).click();

		waitForSpinner();
	}

	public void clickOnPrint() {
		waitFor(ExpectedConditions.elementToBeClickable(printButton));
		element(printButton).waitUntilVisible();
		element(printButton).click();

		waitForSpinner();
	}

	public String getSealDetails() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			logger.error(e);
		}
		waitFor(ExpectedConditions.visibilityOf(sealInput));
		element(sealInput).waitUntilVisible();
		String sealValue = element(sealInput).getValue();
		logger.info("Seal Value:" + sealValue);
		return sealValue;
	}

	public List<String> getLoadDetails() throws Exception {
		Map<String, String> data = getTableDataFirstRow();
		logger.info("Data from Table:" + data);
		List<String> dataList = new ArrayList<>();
		dataList.add(data.get("Load ID"));
		dataList.add(data.get("Door ID"));
		dataList.add(data.get("Trailer Number"));
		dataList.add(data.get("Destinations"));
		return dataList;
	}

	public String downloadBOLUsingUI() {
		waitForSpinner();
		List<WebElement> bolList = getDriverInstance().findElements(By.tagName("iframe"));
		String downloadUrl = element(bolList.get(0)).getAttribute("src");
		getDriverInstance().get(downloadUrl);
		waitForSpinner();
		return downloadUrl.substring(downloadUrl.lastIndexOf("/") + 1, downloadUrl.length()).concat(".pdf");
	}

	public String waitForPresenceOfFile(String pdfFileName) {
		return outboundHelper.getPDFFile(pdfFileName);
	}

	public List<String> getBOLDetails(String pdfPath) {
		Map<String, String> data = outboundHelper.processPDF(pdfPath);
		logger.info("Data from PDF:" + data);
		List<String> dataList = new ArrayList<>();
		dataList.add(data.get("TRANSPORTATION LOAD ID"));
		dataList.add(data.get("TRAILER"));
		dataList.add(data.get("OUTBOUND SEAL NO"));
		dataList.add(data.get("Destination#"));
		return dataList;
	}

}
