package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class YardManagementMoveQueuePage extends SerenityHelper {

	PropertyResolver propertyResolver = new PropertyResolver();
	YMSHelper ymsHelper = new YMSHelper();
	Logger logger = LogManager.getLogger(this.getClass());

	@FindBy(xpath = "//div[contains(text(),'Force')]")
	private WebElement forceOption;

	@FindBy(xpath = "//button[contains(text(),'Yes')]")
	private WebElement yesButton;

	@FindBy(xpath = "//a[@id='moveStatus']")
	private List<WebElement> moveStatusOption;
	
	@FindBy(xpath = "//div[@id='success']/ul/li")
	private WebElement successMessage;

	public String forceMove(String trailer) {
		String message="";
		String trailerXpath = "//tr[td[a[contains(text(),'" + trailer + "')]]]//input[@name='stsTxtBox']";
		String assignStatusXpath = "//tr[td[a[contains(text(),'" + trailer + "')]]]//a[contains(text(),' Assign')]";
		if (ymsHelper.isElementAvailable(assignStatusXpath)) {
			logger.info("Move is in Assign status.. No need to force");
			return "Move is in Assign status.. No need to force";
		}
		else {
			if (ymsHelper.isElementAvailable(trailerXpath)) {
				getDriverInstance().findElement(By.xpath(trailerXpath)).click();
					element(forceOption).click();
					ymsHelper.switchWindows(element(yesButton));
			}
			if(ymsHelper.isElementAvailable("//div[@id='success']/ul/li"))
				message=element(successMessage).getText().trim();
			logger.info(message);
			return message;
		}
	}

	public int getMovesPresentInAssignAndForceStatus() {
		String yardDriver = propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "yms_username");
		int assignMoveAndForceCount = getDriverInstance()
				.findElements(By.xpath("//td[a[contains(text(), 'Assign')] and //a[contains(text(), '" + yardDriver
						+ "')] or a[contains(text(),'Force')]]"))
				.size();
		logger.info("Count of moves present in Assign and Force status " + assignMoveAndForceCount);
		return assignMoveAndForceCount;
	}

}
