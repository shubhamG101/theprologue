package com.walmart.supplychain.nextgen.oms.gluecode.webservices;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.oms.scenariosteps.webservices.OmsSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class Oms {

	@Steps
	OmsSteps omsSteps;

	@Steps
	PreRunCleanup preRunCleanup;
	Logger logger = LogManager.getLogger(this.getClass());

	@Given("^User hits OMS for the \"([^\"]*)\" scenario for the \"([^\"]*)\"$")
	public void user_hits_OMS_for_the_po(String scenarioType, String poNumbers)
			throws JsonProcessingException, JSONException, ParseException {
		String ovgFlag = "false";

		logger.info("Called with parameters scenarioType :{} & poNumbers :{} ", scenarioType, poNumbers);
		omsSteps.userHitsOmsAndPopulatesPolineData(scenarioType, poNumbers, ovgFlag, "");
		preCleanup();

	}

	@Given("^User hits OMS for the \"([^\"]*)\" scenario for the \"([^\"]*)\" with \"([^\"]*)\"$")
	public void user_hits_OMS_for_the_po(String scenarioType, String poNumbers, String ovgFlag)
			throws JsonProcessingException, JSONException, ParseException {

		logger.info("Called with parameters scenarioType :{} & poNumbers :{} ", scenarioType, poNumbers);

		omsSteps.userHitsOmsAndPopulatesPolineData(scenarioType, poNumbers, ovgFlag, "");
		preCleanup();

	}

	@Given("^User hits OMS for the \"([^\"]*)\" scenario for the \"([^\"]*)\" with channel flip \"([^\"]*)\"$")
	public void user_hits_OMS_for_the_po_with_channel_flip(String scenarioType, String poNumbers, String channelFlipVal)
			throws JsonProcessingException, JSONException, ParseException {

		logger.info("Called with parameters scenarioType :{} & poNumbers :{} ", scenarioType, poNumbers);

		omsSteps.userHitsOmsAndPopulatesPolineData(scenarioType, poNumbers, "false", channelFlipVal);
		preCleanup();

	}
	
	@And("^cleanup data from OT for item which will be added as new line \"([^\"]*)\"$")
	public void cleanUpOTForItemtobeAddedAsNewLine(String itemNum) {
		preRunCleanup.cleanUpOTAtlasForAddedLine(itemNum);
	}

	@Given("^User mocks the RDS data for the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void userMockRdsData(String itemNumber, String poType)
	{
		logger.info("Called with parameters itemNumber :{} ", itemNumber);
		preRunCleanup.mockRDS(itemNumber, poType);
	}

	@Given("^PO details are \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void mockOMSPO(String poNumber, String itemNumber, String vnpkQty, String whpkQty, String orderQty, String whpkSellCost, String chnlMthd, String poType, String dcNbr)
	{
		omsSteps.mockPO(poNumber, itemNumber, vnpkQty, whpkQty, orderQty, whpkSellCost, chnlMthd, poType, dcNbr);
	}

	public void preCleanup() {
		if (Config.DC == DC_TYPE.ATLAS||Config.DC==DC_TYPE.SAMS) {
			preRunCleanup.cleanupReceivingAtlas();
			preRunCleanup.cleanUpOf();
			preRunCleanup.cleanUpGDM();
			preRunCleanup.cleanUpGDMByItem();
			preRunCleanup.cleanUpOPAtlas();
			preRunCleanup.cleanUpOTAtlas();
 			preRunCleanup.cleanDCfin();
		} else if (Config.DC == DC_TYPE.MCC) {
			preRunCleanup.cleanupReceiving();
			preRunCleanup.cleanupOf();
			preRunCleanup.cleanUpGDM();
			preRunCleanup.cleanUpOPAtlas();
		} else if (Config.DC==DC_TYPE.WITRON){
			preRunCleanup.cleanupReceivingAtlas();
			//preRunCleanup.cleanUpWitronInventory();
		}else if (Config.DC==DC_TYPE.PHARMACY){
			preRunCleanup.cleanupReceivingAtlas();
			preRunCleanup.cleanUpGDM();
			preRunCleanup.cleanRDS();
			preRunCleanup.cleanSmartSlottingDB();
		}
		else if (Config.DC==DC_TYPE.ACC) { // This block will be called for ACC
			preRunCleanup.cleanUpOPAtlas();
			preRunCleanup.cleanUpGDM();
			//preRunCleanup.cleanUpOP();
			preRunCleanup.cleanupReceivingAtlas();
			preRunCleanup.cleanUpOf();
			preRunCleanup.cleanupMCB();
			preRunCleanup.cleanUpGDMByItem();
			preRunCleanup.cleanUpOTAtlas();
			preRunCleanup.cleanDCfin();
		}
	}
}
