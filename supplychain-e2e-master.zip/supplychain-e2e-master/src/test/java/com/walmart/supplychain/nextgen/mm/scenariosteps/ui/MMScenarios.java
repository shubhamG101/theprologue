package com.walmart.supplychain.nextgen.mm.scenariosteps.ui;

import com.walmart.supplychain.nextgen.mm.steps.ui.MMSteps;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class MMScenarios {

	@Steps
	MMSteps mmSteps;
	
//	@Then("^user verifies the Move is created and completed in MM$")
//	public void user_verifies_the_Move_is_created_and_completed_in_MM() {
//		mmSteps.open_MM_home_page();
//		mmSteps.login_to_MM();
//	
//	
//	}
	
	@Then("^user verifies the Move is created in MM$")
	public void user_verifies_the_Move_is_created_in_MM() {
		mmSteps.open_MM_home_page_Witron();
		mmSteps.login_to_MM_Witron();
}
	
	@Then("^user verifies the Move is created in MM for received container \"([^\"]*)\"$")
	public void user_verifies_the_Move_is_created_in_MM_for_received_container(String typeValue) {
		mmSteps.validateOhHoldContainer(typeValue);
	
	}
	@Then("^user verifies the Move is created in MM for hold container \"([^\"]*)\"$")
	public void user_verifies_the_Move_is_created_in_MM_for_hold_container(String typeValue) {
		mmSteps.validateOhHoldContainer(typeValue);
	
	}
	@Then("^user verifies the Move is created with status as \"([^\"]*)\" in MM$")
	public void user_verifies_the_move_status(String moveStatus) throws Exception {
		mmSteps.validate_move_status( moveStatus,"D1");
	}

}
