package com.walmart.supplychain.rdc.gdm.steps.webservices;

import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.rdc.ASNDetail;
import com.walmart.framework.supplychain.domain.rdc.ASNItemDetails;
import com.walmart.framework.supplychain.domain.rdc.ASNPackDetails;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.witronutilities.WitronUtil;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.witron.gdm.Pages.GDMLoginPage;
import com.walmart.supplychain.witron.gdm.Pages.GDMUnifiedHomePage;
import com.walmart.supplychain.witron.gdm.Pages.GDMUnifiedLoginPage;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class RDCGdmSteps {

	@Autowired
	RdcGDMHelper rdcGDMHelper;

	@Autowired
	Environment environment;

	@Autowired
	GDMUnifiedLoginPage gdmUnifiedLoginPage;

	@Autowired
	Environment endpoint;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	GDMUnifiedHomePage gdmUnifiedHomePage;

	@Autowired
	RDCUtil rdcUtil;

	@Autowired
	DbUtils dbUtils;

	Response response;

	@Autowired
	PreRunCleanup preRunCleanup;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	private static final String QUEUE = "queue";
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 5);

	ObjectMapper om = new ObjectMapper();

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String SHIPMENT_SET_JSON_PATH = "$.testFlowData.deliveryDetailsRDC[*].shipments";
	private static final String SHIPMENT_CONTAINERS_GET_JSON_PATH = "$..containerLabel";
	private static final String SHIPMENT_CONTAINERS_SET_JSON_PATH = "$.testFlowData.deliveryDetailsRDC[*].containersOnShipment";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String DELIVERY_ARV_STATUS = "ARV";
	private static final String DELIVERY_ARV_STATUS_UI = "Arrived";
	String testFlowData;
	private static final String GET_DOOR_NBR = "$.testFlowData.deliveryDetails[*].inboundDoorNumber";
	private static final String GET_DELIVERY = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private static final String GET_INBOUND_LOAD_NBR = "$.testFlowData.deliveryDetails[*].inboundLoadNumber";
	private static final String GET_DELIVERY_DOOR_NBR = "$.doorNumber";
	private static final String GET_DELIVERY_TRAILER_NBR = "$.trailerId";
	private static final String PO_COUNT = "$.testFlowData.poDetails[*].poNumber";
	private static final String PO_LINE_COUNT = "$.testFlowData.poDetails[*].poLineDetails[*].poLineNumber";
	private static final String TOTAL_QUANTITY = "$.testFlowData.poDetails[*].poLineDetails[*].poVnpkQty";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";

	@Step
	public void createMultiShipment(String noOfShipments, String loadNumber, String numOfpacksOnShipmentForEachPOLine,
			String receivingType) {
		try {
			if (receivingType.equalsIgnoreCase("Offline")) {
				testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
				List<String> shipmentList = new ArrayList<String>();
				for (int i = 1; i <= Integer.parseInt(noOfShipments); i++) {
					String shipmentData = rdcGDMHelper.prepareShipmentData(numOfpacksOnShipmentForEachPOLine,
							loadNumber);

					List<String> containersOnASNList = JsonPath.parse(shipmentData)
							.read(SHIPMENT_CONTAINERS_GET_JSON_PATH);
					logger.info("Shipment Data: " + shipmentData);
					String createShipmentUrl = environment.getProperty("rdc_idm_shipment_creation_ep");
					logger.info("Create Shipment Url: " + createShipmentUrl);
					Thread.sleep(5000);

					Response createShipmentResponse = SerenityRest.given().body(shipmentData)
							.contentType("application/json").when().post(createShipmentUrl);
					// Assert.assertEquals(ErrorCodes.RDC_UNABLE_CREATE_SHIPMENT,
					// Constants.SUCESS_STATUS_CODE,
					// createShipmentResponse.getStatusCode());
					logger.info("Shipment Created successfully");

					String testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowData, shipmentList,
							SHIPMENT_SET_JSON_PATH);
					testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowDataUpdated, containersOnASNList,
							SHIPMENT_CONTAINERS_SET_JSON_PATH);
					threadLocal.get().put(TEST_FLOW_DATA, testFlowDataUpdated);
					logger.info("TestFlowData after updating Shipment number and Containers : {}",
							String.valueOf(threadLocal.get().get(TEST_FLOW_DATA)));
				}

			}

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating ASN for RDC", e);
		}
	}

	@Step
	public void precleanup(String flowType) {
		try {
			String rdsdeleteQuery = null;
			// List<Map<String, Object>> allocOrders = dbUtils.selectFrom(PRODUCT_NAME.RDS,
			// environment.getProperty("rds_receiver_query"), "009784587537");
			// logger.info(allocOrders);
			if (flowType.equals("osdr")) {
				rdsdeleteQuery = environment.getProperty("rds_osdr_delete_query");
			}

			preRunCleanup.cleanUpRDS(rdsdeleteQuery);
		} catch (Exception e) {

		}
	}

	@Step
	public void insertInRDS(String flowType) {
		try {
			String rdsInsertQuery = null;
			if (flowType.equals("osdr")) {
				rdsInsertQuery = environment.getProperty("rds_osdr_insert_query");
			}

			preRunCleanup.cleanUpRDS(rdsInsertQuery);
		} catch (Exception e) {

		}
	}

	@Step
	public void validateDeliveryInGDM(String deliveryNum) {
		try {

			TestFlowDataMain root = new TestFlowDataMain();
			TestFlowData testFlowData = new TestFlowData();
			List<PoDetail> poList = new ArrayList<PoDetail>();
			List<DeliveryDetail> deliveryList = new ArrayList<DeliveryDetail>();
			Reader reader = null;
			rdcUtil.validateRDCDeliveryStatus(deliveryNum, DELIVERY_ARV_STATUS);
			String deliveryresponse = rdcUtil.getrdcDelivery(deliveryNum);

			DocumentContext parsedtestflowJson = JsonPath.parse(deliveryresponse);
			List<String> deliveryDoorList = parsedtestflowJson.read(GET_DELIVERY_DOOR_NBR);
			List<String> deliveryTrailerList = parsedtestflowJson.read(GET_DELIVERY_TRAILER_NBR);

			net.minidev.json.JSONObject deliveryDocument = jsonUtil.convertStringToMinidevJsonObject(deliveryresponse);
			String sourceDC = (String) deliveryDocument.get("dcNumber");
			String countryCode = (String) deliveryDocument.get("countryCode");
			net.minidev.json.JSONArray listofPOArray = (JSONArray) deliveryDocument.get("deliveryDocuments");
			for (int i = 0; i < listofPOArray.size(); i++) {
				String channelMethod = "";
				List<PoLineDetail> poLineList = new ArrayList<PoLineDetail>();
				net.minidev.json.JSONObject poDocument = (JSONObject) listofPOArray.get(i);
				logger.info(poDocument.get("purchaseReferenceNumber"));
				PoDetail poDetail = new PoDetail();
				poDetail.setPoNumber(poDocument.get("purchaseReferenceNumber").toString());
				poDetail.setPoStatus(poDocument.get("purchaseReferenceStatus").toString());
				poDetail.setPoStatus(poDocument.get("vendorNumber").toString());
				poDetail.setSourceNumber(sourceDC);
				poDetail.setSrcCountryCode(countryCode);
				poDetail.setBaseDiv(poDocument.get("baseDivCode").toString());

				net.minidev.json.JSONArray listofPOLineArray = (JSONArray) poDocument.get("deliveryDocumentLines");
				for (int j = 0; j < listofPOLineArray.size(); j++) {
					net.minidev.json.JSONObject poLineDocument = (JSONObject) listofPOLineArray.get(i);
					PoLineDetail lineDetail = new PoLineDetail();
					lineDetail.setPoLineNumber(poLineDocument.get("purchaseReferenceLineNumber").toString());
					channelMethod = poLineDocument.get("originalChannel").toString();
					lineDetail.setCaseUpc(poLineDocument.get("caseUPC").toString());
					lineDetail.setItemUpc(poLineDocument.get("itemUPC").toString());
					lineDetail.setItemNumber(poLineDocument.get("itemNbr").toString());
					lineDetail.setPoVnpkQty(poLineDocument.get("expectedQty").toString());
					lineDetail.setOvgQty(poLineDocument.get("overageThresholdQty").toString());
					lineDetail.setTi(poLineDocument.get("palletTi").toString());
					lineDetail.setHi(poLineDocument.get("palletHi").toString());
					lineDetail.setChannelMethod(poLineDocument.get("purchaseRefType").toString());
					lineDetail.setVnpk(poLineDocument.get("vnpkQty").toString());
					lineDetail.setWhpk(poLineDocument.get("whpkQty").toString());
					lineDetail.setWhpkSellPrice(poLineDocument.get("vendorPackCost").toString());
					lineDetail.setDepartmentNumber(poLineDocument.get("department").toString());
					lineDetail.setIsConveyable(poLineDocument.get("isConveyable").toString());
					poLineList.add(lineDetail);
				}
				poDetail.setChannelMethod(channelMethod);
				poDetail.setPoLineDetails(poLineList);
				poList.add(poDetail);
			}
			List<String> poNumList = new ArrayList<String>();

			for (int m = 0; m < poList.size(); m++) {
				poNumList.add(poList.get(m).getPoNumber());
			}

			DeliveryDetail deliveryDetail = new DeliveryDetail();
			deliveryDetail.setDeliveryName("D1");
			deliveryDetail.setDeliveryNumber(deliveryNum);
			deliveryDetail.setInboundDoorNumber(deliveryDoorList.get(0));
			deliveryDetail.setInboundTrailerNumber(deliveryTrailerList.get(0));
			deliveryDetail.setPoNumbers(poNumList);
			deliveryDetail.setDeliveryStatus(DELIVERY_ARV_STATUS);
			deliveryList.add(deliveryDetail);

			testFlowData.setDeliveryDetails(deliveryList);
			testFlowData.setPoDetails(poList);
			root.setTestFlowData(testFlowData);
			tl.get().put(TEST_FLOW_DATA, om.writeValueAsString(root));
			logger.info("testFlowdata:" + tl.get().get(TEST_FLOW_DATA));
			reader.close();

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_POPULATE_TESTFLOWDATA, e);
		}
	}

	public void openGDMUI() {
		logger.info("Launching GDM url");
		gdmUnifiedLoginPage.openGDMUI();
	}

	@Step
	public void validateGDMUI() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			openGDMUI();
			gdmUnifiedHomePage.searchDelivery(deliveryNum);

			List<String> deliveryDoorList = parsedtestflowJson.read(GET_DOOR_NBR);
			List<String> poList = parsedtestflowJson.read(PO_COUNT);
			List<String> poLineList = parsedtestflowJson.read(PO_LINE_COUNT);
			List<String> totalQtyList = parsedtestflowJson.read(TOTAL_QUANTITY);
			int totalQty = 0;
			for (String qty : totalQtyList) {
				totalQty += Integer.parseInt(qty);
			}

			String deliverystatusUI = gdmUnifiedHomePage.getDeliveryStatus();
			String doorNumUI = gdmUnifiedHomePage.getdoorNumber();
			String poCountUI = gdmUnifiedHomePage.getpoCount();
			String poLineCountUI = gdmUnifiedHomePage.getpoLineCount();
			String totalQtyUI = gdmUnifiedHomePage.getTotalQuantity();
			gdmUnifiedHomePage.closeDriver();

			Assert.assertEquals(ErrorCodes.RDC_GDM_UI_DELIVERY_STATUS_MISMATCH, deliverystatusUI,
					DELIVERY_ARV_STATUS_UI);
			Assert.assertEquals(ErrorCodes.RDC_GDM_UI_DOOR_NBR_MISMATCH, deliveryDoorList.get(0), doorNumUI);
			Assert.assertEquals(ErrorCodes.RDC_GDM_UI_PO_COUNT_MISMATCH, String.valueOf(poList.size()), poCountUI);
			Assert.assertEquals(ErrorCodes.RDC_GDM_UI_PO_LINE_COUNT_MISMATCH, String.valueOf(poLineList.size()),
					poLineCountUI);
			Assert.assertEquals(ErrorCodes.RDC_GDM_UI_TOTAL_QUANTITY_MISMATCH, totalQty, Integer.parseInt(totalQtyUI));

		} catch (Exception e) {
			gdmUnifiedHomePage.closeDriver();
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_GDM_UI, e);
		}
	}

	@Step
	public void validateDeliveryStatus(String deliveryStatus) {

		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);
			rdcUtil.validateRDCDeliveryStatus(deliveryNum, deliveryStatus);
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_DELIVERY_STATUS, e);
		}

	}

	@Step
	public void createASNInGDM() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			List<String> inboundLoadList = parsedtestflowJson.read(GET_INBOUND_LOAD_NBR);

			List<ASNItemDetails> asnItemDetailsList = new ArrayList<ASNItemDetails>();
			List<ASNPackDetails> asnIPackList = new ArrayList<ASNPackDetails>();
			for (PoDetail poDetail : poList) {
				List<PoLineDetail> lineDetailList = poDetail.getPoLineDetails();
				for (PoLineDetail lineDetail : lineDetailList) {
					ASNItemDetails itemDetail = new ASNItemDetails();
					itemDetail.setDepartmentNumber(lineDetail.getDepartmentNumber());
					itemDetail.setPoNumber(poDetail.getPoNumber());
					itemDetail.setPoLineNumber(lineDetail.getPoLineNumber());
					itemDetail.setOrderNumber(UUID.randomUUID().toString());
					itemDetail.setGtin(lineDetail.getItemUpc());
					itemDetail.setItemNumber(lineDetail.getItemNumber());
					itemDetail.setFinancialReportingCode(environment.getProperty("country_code"));
					itemDetail.setBaseDivCode("WM");
					int qtyInEaches = Integer.parseInt(lineDetail.getPoVnpkQty())
							* Integer.parseInt(lineDetail.getVnpk());
					itemDetail.setQuantity(qtyInEaches);
					itemDetail.setQuantityUOM("EA");
					itemDetail.setVendorPackQty(Integer.parseInt(lineDetail.getVnpk()));
					itemDetail.setWarehousePackQty(Integer.parseInt(lineDetail.getWhpk()));
					itemDetail.setWarehousePackSell(Double.parseDouble(lineDetail.getWhpkSellPrice()));
					itemDetail.setCurrency("USD");
					asnItemDetailsList.add(itemDetail);

				}
			}

			ASNPackDetails asnPackDetails = new ASNPackDetails();
			asnPackDetails.setPackNumber("US" + javaUtil.randonNumberGenerator(9) + javaUtil.randonNumberGenerator(9)
					+ javaUtil.randonNumberGenerator(5));
			asnPackDetails.setDestinationCountry(environment.getProperty("country_code"));
			asnPackDetails.setDestinationNumber(environment.getProperty("facility_num"));
			asnPackDetails.setDestinationType("DC");
			asnPackDetails.setChannelMethod("CROSSU");
			asnPackDetails.setInvoiceNumber(String.valueOf(javaUtil.randonNumberGenerator(9))
					+ String.valueOf(javaUtil.randonNumberGenerator(2)));
			asnPackDetails.setItems(asnItemDetailsList);
			asnIPackList.add(asnPackDetails);

			ASNDetail asnDetail = new ASNDetail();
			asnDetail.setDestinationNumber(environment.getProperty("facility_num"));
			asnDetail.setDestinationCountry(environment.getProperty("country_code"));
			asnDetail.setDestinationType("DC");
			asnDetail.setSourceNumber("32898");
			asnDetail.setSourceCountry(environment.getProperty("country_code"));
			asnDetail.setSourceType("MCC");
			asnDetail.setAsnId(String.valueOf(String.valueOf(javaUtil.randonNumberGenerator(9))
					+ String.valueOf(javaUtil.randonNumberGenerator(4))));

			Date currDate = new Date();
			System.out.println(currDate);
			DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
			String dateUrlStr = desturl.format(currDate);

			asnDetail.setAsnDate(dateUrlStr);
			asnDetail.setCarrierId("SWFC");
			asnDetail.setShipperName("SWFC");
			asnDetail.setShipDate(dateUrlStr + "T00:00:00");
			asnDetail.setLoadNumber(inboundLoadList.get(0));
			asnDetail.setTrailerSealNumber("64115127");
			asnDetail.setBillOfLadingNumber("32899-" + javaUtil.randonNumberGenerator(7));
			asnDetail.setTrailerNumber("945289");
			asnDetail.setPacks(asnIPackList);

			logger.info("asn payload:" + om.writeValueAsString(asnDetail));
			String asnPayload = om.writeValueAsString(asnDetail);

			synchronized (stratiConnectionUtil) {
				stratiConnectionUtil.publishStartiMessage(environment.getProperty("asn_queue"), asnPayload, QUEUE,
						environment.getProperty("qa_connection_factory"), environment.getProperty("qa_strati_username"),
						environment.getProperty("adjustments_strati"), "createasn");
			}
			Thread.sleep(3000);
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_CREATE_ASN, e);
		}
	}
	
	@Step
	public void validateGDMstausAndLegacyStatus(String status, String legacyStatus) {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);
			Failsafe.with(retryPolicy).run(() -> {
				String deliveryresponse = rdcUtil.getrdcDelivery(deliveryNum);
				DocumentContext parseddeliveryResponseJson = JsonPath.parse(deliveryresponse);

				String deliveryStatus = parseddeliveryResponseJson.read("$.deliveryStatus");
				String deliveryLegacyStatus = parseddeliveryResponseJson.read("$.deliveryLegacyStatus");
				Assert.assertEquals(ErrorCodes.RDC_GDM_DELIVERY_STATUS_MISMATCH, status, deliveryStatus);
				Assert.assertEquals(ErrorCodes.RDC_GDM_DELIVERY_LEGACY_STATUS_MISMATCH, legacyStatus,
						deliveryLegacyStatus);
			});
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_GDM_DELIVERY_STATUS_MISMATCH, e);
		}
	}
}
