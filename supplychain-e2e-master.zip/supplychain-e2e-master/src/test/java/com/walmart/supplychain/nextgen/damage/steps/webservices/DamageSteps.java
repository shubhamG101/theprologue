package com.walmart.supplychain.nextgen.damage.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class DamageSteps {

	private TextParser textParser;
	private Response response;
	private int countOfDamageContainers;
	private static final String INVENTORY_SEARCH_ENDPOINT_KEY = "inventory_search_ep";
	private static final String INVENTORY_QUERYPARAM_KEY = "inventory_ep_qp";
//	private String testData;
	private DocumentContext parsedJson;
	private List<String> poNumberList;

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	@Steps
	InventorySteps inventorySteps;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	Environment environment;

	@Autowired
	JsonUtils jsonUtil;

//	public void filepreReceivingDamage() {
//		try {
//			response = given().relaxedHTTPSValidation().body(createDamagePayLoad().toString())
//					.headers(getDamageHeaders()).when().post((environment.getProperty("pre_receiving_damage")));
//
//			logger.info("Waiting for Status 200 for pre receiving Damage}");
//			Assert.assertEquals(ErrorCodes.UNABLE_TO_FILEDAMAGE, Constants.CREATE_SUCESS_STATUS_CODE,
//					response.getStatusCode());
//
//			logger.info("Response from Damage API Is " + response.getBody().asString());
//
//			JSONArray cntrList = JsonPath.read(response.getBody().asString(), "$.damageContainers[*]");
//			if (cntrList.isEmpty()) {
//				Assert.assertTrue(ErrorCodes.UNABLE_TO_FILEDAMAGE, false);
//			}
//
//		} catch (URISyntaxException | IOException | JSONException e) {
//			throw new AutomationFailure("Something went wrong while validating/getting damage response", e);
//		}
//	}

	public void filepreReceivingDamage() {
		try {
			String createLoadMessage;
			String testFlowData;
			textParser = new TextParser();
			
			
//			threadLocal.get().put("testFlowData",
//					"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"077365376\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020010688\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"062246c1-9b3b-4054-a2b3-756fd00aa310\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-08\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"200\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 200, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"16.4\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020019025\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"e5eb6bf6-f193-4693-a403-729e7605679f\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-08\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"100\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"10\", \"shortQty\": \"60\", \"rejectQty\": \"30\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 100, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"3\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"200\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"notBOL\", \"recvQty\": 0, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"4\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020010685\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"09bc0e76-98d9-474c-83dd-273b328864c4\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-08\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"100\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"20\", \"shortQty\": \"80\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 100, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"5\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"200\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"croReject\", \"recvQty\": 0, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"6\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"200\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 0, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"7\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020019022\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"d614d7de-f775-4939-b315-98fcf030f4bc\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-09-08\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"210\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"200\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 210, \"osdrInd\": \"o\"}, {\"poLineNumber\": \"8\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"200\", \"rejectQty\": \"200\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 0, \"osdrInd\": \"s\"} ], \"uuid\": [\"b7eb8e07-3920-44ce-87c5-7c9f1d7d13f8\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"115\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T13694519\", \"poNumbers\": [\"077365376\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"13694519\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before receiving damage start : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);
			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			for (String poNumber : poNumberList) {
				String itemNum;
				String itemUpc;

				int damageQty=0;

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {

					if (Config.DC==DC_TYPE.ACC) {
						List<String> poQty = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
								+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].poVnpkQty");
						damageQty= Integer.valueOf(poQty.get(0))==1 ? 1 : Integer.valueOf(poQty.get(0))-1;
					}
					else {
						List<String> damageQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
								+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].damageQty");

						damageQty = Integer.parseInt(damageQtyList.get(0).toString());
						logger.info("Damage qty and Po Line Number {} {} " + damageQty , poLineNumber);
					}


					if (damageQty != 0) {

						List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemNumber");
						itemNum = itemList.get(0).toString();

						List<String> itemUpcList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
								+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemUpc");
						itemUpc = itemUpcList.get(0).toString();
						
						logger.info("Item UPC and Number {} {} " + itemUpc , itemNum);


						createLoadMessage = textParser.readTextFile(FileNames.PRE_RECEIVING_DAMAGE);
						JSONObject obj = new JSONObject(createLoadMessage);

						// int damageQty = getCountOfDamageContainers(obj);
						
						obj.put("quantitySentToReclaim", damageQty);


						// Get PO Number
						obj.getJSONObject("delRequest").put("poNumber", poNumber);

						// Get deliveryNumber
						JSONArray delList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[*].deliveryNumber");
						obj.getJSONObject("delRequest").put("deliveryNumber", delList.get(0));

						// Get deliveryNumber

						obj.getJSONObject("delRequest").put("poLineNumber", poLineNumber);

						// Get itemDetails
						obj.getJSONArray("items").getJSONObject(0).put("itemNumber", itemNum);

						// Get upcDetails
						obj.getJSONArray("items").getJSONObject(0).put("upc", itemUpc);

						logger.info("Damage payload is " + obj.toString());

						Failsafe.with(retryPolicy).run(() -> {
						response = given().relaxedHTTPSValidation().body(obj.toString()).headers(getDamageHeaders())
								.when().post((environment.getProperty("pre_receiving_damage")));
						logger.info("Waiting for Status 200 for pre receiving Damage}");
						Assert.assertEquals(ErrorCodes.UNABLE_TO_FILEDAMAGE, Constants.CREATE_SUCESS_STATUS_CODE,
								response.getStatusCode());
						});
						logger.info("Response from Damage API Is " + response.getBody().asString());

						List<String> cntrList = JsonPath.read(response.getBody().asString(), "$.damageContainers[*]");
						Assert.assertFalse(ErrorCodes.UNABLE_TO_FILEDAMAGE, cntrList.isEmpty());

						if (Config.DC==DC_TYPE.ACC) {
							JSONArray instructJSONArry;

							ObjectMapper objectMapper = new ObjectMapper();
							net.minidev.json.JSONArray listOfPoLineDetail = JsonPath.read(testFlowData,
									"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[*]");
							String poLineDetailsJson = objectMapper.writeValueAsString(listOfPoLineDetail);
							List<PoLineDetail> poLineDetailList = (List<PoLineDetail>) jsonUtil
									.getPojoListfromPath(poLineDetailsJson, PoLineDetail.class);
							for (PoLineDetail poLineDetail : poLineDetailList) {
								if (poLineDetail.getPoLineNumber().equals(poLineNumber)) {
									poLineDetail.setDamageQty(String.valueOf(damageQty).trim());
								}
							}
							net.minidev.json.JSONArray listofPoLineJson = jsonUtil.converyListToJsonArray(poLineDetailList);
							testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofPoLineJson,
									"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails");
							threadLocal.get().put("testFlowData", testFlowData);
							
							logger.info("Testflowdata after upadting Pre-damge quantity {} ", testFlowData);
						}
					}
				}
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting damage response", e);
		}

	}

	private int getCountOfDamageContainers(JSONObject object) throws JSONException {
		countOfDamageContainers = object.getInt("quantitySentToReclaim") + object.getInt("quantitySentToCarrier");
		logger.info("Count of Damaged Containers " + countOfDamageContainers);
		return countOfDamageContainers;
	}

	private Headers getDamageHeaders() {

		Header countryCode = new Header("countryCode", "us");
		Header siteNumber = new Header("siteNumber", environment.getProperty("facility_num"));
		Header wmtCorrelationId = new Header("WMT-CorrelationId", "fghgfhjghjghjghjgj");
		Header contentType = new Header("Content-Type", "application/json");

		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(siteNumber);
		headerList.add(wmtCorrelationId);
		headerList.add(contentType);

		logger.info("Header to be added to the request are " + headerList.toString());
		return new Headers(headerList);
	}

	public void validateDamageCntrInventory() {

		logger.info("response while filing damages is " + response.getBody().asString());
		try {
			// Get Damage container details
			logger.info("Response:{}", response.getBody().asString());
			JSONArray cntrList = JsonPath.read(response.getBody().asString(), "$.damageContainers[*]");
			logger.info("Expected container list:{}", cntrList.size());
			logger.info("Actual container list:{}", countOfDamageContainers);
			Assert.assertEquals(ErrorCodes.DAMAGE_CONTAINERS_COUNT_INCORRECT, cntrList.size(), countOfDamageContainers);

			Failsafe.with(retryPolicy).run(() -> {
				for (int i = 0; i < cntrList.size(); i++) {
					response = when().get(environment.getProperty(INVENTORY_SEARCH_ENDPOINT_KEY) + cntrList.get(i)
							+ environment.getProperty(INVENTORY_QUERYPARAM_KEY));
					Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_STATUS, 200, response.getStatusCode());
					logger.info("Response status code is " + response.getStatusCode());
					logger.info("Response message is " + response.getBody().asString());
					logger.info("Waiting for validating container Status for Container Id:{}", cntrList.get(i));
					Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_STATUS,
							inventorySteps.parseContainerStatus(response), "DAMAGE");
					logger.info("Validated the container status for  " + cntrList.get(i) + " in Inventory");
				}
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating/getting container status", e);
		}
	}
}
