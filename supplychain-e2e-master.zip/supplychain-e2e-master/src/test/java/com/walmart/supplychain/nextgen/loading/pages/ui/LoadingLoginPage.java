package com.walmart.supplychain.nextgen.loading.pages.ui;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.thucydides.core.pages.PageObject;

public class LoadingLoginPage extends SerenityHelper {

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	@FindBy(xpath = "//input[@ng-model='user.userId']")
	private WebElement userIdField;

	@FindBy(xpath = "//input[@ng-model='user.password']")
	private WebElement passwordField;

	@FindBy(xpath = "//md-select[@ng-model='user.domainName']")
	private WebElement selectDomainField;

	@FindBy(xpath = "//md-select-menu[@role='presentation']//div[contains(text(),'local')]")
	private WebElement selectLocalField;

	@FindBy(xpath = "//div[@class='loginButton']/button")
	private WebElement loginButton;

	@FindBy(xpath = "//*[contains(@class,'md-dialog']")
	private WebElement spinner;

	@FindBy(xpath = "//div[p[text()='Load Management']]/h1/button")
	private WebElement leftToggleButton;

	@FindBy(xpath = "//p[text()='Container Visibility']")
	private WebElement containerVisibilityOption;

	@FindBy(xpath = "//input[@ng-model='vm.selectedContainerIds']")
	private WebElement containerIdTextField;

	@FindBy(id = "searchIcon")
	private WebElement searchIconinContainerVisibility;

	@FindBy(xpath = "(//table[@ng-model='selectedContainers'])[2]/tbody//td[4]")
	private WebElement ContainerStatus;

	public void enterLoginField(String LoginId) {
		element(userIdField).waitUntilVisible();
		element(userIdField).click();
		element(userIdField).type(LoginId);
	}

	public void enterPasswordField(String password) {
		element(passwordField).waitUntilVisible();
		element(passwordField).click();
		element(passwordField).type(password);
	}

	public void selectDomain(String domainValue) {
		element(selectDomainField).waitUntilVisible();
		element(selectDomainField).click();
		element(selectLocalField).click();
	}

	public void clickLogInButton() {
		element(loginButton).waitUntilVisible();
		element(loginButton).click();
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void waitForSpinner() {
		if (containsElements(".md-dialog")) {
			waitFor(ExpectedConditions.invisibilityOfElementLocated(By.xpath(".md-dialog")));
		}
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);

	}
}
