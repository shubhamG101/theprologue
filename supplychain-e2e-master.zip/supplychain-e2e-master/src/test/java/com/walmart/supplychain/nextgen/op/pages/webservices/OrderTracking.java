package com.walmart.supplychain.nextgen.op.pages.webservices;

import com.jayway.jsonpath.JsonPath;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.supplychain.nextgen.op.steps.webservices.OpSteps;

import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import static net.serenitybdd.rest.SerenityRest.given;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderTracking {

	OpSteps opSteps = new OpSteps();
	Config config = new Config();

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;


	public Response getOrderIdFromOTN(JSONArray otnsArray) {

		String searchWithOtns;
		Response response;

		try {
			searchWithOtns = opSteps.getSearchWithOtnsPayload(otnsArray);
			response = SerenityRest.given().body(searchWithOtns).contentType("application/json").when()
					.post(Config.getOrderManagerSearch());
			return response;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Response> deleteOrderTrackingData() {
		String readTestFlowdata = (String) tl.get().get("testFlowData");
		net.minidev.json.JSONArray orderIdsList = JsonPath.read(readTestFlowdata, "$..ordersDetails[*].orderId");
		List<Response> res = new ArrayList<Response>();
		List<String> OrderTrackingUrls = config.deleteOrderTrackingData();
		int count = 0;
		for (String urls : OrderTrackingUrls) {
			res.add(given().accept("application/json").contentType("application/json").body(orderIdsList.toString())
					.delete(urls));
			res.get(count).then().statusCode(Constants.SUCESS_STATUS_CODE);
			count++;

		}
		return res;
	}

}
