package com.walmart.supplychain.pharmacy.gdm.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.FailsafeException;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class GDMPharmSteps {

	@Autowired
	GDMPharmHelper gdmPharmHelper;

	@Autowired
	Environment environment;

	@Autowired
	JsonUtils jsonUtil;
	
	@Autowired
	DbUtils dbUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String SHIPMENT_SET_JSON_PATH = "$.testFlowData.deliveryDetails[*].shipments";
	private static final String TESTDATAFLOW = "testFlowData";
	private static final String IDM_DELIVERY_EP = "idm_delivery_ep";
	String testFlowData;

	@Step
	public void createMultiShipment(String noOfShipments, String loadNumber, String numOfpacksOnShipmentForEachPOLine, String receivingType) {
		try {
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> shipmentList = new ArrayList<String>();
			for(int i=1;i<=Integer.parseInt(noOfShipments);i++) {
			String shipmentNumber = gdmPharmHelper.randonNumberGenerator(8) + ""
					+ gdmPharmHelper.randonNumberGenerator(8);
			shipmentList.add(shipmentNumber);
			String packData = gdmPharmHelper.preparePackData(numOfpacksOnShipmentForEachPOLine, receivingType);
			String shipmentData = gdmPharmHelper.prepareShipmentData(shipmentNumber, packData, loadNumber);
			logger.info("Shipment Data: " + shipmentData);
			String createShipmentUrl = environment.getProperty("idm_create_Shipment_ep") + shipmentNumber
					+ environment.getProperty("idm_create_Shipment_ep_qp");
			logger.info("Create Shipment Url: " + createShipmentUrl);
			Response createShipmentResponse = SerenityRest.given().relaxedHTTPSValidation().body(shipmentData)
					.headers(gdmPharmHelper.getCreatShipmentHeaders()).post(createShipmentUrl);
			Assert.assertEquals(ErrorCodes.PHARMACY_UNABLE_CREATE_SHIPMENT, 201,
					createShipmentResponse.getStatusCode());
			logger.info("Shipment Created successfully");
			}

			String testFlowDataUpdated = jsonUtil.setJsonAtJsonPath(testFlowData, shipmentList, SHIPMENT_SET_JSON_PATH);
			threadLocal.get().put(TESTDATAFLOW, testFlowDataUpdated);
			logger.info("TestFlowData after updating Shipmentnumber : {}",
					String.valueOf(threadLocal.get().get(TESTDATAFLOW)));
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating Shipmnet", e);
		}
	}

	@Step
	public void getDeliveryResponseForPharmacy(String delvryName) {
		try {
			String testFlowData = threadLocal.get().get(TESTDATAFLOW).toString();
			JSONArray delNum = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber");
			logger.info("Delivery number is" + delNum.get(0));
			List<String> shipNum = JsonPath.read(testFlowData,
					"$.testFlowData.deliveryDetails[?(@.deliveryName=='D1')].shipments[*]");
			logger.info("Expected shipment Numbers ::" + shipNum);
			Response shipmentDetailsResponse = given().relaxedHTTPSValidation()
					.headers(gdmPharmHelper.getCreatShipmentHeaders()).when()
					.get(environment.getProperty(IDM_DELIVERY_EP) + delNum.get(0) + "?includeShipments=true");
			List<String> shipmentDetails = JsonPath.read(shipmentDetailsResponse.asString(),
					"$.shipments..shipmentNumber");
			logger.info("Actual shipment details present in delivery response :: " + shipmentDetails);
			Assert.assertNotEquals(ErrorCodes.PHARMACY_UNABLE_FIND_SHIPMENT_IN_DELIVERY, shipmentDetails.size(), 0);
			Assert.assertEquals(ErrorCodes.PHARMACY_COUNT_MISMATCH_OF_SHIPMENT_IN_DELIVERY, shipNum.size(),
					shipmentDetails.size());
			for (String shipment : shipNum) {
				Assert.assertTrue(ErrorCodes.PHARMACY_UNABLE_FIND_SHIPMENT_IN_DELIVERY,
						shipmentDetails.contains(shipment));
			}
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating Shipment in Delivery document", e);
		}
	}

	@Step
	public String getShipmentDetails(String shipmentNumber) {
		Response getShipmentResponse = null;
		try {
			String getShipmentUrl = environment.getProperty("idm_get_Shipment_ep") + shipmentNumber;
			logger.info("Get Shipment Url: " + getShipmentUrl);
			getShipmentResponse = SerenityRest.given().relaxedHTTPSValidation().body("")
					.headers(gdmPharmHelper.getGetShipmentHeaders()).get(getShipmentUrl);
//			Assert.assertEquals(ErrorCodes.PHARMACY_UNABLE_GET_SHIPMENT, 200, getShipmentResponse.getStatusCode());
			logger.info("Got Shipment Details successfully ######\n" + getShipmentResponse);

		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while getting Shipment details", e);
		}
		return getShipmentResponse.asString();
	}
	
	@Step
	public void updateTiHi(String palletTi, String palletHi) {
		try {
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			JSONArray itemNumber = JsonPath.read(testFlowData,
					"$..itemNumber");
			if(palletTi.equalsIgnoreCase("null")) {
				palletTi = null;
			}
			if(palletHi.equalsIgnoreCase("null")) {
				palletHi = null;
			}
			logger.info("Updating PalletTiHi in global_delivery_manager.atlas_us_rx.item with item_number {}", itemNumber.get(0).toString());
			int insertCount = dbUtils.UpdateFrom(PRODUCT_NAME.IDM, environment.getProperty("gdm_update_pallet_ti_hi"), palletTi, palletHi, itemNumber.get(0).toString());
			logger.info("Successfully inserted in purchase order in global_delivery_manager.atlas_us_rx.item {}", insertCount);
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating Ti Hi in GDM DB", e);
		}
	}

}
