package com.walmart.supplychain.catalyst.by.ui.steps;

import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.by.ui.pages.BYOutboundPage;
import com.walmart.supplychain.catalyst.by.ui.pages.BYReceivingPage;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYWorkQueueSteps extends ScenarioSteps{

	Logger logger = LogManager.getLogger(this.getClass());

	private static final String BY_DOOR_NUMBER_JSONPATH = "$.testFlowData.deliveryDetails..inboundDoorNumber";
	private static final String BY_WAVE_NUMBER_JSONPATH = "$.testFlowData.outboundDetails..waveNumber_BY";

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 
			Constants.RETRY_EXECUTION_COUNT);

	@Autowired
	BYReceivingPage byReceivingPage;

	@Autowired
	BYOutboundSteps byOutboundSteps;

	//	public String currentWaveNumber_BY;
	@Autowired
	BYOutboundPage byOutboundPage;
	
	@Autowired
	Environment environment;
	

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	private static final String TEST_FLOW_DATA = "testFlowData";


	@Step
	public void changeWorkStatus(String workType, String existingWorkStatus, String targetWorkStatus) {

		try {

			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			
			switch(workType){
			case "WAVE":{
				byOutboundPage.switchToFrame("outboundplanner");
				filterWorkQueueForSpecificWave(byOutboundSteps.getCurrentLoadIDInBY());
				break;
			}

			case "HAULPUT":{
				byOutboundPage.switchToFrame("receiving");
				filterWorkQueueForSpecificSource(getReceivingStageNumberInBY());
				break;
			}
			}
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			
			Failsafe.with(retryPolicy).run(() -> {
			String workStatusUnderFilteredRecord= byOutboundPage.getColumnValueUnderWorkQueueTab("Work Status");
			logger.info("Work Status for filtered record: {} ", workStatusUnderFilteredRecord);
			//Assert.assertEquals(ErrorCodes.CATALYST_MMISMATCH_IN_WORK_ASSIGNMENT_STATUS, existingWorkStatus, workStatusUnderFilteredRecord);
			//logger.info("Work assignment presence validated successfully with locked status ===");
			
			byOutboundPage.selectCheckboxForWorkAssignmentRecordUnderWorkQueueTab();
			if(workStatusUnderFilteredRecord.equalsIgnoreCase("Locked")) {
			byOutboundPage.selectOptionsWorkQueueActionsDropdown("Unlock Work");
			byOutboundPage.clickButtonByText("OK");
			byReceivingPage.waitUntillLoadingIndicatorNotVisible();
			}});

			Failsafe.with(retryPolicy).run(() -> {

				String workStatusUnderFilteredRecordAfterUnlock= byOutboundPage.getColumnValueUnderWorkQueueTab("Work Status");
				logger.info("Work Status for filtered record after unlocking: {}", workStatusUnderFilteredRecordAfterUnlock);
				Assert.assertEquals(ErrorCodes.CATALYST_MMISMATCH_IN_WORK_ASSIGNMENT_STATUS, targetWorkStatus, workStatusUnderFilteredRecordAfterUnlock);
				logger.info("Work assignment presence validated successfully with pending status after unlocking ===");

			});


		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while changing work assignment from locked to pending status under work queue tab in BY UI", e);
		}


	}



	public void filterWorkQueueForSpecificWave(String expectedWaveNumber) {

		Failsafe.with(retryPolicy).run(() -> {

			byOutboundPage.enterValueUnderFilterTextBox("workqueue", expectedWaveNumber, "Wave");

			String waveNameUnderFilteredRecord= byOutboundPage.getColumnValueUnderWorkQueueTab("Wave");
			logger.info("wave number for filtered record: {}", waveNameUnderFilteredRecord);

			Assert.assertEquals(ErrorCodes.CATALYST_WRONG_WORK_ASSIGNMENT_RECORD, expectedWaveNumber, waveNameUnderFilteredRecord);
			logger.info("Correct work assignment record for released wave {} got filtered successfully!!", waveNameUnderFilteredRecord);
		});

	}

	public void filterWorkQueueForSpecificSource(String expectedReceivingStage) {

		Failsafe.with(retryPolicy).run(() -> {

			byOutboundPage.enterValueUnderFilterTextBox("workqueue", expectedReceivingStage, "Source");

			String sourceNameUnderFilteredRecord= byOutboundPage.getColumnValueUnderWorkQueueTab("Source");
			logger.info("source number for filtered record: {}", sourceNameUnderFilteredRecord);

			Assert.assertEquals(ErrorCodes.CATALYST_WRONG_WORK_ASSIGNMENT_RECORD, expectedReceivingStage, sourceNameUnderFilteredRecord);
			logger.info("Correct work assignment record for released wave {} got filtered successfully!!", sourceNameUnderFilteredRecord);
		});

	}


	@Step
	public void assignWorkAndChangePriority(String priority) {

		try {

			assignWorkToCurrentUser();
			changeWorkPriority(priority);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while aasign work or changing work priority under work queue tab!!", e);
		}

	}


	public void assignWorkToCurrentUser() throws InterruptedException {

		byOutboundPage.selectOptionsWorkQueueActionsDropdown("Assign User");
		Failsafe.with(retryPolicy).run(() -> {		
			byOutboundPage.enterUserToBeAssigned(environment.getProperty("userName").toUpperCase());
			byOutboundPage.ClickOnSearchedUserRecordUnderAssignUserPopup(environment.getProperty("userName").toUpperCase());
		});
		byOutboundPage.clickButtonByText("Select");
		byOutboundPage.clickButtonByText("OK");	

		Failsafe.with(retryPolicy).run(() -> {

			String actualAssignedUserForWorkAssignment = byOutboundPage.getColumnValueUnderWorkQueueTab("Assigned User");
			logger.info("Assigned user for work assignment after assigning user: {}", actualAssignedUserForWorkAssignment);

			Assert.assertTrue(ErrorCodes.CATALYST_WRONG_WORK_ASSIGNMENT_RECORD, actualAssignedUserForWorkAssignment.contains(environment.getProperty("userName").toUpperCase()));
			logger.info("Work assignment is being assigned to user {} successfully!!", actualAssignedUserForWorkAssignment);

		});

	}


	public void changeWorkPriority(String priority) throws InterruptedException {

		byOutboundPage.selectOptionsWorkQueueActionsDropdown("Change Priority");
		byOutboundPage.enterPriorityUnderChangePriortyPopup(priority);
		byOutboundPage.clickApplyButtonUnderChangePriorityPopup();
		byReceivingPage.waitUntillLoadingIndicatorNotVisible();	

		Failsafe.with(retryPolicy).run(() -> {

			String actualWorkPriority = byOutboundPage.getColumnValueUnderWorkQueueTab("Priority");
			logger.info("Work priority after changing: {}", actualWorkPriority);

			Assert.assertEquals(ErrorCodes.CATALYST_WRONG_WORK_ASSIGNMENT_RECORD, priority, actualWorkPriority);
			logger.info("Priority of Work assignment is being changed to {} successfully!!", priority);

		});

	}

	public String getReceivingStageNumberInBY() {
		
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		List<String> doorNumber_BY = JsonPath.read(runTimeData, BY_DOOR_NUMBER_JSONPATH);
		String BY_ReceivingStageLocation="RCVSTG"+doorNumber_BY.get(0);
		logger.info("Fetched BY_ReceivingStageLocation from testflowdata is {} ", BY_ReceivingStageLocation);
		return BY_ReceivingStageLocation;
	}

}
