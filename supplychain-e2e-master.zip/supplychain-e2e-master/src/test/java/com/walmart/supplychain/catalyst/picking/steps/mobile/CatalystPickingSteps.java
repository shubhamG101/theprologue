package com.walmart.supplychain.catalyst.picking.steps.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystByMobilePage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;

import net.jodah.failsafe.FailsafeException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystPickingSteps extends ScenarioSteps{
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	CatalystByMobilePage catalystByMobilePage;
	
	@Autowired
	CatalystReceivingPage catalystReceivingPage;
	
	@Autowired
	Environment environment;
	
	List<String> sourceLocationList = new ArrayList<String>();
	List<String> destinationLocationList = new ArrayList<String>();
	List<String> workOperationList = new ArrayList<String>();
	static String LPN="";
	
	public void performPicking() throws InterruptedException {	
		try {
			
			//String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			//sourceLocationList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			//destinationLocationList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			//workOperationList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyPickListAtHeadingIsDisplayed();
			catalystByMobilePage.verifyListIdValue(environment.getProperty("operationNumForPicking"));
			catalystByMobilePage.clickOnNextButton();
			catalystByMobilePage.verifyWorkAssignmentHeadingIsDisplayed();
			catalystByMobilePage.clickOnActionsButton();
			catalystByMobilePage.clickOnNextNumOption();
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.enterPosIdValue("1");
			catalystByMobilePage.clickOnDownButton();
			//catalystByMobilePage.clickOnDownButton();
			
			catalystByMobilePage.verifyOrderPickHeadingIsDisplayed();
			catalystByMobilePage.enterPickingLocationTextBox();
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.enterPickingQuantityTextBox();
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.clickOnOkButton();
			catalystByMobilePage.enterPrewrapLocationTextBox();
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.clickOnActionsButton();
			catalystByMobilePage.clickOnBackOption();
			catalystByMobilePage.verifyUndirectedMenuHeadingIsDisplayed();
		
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to add Location and Dock door details", e);
		}
	}
	
}
