package com.walmart.supplychain.nextgen.yms.scenariosteps.db;

import com.walmart.supplychain.nextgen.yms.steps.db.YMSSteps;

import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class YMSDB {
	@Steps
	YMSSteps ymsDB;

	@When("^user adds the delivery and PO details in YMS$")
	public void user_adds_the_delivery_and_PO_details_in_YMS_scheduler() {
		//get PO and delivery number from test flow data
//		ymsDB.insertDeliveryData(poNumber,deliveryNumber);
	}
}
