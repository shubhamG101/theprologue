package com.walmart.supplychain.nextgen.outbound.pages.ui;

import net.thucydides.core.pages.PageObject;
import spring.SpringTestConfiguration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.SerenityHelper;

public class OutboundLoginPage extends SerenityHelper{


	@FindBy(xpath = "//input[@ng-model='user.userId']")
	private WebElement userIdField;

	@FindBy(xpath = "//input[@ng-model='user.password']")
	private WebElement passwordField;
	
	@FindBy(xpath = "//input[@ng-model='user.facilityNum']")
	private WebElement facilityNumField;

	@FindBy(xpath = "//md-select[@ng-model='user.domainName']")
	private WebElement selectDomainField;

	@FindBy(xpath = "//md-select-menu[@role='presentation']//div[contains(text(),'US HOMEOFFICE ')]")
	private WebElement selectHomeOffice;

	@FindBy(xpath = "//div[@class='loginButton']/button")
	private WebElement loginButton;



	public void enteruserIdField(String userId) {
		element(userIdField).waitUntilVisible();
		element(userIdField).click();
		element(userIdField).type(userId);
	}

	public void enterPasswordField(String password) {
		element(passwordField).waitUntilVisible();
		element(passwordField).click();
		element(passwordField).type(password);
	}
	public void enterFacilityNumField(String facilityNum) {
		element(facilityNumField).waitUntilVisible();
		element(facilityNumField).click();
		element(facilityNumField).type(facilityNum);
	}

	public void selectDomain() {
		element(selectDomainField).waitUntilVisible();
		/*element(selectDomainField).click();
		element(selectHomeOffice).click();
		This is not required as it is being selected automatically
		*/
	}

	public void clickLogInButton() {
		element(loginButton).waitUntilVisible();
		element(loginButton).click();

	}

	public void getUrl(String url) {
		getDriverInstance().get(url);
	}
	public void closeDriver() {
		getDriverInstance().close();
	}

}
