package com.walmart.supplychain.catalyst.wavePlanning.steps;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.TimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OrdersDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.witronutilities.WitronUtil;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.witron.myapps.pages.MyAppsHomePage;
import com.walmart.supplychain.witron.myapps.pages.MyAppsLoginPage;
import com.walmart.supplychain.witron.myapps.steps.MyAppsStep;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningBatchPage;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningCreateBatchPage;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningCreateSchPage;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningHomePage;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningLoginPage;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningModifyWaveCyclePage;
import com.walmart.supplychain.witron.wavePlanning.pages.WavePlanningSchedulePage;
import com.walmart.supplychain.witron.wavePlanning.pages.WaveReleasePage;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystWavePlanningStep {
	@Autowired
	WavePlanningLoginPage wavePlanningLoginPage;

	@Autowired
	WavePlanningHomePage wavePlanningHomePage;

	@Autowired
	WavePlanningBatchPage wavePlanningBatchPage;

	@Autowired
	WavePlanningCreateBatchPage wavePlanningCreateBatchPage;

	@Autowired
	WavePlanningSchedulePage wavePlanningSchedulePage;

	@Autowired
	WavePlanningModifyWaveCyclePage wavePlanningModifyWaveCyclePage;

	@Autowired
	WavePlanningCreateSchPage wavePlanningCreateSchPage;

	@Autowired
	WaveReleasePage waveReleasePage;

	boolean loadingFlow = false;

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	ObjectMapper om = new ObjectMapper();

	@Autowired
	JsonUtils jsonUtil;
	@Autowired
	Environment endpoint;
	Response response;
	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	WitronUtil witronUtil;

	@Autowired
	MyAppsStep myAppsStep;

	@Autowired
	MyAppsLoginPage myAppsLoginPage;

	@Autowired
	MyAppsHomePage myAppsHomePage;

	@Autowired
	PreRunCleanup preRunCleanup;

	private static final String OUTBOUND_GET_BATCH = "$.testFlowData.outboundDetails[*]";
	private static final String GET_LOADING_STATUS = "$.shippingContainerList[*].containerStatusDesc";
	private static final String GET_LOADING_SEARCH_EP = "loading_search_url";
	private static final String GET_ORDERS = "$.testFlowData.ordersDetails[*]";
	private static int totalOrderCountModifyPage = 0;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(12, Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";

	public void openWavePlanningUI() {

		logger.info("Launching Wave planning url" + endpoint.getProperty("wave_planning_url"));
		myAppsStep.accessTheAppFromMyApps(environment.getProperty("myApps_userName"), environment.getProperty("myApps"),
				environment.getProperty("facility_num"), environment.getProperty("myApps_op"));

	}

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	public void loginToWavePlanning() {
		try {
			wavePlanningLoginPage.enterLoginField();
			logger.info("Logged in to wave planning app");
		} catch (ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_WAVE_PLANNING_LOGIN_FAILED, e);
		}
	}
	
	
	@Step
	public void prepareTestFlowData() {
		
		try {
			
			String testData;
			
			if(tl.get().get(TEST_FLOW_DATA)==null) {
				
				TestFlowDataMain root = new TestFlowDataMain();
				TestFlowData testFlowData = new TestFlowData();
				
				List<OutboundDetail> outboundList = new ArrayList<OutboundDetail>();
				testFlowData.setOutboundDetails(outboundList);
				root.setTestFlowData(testFlowData);
				tl.get().put(TEST_FLOW_DATA, om.writeValueAsString(root));
				logger.info("Prepared testFlowdata:" + tl.get().get(TEST_FLOW_DATA));
			}
			
			else {
				testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info("existing testFlowdata:" + tl.get().get(TEST_FLOW_DATA));
			}
			
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.CATALYST_OB_TEST_FLOW_DATA_CREATION_FAILED, e);
		}
	}


	@Step
	public void createBatch() {
		try {
			logger.info(" createBatch step");
			
//			Failsafe.with(retryPolicy).run(() -> {
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				
				List outboundList = new ArrayList();
				openWavePlanningUI();
				String batchName = createBatchInWavePlanningUI();
				OutboundDetail outboundDetail = new OutboundDetail();
				outboundDetail.setWitronBatchName(batchName);
				outboundList.add(outboundDetail);
				net.minidev.json.JSONObject testFlowData = jsonUtils.convertStringToMinidevJsonObject(testData);
				String testFlowDataString = jsonUtils.setJsonAtJsonPath(testFlowData.toJSONString(), outboundList,
						"$.testFlowData.outboundDetails");			
				tl.get().put(TEST_FLOW_DATA, testFlowDataString);

				logger.info("testData {}", tl.get().get(TEST_FLOW_DATA));
//			});

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_BATCH_CREATE_FAILED, e);
		}

	}

	@Step
	public void createSchedule() {
		try {

			Failsafe.with(retryPolicy).run(() -> {
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info(testData);
				DocumentContext context = null;
				wavePlanningBatchPage.navigateToScheduler();

				JSONArray listOfBatch = JsonPath.read(testData, OUTBOUND_GET_BATCH);
				String outBoundString = listOfBatch.toJSONString();
				List<OutboundDetail> outboundBatchList = null;
				outboundBatchList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
				});

				String batchName = outboundBatchList.get(0).getWitronBatchName();
				String cycleWave = createScheduleInWavePlanningString(batchName);

				outboundBatchList.get(0).setCycleWave(cycleWave);

				JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
				context = JsonPath.parse(parser.parse(testData));
				context.set("$.testFlowData.outboundDetails",
						JsonPath.parse(om.writeValueAsString(outboundBatchList)).read("$", JSONArray.class));
				String str = context.jsonString();
				tl.get().put(TEST_FLOW_DATA, str);
				logger.info("testData after updating cycle wave::{}", tl.get().get(TEST_FLOW_DATA));
			});
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_SCHEDULE_CREATE_FAILED, e);
		}
	}

	@Step
	public void releaseAndValidateCycleWave() {
		try {
			Failsafe.with(retryPolicy).run(() -> {
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				wavePlanningSchedulePage.navigateToWaveRelease();
				DocumentContext context = null;
				JSONArray listOfBatch = JsonPath.read(testData, OUTBOUND_GET_BATCH);
				String outBoundString = listOfBatch.toJSONString();
				List<OutboundDetail> outboundList = null;
				outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
				});
				String cycleWave = outboundList.get(0).getCycleWave();
				Thread.sleep(3000);
				validateOrdersInWavePlanningUI(cycleWave);
				String releaseNbr = releaseWave(cycleWave);
				outboundList.get(0).setReleaseNbr(releaseNbr);

				JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
				context = JsonPath.parse(parser.parse(testData));
				context.set("$.testFlowData.outboundDetails",
						JsonPath.parse(om.writeValueAsString(outboundList)).read("$", JSONArray.class));
				String str = context.jsonString();
				tl.get().put(TEST_FLOW_DATA, str);
				logger.info("testData after updating release number::{}", tl.get().get(TEST_FLOW_DATA));
			});
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_POPULATE_BOH_FAILED, e);
		}

	}

	public String createBatchInWavePlanningUI() {
		try {

			String batchName = "Batch" + javaUtil.randonNumberGenerator(4);
			Thread.sleep(6000);
			wavePlanningBatchPage.navigateToBatchPage();
			logger.info("clicked on manage batch");
			Thread.sleep(3000);
			wavePlanningBatchPage.clickOnAddBatchBtn();
			logger.info("clicked on add batch");
			// wavePlanningCreateBatchPage.createBatch(batchName);

			String destinationName = environment.getProperty("destination_name");
			if (destinationName != null) {
				wavePlanningCreateBatchPage.createBatchCatalyst(batchName, destinationName);
			} else {
				wavePlanningCreateBatchPage.createBatch(batchName);
			}

			logger.info("created batch");
			wavePlanningBatchPage.validateBatch(batchName);
			logger.info("validated batch");
			return batchName;

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_BATCH_CREATE_FAILED, e);
		}
	}

	public String createScheduleInWavePlanningString(String batchName) {
		try {
			Map<String, String> dayCycleMap = new HashMap<String, String>();
			dayCycleMap.put("2", "Mon#111" + javaUtil.randonNumberGenerator(3));
			dayCycleMap.put("3", "Tue#222" + javaUtil.randonNumberGenerator(3));
			dayCycleMap.put("4", "Wed#333" + javaUtil.randonNumberGenerator(3));
			dayCycleMap.put("5", "Thu#444" + javaUtil.randonNumberGenerator(3));
			dayCycleMap.put("6", "Fri#555" + javaUtil.randonNumberGenerator(3));
			dayCycleMap.put("7", "Sat#666" + javaUtil.randonNumberGenerator(3));
			dayCycleMap.put("1", "Sun#777" + javaUtil.randonNumberGenerator(3));

			Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
			Date date = calendar.getTime();
			int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

			logger.info(dayCycleMap.get(String.valueOf(dayOfWeek)));
			String cycleWaveStr = dayCycleMap.get(String.valueOf(dayOfWeek));
			String[] cycleWaveArr = cycleWaveStr.split("#");
			logger.info(cycleWaveArr);
			String day = cycleWaveArr[0];
			String cycleWave = cycleWaveArr[1];

			Thread.sleep(10000);
			wavePlanningSchedulePage.clickOnAddScheduleBtn();
			wavePlanningCreateSchPage.createSchedule(batchName, day, cycleWave);
			wavePlanningSchedulePage.validateSchedule(batchName);
			cycleWave = cycleWave.substring(0, 3) + " /" + cycleWave.substring(3, cycleWave.length());
			return cycleWave;

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_SCHEDULE_CREATE_FAILED, e);
		}
	}

	public String releaseWave(String cycleWave) {
		try {
			Thread.sleep(3000);
			waveReleasePage.releaseCycleWave(cycleWave);
			String releaseNbr = waveReleasePage.getreleaseNbr(cycleWave);
//			waveReleasePage.closeDriver();
			return releaseNbr;
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_RELEASE_FAILED, e);
		}

	}

	@Step
	public void validateOrdersInWavePlanningUI(String cycleWave) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			DocumentContext parsedtestflowJson = JsonPath.parse(testData);

			JSONArray listOfWAC = JsonPath.read(testData, GET_ORDERS);
			String wacString = listOfWAC.toJSONString();
			List<OrdersDetail> orderList = om.readValue(wacString, new TypeReference<List<OrdersDetail>>() {
			});
			int caseCount = 0;
			int orderCount = 0;
			Set destinationSet = new HashSet();
			for (OrdersDetail order : orderList) {
				caseCount += Integer.parseInt(order.getQuantity()) / Integer.parseInt(order.getVnpk());
				orderCount++;
				destinationSet.add(order.getDestinationNum());
			}

			int orderCountUI = Integer.parseInt(waveReleasePage.getOrdersCount(cycleWave));
			int caseCountUI = Integer.parseInt(waveReleasePage.getCaseCount(cycleWave));
			int destinationCountUI = Integer.parseInt(waveReleasePage.getDestinationCount(cycleWave));
			logger.info(destinationCountUI);

			Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_ORDERS_WAVE_PLAN, caseCount, caseCountUI);
			Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_ORDERS_WAVE_PLAN, orderCount, orderCountUI);
			Assert.assertEquals(ErrorCodes.WITRON_ORDERS_MISMATCH_ORDERS_WAVE_PLAN, destinationSet.size(),
					destinationCountUI);

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.WITRON_ORDERS_MISMATCH_ORDERS_WAVE_PLAN, e);
		}
	}

	@Step
	public void reverseWave() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testFlowData);
			List<String> releaseList = parsedItemDetailsJson.read("$.testFlowData.outboundDetails[*].releaseNbr");
			waveReleasePage.reverseCycleWave(releaseList.get(0));
			waveReleasePage.closeDriver();
		} catch (Exception e) {
			throw new AutomationFailure("Failed to reverse the cycle wave", e);
		}
	}

	@Step
	public void validateWavePlanningAfterRelease() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			openWavePlanningUI();
			Thread.sleep(6000);
			wavePlanningSchedulePage.navigateToWaveRelease();
			DocumentContext context = null;
			JSONArray listOfBatch = JsonPath.read(testData, OUTBOUND_GET_BATCH);
			String outBoundString = listOfBatch.toJSONString();
			List<OutboundDetail> outboundList = null;
			outboundList = om.readValue(outBoundString, new TypeReference<List<OutboundDetail>>() {
			});
			String cycleWave = outboundList.get(0).getCycleWave();
			Thread.sleep(3000);
			validateOrdersInWavePlanningUI(cycleWave);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate wave planning UI after Wave Reversal", e);
		}
	}

//	@Step
//	public void witronCycleWavePreCleanUp() {
//		preRunCleanup.cleanUpWitronCycleWave();
//	}

	@Step
	public void cancelFirstOrderFromDefaultCycle() {
//		logger.info("Searching for orders in default cycle");
		// wavePlanningModifyWaveCyclePage.serachForOrdersInDefaultCycle("999/999");
		int initialOrderCount = wavePlanningModifyWaveCyclePage.getOrderCount();
		logger.info("Initial count of odrers before delete operation " + initialOrderCount);
		wavePlanningModifyWaveCyclePage.deleteFirstOrderInDefaultCycle();
		int finalOrderCount = wavePlanningModifyWaveCyclePage.getOrderCount();
		logger.info("Fint count of odrers after delete operation " + finalOrderCount);
		boolean countValidation = ((initialOrderCount - 1) == finalOrderCount);
		Assert.assertTrue(ErrorCodes.WITRON_ORDER_NOT_CANCELLED, countValidation);
		logger.info("Deleted order ");
		totalOrderCountModifyPage = finalOrderCount;
	}

	@Step
	public void modifyCycleWaveNumber() {
		logger.info("Releasing orders from defualt cycle");
		String testFlowJSON;
		testFlowJSON = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info(testFlowJSON);
		List<String> cycleWaveList = JsonPath.parse(testFlowJSON).read("$.testFlowData.outboundDetails[*].cycleWave");
		String cycleWave = cycleWaveList.get(0);
		logger.info("cycle Wave " + cycleWave);
		String cycle = cycleWave.split(" /")[0];
		logger.info("cycle " + cycle);
		String wave = cycleWave.split(" /")[1];
		logger.info("Wave " + wave);
		wavePlanningModifyWaveCyclePage.releaseOrderFromDefaultCycle(cycle, wave);

	}

	@Step
	public void validateOrderCountInReleasePage() {
		logger.info("Navigate to wave release page");
		wavePlanningSchedulePage.navigateToWaveRelease();
		String testFlowJSON;
		testFlowJSON = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info(testFlowJSON);
		List<String> cycleWaveList = JsonPath.parse(testFlowJSON).read("$.testFlowData.outboundDetails[*].cycleWave");
		String cycleWave = cycleWaveList.get(0);
		logger.info("cycle Wave " + cycleWave);
		String count = waveReleasePage.getOrdersCount(cycleWave);
		logger.info("count " + count);
		int waveReleasePageOrderCount = Integer.parseInt(count);
		boolean countValidation = (totalOrderCountModifyPage == waveReleasePageOrderCount);
		Assert.assertTrue(ErrorCodes.WITRON_ORDER_COUNT_MISMATCH_FOR_MODIFY_AND_RELEASE_PAGES, countValidation);
		logger.info("Order count match after  modifying cycleWave Details");

	}

	@Step
	public void deactivateBatch() {
		logger.info("Navigate to manage batch");
		wavePlanningBatchPage.navigateToBatchPage();
		String testFlowJSON;
		testFlowJSON = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info(testFlowJSON);
		List<String> witronBatchNameList = JsonPath.parse(testFlowJSON)
				.read("$.testFlowData.outboundDetails[*].witronBatchName");
		String witronBatchName = witronBatchNameList.get(0);
		logger.info("witron Batch Name " + witronBatchName);
		wavePlanningBatchPage.deactivateBatch(witronBatchName);

	}

	@Step
	public void activateBatch() {
		logger.info("Navigate to manage batch");
		wavePlanningBatchPage.navigateToBatchPage();
		String testFlowJSON;
		testFlowJSON = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info(testFlowJSON);
		List<String> witronBatchNameList = JsonPath.parse(testFlowJSON)
				.read("$.testFlowData.outboundDetails[*].witronBatchName");
		String witronBatchName = witronBatchNameList.get(0);
		logger.info("witron Batch Name " + witronBatchName);
		wavePlanningBatchPage.activateBatch(witronBatchName);

	}

	@Step
	public void validateOrderCount() {
		logger.info("Navigating to modify cycle wave page");
		wavePlanningModifyWaveCyclePage.navigateToModifyWaveCycle();
		logger.info("Searching for orders in default cycle");
		wavePlanningModifyWaveCyclePage.serachForOrdersInDefaultCycle("999/999");
		int ActualOrderCount = wavePlanningModifyWaveCyclePage.getOrderCount();
		String testFlowJSON;
		testFlowJSON = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info(testFlowJSON);
		List<String> OrdersList = JsonPath.parse(testFlowJSON).read("$.testFlowData.ordersDetails[*].itemNumber");
		boolean countValidation = (ActualOrderCount == OrdersList.size());
		logger.info("ActualOrderCount  " + ActualOrderCount + " Expected Count " + OrdersList.size());
		Assert.assertTrue(ErrorCodes.WITRON_ORDER_COUNT_MISMATCH, countValidation);
		logger.info("Order count match after  modifying cycleWave Details");
	}
}
