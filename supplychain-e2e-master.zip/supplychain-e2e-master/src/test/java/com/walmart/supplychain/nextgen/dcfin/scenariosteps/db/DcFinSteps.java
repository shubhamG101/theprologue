package com.walmart.supplychain.nextgen.dcfin.scenariosteps.db;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.exceptions.ReadFailureException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.Queries;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.Casandra;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.db.QueryHelper;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;
import java.lang.Math;
import java.math.RoundingMode;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class DcFinSteps {

	private QueryHelper queryHelper = new QueryHelper();
	private String queryDCPurchaseData;
	private String queryDCSaleData;
	private ResultSet queryResult;
	private static final String PURCHASE_DB_COL_NAME = "system.sum(total_received_cost)";
	private static final String SALES_DB_COL_NAME = "system.sum(total_sales_cost)";
	private static final String DAMAGE_DB_COL_NAME = "system.sum(total_adjusted_cost)";
	private double purchaseValueFromDB = 0;
	private double saleValueFromDB;
	private double purchaseValueFromReceiveQty;
	private static final double DELTA = 0.001;
	private String deliveryDetails = "$..deliveryDetails[*]";
	private String loadIdDetails = "$..outboundDetails[*]";
	private String srcNumberDetails = "$.testFlowData.poDetails[*].sourceNumber";
	private static final String PO_LINE_DETAILS_PATH = "$..poLineDetails[*]";
	private static final String PO_DETAIL_PATH = "$..poDetails[*]";
	private static final String TEST_FLOW_DATA_KEY = "testFlowData";
	private static final double WHPK_SELL_PRICE_ATLAS = 26.53;
	private static final String WHPK_QTY_FIELD = "whpkqty";
	private static final String WHPK_COST_FIELD = "whpkcost";
	private JsonUtils jsonUtility = new JsonUtils();
	private String testFlowData;
	Session session = null;
	private static final String SHORTAGE = "shortage";
	private static final String OVERAGE = "overage";
	private static final String DAMAGE = "damage";
	private static final String NO_OSDR = "noOsdr";

	private static final String PO_LINE_ITEM_PATH = "$..poLineDetails[*].itemNumber";
	private static final String THOR_DC_NUMBER = "thor_dcNumber";
	private static final String SOURCE_NBR = "source_nbr";
	private static final String SOURCE_CC = "source_cc";
	private static final String END_INV_SALES_DATE = "ending_inv_sales_date";
	private static final String DEPT_NO = "dept_nbr";
	private static final String SALES_UNIQUE_ID = "sales_unique_id";
	private static final String END_INV_ADJUSTMENT_DATE = "ending_inv_adjust_date";
	private static final String ADJUSTMENT_UNIQUE_ID = "inv_adjust_unique_id";

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	private static final String DAMAGE_ADJ_TYPE = "DAMAGE";
	private int itemQtyWhpkDb = 0;
	private int itemQtyWhpk = 0;
	private int receivedQtyInVNPK = 0;
	private double totalExpectedDamageCostForItem = 0.0;

	@Autowired
	Casandra casandra;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	Environment endpoints;

	@Autowired
	Environment environment;
	
	@Autowired
	DbUtils dbUtils;

	@SuppressWarnings("unchecked")
	public double getPurchaseDataFromDB() {
		try {
			if (session == null || session.isClosed()) {
				session = casandra.connectToDb();
			}
			purchaseValueFromDB = 0;
			testFlowData = String.valueOf(threadLocal.get().get(TEST_FLOW_DATA_KEY));
			List<PoDetail> poDetails;
			JSONArray poDetailsArray = JsonPath.read(testFlowData, PO_DETAIL_PATH);
			poDetails = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsArray.toJSONString(), PoDetail.class);
			for (PoDetail poDetail : poDetails) {
				Double purchaseValueForPO = 0.0;
				String poNumber = poDetail.getPoNumber();
				logger.info("Processing for PO Number:{} ", poNumber);
				List<PoLineDetail> poLineDetails = poDetail.getPoLineDetails();
				for (PoLineDetail poLineDetail : poLineDetails) {
					Double purchaseValueForItem = 0.0;
					String itemNumber = poLineDetail.getItemNumber();
					logger.info("Processing for Item Number:{} ", itemNumber);

					if (Config.DC == DC_TYPE.THOR) {
						String thorSourceNumber = environment.getProperty(THOR_DC_NUMBER);
						purchaseValueForItem += getPurchaseForInstructionThor(poNumber, itemNumber, thorSourceNumber);
					} else {
						List<ReceivingInstruction> receivingInstructions = poLineDetail.getReceivingInstructions();
						for (ReceivingInstruction instruction : receivingInstructions) {
							purchaseValueForItem += getPurchaseForInstruction(instruction);
						}
						logger.info("Purchase Value From DB for Item:{} is :{}", itemNumber, purchaseValueForItem);
					}
					purchaseValueForPO += purchaseValueForItem;
				}
				logger.info("Purchase Value From DB for PO:{} is :{}", poNumber, purchaseValueForPO);
				purchaseValueFromDB += purchaseValueForPO;
			}
			logger.info("Total Purchase Value From DB:{}", purchaseValueFromDB);
		} catch (ReadFailureException e) {
			throw new TestCaseFailure(ErrorCodes.DC_FIN_NO_DATA_FOUND, e);
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.DC_FIN_PURCHASE_VALIDATION, e);
		} finally {
			casandra.closeSession();
		}
		return purchaseValueFromDB;
	}

	public double getPurchaseForInstructionThor(String poNumber, String itemNumber, String thorSourceNumber) {
		Double purchaseValueForItem = 0.0;
		logger.info("Executing purchase query for item :{}", itemNumber);
		queryHelper.setQueryParam("po_number", poNumber);
		queryHelper.setQueryParam("item_number", itemNumber);

		queryHelper.setQueryParam("src_number", thorSourceNumber);
		queryDCPurchaseData = queryHelper.getSQLQueryParam(Queries.DC_FIN_PURCHASE_DATA_PO_ITEM_THOR);
		logger.info("Purchase query {}", queryDCPurchaseData);
		queryResult = casandra.executeQuery(session, queryDCPurchaseData);
		purchaseValueForItem += parseResultSet(queryResult, PURCHASE_DB_COL_NAME);
		return purchaseValueForItem;

	}

	public double getPurchaseForInstruction(ReceivingInstruction instruction) {
		Double purchaseValueForItem = 0.0;
		Double purchaseValueForReceivedContainers = 0.0;
		String parentContainer = instruction.getParentContainer();
		logger.info("Processing parent container:{}", parentContainer);
		queryHelper.setQueryParam("parent_container", parentContainer);
		queryHelper.setQueryParam("source_number", environment.getProperty("dcNumber"));
		if (instruction.getIsVTR() && !instruction.getChildContainers().isEmpty()) {
			List<String> childContainers = instruction.getChildContainers();
			childContainers.add(instruction.getVtrContainer());// Add the VTRed container as well
			for (String childContainer : childContainers) {
				queryHelper.setQueryParam("child_container", childContainer);
				if (Config.DC == DC_TYPE.ATLAS) {
					queryDCPurchaseData = queryHelper
							.getSQLQueryParam(Queries.DC_FIN_PURCHASE_DATA_PARENT_CONTAINER_QUERY_ATLAS);// child
					// container
					// will be
					// there in
					// parent
					// container
					// column
				} else {
					queryDCPurchaseData = queryHelper
							.getSQLQueryParam(Queries.DC_FIN_PURCHASE_DATA_CHILD_CONTAINER_QUERY);
				}
				logger.info("Purchase Query for child container:{} is :{}", childContainer, queryDCPurchaseData);
				queryResult = casandra.executeQuery(session, queryDCPurchaseData);
				purchaseValueForReceivedContainers += parseResultSet(queryResult, PURCHASE_DB_COL_NAME);
				logger.info("Purchase Val from DB:{} ", purchaseValueForReceivedContainers);

			}
			queryDCPurchaseData = queryHelper.getSQLQueryParam(Queries.DC_FIN_PURCHASE_DATA_PARENT_CONTAINER_QUERY);
		} else {
			List<String> childContainers = instruction.getChildContainers();
			if (Config.DC != DC_TYPE.ATLAS || childContainers.isEmpty()) {
				queryDCPurchaseData = queryHelper.getSQLQueryParam(Queries.DC_FIN_PURCHASE_DATA_PARENT_CONTAINER_QUERY);
				logger.info("Purchase Query for parent container:{} is :{}", parentContainer, queryDCPurchaseData);
				queryResult = casandra.executeQuery(session, queryDCPurchaseData);
				purchaseValueForReceivedContainers = parseResultSet(queryResult, PURCHASE_DB_COL_NAME);
			} else {
				for (String childContainer : childContainers) {
					queryHelper.setQueryParam("child_container", childContainer);
					queryDCPurchaseData = queryHelper
							.getSQLQueryParam(Queries.DC_FIN_PURCHASE_DATA_PARENT_CONTAINER_QUERY_ATLAS);
					logger.info("Purchase Query for child container:{} is :{}", childContainer, queryDCPurchaseData);
					queryResult = casandra.executeQuery(session, queryDCPurchaseData);
					purchaseValueForReceivedContainers += parseResultSet(queryResult, PURCHASE_DB_COL_NAME);
					logger.info("Purchase Val from DB:{} ", purchaseValueForReceivedContainers);
				}
			}

		}
		// Sum up purchase data for all the parentContainers
		logger.info("Purchase value from DB for received containers:{} ", purchaseValueForReceivedContainers);
		purchaseValueForItem += purchaseValueForReceivedContainers;
		return purchaseValueForItem;
	}

	public double getSalesDataFromDBForThor() throws IOException, JSONException {
		if (session == null || session.isClosed()) {
			session = casandra.connectToDb();
		}
		saleValueFromDB = 0;
		testFlowData = String.valueOf(threadLocal.get().get(TEST_FLOW_DATA_KEY));
		DocumentContext jsonParser = JsonPath.parse(testFlowData);
		List<String> itemNumberList = jsonParser.read(PO_LINE_ITEM_PATH);

		queryHelper.setQueryParam("item_number", itemNumberList.get(0));
		queryHelper.setQueryParam("src_number", environment.getProperty(THOR_DC_NUMBER));

		queryDCSaleData = queryHelper.getSQLQueryParam(Queries.DC_FIN_SALE_DATA_THOR);
		logger.info("Sales query {}", queryDCSaleData);
		queryResult = casandra.executeQuery(session, queryDCSaleData);
		saleValueFromDB = saleValueFromDB + parseResultSet(queryResult, SALES_DB_COL_NAME);
		logger.info("Sales value from DB {}", saleValueFromDB);

		return saleValueFromDB;
	}

	public double getSalesDataFromDB() throws IOException, JSONException {
		String srcNumber;
		saleValueFromDB = 0;
		try {
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			if (session == null || session.isClosed()) {
				session = casandra.connectToDb();
			}

			srcNumber = jsonUtility.readJsonFromString(testFlowData, srcNumberDetails).toString()
					.replaceAll("\\[|\\]|\"", "").split(",")[0];
			logger.info(srcNumber);

			org.json.JSONArray jsonArray = new org.json.JSONArray(
					jsonUtility.readJsonFromString(testFlowData, loadIdDetails).toString());

			for (int i = 0; i < jsonArray.length(); i++) {

				JSONObject jsonObject = jsonArray.getJSONObject(i);
				logger.info("Outbound obj details from the parsed object" + jsonObject.toString());

				queryHelper.setQueryParam("tmsId", jsonObject.getString("tmsLoadId"));
				queryHelper.setQueryParam("src", srcNumber);
				queryHelper.setQueryParam("endDate", getDateString(1));
				queryHelper.setQueryParam("startDate", getDateString(-2));

				queryDCSaleData = queryHelper.getSQLQueryParam(Queries.DC_FIN_SALE_DATA);
				logger.info("Sales query " + queryDCSaleData);

				queryResult = casandra.executeQuery(session, queryDCSaleData);
				logger.info("tms id " + jsonObject.getString("tmsLoadId"));
				saleValueFromDB = saleValueFromDB + parseResultSet(queryResult, SALES_DB_COL_NAME);
				logger.info("Sale value from DB " + saleValueFromDB);

			}
		} catch (ReadFailureException e) {
			throw new TestCaseFailure(ErrorCodes.DC_FIN_NO_DATA_FOUND, e);
		} finally {
			casandra.closeSession();
		}
		return saleValueFromDB;
	}

	@Step
	public void validateAdjustment(String adjType) {
		testFlowData = (String) threadLocal.get().get("testFlowData");
		try {
			testFlowData = (String) threadLocal.get().get("testFlowData");
			if (adjType.equals(DAMAGE_ADJ_TYPE)) {
				List<String> poList = JsonPath.read(testFlowData, "$.testFlowData..poNumber");
				if (poList.isEmpty())
					throw new AutomationFailure("PO Details can not be empty in testflowdata");
				for (String poNumber : poList) {
					logger.info("Validating damage cost for PO:{}", poNumber);
					JSONArray itemDetailsArray = JsonPath.read(testFlowData,
							"$.testFlowData..poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails[*]");
					List<PoLineDetail> itemDetails = (List<PoLineDetail>) jsonUtils
							.getPojoListfromPath(itemDetailsArray.toJSONString(), PoLineDetail.class);
					if (itemDetails.isEmpty())
						throw new AutomationFailure("Item Details can not be empty in testflowdata");
					for (PoLineDetail itemDetail : itemDetails) {
						double totalExpectedDamageCostForItem = getExpectedTotalDamageCost(itemDetail, poNumber);
						Failsafe.with(retryPolicy).run(() -> {
							logger.info("Total Expected Damage cost for item {} is :{} ", itemDetail.getItemNumber(),
									totalExpectedDamageCostForItem);
							double actualDamageCost = getTotalDamageCostDataFromDB(itemDetail);
							logger.info("Total Actual Damage cost for item {} is :{} ", itemDetail.getItemNumber(),
									actualDamageCost);
							Assert.assertEquals(ErrorCodes.DC_FIN_PURCHASE_DAMAGE_VALIDATION_FAILED,
									totalExpectedDamageCostForItem, actualDamageCost,DELTA);
						});
					}
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Unable to validate damage cost", e);
		}
	}

	@Step
	public void validateAdjustmentforThor() {
		try {
			testFlowData = (String) threadLocal.get().get("testFlowData");
			if (Config.DC == DC_TYPE.THOR) {
				List<String> poList = JsonPath.read(testFlowData, "$.testFlowData..poNumber");
				if (poList.isEmpty())
					throw new AutomationFailure("PO Details can not be empty in testflowdata");
				for (String poNumber : poList) {
					logger.info("Validating damage cost for PO:{}", poNumber);
					JSONArray itemDetailsArray = JsonPath.read(testFlowData,
							"$.testFlowData..poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails[*]");
					List<PoLineDetail> itemDetails = (List<PoLineDetail>) jsonUtils
							.getPojoListfromPath(itemDetailsArray.toJSONString(), PoLineDetail.class);
					if (itemDetails.isEmpty())
						throw new AutomationFailure("Item Details can not be empty in testflowdata");
					for (PoLineDetail itemDetail : itemDetails) {
						totalExpectedDamageCostForItem = getExpectedTotalDamageCost(itemDetail, poNumber);
						DecimalFormat df = new DecimalFormat("0.00");
						df.setRoundingMode(RoundingMode.UP);
						totalExpectedDamageCostForItem = Double.parseDouble(df.format(totalExpectedDamageCostForItem));
						Failsafe.with(retryPolicy).run(() -> {
							logger.info("Total Expected adjustment cost for item {} is :{} ",
									itemDetail.getItemNumber(), totalExpectedDamageCostForItem);
							double actualDamageCost = getTotalDamageCostDataFromDB(itemDetail);
							logger.info("Total Actual adjustment cost for item {} is :{} ", itemDetail.getItemNumber(),
									actualDamageCost);
							Assert.assertEquals(ErrorCodes.DC_FIN_PURCHASE_DAMAGE_VALIDATION_FAILED,
									totalExpectedDamageCostForItem, actualDamageCost, DELTA);
						});
					}
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Unable to validate damage cost", e);
		}
	}

	@Step
	public double getExpectedTotalDamageCost(PoLineDetail itemDetail, String poNumber) throws JsonProcessingException {
		int noOfWhpkInOneVnpk;
		int whpk;
		int vnpk;
		double whpkSellPrice;
		double totalPurchase = 0;
		ObjectMapper om = new ObjectMapper();
		List<Integer> qtyArr = null;
		if (Config.DC == DC_TYPE.THOR) {
			qtyArr = JsonPath.read(om.writeValueAsString(itemDetail), "$.receivingInstructions[*].adjustedQty");
		} else {
			qtyArr = JsonPath.read(om.writeValueAsString(itemDetail), "$.receivingInstructions[*].damageQty");
		}
		int totalQtyForItem = 0;
		double totalExpectedDamageCostForItem = 0;
		for (Integer qty : qtyArr) {
			totalQtyForItem += qty;
		}
		String poLine = itemDetail.getPoLineNumber();
		whpkSellPrice = Double.parseDouble(itemDetail.getWhpkSellPrice());
		vnpk = Integer.parseInt(itemDetail.getVnpk());
		whpk = Integer.parseInt(itemDetail.getWhpk());
		if (Config.DC == DC_TYPE.ATLAS
				&& (Config.ENV == ENVIRONMENT.QA || Config.ENV == ENVIRONMENT.DEV || Config.ENV == ENVIRONMENT.CERT)) {
			Map<String, String> map = getDCFinPurchaseValues(Integer.parseInt(poLine), poNumber);
			whpkSellPrice = Double.parseDouble(map.get(WHPK_COST_FIELD));
		}
		noOfWhpkInOneVnpk = vnpk / whpk;
		logger.info("Number of whpk qty in one vnpk " + noOfWhpkInOneVnpk);

		if (Config.DC == DC_TYPE.THOR) {
			logger.info("Total Number of adjusted qty in eaches for item {} is :{} ", itemDetail.getItemNumber(),
					totalQtyForItem);
			totalExpectedDamageCostForItem = (totalQtyForItem * whpkSellPrice) / whpk;
		} else {
			logger.info("Total Number of Damaged whpk qty for item {} is :{} ", itemDetail.getItemNumber(),
					totalQtyForItem * noOfWhpkInOneVnpk);
			totalExpectedDamageCostForItem = totalQtyForItem * noOfWhpkInOneVnpk * whpkSellPrice * -1;// damage will be
																										// negative
		}

		return totalExpectedDamageCostForItem;
	}

	@Step
	public double getTotalDamageCostDataFromDB(PoLineDetail itemDetail) throws JsonProcessingException {
		ObjectMapper om = new ObjectMapper();
		double damageValueFromItem = 0;
		try {
			if (session == null || session.isClosed()) {
				session = casandra.connectToDb();
			}
			if (Config.DC == DC_TYPE.THOR) {
				String itemNumber = JsonPath.read(om.writeValueAsString(itemDetail), "$.itemNumber");
				List<String> adjustmentCode = JsonPath.read(om.writeValueAsString(itemDetail),
						"$.receivingInstructions[*].adjustmentCode");
				queryHelper.setQueryParam("itemNumber", itemNumber);
				queryHelper.setQueryParam("adjustment_code", adjustmentCode.get(0));

				queryHelper.setQueryParam("src_number", environment.getProperty(THOR_DC_NUMBER));
				String damageQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_ADJUSTMENT_THOR);
				logger.info("Adjustment query:{}", damageQuery);
				queryResult = casandra.executeQuery(session, damageQuery);
				double adjustedValueForItem = parseResultSet(queryResult, DAMAGE_DB_COL_NAME);
				logger.info("Actual Damage cost for item:{} is :{}", itemNumber, adjustedValueForItem);
				damageValueFromItem = adjustedValueForItem;
			} else {
				List<String> damageContrArr = JsonPath.read(om.writeValueAsString(itemDetail),
						"$.receivingInstructions[*].damageContainer");
				queryHelper.setQueryParam("source_number", environment.getProperty("dcNumber"));
				for (String damageContainer : damageContrArr) {
					queryHelper.setQueryParam("parent_container", damageContainer);
					String damageQuery = queryHelper
							.getSQLQueryParam(Queries.DC_FIN_DAMAGE_DATA_PARENT_CONTAINER_QUERY);
					logger.info("Damage query:{}", damageQuery);
					queryResult = casandra.executeQuery(session, damageQuery);
					double damageValueForContainer = parseResultSet(queryResult, DAMAGE_DB_COL_NAME);
					logger.info("Actual Damage cost for container(From DB):{} is :{}", damageContainer,
							damageValueForContainer);
					damageValueFromItem += damageValueForContainer;
				}
			}

		} catch (ReadFailureException e) {
			throw new TestCaseFailure(ErrorCodes.DC_FIN_NO_DATA_FOUND, e);
		} finally {
			if (casandra != null)
				casandra.closeSession();
		}
		return damageValueFromItem;
	}

	public double getPurchaseDataForReceiveQty(boolean isPurchaseValidation) {

		int noOfWhpkInOneVnpk;
		int whpk;
		int vnpk;
		double whpkSellPrice;

		try {

			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

			List<PoDetail> poDetails;
			JSONArray poDetailsArray = JsonPath.read(testFlowData, PO_DETAIL_PATH);
			poDetails = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsArray.toJSONString(), PoDetail.class);
			for (PoDetail poDetail : poDetails) {
				if (!(poDetail.getChannelMethod().equalsIgnoreCase("POCON") || poDetail.getChannelMethod().equalsIgnoreCase("DSDC"))) {
				String poNumber = poDetail.getPoNumber();
				logger.info("Processing for PO Number:{} ", poNumber);
				List<PoLineDetail> poLineDetails = poDetail.getPoLineDetails();
				for (PoLineDetail poLineDetail : poLineDetails) {
					int receivedQty = 0;
					whpk = Integer.parseInt(poLineDetail.getWhpk());
					vnpk = Integer.parseInt(poLineDetail.getVnpk());
					if (isPurchaseValidation && Config.DC == DC_TYPE.ATLAS && (Config.ENV == ENVIRONMENT.QA
							|| Config.ENV == ENVIRONMENT.DEV || Config.ENV == ENVIRONMENT.CERT)) {
						Map<String, String> map = getDCFinPurchaseValues(
								Integer.parseInt(poLineDetail.getPoLineNumber()), poNumber);
						whpkSellPrice = Double.parseDouble(map.get(WHPK_COST_FIELD));
						whpk = Integer.parseInt(map.get(WHPK_QTY_FIELD));

					} else {

						whpkSellPrice = Double.valueOf(poLineDetail.getWhpkSellPrice());
					}

					noOfWhpkInOneVnpk = vnpk / whpk;
					logger.info("Number of whpk qty in one vnpk " + noOfWhpkInOneVnpk);
					List<ReceivingInstruction> receivingInstructions = poLineDetail.getReceivingInstructions();

					String labelType = null;

					for (ReceivingInstruction instruction : receivingInstructions) {
						if (Config.DC == DC_TYPE.ACC) {
							if (instruction.getLabelType() != null || !instruction.getLabelType().isEmpty()) {
								labelType = instruction.getLabelType();
							}
							if ((!instruction.getIsPbyl()||!instruction.getIsPbylTripExecuted())&&(isPurchaseValidation||instruction.getIsShipOut()) && (labelType == null || labelType.equals("normal"))) {
								receivedQty = receivedQty + Integer.parseInt(instruction.getReceivedQuantity());
							}
						} else if (Config.DC == DC_TYPE.THOR) {
							if (isPurchaseValidation) {
								receivedQty = receivedQty
										+ (Integer.parseInt(instruction.getReceivedQuantity()) / vnpk);
							} else {
								receivedQty = receivedQty + (instruction.getSalesQty());
							}

						}
						else {
							if ((!instruction.getIsPbyl()||!instruction.getIsPbylTripExecuted())&&(isPurchaseValidation||instruction.getIsShipOut())&& !instruction.getIsGFCS())
								receivedQty = receivedQty + Integer.parseInt(instruction.getReceivedQuantity())-noOfUnloadedContainers(instruction);
						}
					}

					logger.info("Received qty " + receivedQty);
					logger.info("whpkSellPrice " + whpkSellPrice);
					if (isPurchaseValidation) {
						purchaseValueFromReceiveQty = purchaseValueFromReceiveQty
								+ (noOfWhpkInOneVnpk * whpkSellPrice * receivedQty);
						logger.info("purchase Value From Received qty:{}", purchaseValueFromReceiveQty);

					} else {
						if (Config.DC == DC_TYPE.THOR) {
							double purchaseValueFromReceiveQtyWithoutRoundOff = ((receivedQty * whpkSellPrice) / whpk);
							purchaseValueFromReceiveQty = purchaseValueFromReceiveQty
									+ Math.round(purchaseValueFromReceiveQtyWithoutRoundOff * 100.0) / 100.0;
						} else {
							purchaseValueFromReceiveQty = purchaseValueFromReceiveQty
									+ (noOfWhpkInOneVnpk * whpkSellPrice * receivedQty);
						}
					}

				}
				}

			}
		} catch (IOException e) {
			throw new AutomationFailure("Unable to calculate received qty", e);
		}
		return purchaseValueFromReceiveQty;

	}

	private String getDateString(int days) {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(dateCal(days));
	}

	private Date dateCal(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}

	private Double parseResultSet(ResultSet data, String colName) {

		double sumOfPurchase = 0;

		for (Row row : data) {
			sumOfPurchase = sumOfPurchase + row.getDecimal(colName).doubleValue();
			// logger.info("Value from DB:{}", sumOfPurchase);
		}
		return sumOfPurchase;
	}

	@Step
	public void validatePurchase() {
		try {
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			Double pFromReceiveQty = getPurchaseDataForReceiveQty(true);
			Failsafe.with(retryPolicy).run(() -> {
				Double pValueFromDB = getPurchaseDataFromDB();
				Assert.assertEquals(ErrorCodes.DC_FIN_PURCHASE_VALIDATION, pFromReceiveQty, pValueFromDB, DELTA);
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Validating the purchase", e);
		}
	}

	@Step
	public void validateSale() {

		try {
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			Double pFromReceiveQty = getPurchaseDataForReceiveQty(false);
			Failsafe.with(retryPolicy).run(() -> {
				Double sValueFromDB = null;
				if (Config.DC == DC_TYPE.THOR) {
					sValueFromDB = getSalesDataFromDBForThor();
				} else {
					sValueFromDB = getSalesDataFromDB();
				}

				Assert.assertEquals(ErrorCodes.DC_FIN_SALES_VALIDATION, pFromReceiveQty, sValueFromDB, DELTA);
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Validating the Sales", e);
		}
	}
	
	public Map<String, String> getDCFinPurchaseValues(int lineNo, String poNumber) {
		String dcFinUrl = MessageFormat.format(endpoints.getProperty("dc_fin_oms_ep"), poNumber);
		Response omsResponse = SerenityRest.given().get(dcFinUrl);
		String jsonObject;
		Map<String, String> map = new HashMap<>();
		try {
			jsonObject = XML.toJSONObject(omsResponse.getBody().asString()).toString();

			net.minidev.json.JSONObject omsPoObj = jsonUtils.convertStringToMinidevJsonObject(jsonObject);
			String omsRespStr = omsPoObj.toJSONString();

			List<String> val1 = JsonPath.read(omsRespStr, "$..omspol[?(@.opolnbr==" + lineNo + ")].whpkqty");
			List<String> val2 = JsonPath.read(omsRespStr, "$..omspol[?(@.opolnbr==" + lineNo + ")]..whpksellcostamt");

			map.put(WHPK_QTY_FIELD, String.valueOf(val1.get(0)));
			map.put(WHPK_COST_FIELD, String.valueOf(val2.get(0)));
			logger.info("DC Fin mock Values:{}", map);

		} catch (Exception e) {
			logger.error(e);
			map.put(WHPK_QTY_FIELD, "1");
			map.put(WHPK_COST_FIELD, "" + WHPK_SELL_PRICE_ATLAS);
			logger.info("DC Fin mock Values:{}", map);
		}
		return map;
	}

	@Step
	public void validateGdisPosting() {
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> deliveryNumberList = null;
		if (Config.DC == DC_TYPE.THOR) {
			deliveryNumberList = JsonPath.parse(testFlowData).read("$..poDetails[*].thorPO");
		} else {
			deliveryNumberList = JsonPath.parse(testFlowData).read("$..deliveryNumber");
		}
		String deliveryNumber = deliveryNumberList.get(0);

		try {
			List<String> poNumbers = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");
			for (String poNumber : poNumbers) {

				List<String> itemsInPo = JsonPath.parse(testFlowData)
						.read("$..poDetails[?(@.poNumber == '" + poNumber + "')]..itemNumber");
				int poLineNumber = 0;

				for (String item : itemsInPo) {

					List<String> itemQuantity = JsonPath.parse(testFlowData)
							.read("$..poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber == '"
									+ item + "')].receivingInstructions[?(@.isPbyl == false||@.isPbylTripExecuted==false)].receivedQuantity");
					List<String> poLineNumberList = JsonPath.parse(testFlowData)
							.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
									+ "')].poLineDetails[?(@.itemNumber == '" + item + "')].poLineNumber");
					poLineNumber = Integer.parseInt(poLineNumberList.get(0));
					List<String> vnpkList = JsonPath.parse(testFlowData).read("$..poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber == '" + item + "')].vnpk");
					int itemQty = 0;
					int vnpk = Integer.parseInt(vnpkList.get(0));
					List<String> whpkList = JsonPath.parse(testFlowData).read("$..poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber == '" + item + "')].whpk");
					int whpk = Integer.parseInt(whpkList.get(0));
					for (int i = 0; i < itemQuantity.size(); i++) {

						itemQty += Integer.parseInt(itemQuantity.get(i));
					}
					logger.info("Total item Qty for item {} from test flow data is:{} ", item, itemQty);
					if (Config.DC == DC_TYPE.THOR) {
						itemQtyWhpk = (itemQty / vnpk) * (vnpk / whpk);
					} else {
						itemQtyWhpk = getItemQtyWhpk(itemQty, poLineNumber, vnpk, poNumber);
					}

					Failsafe.with(retryPolicy).run(() -> {
						itemQtyWhpkDb = getItemQtyDb(poNumber, item, deliveryNumber);
						itemQtyWhpkDb=itemQtyWhpkDb/whpk;
						Assert.assertEquals(ErrorCodes.DC_FIN_GDIS_VALIDATION_FAILED, itemQtyWhpk, itemQtyWhpkDb);
					});
				}
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating GDIS Posting in DCFin", e);
		}

	}

	private int getItemQtyWhpk(int itemQty, int poLineNumber, int vnpk, String poNumber) {
		int itemqtyInWhpk = 0;
		int whpk = 0;
		Map<String, String> map = getDCFinPurchaseValues(poLineNumber, poNumber);
		whpk = Integer.parseInt(map.get(WHPK_QTY_FIELD));
		itemqtyInWhpk = (itemQty * vnpk) / whpk;
		return itemqtyInWhpk;
	}

	private int getItemQtyDb(String poNumber, String item, String deliveryNumber) {
		String gdisQuery;
		gdisQuery = constructGdisQuery(poNumber, deliveryNumber, item);
		
		List<Map<String, Object>> queryResult = dbUtils.selectFrom(PRODUCT_NAME.DCFIN,
				gdisQuery);
			
		return Integer.valueOf(queryResult.get(0).get("qty_in_eaches").toString());
	}

	private String constructGdisQuery(String poNumber, String deliveryNumber, String item) {

		queryHelper.setQueryParam("poNumber", poNumber);
		queryHelper.setQueryParam("deliveryNumber", deliveryNumber);
		queryHelper.setQueryParam("itemNumber", item);
		String gdisQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_GDIS_QUERY);
		logger.info("GDIS query: " + gdisQuery);
		return gdisQuery;

	}

	private int getGdisData(ResultSet data, String colName) {

		int itemQty = 0;
		for (Row row : data) {
			itemQty = row.getInt(colName);
		}

		return itemQty;
	}

	@Step
	public void validateOsdrPosting() {
		try {
		logger.info("Validating OSDR posting of GDM in DCFinancials");
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> deliveryNumberList = null;
		if (Config.DC == DC_TYPE.THOR) {
			deliveryNumberList = JsonPath.parse(testFlowData).read("$..poDetails[*].thorPO");
		} else {
			deliveryNumberList = JsonPath.parse(testFlowData).read("$..deliveryNumber");
		}
		String deliveryNumber = deliveryNumberList.get(0);

		List<String> poNumbers = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[*].poNumber");

		for (String poNumber : poNumbers) {

			List<String> itemsInPo = JsonPath.parse(testFlowData)
					.read("$..poDetails[?(@.poNumber == '" + poNumber + "')]..itemNumber");
			for (String item : itemsInPo) {
				int recievdQty = 0;

				List<String> itemQuantity = JsonPath.parse(testFlowData)
						.read("$..poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber == '"
								+ item + "')].receivingInstructions[?(@.isPbyl == false||@.isPbylTripExecuted==false)].receivedQuantity");
				recievdQty += sumListofString(itemQuantity);

				List<String> poQuantity = JsonPath.parse(testFlowData)
						.read("$..poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber == '" 
						+ item + "')].poVnpkQty");
				int poTotalQty = sumListofString(poQuantity);
				logger.info("In TestFlow Data Received Qty for PO Number: {} is:{} and poQuantity is :{} ", poNumber,
						recievdQty, poTotalQty);
				String osdr = null;
				int delta = 0;
				if (Config.DC == DC_TYPE.THOR) {
					List<String> vnpkList = JsonPath.parse(testFlowData).read("$..poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.itemNumber == '" + item + "')].vnpk");
					int vnpk = Integer.parseInt(vnpkList.get(0));
					List<Integer> damageQuantity = JsonPath.parse(testFlowData)
							.read("$..poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.itemNumber == '"
									+ item + "')]..receivingInstructions[*].damageQty");
					int damagedQty = (damageQuantity.get(0)) / vnpk;
					receivedQtyInVNPK = recievdQty / vnpk;
					delta = damagedQty;
					osdr = DAMAGE;

					// additional validation for Thor
					Failsafe.with(retryPolicy).run(() -> {
						String osdrJsonMessage = getOSDRForThor(deliveryNumber);
						List<Integer> osdrDBDamageQty = JsonPath.parse(osdrJsonMessage)
								.read("$.[?(@.deliveryNumber == '" + deliveryNumber + "')]..damage");
						List<Integer> osdrDBReceivedQty = JsonPath.parse(osdrJsonMessage)
								.read("$.[?(@.deliveryNumber == '" + deliveryNumber + "')]..totalCaseReceived");
						List<Integer> osdrDBFBQ = JsonPath.parse(osdrJsonMessage)
								.read("$.[?(@.deliveryNumber == '" + deliveryNumber + "')]..multiFreightBillQty");

						Assert.assertEquals(ErrorCodes.THOR_OSDR_RECEIVED_QTY_MISMATCH, receivedQtyInVNPK,
								osdrDBReceivedQty.get(0));
						Assert.assertEquals(ErrorCodes.THOR_OSDR_DAMAGE_QTY_MISMATCH, damagedQty,
								osdrDBDamageQty.get(0));
						Assert.assertEquals(ErrorCodes.THOR_OSDR_FBQ_QTY_MISMATCH, receivedQtyInVNPK + damagedQty,
								osdrDBFBQ.get(0));
					});
				} else {
					delta = poTotalQty - recievdQty;
					if (delta > 0)
						osdr = SHORTAGE;
					else if (delta < 0)
						osdr = OVERAGE;
					else
						osdr = NO_OSDR;
				}
				int deltaFailSafe = delta;
				String osdrFailsafe = osdr;
				Failsafe.with(retryPolicy).run(() -> {
					Assert.assertEquals(ErrorCodes.DC_FIN_OSDR_INCORRECT, Math.abs(deltaFailSafe),
							getDcFinOsdr(deltaFailSafe, osdrFailsafe, deliveryNumber, poNumber));
				});
			}
		}
		}catch(AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validating OSDR",e);
		}
	}

	private String getOSDRForThor(String deliveryNumber) {
		if (session == null || session.isClosed()) {
			session = casandra.connectToDb();
		}
		queryHelper.setQueryParam("delivery_number", deliveryNumber);
		String osdrQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_OSDR_QUERY_THOR);
		logger.info("OSDR query in DCFin: " + osdrQuery);
		queryResult = casandra.executeQuery(session, osdrQuery);
		return getOsdrMessage(queryResult, "original_payload");
	}

	private int getDcFinOsdr(int delta, String osdr, String deliveryNumber, String poNumber) {

		if (session == null || session.isClosed()) {
			session = casandra.connectToDb();
		}
		String osdrQuery;
		osdrQuery = constructOsdrQuery(deliveryNumber, poNumber);
		queryResult = casandra.executeQuery(session, osdrQuery);
		logger.info("Delta Value in OSDR is: {}", delta);
		switch (osdr) {
		case SHORTAGE:
			logger.info("Validating the shortage in this delivery");
			int shortageQty = getOsdrData(queryResult, "shortage_qty");
			logger.info("Shortage qty in DCFin is:{}", shortageQty);
			return shortageQty;
		case OVERAGE:
			logger.info("Validating the overrage in this delivery");
			int overageQty = getOsdrData(queryResult, "overage_qty");
			logger.info("Overrage qty in DCFin is:{}", overageQty);
			return overageQty;
		case DAMAGE:
			logger.info("Validating the damage in this delivery");
			int damageQty = getOsdrData(queryResult, "damage_qty");
			logger.info("Damage qty in DCFin is:{}", damageQty);
			return damageQty;
		default:
			logger.info("No OSDR found in this delivery");
			return 0;
		}

	}

	private int getOsdrData(ResultSet queryResult, String colName) {

		int osdrData = 0;
		List<Row> rows = queryResult.all();
		if (!rows.isEmpty()) {
			for (Row row : rows)
				osdrData = row.getInt(colName);
		} else {
			osdrData = 0;
		}
		return osdrData;
	}

	private String getOsdrMessage(ResultSet queryResult, String colName) {

		String osdrData = null;
		List<Row> rows = queryResult.all();
		if (!rows.isEmpty()) {
			for (Row row : rows)
				osdrData = row.getString(colName);
		}
		return osdrData;
	}

	private String constructOsdrQuery(String deliveryNumber, String poNumber) {

		queryHelper.setQueryParam("deliveryNumber", deliveryNumber);
		queryHelper.setQueryParam("poNumber", poNumber);
		String osdrQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_OSDR_QUERY);
		logger.info("OSDR query in DCFin: " + osdrQuery);
		return osdrQuery;

	}

	private int sumListofString(List<String> itemQuantity) {

		int sum = 0;
		for (int i = 0; i < itemQuantity.size(); i++) {

			sum += Integer.parseInt(itemQuantity.get(i));
		}

		return sum;

	}

	@Step
	public void deleteThorDCFIN(String itemNbr) throws JsonProcessingException {
		ObjectMapper om = new ObjectMapper();
		double damageValueFromItem = 0;

		try {
			if (session == null || session.isClosed()) {
				session = casandra.connectToDb();
			}
			deleteSalesdata(itemNbr);
			deleteAdjustmentData(itemNbr);

		} catch (ReadFailureException e) {
			throw new TestCaseFailure(ErrorCodes.DC_FIN_NO_DATA_FOUND, e);
		} finally {
			if (casandra != null)
				casandra.closeSession();
		}
	}

	public void deleteSalesdata(String itemNbr) {

		queryHelper.setQueryParam("itemNbr", itemNbr);

		String selectSalesQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_SALES_DATA_THOR);
		logger.info("Sales Select query:{}", selectSalesQuery);
		queryResult = casandra.executeQuery(session, selectSalesQuery);
		List<Row> rows = queryResult.all();
		logger.info("rows to be deleted" + rows.size());
		if (!rows.isEmpty()) {
			for (Row row : rows) {

				queryHelper.setQueryParam(SOURCE_NBR, String.valueOf(row.getInt(SOURCE_NBR)));
				queryHelper.setQueryParam(SOURCE_CC, row.getString(SOURCE_CC));
				queryHelper.setQueryParam(DEPT_NO, String.valueOf(row.getInt(DEPT_NO)));
				queryHelper.setQueryParam(SALES_UNIQUE_ID, row.getString(SALES_UNIQUE_ID));
				queryHelper.setQueryParam(END_INV_SALES_DATE, row.getString(END_INV_SALES_DATE));

				String deleteSalesQuery = queryHelper.getSQLQueryParam(Queries.DELETE_THOR_SALES_DATA);
				logger.info("Sales delete query:{}", deleteSalesQuery);
				queryResult = casandra.executeQuery(session, deleteSalesQuery);
				logger.info("queryResult:{}", queryResult);
			}
		}

	}

	public void deleteAdjustmentData(String itemNbr) {

		queryHelper.setQueryParam("itemNbr", itemNbr);

		String selectSalesQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_ADJUSTMENT_DATA_THOR);
		logger.info("Adjustment Select query:{}", selectSalesQuery);
		queryResult = casandra.executeQuery(session, selectSalesQuery);
		List<Row> rows = queryResult.all();
		logger.info("rows to be deleted" + rows.size());
		if (!rows.isEmpty()) {
			for (Row row : rows) {

				queryHelper.setQueryParam(SOURCE_NBR, String.valueOf(row.getInt(SOURCE_NBR)));
				queryHelper.setQueryParam(SOURCE_CC, row.getString(SOURCE_CC));
				queryHelper.setQueryParam(DEPT_NO, String.valueOf(row.getInt(DEPT_NO)));
				queryHelper.setQueryParam(ADJUSTMENT_UNIQUE_ID, row.getString(ADJUSTMENT_UNIQUE_ID));
				queryHelper.setQueryParam(END_INV_ADJUSTMENT_DATE, row.getString(END_INV_ADJUSTMENT_DATE));

				String deleteSalesQuery = queryHelper.getSQLQueryParam(Queries.DELETE_THOR_ADJUSTMENT_DATA);
				logger.info("Adjustment delete query:{}", deleteSalesQuery);
				queryResult = casandra.executeQuery(session, deleteSalesQuery);
				logger.info("queryResult:{}", queryResult);
			}
		}

	}
	public int noOfUnloadedContainers(ReceivingInstruction instruction) {
		List<String> unloadedCtrs = JsonPath.read(testFlowData,
				"$.testFlowData.outboundDetails[*].unloadedContainers[*]");
		if(unloadedCtrs.isEmpty())
			return 0;
		List<String> containers=new ArrayList<String>();
		containers.add(instruction.getParentContainer());
		containers.addAll(instruction.getChildContainers());
		
		int totalUnloadedContainersForInstruction=0;
		for(String unloadedContainer:unloadedCtrs) {
			if(containers.contains(unloadedContainer)) {
				logger.info("Container {} is unloaded",unloadedContainer);
				totalUnloadedContainersForInstruction++;
			}
		}
		if(totalUnloadedContainersForInstruction>0) {
			logger.info("Total Unloaded containers={}",totalUnloadedContainersForInstruction);
		}
		return totalUnloadedContainersForInstruction;
	}
	
	@Step
	public void cleanDCfinDB(List<String> poNumberList, List<String> itemList) {
		try {
			if (session == null || session.isClosed()) {
				session = casandra.connectToDb();
		}
		for (String poNum : poNumberList) {
			String poCleanQuery;
			poCleanQuery = constructPOCleanUP(poNum);
			casandra.executeQuery(session, poCleanQuery);
			logger.info("PO data cleaned in DCFin");
		}
//		for (String itemNum : itemList) {
//			String itemCleanQuery;
//			itemCleanQuery = constructItemCleanUP(itemNum);
//			casandra.executeQuery(session, itemCleanQuery);
//			logger.info("Item data cleaned in DCFin");
//		}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while cleaning data in DCfin", e);
		}
		finally {
			casandra.closeSession();
		}
	}
	
	private String constructItemCleanUP(String item) {
		queryHelper.setQueryParam("sourceNumber", environment.getProperty("facility_num"));
		queryHelper.setQueryParam("source_CC", environment.getProperty("country_code"));
		queryHelper.setQueryParam("itemNumber", item);
		String itemCleanUpQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_ITEM_DATA_CLEAN);
		logger.info("Item cleanUp query: " + itemCleanUpQuery);
		return itemCleanUpQuery;
	}
	
	private String constructPOCleanUP(String poNumber) {
		queryHelper.setQueryParam("sourceNumber", environment.getProperty("facility_num"));
		queryHelper.setQueryParam("source_CC", environment.getProperty("country_code"));
		queryHelper.setQueryParam("poNumber", poNumber);
		String poCleanUpQuery = queryHelper.getSQLQueryParam(Queries.DC_FIN_PO_DATA_CLEAN);
		logger.info("PO cleanUp query: " + poCleanUpQuery);
		return poCleanUpQuery;
	}
}