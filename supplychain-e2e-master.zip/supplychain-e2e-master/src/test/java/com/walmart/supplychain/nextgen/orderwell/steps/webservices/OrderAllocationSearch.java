package com.walmart.supplychain.nextgen.orderwell.steps.webservices;

public class OrderAllocationSearch {

    private String itemNumber, poNbr, channelMethod;


    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getPoNbr() {
        return poNbr;
    }

    public void setPoNbr(String poNbr) {
        this.poNbr = poNbr;
    }

    public String getChannelMethod() {
        return channelMethod;
    }

    public void setChannelMethod(String channelMethod) {
        this.channelMethod = channelMethod;
    }
}
