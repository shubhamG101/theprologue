package com.walmart.supplychain.nextgen.inventory.pages.web;

import com.jayway.jsonpath.DocumentContext;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class InventoryWebVtrPage extends SerenityHelper {

    @Autowired
    Environment endpoint;

    @Autowired
    Environment environment;

    Response response;
    List<String> splitQty;

    private DocumentContext parsedJson;

    Logger logger = LogManager.getLogger(this.getClass());

    // WebDriver driver;
    RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
            Constants.RETRY_EXECUTION_COUNT);

    @FindBy(xpath = "//p[text()='Inventory']")
    private WebElement inventoryPage;

    @FindBy(id = "siteNumber")
    private WebElement siteNumber;

    @FindBy(xpath = "//h2[text()='Please enter the DC number you would like to access!']")
    private WebElement textField;

    @FindBy(xpath = "//label[text()='Select site Id']")
    private WebElement SiteNumber;
    
    @FindBy(id = "single-select-simple-option-US-32898")
    private WebElement chooseSite;

    @FindBy(id = "site-id-button")
    private WebElement siteIdBtn;

    @FindBy(xpath = "//span[text()='Advanced Search']")
    private WebElement advanceSearchBtn;

    @FindBy(id = "deliveryNumber")
    private WebElement deliveryNumber;

    @FindBy(id = "poNumber")
    private WebElement poNumber;

    @FindBy(xpath = "//div[@class='ld-sc-ui-modal-footer-content-standard']/button[2]")
    private WebElement search;

    @FindBy(xpath = "//label[@for='selectAll']")
    private WebElement selectAllCheckBox;

    @FindBy(xpath = "//span[text()='Create Exception']")
    private WebElement createException;

    @FindBy(xpath = "//span[text()='View All']")
    private WebElement viewAllcntr;

    @FindBy(xpath = "//label[text()='Adjustment Reason']")
    private WebElement clickonDropdown;

    @FindBy(xpath = "//li[@id='single-select-simple-option-Void to Reinstate']")
    private WebElement selectVTRFromDropDown;

    @FindBy(xpath = "//input[@id='default-input']")
    private WebElement commentBox;

    @FindBy(xpath = "//span[text()='Submit']")
    private WebElement submitBtn;

    @FindBy(xpath = "//p[text()='Do you want to continue the operation for containers for which creation is allowed?']")
    private WebElement successfulVTRMsg;

    @FindBy(xpath = "//span[text()='Continue']")
    private WebElement continueBtn;

    @FindBy(xpath = "//p[text()='Containers Adjusted Successfully:']")
    private WebElement getSuccessfulMsg;

    @FindBy(xpath = "//span[text()='Close']")
    private WebElement closeBtn;

    Boolean loadedException;
    Boolean vtrException;

    @FindBy(xpath = "//h2[contains(text(),'Delivery for the container has already been finalized.')]")
    private WebElement vtrFinalException;

    public void bulkVTRInWeb(String delNum, String poNum) {
        try {
            WebDriver driver = getDriverInstance();
            Set<String> windowIds = driver.getWindowHandles();
            String parent = driver.getWindowHandle();
            Iterator<String> I1 = windowIds.iterator();
            while (I1.hasNext()) {
                String child_window = I1.next();
                if (!parent.equals(child_window)) {
                    driver.switchTo().window(child_window);
                    element(inventoryPage).waitUntilVisible();
                    element(advanceSearchBtn).waitUntilVisible();
                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                    jse.executeScript("arguments[0].click()", element(advanceSearchBtn));
                    sleep(20);
                    element(deliveryNumber).waitUntilVisible();
                    element(deliveryNumber).click();
                    element(deliveryNumber).sendKeys(delNum);

                    element(deliveryNumber).waitUntilVisible();
                    element(poNumber).click();
                    element(poNumber).sendKeys(poNum);

                    element(search).waitUntilEnabled();
                    element(search).click();

                    element(selectAllCheckBox).waitUntilVisible();
                    element(selectAllCheckBox).waitUntilClickable();
                    element(selectAllCheckBox).click();

                    element(createException).waitUntilEnabled();
                    element(createException).waitUntilClickable();
                    element(createException).click();

                    element(clickonDropdown).waitUntilClickable();
                    element(clickonDropdown).click();
                    element(selectVTRFromDropDown).click();
                    element(commentBox).sendKeys("proceed with VTR");

                    element(submitBtn).waitUntilEnabled();
                    element(submitBtn).click();
                    sleep();
                    element(successfulVTRMsg).waitUntilVisible();

                    element(continueBtn).waitUntilVisible();
                    element(continueBtn).waitUntilClickable();
                    element(continueBtn).click();
                    sleep();
                    element(getSuccessfulMsg).waitUntilVisible();

                    element(closeBtn).waitUntilEnabled();
                    element(closeBtn).click();
                    sleep();
                    driver.close();
                    driver.switchTo().window(parent);
                    logger.info("VTR has been done for all received containers");
                }
            }

        } catch (Exception e) {
            throw new AutomationFailure("Unable to perform VTR", e);
        }
    }
}
