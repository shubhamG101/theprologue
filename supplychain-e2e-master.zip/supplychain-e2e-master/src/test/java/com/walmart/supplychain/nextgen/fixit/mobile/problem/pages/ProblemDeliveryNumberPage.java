package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.jms.DC_TYPE;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.google.common.base.Predicate;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.webdriver.WebDriverFacade;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.base.Predicate;
import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.PressesKey;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

public class ProblemDeliveryNumberPage extends MobilePageObject {

	Logger logger = LogManager.getLogger(this.getClass());

	public ProblemDeliveryNumberPage(WebDriver driver){
		super(driver);
	}

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Delivery Number']")
	public WebElement deliveryNumber_Text;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	public WebElement next_Button;

	@AndroidFindBy(xpath = "//android.widget.ImageButton[@resource-id='com.walmart.move.nim.fixit.mobile:id/fab']")
	public WebElement plusSignCreateTicket_Icon;

	//RDC changes
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_deliveryNumber']")
	private WebElement deliveryNumberManifest_Textbox;

	//login
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/dc_site_id_edit_text']")
	private WebElement dcNumber_Textbox;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/confirm_location_fab']")
	private WebElement nextArrow;

	@AndroidFindBy(xpath = "//*[@text='Sign in using user name']")
	private WebElement sign_Button;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/shared_login_username_edit_text']")
	private WebElement userName_Textbox;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/shared_login_password_edit_text']")
	private WebElement password_Textbox;

	@AndroidFindBy(xpath = "//*[@text='SIGN IN']")
	private WebElement dcSign_Button;

	@AndroidFindBy(xpath = "//android.view.View[contains(@text,'SC-FIXit')]")
	private WebElement fixitApp;

	//NextGen
	@AndroidFindBy(id = "com.walmart.auth.app:id/userid")
	private WebElement userid;

	@AndroidFindBy(id = "com.walmart.auth.app:id/password")
	private WebElement password;

	@AndroidFindBy(id = "com.walmart.auth.app:id/site_id")
	private WebElement site_id;

	@AndroidFindBy(id = "com.walmart.auth.app:id/domain")
	private WebElement locationType;

	@AndroidFindBy(id = "com.walmart.auth.app:id/sign_in")
	private WebElement sign_in_Btn;

	@AndroidFindBy(id = "com.walmart.auth.app:id/userid")
	private WebElement myAppsTitle;

	@AndroidFindBy(xpath = "//android.widget.Button")
	public WebElement menu_Icon;

	@AndroidFindBy(xpath = "//*[@text='exit_to_app Sign Out']")
	private WebElement signOut_Button;

	//acc
	@AndroidFindBy(xpath = "//*[@text='Receiving']")
	private WebElement receiving_Button;

	@AndroidFindBy(xpath = "//*[@text='Delivery']")
	private WebElement delivery_Button;

	@AndroidFindBy(xpath = "//*[@text='LPN']")
	private WebElement lpn_Button;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/receive']")
	private WebElement receive_Button;
	
	
	/*public Problem_ScanPage enterDeliveryNumber(String deliveryNum) {
		AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),deliveryNumber_Text);
		deliveryNumber_Text.sendKeys(deliveryNum);
		AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),next_Button);
		next_Button.click();
		return new Problem_ScanPage(AppiumHelper.getWebdriverForPage());
	}*/

	private void clickOnPlustSignCreateTicket() {
		plusSignCreateTicket_Icon.click();
	}

	public void appSwitchFixitToReceiving() {
		element(receive_Button).waitUntilClickable();
		receive_Button.click();
		Boolean appSwitch = !getAndroidDriver().findElements(By.xpath("//*[@text='Receiving']")).isEmpty();
		Assert.assertTrue(ErrorCodes.FIXIT_MOBILE_APP_SWITCH_FAILED, appSwitch);
	}

	public void enterDeliveryNumber(String deliveryNum) {
		clickOnPlustSignCreateTicket();
		deliveryNumber_Text.sendKeys(deliveryNum);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}

	public void enterDeliveryManifestNumber(String deliveryNum) {
		clickOnPlustSignCreateTicket();
		String market = Config.DC.getValue();
		if(market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
			element(receiving_Button).waitUntilVisible();
			element(receiving_Button).click();
			element(delivery_Button).waitUntilVisible();
			element(delivery_Button).click();
			next_Button.click();
		}
		element(deliveryNumberManifest_Textbox).waitUntilVisible();
		element(deliveryNumberManifest_Textbox).type(deliveryNum);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return (AndroidDriver<AndroidElement>)
				((WebDriverFacade) getDriver()).getProxiedDriver();
	}

	public void loginIntoMyapp(String dcNumber,String user,String pass) {
		element(dcNumber_Textbox).waitUntilVisible();
		element(dcNumber_Textbox).type(dcNumber);
		getAndroidDriver().hideKeyboard();

		element(nextArrow).waitUntilClickable();
		element(nextArrow).click();

		element(sign_Button).waitUntilClickable();
		element(sign_Button).click();

		element(userName_Textbox).waitUntilVisible();
		element(userName_Textbox).type(user);

		element(password_Textbox).waitUntilVisible();
		element(password_Textbox).type(pass);
		getAndroidDriver().hideKeyboard();

		element(dcSign_Button).waitUntilClickable();
		element(dcSign_Button).click();

		element(fixitApp).waitUntilClickable();
		element(fixitApp).click();
	}

	public void loginNextGenMyapps(String userID, String pwd, String siteID) {

		getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if(!getAndroidDriver().findElements(By.xpath("//android.view.View[contains(@text,'SC-FIXit')]")).isEmpty()){
			logger.info("Fixit App is visible");
			launchFIXitApp();
		}else{
			logger.info("MyApps login page is visible");
			element(userid).waitUntilVisible();
			element(userid).sendKeys(userID);

			element(password).sendKeys(pwd);

			element(site_id).clear();
			element(site_id).sendKeys(siteID);

			element(sign_in_Btn).waitUntilClickable();
			element(sign_in_Btn).click();
		}
	}

	public void launchFIXitApp() {
		element(fixitApp).waitUntilVisible();
		element(fixitApp).waitUntilClickable();
		element(fixitApp).click();
	}

	public void logoutMyApps(){
		element(menu_Icon).waitUntilVisible();
		element(menu_Icon).click();
		element(signOut_Button).waitUntilVisible();
		element(signOut_Button).click();
	}
}