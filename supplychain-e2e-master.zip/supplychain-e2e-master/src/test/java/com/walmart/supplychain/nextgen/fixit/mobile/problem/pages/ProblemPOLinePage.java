package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class ProblemPOLinePage extends MobilePageObject{

	Logger logger = LogManager.getLogger(this.getClass());

	public ProblemPOLinePage(WebDriver driver){
		super(driver);
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	private WebElement next_Button;

	@AndroidFindBy(xpath = "(//*[@text='PO Line #'])[1]")
	private WebElement poFirst;

	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.walmart.move.nim.fixit.mobile:id/tb_notInList']")
	private WebElement itemNotInList_Button;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_header']")
	private WebElement tv_header;

	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_skip_po']")
	private WebElement skipPO_Button;

	public void selectPOLine() {
		selectPOFromList();
		next_Button.click();
	}

	private void selectPOFromList() {
		poFirst.click();
	}

	public void navigateToSelectNWF() {
		AppiumHelper.scrollToElementInMObile("PO line not found?", getAndroidDriver());
		element(itemNotInList_Button).waitUntilVisible();
		element(itemNotInList_Button).click();
		//AppiumHelper.scrollToElementInMObile("Item not found?", getAndroidDriver());
		getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if(!getAndroidDriver().findElements(By.id("com.walmart.move.nim.fixit.mobile:id/tb_notInList")).isEmpty()){
			logger.info("Item not found visible");
			//AppiumHelper.scrollToElementInMObile("Item not found?", getAndroidDriver());
			element(itemNotInList_Button).waitUntilClickable();
			element(itemNotInList_Button).click();
		}else{
			logger.info("Item not found button is not visible");
		}
	}

	public void navigateToSelectNOP() {
		AppiumHelper.scrollToElementInMObile("PO line not found?", getAndroidDriver());
		itemNotInList_Button.click();
	}

	public void skipPOSelection() {
		element(skipPO_Button).waitUntilVisible();
		element(skipPO_Button).click();
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
	    return (AndroidDriver<AndroidElement>)
	            ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
}
