package com.walmart.supplychain.nextgen.fixit;

import java.io.IOException;
import java.net.URISyntaxException;

import com.walmart.framework.utilities.jms.DC_TYPE;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.FixitMobileHomePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.strati.libs.commons.configuration.ConfigurationException;
import net.jodah.failsafe.FailsafeException;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;

public class FIXitEnd2EndScenarios {
	
	@Steps
	FIXitEnd2EndSteps fixitStep;
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Given ("^User modifies config to \"([^\"]*)\"$") 
	public void modifyConfigValue(String configValueCheck) {
		try {
			fixitStep.updateConfig(configValueCheck);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with switching web browser to mobile driver", e);
		}
	}
	
	@Given("^User create \"([^\"]*)\" problem ticket from fixit mobile$")
	 public void createProblemTicket(String problemName) {
		fixitStep.createProblemTicket(problemName);
	 }
	
	@Given("^User create \"([^\"]*)\" problem ticket from fixit web$")
	 public void createProblemTicketWeb(String problemName) {
		fixitStep.createProblemTicketWeb(problemName);
	 }
	
	 @Given("^user create \"([^\"]*)\" problem ticket from fixit mobile \"([^\"]*)\"$")
	 public void createProblemTicketForSams(String problemName,String dc) {
		fixitStep.createProblemTicketForSams(problemName);
	 }
	
	@When("^User login into \"([^\"]*)\" fixit web dashboard with dc \"([^\"]*)\"$")
	public void loginFixitWeb(String user,String dc) {
		fixitStep.loginOneTimeWebdashbaord(user,dc);
	}
	
//	 @Then("^User verifies problem ticket with \"([^\"]*)\" status for \"([^\"]*)\" user$")
//	 public void verifyProblemTicket(String resolution,String user) {
//		 fixitStep.verifyResolutionTicket(resolution, user);
//	 }
	 
//	 @Then("^User verifies problem ticket with \"([^\"]*)\" status for \"([^\"]*)\" user gdc$")
//	 public void verifyProblemTicketGdc(String resolution,String user) {
//		 fixitStep.verifyResolutionTicketGdc(resolution, user);
//	 }
	 
	@And("^User assigns problem ticket to \"([^\"]*)\" from TRACKER User$")
	public void assignProblemTicketToHO(String assignTogroup) {
		fixitStep.assigneProblemTicketTOHO(assignTogroup);
	}
	
	@When("^\"([^\"]*)\" User assigns problem to another user$") 
	public void hOAssignsToAnotherHO(String userName) {
		fixitStep.hoAssignsProblemToAnotherHO();
	}
	
	@When("^\"([^\"]*)\" User request for more info$")
	public void resolveUserRequestForMoreInfo(String userName) {
		fixitStep.hoRequestForMoreInfo();
	}
	
	@Then("^User resubmits problem ticket from \"([^\"]*)\" user$")
	public void dcUserResubmitsProblemTicket(String userName) {
		fixitStep.dcUserResubmitsProblemTicket(userName);
	}
	
	@Given("^User updates OMS PO \"([^\"]*)\"$")
	public void UpdateOMSPO(String resolutionName) {
		fixitStep.updateOMSPOForResolution(resolutionName);
	}
	
	
	@When("^User provides \"([^\"]*)\" resolution from \"([^\"]*)\" User$")
	public void provideResolutionForProblem(String resolutionName,String userName) {
		fixitStep.provideResolutionForProblem(resolutionName,userName, Config.DC.getValue());
	}
	
	@When("^User provides \"([^\"]*)\" resolution from \"([^\"]*)\" User for \"([^\"]*)\"$")
	public void provideResolution(String resolutionName,String userName,String market) {
		fixitStep.provideResolution(resolutionName,userName,market);
	}

	@When("^User provides \"([^\"]*)\" resolution edit from \"([^\"]*)\" User for \"([^\"]*)\"$")
	public void provideResolutionEdit(String resolutionName,String userName,String market) {
		fixitStep.provideResolutionEdit(resolutionName,userName,market);
	}

	@When("User edit the ticket and saves it")
	public void editTicket(){
		fixitStep.editTicket();
	}

	@Then("User edit the slot Id to \"([^\"]*)\"$")
	public void editSlot(String slotId){
		fixitStep.editSlot(slotId);
	}

	@When("^User provides \"([^\"]*)\" as disposition from web")
	public void provideDispositiontionForDamage(String dispositionName) {
		fixitStep.provideDispositionForDamage(dispositionName);
	}

	@When("^User modifies disposition to \"([^\"]*)\" from web")
	public void modifyDispositiontionForDamage(String dispositionName) {
		fixitStep.provideDispositionForDamage(dispositionName);
	}

	@When("^User cancels containers for the problem ticket")
	public void cancelContainers() {
		fixitStep.cancelContainers();
	}

	@Then("^User verifies problem ticket with \"([^\"]*)\" disposition type")
	public void verifyDispositiontionForDamage(String dispositionName) {
		fixitStep.verifyDispositionForDamage(dispositionName);
	}
	
	@When("^User search for problem ticket \"([^\"]*)\" in web dashboard from \"([^\"]*)\"$")
	public void searchProblemTicket(String searchCreteria,String user) {
		fixitStep.searchProblemTicket(searchCreteria,user);
	}

	@Then("^User search for the problem ticket$")
	public void searchProblemTicket() {
		fixitStep.searchProblemTicket();
	}

	@Then("^User verifies problem ticket is not visible$")
	public void verifyProblemTicketNotVisible() {
		fixitStep.verifyProblemTicketNotVisible();
	}
	
	 @Then("^User verifies problem ticket for \"([^\"]*)\"$")
	 public void verifyProblemDetails(String search) {
		 fixitStep.verifyProblemDetails();
	 }
	 
	 @Then("^user updates OMS PO \"([^\"]*)\"$")
	 public void updateOMSPO(String resolutionName) {
		 fixitStep.updateOMSPOForResolution(resolutionName);
	 }
	 
	 @When("^user validate resolution in fixit mobile app \"([^\"]*)\"$")
	 public void validateTicketResolution(String resolution) {
		 fixitStep.validateResolutionMobile(resolution);
	 }
	 
	 @When("^user canceled ticket from \"([^\"]*)\"$")
	 public void cancelTicket(String platform) {
		 fixitStep.cancelTicket(platform);
	 }
	 
	 @When("^user canceled ticket from \"([^\"]*)\" for gdc$")
	public void cancelTicketGdc(String platform) {
		fixitStep.cancelTicketGdc(platform);
	}

	 @When("^user cancels ticket from \"([^\"]*)\"$")
	 public void cancelTicketFromPlatform(String platform) {
		fixitStep.cancelTicketFromPlatform(platform);
	}

	@When("^user cancels damage ticket from \"([^\"]*)\"$")
	public void cancelDamageTicketFromPlatform(String platform) {
		fixitStep.cancelDamageTicketFromPlatform(platform);
	}
	 
	 @Then("^validate ticket status as \"([^\"]*)\"$")
	 public void validateCancelTikcet(String status) {
		 fixitStep.validateCanceledTicket(status,String.valueOf(Config.DC));
	 }
	 
	 @Then("^validate ticket status as \"([^\"]*)\" gdc$")
	 public void validateCancelTikcetGdc(String status) {
		 fixitStep.validateCanceledTicketGdc(status,String.valueOf(Config.DC));
	 }

	@Then("^user verifies ticket status should change to \"([^\"]*)\"$")
	public void verifyCancelTicket(String status) {
		fixitStep.verifyCancelledTicket(status,String.valueOf(Config.DC));
	}
	 
	 @When("^assign problem ticket to HO$")
	 public void assignProblemTikcetToHO() {
		 fixitStep.assignProblemTicketToHO();
	 }

	@When("^assign problem ticket to HO in mobile$")
	public void assignToHOMobile() {
		fixitStep.assignToHOMobile();
	}
	 	
	 @Then("validate ticket assigned to \"([^\"]*)\"$")
	 public void validateAssignedGroup(String group) {
		 fixitStep.validateAssignedGroup(group);
	 }
	 
	 @Then("user marks ticket resolved$")
	 public void markTicketResolved() {
		 fixitStep.markResolved();
	 }
	 
	 @Given("^user resolve problem ticket \"([^\"]*)\" for \"([^\"]*)\"$")
	 public void resolveProblemTicketForSams(String resolution,String dc) {

	 }
	 
	 @Then("^user verifies problem ticket in tracker user as \"([^\"]*)\"$")
	 public void verifyResolverTicket(String resolution) {
		 fixitStep.verifyResolverTicket(resolution);
	 }
	 
	 @Given("^user closing ticket from dashboard$")
	 public void closeWebTicket() {
		 fixitStep.closeWebTicket();
	 }
	 
//	 @Given("user creates \"([^\"]*)\" for the rdc mobile$")
//	 public void createRDCExceptionMobile(String exceptionName) {
//		 fixitStep.createRdcExceptionMobile(exceptionName);
//	 }
	 
//	 @Given("user creates \"([^\"]*)\" for the rdc web$")
//	 public void createRDCExceptionWeb(String exceptionName) {
//		 fixitStep.createRdcExceptionWeb(exceptionName);
//	 }
	 
	 @Given("user creates \"([^\"]*)\" damage for the \"([^\"]*)\" from mobile$")
	 public void createRdcDamageMobile(String damageType,String market) {
		 fixitStep.createRdcDamageMobile(damageType,market);
	 }
	 
	 @Given("user creates \"([^\"]*)\" damage for the rdc from web$")
	 public void createRdcDamageWeb(String damageType) {
		 fixitStep.createRdcDamageWeb(damageType);
	 }

	@When("user creates \"([^\"]*)\" damage from the web$")
	public void createDamageweb(String damageType) {
		fixitStep.createDamageWeb(damageType);
	}
	 
	 @Given("user creates \"([^\"]*)\" for the \"([^\"]*)\" mobile$")
	 public void createGDCExceptionMobile(String exceptionName,String market) {
		 fixitStep.createGdcExceptionMobile(exceptionName,market);
	 }

	@Given("user creates \"([^\"]*)\" ticket with \"([^\"]*)\" subtype from mobile$")
	public void createExceptionMobile(String exceptionName, String subtype) {
		fixitStep.createExceptionMobile(exceptionName, subtype);
	}



	@Given("user creates \"([^\"]*)\" damage from mobile$")
	public void createDamageMobile(String damageType) {
		fixitStep.createDamageMobile(damageType);
	}
	 
	 @Given("user login into myapp with dc \"([^\"]*)\"$")
	 public void loginIntoMyapp(String dc) {
		 fixitStep.loginIntoMyApp(dc);
	 }
	 
	 @Given("user reads test data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	 public void readTestData(String delivery,String upc,String ponumber) {
		 fixitStep.readTestData( delivery, upc, ponumber);
	 }
	 
	 @And("assign problem ticket to HO in web$")
	 public void assignToHo() {
		 fixitStep.assignToHO();
	 }

	@And("assign problem ticket to WFS Program in web$")
	public void assignToWFSprogram() { fixitStep.assignToWfsProgram(); }
	 
	 @Given("User launches FIXit through MyApps for \"([^\"]*)\" DC$")
	 public void launchFIXitThruNextGenMyApps(String dcType) {
		 fixitStep.launchFixitThruNextGenMyApps(dcType);
	 }

	@Then("User performs app switch to Receiving App")
	public void appSwitchFixitToReceiving() {
		fixitStep.appSwitchFixitToReceiving();
	}

	 @Then("User logs out from MyApps")
	 public void logoutMyApps(){
		fixitStep.logoutMyApps();
	 }
	 
	 @Given("^verify ticket assigned to \"([^\"]*)\" group$")
	 public void verifyAssignedGroup(String group) {
		 fixitStep.verifyGroup(group);
	 }
	 
	 @When("^assign problem ticket to \"([^\"]*)\"$")
	 public void assignToReplenishment(String groupName) {
		 fixitStep.assignToReplenishment(groupName);
	 }
	 
	 @And("^user adds bulk resolution from tracker user$")
	 public void addBulkResolution() {
		 fixitStep.addBulkResolution();
	 }


	 //adding for bulk comment
	@And("^user adds bulk comment from tracker user$")
	public void addBulkComment() {
		fixitStep.addBulkComment();
	}

	 
	 @Then("^user verifies \"([^\"]*)\" bulk resolution$")
	 public void verifyBulkResolution(String resolution) {
		 fixitStep.verifyBulkResolution(resolution);
	 }
	 
	 @Then("^user logged out from fixit app$")
	 public void logoutFixit() {
		 fixitStep.logoutFixit();
	 }
	 
	 @When("^user reassigns problem ticket to ho$")
	 public void reassignTicket() {
		 fixitStep.reassignTicket();
	 }
	 		
	@Then("^user verifies \"([^\"]*)\" status$")
	public void verifyReassignedStatus(String expectedStatus) {
		fixitStep.verifyStatus(expectedStatus);
	 }
	 
	@Then("^user verifies ticket \"([^\"]*)\" status and claim status as \"([^\"]*)\"$")
	public void verifyDamageTicket(String status,String claimStatus) {
		fixitStep.verifyDamageTicketStatus(status,claimStatus);
	 }

	@When("user creates \"([^\"]*)\" for the web$")
	public void createExceptionWeb(String exceptionName) {
		fixitStep.createExceptionWeb(exceptionName);
	}

	@When("user creates \"([^\"]*)\" dispute for web with \"([^\"]*)\" issue$")
	public void createDisputeExceptionWeb(String exceptionName, String issue_cause) {
		fixitStep.createDisputeExceptionWeb(exceptionName, issue_cause);
	}

	@Then("^User verifies problem ticket with \"([^\"]*)\" status for \"([^\"]*)\" user$")
	public void verifyProblemTicketWeb(String resolution,String user) {
		fixitStep.verifyResolutionTicketWeb(resolution, user);
	}

	@Then("^User asks for more information$")
	public void moreInfo() {
		fixitStep.moreInfo();
	}

	@Then("User must be able to export data")
	public void exportData(){
		fixitStep.exportData();
	}

	@Then("^User verifies metrics dashboard is \"([^\"]*)\"")
	public void verifyMetricsDashboard(String presence) { fixitStep.verifyMetricsDashboard(presence);}

	@Then("User reprints label from fixit App")
	public void reprintLabelMobile(){
		fixitStep.reprintLabelMobile();
	}

	@Then("user creates \"([^\"]*)\" damage using API for GFCS$")
	public void createCPDamage(String damageLocation){
		fixitStep.createDamage(damageLocation);
	}
}