package com.walmart.supplychain.catalyst.by.ui.pages;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.WebElementFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYQcDashboardPage  extends SerenityHelper{
	
	Logger logger = LogManager.getLogger(this.getClass());
	WebDriver driver;
	
	@Autowired
	CatalystUtil catalystUtil;
	
	@FindBy(xpath = "//span[text()='Freight Dashboard']/parent::div[1]/following-sibling::a[1]//span[contains(@id,'btnIconEl')]")
	public WebElement freightDashboardExpansionButton;	
	
	@FindBy(xpath = "//span[@class='x-header-text -text -text-default'][normalize-space()='Freight Dashboard']")
	public WebElement freightDashboardHeading;
	
	@FindBy(xpath = "//iframe[contains(@name,'QC-Dashboard')]")
	public WebElement qcDashboardFrame;
	
	@FindBy(xpath = "//span[text()='Actions']/parent::span[@class='x-btn-button']")
	public WebElement actionsButton;
	
	@FindBy(xpath = "//span[normalize-space()='Change Inventory Status']")
	public WebElement changeInventoryStatusOption;
	
	@FindBy(xpath = "//label[text()='Invsts-Reacod']/parent::div[1]/following-sibling::table//div[contains(@class,'icon-expanded')]")
	public WebElement inventoryStatusCodeDropdown;
	
	@FindBy(xpath = "//li[@class='x-boundlist-item']")
	public WebElement inventoryStatusCodeDropdownList;
	
	@FindBy(xpath = "//span[text()='Execute Action']/following-sibling::span[1]")
	public WebElement executeActionButton;

	@FindBy(xpath = "//span[text()='Freight Dashboard']/parent::div/following-sibling::div[contains(@class,'x-tool x-box-item')]")
	public WebElement freightDashboardCloseButton;
	
	private WebElement getLpnCheckbox(String lpn) {
		return getDriver().findElement(By.xpath("//div[text()='"+lpn+"']/parent::td[1]/preceding-sibling::td[1]/div/div[@class='x-grid-row-checker']"));
	}
	
	//iframe[@id='rpIFrame-1129']
	public void clickOnFreightDashboardExpansionButton() {
		getDriverInstance().switchTo().frame(qcDashboardFrame);
		element(freightDashboardExpansionButton).waitUntilVisible();
		element(freightDashboardExpansionButton).click();
		logger.info("Clicked on Freight Dashboard Expansion Button in BY UI ==========");
	}
	
	public void verifyFreightDashboardHeading() {
		
		//getDriverInstance().switchTo().frame(qcDashboardFrame);
		catalystUtil.verifyElementIsDisplayed(freightDashboardHeading);
	}
	
	
	public void selectLpn(String lpn) {
		element(getLpnCheckbox(lpn)).waitUntilVisible();
		element(getLpnCheckbox(lpn)).click();
		logger.info("Clicked on Lpn checkbox in BY UI ==========");
	}
	
	public void clickOnActionsButton() {
		element(actionsButton).waitUntilVisible();
		element(actionsButton).waitUntilClickable();
		element(actionsButton).click();
		logger.info("Clicked on Actions Button in BY UI ==========");
	}
	
	public void clickOnChangeInventoryStatusOption() {
		element(changeInventoryStatusOption).waitUntilVisible();
		element(changeInventoryStatusOption).click();
		logger.info("Clicked on Change Inventory Status change in BY UI ==========");
	}
	
	public void clickOnInventoryStatusCodeDropdown() {
		element(inventoryStatusCodeDropdown).waitUntilVisible();
		element(inventoryStatusCodeDropdown).click();
		logger.info("Clicked on Inventory Status Code Dropdown Expansion button in BY UI ==========");
	}
	
	public void selectNewInventoryStatusFromDropdownList(String newStatus) {
		ArrayList<WebElement>inventoryStatusDropdownList=(ArrayList<WebElement>) getDriver().findElements(By.xpath("//li[@class='x-boundlist-item']"));
		for(WebElement element: inventoryStatusDropdownList ) {
			if(element.getText().equalsIgnoreCase(newStatus)){
				element.click();
				logger.info("Clicked on Inventory Status Code Dropdown Expansion button in BY UI =========="+element.getText() );
			}
			
		}
		
	}
	
	public void clickOnExecuteActionButton() {
		element(executeActionButton).waitUntilVisible();
		element(executeActionButton).click();
		logger.info("Clicked on Execute Action button in BY UI ==========");
	}
	
	public void clickFreightDashboardCloseButton() {
		element(freightDashboardCloseButton).waitUntilVisible();
		element(freightDashboardCloseButton).waitUntilClickable();
		element(freightDashboardCloseButton).click();
		logger.info("Clicked on Freight Dashboard Close Button in BY UI ==========");
	}
	
}
