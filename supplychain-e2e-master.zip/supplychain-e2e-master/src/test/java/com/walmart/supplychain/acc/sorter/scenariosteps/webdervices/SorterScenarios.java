package com.walmart.supplychain.acc.sorter.scenariosteps.webdervices;

import com.walmart.supplychain.acc.sorter.steps.webservices.SorterSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class SorterScenarios {
	@Steps
	SorterSteps sorterSteps;
	
	@And("^verify that sorter has got LPN to RDC mapping for \"([^\"]*)\" flow$")
	public void verificationOfLpnToRdcMappingInSorter(String flowType)
	{
		sorterSteps.validateAndSetLPNtoStoreMap(flowType);
	}
	
	@Then("^user verifies that labels from the sorter database are purged post gate out$")
	public void verificationOfsorterDBpurge()
	{
		sorterSteps.verificationOfsorterDBpurge();
	}
}
