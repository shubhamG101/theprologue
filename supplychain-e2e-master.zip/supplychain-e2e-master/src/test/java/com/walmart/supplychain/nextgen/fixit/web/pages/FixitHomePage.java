package com.walmart.supplychain.nextgen.fixit.web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.geo.Point;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class FixitHomePage extends SerenityHelper {

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TRACKER_DC_USER="https://fit-qa1.prod.us.walmart.net/fixit/tracker?code=C51B07E76F24487880628ED8441CA182&state=1234";
	private static final String RESOLVE_HO_USER="https://fit-qa1.prod.us.walmart.net/fixit/resolve?code=C51B07E76F24487880628ED8441CA182&state=1234";

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20,10);//15 times with a delay of 10s
	boolean problemTicketDisplayed=false;
	
	
	//login - username password
	@FindBy(xpath = "//button[text()='Login again']")
	private WebElement loginAgain_Button;
	
	@FindBy(xpath = ".//*[@id='uname']")
	private WebElement userName_Textbox;
	
	@FindBy(xpath = ".//*[@id='j_password']")
	private WebElement password_Textbox;
	
	@FindBy(xpath = ".//*[@id='domain']")
	private WebElement domain_Dropdown;
	
	@FindBy(xpath = ".//*[@id='domain']/option")
	private WebElement domainList_Dropdown;
	
	@FindBy(xpath = ".//*[@type='submit']")
	private WebElement signIn_Button;
	
	
	// TRACKER user
	@FindBy(xpath = "(//*[@class='swimlanes']//*[@class='lane'])[1]//*[@class='cards']")
	private WebElement newSwimlane_POLinks;

	@FindBy(xpath = "(//*[@class='swimlanes']//*[@class='lane'])[3]//*[@class='cards']")
	private WebElement workingSwimlane_POLinks;

	@FindBy(xpath = "(//*[@class='swimlanes']//*[@class='lane'])[2]//*[@class='cards']")
	private WebElement assignmentSwimlane_POLinks;

	@FindBy(xpath = "(//*[@class='swimlanes']//*[@class='lane'])[4]//*[@class='cards']")
	private WebElement resolutionAvailSwimlane_POLinks;

	@FindBy(xpath = "//*[@class='awaiting-info']")
	private WebElement awaitingInfoSwimlane_POLinks;

	@FindBy(xpath = "//*[@class='swimlanes']//*[@class='lane']")
	private WebElement allSwimlanes; //all the swimlanes
	
	@FindBy(xpath = "//*[text()='Show more']")
	private WebElement showMore_Link;

	// search
	@FindBy(xpath = "//*[text()='Search']")
	private WebElement searchBox;

	@FindBy(xpath = "//*[@name='ticketId']")
	private WebElement ticketId_Txtbox;

	@FindBy(xpath = "//*[@class='searchbox-actions']//*[text()='Search']")
	private WebElement search_Button;
	
	@FindBy(xpath = "//*[@class='my-queue fade-in']//section//*[@class='issue-id']")
	private WebElement problemTicketForAll;

	// filter
	@FindBy(xpath = "//*[text()='Filters']")
	private WebElement filter_Button;

	@FindBy(xpath = "//*[text()='Assigned to']")
	private WebElement assingedto_Dropdown;

	@FindBy(xpath = "//*[@class='MuiList-root MuiMenu-list MuiList-padding']")
	private WebElement assignedto_Dropdown_list;

	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement apply_Button;

	// department
	@FindBy(xpath = "//*[text()='Departments']")
	private WebElement depeartments_Button;

	@FindBy(xpath = "//*[@data-department-type='apparel']/i")
	private WebElement apparel;

	// Problem details
	@FindBy(xpath = "//*[@class='td-lhs']//*[@class='card-exp']//*[@class='issue-type']/span[2]")
	private WebElement ProblemTicketStatus;

	@FindBy(xpath = "//*[@class='td-lhs']//*[@class='card-exp']//*[@class='meta']")
	private WebElement problemTicketNum;
	
	@FindBy(xpath="//*[@id='mui-component-select-assignedGroup']")
	private WebElement assignedtoText;
	
	@FindBy(xpath="//*[@name='poType']")
	private WebElement type_Textbox;
	
	@FindBy(xpath="//*[@name='event']")
	private WebElement event_Textbox;
	
	@FindBy(xpath="//*[@id='po-number']")
	private WebElement poNumber_Textbox;
	
	@FindBy(xpath="//*[@id='po-line']")
	private WebElement poLineNumber_Textbox;
	
	@FindBy(xpath="//*[@id='item-number']")
	private WebElement itemNumer_Textbox;
	
	@FindBy(xpath="//*[@id='department-number']")
	private WebElement department_Textbox;
	
	//@FindBy(xpath="//*[text()='Save Changes']")
	@FindBy(xpath="//*[@class='save-and-discard-changes lining']/button")
	private WebElement saveChanges_Bttn;
	
	@FindBy(xpath="//*[@id='mui-component-select-resolutionType']")
	private WebElement resolution_DropDownbox;
	
	@FindBy(xpath="//*[@class='timeline fade-in']/div[1]//*[@class='diff']//div[2]")
	private WebElement poNumberHistory_Text;
	
	@FindBy(xpath=".//span[@class='hover icon close']")
	private WebElement close_Icon;
	
	//starts Resolve user
	
	//Resolve user - problem details
	@FindBy(xpath="//*[@id='assign-to-user']")
	private WebElement assignedUserId;
	
	@FindBy(xpath = "//*[text()='More info needed']")
	private WebElement moreInfoNeeded_Link;
	
	//Resolve user - swimlanes
	@FindBy(xpath = "(//*[@class='swimlanes']//*[@class='lane'])[2]//*[@class='cards']")
	private WebElement workingSwimlane_HOPOLinks;
	
	@FindBy(xpath = "(//*[@class='swimlanes']//*[@class='lane'])[3]//*[@class='cards']")
	private WebElement awaitingInfoSwimlane_HOPOLinks;

	//common for both user
	@FindBy(xpath = "//*[@class='swimlanes']//*[@class='lane']//*[@class='cards']")
	private WebElement allPO_Links;
	
	@FindBy(xpath = "//*[@title='Comments']")
	private WebElement comment_Icon;
	
	@FindBy(xpath = "//*[@title='History']")
	private WebElement hitory_Icon;
	
	@FindBy(xpath = "//*[@id='comment-id']")
	private WebElement comment_Textbox;
	
	//@FindBy(xpath = "//*[text()='AssignTo HO']")
	@FindBy(xpath = "//*[@class='add-comment']//button[1]")
	private WebElement assignToHO_Button;
	
	@FindBy(xpath = "//*[@title='History']")
	private WebElement history_Icon;
	
	@FindBy(xpath = "//*[text()='Submit resolution']")
	private WebElement submitResolution_Button;
	
	@FindBy(xpath="	")
	private WebElement assignedTo_Dropdown;
	
	@FindBy(xpath="//*[@class='issue-type']/span[1]")
	private WebElement IssueType_Text;
	
	@FindBy(xpath="//*[@class='issue-type']/span[2]")
	private WebElement problemTicket_Status;
	
	@FindBy(xpath="//*[@class='message']/div[2]/div[1]")
	private WebElement Comment_Text;
	
	@FindBy(xpath="//*[@name='moreInfoComment']")
	private WebElement moreInfoNeededComment_Textbox;

	@FindBy(xpath="//*[text()='Reassign to DC']")
	private WebElement reAssicgnToDC_Button;
	
	//After selecting - Resolution type & Donate
	
	//@FindBy(xpath="//*[@id='resolutionQuantity']")
	@FindBy(xpath="//*[@class='resolution-fields']//div[2]//input")
	private WebElement quantityToReceive_Textbox;
	
	//@FindBy(xpath="//*[@id='resolutionPo']")
	@FindBy(xpath="//*[@class='resolution-fields']//div[3]//input")
	private WebElement newPONumber_Textbox;
	
	//@FindBy(xpath="//*[@id='resolutionPoLine']")
	@FindBy(xpath="//*[@class='resolution-fields']//div[4]//input")
	private WebElement newPOLineNumber_Textbox;
	
	//search specific
	@FindBy(xpath="(//*[@class='swimlanes']//*[@class='lane'])[1]//*[@class='cards']//*[@class='issue-id']") //same for dc & ho
	private WebElement problemTicketNewLaneDCHO_Text;
	
	@FindBy(xpath="(//*[@class='swimlanes']//*[@class='lane'])[2]//*[@class='cards']//*[@class='issue-id']") //only dc
	private WebElement problemTicketAssignedLaneDC_Textbox;
	
	@FindBy(xpath="(//*[@class='swimlanes']//*[@class='lane'])[3]//*[@class='cards']//*[@class='issue-id']") //only dc
	private WebElement problemTicketWorkingLaneDC_Textbox;
	
	@FindBy(xpath="(//*[@class='swimlanes']//*[@class='lane'])[4]//*[@class='cards']//*[@class='issue-id']") //only dc
	private WebElement problemTicketResolutionAvailLaneDC_Textbox;

	@FindBy(xpath="//*[@class='button expand assign-button outline filled']")
	private WebElement assign_Button;

	@FindBy(xpath="//*[@class='selectors']//label[2]")
	private WebElement homeoffice_Button;

	@FindBy(xpath="//*[@class='button expand  filled']")
	private WebElement popupassign_Button;
	
	
	public void closeBrowser() {
		getDriver().quit();
	}
	
	WebDriver driver = null;
	/*public void loginIntoFixit(String url) {
		 driver = getDriverInstance();
		logger.info("Fixit login URL " +url);
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		long timeOut = 5000;
	    long end = System.currentTimeMillis() + timeOut;
	        while (System.currentTimeMillis() < end) {
	            if (String.valueOf(
	                    ((JavascriptExecutor) driver)
	                            .executeScript("return document.readyState"))
	                    .equals("complete")) {
	                break;
	            }
	        }
	        enterUserPass("user","pass");
	}
	
	public void loginOneTimeFixit(String url) {
		driver = getDriverInstance();
		logger.info("Fixit login URL " +url);
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		long timeOut = 5000;
	    long end = System.currentTimeMillis() + timeOut;
	        while (System.currentTimeMillis() < end) {
	            if (String.valueOf(
	                    ((JavascriptExecutor) driver)
	                            .executeScript("return document.readyState"))
	                    .equals("complete")) {
	                break;
	            }
	        }
	        enterUserPass("b0n00kf","Wal@456B");
	}*/
	
	

	private void clickOnNewLanePODC(String poNumber,WebElement element) {
		element(element).waitUntilVisible();
		List<WebElement> poNumbers = getDCPONumbers(element);
		for (WebElement webElement : poNumbers) {
			if (webElement.getText().equals(poNumber)) {
				element(webElement).waitUntilVisible();
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				moveToElementUsingJavaScript(getDriverInstance(),webElement);
				//clickUsingActions(getDriverInstance(),webElement);
				new Actions(getDriver()).moveToElement(webElement).click().build().perform();
				break;
			}
		}	
	}
	
	public void clickOnNewLaneProblemDC(String problemTicket) {
		element(newSwimlane_POLinks).waitUntilVisible();
		clickOnNewLanePODC(problemTicket,newSwimlane_POLinks);
	}
	
	public void clickOnWorkingLaneProblemTicketHO(String problemTicket) {
		element(workingSwimlane_HOPOLinks).waitUntilVisible();
		clickOnNewLanePODC(problemTicket,workingSwimlane_HOPOLinks);
	}
	
	public void clickOnWaitingInfoProblemTicketDC(String problemTicket) {
		element(awaitingInfoSwimlane_POLinks).waitUntilVisible();
		clickOnNewLanePODC(problemTicket,awaitingInfoSwimlane_POLinks);
	}
	
	public void clickOnAwaitingInfoLaneProblemTicketHO(String problemTicket) {
		clickOnNewLanePODC(problemTicket,awaitingInfoSwimlane_HOPOLinks);
	}
	
	public List<WebElement> getDCPONumbers(WebElement swimlane) {
		List<WebElement> listPoProblems=swimlane.findElements(By.xpath("//*[@class='issue-id']"));
		return listPoProblems;
	}
	
	public void AssignProblemTicketToHO(String assignedto) throws Exception {
		element(assign_Button).waitUntilClickable();
		click(assign_Button);

		element(homeoffice_Button).waitUntilClickable();
		click(homeoffice_Button);

		element(popupassign_Button).waitUntilClickable();
		click(popupassign_Button);

		Thread.sleep(3000);

//		element(assignedtoText).waitUntilVisible();
//		click(assignedtoText);
//		List<WebElement> assignedToDropdownValues = getAssignedToDropdownValues();
//
//		for (WebElement webElement : assignedToDropdownValues) {
//			String str=webElement.getText().trim();
//			if (webElement.getText().trim().equals(assignedto.trim())) {
//				webElement.click();
//
//				element(type_Textbox).waitUntilVisible();
//				//moveToElementUsingJavaScript(getDriverInstance(),type_Textbox);
//				//type_Textbox.click();
//				//type_Textbox.clear();
//
//				type_Textbox.sendKeys("1");
//
//				/*event_Textbox.click();
//				element(event_Textbox).type("1");*/
//
//				element(saveChanges_Bttn).waitUntilVisible();
//				JavascriptExecutor executor = (JavascriptExecutor)getDriverInstance();
//				executor.executeScript("arguments[0].click();", saveChanges_Bttn);
//				//FluentWaitForElement(getDriverInstance(),"(//*[@class='swimlanes']//*[@class='lane'])[2]//*[@class='cards']");
//				element(newSwimlane_POLinks).waitUntilVisible();
//
//				break;
//			}
//		}
	}
	
	public List<WebElement> getAssignedToDropdownValues() {
		return assignedto_Dropdown_list.findElements(By.tagName("li"));
	}
	
	public boolean validateProblemTicketDisplayedInLane(String user,String problemTicket,String swimlane,String newPONumber) throws InterruptedException {
		//element(allPO_Links).waitUntilVisible();
		// getDriver().navigate().refresh();
		element(allPO_Links).waitUntilVisible();
		FluentWaitForElement(driver,"//*[@class='swimlanes']//*[@class='lane']//*[@class='cards']");

		switch(swimlane) {
		//completed for both user
		case "New":
			if(user.equalsIgnoreCase("TRACKER")) {
				element(newSwimlane_POLinks).waitUntilVisible();
					//problemTicketDisplayed=checkProblemTicketDisplayedForAll(PO,getDCPONumbers(newSwimlane_POLinks));
				
				element(searchBox).waitUntilVisible();
				//element(searchBox).click();
				clickUsingJavaScript(getDriver(), searchBox);
				element(ticketId_Txtbox).waitUntilVisible();
				element(ticketId_Txtbox).type(problemTicket);
				element(search_Button).waitUntilVisible();
				element(search_Button).click();
				Thread.sleep(5000);
				element(problemTicketNewLaneDCHO_Text).waitUntilVisible();
				String result=problemTicketNewLaneDCHO_Text.getText();
				for (int i = 0; i < 5; i++) {
					if (problemTicket.trim().equalsIgnoreCase(result.trim())) {
						problemTicketDisplayed = problemTicketNewLaneDCHO_Text.isDisplayed();
						moveToElementUsingJavaScript(getDriver(), problemTicketNewLaneDCHO_Text);
						clickUsingActions(getDriver(), problemTicketNewLaneDCHO_Text);
						//element(problemTicketNewLaneDCHO_Text).click();
						Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
								verifyProblemTicketStatus("ASSIGNED"));
						logger.info("Problem ticket status verified as 'ASSIGNED' ");
						Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_GROUP_MISMATCH, verifyProblemTicketGroup("DC"));
						logger.info("Problem ticket group verified as 'DC' ");
						break;
					} 
				}
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
				
			}else {
				getDriver().navigate().to(RESOLVE_HO_USER);
				element(loginAgain_Button).waitUntilClickable();
				element(loginAgain_Button).click();
				
				element(newSwimlane_POLinks).waitUntilVisible();
					//problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(newSwimlane_POLinks));*/
				
				element(searchBox).waitUntilVisible();
				clickUsingJavaScript(getDriver(), searchBox);
				element(ticketId_Txtbox).waitUntilVisible();
				element(ticketId_Txtbox).type(problemTicket);
				element(search_Button).waitUntilVisible();
				element(search_Button).click();
				
				element(problemTicketNewLaneDCHO_Text).waitUntilVisible();
				String result=problemTicketNewLaneDCHO_Text.getText();
				if(problemTicket.trim().equalsIgnoreCase(result.trim())) {
					problemTicketDisplayed=problemTicketNewLaneDCHO_Text.isDisplayed();
				}
				
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
				element(problemTicketNewLaneDCHO_Text).waitUntilVisible();
				moveToElementUsingJavaScript(getDriverInstance(),problemTicketNewLaneDCHO_Text);
				clickUsingActions(getDriver(), problemTicketNewLaneDCHO_Text);
				//element(problemTicketNewLaneDCHO_Text).click();
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH, verifyProblemTicketStatus("ASSIGNED"));
				logger.info("Problem ticket status verified as 'ASSIGNED' ");
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_GROUP_MISMATCH, verifyProblemTicketGroup("Inbound Quality (HO)"));
				logger.info("Problem ticket group verified as 'DC' ");

			}
			break;
			
		case "Assigned":
			if(user.equalsIgnoreCase("TRACKER")) {
				element(assignmentSwimlane_POLinks).waitUntilVisible();
					//problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(assignmentSwimlane_POLinks));
				element(searchBox).waitUntilVisible();
				element(searchBox).click();
				element(ticketId_Txtbox).waitUntilVisible();
				element(ticketId_Txtbox).type(problemTicket);
				element(search_Button).waitUntilVisible();
				element(search_Button).click();
				
				element(problemTicketAssignedLaneDC_Textbox).waitUntilVisible();
				String result=problemTicketAssignedLaneDC_Textbox.getText();
				if(problemTicket.trim().equalsIgnoreCase(result.trim())) {
					problemTicketDisplayed=problemTicketAssignedLaneDC_Textbox.isDisplayed();
				}
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
			}else {
				// Not applicable for Resolve user
				/*element(assignmentSwimlane_POLinks).waitUntilVisible();
				problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(assignmentSwimlane_POLinks));
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}*/
			}
			break;
			
		case "Working":
			if(user.equalsIgnoreCase("TRACKER")) {
				element(workingSwimlane_POLinks).waitUntilVisible();
				problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(workingSwimlane_POLinks));
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
			}else {
				element(workingSwimlane_HOPOLinks).waitUntilVisible();
				problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(workingSwimlane_HOPOLinks));
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
			}
			break;
			
		case "Awaiting Information":
			if(user.equalsIgnoreCase("TRACKER")) {
				//element(showMore_Link).waitUntilClickable();
				//element(showMore_Link).click();
				element(awaitingInfoSwimlane_POLinks).waitUntilVisible();
				//problemTicketDisplayed=checkProblemTicketDisplayedForAll(PO,getDCPONumbers(awaitingInfoSwimlane_POLinks));
				
				element(searchBox).waitUntilVisible();
				element(searchBox).click();
				element(ticketId_Txtbox).waitUntilVisible();
				element(ticketId_Txtbox).type(problemTicket);
				element(search_Button).waitUntilVisible();
				element(search_Button).click();
				
				problemTicketDisplayed=problemTicketForAll.isDisplayed();
				
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
			}else {
				element(workingSwimlane_POLinks).waitUntilVisible();
				problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(workingSwimlane_POLinks));
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
			}
			break;
			
		case "Resolution Available":
			if(user.equalsIgnoreCase("TRACKER")) {
				element(resolutionAvailSwimlane_POLinks).waitUntilVisible();
				
				element(searchBox).waitUntilVisible();
				element(searchBox).click();
				element(ticketId_Txtbox).waitUntilVisible();
				element(ticketId_Txtbox).type(problemTicket);
				element(search_Button).waitUntilVisible();
				element(search_Button).click();
				
				element(problemTicketResolutionAvailLaneDC_Textbox).waitUntilVisible();
				String result=problemTicketResolutionAvailLaneDC_Textbox.getText();
				if(problemTicket.trim().equalsIgnoreCase(result.trim())) {
					problemTicketDisplayed=problemTicketResolutionAvailLaneDC_Textbox.isDisplayed();
					
				}
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}
				
				element(problemTicketResolutionAvailLaneDC_Textbox).waitUntilVisible();
				moveToElementUsingJavaScript(getDriverInstance(),problemTicketResolutionAvailLaneDC_Textbox);
				clickUsingActions(getDriver(), problemTicketResolutionAvailLaneDC_Textbox);
				
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH, verifyProblemTicketStatus("ANSWERED"));
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_GROUP_MISMATCH, verifyProblemTicketGroup("DC"));
				
			//	element(hitory_Icon).waitUntilVisible();
			//	element(hitory_Icon).click();
				
			//	Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEMTICKETHISTORY, verifyProblemTicketHistory(newPONumber));
				
				/*problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(resolutionAvailSwimlane_POLinks));
				if(problemTicketDisplayed==false) {
					logger.info("Problem ticket not displayed under {} swimlane for {}", swimlane,user);
				}else {
					logger.info("Problem ticket displayed under {} swimlane for {}", swimlane,user);
				}*/
			}else {
				element(resolutionAvailSwimlane_POLinks).waitUntilVisible();
				//problemTicketDisplayed=checkProblemTicketDisplayedForAll(problemTicket,getDCPONumbers(resolutionAvailSwimlane_POLinks));
			}
			break;
			
		default: 
			logger.info("User is not either Tracker or Resolve...");
			
		}
		return problemTicketDisplayed;
	}
	
	private boolean checkProblemTicketDisplayedForAll(String poNumber,List<WebElement> pos) {
		boolean result=false;
		element(newSwimlane_POLinks).waitUntilVisible(); 
		List<WebElement> poNumbers = pos;
		for (WebElement webElement : poNumbers) {
			if (webElement.getText().equals(poNumber)) {
				result=true;
				break;
			}
		}
		return result;	
	}
	
	public void hoAssignsProblemToAnotherHOUser(String userID) {
		element(assignedUserId).waitUntilVisible();
		element(assignedUserId).type(userID);
		JavascriptExecutor executor = (JavascriptExecutor)getDriverInstance();
		executor.executeScript("arguments[0].click();", saveChanges_Bttn);
	}
	
	public void hoRequestForMoreInfoFromDC() {
		try {
		element(moreInfoNeeded_Link).waitUntilClickable();
		element(moreInfoNeeded_Link).click();
		element(moreInfoNeededComment_Textbox).waitUntilClickable();
		element(moreInfoNeededComment_Textbox).type("Request for info from DC");
		element(reAssicgnToDC_Button).waitUntilClickable();
		element(reAssicgnToDC_Button).click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		clickUsingActions(getDriverInstance(), searchBox);
	}
	
	public void submitAwaitingInfoTicketFromDC(String problemTicket) {
		try {
			searchProblemTicket("TICKET_ID",problemTicket);
			
		/*element(showMore_Link).waitUntilClickable();
		element(showMore_Link).click();
		
		//clickOnWaitingInfoProblemTicketDC(problemTicket);
		
		List<WebElement> poNumbers = getDCPONumbers(awaitingInfoSwimlane_POLinks);
		for (WebElement webElement : poNumbers) {
			if (webElement.getText().equals(problemTicket)) {
				
				int count=100;
				while(count<100){
					if(webElement.isEnabled() && webElement.isDisplayed()){
						moveToElementUsingJavaScript(getDriver(),webElement);
						break;
					}
					count++;
					getDriver().findElement(By.xpath("//*[@data-direction='right']")).click();
				}
				
				
				org.openqa.selenium.Point p1=webElement.getLocation();
				new Actions(getDriver()).moveByOffset((int)p1.getX(), (int)p1.getY()).click().build().perform();
				//moveToElementUsingJavaScript(getDriver(),webElement);
				//moveToElementAndClickUsingActions(getDriver(),webElement);
				
				//moveToElementUsingJavaScript(getDriverInstance(),webElement);
				//clickUsingActions(getDriverInstance(),webElement);
				//new Actions(getDriverInstance()).moveToElement(webElement).click().build().perform();
				break;
			}*/
		//}		
			
		element(comment_Icon).waitUntilVisible();
		//moveToElementUsingJavaScript(getDriver(), comment_Icon);
		element(comment_Icon).click();
		//clickUsingActions(getDriver(), comment_Icon);
		
		element(comment_Textbox).waitUntilClickable();
		element(comment_Textbox).type("submitted from DC");
		
		element(assignToHO_Button).waitUntilClickable();
		//clicks
		moveToElementUsingJavaScript(getDriver(), assignToHO_Button);
		clickUsingJavaScript(getDriver(), assignToHO_Button);
		
		//moveToElementUsingJavaScript(getDriverInstance(),assignToHO_Button);
		//clickUsingActions(getDriverInstance(),webElement);
		new Actions(getDriver()).moveToElement(assignToHO_Button).doubleClick().perform();
		assignToHO_Button.click();
		element(assignToHO_Button).click();
		
		assignToDCorHO("Inbound Quality (HO)");
		
		element(saveChanges_Bttn).waitUntilClickable();
		clickUsingJavaScript(getDriverInstance(), saveChanges_Bttn);
		
		Thread.sleep(15000);
		//element(searchBox).waitUntilVisible();
		//clickUsingActions(getDriverInstance(), searchBox);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
		
	}
	
	public void provideResolution(String resolutionName,String problemTicket,String WMRA,String totalCostOfItem,String totalRetailOfItem,String dcNumber,String qtyToReceive,String newPONum,String newPOLineNum) throws InterruptedException {
		logger.info("Resolutin name : {}", resolutionName);
		switch(resolutionName.trim()) {
		case "Receive against another PO":
			//loginIntoFixit(RESOLVE_HO_USER);
			element(searchBox).waitUntilVisible();
			element(searchBox).click();
			Thread.sleep(2000);
			logger.info("Providing resolution as {}",resolutionName);
			element(ticketId_Txtbox).waitUntilVisible();
			element(ticketId_Txtbox).type(problemTicket);
			element(search_Button).waitUntilClickable();
			element(search_Button).click();
			List<WebElement> list=getDriver().findElements(By.xpath("(//*[@class='swimlanes']//*[@class='lane'])[2]//*[@class='cards']//*[@class='issue-id']"));
			for (WebElement webElement : list) {
				element(webElement).waitUntilVisible();
				if (webElement.getText().trim().equals(problemTicket)) {
					logger.info("Working swimlane problem ticket : ",webElement.getText());
					element(webElement).waitUntilVisible();
					moveToElementUsingJavaScript(getDriverInstance(),webElement);
					//clickUsingActions(getDriverInstance(),webElement);
					new Actions(getDriver()).moveToElement(webElement).click().build().perform();
					break;
				}
			}
			//clickOnWorkingLaneProblemTicketHO(problemTicket);
			submitResolutionForReceiveAgainstAnotherPO(resolutionName);
			break;
			
		case "Donate":
			//element(problemTicketForAll).waitUntilClickable();
			//clickUsingJavaScript(getDriver(), problemTicketForAll);
			submitResolutionForDonate(resolutionName, WMRA, totalCostOfItem, totalRetailOfItem);
			
			break;
			
		case "Transfer to another DC":
			//element(problemTicketForAll).waitUntilClickable();
			//clickUsingJavaScript(getDriver(), problemTicketForAll);
			submitResolutionForTransfertoAnotherDC(resolutionName, dcNumber);
			break;
			
		case "Destroy":
			/*element(problemTicketForAll).waitUntilClickable();
			clickUsingJavaScript(getDriver(), problemTicketForAll);*/
			//element(problemTicketNewLaneDCHO_Text).waitUntilVisible();
			//clickUsingActions(getDriver(), problemTicketNewLaneDCHO_Text);
			submitResolutionForDonate(resolutionName, WMRA, totalCostOfItem, totalRetailOfItem);
			element(close_Icon).waitUntilVisible();
			element(close_Icon).click();
			break;
			
		case "Added a PO Line":
			//element(problemTicketForAll).waitUntilClickable();
			//clickUsingJavaScript(getDriver(), problemTicketForAll);
			submitResolutionForAddedPOLine(resolutionName, qtyToReceive, newPONum, newPOLineNum);
			
		default: 
			logger.info("Resolution type not available...");
				
			}
		}
	
	public void submitnotOnPOFromDCNewLane(String assignedto) {
		try {
			element(assignedtoText).waitUntilVisible();
			click(assignedtoText);
			List<WebElement> assignedToDropdownValues = getAssignedToDropdownValues();
			
			for (WebElement webElement : assignedToDropdownValues) {
				String str=webElement.getText().trim();
				if (webElement.getText().trim().equals(assignedto.trim())) {
					webElement.click();
					
					element(type_Textbox).waitUntilVisible();
					moveToElementUsingJavaScript(getDriver(),type_Textbox);
					//element(type_Textbox).click();
					clickUsingActions(getDriver(), type_Textbox);
					type_Textbox.clear();
					element(type_Textbox).type("");
					element(type_Textbox).type("1");
					
					element(event_Textbox).waitUntilClickable();
					//moveToElementUsingJavaScript(driver,event_Textbox);
					//element(event_Textbox).click();
					clickUsingActions(getDriver(), event_Textbox);
					event_Textbox.clear();
					element(event_Textbox).type("");
					element(event_Textbox).type("1");
					
					element(poNumber_Textbox).waitUntilClickable();
					//moveToElementUsingJavaScript(driver,poNumber_Textbox);
					element(poNumber_Textbox).click();
					poNumber_Textbox.clear();
					element(poNumber_Textbox).type("12345678");
					
					element(poLineNumber_Textbox).waitUntilClickable();
					//moveToElementUsingJavaScript(driver,poLineNumber_Textbox);
					element(poLineNumber_Textbox).click();
					poLineNumber_Textbox.clear();
					element(poLineNumber_Textbox).type("2");
					
					element(itemNumer_Textbox).waitUntilClickable();
					//moveToElementUsingJavaScript(driver,itemNumer_Textbox);
					element(itemNumer_Textbox).click();
					itemNumer_Textbox.clear();
					element(itemNumer_Textbox).type("2");
					
					element(department_Textbox).waitUntilClickable();
					moveToElementUsingJavaScript(getDriver(),department_Textbox);
					element(department_Textbox).click();
					department_Textbox.clear();
					element(department_Textbox).type("33");
					
					element(saveChanges_Bttn).waitUntilClickable();
					clickUsingJavaScript(getDriver(), saveChanges_Bttn);
					
					element(close_Icon).waitUntilVisible();
					element(close_Icon).click();
					
					/*Thread.sleep(4000);
					FluentWaitForElement(getDriverInstance(),"//*[@class='swimlanes']//*[@class='lane']//*[@class='cards']");
					element(newSwimlane_POLinks).waitUntilVisible();*/
					
					System.out.println("test");
					break;
					
					/*JavascriptExecutor executor = (JavascriptExecutor)getDriverInstance();
					executor.executeScript("arguments[0].click();", saveChanges_Bttn);*/
					//FluentWaitForElement(getDriverInstance(),"(//*[@class='swimlanes']//*[@class='lane'])[2]//*[@class='cards']");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	private void submitResolutionForReceiveAgainstAnotherPO(String resolutionName) {
		try {
			assignToDCorHO("DC");
			
			element(resolution_DropDownbox).waitUntilClickable();
			
			clickUsingJavaScript(getDriver(), resolution_DropDownbox);
			//element(resolution_DropDownbox).click();
			
			selectFromDropDown(resolutionName,getResolutionDropDownElements());
			element(quantityToReceive_Textbox).waitUntilClickable();
			//element(quantityToReceive_Textbox).click();
			//clickUsingActions(getDriverInstance(), quantityToReceive_Textbox);
			moveToElementUsingJavaScript(getDriver(),quantityToReceive_Textbox);
			clickUsingJavaScript(getDriver(), quantityToReceive_Textbox);
			element(quantityToReceive_Textbox).clear();
			element(quantityToReceive_Textbox).type("1");
			Thread.sleep(1000);
			
			element(newPONumber_Textbox).waitUntilClickable();
			//element(newPONumber_Textbox).clear();
			//clickUsingActions(getDriver(), newPONumber_Textbox);
			moveToElementUsingJavaScript(getDriver(),newPONumber_Textbox);
			clickUsingJavaScript(getDriver(), newPONumber_Textbox);
			newPONumber_Textbox.clear();
			element(newPONumber_Textbox).type("12345678");
			Thread.sleep(1000);
			
			element(newPOLineNumber_Textbox).waitUntilClickable();
			//clickUsingActions(getDriver(), newPOLineNumber_Textbox);
			moveToElementUsingJavaScript(getDriver(),newPOLineNumber_Textbox);
			clickUsingJavaScript(getDriver(), newPOLineNumber_Textbox);
			newPOLineNumber_Textbox.clear();
			//element(newPOLineNumber_Textbox).clear();
			element(newPOLineNumber_Textbox).type("2");
			Thread.sleep(1000);
			
			element(submitResolution_Button).waitUntilClickable();
			element(submitResolution_Button).click();

			element(saveChanges_Bttn).waitUntilClickable();
			clickUsingJavaScript(getDriverInstance(), saveChanges_Bttn);
			
			Thread.sleep(8000);
			//clickUsingActions(getDriverInstance(), searchBox);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void submitResolutionForDonate(String resolutionName,String WMRA,String totalCostOfItem,String totalRetailOfItem ) throws InterruptedException {
		element(event_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriverInstance(),event_Textbox);
		clickUsingActions(getDriverInstance(), event_Textbox);
		event_Textbox.clear();
		element(event_Textbox).type("1");
		Thread.sleep(2000);
		
		element(poLineNumber_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriverInstance(),poLineNumber_Textbox);
		element(poLineNumber_Textbox).click();
		poLineNumber_Textbox.clear();
		element(poLineNumber_Textbox).type("1"); //enters data for details page
		
		element(resolution_DropDownbox).waitUntilClickable();
		clickUsingJavaScript(getDriver(), resolution_DropDownbox);
		selectFromDropDown(resolutionName,getResolutionDropDownElements());
		
		element(quantityToReceive_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),quantityToReceive_Textbox);
		clickUsingJavaScript(getDriver(), quantityToReceive_Textbox);
		element(quantityToReceive_Textbox).clear();
		element(quantityToReceive_Textbox).type(WMRA);
		Thread.sleep(1000);
		
		element(newPONumber_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),newPONumber_Textbox);
		clickUsingJavaScript(getDriver(), newPONumber_Textbox);
		newPONumber_Textbox.clear();
		element(newPONumber_Textbox).type(totalCostOfItem);
		Thread.sleep(1000);
		
		element(newPOLineNumber_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),newPOLineNumber_Textbox);
		clickUsingJavaScript(getDriver(), newPOLineNumber_Textbox);
		newPOLineNumber_Textbox.clear();
		element(newPOLineNumber_Textbox).type(totalRetailOfItem);
		Thread.sleep(1000);
		
		element(submitResolution_Button).waitUntilClickable();
		element(submitResolution_Button).click();
	}
	
	private void submitResolutionForTransfertoAnotherDC(String resolutionName,String dcNumber) throws InterruptedException {
		element(resolution_DropDownbox).waitUntilClickable();
		clickUsingJavaScript(getDriver(), resolution_DropDownbox);
		selectFromDropDown(resolutionName,getResolutionDropDownElements());
		
		element(quantityToReceive_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),quantityToReceive_Textbox);
		clickUsingJavaScript(getDriver(), quantityToReceive_Textbox);
		element(quantityToReceive_Textbox).clear();
		element(quantityToReceive_Textbox).type(dcNumber);
		Thread.sleep(1000);
		
		element(submitResolution_Button).waitUntilClickable();
		element(submitResolution_Button).click();
	}
	
	private void submitResolutionForAddedPOLine(String resolutionName,String qtyToReceive,String newPONum,String newPOLineNum) throws InterruptedException {
		element(resolution_DropDownbox).waitUntilClickable();
		clickUsingJavaScript(getDriver(), resolution_DropDownbox);
		selectFromDropDown(resolutionName,getResolutionDropDownElements());
		
		element(quantityToReceive_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),quantityToReceive_Textbox);
		clickUsingJavaScript(getDriver(), quantityToReceive_Textbox);
		element(quantityToReceive_Textbox).clear();
		element(quantityToReceive_Textbox).type(qtyToReceive);
		Thread.sleep(1000);
		
		element(newPONumber_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),newPONumber_Textbox);
		clickUsingJavaScript(getDriver(), newPONumber_Textbox);
		newPONumber_Textbox.clear();
		element(newPONumber_Textbox).type(newPONum);
		Thread.sleep(1000);
		
		element(newPOLineNumber_Textbox).waitUntilClickable();
		moveToElementUsingJavaScript(getDriver(),newPOLineNumber_Textbox);
		clickUsingJavaScript(getDriver(), newPOLineNumber_Textbox);
		newPOLineNumber_Textbox.clear();
		element(newPOLineNumber_Textbox).type(newPOLineNum);
		Thread.sleep(1000);
		
		element(submitResolution_Button).waitUntilClickable();
		element(submitResolution_Button).click();
	}
	
	private void selectFromDropDown(String strToSelect,List<WebElement> listOfElements) {
		List<WebElement> listOfWebElements = listOfElements;
		for (WebElement webElement : listOfWebElements) {
			String str=webElement.getText().trim();
			if (webElement.getText().trim().equalsIgnoreCase(strToSelect.trim())) {
				element(webElement).click();
				break;
			}
		}
	}
	
	private List<WebElement> getResolutionDropDownElements() {
		return driver.findElements(By.xpath("//*[@class='MuiList-root MuiMenu-list MuiList-padding']/li"));
	}
	
	private void assignToDCorHO(String assignedto) {
		element(assignedtoText).waitUntilVisible();
		element(assignedtoText).click();
		List<WebElement> assignedToDropdownValues = getAssignedToDropdownValues();
		for (WebElement webElement : assignedToDropdownValues) {
			String str=webElement.getText().trim();
			if (webElement.getText().trim().equals(assignedto.trim())) {
				webElement.click();
				break;
			}
		}	
	}
	
	
	public void searchProblemTicket(String creteria,String ticketId) {
		try {
		if(creteria.equalsIgnoreCase("TICKET_ID")) {
			element(searchBox).waitUntilVisible();
			element(searchBox).click();
			Thread.sleep(1000);
			element(ticketId_Txtbox).waitUntilVisible();
			element(ticketId_Txtbox).type(ticketId);
			element(search_Button).waitUntilVisible();
			element(search_Button).click();
			//element(showMore_Link).waitUntilVisible();
			//element(showMore_Link).click();
				clickOnSearchedTicket();
		}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	private void clickOnSearchedTicket() throws InterruptedException {
		element(problemTicketForAll).waitUntilClickable();
		clickUsingJavaScript(getDriver(),problemTicketForAll);
		Thread.sleep(1000);
		//element(problemTicketForAll).click();
	}
	
	public String getProblemTicketStatus() {
		element(problemTicket_Status).waitUntilClickable();
		return element(problemTicket_Status).getText();
	}
	
	public String getProblemGroupName() {
		element(assignedtoText).waitUntilClickable();
		return element(assignedtoText).getText();
	}
	
	public boolean verifyProblemTicketStatus(String problemTicketStatus) {
		logger.info("Problem ticket status {}",getProblemTicketStatus());
		return getProblemTicketStatus().trim().equals(problemTicketStatus);
	}
	
	public boolean verifyProblemTicketGroup(String groupName) {
		logger.info("Problem ticket group {}",getProblemGroupName());
		return getProblemGroupName().trim().equals(groupName);
	}
	
	public boolean verifyProblemTicketHistory(String poNumber) {
		element(poNumberHistory_Text).waitUntilVisible();
		String poNum=element(poNumberHistory_Text).getText();
		String poNumActual = poNum.replaceAll("[^0-9]+", " ");
		String poNumActualValue= poNumActual.replaceAll(" ", "");
		logger.info("Problem ticket history text : {}",poNumActualValue);
		return poNumber.trim().equals(poNumActualValue.trim());
		
	}
	
	private boolean checkListContainsString(String str,List<WebElement> list) {
		List<WebElement> listOfElements=list;
		List<String> listOfvalues=null;
		for (WebElement webElement : listOfElements) {
			listOfvalues.add(webElement.getText());
		}
		return list.contains(str);
	}
	
	private void FluentWaitForElement(WebDriver driver, String xpath) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(180, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
	}
	
	public void moveToElementUsingJavaScript(WebDriver driver,WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].scrollIntoView();",element);
	}
	
	public void clickUsingJavaScript(WebDriver driver,WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}
	
	public void clickUsingActions(WebDriver driver,WebElement element) {
		new Actions(driver).click(element).build().perform();
	}
	
	public void moveToElementAndClickUsingActions(WebDriver driver,WebElement element) {
		new Actions(driver)
		.moveToElement(element).click().build().perform();
	}

	public void closeDriver() {
		getDriverInstance().close();
	}

}
