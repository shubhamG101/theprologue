package com.walmart.supplychain.baja.op.scenariosteps;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.baja.op.step.OrderEnrichStep;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class )
public class OrderEnrichScenario {

	
	Logger logger = LogManager.getLogger(this.getClass());
	@Steps
	OrderEnrichStep opsteps;
	
	@Then("^User verifies that Orders are enriched and then release the orders$")
	public void userReleasesEnrichedOrdersToOF() throws JSONException, IOException {
		logger.info("User verifies that Orders are enriched and then release the orders");
		opsteps.userEnrichReleaseOrders();
	}
}
