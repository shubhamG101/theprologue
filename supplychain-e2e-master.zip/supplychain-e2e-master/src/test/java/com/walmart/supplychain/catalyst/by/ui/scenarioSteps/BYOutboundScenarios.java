package com.walmart.supplychain.catalyst.by.ui.scenarioSteps;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.by.ui.steps.BYOutboundSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.catalyst.by.ui.steps.BYWorkQueueSteps;
import com.walmart.supplychain.catalyst.by.ui.steps.BYReceivingSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class BYOutboundScenarios {
	
	
	@Steps
	BYOutboundSteps byOutboundSteps;
	
	@Steps
	BYWorkQueueSteps byWorkQueueSteps;
	
	@Steps
	BYReceivingSteps byReceivingSteps;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	
	@Then("^user verifies Order is present as Active Order in BY web UI$")
	public void verifyOrderInBY() throws InterruptedException {
		
		byReceivingSteps.loginToBY();
		byUiHelper.navigateToMentionedMenu("WALMART - OUTBOUND PLANNER");
		byUiHelper.navigateToMentionedTab("Outbound");
		byOutboundSteps.verifyOrderAsActiveStatusInBY();
		
	}
	
	@Given("^user plans wave using Load ID$")
	public void planWaveInBY() throws InterruptedException {
		
		byUiHelper.navigateToMentionedTab("Waves and Picks");
		byOutboundSteps.planWaveUsingLoadId();
		
	}
	
	@Then("^user verifies that planned wave is succesfully planned$")
	public void verifyPlannedWaveInBY() throws InterruptedException {
		
		byOutboundSteps.validatePlannedWaveIsSuccessful();;
	}
	
	@When("^user allocates wave$")
	public void userAllocatesWaveInBY() throws InterruptedException {
		
		byOutboundSteps.allocateWave();
		
	}
	
	
	@Then("^user verifies the wave is allocated successfully and status is \"([^\"]*)\"$")
	public void userVerifyAllocatedWave(String waveStatus) throws InterruptedException {
		
		byOutboundSteps.validateAllocatedWaveIsSuccessful(waveStatus);
	}
	
	
	@Then("^user verifies Allocated Percentage of wave$")
	public void userVerifyAllcatedPercentage() throws InterruptedException {
		
		byOutboundSteps.validateAllocatedPercentage();;
	}
	
	
	@When("^user releases the wave$")
	public void userReleasesWaveInBY() throws InterruptedException {
		
		byOutboundSteps.releaseWave();
	}
	
	
	@Then("^user verifies wave status is changed to \"([^\"]*)\"$")
	public void userVerifyWaveStatus(String waveStatus) throws InterruptedException {
		
		byOutboundSteps.validateWaveStatus(waveStatus);
	}
	
	@Then("^user verifies work has been generated under Picks tab$")
	public void userVerifyWorkAssignmentUnderPicksTab() throws InterruptedException {
		
		byOutboundSteps.verifyWorkAssignmentUnderPicksTab();
	}
	
}
