package com.walmart.supplychain.acc.labeling;

import static net.serenitybdd.rest.SerenityRest.when;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class LabelSteps {

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	TextParser textParser;

	@Autowired
	Environment environment;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	Logger logger = LogManager.getLogger(this.getClass());

	public void checkLabels(String expectedclientID) {

		String testData = (String) tl.get().get("testFlowData");
		
		JSONArray listOfcntrs = JsonPath.read(testData,
				"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?( (@.isPbyl == false || @.isPBYL == false))].parentContainer");
		String cntrString = listOfcntrs.toJSONString();
		logger.info("Cntr List {}", cntrString);

		if (cntrString.isEmpty())
			throw new AutomationFailure("Container List in testflowdata is empty");

		for(int i=0;i<listOfcntrs.size();i++){
			
			//framing the URL for containers
			String labelingurl = environment.getProperty("labeling_data") + listOfcntrs.get(i);
			logger.info(labelingurl);
			
			Response response = null;		
			response = when().get(labelingurl);
			Assert.assertEquals(ErrorCodes.LABEL_RESPONSE_NOT_CORRECT,Constants.SUCESS_STATUS_CODE,response.getStatusCode());
			
			JSONArray actualclientId = JsonPath.parse(response.getBody().asString()).read("$..clientID");
			
			Assert.assertEquals(ErrorCodes.LABEL_CLIENT_ID_MISMATCH, expectedclientID,actualclientId.get(0));			
		}
		
	}
}
