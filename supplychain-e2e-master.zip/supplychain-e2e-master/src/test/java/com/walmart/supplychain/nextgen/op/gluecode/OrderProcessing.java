package com.walmart.supplychain.nextgen.op.gluecode;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;
import java.net.URISyntaxException;

import org.json.JSONException;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.op.steps.webservices.OpSteps;


public class OrderProcessing {

    @Steps
    OpSteps op;


    @Then("^user verifies orders should be downloaded with OP for the PO quantity present in delivery$")
    public void user_verifies_orders_should_be_downloaded_with_OP_for_the_PO_quantity_present_in_delivery() throws IOException, URISyntaxException {
        op.verifyOMSearchServiceForOtnAndQuantity("");
        op.verifyOAOrders();
    }
    
    @Then("^user verifies orders should not be downloaded for cancelled \"([^\"]*)\" delivery$")
    public void user_verifies_orders_should_not_be_downloaded_for_cancelled_delivery(String status) throws IOException, URISyntaxException {
    		op.verifyOMSearchServiceForOtnAndQuantity(status);
    }


    @Given("^user verifies the fulfilled Qty in OP$")
    public void user_verifies_the_fulfilled_Qty_in_OP() throws IOException, URISyntaxException {
        op.verifyFulFilledQtyInOA();
    }
    
    @Given("^user verifies the fulfilled Qty in OP from DB$")
    public void user_verifies_the_fulfilled_Qty_in_OPfromDB() throws IOException, URISyntaxException {
        op.verifyFulFilledQtyInOA("db");
    }
    
    @Given("^user validates PO details in order Manager for each PO$")
    public void user_validates_PO_Details_In_OM() {
    	op.verifyPOEntryInOM();
    }

    @Given("^user verifies the orders are downloaded and fulfilled in OP$")
    public void verifyOrdersCreatedAndFulfilledAtRdc() throws IOException {
        op.verifyOrdersAreCreatedInOm();
        op.verifyOrdersAreCreatedAndFulfilledInOA();
    }
    
    @And("^user verifies Delivery finalization in OP$")
	public void user_verifies_Delivery_finalization_in_op() throws JSONException {
		op.validateDeliveryFinalizationOp();
	}
    
    @Given("^user verifies orders should be downloaded within OP$")
    public void verify_orders_are_downloaded() throws IOException
    {
    	 op.verifyOrdersAreDownloaded();
    }
    
    @And("^User verifies that new exception is raised for the invalid stores$")
  	public void user_verifies_new_exception_is_raised_Invalid_store() throws JSONException {
    	op.verifyNewExceptionRaised();
  	}
    
    @And("^user verifies orders status \"([^\"]*)\" in OM$")
  	public void user_verifies_order_status_in_om(String status) throws JSONException {
    	op.verifyOrderStatusInOM(status);
  	}
    
    @And("^user verifies orders status \"([^\"]*)\" in OA$")
  	public void user_verifies_order_status_in_oa(String status) throws JSONException {
    	op.verifyOrderStatusInOA(status);
  	}
    @Then("^user updates the order date to greater then seven days in OP$")
    public void updateDateGreaterThen7Days() {
        op.updateDateinDB();
    }

    @Then("^user triggers order refresh process$")
    public void triggerOrderRefresh() throws InterruptedException {
        op.triggerOrderRefresh();
    }
}