package com.walmart.supplychain.nextgen.of.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.of.pages.webservices.OrderFulfillmentHelper;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderFulfillmentSteps {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	OrderFulfillmentHelper ofHelper;
	@Autowired
	JavaUtils javaUtils;
	@Autowired
	JsonUtils jsonUtils;
	@Autowired
	Environment environment;
	
	@Autowired
	ReceivingHelper receivingHelper;
	
	Response response=null;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY_30S,
			Constants.RETRY_EXECUTION_COUNT);
	Logger logger = LogManager.getLogger(this.getClass());
	HashMap<String, List<String>> map;
	static final String TEST_FLOW_DATA_KEY = "testFlowData";
	static final String PO_NUMBERS_JSON_PATH = "$.testFlowData.deliveryDetails[*].poNumbers[*]";
	static final String VTR_INSTRUCTION_JSON_PATH = "$..poDetails[?(@.poNumber=='#0#')]..receivingInstructions[?(@.isVTR==true)]";
	static final String CONTAINER_STATUS_JSON_PATH = "$..fulfillmentUnits[?(@.destCtnrTrckgId=='#0#')].fulfillmentUnitStatus";
	static final String REASON_CODE_JSON_PATH = "$..fulfillmentUnits[?(@.destCtnrTrckgId=='#0#')].outReasonCode";
	// static final String STATUS_FOR_DELETED="DELETED";
	static final String REASON_CODE_FOR_DELETED = "Void to reinstate";
	private static final short DEL_FINAL_OF = 4;
	static final String DAMAGE_INSTRUCTION_JSON_PATH = "$..poDetails[?(@.poNumber=='#0#')]..receivingInstructions[?(@.isDamage==true)]";
	private static final String CANCEL_STATUS="CANCELLED";

	/*
	 * No need to check soft allocation
	 */
	/*
	 * @Step public void fetchOfSoftAllocationResponse() {
	 * 
	 * 
	 * response = ofHelper.buildInstructionUrlAndGetResponseForSoftAllocation();
	 * ofHelper.validateResponseForSoftAllocation(response); logger.info(
	 * "OF updated OP Allocation successfully");
	 * 
	 * 
	 * }
	 */

	@Step
	public void fetchOfFulFillmentResponse() throws JSONException {
		try {
			Failsafe.with(retryPolicy).run(() -> {
				map = new HashMap<>();
				Response[] response = ofHelper.buildInstructionUrlAndGetResponseForFulfillment();
				logger.info("Waiting for OF to update the status ");
				map = ofHelper.validateResponseForFulfillment(response);
				logger.info("Order Fulfillment completed successfully");
			});
			ofHelper.updateRunTimeDataForReceivingInstruction(map);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching fulfillment response", e);
		}

	}

	@SuppressWarnings("unchecked")
	@Step
	public void validateFulfillmentResponseAfterVTR(String status) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> poNumbers = JsonPath.read(testFlowData, PO_NUMBERS_JSON_PATH);
			for (String poNumber : poNumbers) {
				logger.info("Processing for PO:{}", poNumber);
				JSONArray instructionArray = JsonPath.read(testFlowData,
						javaUtils.format(VTR_INSTRUCTION_JSON_PATH, poNumber));
				List<ReceivingInstruction> receivingInstructionList = (List<ReceivingInstruction>) jsonUtils
						.getPojoListfromPath(instructionArray.toJSONString(), ReceivingInstruction.class);
				for (ReceivingInstruction instruction : receivingInstructionList) {
					String vtrContainer = instruction.getVtrContainer();
					String messageId = instruction.getMessageId();
					logger.info("VTR Container:{}", vtrContainer);
					logger.info("Message Id:{}", messageId);
					validateFulfillmentStatusAfterVTR(messageId, vtrContainer, status);
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("VTR Fulfillment Status Validation failed", e);
		}

	}

	@Step
	public void validateFulfillmentStatusAfterVTR(String messageId, String vtrContainer, String status) {

		try {
			Failsafe.with(retryPolicy).run(() -> {
				Response response = null;
				if (Config.DC == DC_TYPE.ATLAS) {
					response = given().relaxedHTTPSValidation().accept("application/json")
							.contentType("application/json").headers(ofHelper.prePareHeaders())
							.body("[{\"fulfillmentIds\":[\"" + messageId + "\"]}]")
							.post(environment.getProperty("fulfillment_search_url"));
				} else {
					response = SerenityRest.given().body("[{\"fulfillmentIds\":[\"" + messageId + "\"]}]")
							.post(environment.getProperty("of_fm_search"));
				}
				logger.info("response:{}", response.asString());
				List<String> fulfillmentStatusList = JsonPath.read(response.asString(),
						javaUtils.format(CONTAINER_STATUS_JSON_PATH, vtrContainer));
				List<String> reasonCodeList = JsonPath.read(response.asString(),
						javaUtils.format(REASON_CODE_JSON_PATH, vtrContainer));
				for (String fulfillmentStatus : fulfillmentStatusList) {
					logger.info("Fulfillment Expected Status :{}", status);
					logger.info("Fulfillment Actual Status :{}", fulfillmentStatus);
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_STATUS_NOT_UPDATED_AFTER_VTR, status,
							fulfillmentStatus);
				}
				logger.info("Validate OF Status after VTR Successfully");
				/*
				 * for(String reasonCode:reasonCodeList) { logger.info(
				 * "Reason Code :{}",reasonCode); Assert.assertEquals(
				 * "OF Reason code Mismatch", REASON_CODE_FOR_DELETED, reasonCode); }
				 * logger.info( "Validated OF Reason code after VTR Successfully");
				 */
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("VTR Fulfillment Status Validation failed", e);
		}
	}

	@Step
	public void validateFulfillmentResponseAfterDamage(String status) {
		try {
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA_KEY).toString();
			List<String> poNumbers = JsonPath.read(testFlowData, PO_NUMBERS_JSON_PATH);
			for (String poNumber : poNumbers) {
				logger.info("Processing for PO:{}", poNumber);
				JSONArray instructionArray = JsonPath.read(testFlowData,
						javaUtils.format(DAMAGE_INSTRUCTION_JSON_PATH, poNumber));
				List<ReceivingInstruction> receivingInstructionList = (List<ReceivingInstruction>) jsonUtils
						.getPojoListfromPath(instructionArray.toJSONString(), ReceivingInstruction.class);
				for (ReceivingInstruction instruction : receivingInstructionList) {
					String damageContainer = instruction.getDamageContainer();
					String messageId = instruction.getMessageId();
					logger.info("Damage Container:{}", damageContainer);
					logger.info("Message Id:{}", messageId);
					validateFulfillmentStatusAfterDamage(messageId, damageContainer, status);
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Damage Fulfillment Status Validation failed", e);
		}

	}

	@Step
	public void validateFulfillmentStatusAfterDamage(String messageId, String damageContainer, String status) {

		try {
			Failsafe.with(retryPolicy).run(() -> {
				Response response = null;
				if (Config.DC == DC_TYPE.ATLAS) {
					response = given().relaxedHTTPSValidation().accept("application/json")
							.contentType("application/json").headers(ofHelper.prePareHeaders())
							.body("[{\"fulfillmentIds\":[\"" + messageId + "\"]}]")
							.post(environment.getProperty("fulfillment_search_url"));
				} else {
					response = SerenityRest.given().body("[{\"fulfillmentIds\":[\"" + messageId + "\"]}]")
							.post(environment.getProperty("of_fm_search"));
				}
				logger.info("response:{}", response.asString());
				List<String> fulfillmentStatusList = JsonPath.read(response.asString(),
						javaUtils.format(CONTAINER_STATUS_JSON_PATH, damageContainer));
				for (String fulfillmentStatus : fulfillmentStatusList) {
					logger.info("Fulfillment Expected Status :{}", status);
					logger.info("Fulfillment Actual Status :{}", fulfillmentStatus);
					Assert.assertEquals(ErrorCodes.OF_FULFILLMENT_STATUS_NOT_UPDATED_AFTER_VTR, status,
							fulfillmentStatus);
				}
				logger.info("Validate OF Status after Damage Successfully");
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Damage Fulfillment Status Validation failed", e);
		}
	}

	@Step
	public void deleteFulFillment() throws JSONException {
		try {
			ofHelper.deleteOfInstructionAndSoftAllocation();
			ofHelper.deleteFulfillments();
			logger.info("Order Fulfillment db cleaned up successfully");
		} catch (Exception e) {
			throw new AutomationFailure("Fulfillment cleanup is failed", e);
		}

	}

	@Step
	public void validateDeliveryFinalization() {

		try {
			logger.info("Validating delivery finalization in OF***{");
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Calling delivery finalization method in OF");
				Assert.assertEquals(ErrorCodes.OF_DELIVERY_NOT_FINALIZED, DEL_FINAL_OF,
						ofHelper.validateDelFinalization());
				logger.info("Sucessfully validated the delivery finalization in OF***}");
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Delivery Finalisation check failed in OF", e);
		}

	}

	@Step
	public void validatePartialReceiving() {
		
		try {
			Failsafe.with(retryPolicy).run(() -> {
				Response[] response = ofHelper.buildInstructionUrlAndGetResponseForFulfillment();
				logger.info("Waiting for OF to update the status ");
				Assert.assertEquals(ErrorCodes.OF_SHORTAGE_QTY_INCORRECT, true,
						ofHelper.validateResponseForShortage(response));
				logger.info("Sucessfully validated the fulfillment in OF for shortage");
			});
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching fulfillment response", e);
		}
		
	}

	@Step
	public void fetchOfFulFillmentResponseACC() {
		
		try {
				logger.info("Waiting for OF to update the status ");
				ofHelper.buildInstructionUrlAndGetResponseForFulfillmentACC();
				logger.info("Sucessfully validated the fulfillment in OF");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching fulfillment response", e);
		}			
	}
	
	@Step
	public void checkCancelledLabels() {
		try {
			String testFlowData = (String) threadLocal.get().get("testFlowData");
			DocumentContext parsedJson = JsonPath.parse(testFlowData);
			List<String> deliveryNumberlist = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
			List<String> poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			String cancelContainerDetails = receivingHelper.getCancelledContainerDetails(deliveryNumberlist.get(0));
			List<String> container = JsonPath.parse(cancelContainerDetails).read("$.[?(@.purchaseReferenceNumber=='"+poNumberList.get(0)+"' && @.receivedQuantity==0)]..trackingId");
			String labelingurl = environment.getProperty("fulfillment_lpn_url") + container.get(0);
			logger.info(labelingurl);
			
			Failsafe.with(retryPolicy).run(() -> {
			response = given().relaxedHTTPSValidation().headers(ofHelper.getOFHeaders()).when().get(labelingurl);
			Assert.assertEquals(ErrorCodes.LABEL_RESPONSE_NOT_CORRECT,Constants.SUCESS_STATUS_CODE,response.getStatusCode());
			});
			
			List<String> actualStatusOfCancelledContainer = JsonPath.parse(response.getBody().asString()).read("$.fulfillmentSearchOnReceiveContainer..fulfillmentStatus");
			Assert.assertEquals(ErrorCodes.CANCELLED_LABEL_STATUS_MISMATCH, CANCEL_STATUS,actualStatusOfCancelledContainer.get(0));
			logger.info("Validated Cancelled lable {} in OF", container);
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating cancelled Pallet", e);
		}

	}	
}
