package com.walmart.supplychain.rdc.receiving.steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.rdcutilities.RDCUtil;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.rdc.receiving.pages.DockTagLocationPage;
import com.walmart.supplychain.rdc.receiving.pages.DockTagReceivePage;
import com.walmart.supplychain.rdc.receiving.pages.DockTagScanPage;
import com.walmart.supplychain.rdc.receiving.pages.ItemCatalogHomePage;
import com.walmart.supplychain.rdc.receiving.pages.ItemCatalogUpdatePage;
import com.walmart.supplychain.rdc.receiving.pages.PalletCorrectionHomePage;
import com.walmart.supplychain.rdc.receiving.pages.PalletCorrectionPage;
import com.walmart.supplychain.rdc.receiving.pages.PalletCorrectionUpdatePage;
import com.walmart.supplychain.rdc.receiving.pages.ReceivingConfirmTrailerPage;
import com.walmart.supplychain.rdc.receiving.pages.ReceivingDoorScanPage;
import com.walmart.supplychain.rdc.receiving.pages.ReceivingItemQtyPage;
import com.walmart.supplychain.rdc.receiving.pages.ReceivingOveragePage;
import com.walmart.supplychain.rdc.receiving.pages.ReceivingScanUPCPage;
import com.walmart.supplychain.witron.loading.pages.MyAppsTabletLoginPage;
import com.walmart.supplychain.witron.myapps.pages.MyAppsHomePage;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingSteps {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	JavaUtils javaUtil;

	@Autowired
	RDCUtil rdcUtil;

	@Autowired
	DbUtils dbUtils;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, 5);
	List<String> containerList = null;

	Response response;

	@Autowired
	MyAppsTabletLoginPage myAppsTabletLoginPage;

	@Autowired
	ReceivingConfirmTrailerPage receivingConfirmTrailerPage;

	@Autowired
	ReceivingScanUPCPage receivingScanUPCPage;

	@Autowired
	ReceivingItemQtyPage receivingItemQtyPage;

	@Autowired
	DockTagLocationPage dockTagLocationPage;

	@Autowired
	DockTagReceivePage dockTagReceivePage;

	@Autowired
	DockTagScanPage dockTagScanPage;

	@Autowired
	PalletCorrectionPage palletCorrectionPage;

	@Autowired
	PalletCorrectionHomePage palletCorrectionHomePage;

	@Autowired
	PalletCorrectionUpdatePage palletCorrectionUpdatePage;

	@Autowired
	ItemCatalogHomePage itemCatalogHomePage;

	@Autowired
	ItemCatalogUpdatePage itemCatalogUpdatePage;

	@Autowired
	ReceivingOveragePage receivingOveragePage;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	ObjectMapper om = new ObjectMapper();

	private static final String GET_DOOR_NBR = "$.testFlowData.deliveryDetails[*].inboundDoorNumber";
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String GET_DELIVERY = "$.testFlowData.deliveryDetails[*].deliveryNumber";
	private static final String GET_RECEIVING_INSTRUCTIONS = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*]";
	private static final String GET_PARENT_CNTRS = "$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].parentContainer";
	private static final String GET_DELIVERY_DETAILS = "$.testFlowData.deliveryDetails[*]";
	private static final String GET_DOCK_TAGS = "$.testFlowData.deliveryDetails[*].dockTags";

	@Autowired
	ReceivingDoorScanPage receivingDoorScanPage;

	Logger logger = LogManager.getLogger(this.getClass());
	private static final String TEST_FLOW_DATA = "testFlowData";
	String testFlowData;

	@Step
	public void scanDoor() {
		try {
			Thread.sleep(6000);
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> deliveryDoorList = parsedtestflowJson.read(GET_DOOR_NBR);
			String doorNum = deliveryDoorList.get(0);
			receivingDoorScanPage.scanDoor(doorNum);
			receivingConfirmTrailerPage.confirmTrailer();
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_SCAN_DOOR, e);
		}
	}

	@Step
	public void reOpenDelivery() {
		try {
			Thread.sleep(6000);
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			List<String> deliveryDoorList = parsedtestflowJson.read(GET_DOOR_NBR);
			String doorNum = deliveryDoorList.get(0);

			receivingDoorScanPage.scanDoor(deliveryNum);
			receivingDoorScanPage.confirmReOpen(doorNum);
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_SCAN_DOOR, e);
		}
	}

	@Step
	public void receiveRDCItems(String deliveryType) {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPoList = new ArrayList<PoDetail>();
			containerList = new ArrayList<String>();

			for (PoDetail podetail : poList) {
				List<PoLineDetail> poLineList = podetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					List<ReceivingInstruction> recvInstrList = null;
					if (!deliveryType.equals("reopened")) {
						recvInstrList = receiveItems(lineDetail, deliveryType);
					} else {
						containerList = parsedtestflowJson.read(GET_PARENT_CNTRS);
						recvInstrList = receiveItems(lineDetail, deliveryType);
						int additionalRecviedQty = Integer.parseInt(recvInstrList.get(0).getReceivedQuantity());
						recvInstrList.addAll(lineDetail.getReceivingInstructions());
						lineDetail.setRecvQty(lineDetail.getRecvQty() + additionalRecviedQty);
					}

					if (lineDetail.getproblemType().equals("overage")) {

						receivingScanUPCPage.scanupc(lineDetail.getCaseUpc());
						receivingOveragePage.createOverageProblem(lineDetail.getProblemQty());
					}

					lineDetail.setReceivingInstructions(recvInstrList);
					newpoLineList.add(lineDetail);
				}
				podetail.setPoLineDetails(newpoLineList);
				newPoList.add(podetail);
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPoList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating receiving instructions::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_RECEIVE_ITEM, e);
		}
	}

	public List<ReceivingInstruction> receiveItems(PoLineDetail lineDetail, String deliveryType) {

		int recQty = 0;
		if (deliveryType.equals("reopened")) {
			recQty = 10;
		} else {
			recQty = lineDetail.getRecvQty();
		}
		int orderedQty = Integer.parseInt(lineDetail.getPoVnpkQty());
		int totalReceivedQty = 0;
		List<ReceivingInstruction> recvInstrList = new ArrayList<ReceivingInstruction>();
		try {
			// Thread.sleep(2000);
			int casesperPallet = Integer.parseInt(lineDetail.getTi()) * Integer.parseInt(lineDetail.getHi());
			int i = 0;
			while (recQty > 0) {
				receivingScanUPCPage.scanupc(lineDetail.getCaseUpc());
				ReceivingInstruction recvInstr = new ReceivingInstruction();
				int instructionQty = 0;
				if (i == 0) {
					String ItemNbrStr = receivingItemQtyPage.getItemNbr();
					Assert.assertEquals(ErrorCodes.RDC_FAILED_VALIDATE_ITEM, lineDetail.getItemNumber(),
							ItemNbrStr.substring(9));
				}
				if (recQty >= casesperPallet) {

					totalReceivedQty += casesperPallet;
					receivingItemQtyPage.enterReceiveQtyAndReceive(String.valueOf(casesperPallet));
					instructionQty = casesperPallet;
					if (totalReceivedQty > orderedQty) {
						receivingItemQtyPage.clickOvgWarningBtn();
					}
				} else if (recQty < casesperPallet) {

					totalReceivedQty += recQty;
					receivingItemQtyPage.enterReceiveQtyAndReceive(String.valueOf(recQty));
					int slotSize = recQty * 4;
					receivingItemQtyPage.confirmSlotSizeForPartialReceiving(String.valueOf(slotSize));
					receivingItemQtyPage.clickReceiveBtn();
					if (totalReceivedQty > orderedQty) {
						receivingItemQtyPage.clickOvgWarningBtn();
					}
					instructionQty = recQty;
				}
				String containerTrackingId = getContainerNbr(containerList);
				containerList.add(containerTrackingId);
				logger.info("container parent:" + containerTrackingId);

				recvInstr.setReceivedQuantity(String.valueOf(instructionQty));
				recvInstr.setChannelType("SSTKU");
				recvInstr.setDestNumber("32679");
				recvInstr.setIsVTR(false);
				recvInstr.setIsDamage(false);
				recvInstr.setParentContainer(containerTrackingId);

				recvInstrList.add(recvInstr);
				logger.info("containerList parent:" + om.writeValueAsString(recvInstrList));
				recQty = recQty - instructionQty;
				i++;
			}

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_RECEIVE_ITEM, e);
		}

		return recvInstrList;

	}

	public String getContainerNbr(List cntrList) {

		String containerTrackingId = null;
		try {
			Thread.sleep(5000);
			logger.info("containerI List:" + om.writeValueAsString(cntrList));
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);
			List<Map<String, Object>> trackingList = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING,
					environment.getProperty("rdc_get_containers"), deliveryNum,
					environment.getProperty("facility_num"));
			logger.info("containerI List:" + om.writeValueAsString(trackingList));
			for (Map<String, Object> containerMap : trackingList) {
				String trackingId = (String) containerMap.get("TRACKING_ID");
				if (!cntrList.contains(trackingId)) {
					containerTrackingId = trackingId;
					break;
				}
			}
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_GET_RECEIVED_CONTAINER, e);
		}
		logger.info("containerId:" + containerTrackingId);
		return containerTrackingId;
	}

	@Step
	public void validateContainersInReceiving() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			JSONArray listOfRecvInstr = JsonPath.read(testFlowData, GET_RECEIVING_INSTRUCTIONS);
			String recvInstrString = listOfRecvInstr.toJSONString();
			List<ReceivingInstruction> recvInstrList = objectMapper.readValue(recvInstrString,
					new TypeReference<List<ReceivingInstruction>>() {
					});
			Map<String, String> cntrMap = new HashMap<String, String>();

			Failsafe.with(retryPolicy).run(() -> {

				List<Map<String, Object>> trackingList = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING,
						environment.getProperty("rdc_get_containers_details"), deliveryNum,
						environment.getProperty("facility_num"));

				for (Map<String, Object> cntrDetails : trackingList) {

					String cntr = (String) cntrDetails.get("TRACKING_ID");
					int qty = (int) cntrDetails.get("QUANTITY");
					int vnpk = (int) cntrDetails.get("VNPK_QTY");
					String qtyInCases = String.valueOf(qty / vnpk);
					cntrMap.put(cntr, qtyInCases);

				}
				logger.info("container details DB:" + om.writeValueAsString(cntrMap));

				Assert.assertEquals(ErrorCodes.RDC_FAILED_VALIDATE_CONTAINERS_IN_RECEIVING, recvInstrList.size(),
						cntrMap.size());

				for (ReceivingInstruction recvInstr : recvInstrList) {
					logger.info("validating the container:" + recvInstr.getParentContainer());
					String cntrQty = cntrMap.get(recvInstr.getParentContainer());
					Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_QTY_IN_RECEIVING,
							recvInstr.getReceivedQuantity(), cntrQty);
				}
			});
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_VALIDATE_CONTAINERS_IN_RECEIVING, e);
		}
	}

	@Step
	public void validateReceiptsInReceiving() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			Map<String, String> receiptsMap = new HashMap<String, String>();

			List<Map<String, Object>> receiptsList = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING,
					environment.getProperty("rdc_get_receipts"), deliveryNum, environment.getProperty("facility_num"));

			for (Map<String, Object> rcptDetails : receiptsList) {

				int receivedQty = (int) rcptDetails.get("QUANTITY");
				int lineNumber = (int) rcptDetails.get("PURCHASE_REFERENCE_LINE_NUMBER");
				String poNbr = (String) rcptDetails.get("PURCHASE_REFERENCE_NUMBER");
				String mapKey = poNbr + lineNumber;
				if (receiptsMap.containsKey(mapKey)) {
					int existingrecvQty = Integer.parseInt(receiptsMap.get(mapKey));
					int newRecvQty = existingrecvQty + receivedQty;
					receiptsMap.put(mapKey, String.valueOf(newRecvQty));
				} else {
					receiptsMap.put(mapKey, String.valueOf(receivedQty));
				}
			}

			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPoList = new ArrayList<PoDetail>();

			for (PoDetail podetail : poList) {
				List<PoLineDetail> poLineList = podetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					String expectedReceivedQty = String.valueOf(lineDetail.getRecvQty());
					String actualreceivedQty = receiptsMap.get(podetail.getPoNumber() + lineDetail.getPoLineNumber());

					Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_RECEIPTS_IN_RECEIVING, expectedReceivedQty,
							actualreceivedQty);
				}
			}

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_RECEIPTS_IN_RECEIVING, e);
		}
	}

	@Step
	public void validateContainersInRDS() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			List<String> parentCntrsList = parsedtestflowJson.read(GET_PARENT_CNTRS);

			String[] cntrArr = new String[parentCntrsList.size()];
			for (int i = 0; i < parentCntrsList.size(); i++) {
				cntrArr[i] = "00" + parentCntrsList.get(i);
			}

			Map<String, String> rdscntrMap = new HashMap<String, String>();

			Failsafe.with(retryPolicy).run(() -> {

				List<Map<String, Object>> rdstrackingList = dbUtils.selectFrom(PRODUCT_NAME.RDS, dbUtils
						.transformIntoSpringQuery(environment.getProperty("rds_get_tracking_IDs"), cntrArr.length),
						cntrArr);
				logger.info("size of th trackingIDs list:" + rdstrackingList.size());
				Assert.assertNotEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS, 0, rdstrackingList.size(),
						"");
				for (Map<String, Object> trackingrecord : rdstrackingList) {

					String cntrID = (String) trackingrecord.get("rcv_unit_tag_id");
					int cntrQty = (int) trackingrecord.get("whpk_qty");
					rdscntrMap.put(cntrID.substring(2).trim(), String.valueOf(cntrQty));
					logger.info("containerId" + cntrID);
					logger.info("qty" + cntrQty);
					if (cntrQty == 0) {
						Assert.assertFalse(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS, true, "");
					}
				}
				Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS, parentCntrsList.size(),
						rdstrackingList.size());
			});

			JSONArray listOfRecvInstr = JsonPath.read(testFlowData, GET_RECEIVING_INSTRUCTIONS);
			String recvInstrString = listOfRecvInstr.toJSONString();
			List<ReceivingInstruction> recvInstrList = objectMapper.readValue(recvInstrString,
					new TypeReference<List<ReceivingInstruction>>() {
					});
			for (ReceivingInstruction recvInstr : recvInstrList) {

				String expectedCntrQty = recvInstr.getReceivedQuantity();
				String actualCntrQty = rdscntrMap.get(recvInstr.getParentContainer());

				Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS, expectedCntrQty,
						actualCntrQty);
			}

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS, e);
		}
	}

	@Step
	public void finalizeDelivery() {
		try {
			receivingScanUPCPage.compleDelivery();
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_COMPLETE_DELIVERY_IN_RECEIVING, e);
		}
	}

	@Step
	public void createDockTag() {
		try {
			receivingScanUPCPage.clickCreateDockTag();

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			JSONArray listOfdelivery = JsonPath.read(testFlowData, GET_DELIVERY_DETAILS);
			String deliveryString = listOfdelivery.toJSONString();
			List<DeliveryDetail> deliveryList = objectMapper.readValue(deliveryString,
					new TypeReference<List<DeliveryDetail>>() {
					});
			List<String> docktagIdList = new ArrayList<String>();
			List<DeliveryDetail> newDeliveryList = new ArrayList<DeliveryDetail>();

			for (DeliveryDetail deliverydetail : deliveryList) {

				Failsafe.with(retryPolicy).run(() -> {
					List<Map<String, Object>> dockTagList = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING,
							environment.getProperty("rdc_get_dock_tags"), deliverydetail.getDeliveryNumber(),
							environment.getProperty("facility_num"));

					Assert.assertNotEquals(ErrorCodes.RDC_DOCKTAG_NOT_GENERATED, 0, dockTagList.size());

					for (Map<String, Object> dockTag : dockTagList) {
						docktagIdList.add((String) dockTag.get("DOCK_TAG_ID"));
					}
					deliverydetail.setDockTags(docktagIdList);
					newDeliveryList.add(deliverydetail);
				});
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.deliveryDetails",
					JsonPath.parse(om.writeValueAsString(newDeliveryList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after updating docktag details::{}", tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_COMPLETE_DOCKTAG, e);
		}
	}

	@Step
	public void receiveDockTag() {

		String dockTagId = null;
		String location = null;
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<List<String>> dockTagList = parsedtestflowJson.read(GET_DOCK_TAGS);
			List<String> doorList = parsedtestflowJson.read(GET_DOOR_NBR);

			receivingScanUPCPage.navigateToMainMenu();
			receivingDoorScanPage.navigateToDockTagScreen();
			dockTagLocationPage.enterDockTagLocation(doorList.get(0));
			for (int i = 0; i < dockTagList.size(); i++) {
				dockTagScanPage.enterDockTag(dockTagList.get(0).get(i));
				Thread.sleep(3000);
				receiveRDCItems("sstk");
				dockTagScanPage.navigateToDockTagPage();
			}
			dockTagScanPage.navigateToDockTagPage();
			dockTagLocationPage.navigateScanDoorPage();

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_RECEIVE_DOCKTAG, e);
		}
	}

	@Step
	public void completeDockTag() {
		String dockTagId = null;
		String location = null;
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<List<String>> dockTagList = parsedtestflowJson.read(GET_DOCK_TAGS);
			List<String> doorList = parsedtestflowJson.read(GET_DOOR_NBR);

			receivingDoorScanPage.navigateToDockTagScreen();
			dockTagLocationPage.enterDockTagLocation(doorList.get(0));
			for (int i = 0; i < dockTagList.size(); i++) {
				dockTagScanPage.enterDockTag(dockTagList.get(0).get(i));
				String dockTagConfirmationMsg = dockTagReceivePage.completeDockTag();
				// Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_DOCKTAG_COMPLETE_MSG,
				// "", dockTagConfirmationMsg);
			}
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_RECEIVE_DOCKTAG, e);
		}
	}

	@Step
	public void performPalletCorrection() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			receivingScanUPCPage.navigateToMainMenu();
			receivingDoorScanPage.navigateToPalletCorrectionScreen();

			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPoList = new ArrayList<PoDetail>();

			for (PoDetail podetail : poList) {
				List<PoLineDetail> poLineList = podetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					List<ReceivingInstruction> recvInstrList = lineDetail.getReceivingInstructions();
					ReceivingInstruction recvInstr = recvInstrList.get(0);
					String newPalletQty = null;
					boolean cancelPallet = false;
					if (lineDetail.getPoLineNumber().equals("1")) {
						recvInstr.setIsVTR(true);
						recvInstr.setvtrQty(10);
						newPalletQty = String.valueOf(Integer.parseInt(recvInstr.getReceivedQuantity()) - 10);
					} else if (lineDetail.getPoLineNumber().equals("2")) {
						recvInstr.setIsVTR(true);
						recvInstr.setvtrQty(Integer.parseInt(recvInstr.getReceivedQuantity()));
						newPalletQty = "0";
					} else if (lineDetail.getPoLineNumber().equals("3")) {
						recvInstr.setIsVTR(true);
						recvInstr.setvtrQty(Integer.parseInt(recvInstr.getReceivedQuantity()));
						newPalletQty = "0";
						cancelPallet = true;
					} else {
						continue;
					}

					palletCorrectionPage.scanThePallet(recvInstr.getParentContainer());
					String label = palletCorrectionHomePage.getLabel();
					String item = palletCorrectionHomePage.getItem();
					String cases = palletCorrectionHomePage.getcases();

					Assert.assertEquals(ErrorCodes.RDC_FAILED_VALIDATE_LABEL_IN_RC, recvInstr.getParentContainer(),
							label);
					Assert.assertEquals(ErrorCodes.RDC_FAILED_VALIDATE_ITEM_IN_RC, lineDetail.getItemNumber(), item);
					Assert.assertEquals(ErrorCodes.RDC_FAILED_VALIDATE_QUANTITY_IN_RC, recvInstr.getReceivedQuantity(),
							cases);

					if (cancelPallet) {
						palletCorrectionHomePage.cancelLabel();
					} else {
						palletCorrectionHomePage.navigateToUpdatePalletQtyScreen();
						palletCorrectionUpdatePage.updatePalletQuantity(newPalletQty);
					}
				}
			}
			Thread.sleep(3000);
			palletCorrectionPage.navigateToDoorScanPage();

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(poList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after Pallet Correction::{}", tl.get().get(TEST_FLOW_DATA));
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_PERFORM_RECEIVING_CORRECTION, e);
		}
	}

	@Step
	public void validateContainersAfterReceivingCorrection() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			JSONArray listOfRecvInstr = JsonPath.read(testFlowData, GET_RECEIVING_INSTRUCTIONS);
			String recvInstrString = listOfRecvInstr.toJSONString();
			List<ReceivingInstruction> recvInstrList = objectMapper.readValue(recvInstrString,
					new TypeReference<List<ReceivingInstruction>>() {
					});
			Map<String, String> cntrMap = new HashMap<String, String>();

			for (ReceivingInstruction recvInstr : recvInstrList) {

				int recevQty = Integer.parseInt(recvInstr.getReceivedQuantity());
				int vrQty = recvInstr.getvtrQty();
				int deltaQty = recevQty - vrQty;

				List<Map<String, Object>> trackingList = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING,
						environment.getProperty("rdc_get_containers_tracking_details"), recvInstr.getParentContainer());

				int qty = (int) trackingList.get(0).get("QUANTITY");
				int vnpk = (int) trackingList.get(0).get("VNPK_QTY");
				int qtyInCases = qty / vnpk;
				Assert.assertEquals(ErrorCodes.RDC_CONTAINER_QUANTITY_MISMATCH_AFTER_RC, deltaQty, qtyInCases);
			}
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_CONTAINER_QUANTITY_MISMATCH_AFTER_RC, e);
		}
	}

	@Step
	public void validateReceiptsAfterReceivingCorrection() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPoList = new ArrayList<PoDetail>();

			for (PoDetail podetail : poList) {
				List<PoLineDetail> poLineList = podetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					List<String> recvQtyList = parsedtestflowJson
							.read("$.testFlowData.poDetails[*].poLineDetails[?(@.poLineNumber=="
									+ lineDetail.getPoLineNumber() + ")].receivingInstructions[*].receivedQuantity");
					List<Integer> vtrQtyList = parsedtestflowJson
							.read("$.testFlowData.poDetails[*].poLineDetails[?(@.poLineNumber=="
									+ lineDetail.getPoLineNumber() + ")].receivingInstructions[*].vtrQty");
					int RecvQty = 0;
					int totalVtrQty = 0;
					for (int i = 0; i < recvQtyList.size(); i++) {
						RecvQty += Integer.parseInt(recvQtyList.get(i));
						totalVtrQty += vtrQtyList.get(i);
					}

					int actualRecvQty = RecvQty - totalVtrQty;
					int totalRecvQtyDB = 0;

					List<Map<String, Object>> receiptsList = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING,
							environment.getProperty("rdc_get_receipts_by_line_number"), deliveryNum,
							environment.getProperty("facility_num"), podetail.getPoNumber(),
							lineDetail.getPoLineNumber());

					for (Map<String, Object> rcptDetails : receiptsList) {

						int receivedQty = (int) rcptDetails.get("QUANTITY");
						totalRecvQtyDB = totalRecvQtyDB + receivedQty;
					}

					Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_RECEIPTS_IN_RECEIVING_AFTER_RC, actualRecvQty,
							totalRecvQtyDB);
					lineDetail.setRecvQty(actualRecvQty);
					int ovgShortQty = Integer.parseInt(lineDetail.getPoVnpkQty()) - actualRecvQty;
					if (ovgShortQty >= 0) {
						lineDetail.setOvgQty(String.valueOf(0));
						lineDetail.setOverageFlag("s");
						lineDetail.setShortQty(String.valueOf(ovgShortQty));
					} else {
						lineDetail.setOvgQty(String.valueOf(Math.abs(ovgShortQty)));
						lineDetail.setOverageFlag("o");
						lineDetail.setShortQty(String.valueOf(0));
					}
				}
			}

			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(poList)).read("$", JSONArray.class));
			String str = context.jsonString();
			tl.get().put(TEST_FLOW_DATA, str);
			logger.info("testData after validating Receipts for Receiving correction::{}",
					tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_RECEIPTS_IN_RECEIVING_AFTER_RC, e);
		}
	}

	@Step
	public void validateContainersInRDSAfterRC() {
		try {

			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			List<String> parentCntrsList = parsedtestflowJson.read(GET_PARENT_CNTRS);

			String[] cntrArr = new String[parentCntrsList.size()];
			for (int i = 0; i < parentCntrsList.size(); i++) {
				cntrArr[i] = "00" + parentCntrsList.get(i);
			}

			Map<String, String> rdscntrMap = new HashMap<String, String>();

			Failsafe.with(retryPolicy).run(() -> {

				List<Map<String, Object>> rdstrackingList = dbUtils.selectFrom(PRODUCT_NAME.RDS, dbUtils
						.transformIntoSpringQuery(environment.getProperty("rds_get_tracking_IDs"), cntrArr.length),
						cntrArr);
				logger.info("size of th trackingIDs list:" + rdstrackingList.size());
				Assert.assertNotEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS_AFTER_RC, 0,
						rdstrackingList.size(), "");
				for (Map<String, Object> trackingrecord : rdstrackingList) {

					String cntrID = (String) trackingrecord.get("rcv_unit_tag_id");
					int cntrQty = (int) trackingrecord.get("whpk_qty");
					rdscntrMap.put(cntrID.substring(2).trim(), String.valueOf(cntrQty));
					logger.info("containerId" + cntrID);
					logger.info("qty" + cntrQty);
				}
			});

			JSONArray listOfRecvInstr = JsonPath.read(testFlowData, GET_RECEIVING_INSTRUCTIONS);
			String recvInstrString = listOfRecvInstr.toJSONString();
			List<ReceivingInstruction> recvInstrList = objectMapper.readValue(recvInstrString,
					new TypeReference<List<ReceivingInstruction>>() {
					});
			for (ReceivingInstruction recvInstr : recvInstrList) {

				int newexpectedCntrQty = Integer.parseInt(recvInstr.getReceivedQuantity()) - recvInstr.getvtrQty();
				int actualCntrQty = Integer.parseInt(rdscntrMap.get(recvInstr.getParentContainer()));

				Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS_AFTER_RC, newexpectedCntrQty,
						actualCntrQty);
			}

		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS_AFTER_RC, e);
		}
	}

	@Step
	public void catalogItems() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPoList = new ArrayList<PoDetail>();

			for (PoDetail podetail : poList) {
				List<PoLineDetail> poLineList = podetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					receivingScanUPCPage.scanupc(lineDetail.getCaseUpc());
					// String appErrorMsg = receivingScanUPCPage.getupcErrorTxt();
					// String updateGtinErrorTxt = environment.getProperty("update_gtin_error_msg");
					// updateGtinErrorTxt.replaceAll("#", lineDetail.getCaseUpc());
					// logger.info("error message expected:" + updateGtinErrorTxt);
					// Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_UPDATE_GTIN_ERROR_MSG,
					// updateGtinErrorTxt,
					// appErrorMsg);
					receivingScanUPCPage.clickUpdateGtin();
					itemCatalogHomePage.enterItemNumber(String.valueOf(javaUtil.randonNumberGenerator(6)));
					String invalidItemAppMsg = itemCatalogHomePage.getinvalidItemErrorMsg();
					String invalidItemErrorMsg = environment.getProperty("invalid_item_error_msg");
					Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_INVALID_ITEM_ERROR_MSG, invalidItemErrorMsg,
							invalidItemAppMsg);
					itemCatalogHomePage.enterItemNumber(lineDetail.getItemNumber());
					String updatedGTIN = itemCatalogUpdatePage.getupdatedGTIN();
					String item = itemCatalogUpdatePage.getItem();

					Assert.assertEquals(ErrorCodes.RDC_MISMATCH_IN_UPDATED_GTIN, lineDetail.getCaseUpc(), updatedGTIN);
					Assert.assertEquals(ErrorCodes.RDC_MISMATCH_IN_UPDATED_ITEM, lineDetail.getItemNumber(), item);
					itemCatalogUpdatePage.clickUpdate();
					Thread.sleep(5000);
					receivingItemQtyPage.performPalletCancel();
				}
			}
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_FAILED_TO_RECEIVE_ITEM, e);
		}
	}

	@Step
	public void validateGDMForItemCatalog() {
		try {
			String testFlowData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info(testFlowData);

			DocumentContext parsedtestflowJson = JsonPath.parse(testFlowData);
			DocumentContext context = null;

			List<String> deliveryList = parsedtestflowJson.read(GET_DELIVERY);
			String deliveryNum = deliveryList.get(0);

			String deliveryresponse = rdcUtil.getrdcDelivery(deliveryNum);
			DocumentContext parseddeliveryResponseJson = JsonPath.parse(deliveryresponse);

			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = objectMapper.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPoList = new ArrayList<PoDetail>();

			for (PoDetail podetail : poList) {
				List<PoLineDetail> poLineList = podetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					List<String> caseUpcList = parseddeliveryResponseJson
							.read("$.deliveryDocuments[?(@.purchaseReferenceNumber=='" + podetail.getPoNumber()
									+ "')].deliveryDocumentLines[?(@.purchaseReferenceLineNumber=='"
									+ lineDetail.getPoLineNumber() + "')].vendorUPC");
					Assert.assertEquals(ErrorCodes.RDC_GDM_MISMATCH_IN_CASE_UPC_AFTER_ITEM_CATALOG,
							lineDetail.getCaseUpc(), caseUpcList.get(0));
				}
			}
		} catch (Exception e) {
			throw new TestCaseFailure(ErrorCodes.RDC_GDM_FAILED_TO_VALIDATE_CASEUPC_AFTER_ITEM_CATALOG, e);
		}
	}

}
