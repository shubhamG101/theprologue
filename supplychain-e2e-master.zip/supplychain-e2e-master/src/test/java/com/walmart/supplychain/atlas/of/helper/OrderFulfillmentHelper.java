package com.walmart.supplychain.atlas.of.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.walmart.framework.utilities.javautils.Assert;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderFulfillmentHelper {
	Config config = new Config();
	Logger logger = LogManager.getLogger(this.getClass());
	// JsonUtils jsonUtils = new JsonUtils();

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	TextParser textParser;

	@Autowired
	JsonUtils jsonUtils;

	String readTestFlowdata;
	private DocumentContext parsedRcvInst;

	@Autowired
	Environment environment;

	public Headers prePareHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		return new Headers(headerList);
	}

	public net.minidev.json.JSONArray initializeMessageList() {
		readTestFlowdata = (String) tl.get().get("testFlowData");
		return JsonPath.read(readTestFlowdata,
				"$.testFlowData.poDetails.[*].poLineDetails.[*].receivingInstructions.[*].messageId");

	}

	
}
