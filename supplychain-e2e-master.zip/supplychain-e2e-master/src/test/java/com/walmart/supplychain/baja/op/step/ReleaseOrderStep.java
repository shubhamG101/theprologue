package com.walmart.supplychain.baja.op.step;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.op.CycleWavelist;
import com.walmart.framework.supplychain.domain.op.ReleaseOrder;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ContainerDetails;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OrdersDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReleaseDetails;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReleaseOrderStep {

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	JsonUtils jsonUtils;

	List<ReleaseDetails> releaseDetails = new ArrayList<>();
	String testFlowData;
	String time = "T00:00:00";

	Logger logger = LogManager.getLogger(this.getClass());

	@Step
	public void userReleaseOrders(String cycleNbr, String waveNbr) throws JSONException, JsonProcessingException {

		try {
			logger.info("Releasing order");

			String testFlowData = String.valueOf(tl.get().get("testFlowData"));

			CycleWavelist wave = new CycleWavelist();
			wave.setcycleNbr(cycleNbr);
			wave.setwaveNbr(waveNbr);
			ObjectMapper om = new ObjectMapper();
			List waveList = new ArrayList();
			waveList.add(wave);
			JavaUtils javautils = new JavaUtils();
			ReleaseOrder releaseOrder = new ReleaseOrder();
			releaseOrder.setCycleWaveList(waveList);
			releaseOrder.setcreateTs(javautils.getCurrentDate().concat(time));
			releaseOrder.setcreateUserId("sysadmin");
			releaseOrder.seteffectiveReleaseDate(javautils.getCurrentDate());
			releaseOrder.setorgUnitId(2);
			releaseOrder.setreleaseMsgTxt("Test");

			String requestBodyFailSafe = om.writeValueAsString(releaseOrder);
			logger.info("Check payload for Release Order-->" + requestBodyFailSafe);

			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 3, 3)).run(() -> {

				Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe).post(
						"http://lb-node.cluster3.cloud.s32800.us.wal-mart.com/us-32837/wave-release/orders/release/waverelease");
				Assert.assertEquals(ErrorCodes.BAJA_ORDER_RELEASE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				JSONArray releaseWaveID = JsonPath.parse(response.getBody().asString()).read("$..releaseWaveId",
						JSONArray.class);
				logger.info("Release ID generated" + releaseWaveID);
				
				ReleaseDetails releaseObj = new ReleaseDetails();
				releaseObj.setReleaseNumber(releaseWaveID.get(0).toString());
				releaseObj.setCycleNumber(cycleNbr);
				releaseObj.setWaveNumber(waveNbr);
				releaseObj.setLoadId("");

				releaseDetails.add(releaseObj);

				String testFlowData_updated = jsonUtils.setJsonAtJsonPath(testFlowData, releaseDetails,
						"$..testFlowData.releaseDetails");
				tl.get().put("testFlowData", testFlowData_updated);
				logger.info("TestFlowData after updating release number details :"
						+ String.valueOf(tl.get().get("testFlowData")));
			});
			
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while releasing the orders", e);
		}

	}
}
