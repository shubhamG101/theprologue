package com.walmart.supplychain.catalyst.by.webservices.steps;

import static net.serenitybdd.rest.SerenityRest.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;

import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class BYWebservicesSteps extends ScenarioSteps{
	
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	DbUtils dbUtils;
	
	@Autowired
	JavaUtils javaUtils;
	
	
	@Autowired
	BYWebservicesHelper byWebservicesHelper;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);
	
	
	private Response response;
	private static Cookies cookies;
	private static final String TEST_FLOW_DATA = "testFlowData";
	
	
	private static final String DELIVERY_NUMBER_JSONPATH = "$.testFlowData.deliveryDetails..deliveryNumber";
	private static final String PO_NUMBER_JSONPATH = "$.testFlowData.poDetails..poNumber";
	private static final String TRAILER_NUMBER_JSONPATH = "$.testFlowData.deliveryDetails..inboundTrailerNumber";
	private static final String INBOUND_YARD_ZONE_JSONPATH = "$.testFlowData.deliveryDetails..inboundYardZone";
	private static final String INBOUND_DOOR_JSONPATH = "$.testFlowData.deliveryDetails..inboundDoorNumber";
	
	
	private static final String BY_IBD_SHIPMENT_STATUS_JSONPATH = "$.inboundShipments..inboundShipmentStatus";
	private static final String BY_PO_JSONPATH = "$.plannedInboundOrderLines..plannedInboundOrderNumber";
	private static final String BY_ITEM_JSONPATH = "$.plannedInboundOrderLines..itemNumber";
	private static final String BY_EQUIPMENT_STATUS_JSONPATH = "$.transportEquipment..status";
	private static final String BY_EQUIPMENT_NUMBER_JSONPATH = "$.transportEquipment..transportEquipmentNumber";
	private static final String BY_EQUIPMENT_CURRENT_LOCATION_JSONPATH = "$.transportEquipment..yardLocation";
	private static final String BY_EQUIPMENT_SAFETY_CHECK_STATUS_JSONPATH = "$.transportEquipment..safetyCheckStatus";
	private static final String BY_IBD_SHIPMENT_RESOURCE_ID_JSONPATH = "$.inboundShipments..resourceId";
	private static final String IB_HACCP_LPN_NUMBER_JSON_PATH = "$.testFlowData..receivingInstructions..parentContainer";

	private static List<String> deliveryNumber;
	private static List<String> poNumber;
	private static List<String> itemNumbers;
	private static List<String> inboundTrailerNumber;
	private static List<String> inboundShipmentResourceId;
	private static List<String> inboundDoorNumber;
	private String problemPONumber;
	private String problemItemNumber;
		
	String expectedItem = null;
	
	@Step
	public void verifyInboundShipment_EqiupmentStatus(String shipmentStatus, String equipmentStatus) {
		
		try {

			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			
			//fetching delivery number
			deliveryNumber = JsonPath.read(testFlowData, DELIVERY_NUMBER_JSONPATH);
			logger.info("Expected Delivery number : {} ", deliveryNumber.get(0));
			
			//fetching PO number
			poNumber = JsonPath.read(testFlowData, PO_NUMBER_JSONPATH);
			logger.info("Expected PO number : {} ", poNumber);
			
			if(equipmentStatus.equalsIgnoreCase("Expected"))
				cookies = byWebservicesHelper.getAuthorization();
			
			
			verifyShipmentStatus(shipmentStatus, deliveryNumber.get(0));
			setDeliveryUpdatedStatusInTestflowdata(shipmentStatus);
			
			verifyEquipmentStatus(equipmentStatus, deliveryNumber.get(0));
			
			if(equipmentStatus.equalsIgnoreCase("Expected"))
				verifyPO_And_ItemDetails(deliveryNumber.get(0), poNumber);
				
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying inbound shipment or equipment status through BY services", e);
		}
		
	}
	
	
	public void verifyShipmentStatus(String expectedStatus, String expectedDeliveryNumber) {
		
		Failsafe.with(retryPolicy).run(() -> {
			
			response = byWebservicesHelper.getInboundShipmentResponse(expectedDeliveryNumber);
			logger.info("Staus code after hitting inbound shipment api: {}", response.getStatusCode());
			
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			logger.info("Response after hitting inbound shipment api: {}", response.asString());
			
			//Validating delivery status
			List<String> actualDeliveryStatus = JsonPath.read(response.asString(), BY_IBD_SHIPMENT_STATUS_JSONPATH);
			logger.info("Actual delivery Status : {}", actualDeliveryStatus.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_DELIVERY_STATUS, expectedStatus.toUpperCase(), actualDeliveryStatus.get(0));
			logger.info("Validated successfully inbound shipment status as {}", actualDeliveryStatus.get(0));
			
			
			//Fetching resource id for inbound shipment number
			inboundShipmentResourceId = JsonPath.read(response.asString(), BY_IBD_SHIPMENT_RESOURCE_ID_JSONPATH);
			logger.info("Resource id for inbound shipment : {}", inboundShipmentResourceId.get(0));
		});
		
	}
	

	
	public void verifyEquipmentStatus(String expectedStatus, String expectedDeliveryNumber) { 
		
		Failsafe.with(retryPolicy).run(() -> {
			
			response = byWebservicesHelper.getTransportEqipmentResponse(expectedDeliveryNumber);
			logger.info("Staus code after hitting transport equipment api: {}", response.getStatusCode());
			
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_EQUIPMENT_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			logger.info("Response after hitting transport equipment api: {}", response.asString());
			
			//Validating equipment status
			List<String> actualEquipmentStatus = JsonPath.read(response.asString(), BY_EQUIPMENT_STATUS_JSONPATH);
			logger.info("Actual Equipment Status : {}", actualEquipmentStatus.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_STATUS, expectedStatus.toUpperCase(), actualEquipmentStatus.get(0));
			logger.info("Validated successfully equipment status as {}", actualEquipmentStatus.get(0));
		});
		
	}

	
	
	public void verifyPO_And_ItemDetails(String expectedDeliveryNumber, List<String> expectedPONumber) {
		
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
		Failsafe.with(retryPolicy).run(() -> {
			
			response = byWebservicesHelper.getPO_ItemResponse(expectedDeliveryNumber);
			logger.info("Status code after hitting po lines api: {}", response.getStatusCode());
			
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			logger.info("Response after hitting po lines api: {}", response.asString());
			
			//validating PO number
			List<String> actualPONumber = JsonPath.read(response.asString(), BY_PO_JSONPATH);
			logger.info("Actual PO number: {}", actualPONumber);
			Collections.sort(expectedPONumber);
			Collections.sort(actualPONumber);
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_IBD_SHIPMENT_PO_NUMBER, expectedPONumber, actualPONumber);
			logger.info("Validated successfully PO numbers {}", actualPONumber);
			
			
			//Validating item numbers
			for(String currentPONumber : poNumber) {
				
				itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..itemNumber");
				logger.info("Expected Item numbers are {} for PO number {}", itemNumbers, currentPONumber);
				
				List<String> actualItemNumbers = JsonPath.read(response.asString(), 
						"$.plannedInboundOrderLines[?(@.plannedInboundOrderNumber=='"+currentPONumber+"')]..itemNumber");
				logger.info("Actual items for PO {} : {}", currentPONumber, actualItemNumbers);
				Collections.sort(itemNumbers);
				Collections.sort(actualItemNumbers);
				Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_IBD_SHIPMENT_ITEM_NUMBER, itemNumbers, actualItemNumbers);
				logger.info("Validated successfully Item numbers for PO ", currentPONumber);
			}
			
		});
		
	}
	
	
	
	@Step
	public void verifyCheckedInLocation() {
		
		try {
			
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			
			//fetching expected trailer number
			inboundTrailerNumber = JsonPath.read(testFlowData, TRAILER_NUMBER_JSONPATH);
			logger.info("Trailer number to be validated: {} ", inboundTrailerNumber.get(0));
			
			//fetching expected trailer yard location
			List<String> inboundYardZone = JsonPath.read(testFlowData, INBOUND_YARD_ZONE_JSONPATH);
			logger.info("Trailer yard location to be validated: {} ", inboundYardZone.get(0));
			
			Failsafe.with(retryPolicy).run(() -> {
				
				response = byWebservicesHelper.getTransportEqipmentResponse(deliveryNumber.get(0));
				logger.info("Staus code after hitting transport equipment api: {}", response.getStatusCode());
				Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_EQUIPMENT_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
				
				//validating inbound trailer equipment number
				List<String> actualEquipmentNumber = JsonPath.read(response.asString(), BY_EQUIPMENT_NUMBER_JSONPATH);
				logger.info("Actual equipment number : {}", actualEquipmentNumber.get(0));
				Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_NUMBER, inboundTrailerNumber.get(0), actualEquipmentNumber.get(0));
				logger.info("Validated successfully equipment number as {}", actualEquipmentNumber.get(0));
				
			});
			
			verifyEuipmentLocation(inboundYardZone.get(0));
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying shipment checked in location through BY services", e);
		}
	}
	
	
	public void verifyEuipmentLocation(String expectedLocation) {
		
		//validating inbound trailer equipment current location
		Failsafe.with(retryPolicy).run(() -> {
			
			response = byWebservicesHelper.getTransportEqipmentResponse(deliveryNumber.get(0));
			logger.info("Response after hitting transport equipment api: {}", response.asString());
			List<String> actualEquipmentLocation = JsonPath.read(response.asString(), BY_EQUIPMENT_CURRENT_LOCATION_JSONPATH);
			logger.info("Actual equipment location : {}", actualEquipmentLocation.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_LOCATION, expectedLocation, actualEquipmentLocation.get(0));
			logger.info("Validated successfully equipment current location as {}", actualEquipmentLocation.get(0));
		});
		
	}
	
	
	@Step
	public void verifyAssignedDoorLocation() {
		
		try {
			
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			
			//fetching expected assigned door location for trailer
			inboundDoorNumber = JsonPath.read(testFlowData, INBOUND_DOOR_JSONPATH);
			logger.info("Trailer door location to be validated: {} ", inboundDoorNumber.get(0));
			
			Failsafe.with(retryPolicy).run(() -> {
				
				response = byWebservicesHelper.getTransportEqipmentResponse(deliveryNumber.get(0));
				logger.info("Staus code after hitting transport equipment api: {}", response.getStatusCode());
				Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_EQUIPMENT_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			});
			
			verifyEuipmentLocation(inboundDoorNumber.get(0));
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying shipment assigned door location and safety check status through BY services", e);
		}
	}
	
	@Step
	public void verifyTrailerSafetyCheckStatus(String expectedStatus) {
		
		try {
			
			Failsafe.with(retryPolicy).run(() -> {
				
				//validating safety check status
				response = byWebservicesHelper.getTransportEqipmentResponse(deliveryNumber.get(0));
				List<String> actualSafetyCheckStatus = JsonPath.read(response.asString(), BY_EQUIPMENT_SAFETY_CHECK_STATUS_JSONPATH);
				logger.info("Actual safety check status : {}", actualSafetyCheckStatus.get(0));
				Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_SAFETY_CHECK_STATUS, expectedStatus.toUpperCase(), actualSafetyCheckStatus.get(0));
				logger.info("Validated successfully equipment safety status as {}", actualSafetyCheckStatus.get(0));
			});
			
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying trailer safety check status through BY services", e);
		}
		
	}
	
	
	public void setDeliveryUpdatedStatusInTestflowdata(String updatedDeliveryStatus) throws IOException, ParseException {
		
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		
		JSONArray jsonArrayOfOBDetails = JsonPath.read(runTimeData, "$.testFlowData.deliveryDetails[*]");
		
		List<DeliveryDetail> deliveryDetailObj = (List<DeliveryDetail>) jsonUtils
				.getPojoListfromPath(jsonArrayOfOBDetails.toJSONString(), DeliveryDetail.class);
		
		deliveryDetailObj.get(0).setDeliveryStatus(updatedDeliveryStatus.toUpperCase());
		
		JSONArray deliveryDetailsList = jsonUtils.converyListToJsonArray(deliveryDetailObj);

		JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
		String testFlowData = jsonUtils.setJsonAtJsonPath(parentObject.toJSONString(), deliveryDetailsList,
				"$.testFlowData.deliveryDetails");
		
		threadLocal.get().put(TEST_FLOW_DATA, testFlowData);
		logger.info("Updated delivery status field as {} value in test flow data!!", updatedDeliveryStatus);
		logger.info("testFlowData after updating delivery details:{}", testFlowData);
	}
	
	
	@Step
	public void verifyReceivedContainerDetails() {
		
		try {
			
			logger.info("Inbound shipment resource id to be used for getting container details response: {}", inboundShipmentResourceId.get(0));
			
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			
			for(String currentPONumber : poNumber) {
				
				itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..itemNumber");
				logger.info("Expected Item numbers for LPN validation corrosponding to PO number {} : {}", currentPONumber, itemNumbers);
				
				for(String currentItem : itemNumbers) {
					
					//Validating received LPNs for current item
					logger.info("Current item: {}", currentItem);
					List<String> expectedReceivedLPNs = JsonPath.read(testFlowData,
							"$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')]..receivingInstructions..parentContainer");
					logger.info("Expected Received LPNs: {}", expectedReceivedLPNs);
					
					if(!expectedReceivedLPNs.isEmpty()) {
						
						Failsafe.with(retryPolicy).run(() -> {
							
							response = byWebservicesHelper.getContainerDetailsResponse(inboundShipmentResourceId.get(0));
							logger.info("Staus code after hitting container details api: {}", response.getStatusCode());
							Assert.assertEquals(ErrorCodes.CATALYST_BY_CONTAINER_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
							logger.info("Response after hitting received container details api: {}", response.asString());

							//problem LPN
							List<String> ActualReceivedLPNs = new ArrayList<String>();
							for(String currentLPN : expectedReceivedLPNs) {
								
								List<String> lpnExpectedStatus = JsonPath.read(testFlowData,
										"$.testFlowData..receivingInstructions[?(@.parentContainer=='"+currentLPN+"')]..receivedStatus");
								
								if(lpnExpectedStatus.get(0).equalsIgnoreCase("Problems")) {
									expectedItem = "PROBLEM1";
									ActualReceivedLPNs = JsonPath.read(response.asString(), "$.inventory[?(@.itemNumber=='"+expectedItem+"')]..lpn");
								}
								else 
									ActualReceivedLPNs = JsonPath.read(response.asString(), "$.inventory[?(@.itemNumber=='"+currentItem+"')]..lpn");
							}

							logger.info("Actual Received LPNs: {}", ActualReceivedLPNs);
							
							Collections.sort(expectedReceivedLPNs);
							Collections.sort(ActualReceivedLPNs);
							Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPNs, expectedReceivedLPNs, ActualReceivedLPNs);
							logger.info("Validated successfully the received LPNs");
						});
						
						
						//Validating individual LPN details
						for(String currentLPN : expectedReceivedLPNs) {
							
							logger.info("Current LPN: {}", currentLPN);
							
							//Validating inbound shipment number attached to the current LPN
							verifyAttachedIBDShipment_CurrentLPN(currentLPN);
							
							//Validating door location from where items was being received
							verifyReceivedLPNLocation(currentLPN);
							
							//Validating received LPN status
							verifyReceivedLPNStatus(currentLPN, "useTestFlowData");
							
							//Validating LPN's received quantity
							verifyReceivedLPNQuantity(currentLPN);
						}
					}
					
					else
						logger.info("There were no expected received LPNs to validate for item {}", currentItem);
					
				}
			}
				
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying received container details through BY services", e);
		}
		
	}
	
	
	public void verifyAttachedIBDShipment_CurrentLPN(String currentLPN) {
		
		List<String> ActualIBDShipmentNumberForCurrentLPN = JsonPath.read(response.asString(), 
				"$.inventory[?(@.lpn=='"+currentLPN+"')].inboundShipmentId..inboundShipmentNumber");
		Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_DELIVERY_STATUS, deliveryNumber.get(0), ActualIBDShipmentNumberForCurrentLPN.get(0));
		logger.info("Validated successfully inbound shipment number as {} for current LPN {}", ActualIBDShipmentNumberForCurrentLPN.get(0), currentLPN);
	}
	
	public void verifyReceivedLPNLocation(String currentLPN) {
		
		List<String> ActualLocationForCurrentLPN = JsonPath.read(response.asString(), "$.inventory[?(@.lpn=='"+currentLPN+"')]..locationNumber");
		logger.info("Actual current LPN location: {}", ActualLocationForCurrentLPN.get(0));
		String expectedDoorLocation = "RCVSTG" + inboundDoorNumber.get(0);
		Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPN_LOCATION, expectedDoorLocation, ActualLocationForCurrentLPN.get(0));
		logger.info("Validated successfully LPN location as {} for current LPN {}", ActualLocationForCurrentLPN.get(0), currentLPN);
	}
	
	public void verifyReceivedLPNStatus(String currentLPN, String expectedStatus) {
		
		List<String> currentLPNExpectedStatus = new ArrayList<String>();
		if(expectedStatus.equalsIgnoreCase("useTestFlowData")) {
			
			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
			currentLPNExpectedStatus = JsonPath.read(testFlowData,
					"$.testFlowData..receivingInstructions[?(@.parentContainer=='"+currentLPN+"')]..receivedStatus");
		}
		else
			currentLPNExpectedStatus.add(expectedStatus);
		
		logger.info("Current LPN Expected Status: {}", currentLPNExpectedStatus.get(0));
		
		String lpnExpectedStatusCode = null;
		switch(currentLPNExpectedStatus.get(0)) {
		
			case "Available" :
				lpnExpectedStatusCode = "AVAL";
				break;
			
			case "QC Inspect" :
				lpnExpectedStatusCode = "QCI";
				break;
			
			//need to check on exact status code
			case "Damage" :
				lpnExpectedStatusCode = "DMG";
				break;
				
			case "Problems" :
				lpnExpectedStatusCode = "PROB";
				break;
				
			case "Return On Carrier" :
				lpnExpectedStatusCode = "ROC";
				break;
				
			//Further cases will be added based on different kinds of receiving LPN status
		}
		
		List<String> currentLPNActualStatus = JsonPath.read(response.asString(), "$.inventory[?(@.lpn=='"+currentLPN+"')]..inventoryStatus");
		logger.info("Current LPN Actual Status: {}", currentLPNActualStatus.get(0));
		
		Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPN_STATUS, lpnExpectedStatusCode, currentLPNActualStatus.get(0));
		logger.info("Validated successfully LPN status as {} for current LPN {}", currentLPNActualStatus.get(0), currentLPN);
	}
	
	public void verifyReceivedLPNQuantity(String currentLPN) {
		
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
		List<String> currentLPNExpectedReceivedCase = JsonPath.read(testFlowData,
				"$.testFlowData..receivingInstructions[?(@.parentContainer=='"+currentLPN+"')]..receivedQuantity");
		
		int expectedCase = Integer.parseInt(currentLPNExpectedReceivedCase.get(0));
		List<Integer> actualUntisPerCase = JsonPath.read(response.asString(), "$.inventory[?(@.lpn=='"+currentLPN+"')]..unitsPerCase");
		logger.info("Actual units per case : {}", actualUntisPerCase.get(0));
		
		int expectedReceivedQty_CurrentLPN = expectedCase * actualUntisPerCase.get(0);
		logger.info("Current LPN expected received quantity : {}", expectedReceivedQty_CurrentLPN);
		
		List<Integer> actualReceivedQty_CurrentLPN = JsonPath.read(response.asString(), "$.inventory[?(@.lpn=='"+currentLPN+"')]..unitQuantity");
		logger.info("Current LPN actual received quantity : {}", actualReceivedQty_CurrentLPN.get(0));
		
		Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPN_QUANTITY, expectedReceivedQty_CurrentLPN, actualReceivedQty_CurrentLPN.get(0));
		logger.info("Validated successfully LPN received quantity as {} for current LPN {}", actualReceivedQty_CurrentLPN.get(0), currentLPN);
	}

	@Step
	public void verifyNewAddedPODetails() {
		try {

			String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();	
			Failsafe.with(retryPolicy).run(() -> {
			cookies = byWebservicesHelper.getAuthorization();
			List<String> problemDeliveryNumber = JsonPath.read(testFlowData, DELIVERY_NUMBER_JSONPATH);
			response = byWebservicesHelper.getPO_ItemResponse(problemDeliveryNumber.get(0));
			logger.info("Status code after hitting po lines api: {}", response.getStatusCode());
			
			Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_DELIVERY_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
			
			logger.info("Response after hitting po lines api: {}", response.asString());
		});
			
		
			List<String> actualPoNumbers = JsonPath.read(response.asString(), "$..plannedInboundOrderLines[?(@.receiveStatus=='PROB')]..plannedInboundOrderNumber");
			List<String> actualItemNumbers = JsonPath.read(response.asString(), "$..plannedInboundOrderLines[?(@.receiveStatus=='PROB')]..itemNumber");
						
			String expectedProblemItemNum = "PROBLEM1";
			
			for(String currentItem : actualItemNumbers) {
				
				Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_PROBLEM_ITEM_NOT_FOUND, expectedProblemItemNum, currentItem);
			}
			
			//fetching all poNumbers from the response
			for (int i=0; i < actualPoNumbers.size(); i++) {
				boolean flag = false;
				if(actualPoNumbers.get(i).startsWith("PROB")) {
					flag = true;
					//Validating problemPO for unexpected item received
					logger.info("plannedInboundOrderNumber number for unexpected item: {}", actualPoNumbers.get(i));				
					Assert.assertEquals(ErrorCodes.CATALYST_BY_SERVICE_PROBLEM_PO_NOT_FOUND, true, flag);
					logger.info("Problem ASN successfully got generated on receiving unexpected item: {}", actualPoNumbers.get(i));
				}
					
			}
			
//		return problemPONumber;
		setPONumbersInTestflowdata(actualPoNumbers);
		} catch (AssertionError | FailsafeException e) {
		throw new TestCaseFailure(e);
		} catch (Exception e) {
		throw new AutomationFailure(
				"Something went wrong while verifying received problem ASN details through BY services", e);
			}
		}
	

	public void setPONumbersInTestflowdata(List<String> updatePONumber) throws IOException, ParseException {
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		
		JSONArray jsonArrayOfPODetails = JsonPath.read(runTimeData, "$.testFlowData.deliveryDetails[*]");
		
		List<DeliveryDetail> deliveryDetailObj = (List<DeliveryDetail>) jsonUtils
				.getPojoListfromPath(jsonArrayOfPODetails.toJSONString(), DeliveryDetail.class);
		List<String> currentPO = deliveryDetailObj.get(0).getPoNumbers();
		logger.info("Current PO returned: {}", currentPO);
		for(String problemPO : updatePONumber) {
			currentPO.add(problemPO);
			}
		logger.info("New plannedInboundOrderNumber returned: {}", currentPO);
		
		deliveryDetailObj.get(0).setPoNumbers(currentPO);
		
		JSONArray deliveryDetailsList = jsonUtils.converyListToJsonArray(deliveryDetailObj);

//		JSONObject parentObject = jsonUtils.convertStringToMinidevJsonObject(runTimeData);
		String testFlowData = jsonUtils.setJsonAtJsonPath(runTimeData, deliveryDetailsList,
				"$.testFlowData.deliveryDetails");
		
		threadLocal.get().put(TEST_FLOW_DATA, testFlowData);
		logger.info("Updated Planned Inbound Order field as {} value in test flow data!!", currentPO);
		logger.info("testFlowData after updating delivery details:{}", testFlowData);
	}

	//Validating the Inventory Status change from QCI To Available
	@Step
	public void validateLPNStatusInInventoryModule(String status) {

		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		List<String> haccpLPN = JsonPath.read(runTimeData, IB_HACCP_LPN_NUMBER_JSON_PATH);
		verifyHACCPInventoryStatus(haccpLPN.get(0),status);

	}
	
	public void verifyHACCPInventoryStatus(String haccpLPN, String statusOfLpn) {

		try {
			Failsafe.with(retryPolicy).run(() -> {
				
				logger.info("inboundShipmentResourceId====================="+inboundShipmentResourceId);
				response = byWebservicesHelper.getContainerDetailsResponse(inboundShipmentResourceId.get(0));
				logger.info("inboundShipmentResource RESPONSE ========================================= {}", response.asString());
				logger.info("Staus code after hitting container details api: {}", response.getStatusCode());
				Assert.assertEquals(ErrorCodes.CATALYST_BY_CONTAINER_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE,response.getStatusCode());
			});
			
			verifyReceivedLPNStatus(haccpLPN, statusOfLpn);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure(
					"Something went wrong while verifying received container details through BY services", e);
		}
	}
	
	
	@Step
	public void verifyRocStatusLpnMovedToPermanentStorageLocation(String expectedStorageLocation) {
		
		try {
			
			Failsafe.with(retryPolicy).run(() -> {
				
				response = byWebservicesHelper.getContainerDetailsResponse(inboundShipmentResourceId.get(0));
				logger.info("Staus code after hitting container details api: {}", response.getStatusCode());
				Assert.assertEquals(ErrorCodes.CATALYST_BY_CONTAINER_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE, response.getStatusCode());
				
				logger.info("Response after hitting received container details api: {}", response.asString());
				List<String> ActualLocationForRocStatusLpn = JsonPath.read(response.asString(), "$.inventory[?(@.inventoryStatus=='ROC')]..locationNumber");
				logger.info("Actual storage location for ROC status LPNs: {}", ActualLocationForRocStatusLpn);
				
				for(String currentLocation : ActualLocationForRocStatusLpn) {
					
					logger.info("Current storage location for ROC status LPN: {}", currentLocation);
					Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ROC_LPN_STORAGE_LOCATION, expectedStorageLocation, currentLocation);
				}
				
				logger.info("Validated successfully the storage location for ROC status LPNs");
			});
			
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying received LPNs with ROC status are moved to storage location", e);
		}
		
	}
}

