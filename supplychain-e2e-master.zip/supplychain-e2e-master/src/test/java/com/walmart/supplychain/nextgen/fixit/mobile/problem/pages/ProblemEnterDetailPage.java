package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

public class ProblemEnterDetailPage extends MobilePageObject {
	Logger logger = LogManager.getLogger(this.getClass());
	
	public ProblemEnterDetailPage(WebDriver driver){
        super(driver);
    }
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Problem qty']")
	private WebElement problemQty_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Ti']")
	private WebElement ti_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Hi']")
	private WebElement hi_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='PO Number on case']")
	private WebElement poNumber_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Comments']")
	private WebElement comments_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Comments*']")
	private WebElement commentsForHazmat_Textbox;
	
	/*@AndroidFindBy(xpath = "//android.widget.EditText[@text='Shipped to']")
	private WebElement shippedTo_Textbox;
	*/
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Original Destination']")
	private WebElement shippedTo_Textbox;
	
	//wrong dc
	@AndroidFindBy(xpath = "//*[@text='Destination']")
	private WebElement destination_Textbox;
	
	//wrong pack
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_itemNumber']")
	private WebElement itemNumber_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_systemVnpk']")
	private WebElement systemVNPK_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_systemWhpk']")
	private WebElement systemWHPK_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Received VNPK']")
	private WebElement receivedVNPK_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Received WHPK']")
	private WebElement receivedWHPK_Textbox;
	// end
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	public WebElement next_Button;
	
	//3pl 
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_sell_by_date']")
	private WebElement sellByDate_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/next']")
	private WebElement forwardDate_Link;
	
	@AndroidFindBy(xpath = "//*[@text='14']")
	private WebElement date_Link;
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	private WebElement ok_Button;
	
	//RDC changes
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_problemQty']")
	private WebElement exceptionQty_Textbox;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_field'])[1]")
	private WebElement pallet1_Textbox;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_field'])[2]")
	private WebElement pallet2_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/btn_addPallet']")
	private WebElement addPallet_Textbox;
	
	@AndroidFindBy(xpath = "//*[@text='Save']")
	private WebElement save_Button;
	
	//Damage elements
	@AndroidFindBy(xpath ="//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_reclaimQty']")
	private WebElement reclaim_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_destroyQty']")
	private WebElement destroy_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_sendToCarrierQty']")
	private WebElement sendBackToCarried_Textbox;
	
	@AndroidFindBy(xpath = "//*[@text='Physical Damage']")
	private WebElement physicalDamage_Button;
	
	@AndroidFindBy(xpath = "//*[@text='Concealed']")
	private WebElement concealed_Button;
	
	@AndroidFindBy(xpath = "//*[@text='Wet']")
	private WebElement wet_Button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/add_image_camera']")
	private WebElement addImage_Icon;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/btn_takepicture']")
	private WebElement takePicture_Button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/et_damageComment']")
	private WebElement comment_Textbox;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@index='1']")
	private WebElement trailer_Image;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.android.packageinstaller:id/permission_allow_button']")
	private WebElement allowPermission_Button;
	
	@AndroidFindBy(xpath = "//*[@text='Reason']")
	private WebElement reason_Dropdown;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/pb_page']")
	private WebElement reasonCode;
	
	//Pharmacy
	@AndroidFindBy(xpath = "//*[@text='VNPK']")
	private WebElement vnpk_Button;

	@AndroidFindBy(xpath = "//*[@text='WHPK']")
	private WebElement whpk_Button;

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Comments, Optional']")
	private WebElement comment_field;

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='PO Number on case, Optional']")
	private WebElement poNumber_field;

	//mcc
	@AndroidFindBy(xpath = "//*[@text='Pallet']")
	private WebElement pallet_Button;

	public void enterExceptionDetails(String problemQty,String ti,String hi,String poNumber,String comment) {
		problemQty_Textbox.sendKeys(problemQty);
		getAndroidDriver().hideKeyboard();
		ti_Textbox.sendKeys(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		comments_Textbox.sendKeys(comment);
		getAndroidDriver().hideKeyboard();
		poNumber_Textbox.sendKeys(poNumber);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}
	
	public void enterExceptionDetailsForNotWalmartFreight(String problemQty,String ti,String hi,String shipedTo,String comment) {
		problemQty_Textbox.sendKeys(problemQty);
		getAndroidDriver().hideKeyboard();
		ti_Textbox.sendKeys(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		shippedTo_Textbox.sendKeys(shipedTo);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		comments_Textbox.sendKeys(comment);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}
	
	public void enterExceptionDetailsForWrongDC(String problemQty,String ti,String hi,String destination,String comment) {
		problemQty_Textbox.sendKeys(problemQty);
		getAndroidDriver().hideKeyboard();
		ti_Textbox.sendKeys(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		comments_Textbox.sendKeys(comment);
		getAndroidDriver().hideKeyboard();
		destination_Textbox.sendKeys(destination);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}
	
	public void enterExceptionDetailsForHazmat(String problemQty,String ti,String hi,String comment) {
		problemQty_Textbox.sendKeys(problemQty);
		getAndroidDriver().hideKeyboard();
		ti_Textbox.sendKeys(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		comments_Textbox.sendKeys(comment);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}

	public void enterExceptionDetailsForWrongPack(String problemQty,String ti,String hi,String comment,String receivedVNPK,String receivedWHPK) {
		problemQty_Textbox.sendKeys(problemQty);
		getAndroidDriver().hideKeyboard();
		ti_Textbox.sendKeys(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		comments_Textbox.sendKeys(comment);
		getAndroidDriver().hideKeyboard();
		receivedVNPK_Textbox.sendKeys(receivedVNPK);
		getAndroidDriver().hideKeyboard();
		receivedWHPK_Textbox.sendKeys(receivedWHPK);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
	    return (AndroidDriver<AndroidElement>)
	            ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
	
	public void enterExceptionDetailsForQualityIssue(String problemQty,String ti,String hi,String comment,String type,String poNumber) {
		element(problemQty_Textbox).waitUntilVisible();
		element(problemQty_Textbox).type(problemQty);
		getAndroidDriver().hideKeyboard();
		element(ti_Textbox).waitUntilVisible();
		element(ti_Textbox).type(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		element(sellByDate_Textbox).waitUntilVisible();
		element(sellByDate_Textbox).click();
		element(forwardDate_Link).waitUntilVisible();
		element(forwardDate_Link).click();
		element(forwardDate_Link).click();
		element(forwardDate_Link).click();
		element(date_Link).waitUntilVisible();
		element(date_Link).click();
		element(ok_Button).waitUntilVisible();
		element(ok_Button).click();
		if(type.equalsIgnoreCase("NOP"))
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type(poNumber);
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comment);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}
	
	public void enterExceptionDetailsWrongPackForSams(String problemQty,String ti,String hi,String comment,String rcvdVNPK,String rcvdWHPK) {
		element(problemQty_Textbox).waitUntilVisible();
		element(problemQty_Textbox).type(problemQty);
		getAndroidDriver().hideKeyboard();
		element(ti_Textbox).waitUntilVisible();
		element(ti_Textbox).type(ti);
		hi_Textbox.sendKeys(hi);
		getAndroidDriver().hideKeyboard();
		element(sellByDate_Textbox).waitUntilVisible();
		element(sellByDate_Textbox).click();
		element(forwardDate_Link).waitUntilVisible();
		element(forwardDate_Link).click();
		element(forwardDate_Link).click();
		element(forwardDate_Link).click();
		element(date_Link).waitUntilVisible();
		element(date_Link).click();
		element(ok_Button).waitUntilVisible();
		element(ok_Button).click();
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		element(comments_Textbox).waitUntilVisible();
		element(comments_Textbox).type(comment);
		element(receivedVNPK_Textbox).waitUntilVisible();
		element(receivedVNPK_Textbox).type(rcvdVNPK);
		getAndroidDriver().hideKeyboard();
		element(receivedWHPK_Textbox).waitUntilVisible();
		element(receivedWHPK_Textbox).type(rcvdWHPK);
		getAndroidDriver().hideKeyboard();
		next_Button.click();
	}
	
	public void enterExceptionDetailsForRecallRdc(String problemQty,String pallet1,String pallet2,String comment) {
		element(exceptionQty_Textbox).waitUntilClickable();
		element(exceptionQty_Textbox).click();
		exceptionQty_Textbox.sendKeys(problemQty);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).click();
		element(pallet1_Textbox).clear();
		element(pallet1_Textbox).type(pallet1);
		getAndroidDriver().hideKeyboard();
		element(addPallet_Textbox).waitUntilClickable();
		element(addPallet_Textbox).click();
		getAndroidDriver().hideKeyboard();
		element(pallet2_Textbox).waitUntilVisible();
		element(pallet2_Textbox).click();
		element(pallet2_Textbox).clear();
		element(pallet2_Textbox).type(pallet2);
		getAndroidDriver().hideKeyboard();
		element(save_Button).waitUntilClickable();
		element(save_Button).click();
	}
	
	public void enterExceptionDetailsForWrongPackRdc(String problemQty,String pallet1,String pallet2,String comment,String receivedVNPK,String receivedWHPK,String exceptionName) {
		String market = Config.DC.getValue();
		if(market.equalsIgnoreCase("pharmacy") || market.equalsIgnoreCase("atlas") || market.equalsIgnoreCase("acc")){
			element(vnpk_Button).waitUntilVisible();
			element(vnpk_Button).click();
		}
		element(exceptionQty_Textbox).waitUntilClickable();
		element(exceptionQty_Textbox).click();
		exceptionQty_Textbox.sendKeys(problemQty);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).click();
//		element(pallet1_Textbox).clear();
//		element(pallet1_Textbox).type(pallet1);
//		getAndroidDriver().hideKeyboard();
//		element(addPallet_Textbox).waitUntilClickable();
//		element(addPallet_Textbox).click();
//		getAndroidDriver().hideKeyboard();
//		element(pallet2_Textbox).waitUntilVisible();
//		element(pallet2_Textbox).click();
//		element(pallet2_Textbox).clear();
//		element(pallet2_Textbox).type(pallet2);
		getAndroidDriver().hideKeyboard();
		element(save_Button).waitUntilClickable();
		element(save_Button).click();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		if(exceptionName.equals("WRONGPACK")) {
			element(receivedVNPK_Textbox).waitUntilVisible();
			element(receivedVNPK_Textbox).type(receivedVNPK);
			getAndroidDriver().hideKeyboard();
			element(receivedWHPK_Textbox).waitUntilVisible();
			element(receivedWHPK_Textbox).type(receivedWHPK);
			getAndroidDriver().hideKeyboard();
		}else if(exceptionName.equals("OVERAGE")) {
		}else if(exceptionName.equals("QUALITYISSUE")) {
		}else if(exceptionName.equals("DATEISSUE")) {
		}
		
	}

	public void enterExceptionDetails(String problemQty,String pallet1,String pallet2,String comments,String receivedVNPK,String receivedWHPK,String exceptionName, String poNumber, String shippedTo ,String market) throws InterruptedException {
		if(market.equalsIgnoreCase(DC_TYPE.PHARMACY.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue()) || market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
			element(vnpk_Button).waitUntilVisible();
			element(vnpk_Button).click();
		}
		element(exceptionQty_Textbox).waitUntilClickable();
		element(exceptionQty_Textbox).click();
		exceptionQty_Textbox.sendKeys(problemQty);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).click();
//		element(pallet1_Textbox).clear();
//		element(pallet1_Textbox).type(pallet1);
//		getAndroidDriver().hideKeyboard();
//		element(addPallet_Textbox).waitUntilClickable();
//		element(addPallet_Textbox).click();
//		getAndroidDriver().hideKeyboard();
//		element(pallet2_Textbox).waitUntilVisible();
//		element(pallet2_Textbox).click();
//		element(pallet2_Textbox).clear();
//		element(pallet2_Textbox).type(pallet2);
		getAndroidDriver().hideKeyboard();
		element(save_Button).waitUntilClickable();
		element(save_Button).click();
		if(exceptionName.equals("WRONGPACK")) {
			AppiumHelper.ScrollDown(getAndroidDriver());
			element(receivedVNPK_Textbox).waitUntilVisible();
			element(receivedVNPK_Textbox).type(receivedVNPK);
			getAndroidDriver().hideKeyboard();
			element(receivedWHPK_Textbox).waitUntilVisible();
			element(receivedWHPK_Textbox).type(receivedWHPK);
			getAndroidDriver().hideKeyboard();
		}else if(exceptionName.equals("NOTONPO")) {
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type(poNumber);
			AppiumHelper.ScrollDown(getAndroidDriver());
		}else if(exceptionName.equals("NOTWALMARTFREIGHT")) {
			element(poNumber_field).waitUntilVisible();
			element(poNumber_field).type(poNumber);
			AppiumHelper.ScrollDown(getAndroidDriver());
			element(shippedTo_Textbox).waitUntilVisible();
			element(shippedTo_Textbox).type(shippedTo);
			getAndroidDriver().hideKeyboard();
		}else if(exceptionName.equals("WRONGDC")){
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type(poNumber);
			AppiumHelper.ScrollDown(getAndroidDriver());
			element(destination_Textbox).waitUntilVisible();
			element(destination_Textbox).type(shippedTo);
			getAndroidDriver().hideKeyboard();
			uploadImage(market);
		}
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		element(comment_field).waitUntilVisible();
		element(comment_field).type(comments);
		getAndroidDriver().hideKeyboard();
	}

	public void enterExceptionDetailsForNotWalmartFreightRdc(String qty, String pallet1,String pallet2,String comments,String shippedTo,String poNumber) {
		String market = Config.DC.getValue();
		if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue()) || market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
			element(vnpk_Button).waitUntilVisible();
			element(vnpk_Button).click();
		}
		element(exceptionQty_Textbox).waitUntilClickable();
		element(exceptionQty_Textbox).click();
		element(exceptionQty_Textbox).type(qty);
		element(pallet1_Textbox).waitUntilVisible();
		element(pallet1_Textbox).click();
//		element(pallet1_Textbox).clear();
//		element(pallet1_Textbox).type(pallet1);
//		getAndroidDriver().hideKeyboard();
//		element(addPallet_Textbox).waitUntilClickable();
//		element(addPallet_Textbox).click();
//		getAndroidDriver().hideKeyboard();
//		element(pallet2_Textbox).waitUntilVisible();
//		element(pallet2_Textbox).click();
//		element(pallet2_Textbox).clear();
//		element(pallet2_Textbox).type(pallet2);
		getAndroidDriver().hideKeyboard();
		element(save_Button).waitUntilClickable();
		element(save_Button).click();
		element(poNumber_field).waitUntilVisible();
		element(poNumber_field).type(poNumber);
		AppiumHelper.ScrollDown(getAndroidDriver());
		element(shippedTo_Textbox).waitUntilVisible();
		element(shippedTo_Textbox).type(shippedTo);
		getAndroidDriver().hideKeyboard();
		AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
		element(comment_field).waitUntilVisible();
		element(comment_field).type(comments);
		getAndroidDriver().hideKeyboard();
	}
	
	public void enterDamageDetailsForPhysicalDamage(String reclaims, String destory,
			String sendBackToCarrier,String comments,String dmgType,String market) {
		try {
			if(market.equalsIgnoreCase(DC_TYPE.PHARMACY.getValue()) || market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
				element(vnpk_Button).waitUntilVisible();
				element(vnpk_Button).click();
			}else if(market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				element(pallet_Button).waitUntilVisible();
				element(pallet_Button).click();
			}
			element(reclaim_Textbox).waitUntilClickable();
			element(reclaim_Textbox).type(reclaims);
			element(destroy_Textbox).waitUntilClickable();
			element(destroy_Textbox).type(destory);
			element(sendBackToCarried_Textbox).waitUntilClickable();
			element(sendBackToCarried_Textbox).type(sendBackToCarrier);
			if(dmgType.equals("WET")) {
				element(wet_Button).waitUntilClickable();
				element(wet_Button).click();
				element(trailer_Image).waitUntilClickable();
				element(trailer_Image).click();
			}else if (dmgType.equals("CONCEALED")) {
				element(concealed_Button).waitUntilClickable();
				element(concealed_Button).click();
			}else if(dmgType.equals("PHYSICAL")) {
				element(physicalDamage_Button).waitUntilClickable();
				element(physicalDamage_Button).click();
			}
			AppiumHelper.scrollToElementInMObile("Comment",getAndroidDriver());
			uploadImage(market);
			element(comment_Textbox).waitUntilVisible();
			element(comment_Textbox).type(comments);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void enterExceptionDetailsForWrongDCRdc(String qty, String pallet1,String pallet2,String comments,String shippedTo,String poNumber) {
		try {
			String market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				element(vnpk_Button).waitUntilVisible();
				element(vnpk_Button).click();
			}
			element(exceptionQty_Textbox).waitUntilClickable();
			element(exceptionQty_Textbox).click();
			element(exceptionQty_Textbox).type(qty);
			element(pallet1_Textbox).waitUntilVisible();
			element(pallet1_Textbox).click();
//			element(pallet1_Textbox).clear();
//			element(pallet1_Textbox).type(pallet1);
//			getAndroidDriver().hideKeyboard();
//			element(addPallet_Textbox).waitUntilClickable();
//			element(addPallet_Textbox).click();
//			getAndroidDriver().hideKeyboard();
//			element(pallet2_Textbox).waitUntilVisible();
//			element(pallet2_Textbox).click();
//			element(pallet2_Textbox).clear();
//			element(pallet2_Textbox).type(pallet2);
			getAndroidDriver().hideKeyboard();
			element(save_Button).waitUntilClickable();
			element(save_Button).click();
			element(poNumber_Textbox).waitUntilVisible();
			element(poNumber_Textbox).type(poNumber);
			AppiumHelper.ScrollDown(getAndroidDriver());
			element(destination_Textbox).waitUntilVisible();
			element(destination_Textbox).type(shippedTo);
			getAndroidDriver().hideKeyboard();
			
			uploadImage(market);
			
			AppiumHelper.scrollToElementInMObile("Comments",getAndroidDriver());
			element(comment_field).waitUntilVisible();
			element(comment_field).type(comments);
			getAndroidDriver().hideKeyboard();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void uploadImage(String market) throws InterruptedException {
		element(addImage_Icon).waitUntilClickable();
		element(addImage_Icon).click();
//		boolean isAllowDisplayed=false;
//		try {
//			getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//			isAllowDisplayed=element(allowPermission_Button).isDisplayed();
//		}catch(NoSuchElementException e) {
//			isAllowDisplayed=false;
//			logger.info("Permission already granted");
//		}
//		if(isAllowDisplayed) {
//			allowPermission();
//		}
		getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if(!getAndroidDriver().findElements(By.id("com.android.packageinstaller:id/permission_allow_button")).isEmpty()){
			allowPermission();
		}else{
			logger.info("Permission already granted");
		}
		element(takePicture_Button).waitUntilVisible();
		element(takePicture_Button).waitUntilClickable();
		element(takePicture_Button).click();
		Thread.sleep(4000);
//		if(market.equalsIgnoreCase(DC_TYPE.RDC.getValue())) {
//			element(addImage_Icon).waitUntilClickable();
//			element(addImage_Icon).click();
//			Thread.sleep(2000);
//			element(takePicture_Button).waitUntilVisible();
//			element(takePicture_Button).waitUntilClickable();
//			element(takePicture_Button).click();
//			Thread.sleep(2000);
//			selectDmgReasonCode();
//		}
	}

	private void allowPermission() {
		logger.info("Allowing camera and storage permissions");
		element(allowPermission_Button).waitUntilClickable();
		element(allowPermission_Button).click();
		element(allowPermission_Button).waitUntilClickable();
		element(allowPermission_Button).click();
	}
	
	private void selectDmgReasonCode() {
		element(reason_Dropdown).waitUntilClickable();
		element(reason_Dropdown).click();
		element(reasonCode).waitUntilClickable();
		element(reasonCode).click();
	}

}
