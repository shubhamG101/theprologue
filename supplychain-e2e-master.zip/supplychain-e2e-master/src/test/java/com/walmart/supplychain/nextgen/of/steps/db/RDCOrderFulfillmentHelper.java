package com.walmart.supplychain.nextgen.of.steps.db;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.restassured.response.Response;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.supplychain.nextgen.of.pages.webservices.OrderFulfillmentHelper;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class RDCOrderFulfillmentHelper {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	MongoUtil mongoUtil;
	
	private String deliveryNumberFieldName="deliveryNumber";
	private String dbName="offline_fulfillment";
	private String collectionNameoffFull="offline_fulfillments";
	private String collectionNameoffDel="offline_delivery";
	private String xdocFieldName="xdockRecords";
	private String deliveryStatusFieldName="deliveryStatus";
	
	private String deliveryStatFieldName="deliveryStatus";
	private String statusInprogress="IN_PROGRESS";
	private String statusQueued="QUEUED";
	
	
	public String[] getXDOC(String deliveryNumber) throws SQLException {
		List<String> xdcoDataOrigin=null;
		String[] xdcoDataMod=null;
		
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		xdcoDataOrigin = mongoUtil.getDatafromDB(dbName, collectionNameoffDel, searchQuery, xdocFieldName);
		
		if ((xdcoDataOrigin!=null) && (!xdcoDataOrigin.isEmpty())) {
			 xdcoDataMod=xdcoDataOrigin.get(0).split(", TextMessage");
		}
		return xdcoDataMod;
	}

	public long getCountofXDOCRecords(String deliveryNumber) throws SQLException {
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		return mongoUtil.getRecordCount(dbName, collectionNameoffFull, searchQuery);
	}
	
	public  String getdeliveryStatus(String deliveryNumber) throws SQLException {
		String deliveryStatus=null;
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put(deliveryNumberFieldName, deliveryNumber);
		List<String> deliveryStatusRes = mongoUtil.getDatafromDB(dbName, collectionNameoffDel, searchQuery,deliveryStatusFieldName);
		if ((deliveryStatusRes!=null) && (!deliveryStatusRes.isEmpty())) {
			deliveryStatus= deliveryStatusRes.get(0);
			return deliveryStatus;
		}
		return deliveryStatus;
	}
	
	public void clearInprocessandQueuedXdocRec() {
		BasicDBObject case1 = new BasicDBObject();
		case1.put(deliveryStatFieldName, statusInprogress);
		BasicDBObject case2 = new BasicDBObject();
		case2.put(deliveryStatFieldName, statusQueued);
		BasicDBList or = new BasicDBList();
		or.add(case1);
		or.add(case2);
		DBObject searchQuery = new BasicDBObject("$or", or);
		mongoUtil.removeRecords(dbName,collectionNameoffDel, searchQuery);
	}
	
	
}
