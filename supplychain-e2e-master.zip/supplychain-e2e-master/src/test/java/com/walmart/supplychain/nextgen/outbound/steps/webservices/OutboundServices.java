package com.walmart.supplychain.nextgen.outbound.steps.webservices;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OutboundServices extends ScenarioSteps {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	@Autowired
	Environment environment;
	@Autowired
	JsonUtils jsonUtils;
	TextParser textParser = new TextParser();
	JavaUtils javaUtil = new JavaUtils();
	Logger logger = LogManager.getLogger(this.getClass());
	JsonUtils jsonUtil = new JsonUtils();

	private static final String INVALID_RESPONSE_CODE_TEXT = "Invalid response code ";
	public static final int SUCESS_STATUS_CODE = 201;
	private static final String STO_FILE_PATH = "/TestData/sto/";
	private static final String JSON_FORMAT = "application/json";
	private static final String MOCK_ADMIN_URL = "mock_admin_url";
	private static final String MOCK_ID_LIST_KEY = "listOfMocksToBeRemoved";

	@Step
	public void mockSto() {
		List<String> listOfMocksToBeRemoved = new ArrayList<>();
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		JSONArray outboundDetailsArray = JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*]");
		JSONArray poDetailsArray = JsonPath.read(testFlowData, "$.testFlowData.poDetails[*]");
		List<OutboundDetail> listOfLoads = null;
		List<PoDetail> listOfPODetails = null;
		try {
			listOfLoads = (List<OutboundDetail>) jsonUtils.getPojoListfromPath(outboundDetailsArray.toJSONString(),
					OutboundDetail.class);
			listOfPODetails = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsArray.toJSONString(),
					PoDetail.class);
		} catch (IOException e) {
			logger.error(e);
		}
		if (listOfLoads == null || listOfLoads.isEmpty())
			return;

		for (PoDetail poDetail : listOfPODetails) {
			for (PoLineDetail poLineDetail : poDetail.getPoLineDetails()) {
				String channel = getChannelForOutboundMock(poLineDetail);
				
				
					if (!channel.equals("")) {
						OutboundDetail load = getOutboundLoadForChannel(poLineDetail,channel,listOfLoads);
						try {
							logger.info("Mocking Channel:{} Dest:{} item:{}", channel, load.getDestNumber(),
									poLineDetail.getItemNumber());
							listOfMocksToBeRemoved.addAll(
									mockBatchStoNumberAndStoDetail(channel, load, poLineDetail.getItemNumber(),poLineDetail.getPoEvent()));
							if (threadLocal.get().get(MOCK_ID_LIST_KEY) != null) {
								listOfMocksToBeRemoved
										.addAll((ArrayList<String>) threadLocal.get().get(MOCK_ID_LIST_KEY));
							}
							threadLocal.get().put(MOCK_ID_LIST_KEY, listOfMocksToBeRemoved);
						} catch (URISyntaxException | IOException ex) {
							logger.error(ex);
							Assert.fail("STO Mock Failed:" + ex.getMessage());
						}
					} else {
						logger.info("No STO Mock required for containers of channel type {} for item{}", channel,
								poLineDetail.getItemNumber());
					}
				

			}
		}
		
		logger.info("TFD after STO numbers updation is:{}",threadLocal.get().get("testFlowData").toString());

	}

	@Step
	private List<String> mockBatchStoNumberAndStoDetail(String channel, OutboundDetail outboundDetail, String itemNumber,String poEvent)
			throws URISyntaxException, IOException {
		String destination=outboundDetail.getDestNumber();
		String batchFile = STO_FILE_PATH + channel.toLowerCase() + "_batch.txt";
		String stoFile = STO_FILE_PATH + channel.toLowerCase() + "_sto.txt";
		String stoDetailFile = STO_FILE_PATH + channel.toLowerCase() + "_sto_detail.txt";
		List<String> listOfUUIDs = new ArrayList<>();
		listOfUUIDs.add(mockBatch(batchFile, destination, itemNumber));
		listOfUUIDs.addAll(mockStoNumberAndStoDetail(stoFile, stoDetailFile, itemNumber, outboundDetail, channel,poEvent ));
		return listOfUUIDs;
	}

	@Step
	private String mockBatch(String batchFile, String destination, String itemNumber)
			throws URISyntaxException, IOException {
		String uuid = javaUtil.getUUID();
		String reqBody = textParser.readTextFile(batchFile);
		String batchId = String.valueOf(javaUtil.randonNumberGenerator(7));
		reqBody = format(reqBody, batchId, uuid, itemNumber);
		logger.info(reqBody);
		Response resp = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT).body(reqBody)
				.post(environment.getProperty(MOCK_ADMIN_URL));
		Assert.assertEquals(INVALID_RESPONSE_CODE_TEXT, SUCESS_STATUS_CODE, resp.getStatusCode());
		return uuid;

	}

	@Step
	private List<String> mockStoNumberAndStoDetail(String stoFile, String stoDetailFile, String itemNumber, OutboundDetail load,String channel,String poEvent)
			throws URISyntaxException, IOException {
		List<String> listOfUUIDs = new ArrayList<>();
		List<String> stoNumbers = JsonPath.read(threadLocal.get().get("testFlowData").toString(), "$..outboundDetails[?(@.loadId == "+ load.getLoadId()+")].stoNumbers[*]");
		String uuid = javaUtil.getUUID();
		String reqBody = textParser.readTextFile(stoFile);
		String stoNumber = String.valueOf(javaUtil.randonNumberGenerator(9));
		String legacyNumber = String.valueOf(javaUtil.randonNumberGenerator(9));
		reqBody = format(reqBody, legacyNumber, stoNumber, uuid, itemNumber);
		logger.info(reqBody);		
		try {
			if (channel.equalsIgnoreCase(CHANNELS.STAPLESTOCK.getValue())) 
				stoNumbers.add("1"+legacyNumber);		
			else if(channel.equalsIgnoreCase(CHANNELS.CROSSNA.getValue()))
				stoNumbers.add("2"+legacyNumber);
			else if(channel.equalsIgnoreCase(CHANNELS.CROSSNMA.getValue()))
				stoNumbers.add("3"+legacyNumber);
				
			load.setstoNumbers(stoNumbers);
			String newTestFlowData = jsonUtil.setJsonAtJsonPath((String)threadLocal.get().get("testFlowData"), load,"$..outboundDetails[?(@.loadId == "+ load.getLoadId()+")]");
			threadLocal.get().put("testFlowData", newTestFlowData);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Response resp = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT).body(reqBody)
				.post(environment.getProperty(MOCK_ADMIN_URL));
		Assert.assertEquals(INVALID_RESPONSE_CODE_TEXT, SUCESS_STATUS_CODE, resp.getStatusCode());
		listOfUUIDs.add(uuid);
		String mockStoDetailUUID = mockStoDetail(stoDetailFile, stoNumber, itemNumber,poEvent);
		listOfUUIDs.add(mockStoDetailUUID);
		return listOfUUIDs;
	}

	@Step
	private String mockStoDetail(String stoDetailFile, String stoNumber, String itemNumber,String poEvent)
			throws URISyntaxException, IOException {
		String uuid = javaUtil.getUUID();
		String reqBody = textParser.readTextFile(stoDetailFile);
		reqBody = format(reqBody, stoNumber, uuid, itemNumber,poEvent);
		logger.info(reqBody);
		Response resp = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT).body(reqBody)
				.post(environment.getProperty(MOCK_ADMIN_URL));
		Assert.assertEquals(INVALID_RESPONSE_CODE_TEXT, SUCESS_STATUS_CODE, resp.getStatusCode());
		return uuid;

	}

	private String format(String text, String... val2) {
		for (int occurence = 0; occurence < val2.length; occurence++) {
			text = text.replace("#" + occurence + "#", val2[occurence]);
		}
		return text;
	}

	public void cleanUpStoMocks() {
		try {
			@SuppressWarnings("unchecked")
			List<String> listOfMocksToBeRemoved = (List<String>) threadLocal.get().get(MOCK_ID_LIST_KEY);
			if (listOfMocksToBeRemoved == null || listOfMocksToBeRemoved.isEmpty())
				return;
			for (String mockId : listOfMocksToBeRemoved) {
				Response resp = SerenityRest.given().accept(JSON_FORMAT).contentType(JSON_FORMAT)
						.delete(environment.getProperty(MOCK_ADMIN_URL) + mockId);
				if (resp.getStatusCode() == 200)
					logger.info("Deleted Mock {}", mockId);
			}
		} catch (Exception ex) {
			logger.error(ex);
			// No need to fail this when there is a cleanup issue
		}
	}

	public String getChannelForOutboundMock(PoLineDetail poLineDetail) {
		for (ReceivingInstruction instruction : poLineDetail.getReceivingInstructions()) {
			String channel = instruction.getChannelType();
			if (channel.equalsIgnoreCase(CHANNELS.STAPLESTOCK.getValue())
					|| channel.equalsIgnoreCase(CHANNELS.CROSSNA.getValue())
					|| channel.equalsIgnoreCase(CHANNELS.CROSSNMA.getValue())) {
				return channel;
			}
		}
		return "";
	}

	public OutboundDetail getOutboundLoadForChannel(PoLineDetail poLineDetail,String channel,List<OutboundDetail> loads) {
		String dest="" ;
		for (ReceivingInstruction instruction : poLineDetail.getReceivingInstructions()) {
			if(instruction.getChannelType().equals(channel))
				dest=instruction.getDestNumber();
		}
		for(OutboundDetail outboundDetail:loads) {
			if(outboundDetail.getDestNumber().equals(dest))
				return outboundDetail;
		}
		return null;
	}

}
