package com.walmart.supplychain.thor.receiving.scenariosteps;

import com.walmart.supplychain.thor.receiving.steps.ThorReceivingStep;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ThorReceivingScenarios {
	
	@Steps
	ThorReceivingStep thorReceivingStep;
	
	@Given("^user does pre clean up for the item \"([^\"]*)\"$")
	public void userDoesPreCleanUpForTheItem(String itemNbr)
	{
		thorReceivingStep.preCleanUpForThor(itemNbr);
	}
	
	@When("^user changes the PO status to \"([^\"]*)\" and validates the change in status$")
	public void userChangesThePOStatus(String poStatus)
	{
		thorReceivingStep.changePOStatus(poStatus);
	}
	
	@When("^user receives the cases from Thor receiving$")
	public void userReceivesTheCasesFromThorReceiving()
	{
		thorReceivingStep.receiveThorSKUs();
	}

}
