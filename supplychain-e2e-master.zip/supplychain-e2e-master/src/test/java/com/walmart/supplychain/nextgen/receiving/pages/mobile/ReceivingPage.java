package com.walmart.supplychain.nextgen.receiving.pages.mobile;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import kafka.utils.threadsafe;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import spring.SpringTestConfiguration;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingPage extends SerenityHelper {
	@Autowired
	Environment endpoint;
	Logger logger = LogManager.getLogger(this.getClass());

	private static final String PRINTER_NAME = "emulator";

	// Receiving-Door scan page
	@FindBy(xpath = "//div[text()='Scan a door to begin receiving']")
	private WebElement scanDoorPannel;

	@FindBy(xpath = "//span[text()='PROCEED TO DELIVERY']")
	private WebElement proceedWithDeivery;

	@FindBy(xpath = "//button[@aria-label='MoreVert']/span")
	private WebElement selectProgramMenu;

	@FindBy(xpath = "//div[@id='atlas-menu']")
	private WebElement selectProgramIcon;

	@FindBy(xpath = "//div[div[text()='Receiving']]/button")
	private WebElement receivingMenu;

	@FindBy(xpath = "//div[text()='Printer']")
	private WebElement printerTab;

	@FindBy(xpath = "//input[contains(@id,'EnterPrinternametosearch')]")
	private WebElement searchPrinterTextbox;

	@FindBy(xpath = "//div[div[text()='Online Printers']]//div[2]/span")
	private WebElement onlinePrinterList;

	// Receiving-Trailer details page
	@FindBy(xpath = "//span[text()='PROCEED']")
	private WebElement proceedButton;

	@FindBy(xpath = "//div[text()='Inbound Door Receiving']")
	private WebElement inboundReceivingTab;

	@FindBy(xpath = "//div[@role='document']//div[contains(text(),'Trailer #')]")
	private WebElement trailerNumTextMssg;

	@FindBy(xpath = "//button[span[contains(text(),'Continue')]]")
	private WebElement trailerDetails_ContinueButton;

	// Receiving-Delivery home page
	@FindBy(xpath = "//div[contains(text(),'Delivery #')]")
	private WebElement deliveryNumTextMssg;

	@FindBy(xpath = "//div[div[div[text()='Select PO']]]//span[text()='Continue']")
	private WebElement itemOnMultiplePO_ContinueButton;

	@FindBy(xpath = "//span[text()='OK']")
	private WebElement confirmation_OK_Button;

	@FindBy(xpath = "(//div[contains(text(), 'scanned. Place on conveyor.')])[1]")
	private WebElement scannedItemMessage;

	@FindBy(xpath = "//span[text()='DISMISS']")
	private WebElement confirmation_dismiss_Buttom;

	@FindBy(xpath = "//div[text()='YES']")
	private WebElement confirmationYesButton;

	@FindBy(xpath = "//span[text()='Complete Delivery']")
	private WebElement completeDeliveryButton;
	
	@FindBy(xpath = "//span[text()='RECEIVE']")
	private WebElement receivingCorrection;

	@FindBy(xpath = "//span[text()='Complete Docktag']")
	private WebElement completeDockTagButton;

	@FindBy(xpath = "//div[contains(text(),'Great Job!')]")
	private WebElement deliveryCompleteTextMssg;

	@FindBy(xpath = "//div[text()='UPC ']")
	private WebElement upcLabelOnAttentionPopup;

	@FindBy(xpath = "//div[div[h2[text()='Are you sure?']]]//button/span[text()='Continue']")
	private WebElement deliveryCompleteConfimationPopup_ContinueButton;

	// Commented since in Dock tag message and normal flow button text is different
	// Used div appraoch as below which can be common for both scenarios
//	@FindBy(xpath = "//span[text()='Yes, I confirm ']")
//	private WebElement deliveryCompleteConfimationPopup_Confirm;

	@FindBy(xpath = "//div[@role='document']//div[3]/div[2]")
	private WebElement deliveryCompleteConfimationPopup_Confirm;

	@FindBy(xpath = "//div[div[h2[text()='Are you sure?']]]//button/span[text()='Go Back']")
	private WebElement deliveryCompleteConfimationPopup_GoBack;

	// Receive and Pallet creation page
	@FindBy(xpath = "//div[div[contains(text(),'Scan or enter quantity to receive')]]//input")
	private WebElement receiveQtyTextBox;

	@FindBy(xpath = "//div[div[contains(text(),'Cases')]/text()[preceding-sibling::br]]/div[1]")
	private WebElement qtyToReceiveText;

	@FindBy(xpath = "//div[contains(text(),'Cases Needed')]/preceding-sibling::div[1]")
	private WebElement qtyToReceiveTextWitron;

	@FindBy(xpath = "//div[contains(text(),'Enter expiration date to receive')]/parent::div//input")
	private WebElement selectExpiryDate;

	@FindBy(xpath = "//div[contains(text(),'Item is too close to expiration.')]")
	private WebElement itemTooCloseMessage;

	// div[contains(text(),'Item is too close to expiration.')]

	// div[contains(text(),'Enter expiration date to receive')]/parent::div//input

	@FindBy(xpath = "//span[text()='receive']")
	private WebElement receiveButton;

	@FindBy(xpath = "//span/div[contains(text(),'Receive')]")
	private WebElement receiveButtonWitron;
	
	@FindBy(xpath = "//button/span[contains(text(),'Receive')]")
	private WebElement receiveButtonWitronOverage;
	

	@FindBy(xpath = "//div[contains(text(),'Scan the next item')]")
	private WebElement scanNextUPCWitron;
	
	@FindBy(xpath = "//h2/div[contains(text(),'Close date alert')]")
	private WebElement closeDatePopUp;
	
	@FindBy(xpath = "//button/span[contains(text(),'Receive')]")
	private WebElement closeDateReceive;
	
	@FindBy(xpath = "//div[contains(text(),'Approve expiry date')]")
	private WebElement closeDateOverride;
	
	@FindBy(xpath = "//input[@id='manager-userid-input']")
	private WebElement closeDateOverrideUserId;
	
	@FindBy(xpath = "//input[@id='manager-password-input']")
	private WebElement closeDateOverridePass;
	
	@FindBy(xpath = "//span[contains(text(),'Approve')]")
	private WebElement closeDateOverrideApprove;
	
	
	//input[@id='manager-userid-input']
	
	//input[@id='manager-password-input']
	
	//span[contains(text(),'Approve')]
	
	
	@FindBy(xpath = "//div[text()='Pallet in progress']")
	private WebElement palletInprogressText;

	@FindBy(xpath = "//div[text()='Pallet complete']")
	private WebElement palletCompletedText;

	@FindBy(xpath = "//div[contains(text(),'Pallet ')]")
	private WebElement palletInProgressOrCompletedText;

	@FindBy(xpath = "//div[text()='Start a new Pallet']//parent::div/*[name()='svg']")
	private WebElement closeButtonWitron;

	@FindBy(xpath = "//header[div[div[text()='Pallet complete']]]/div/*[name()='svg']")
	private WebElement receivecloseButton;

	@FindBy(xpath = "//div[text()='Pallet completed']//parent::div/*[name()='svg']")
	private WebElement receivecloseButtonWit;

	@FindBy(xpath = "//div[@role='document']/div[*]/div[*]//span[text()='Finish Pallet']")
	private WebElement finishPalletButton;

	@FindBy(xpath = "//div[div[text()='Finish Pallet']]/div[3]/button/span[text()='Finish Pallet']")
	private WebElement finishPalletPopupButton;

	@FindBy(xpath = "//span[text()='Finish Pallet']")
	private WebElement finishPalletbuttonWit;

	@FindBy(xpath = "//div[@id='printer-settings-loader']/div/div/svg/circle")
	private WebElement pageloader;

	@FindBy(xpath = "//div[div[div[text()='Select Delivery Document Line']]]//span[text()='Continue']")
	private WebElement multiple_Delivery_DocumnentLines_ContinueButton;

	@FindBy(xpath = "//span[text()='GOT IT']")
	private WebElement gotItOption;

	@FindBy(xpath = "//div[text()='Problem Receiving']")
	private WebElement probRecvBtn;

	@FindBy(xpath = "//div[text()='Scan a problem label to begin receiving']")
	private WebElement probRecvScanScreen;

	//// input[@class='MuiInput-input-423']

	//// span[text()='START RECEIVING']

	@FindBy(xpath = "//span[text()='START RECEIVING']")
	private WebElement probRecvReceiveBtn;

	@FindBy(xpath = "//div//div//input")
	private WebElement probRecvInput;

	@FindBy(xpath = "//span[text()='receive']")
	private WebElement probRecv;

	@FindBy(xpath = "//input")
	private WebElement printerInput;

	@FindBy(xpath = "//div[div[text()='Online Printers']]//div[2]/span")
	private WebElement selectPrinter;

	@FindBy(xpath = "//span[text()='NEXT PALLET']")
	private WebElement nextpallet;

	@FindBy(xpath = "//div[@role='document']//span[text()='FINISH LABEL']")
	private WebElement finishPallet;

	@FindBy(xpath = "//div[div[text()='Start a new pallet']]/*[name()='svg']")
	private WebElement closeIcon;

	@FindBy(xpath = "//div[div[text()='Add to open pallet']]/*[local-name()='svg']")
	private WebElement closeIconForDockTag;

	@FindBy(xpath = "//span[text()='Cancel Pallet']")
	private WebElement cancelPallet;

	@FindBy(xpath = "//span[text()='NO']/../..//button[2]")
	private WebElement cancelPalletDiag;

	@FindBy(xpath = "//span[text()='Update Case UPC']")
	private WebElement upcUpdateDiagButton;

	@FindBy(xpath = "//div[text()='Next']")
	private WebElement confirmNext;

	@FindBy(xpath = "//div[@role='document']/div/div[5]//input")
	private WebElement upcUPdateEnterItemNumber;

	@FindBy(xpath = "//p[contains(text(),'update')]")
	private WebElement upcUpdateDiag;

	@FindBy(xpath = "//div[text()='Update']")
	private WebElement upcUpdated;

	@FindBy(xpath = "//span[text()='Enter Delivery Number']")
	private WebElement enterDeliveryNumberButton;

	@FindBy(xpath = "//div[@role='document']/div//input")
	private WebElement enterDeliveryNumber;

	@FindBy(xpath = "//div[text()='Open Delivery']")
	private WebElement openDeliveryButton;

	@FindBy(xpath = "//div[text()='Try searching using these suggestions:']")
	private WebElement appUIState;

	@FindBy(xpath = "//button[@aria-label='MoreVert']")
	private WebElement manualReceivingButton;

	@FindBy(xpath = "//div[text()='Manual Receive']")
	private WebElement manualReceivingOption;

	@FindBy(xpath = "//button[text()='CONTINUE']")
	private WebElement manualReceivingContinueButton;

	@FindBy(xpath = "//input[@placeholder='Search delivery']/../../../div[1]/*[name()='svg']")
	private WebElement backArrow;

	@FindBy(xpath = "//div[@role='document']//div[text()='Location']/..//input[@type='text']")
	private WebElement enterDoorNumber;

	@FindBy(xpath = "//div[text()='Confirm the type of pallet that is being used for proper weight calculation.']")
	private WebElement selectPalletTypeScreen;

	@FindBy(xpath = "//div[text()='Next']")
	private WebElement clickNextButtonOnPalletTypeScreen;

	@FindBy(xpath = "//div[text()='Select Delivery Document Line']")
	private WebElement selectMultiLine;

	@FindBy(xpath = "//span[text()='Cancel']")
	private WebElement cancelReject;
	// span[text()='Cancel']

	@FindAll({ @FindBy(xpath = "//fieldset/div/label") })
	private List<WebElement> listOfMultiLine;
//	@FindBy(xpath = "//fieldset/div/label")
//	private WebElementFacade listOfMultiLine;

	@FindBy(xpath = "//span[text()='Continue']")
	private WebElement multiLineContinueButton;

//	@FindBy(xpath = "//span[text()='Add Rejection']")
//	private WebElement addReject;

	@FindBy(xpath = "//span[text()='Update Rejection']")
	private WebElement updateRejection;
	// span[text()='Update Rejection']

	//	@FindBy(xpath = "//span[text()='PO LINE 1']")
//	private WebElement selectLineToBeRejected;
	@FindBy(xpath = "//h1[text()='Select PO Line']/../..//div[contains(text(),'ITEM')]")
	private WebElement selectLineToBeRejected;

	@FindBy(xpath = "//span[text()='Next']")
	private WebElement nextButtonForReject;

//	@FindBy(xpath = "//input[@id='rejectInput']")
//	private WebElement enterRejectedQTy;

	@FindBy(xpath = "//input[@id='new-quantity-input']")
	private WebElement enterRejectedQty;

	//	@FindBy(xpath = "//*[@id=\"root\"]/div/div/ul/div/div/div[1]/div[1]/div[1]/div[2]/div[4]/div[2]")
//	private WebElement rejectedQtyAtLineLevel;
	@FindBy(xpath = "//div[text()='R']//following-sibling::div")
	private WebElement rejectedQtyAtLineLevel;

	// Then CLick on Next button as above

	@FindBy(xpath = "//span[text()='R10 - Supplier Claim']")
	private WebElement selectRejectionReason;

	// Then CLick on Next button as above

	@FindBy(xpath = "//textarea")
	private WebElement enterRejectionReasonComment;

	@FindBy(xpath = "//span[text()='Save']")
	private WebElement saveRejection;

	// Cancel Pallet

	@FindBy(xpath = "//div[text()='Cancel Labels']")
	private WebElement selectCancelPallet;

	@FindBy(xpath = "//span[text()='Cancel Labels']")
	private WebElement clickCancelPalletButton;

	// Pallet COrrection

	@FindBy(xpath = "//div[text()='Pallet Corrections']")
	private WebElement selectPalletCorrection;

	@FindBy(xpath = "//h1[text()='Scan the LPN to Correct']")
	private WebElement scanPalletPage;

	@FindBy(xpath = "//input[@id='new-lpn-quantity']")
	private WebElement enterUpdatedQty;

	@FindBy(xpath = "//div[text()='Quantity exceeds Ti x Hi']")
	private WebElement qtyExceedServVal;

	// div[3]/div[3]/div/div[3]/button/span[1]

	@FindBy(xpath = "//div[3]/div[3]/div/div[3]/button/span[1]")
	private WebElement qtyExceedServValPopUp;

	@FindBy(xpath = "//input[@id='new-lpn-quantity']")
	private WebElement enterGreaterThanQty;
	// input[@aria-invalid='Please enter new quantity']

	@FindBy(xpath = "//input[@aria-invalid='Please enter new quantity']")
	private WebElement enterEqualQty;

	@FindBy(xpath = "//span[text()='Next']")
	private WebElement nextButtonCorrection;

	@FindBy(xpath = "//span[text()='Update']")
	private WebElement nextQtyUpdateButtonCorrection;

	@FindBy(xpath = "//div[text()='LPN will be canceled']")
	private WebElement zeroCorrectedQty;

	@FindBy(xpath = "//span[text()='PO already confirmed, cannot cancel label’]")
	private WebElement negativeVTRPostPoConfirm;

	@FindBy(xpath = "//div[text()='poNotConfirmed']")
	private WebElement negativePoConfirm;

	@FindBy(xpath = "//span[text()='OK']")
	private WebElement buttonOK;
	
	@FindBy(xpath = "//h2/div[contains(text(),'Overage alert')]")
	private WebElement overageAlert;
	
	@FindBy(xpath = "//div[contains(text(),'Approve overage')]")
	private WebElement overageAlertPopUpValidation;
	
	
	@FindBy(xpath = "//*[@id='manager-override']/div[3]/div[1]/div[2]/div/div[4]/div[1]/span[2]")
	private WebElement receivedValPostOverride;
	
	//*[@id="manager-override"]/div[3]/div[1]/div[2]/div/div[4]/div[1]/span[2]
	
	
	@FindBy(xpath = "//button/span[contains(text(),'Receive')]")
	private WebElement overageReceiveButton;

	@FindBy(xpath = "//*[text()='SSTK']")
	private WebElement sstkTextOnTop;

	@FindBy(xpath = "//*[text()='DA CON']")
	private WebElement daConTextOnTop;

	@FindBy(xpath = "//*[text()='FLOOR LINE PALLET']//div[text()='DA Conveyable']")
	private WebElement daConveyableFloorLinePalletTextOnTop;

	@FindBy(xpath = "//*[text()='PO CON']")
	private WebElement poConTextOnTop;

	@FindBy(xpath = "//*[text()='DA NONCON']")
	private WebElement daNonConTextOnTop;

	@FindBy(xpath = "//*[text()='Add to floor line pallet']")
	private WebElement addToFloorLinePallet;

	@FindBy(xpath = "//h2[text()='Freight is not Conveyable']")
	private WebElement FreightNotConveyableDialogHeading;

	@FindBy(xpath = "//p[contains(text(),'Would you like to start receiving')]")
	private WebElement FreightNotConveyableMessage;

	@FindBy(xpath = "//span[text()='YES']")
	private WebElement FreightNotConveyableAcceptButton;

	@FindBy(xpath = "//input[@placeholder='Search for a PO or DC']")
	private WebElement searchPO;

	@FindBy(xpath = "//span[text()='YES, CONTINUE']")
	private WebElement clickOnYesOnCombinePOs;

	@FindBy(xpath = "//div[text()='NEXT DSDC PALLET']")
	private WebElement nextDSDCpallet;

	String doorAndTrailerValidationPageXpathValue = "//p[contains(text(),'Before you begin, please verify the trailer number')]";
	String wrongDoorScanXpathValue = "	";
	String doorAssocWithMultiDiliveryXpathValue = "//div[contains(text(),'Unable to retrieve information for this delivery')]";
	String doorIsOfflineValidationXpathValue = "//p[contains(text(),'This door is not mapped to an ACL and no labels will be pre-generated')]";

	// String noAllocationXpathValue="//p[@id=\"alert-dialog-description\" and
	// contains(text(),\"Looks like the request couldn't be completed right now.
	// This could be caused by poor connectivity or system issues.\")]";
	String noAllocationXpathValue = "//div[text()='No Allocations']";
	String noItemFoundXpathValue = "//p[@id=\"alert-dialog-description\" and contains(text(),\"The scanned item wasn't found on this delivery. Make sure you scanned the correct label or try searching for the item.\")]";
	String newPalletPageXpathValue = "//div[text()='Start a new pallet']";
	String newPalletPageXpathValueWitron = "//div[text()='Start a new Pallet']";

	String poPoLinesAllDetail = "//ul"; // PO 04115566221  Received103  FB QtyO0S102D0R0PF0PO Line 190%GROUND BEEF
	// PATTY1 Received3 FB QtyO0S2D0R0PF0PO Line 2PIZZA SAUCE0 Received100 FB
	// QtyO0S100D0R0PF0Add RejectionConfirm PO

	//	@FindBy(xpath = "//ul//input[@type='checkbox']/parent::span")
	@FindBy(xpath = "//div//input[@type='checkbox']/parent::span")

	private WebElement selectAllPOButton;

	@FindBy(xpath = "//p")
	private WebElement expandPO;

	@FindBy(xpath = "//span[text()='Confirm POs']")
	private WebElement conFirmPOButton;

	@FindBy(xpath = "//span[text()='Review and Confirm POs']")
	private WebElement reviewAndconFirmPOButton;

	@FindBy(xpath = "//button/span[contains(text(),'Yes, confirm')]")
	private WebElement poFinalConfirm;

//	@FindBy(xpath = "//*[@id=\"root\"]/div/div/ul/div/div/div[2]/div[2]")
//	private WebElement poConfirmVerification;

	@FindBy(xpath = "//p[text()='PO']/../../../../../following-sibling::div//div[2]")
	private WebElement poConfirmVerification;
	// button/span[contains(text(),'Record Temperature')]

	@FindBy(xpath = "//button/span[contains(text(),'Record Temperature')]")
	private WebElement recordTemPopUp;

	@FindBy(xpath = "//input[@id='Zone 1']")
	private WebElement recordZoneOne;

	@FindBy(xpath = "//input[@id='Zone 2']")
	private WebElement recordZoneTwo;

	@FindBy(xpath = "//input[@id='Zone 3']")
	private WebElement recordZoneThree;

	@FindBy(xpath = "//ul/li//div[2]/div[1]/button/span")
	private WebElement recordZoneOneButton;

	@FindBy(xpath = "//ul/li//div[2]/div[2]/button/span")
	private WebElement recordZoneTwoButton;

	@FindBy(xpath = "//ul/li//div[2]/div[3]/button/span")
	private WebElement recordZoneThreeButton;

	@FindBy(xpath = "//button/span[text()='SAVE']")
	private WebElement recordZoneSave;

	// button/span[text()='SAVE']

	@FindBy(css = "svg[role='presentation']>path")
	private WebElement poConfirmCloseNew;

	@FindBy(css = "svg[role='presentation']")
	private WebElement poConfirmClose;

	@FindBy(xpath = "//div[text()='YES']")
	private WebElement popupAcceptButton;

	String errorPopupMsg = "//div[text()='Are the cases labeled correctly?']";
	String limitedQtyAttentionMsg = "//div[text()='Product identified as Limited Qty']";
	String lithiumIonAttentionMsg = "//div[text()='Product contains lithium batteries']";
	String multipleDeliveryDocumnentLines = "//div[div[div[text()='Select Delivery Document Line']]]";
	String itemOnMultiplePO = "//div[div[div[text()='Select PO']]]//span[text()='Continue']";
	String finishPalletXpathValue = "//div[@role='document']/div[3]/div[3]//span[text()='Finish Pallet']";
	String labelPrintingError = "//div[text()='Label printing error']";
	String placeOnConveyor = "//div[text()='Place on conveyor']";
	String placeOnConveyorText = "//div[text()='Place this item on the conveyor']";



	@FindBy(xpath = "//div[text()='Place on conveyor']/parent::div/*[name()='svg']/*[name()='path']")
	private WebElement PlaceOnConveyorCloseButton;

	// Report OVG Problem

	@FindBy(xpath = "//span[text()='REPORT PROBLEM']")
	private WebElement reportProblem;

	@FindBy(xpath = "//span[text()='Next']")
	private WebElement nextButton;

	@FindBy(xpath = "//label[text()='TI']/..//input")
	private WebElement tiField;

	@FindBy(xpath = "//label[text()='HI']/..//input")
	private WebElement hiField;

	@FindBy(xpath = "//label[text()='Qty']/..//input")
	private WebElement qtyField;

	@FindBy(xpath = "//div[text()='PRINT']")
	private WebElement printOption;

	@FindBy(xpath = "(//div[text()='Problem Receiving'])[2]")
	private WebElement problemReceivingTab;

	@FindBy(xpath = "//div[text()='Scan a problem label to begin receiving']")
	private WebElement scanProblemPannel;

	String overagePopup = "//div[text()='Overage']";

	@FindBy(xpath = "//div[text()='Start a new pallet']/parent::div/*[name()='svg']/*[name()='path']")
	private WebElement pageCloseButton;

	/// Pallet hold
	@FindBy(xpath = "//button/span")
	private WebElement doorScanPageMenuButton;

	@FindBy(xpath = "//div[text()='Pallet Hold']")
	private WebElement palletHoldButton;

	@FindBy(xpath = "//span[text()='Pallet Hold']")
	private WebElement palletHoldPageDisplayed;

	@FindBy(xpath = "//p[text()='Scan To Add Or Remove']")
	private WebElement palletScannedForHoldDisplayed;

	@FindBy(xpath = "//span[text()='Put Pallets On Hold']")
	private WebElement palletOnHoldButton;

	@FindBy(xpath = "//div[text()='1 pallets put on hold']")
	private WebElement palletHoldMessageDisplayed;

	// Temp Ti-Hi Witron

	@FindBy(xpath = "//span[text()='Update Item Attributes']")
	private WebElement updateItemAttribute;

	@FindBy(css = "svg[id='editTiHi']")
	private WebElement editItemTiHiButton;

	@FindBy(css = "input[id='tiValue']")
	private WebElement inputTiVal;

	@FindBy(css = "input[id='hiValue']")
	private WebElement inputHiVal;

	@FindBy(xpath = "//span[text()='Save']")
	private WebElement saveButton;

	@FindBy(xpath = "//button")
	private WebElement backButton;

	// button

	@FindBy(xpath = "//div[text()='TI x HI']/parent::div/label")
	private WebElement updatedTiHiVal;

	@FindBy(xpath = "//div[contains(text(),'Receive DSDC POs')]")
	private WebElement DSDCOption;

	@FindBy(xpath = "//div[contains(text(),'Print DSDC label')]//parent::div/*[name()='svg']")
	private WebElement closeButtonDSDCScreen;

	@FindBy(xpath = "//div[@id='selectDsdcPo']/div/span/span[1]")
	private WebElement PoCheckbox;

	@FindBy(xpath = "//div[text()='Next']")
	private WebElement DsdcPoconNextButton;

	@FindBy(xpath = "//input[@placeholder='Case qty']")
	private WebElement enterQtyToReceivePage;

	@FindBy(xpath = "//div[contains(text(),'Print Label')]")
	private WebElement printLabelButton;

	@FindBy(xpath = "//div[contains(text(),'DSDC pallet complete')]//parent::div/*[name()='svg']")
	private WebElement closeDSDCPalletCompletePage;
	// label

	@FindBy(xpath = "//*[@id=\"alert-dialog-title\"]/h2/div")
	private WebElement croRejectedNotOnBolLine;
	// button/span[text()='OK']

	@FindBy(xpath = "//button/span[text()='OK']")
	private WebElement croRejectedNotOnBolLineOK;

	@FindBy(xpath = "//button/span[text()='GOT IT']")
	private WebElement croRejectedLineOK;

	@FindBy(css = "svg[role='presentation']>path")
	private WebElement backFromRejectNotOnBOL;

	@FindBy(xpath = "//span[text()='Cancel Pallet']")
	private WebElement cancelPalletLink;

	@FindBy(xpath = "//button[2]/span[text()='Cancel Pallet']")
	private WebElement cancelPalletPopUpOK;

	@FindBy(xpath = "//div[text()='No items being worked']")
	private WebElement cancelPalletRemoved;
	////

	@FindBy(xpath = "//span[text()='Reject']")
	private WebElement closeDateReject;

//	@FindBy(xpath = "//html/body/div[2]/div[3]/div/div[2]/div/div[1]/div/div[4]/div[4]/div[2]")
//	private WebElement validateInitialRejectQty;

	@FindBy(xpath = "//div[text()='R']//following-sibling::div")
	private WebElement validateInitialRejectQty;

	@FindBy(xpath = "//input[@id='quantity-input']")
	private WebElement getDefaultRejectQty;

	// PBYL Print DockTag
	@FindBy(id = "pickByLineDockTagCreation-menu")
	private WebElement printPBYLDockTagOption;

	@FindBy(id = "print-another-pbyl-docktag-button")
	private WebElement printAnotherPBYLDockTagButton;

	@FindBy(id = "//div[text()='Print PBYL Dock Tag']//parent::div/*[name()='svg']")
	private WebElement closeIconPrintPBYLDockTag;

	@FindBy(xpath = "//button[@aria-label='ArrowBack']//*[name()='svg']")
	private WebElement backArrowScanUPCScreen;

	@FindBy(xpath = "//span[text()='Receive PBYL Dock Tag']")
	private WebElement receivePBYLDockTagBtton;

	@FindBy(xpath = "//*[contains(@placeholder,'Qty')]")
	private WebElement qtyToReceiveTextboxPBYL;

	@FindBy(xpath = "//div[contains(text(),'Scan the next item')]")
	private WebElement scanNextUPCMessage;

	@FindBy(xpath = "//div[text()='Pallet complete']")
	private WebElement palletCompleteTopLabel;

	@FindBy(xpath = "//div[contains(text(),'Receive POCON POs')]")
	private WebElement POCONOption;

	@FindBy(xpath = "//div[contains(text(),'PO Consolidation')]")
	private WebElement checkForPoconScreen;

	@FindBy(id = "selectPO")
	private WebElement poconCheckbox;

	@FindBy(xpath = "//div[contains(text(),'Pallet complete')]//parent::div/*[name()='svg']")
	private WebElement closeBtnPOCONPalletCompletePage;

	// input[@id='quantity-input’]

	public void checkDoorScanPage() {
		WebDriver driver = getDriverInstance();
		if (Config.isCloud) {
			logger.info("atlas_receivingapp_webui_url " + endpoint.getProperty("atlas_receivingapp_webui_url"));
			driver.get(endpoint.getProperty("atlas_receivingapp_webui_url"));
			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			element(scanDoorPannel).waitUntilVisible();
			if (ENVIRONMENT.PROD != Config.ENV) {
				/*
				 * Commented out below lines as by default it is Atlas and if we click on Atlas,
				 * Printer popup is coming while receiving
				 */
				/*
				 * element(selectProgramMenu).click();
				 * element(selectProgramIcon).waitUntilVisible();
				 * element(selectProgramIcon).click();
				 */

			}
		} else {
			logger.info("Launching the web URL for receiving " + endpoint.getProperty("receivingapp_webui_url"));
			driver.get(endpoint.getProperty("receivingapp_webui_url"));
			element(scanDoorPannel).waitUntilVisible();
		}

	}

	public void openReceivingApp() {
		WebDriver driver = getDriverInstance();
		logger.info("Launching the web URL for receiving " + endpoint.getProperty("receivingapp_webui_url"));
		driver.get(endpoint.getProperty("receivingapp_webui_url"));
	}

	public void clickOnReceiveMenu() {
		element(receivingMenu).waitUntilVisible();
		element(receivingMenu).waitUntilClickable();
		element(receivingMenu).click();
	}

	public void clickOnAcceptButton() {
		element(popupAcceptButton).waitUntilVisible();
		element(popupAcceptButton).waitUntilClickable();
		element(popupAcceptButton).click();
	}


	public void markPalletOnHold(String cntr) {

		WebDriver driver = getDriverInstance();
		sleep(1);
		element(palletHoldButton).waitUntilVisible();
		element(palletHoldButton).waitUntilClickable();
		element(palletHoldButton).click();
		element(palletHoldPageDisplayed).waitUntilVisible();
		sleep(1);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + cntr
				+ "'}; document.dispatchEvent(door)");

		element(palletOnHoldButton).waitUntilVisible();
		element(palletOnHoldButton).waitUntilClickable();
		element(palletOnHoldButton).click();
		element(palletHoldMessageDisplayed).waitUntilVisible();

	}

	public void markPalletCancel(String cntr, String val) {

		WebDriver driver = getDriverInstance();
		sleep(1);
		element(selectCancelPallet).waitUntilVisible();
		element(selectCancelPallet).waitUntilClickable();
		element(selectCancelPallet).click();
		element(clickCancelPalletButton).waitUntilVisible();
		sleep(1);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + cntr
				+ "'}; document.dispatchEvent(door)");

		element(clickCancelPalletButton).waitUntilVisible();
		element(clickCancelPalletButton).waitUntilClickable();
		element(clickCancelPalletButton).click();
		sleep(3);
		if (val.contains("negativeVTRPostPOConfirm")) {
			element(negativeVTRPostPoConfirm).waitUntilClickable();
			String message = element(negativeVTRPostPoConfirm).getText();
			logger.info("failed message val {}", message);

			Assert.assertEquals(ErrorCodes.WITRON_VTR_NEGATIVE, message, "PO already confirmed, cannot cancel label");

		} else
			logger.info("Container cancelled {}", cntr);

	}

	public void doPalletCorrection(String cntr, int cntrQty, int tiHiProduct, String poLine, String val) {
		String b = Keys.BACK_SPACE.toString();

		WebDriver driver = getDriverInstance();
		sleep(1);
		element(selectPalletCorrection).waitUntilVisible();
		element(selectPalletCorrection).waitUntilClickable();
		element(selectPalletCorrection).click();
		element(scanPalletPage).waitUntilVisible();
		sleep(1);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + cntr
				+ "'}; document.dispatchEvent(door)");

		element(enterUpdatedQty).waitUntilVisible();
		element(enterUpdatedQty).waitUntilClickable();
		element(enterUpdatedQty).click();
		sleep(2);

		if (val.contains("negativePOConfirm")) {
			element(enterUpdatedQty).sendKeys(String.valueOf(cntrQty - 10));
			sleep(1);
			element(nextButtonCorrection).waitUntilVisible();
			element(nextButtonCorrection).click();
			element(nextQtyUpdateButtonCorrection).waitUntilEnabled();
			sleep(1);
			element(nextQtyUpdateButtonCorrection).click();
			sleep(1);
			element(negativePoConfirm).waitUntilVisible();
			element(negativePoConfirm).waitUntilClickable();

			String vale = element(negativePoConfirm).getText();
			logger.info("value {} ", vale);

			sleep(1);
			boolean flag = element(negativePoConfirm).containsText("poNotConfirmed [");
			logger.info("Pallet correct negative validation {} ", flag);
			Assert.assertEquals(ErrorCodes.WITRON_POCONFIRM_NEGATIVE_VALIDATION, flag, true);

			// element(buttonOK).click();

		} else if (val.contains("negativeVTRPostPOConfirm")) {
			markPalletCancel(cntr, val);
		} else {

			if (poLine.contentEquals("1") || poLine.contentEquals("4")) {
				int greaterThanQty = cntrQty + 1;

				element(enterUpdatedQty).sendKeys(String.valueOf(greaterThanQty));

				element(enterGreaterThanQty).waitUntilVisible();
				sleep(2);
				element(enterGreaterThanQty).click();

				element(enterGreaterThanQty).sendKeys(b + b + b + b + b + b + b + b + b + b + String.valueOf(cntrQty));

				element(enterEqualQty).waitUntilVisible();
				sleep(2);

				element(enterEqualQty).click();

				element(enterGreaterThanQty).sendKeys(b + b + b + b + b + b + b + b + b + b + String.valueOf("0"));

				element(zeroCorrectedQty).waitUntilVisible();
				sleep(2);
				element(nextButtonCorrection).waitUntilVisible();
				element(nextButtonCorrection).click();
				element(nextQtyUpdateButtonCorrection).waitUntilVisible();
				element(nextQtyUpdateButtonCorrection).click();
				sleep(3);

			} else if (poLine.contentEquals("2")) {

				int lessThanQty = cntrQty - 10;
				element(enterUpdatedQty).sendKeys(String.valueOf(lessThanQty));
				sleep(2);
				element(nextButtonCorrection).waitUntilVisible();
				element(nextButtonCorrection).click();
				element(nextQtyUpdateButtonCorrection).waitUntilVisible();
				element(nextQtyUpdateButtonCorrection).click();
				sleep(3);

			} else if (poLine.contentEquals("3")) {
// its temp correction
				List<WebElement> listSize = new ArrayList<WebElement>();

				WebDriver driverWeb = getDriverInstance();
				element(enterUpdatedQty).sendKeys(String.valueOf(tiHiProduct));
				sleep(2);
				element(nextButtonCorrection).waitUntilVisible();
				element(nextButtonCorrection).click();
				element(nextQtyUpdateButtonCorrection).waitUntilVisible();
				element(nextQtyUpdateButtonCorrection).click();
				sleep(1);
				listSize = driverWeb.findElements(By.xpath("//div[text()='Quantity exceeds Ti x Hi']"));
				logger.info("List Fail size {} ", listSize.size());
				Assert.assertEquals(ErrorCodes.WITRON_PALLET_CORRECTION_MORE_THAN_TI_HI, listSize.size(), 0);
				// element(qtyExceedServValPopUp).waitUntilVisible();
//     			sleep(1);
//     			element(qtyExceedServValPopUp).click();
//     			sleep(1);
//     			element(scanPalletPage).waitUntilVisible();
//     			js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + cntr
//     					+ "'}; document.dispatchEvent(door)");
//     			element(enterUpdatedQty).waitUntilVisible();
//
//     			element(enterUpdatedQty).sendKeys(String.valueOf(cntrQty+4));
//
//    			sleep(1);
//    			element(nextButtonCorrection).waitUntilVisible();
//    			element(nextButtonCorrection).click();
//    			element(nextQtyUpdateButtonCorrection).waitUntilVisible();
//    			element(nextQtyUpdateButtonCorrection).click();
//    			sleep(3);
			}
			// else {
//			element(enterUpdatedQty).sendKeys(String.valueOf(cntrQty+4))
//
//			sleep(2);
//			element(nextButtonCorrection).waitUntilVisible();
//			element(nextButtonCorrection).click();
//			element(nextQtyUpdateButtonCorrection).waitUntilVisible();
//			element(nextQtyUpdateButtonCorrection).click();
//			sleep(3);
//             //}

			logger.info("Container cancelled {}", cntr);
		}
	}

	public void clickOnReceiveProbCntr() {
		element(probRecvReceiveBtn).waitUntilVisible();
		element(probRecvReceiveBtn).waitUntilClickable();
		element(probRecvReceiveBtn).click();
	}
	
	public void clickOnReceiveCorrectionBtn() {
		logger.info("waiting for the visibility of RECEIVE button");
		element(receivingCorrection).waitUntilVisible();
		logger.info("waiting to click the RECEIVE button");
		element(receivingCorrection).waitUntilClickable();
		element(receivingCorrection).click();
		logger.info("clicked on recieve button");

	}

	public void clickOnProbrecvBtn() {
		element(probRecvBtn).waitUntilVisible();
		element(probRecvBtn).waitUntilClickable();
		element(probRecvBtn).click();
	}

	public void inputReceiveQty(String qty) {
		logger.info("problem container Qty:" + qty);
		element(probRecvInput).waitUntilVisible();
		element(probRecvInput).waitUntilClickable();
		element(probRecvInput).type(qty);
	}

	public void clickOnProbrecv() {
		element(probRecv).waitUntilVisible();
		element(probRecv).waitUntilClickable();
		element(probRecv).click();
	}

	public void inputPrinterName() {
		element(printerInput).waitUntilVisible();
		element(printerInput).waitUntilClickable();
		element(printerInput).type(PRINTER_NAME);
	}

	public void selectPrinter() {
		element(selectPrinter).waitUntilVisible();
		element(selectPrinter).waitUntilClickable();
		element(selectPrinter).click();
	}

	public void clickOnPrinterTab() {
		element(printerTab).waitUntilVisible();
		element(printerTab).waitUntilClickable();
		element(printerTab).click();

	}

	public void clickOnNextpallet() {
		element(nextpallet).waitUntilVisible();
		element(nextpallet).waitUntilClickable();
		element(nextpallet).click();

	}

	public void clickOnFinishPallet() {
		element(finishPallet).waitUntilVisible();
		element(finishPallet).waitUntilClickable();
		element(finishPallet).click();

	}

	public void enterPrinter(String printerName) {
		element(searchPrinterTextbox).waitUntilVisible();
		element(searchPrinterTextbox).waitUntilEnabled();
		element(searchPrinterTextbox).type(printerName);

	}

	public void selectOnlinePrinter() {
		element(onlinePrinterList).waitUntilVisible();
		element(onlinePrinterList).waitUntilClickable();
		element(onlinePrinterList).click();
		logger.info("Receiving App :: Online printer selected");

	}

	public void clickOnProceedButton() {
		element(proceedButton).waitUntilVisible();
		element(proceedButton).waitUntilClickable();
		element(proceedButton).click();

	}

	public void clickOnInboundReceiveTab() {
		element(inboundReceivingTab).waitUntilVisible();
		element(inboundReceivingTab).waitUntilClickable();
		element(inboundReceivingTab).click();
	}

	public void scanDoor(String door) {
		WebDriver driver = getDriverInstance();
		element(scanDoorPannel).waitUntilVisible();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + door
				+ "'}; document.dispatchEvent(door)");
	}

	public void scanProblemLabel(String label) {
		WebDriver driver = getDriverInstance();
		element(probRecvScanScreen).waitUntilVisible();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + label
				+ "'}; document.dispatchEvent(door)");
	}

	public void proceedWithDelivery() {
		element(proceedWithDeivery).waitUntilVisible();
		element(proceedWithDeivery).click();
		;

	}

	public boolean isWrongDoorScanErrorDisplayed() {
		return isElementVisible(wrongDoorScanXpathValue);
	}

	public boolean isdoorAssociatedWithMultiDilivery() {
		return isElementVisible(doorAssocWithMultiDiliveryXpathValue);
	}

	public boolean isDoorAndTrailerValidationPageDisplayed() {
		return isElementVisible(doorAndTrailerValidationPageXpathValue);
	}

	public boolean isDoorIsOffline() {
		return isElementVisible(doorIsOfflineValidationXpathValue);
	}

	public String getTrailerNumber() {
		element(trailerNumTextMssg).waitUntilVisible();
		element(trailerNumTextMssg).waitUntilEnabled();
		String trailerNum = element(trailerNumTextMssg).getText().replaceAll("Trailer #", "");
		System.out.println("trailerNum : " + trailerNum);
		return trailerNum;
	}

	public void trailerDetails_clickOncontinueButton() {
		element(trailerDetails_ContinueButton).waitUntilVisible();
		element(trailerDetails_ContinueButton).waitUntilClickable();
		element(trailerDetails_ContinueButton).click();

	}

	public String getDeliveryNumber() {
		element(deliveryNumTextMssg).waitUntilVisible();
		element(deliveryNumTextMssg).waitUntilEnabled();
		String deliveryNum = element(deliveryNumTextMssg).getText().replaceAll("Delivery #", "");
		System.out.println("Delivery # : " + deliveryNum);
		return deliveryNum;
	}

	public void selectPOfromRadioButton(String poNumber) {
		WebDriver driver = getDriverInstance();
		element(itemOnMultiplePO_ContinueButton).waitUntilVisible();
		element(itemOnMultiplePO_ContinueButton).waitUntilClickable();
		driver.findElement(By
				.xpath("//div[div[div[text()='Select PO']]]//div[@role='radiogroup']//span[text()='" + poNumber + "']"))
				.click();
	}

	public void clickOn_itemOnMutiplePO_ContinueButton() {
		element(itemOnMultiplePO_ContinueButton).waitUntilVisible();
		element(itemOnMultiplePO_ContinueButton).waitUntilClickable();
		element(itemOnMultiplePO_ContinueButton).click();
	}

	public boolean isNoAllocationErrorMssgDisplayed() {
		return isElementVisible(noAllocationXpathValue);
	}

	public void clickOn_ConfirmationOkButton() {
		element(confirmation_OK_Button).waitUntilVisible();
		element(confirmation_OK_Button).waitUntilClickable();
		element(confirmation_OK_Button).click();
	}



	public boolean isNoItemFoundErrorMssgDisplayed() {
		return isElementVisible(noItemFoundXpathValue);
	}

	public boolean isErrorMsgDisplayed() {
		return isElementVisible(errorPopupMsg);

	}
	public boolean isLimitedQtyAttentionMsgDisplayed() {
		return isElementVisible(limitedQtyAttentionMsg);

	}

	public boolean isLithiumIonAttentionMsgDisplayed() {
		return isElementVisible(lithiumIonAttentionMsg);

	}


	public void clickOn_ConfirmationDismissButton() {
		element(confirmation_dismiss_Buttom).waitUntilVisible();
		element(confirmation_dismiss_Buttom).waitUntilClickable();
		element(confirmation_dismiss_Buttom).click();
	}

	public void clickOn_ConfirmationYesButton() {
		element(confirmationYesButton).waitUntilVisible();
		element(confirmationYesButton).waitUntilClickable();
		element(confirmationYesButton).click();
	}

	public boolean iscontainerReceive_NewPalletPageDisplayed() {
		if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS) {
			return isElementVisible(newPalletPageXpathValueWitron);
		} else {
			return isElementVisible(newPalletPageXpathValue);
		}
	}

	public void updateTiHiValues(String tiHi) {

		String[] tiHiVal = tiHi.split("x");

		logger.info(" ti = {} and Hi = {} ", tiHiVal[0].replace("\"", ""), tiHiVal[1].replace("\"", ""));
		element(updateItemAttribute).waitUntilVisible();

		element(updateItemAttribute).waitUntilClickable();

		element(updateItemAttribute).click();

		sleep(1);

		element(editItemTiHiButton).waitUntilVisible();

		element(editItemTiHiButton).waitUntilClickable();

		element(editItemTiHiButton).click();

		sleep(1);

		element(inputTiVal).waitUntilVisible();

		element(inputTiVal).waitUntilClickable();

		element(inputTiVal).click();

		sleep(1);

		String b = Keys.BACK_SPACE.toString();

		element(inputTiVal).sendKeys(b + b + b + b + b + b + b + b + b + b + tiHiVal[0].trim());

		element(inputHiVal).waitUntilVisible();

		element(inputHiVal).waitUntilClickable();
		element(inputHiVal).click();

		String b1 = Keys.BACK_SPACE.toString();

		element(inputHiVal).sendKeys(b1 + b1 + b1 + b1 + b1 + b1 + b1 + b1 + b1 + b1 + tiHiVal[1].trim());

		sleep(1);

		element(saveButton).waitUntilVisible();

		element(saveButton).waitUntilClickable();

		element(saveButton).click();
		sleep(1);
		element(backButton).waitUntilVisible();
		element(backButton).waitUntilClickable();
		element(backButton).click();

	}

	public void scanUPC(String UPC) {
		WebDriver driver = getDriverInstance();
		element(completeDeliveryButton).waitUntilEnabled();
		element(completeDeliveryButton).waitUntilClickable();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		logger.info("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + UPC
				+ "'}; document.dispatchEvent(door)");
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + UPC
				+ "'}; document.dispatchEvent(door)");
		logger.info("Receiving App :: UPC scan completed");

	}

	public void scanUPCPBYLReceiving(String UPC) {
		WebDriver driver = getDriverInstance();
		sleep(5);
		element(completeDockTagButton).waitUntilEnabled();
		element(completeDockTagButton).waitUntilClickable();
		sleep(1);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		logger.info("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + UPC
				+ "'}; document.dispatchEvent(door)");
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + UPC
				+ "'}; document.dispatchEvent(door)");
		logger.info("Receiving App :: UPC scan for PBYL Docktag Receiving completed");

	}

	public void scanUPCWitron(String UPC) {
		WebDriver driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		logger.info("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + UPC
				+ "'}; document.dispatchEvent(door)");
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + UPC
				+ "'}; document.dispatchEvent(door)");
		logger.info("Receiving App :: UPC scan completed");

	}

	public void validateSelectPalletTypeScreen() {
		logger.info("validating Select Pallet Type Screen");
		element(selectPalletTypeScreen).waitUntilVisible();
		element(clickNextButtonOnPalletTypeScreen).click();
	}

	public boolean multiLinevailableOrNot() {
		setImplicitTimeout(2, ChronoUnit.SECONDS);
		boolean flag;
		try {
			sleep(3);
			if (element(selectMultiLine).withTimeoutOf(2, TimeUnit.SECONDS).isDisplayed())
				flag = true;
			else
				flag = false;

		} catch (Exception e) {
			flag = false;
			logger.info("multiLinevailableOrNot flag is set in catch block");
		}
		return flag;
	}

	public void validateAndSelectMultiLine(String lineNumber, String croAction) {

		logger.info("Total number of line :{}", listOfMultiLine.size());
		for (WebElement line : listOfMultiLine) {
			String lineText = line.getText().toString();
			logger.info(" text {} ", lineText);

			String lineTextVal = lineText.substring(lineText.length() - 2, lineText.length());
			logger.info(" number of line :{} and actual : {} ", lineTextVal.trim(), lineNumber.trim());

			if (lineNumber.contentEquals(lineTextVal.trim())) {

				sleep(2);
				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				element(line).waitUntilVisible();
				logger.info("waited for visibility of line");
				js.executeScript("arguments[0].click();",line);
				logger.info("clicked line");
				//	line.click();
				sleep(2);
				element(multiLineContinueButton).waitUntilVisible();
				logger.info("waited for visibility of multiLineContinueButton");
				element(multiLineContinueButton).click();
				logger.info("clicked on multiLineContinueButton");
				sleep(2);
				break;
			}

		}

		if (croAction.contains("croReject")) {

			element(croRejectedNotOnBolLine).waitUntilVisible();
			logger.info("waited for visibility of croRejectedNotOnBolLine");
			element(croRejectedLineOK).click();
			logger.info("clicked croRejectedLineOK");
		}
	}

	public void clickReviewAndPOConfirmButton() {
		element(reviewAndconFirmPOButton).waitUntilVisible();
		element(reviewAndconFirmPOButton).click();
		element(selectAllPOButton).waitUntilVisible();
		sleep(1);
//		return element(poPoLinesAllDetail).getText().toString();

	}

	public void validateVtredQty(String poLine, String qty) {
		WebDriver driver = getDriverInstance();

		element(reviewAndconFirmPOButton).waitUntilVisible();
		element(reviewAndconFirmPOButton).click();
		element(selectAllPOButton).waitUntilVisible();
		sleep(1);
		element(expandPO).waitUntilVisible();
		element(expandPO).click();

		element(driver.findElement(By.xpath("//div[@role='region']/div[1]/div["+poLine+"]/div[4]/div[1]/div[1]"))).waitUntilVisible();
		sleep(1);
		String rcvQty = element(
				driver.findElement(By.xpath("//div[@role='region']/div[1]/div["+poLine+"]/div[4]/div[1]/div[1]"))).getText();
//		element(driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/ul/div/div/div[1]/div[2]/div/div/div/div/div["
//				+ poLine + "]/div[3]/div[1]/div[1]"))).waitUntilVisible();
//		sleep(1);
//		String rcvQty = element(
//				driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/ul/div/div/div[1]/div[2]/div/div/div/div/div["
//						+ poLine + "]/div[3]/div[1]/div[1]"))).getText();

		Assert.assertEquals(ErrorCodes.WITRON_VTR_QTY_MATCHES, qty, rcvQty);
		logger.info(" vtr qty = {} and Actual QTY = {} ", qty, rcvQty);

	}

	public void rejectQty(String qty, String poLine) {
		WebDriver driver = getDriverInstance();

		element(updateRejection).waitUntilVisible();
		element(updateRejection).waitUntilClickable();
		element(updateRejection).click();
		element(selectLineToBeRejected).waitUntilVisible();

		List<WebElement> poLines = driver.findElements(By.xpath("//h1[text()='Select PO Line']/../..//div[contains(text(),'ITEM')]"));
		int index = Integer.parseInt(poLine);
		element(poLines.get(index-1)).waitUntilVisible();
		element(poLines.get(index-1)).waitUntilClickable();
		sleep(1);

		element(poLines.get(index-1)).click();
		sleep(1);

//		logger.info("xpath {} ", "//span[text()='PO LINE " + poLine + "']");
//		element(driver.findElement(By.xpath("//span[text()='PO LINE " + poLine + "']"))).waitUntilVisible();
//		element(driver.findElement(By.xpath("//span[text()='PO LINE " + poLine + "']"))).waitUntilClickable();
//		sleep(1);
//
//		element(driver.findElement(By.xpath("//span[text()='PO LINE " + poLine + "']"))).click();
//		sleep(1);

//		element(selectLineToBeRejected).waitUntilVisible();
//		element(selectLineToBeRejected).waitUntilClickable();
//		sleep(1);
//
//		element(selectLineToBeRejected).click();

		element(nextButtonForReject).waitUntilVisible();
		element(nextButtonForReject).waitUntilClickable();
		element(nextButtonForReject).click();
		sleep(1);

		element(enterRejectedQty).waitUntilVisible();
		sleep(1);
		element(enterRejectedQty).click();
		sleep(1);
		element(enterRejectedQty).sendKeys(qty);

//		element(nextButtonForReject).waitUntilVisible();
//		element(nextButtonForReject).waitUntilClickable();
//		element(nextButtonForReject).click();

		element(selectRejectionReason).waitUntilVisible();
		element(selectRejectionReason).waitUntilClickable();
		element(selectRejectionReason).click();

//		element(nextButtonForReject).waitUntilVisible();
//		element(nextButtonForReject).waitUntilClickable();
//		element(nextButtonForReject).click();

		element(enterRejectionReasonComment).waitUntilVisible();
		sleep(1);

		element(enterRejectionReasonComment).click();
		sleep(1);

		element(enterRejectionReasonComment).sendKeys("Rejecting the Qty ");

		element(saveRejection).waitUntilVisible();
		element(saveRejection).waitUntilClickable();
		element(saveRejection).click();
		sleep(1);
		element(updateRejection).waitUntilVisible();
		sleep(1);

	}

	public void rejectQtyExceptionFlow(String qty, String poLine) {
		WebDriver driver = getDriverInstance();
		String finalQty = "20";
		for (int i = 0; i < 3; i++) {
			element(updateRejection).waitUntilVisible();
			element(updateRejection).waitUntilClickable();
			element(updateRejection).click();

			// element(selectLineToBeRejected).waitUntilVisible();

//			logger.info("xpath {} ", "//span[text()='PO LINE " + poLine + "']");
//			element(driver.findElement(By.xpath("//span[text()='PO LINE " + poLine + "']"))).waitUntilVisible();
//			element(driver.findElement(By.xpath("//span[text()='PO LINE " + poLine + "']"))).waitUntilClickable();
//			sleep(1);
//
//			element(driver.findElement(By.xpath("//span[text()='PO LINE " + poLine + "']"))).click();
//			sleep(1);
//
//			element(nextButtonForReject).waitUntilVisible();
//			element(nextButtonForReject).waitUntilClickable();
//			element(nextButtonForReject).click();
//			sleep(1);

			if (i == 0) {
				element(enterRejectedQty).waitUntilVisible();
				sleep(1);
				element(enterRejectedQty).click();
				sleep(1);
				element(enterRejectedQty).sendKeys(qty);
			} else if (i == 1) {
				element(enterRejectedQty).waitUntilVisible();
				sleep(1);
				element(enterRejectedQty).click();
				sleep(1);
				element(enterRejectedQty).sendKeys(finalQty);
			} else {
				element(enterRejectedQty).waitUntilVisible();
				sleep(1);
				element(enterRejectedQty).click();
				sleep(1);
				element(enterRejectedQty).sendKeys("0");
			}

			element(selectRejectionReason).waitUntilVisible();
			element(selectRejectionReason).waitUntilClickable();
			element(selectRejectionReason).click();

			element(enterRejectionReasonComment).waitUntilVisible();
			sleep(1);

			element(enterRejectionReasonComment).click();
			sleep(1);

			element(enterRejectionReasonComment).sendKeys("Rejecting the Qty ");

			element(saveRejection).waitUntilVisible();
			element(saveRejection).waitUntilClickable();
			element(saveRejection).click();
			sleep(1);
			element(updateRejection).waitUntilVisible();
			sleep(3);
			if (i == 0) {
				int initVal = Integer.parseInt(element(rejectedQtyAtLineLevel).getText());
				Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, initVal, Integer.parseInt(qty));
				logger.info("final qty = {} ", initVal);

			} else if (i == 1) {
				int initVal = Integer.parseInt(element(rejectedQtyAtLineLevel).getText());
				Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, initVal, Integer.parseInt(finalQty));
				logger.info("final qty = {} ", initVal);
			} else {
				int initVal = Integer.parseInt(element(rejectedQtyAtLineLevel).getText());
				Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, initVal, 0);
				logger.info("final qty = {} ", initVal);
			}
		}
	}

	public void recordTrailerTemp() {

		// element(selectAllPOButton).waitUntilVisible();
//		element(selectAllPOButton).waitUntilClickable();
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(conFirmPOButton).waitUntilClickable();
		element(conFirmPOButton).click();
		// String poLineDetail = element(poPoLinesAllDetail).getText().toString();

		sleep(1);

		element(poFinalConfirm).waitUntilVisible();
		element(poFinalConfirm).waitUntilClickable();

		element(poFinalConfirm).click();

		element(recordTemPopUp).waitUntilVisible();
		element(recordTemPopUp).waitUntilClickable();
		sleep(1);

		element(recordTemPopUp).click();

		element(recordZoneOne).waitUntilVisible();
		element(recordZoneOne).waitUntilClickable();
		sleep(1);

		element(recordZoneOne).click();

		element(recordZoneOne).sendKeys("-10");
		;

		sleep(1);
		element(recordZoneTwo).click();

		element(recordZoneTwo).sendKeys("0");
		;

		sleep(1);

		element(recordZoneThree).click();

		element(recordZoneThree).sendKeys("10");
		;

		sleep(1);

		element(recordZoneOneButton).waitUntilVisible();
		element(recordZoneOneButton).waitUntilClickable();
		sleep(1);

		element(recordZoneOneButton).click();
		sleep(1);
		element(recordZoneTwoButton).waitUntilVisible();
		element(recordZoneTwoButton).waitUntilClickable();

		element(recordZoneTwoButton).click();

		sleep(1);

		element(recordZoneThreeButton).waitUntilVisible();
		element(recordZoneThreeButton).waitUntilClickable();

		element(recordZoneThreeButton).click();
		sleep(1);

		element(recordZoneSave).waitUntilVisible();
		element(recordZoneSave).waitUntilClickable();

		element(recordZoneSave).click();
		sleep(2);
		element(poConfirmClose).waitUntilVisible();
		element(poConfirmClose).waitUntilClickable();
		element(poConfirmClose).click();
	}

	public boolean confirmPO() {

		boolean flag = false;
		element(selectAllPOButton).waitUntilVisible();
		sleep(2);
		element(updateRejection).waitUntilVisible();
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);
		element(selectAllPOButton).click();
		sleep(1);

		element(conFirmPOButton).waitUntilClickable();
		sleep(2);

		element(conFirmPOButton).click();
		// String poLineDetail = element(poPoLinesAllDetail).getText().toString();

		sleep(1);

		element(poFinalConfirm).waitUntilVisible();
		element(poFinalConfirm).waitUntilClickable();

		element(poFinalConfirm).click();

		element(poConfirmVerification).waitUntilVisible();

		String confirmText = element(poConfirmVerification).getText();
		sleep(1);
		logger.info("Confirm Text Value {}", confirmText);
		if (confirmText.contains("Confirmed")) {
			flag = true;
		}
		return flag;

	}

	public void closePoConfirm() {

		sleep(2);
		try {
			element(poConfirmClose).waitUntilVisible();
			element(poConfirmClose).waitUntilClickable();
			element(poConfirmClose).click();
			sleep(1);
		} catch (Exception e) {
			element(poConfirmCloseNew).click();

		}

	}


	public void closePlaceOnConveyerPage() {

		sleep(2);
		try {
			logger.info("clicking on PlaceOnConveyor CloseButton");
			element(PlaceOnConveyorCloseButton).waitUntilVisible();
			element(PlaceOnConveyorCloseButton).waitUntilClickable();
			element(PlaceOnConveyorCloseButton).click();
			sleep(1);
		} catch (Exception e) {
			logger.info("PlaceOnConveyorCloseButton not getting clicked");

		}

	}


	public String getQtyToReceive() {
		if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS) {
			element(qtyToReceiveTextWitron).waitUntilVisible();
			element(qtyToReceiveTextWitron).waitUntilEnabled();
			return element(qtyToReceiveTextWitron).getText();
		} else {
			element(qtyToReceiveText).waitUntilVisible();
			element(qtyToReceiveText).waitUntilEnabled();
			return element(qtyToReceiveText).getText();
		}
	}

	public void enterQtyToReceive(String receiveQty) {
		element(receiveQtyTextBox).waitUntilVisible();
		element(receiveQtyTextBox).waitUntilEnabled();
		element(receiveQtyTextBox).click();
		element(receiveQtyTextBox).type(receiveQty);

	}

	public boolean verifyUpdateTiHi(String tempTiHi) {
		element(updatedTiHiVal).waitUntilVisible();
		String updateTiHiVal = element(updatedTiHiVal).getText().toString();
		logger.info("Ti Hi From App = {} and Ti Hi as Input ={} ", updateTiHiVal.trim(), tempTiHi.trim());
		return updateTiHiVal.trim().contentEquals(tempTiHi.trim());

	}

	public void selectExpiryDateWitron(String date) {
		element(selectExpiryDate).waitUntilVisible();
		element(selectExpiryDate).waitUntilEnabled();
		String[] rotateDate = date.split("-");

		logger.info("Rotate date format : {}", rotateDate[1] + rotateDate[2] + rotateDate[0]);

		element(selectExpiryDate).sendKeys(rotateDate[1]);
		sleep(1);

		element(selectExpiryDate).sendKeys(rotateDate[2]);
		sleep(1);

		element(selectExpiryDate).sendKeys(rotateDate[0]);
		sleep(1);

		// remove this and enable above
//		logger.info("Rotate date format : {}", rotateDate[2] + rotateDate[1] + rotateDate[0]);
//
//		element(selectExpiryDate).sendKeys(rotateDate[2]);
//		sleep(1);
//
//		element(selectExpiryDate).sendKeys(rotateDate[1]);
//		sleep(1);
//
//		element(selectExpiryDate).sendKeys(rotateDate[0]);
//		sleep(1);

	}

	public void clickOnReceiveButton() {

		if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS) {
			element(receiveButtonWitron).waitUntilVisible();
			element(receiveButtonWitron).waitUntilEnabled();
			sleep(1);
			element(receiveButtonWitron).click();
			element(scanNextUPCWitron).waitUntilVisible();
			sleep(0);
		} else {
			element(receiveButton).waitUntilVisible();
			element(receiveButton).waitUntilClickable();
			element(receiveButton).click();

		}
	}
	
	public void handleCloseDate() {

		if (Config.DC == DC_TYPE.WITRON ) {
			element(receiveButtonWitron).waitUntilVisible();
			element(receiveButtonWitron).waitUntilEnabled();
			sleep(1);
			element(receiveButtonWitron).click();
			element(closeDatePopUp).waitUntilVisible();
			sleep(1);
			element(closeDateReceive).waitUntilClickable();
			element(closeDateReceive).click();
			element(closeDateOverride).waitUntilVisible();
			sleep(1);
			element(closeDateOverrideUserId).click();
			element(closeDateOverrideUserId).sendKeys("r0k008m");
			sleep(1);
			element(closeDateOverridePass).click();
			element(closeDateOverridePass).sendKeys("Walmart1");
			element(closeDateOverrideApprove).waitUntilClickable();
			element(closeDateOverrideApprove).click();
		}
	}
	
	
	public void handleOverageAlert(int overageQty) {

		if (Config.DC == DC_TYPE.WITRON ) {
	
			element(overageReceiveButton).waitUntilClickable();
			element(overageReceiveButton).click();
			element(overageAlertPopUpValidation).waitUntilVisible();
			sleep(1);
			int receivedVal=Integer.parseInt(element(receivedValPostOverride).getText());
			logger.info("Qty from Page  = {}", receivedVal);
			Assert.assertEquals(ErrorCodes.WITRON_OVG_QTY, overageQty, receivedVal);


			element(closeDateOverrideUserId).click();
			element(closeDateOverrideUserId).sendKeys("r0k008m");
			sleep(1);
			element(closeDateOverridePass).click();
			element(closeDateOverridePass).sendKeys("Walmart1");
			element(closeDateOverrideApprove).waitUntilClickable();
			element(closeDateOverrideApprove).click();
		}

	}

	public void rejectFromInstructionPage(String qty, int i) {
		String b = Keys.BACK_SPACE.toString();
		element(receiveButtonWitron).waitUntilVisible();
		element(receiveButtonWitron).waitUntilEnabled();
		sleep(1);
		element(receiveButtonWitron).click();
		sleep(1);
		element(closeDateReject).waitUntilVisible();
		element(closeDateReject).waitUntilClickable();
		sleep(1);
		element(closeDateReject).click();
		element(getDefaultRejectQty).waitUntilVisible();
		sleep(1);

		String defaultRejectQty = element(validateInitialRejectQty).getText();
		logger.info("Qty from Page and default qty = {}", defaultRejectQty);

		String qtyFromPage = element(getDefaultRejectQty).getValue();
		logger.info("Qty from Page and default qty = {} ", qtyFromPage);

		Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, Integer.parseInt(qty), Integer.parseInt(qtyFromPage));

		if (i == 0) {
			Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, Integer.parseInt(defaultRejectQty), 0);

		} else if (i == 1) {
			Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, Integer.parseInt(defaultRejectQty), 10);

		} else {
			Assert.assertEquals(ErrorCodes.WITRON_REJECT_QTY_MATCH, Integer.parseInt(defaultRejectQty), 20);

			element(cancelReject).waitUntilEnabled();
			sleep(1);
			element(cancelReject).click();
			clickOnCloseButtonWitron();
			cancelPalletCase();

		}

		if (i == 0 || i == 1) {
			element(getDefaultRejectQty).sendKeys(b + b + b + b + String.valueOf("10"));

			element(selectRejectionReason).waitUntilVisible();
			element(selectRejectionReason).waitUntilClickable();
			element(selectRejectionReason).click();

			element(enterRejectionReasonComment).waitUntilVisible();
			sleep(1);

			element(enterRejectionReasonComment).click();
			sleep(1);

			element(enterRejectionReasonComment).sendKeys("Rejecting the Qty ");

			element(saveRejection).waitUntilVisible();
			element(saveRejection).waitUntilClickable();
			element(saveRejection).click();
			sleep(1);
			element(cancelPalletRemoved).waitUntilVisible();
		}
	}

	public void clickOnReceiveButtonWitron(String croAction) {

		if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS) {
			element(receiveButtonWitron).waitUntilVisible();
			element(receiveButtonWitron).waitUntilEnabled();
			sleep(1);
			element(receiveButtonWitron).click();
			if (croAction.contains("notBOL")) {
				verifyRejectLineNotOnBol();
			}
			sleep(1);
		}
	}

	public void verifyRejectLineNotOnBol() {

		if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS) {
			element(croRejectedNotOnBolLine).waitUntilVisible();
			sleep(1);
			element(croRejectedNotOnBolLineOK).click();
			sleep(1);

			element(backFromRejectNotOnBOL).waitUntilVisible();

			element(backFromRejectNotOnBOL).click();

			element(cancelPalletLink).waitUntilVisible();

			element(cancelPalletLink).click();

			element(cancelPalletPopUpOK).waitUntilVisible();

			element(cancelPalletPopUpOK).click();
			sleep(2);

		}
	}

	public void clickOnFinshPalletButton() {
		element(palletInprogressText).waitUntilVisible();
		element(palletInprogressText).waitUntilEnabled();
		element(finishPalletButton).waitUntilVisible();
		element(finishPalletButton).waitUntilClickable();
		element(finishPalletButton).click();
	}

	public void clickOnFinshPalletButtonWitron() {

		element(finishPalletbuttonWit).waitUntilVisible();
		element(finishPalletbuttonWit).waitUntilClickable();
		element(finishPalletbuttonWit).click();
	}

	public boolean isFinshPalletButtonDisplayed() {
		return isElementVisible(finishPalletXpathValue);
	}

	public boolean isPlaceOnConveyorDisplayed() {
		return isElementVisible(placeOnConveyor);
	}

	public boolean isPlaceOnConveyorTextDisplayed() {
		return isElementVisible(placeOnConveyorText);
	}

	public void clickOnFinshPalletPopupButton() {
		element(finishPalletPopupButton).waitUntilVisible();
		element(finishPalletPopupButton).waitUntilClickable();
		element(finishPalletPopupButton).click();
		logger.info("Receiving App :: Received and created pallet");

	}

	public void clickOnCompleteDeliveryButton() {
		element(completeDeliveryButton).waitUntilVisible();
		element(completeDeliveryButton).click();

	}

	public void clickOnCompleteDeliveryPopup_ContinueButton() {
		element(deliveryCompleteConfimationPopup_ContinueButton).waitUntilVisible();
		element(deliveryCompleteConfimationPopup_ContinueButton).waitUntilClickable();
		element(deliveryCompleteConfimationPopup_ContinueButton).click();
		logger.info("Receiving App :: Clicked on complete delivery");
	}

	public void clickOnCompleteDeliveryPopup_Confirm() {
		element(deliveryCompleteConfimationPopup_Confirm).waitUntilVisible();
		element(deliveryCompleteConfimationPopup_Confirm).waitUntilClickable();
		element(deliveryCompleteConfimationPopup_Confirm).click();
		logger.info("Receiving App :: Clicked on complete delivery");
	}

	public String getDeliveryCompleteSuccessMssg() {
		String completeDeleiverySuccessMssg = element(deliveryCompleteTextMssg).getText();
		System.out.println("getDeliveryCompleteTextMssg :" + completeDeleiverySuccessMssg);
		return completeDeleiverySuccessMssg;
	}

	public String verifyItemUpcOnAttentionPopup() {
		String upcLabelOnAttentionPopupMsg = element(upcLabelOnAttentionPopup).getText();
		logger.info("upcLabelOnAttentionPopup Message:" + upcLabelOnAttentionPopupMsg);
		return upcLabelOnAttentionPopupMsg;
	}

	public void clickOnCloseButton() {
		element(palletCompletedText).waitUntilVisible();
		element(palletCompletedText).waitUntilEnabled();
		// element(receivecloseButton).waitUntilVisible();
		// element(receivecloseButton).waitUntilClickable();
		// element(receivecloseButton).click();
	}

	public void clickOnCloseButtonWitron() {
		element(closeButtonWitron).waitUntilVisible();
		element(closeButtonWitron).waitUntilEnabled();
		element(closeButtonWitron).waitUntilClickable();
		sleep(1);
		element(closeButtonWitron).click();
	}

	public void clickOnPalletCompleted() {
		element(receivecloseButtonWit).waitUntilVisible();
		element(receivecloseButtonWit).waitUntilEnabled();
		element(receivecloseButtonWit).waitUntilClickable();
		sleep(1);
		element(receivecloseButtonWit).click();
	}
	public void cancelPalletCase() {

		element(cancelPalletLink).waitUntilVisible();
		element(cancelPalletLink).waitUntilClickable();
		sleep(1);
		element(cancelPalletLink).click();

		element(cancelPalletPopUpOK).waitUntilVisible();
		element(cancelPalletPopUpOK).waitUntilClickable();
		sleep(1);
		element(cancelPalletPopUpOK).click();

		element(cancelPalletRemoved).waitUntilVisible();
		element(cancelPalletRemoved).waitUntilPresent();

	}

	public boolean isElementVisible(String fieldName) {
		try {
			WebDriver driver = getDriverInstance();
			WebDriverWait wait = new WebDriverWait(driver, 6);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(fieldName)));
			return true;
		} catch (TimeoutException ex) {
			return false;
		}
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);
	}

	public void closeDiver() {
		WebDriver driver = getDriverInstance();
		logger.info("\nClosing current webDriver session\n");
		// driver.quit();
	}

	public void selectPOLinefromRadioButton(String poNumber) {
		WebDriver driver = getDriverInstance();
		element(multiple_Delivery_DocumnentLines_ContinueButton).waitUntilVisible();
		element(multiple_Delivery_DocumnentLines_ContinueButton).waitUntilClickable();
		driver.findElement(By.xpath(
				"//div[div[div[text()='Select Delivery Document Line']]]//div[@role='radiogroup']//span[contains(text(),'"
						+ poNumber + "')]"))
				.click();
	}

	public void closeWitronDiver() {
		WebDriver driver = getDriverInstance();
		logger.info("\nClosing current webDriver session\n");
		driver.quit();
	}

	public void clickOn_multiple_Delivery_DocumentLines_ContinueButton() {
		element(multiple_Delivery_DocumnentLines_ContinueButton).waitUntilVisible();
		element(multiple_Delivery_DocumnentLines_ContinueButton).waitUntilClickable();
		element(multiple_Delivery_DocumnentLines_ContinueButton).click();
	}

	public boolean isitemFoundOnMultiplePO() {
		return isElementVisible(itemOnMultiplePO);
	}

	public boolean isiMultipleDeliveryDocumentLinesFound() {
		return isElementVisible(multipleDeliveryDocumnentLines);
	}

	public boolean isOveragePopupDisplayed() {
		return isElementVisible(overagePopup);
	}

	public void clickOnReportProblem() {
		element(reportProblem).waitUntilVisible();
		element(reportProblem).waitUntilClickable();
		element(reportProblem).click();
	}

	public void clickOnNextButton() {
		element(nextButton).waitUntilVisible();
		element(nextButton).waitUntilClickable();
		element(nextButton).click();
	}

	public void enterTIValue(String tiValue) {
		element(tiField).waitUntilVisible();
		element(tiField).waitUntilEnabled();
		element(tiField).type(tiValue);
	}

	public void enterHIValue(String hiValue) {
		element(hiField).waitUntilVisible();
		element(hiField).waitUntilEnabled();
		element(hiField).type(hiValue);
	}

	public void enterQty(String qty) {
		element(qtyField).waitUntilVisible();
		element(qtyField).waitUntilEnabled();
		element(qtyField).type(qty);
	}

	public void printLabels() {
		element(printOption).waitUntilVisible();
		element(printOption).waitUntilClickable();
		element(printOption).click();
	}

	public boolean isPrintingErrorDisplayed() {
		return isElementVisible(labelPrintingError);
	}

	public void clickOnGotIt() {
		element(gotItOption).waitUntilVisible();
		element(gotItOption).waitUntilClickable();
		element(gotItOption).click();
	}

	public void clickOnProblemReceiving() {
		element(problemReceivingTab).waitUntilVisible();
		element(problemReceivingTab).waitUntilClickable();
		element(problemReceivingTab).click();
	}

	public void scanProblemContainer(String problemContainer) {
		WebDriver driver = getDriverInstance();
		element(scanProblemPannel).waitUntilVisible();
		logger.info("problem container:" + problemContainer);
		driver = getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("door = new CustomEvent('scanned', {}); door.barcode = {value:'" + problemContainer
				+ "'}; document.dispatchEvent(door)");
	}

	public void closeIcon() throws InterruptedException {
		element(closeIcon).waitUntilVisible();
		element(closeIcon).waitUntilClickable();
		element(closeIcon).click();
		logger.info("Closed the scan item page");
		Thread.sleep(2000);
	}

	public void closeIconForDockTag() throws InterruptedException {
		element(closeIconForDockTag).waitUntilVisible();
		element(closeIconForDockTag).waitUntilClickable();
		Thread.sleep(2000);
		element(closeIconForDockTag).click();
		logger.info("Closed the scan item page for Docktag");
		Thread.sleep(2000);
	}

	public void cancelPallet() throws InterruptedException {
		element(cancelPallet).waitUntilVisible();
		element(cancelPallet).waitUntilClickable();
		element(cancelPallet).click();
		logger.info("Clicked on cancel pallet");

		Thread.sleep(2000);

		element(cancelPalletDiag).waitUntilVisible();
		element(cancelPalletDiag).waitUntilClickable();
		element(cancelPalletDiag).click();
		logger.info("Pallet cancelled successfully");

		Thread.sleep(2000);

	}

	public void clickOnPageCloseButton() {

		element(pageCloseButton).waitUntilVisible();
		element(pageCloseButton).waitUntilClickable();
		element(pageCloseButton).click();
		logger.info("Clicked on the page close button at the receiving screen");
	}

	public boolean checkUpcUpdateDialog() throws InterruptedException {

		Thread.sleep(5000);
		return element(upcUpdateDiag).isVisible();
	}

	public void clickOnUpcUpdateButton() {

		element(upcUpdateDiagButton).waitUntilVisible();
		element(upcUpdateDiagButton).waitUntilClickable();
		element(upcUpdateDiagButton).click();
		logger.info("Clicked on the UPC update button");

	}

	public void upcUpdateenterItemNumber(String itemNum) {

		element(upcUPdateEnterItemNumber).waitUntilVisible();
		element(upcUPdateEnterItemNumber).waitUntilClickable();
		element(upcUPdateEnterItemNumber).sendKeys(itemNum);
		logger.info("Entered item number for UPC update");

	}

	public void upcUpdateclickOnNext() {
		element(confirmNext).waitUntilVisible();
		element(confirmNext).waitUntilClickable();
		element(confirmNext).click();
		logger.info("Clicked on the next button during UPC update");

	}

	public void upcUpdated() {
		element(upcUpdated).waitUntilVisible();
		element(upcUpdated).waitUntilClickable();
		element(upcUpdated).click();
		logger.info("Clicked on the button for UPC update");

	}

	public void clickOnEnterDeliveryNumber() {
		element(enterDeliveryNumberButton).waitUntilVisible();
		element(enterDeliveryNumberButton).waitUntilClickable();
		element(enterDeliveryNumberButton).click();
		logger.info("Clicked on the enter delivery number to re-open delivery");

	}

	public void enterDeliveryNumber(String deliveryNumber) {
		element(enterDeliveryNumber).waitUntilVisible();
		element(enterDeliveryNumber).waitUntilClickable();
		element(enterDeliveryNumber).sendKeys(deliveryNumber);
		element(enterDeliveryNumber).sendKeys(Keys.ENTER);
		logger.info("Enter delivery number " + deliveryNumber + " to re-open delivery");
	}

	public void clickOnopenDeliveryButton() {
		element(openDeliveryButton).waitUntilVisible();
		element(openDeliveryButton).waitUntilClickable();
		element(openDeliveryButton).click();
		logger.info("Clicked on open delivery button to re-open delivery");
	}

	public void validateAppUIScreen() {

		element(appUIState).waitUntilVisible();
		logger.info("No Error shown on the UI on re-opening delivery");
	}

	public void enterDoorNumber(String doorNumber) {

		element(enterDoorNumber).waitUntilVisible();
		element(enterDoorNumber).waitUntilClickable();
		element(enterDoorNumber).sendKeys(doorNumber);
		element(enterDoorNumber).sendKeys(Keys.ENTER);
		logger.info("Enter delivery number " + doorNumber + " to re-open delivery");

	}

	public void selectManualReceiving() {

		element(manualReceivingButton).waitUntilVisible();
		element(manualReceivingButton).waitUntilClickable();
		element(manualReceivingButton).click();
		logger.info("Clicked on Manual receive Button");

		element(manualReceivingOption).waitUntilClickable();
		element(manualReceivingOption).waitUntilClickable();
		element(manualReceivingOption).click();
		logger.info("Clicked on Manual receive option");

	}

	public void clickOnContinueButton() {

		element(manualReceivingContinueButton).waitUntilClickable();
		element(manualReceivingContinueButton).waitUntilClickable();
		element(manualReceivingContinueButton).click();
		logger.info("Clicked on Continue button to trigger manual receive option");
	}

	public void clickOnBackArrow() {
		element(backArrow).waitUntilClickable();
		element(backArrow).waitUntilClickable();
		element(backArrow).click();
		logger.info("Clicked on Back Arrow after re-opening delivery ");
	}

	public void clickOnRecevingRightMenu() {
		element(manualReceivingButton).waitUntilVisible();
		element(manualReceivingButton).waitUntilClickable();
		element(manualReceivingButton).click();
		logger.info("Clicked on Manual receive Button");
	}

	public void clickOnDSDCOption() {
		element(DSDCOption).waitUntilVisible();
		element(DSDCOption).waitUntilClickable();
		element(DSDCOption).click();
		logger.info("Selected on DSDC option");
	}

	public void clickOnPoCheckbox() {
		element(PoCheckbox).waitUntilVisible();
		element(PoCheckbox).waitUntilClickable();
		element(PoCheckbox).click();
		logger.info("Selected Po Checkbox");
	}

	public void clickOnNextBtn() {
		element(DsdcPoconNextButton).waitUntilVisible();
		element(DsdcPoconNextButton).waitUntilClickable();
		element(DsdcPoconNextButton).click();
		logger.info("Clicked Dsdc Next button");
	}


	public void checkForDSDCPage() {
		element(closeButtonDSDCScreen).waitUntilVisible();
		element(closeButtonDSDCScreen).waitUntilClickable();
	}

	public void selectSourceNumber(String sourceNumber) {
		element(closeButtonDSDCScreen).waitUntilVisible();
		element(closeButtonDSDCScreen).waitUntilClickable();
		WebDriver driver = getDriverInstance();
		driver.findElement(By.xpath("//button/span/div[contains(text(),'" + sourceNumber + "')]")).click();
		logger.info("Selected Source number");
	}

	public void enterQtyToReceivingField(String poNumber, String qty) {
		element(enterQtyToReceivePage).waitUntilVisible();
		element(enterQtyToReceivePage).waitUntilClickable();
		element(enterQtyToReceivePage).sendKeys(qty);
		//WebDriver driver = getDriverInstance();
		//driver.findElement(By.xpath("//input[contains(@placeholder,'Case qty')]")).sendKeys(qty);
//		driver.findElement(By
//				.xpath("//div[div[div[contains(text(),'"+poNumber+"')]]]/div[2]//input"))
//				.sendKeys(qty);
		logger.info("Entered quantity to receive");
	}

	public void clickOnPrintLabelButton() {
		element(printLabelButton).waitUntilVisible();
		element(printLabelButton).waitUntilClickable();
		element(printLabelButton).click();
		logger.info("Clicked on Print Label Button");
	}

	public void checkForDSDCPalletCompletePage() {
		element(closeDSDCPalletCompletePage).waitUntilVisible();
		element(closeDSDCPalletCompletePage).waitUntilClickable();
	}

	public void clickOnCloseButtonDSDCScreen() {
		element(closeDSDCPalletCompletePage).waitUntilVisible();
		element(closeDSDCPalletCompletePage).waitUntilClickable();
		element(closeDSDCPalletCompletePage).click();
	}

	public void validateFreightIsNotConveyableDialogBox(String upc) {

		element(FreightNotConveyableDialogHeading).waitUntilVisible();
		element(FreightNotConveyableDialogHeading).waitUntilClickable();
		element(FreightNotConveyableDialogHeading).isVisible();
		String message=element(FreightNotConveyableMessage).getText();
		//add new error code for this file
		logger.info(message);
		Assert.assertEquals(ErrorCodes.RECEIVING_FREIGHT_POPUP_NOT_FOUND, message, "UPC #"+upc+" is not conveyable. Would you like to start receiving this freight?");
		element(FreightNotConveyableAcceptButton).click();
	}

	public void validateAddToFloorLinePalletMessage() {
		element(addToFloorLinePallet).waitUntilVisible();
		element(addToFloorLinePallet).waitUntilClickable();
		element(addToFloorLinePallet).isVisible();
		Assert.assertTrue(ErrorCodes.RECEIVING_ADD_TO_FLOOR_LINE_PALLET_MSG_NOT_FOUND, element(addToFloorLinePallet).isDisplayed());
	}

	public void verifyScannedItemMessage(String upc) {

		element(scannedItemMessage).waitUntilVisible();
		String message=element(scannedItemMessage).getText();
		logger.info(message);
		Assert.assertEquals(ErrorCodes.RECEIVING_SCANNED_CROSSU_ITEM_MESSAGE_NOT_FOUND, message, "UPC #"+upc+" scanned. Place on conveyor.");
	}
	public void clickOnPrintPBYLDockTagOption() {
		element(printPBYLDockTagOption).waitUntilVisible();
		element(printPBYLDockTagOption).waitUntilClickable();
		element(printPBYLDockTagOption).click();
		logger.info("Selected on Print PBYL Tag Option");
	}
	public void clickOnPrintAnotherPrintPBYLDockTag() {
		element(printAnotherPBYLDockTagButton).waitUntilVisible();
		element(printAnotherPBYLDockTagButton).waitUntilClickable();
		element(printAnotherPBYLDockTagButton).click();
		logger.info("Clicked on Print Another PBYL DockTag Button");
	}
	public void clickOnCloseIconPrintPBYLDockTag() {
//		element(closeIconPrintPBYLDockTag).waitUntilVisible();
//		element(closeIconPrintPBYLDockTag).waitUntilEnabled();
//		element(closeIconPrintPBYLDockTag).waitUntilClickable();
//		sleep(1);
//		element(closeIconPrintPBYLDockTag).click();
//		sleep(5);
		logger.info("Clicked on Close Icon for Print PBYL DockTag");
	}
	public void clickOnBackArrowScanUPCScreen() {
//		element(backArrowScanUPCScreen).waitUntilVisible();
//		element(backArrowScanUPCScreen).waitUntilClickable();
//		element(backArrowScanUPCScreen).click();
		logger.info("Clicked on back Arrow Scan UPC Screen");
	}
	public void clickOnReceivePBYLDockTagButton() {
		sleep(5);
		element(receivePBYLDockTagBtton).waitUntilVisible();
		element(receivePBYLDockTagBtton).waitUntilClickable();
		element(receivePBYLDockTagBtton).click();
		logger.info("Clicked on receivePBYLDockTagBtton");
	}

	public void enterQtyToReceivePBYL(int qty) {
		element(qtyToReceiveTextboxPBYL).waitUntilVisible();
		element(qtyToReceiveTextboxPBYL).waitUntilClickable();
		element(qtyToReceiveTextboxPBYL).sendKeys(""+qty);
		logger.info("Entered quantity to receive="+qty);
	}

	public void waitForScanNextItemMessageToAppear() {
		element(scanNextUPCMessage).waitUntilVisible();
		logger.info("Waiting For 'Scan Next Item' Message To Appear");
	}

	public void clickOnFinishPalletButton() {
		sleep(5);
		boolean isPalletCompletedTextDisplayed = element(palletInProgressOrCompletedText).getText().equalsIgnoreCase("Pallet complete");
		if(!isPalletCompletedTextDisplayed) {
			clickOnFinshPalletButton();
			clickOnFinshPalletPopupButton();
		}
	}

	public void selectAllPoAndclickOnNextInDSDCScreen() {
		WebDriver driver =getWebDriverInstance();
		List<WebElement> pos = driver.findElements(By.xpath ( "//div[@id='selectDsdcPo']/div/span/span[1]"));
		for (int i = 0; i < pos.size(); i++) {
			element(pos.get(i)).waitUntilVisible();
			element(pos.get(i)).waitUntilClickable();
			element(pos.get(i)).click();
		}
		logger.info("Selected all Po Checkbox");

	}

	public void clickOnYesForMultiPOReceiving() {
		clickOnNextBtn();
		element(clickOnYesOnCombinePOs).click();
		logger.info("clicked on Next button and selected Yes btn for multi po receiving");
	}

	public void enterQtyToReceiveMultiPO(List<String> caseQtys) {
		WebDriver driver = getWebDriverInstance();
		List<WebElement> caseQtyBox = driver.findElements(By.xpath("//input[@placeholder='Case qty']"));
		for (int i = 0; i < caseQtyBox.size(); i++) {
			int caseQty = Integer.valueOf(caseQtys.get(i));
			caseQtyBox.get(i).sendKeys(String.valueOf(caseQty));
		}
		logger.info("Entered quantity to receive for PO");
	}

	public void clickOnPOCONOption() {
		element(POCONOption).waitUntilVisible();
		element(POCONOption).waitUntilClickable();
		element(POCONOption).click();
		logger.info("Selected POCON option");
	}

	public void checkForPOCONPage() {
		element(checkForPoconScreen).waitUntilVisible();
		element(checkForPoconScreen).waitUntilClickable();
	}

	public void clickOnPOCONcheckbox() {
		element(poconCheckbox).waitUntilVisible();
		element(poconCheckbox).waitUntilClickable();
		element(poconCheckbox).click();
		logger.info("Selected Po Checkbox");
	}

	public void checkForPOCONPalletCompletePage() {
		element(closeBtnPOCONPalletCompletePage).waitUntilVisible();
		element(closeBtnPOCONPalletCompletePage).waitUntilClickable();
	}

	public void clickOnCloseButtonPOCONScreen() {
		element(closeBtnPOCONPalletCompletePage).waitUntilVisible();
		element(closeBtnPOCONPalletCompletePage).waitUntilClickable();
		element(closeBtnPOCONPalletCompletePage).click();
	}

	public boolean validatePoTypeTextOnTop(String poTypeText) {
		boolean isPoTypeTextDisplayed = false;
		switch (poTypeText) {
			case "SSTK" : isPoTypeTextDisplayed = isPoTypeTextDisplayedCorrectly(sstkTextOnTop); break;
			case "DA CON" : isPoTypeTextDisplayed = isPoTypeTextDisplayedCorrectly(daConTextOnTop);break;
			case "DA NONCON" : isPoTypeTextDisplayed =  isPoTypeTextDisplayedCorrectly(daNonConTextOnTop);break;
			case "PO CON" :  isPoTypeTextDisplayed = isPoTypeTextDisplayedCorrectly(poConTextOnTop);break;
			case "DA Conveyable" :  isPoTypeTextDisplayed = isPoTypeTextDisplayedCorrectly(daConveyableFloorLinePalletTextOnTop);break;
			default : isPoTypeTextDisplayed= false; new AutomationFailure(poTypeText+" is not a valid poType.");
		}
		return isPoTypeTextDisplayed;
	}

	public boolean isPoTypeTextDisplayedCorrectly(WebElement webElement) {
		return element(webElement).isDisplayed();
	}
}
