package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class YMSGateManagementPage extends SerenityHelper {

	PropertyResolver propertyResolver = new PropertyResolver();
	YMSHelper ymsHelper= new YMSHelper();
	Logger logger = LogManager.getLogger(this.getClass());
	String errorMessageXpath="(//div[@class='errorDH'])[3]/ul/li";

	@FindBy(xpath = "//td[@id='Gate Management']//a")
	private WebElement gateManagementLink;

	@FindBy(xpath = "//tr[@id='label.menu.gateMenu.gateInOut']//a")
	private WebElement gateInOrOutLink;

	@FindBy(id = "keyValue")
	private WebElement inboundField;

	@FindBy(id = "trailerId")
	private WebElement trailerNumberField;

	@FindBy(id = "scac")
	private WebElement scacField;

	@FindBy(id = "dcNumber")
	private WebElement dcNumberDropDown;

	@FindBy(id = "subcenterId")
	private WebElement subCenterDropDown;

	@FindBy(id = "GateInId")
	private WebElement gateInButton;

	@FindBy(id = "GateOut")
	private WebElement gateOutButton;

	@FindBy(id = "deliveryType")
	private WebElement deliveryTypeDropDown;

	@FindBy(id = "trailerType")
	private WebElement trailerTypeDropDown;

	@FindBy(name = "tractorNumber")
	private WebElement tractorNumberField;

	@FindBy(id = "wmStatus")
	private WebElement wmStatusDropDown;

	@FindBy(id = "verifiedFlagY")
	private WebElement identificationReqYesRadioButton;

	@FindBy(id = "next")
	private WebElement nextButton;

	@FindBy(id = "yes")
	private WebElement yesButton;

	@FindBy(xpath = "(//div[@class='errorDH'])[3]/ul/li")
	private WebElement errorMsgLabel;

	@FindBy(xpath = "//*[@class='successDH']/ul/li")
	public WebElement successMsgLabel;

	@FindBy(id = "ok")
	private WebElement okButton;

	public void clickGateManagement() {
		element(gateManagementLink).waitUntilVisible();
		logger.info("Clicking in Gate Management Link");
		element(gateManagementLink).click();
	}

	public void clickGateInorOut() {
		element(gateInOrOutLink).waitUntilVisible();
		logger.info("Clicking in Gate In/Out Link");
		element(gateInOrOutLink).click();
	}

	public String deliveryGateIn(String deliveryNumber) {
		String message = "";
		element(inboundField).waitUntilVisible();
		element(inboundField).type(deliveryNumber);
		logger.info("Clicking on Gate In button");
		element(gateInButton).click();
//		if (ymsHelper.isElementVisible(errorMessageXpath))
//			message = element(errorMsgLabel).getText();
//		else {
			element(deliveryTypeDropDown)
					.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "deliverytype"));
			element(trailerTypeDropDown)
					.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "trailertype"));
			logger.info("Clicking on Next button");
			element(nextButton).click();
//			if (ymsHelper.isElementVisible(errorMessageXpath))
//				message = element(errorMsgLabel).getText();
//			else {
				element(tractorNumberField).clear();
				element(tractorNumberField).type("TR" + deliveryNumber);
				element(wmStatusDropDown)
						.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "wmstatus"));
//				if (ymsHelper.isElementVisible("//*[@id='verifiedFlagY']"))
//					element(identificationReqYesRadioButton).click();
				logger.info("Clicking on Next button");
				element(nextButton).click();
			//}
			element(yesButton).waitUntilVisible();
			element(yesButton).click();
			if (ymsHelper.isElementDisplayed(successMsgLabel))
				message = element(successMsgLabel).getText();
			element(okButton).click();

			logger.info("Delivery Gate In is successful");
	//	}

		return message;

	}

	public String TrailerGateIn(String deliveryNumber) {
		String message = "";
		
		element(trailerNumberField).waitUntilVisible();
		element(trailerNumberField).clear();
		element(trailerNumberField).type("TLR" + deliveryNumber);
		//update later to use one trailer for both inbound and outbound
		/*if(RunTimeData.getOutBoundTrailer()==null||trailerNumber.equals("")) {
            RunTimeData.setOutBoundTrailer("TLR" + deliveryNumber);
        }*/
		element(scacField).clear();
		element(scacField).type(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "scac"));
		element(dcNumberDropDown).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number", true));
		element(subCenterDropDown)
				.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "sub_center", true));
		element(gateInButton).click();
		logger.info("Gate In button is clicked");
//		if (ymsHelper.isElementVisible(errorMessageXpath))
//			message = element(errorMsgLabel).getText();
//		else {
			element(deliveryTypeDropDown).waitUntilVisible();
			element(deliveryTypeDropDown)
					.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "deliverytype"));
			element(trailerTypeDropDown)
					.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "trailertype"));
			element(nextButton).click();
			logger.info("Next button is clicked");
//			if (ymsHelper.isElementVisible(errorMessageXpath)) {
//				message = element(errorMsgLabel).getText();
//			} else {
				element(tractorNumberField).waitUntilVisible();
				element(tractorNumberField).clear();
				element(tractorNumberField).type("TR" + deliveryNumber);
				element(wmStatusDropDown)
						.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "wmstatus"));
//				if (ymsHelper.isElementVisible("//*[@id='verifiedFlagY']"))
//					element(identificationReqYesRadioButton).click();
				element(nextButton).click();
				logger.info("Next button is clicked");
//			}
			element(yesButton).waitUntilVisible();
			element(yesButton).click();
			if (ymsHelper.isElementDisplayed(successMsgLabel))
				message = element(successMsgLabel).getText();
			element(okButton).click();
			logger.info("Trailer Gate In is successful");
//		}
		return message;
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);
	}

	public String TrailerGateOut(String deliveryNumber,String trailerNumber) {
		String message = "";
		element(trailerNumberField).waitUntilVisible();
		element(trailerNumberField).clear();
		element(trailerNumberField).type(trailerNumber);
		element(scacField).clear();
		element(scacField).type(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "scac"));
		element(dcNumberDropDown).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number", true));
		element(subCenterDropDown)
				.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "sub_center", true));
		element(gateOutButton).click();
		logger.info("Gate Out Button is clicked");
//		if (ymsHelper.isElementVisible(errorMessageXpath)) {
//			message = element(errorMsgLabel).getText();
//		}
		element(nextButton).click();
		logger.info("Next Button is clicked");
		element(tractorNumberField).clear();
		element(tractorNumberField).type("TR" +deliveryNumber);
		element(nextButton).click();
		if (ymsHelper.isElementDisplayed(successMsgLabel)) {
			message=element(successMsgLabel).getText().trim();
			element(okButton).click();
			logger.info("OK button is clicked successfully.");
		}
		return message;
	}

}
