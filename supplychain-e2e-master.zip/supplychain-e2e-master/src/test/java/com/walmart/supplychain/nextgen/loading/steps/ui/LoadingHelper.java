package com.walmart.supplychain.nextgen.loading.steps.ui;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import io.restassured.http.Header;
import io.restassured.http.Headers;

public class LoadingHelper {

	@Autowired
	Environment environment;
	
	public Headers getloadingHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum",environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		return new Headers(headerList);
	}
}
