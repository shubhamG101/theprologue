package com.walmart.supplychain.acc.mcb.steps.webservices;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

import org.apache.logging.log4j.LogManager;
import io.restassured.http.Header;
import io.restassured.http.Headers;


@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class MCBSteps {
	@Autowired
	MCBHelper mcbHelper;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	JsonUtils jsonUtils;

	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);


	String testFlowData;
	private static final String RECEIVE_INSTRUCTION_CONTAINER_JSON_PATH="$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?((@.isPbyl == false) && (@.isDamage == false))].parentContainer";
	private static final String MCB_PALLET_JSON_PATH="$.build.links..masterLabel";
	private static final String MCB_PALLET_IN_TESTFLOWDATA_JSON_PATH="$.testFlowData.outboundDetails[*]..mcbContainerID";
	private static final String DEST_NUMBER_JSON_PATH="$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[*].destNumber";
	private static final String SCAN_PALLET_URL_COMBINED="scan_pallet_url_combined";
	private static final String CREATE_MCB_PALLET_URL_COMBINED="create_mcb_pallet_url_combined";
	private static final String CREATE_MCB_PALLET_URL_COMBINED_REGULAR_NEW="create_mcb_pallet_url_combined_and_regular_new";
	private static final String CREATE_MCB_PALLET_COMPLETE_START="complete_start_mcb_pallet_url_new";
	private static final String CREATE_MCB_PALLET_COMPLETE_FINISH="complete_finish_mcb_pallet_url_new";
	private static final String ASSOCIATE_NEXT_PALLET_COMBINED="associate_next_pallets_url_combined";
	private static final String COMPLETE_MCB_PALLET_COMBINED="complete_mcb_pallet_combined";
	private static final String SCAN_PALLET_URL_REGULAR="scan_pallet_url_regular";
	private static final String CREATE_MCB_PALLET_URL_REGULAR="create_mcb_pallet_url_regular";
	private static final String ASSOCIATE_NEXT_PALLET_REGULAR="associate_next_pallets_url_regular";
	private static final String COMPLETE_MCB_PALLET_REGULAR="complete_mcb_pallet_regular";
	private static final String DISSOCIATE_CHILD_FROM_MCB="dissociate_child_from_mcb_pallet";
	private static final String TESTFLOW_DATA="testFlowData";
	private static final String GET_GROUP_ID="get_mcb_group_id";
	private static final String GET_REGULAR_MCB_GROUP_ID="get_mcb_group_regular_id";
	private static final String GET_MCB_ID="get_mcb_id";
	private static final String MCB_STORE_GROUP_ID="mcb_store_group_id";
	private static final String MCB_CTRN_ID="mcb_master_ctnr_id";
	private static final String OUTBOUND_ENTITY="$.testFlowData.outboundDetails";
	private static final String FACILITY_COUNTRY_CODE="facilityCountryCode";
	private static final String FACILITY_NUMBER="facilityNum";
	private static final String WMT_USER_ID="WMT-UserId";
	private static final String APPLICATION_CONTENT_TYPE="application/json";
	private static final String COUNTRY_CODE="country_code";
	private static final String DC_NUMBER="dcNumber";
	private static final String NEXTGEN_USER_NAME="nextGenUserName";
	private static final String MASTER_TRACKING_ID= "$.masterContainerTO.trackingId";
	private Response scanAPallet;
	private Response createMCBPallet;
	private Response createMCBPalletNew;
	private Response completeStartMCBPalletNew;
	private Response completefinishMCBPalletNew;
	private Response addNextPallet;
	private Response completeAPallet;
	private Response dissociateChild;
	private String parentTrackingId;

	public void createMCBPalletRegularFlow(String groupName) {
		List<String> mcbPalletNameList=null;
		String mcbPalletName=null;
		boolean isMCBPalletBuilt=false;
		List<String> storeList=null;
		String oldPalletOnMCB=null;
		int groupId=0;
		try {
			testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			logger.info("Get groupID for the groupName {}",groupName);
			List<Map<String, Object>> groupNameMap = dbUtils.selectFrom(Config.DC,
					environment.getProperty(GET_GROUP_ID), groupName);
			if (groupNameMap.size() > 0) {
				groupId = (int) groupNameMap.get(0).get(MCB_STORE_GROUP_ID);
			}
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> listOfCntrs = testFlowDataJsonParser.read(RECEIVE_INSTRUCTION_CONTAINER_JSON_PATH);

			for (String cntr : listOfCntrs) {
				storeList = testFlowDataJsonParser.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.parentContainer == '"+cntr+"')].destNumber");
				int storeNumber=Integer.parseInt(storeList.get(0));
				if (!isMCBPalletBuilt) {
					oldPalletOnMCB=cntr;
					logger.info("scaning first label : {}",cntr);
					String scanPalletResponse=scanPalletForMCBRegular(cntr, groupName, groupId);
					logger.info("scanned first label : {}",cntr);
					Thread.sleep(3000);
					DocumentContext  scanAPalletJsonParser = JsonPath.parse(scanPalletResponse);
					mcbPalletNameList = scanAPalletJsonParser.read(MCB_PALLET_JSON_PATH);
					mcbPalletName=mcbPalletNameList.get(0);
					isMCBPalletBuilt=true;
					logger.info("MCB pallet is : {}",mcbPalletName);

					logger.info("Creating MCB pallet : {}",mcbPalletName);
					createMCBPalletforRegular(mcbPalletName, cntr, groupName, groupId);
					logger.info("Created MCB pallet : {}",mcbPalletName);

					setDataIntoTestflowdata(mcbPalletName);
				}
				else {
					logger.info("Associating label : {} to the MCB :{}",cntr,mcbPalletName);
					associatePalletsonMCBforRegular(cntr, oldPalletOnMCB, storeNumber, groupName, String.valueOf(groupId));
					logger.info("Associated label : {} to the MCB :{}",cntr,mcbPalletName);
				}
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating MCB pallet Regular flow", e);
		}
	}

	@Step
	public void createMCBPalletCombinedFlow() {
		List<String> mcbPalletNameList=null;
		String mcbPalletName=null;
		boolean isMCBPalletBuilt=false;
		List<String> storeList=null;
		String oldPalletOnMCB=null;

		try {
			testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> listOfCntrs = testFlowDataJsonParser.read(RECEIVE_INSTRUCTION_CONTAINER_JSON_PATH);

			for (String cntr : listOfCntrs) {
				storeList = testFlowDataJsonParser.read("$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.parentContainer == '"+cntr+"')].destNumber");
				int storeNumber=Integer.parseInt(storeList.get(0));
				if (!isMCBPalletBuilt) {
					oldPalletOnMCB=cntr;
					logger.info("scaning first label : {}",cntr);
					String scanPalletResponse=scanPalletForMCBCombined(cntr);
					logger.info("scanned first label : {}",cntr);
					Thread.sleep(3000);
					DocumentContext  scanAPalletJsonParser = JsonPath.parse(scanPalletResponse);
					mcbPalletNameList = scanAPalletJsonParser.read(MCB_PALLET_JSON_PATH);
					mcbPalletName=mcbPalletNameList.get(0);
					isMCBPalletBuilt=true;
					logger.info("MCB pallet is : {}",mcbPalletName);

					logger.info("Creating MCB pallet : {}",mcbPalletName);
					createMCBPalletforCombined(mcbPalletName, cntr);
					logger.info("Created MCB pallet : {}",mcbPalletName);

					setDataIntoTestflowdata(mcbPalletName);
				}
				else {
					logger.info("Associating label : {} to the MCB :{}",cntr,mcbPalletName);
					associatePalletsonMCBforCombined(cntr, oldPalletOnMCB, storeNumber);
					logger.info("Associated label : {} to the MCB :{}",cntr,mcbPalletName);
				}
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating MCB pallet for Combined flow", e);
		}
	}

	public String scanPalletForMCBRegular(String cntr, String groupName, int groupId) throws IOException {
		scanAPallet=null;
		String mcbFirstPalletScanPayload=mcbHelper.constructFirstPalletScanPayload(cntr, groupName, groupId);
		logger.info("REGULAR* mcbFirstPalletScanPayload : "+mcbFirstPalletScanPayload );
		Failsafe.with(retryPolicy).run(() -> {
			scanAPallet = SerenityRest.given().body(mcbFirstPalletScanPayload).contentType(APPLICATION_CONTENT_TYPE)
					.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
					.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
					.when().post(environment.getProperty(SCAN_PALLET_URL_REGULAR));

			Assert.assertEquals(ErrorCodes.MCB_SCAN_FAILED,Constants.SUCESS_STATUS_CODE,
					scanAPallet.getStatusCode());
		});
		 return scanAPallet.asString();

	}

	public String scanPalletForMCBCombined(String cntr) throws IOException {
		scanAPallet=null;
		String mcbFirstPalletScanPayload=mcbHelper.constructFirstPalletScanPayload(cntr);
		Failsafe.with(retryPolicy).run(() -> {
			scanAPallet = SerenityRest.given().body(mcbFirstPalletScanPayload).contentType(APPLICATION_CONTENT_TYPE)
					.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
					.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
					.when().post(environment.getProperty(SCAN_PALLET_URL_COMBINED));

			Assert.assertEquals(ErrorCodes.MCB_SCAN_FAILED,Constants.SUCESS_STATUS_CODE,
					scanAPallet.getStatusCode());
		});
		return scanAPallet.asString();
	}

	public void createMCBPalletforRegular(String mcbPalletName, String cntr, String groupName, int groupId) throws IOException {
		createMCBPallet=null;
		String mcbNextPalletScanPayload=mcbHelper.constructCreateMCBPalletPayload(mcbPalletName, cntr, groupName, groupId);
		logger.info("REGULAR* mcbNextPalletScanPayload : "+mcbNextPalletScanPayload );
		Failsafe.with(retryPolicy).run(() -> {
			createMCBPallet = SerenityRest.given().body(mcbNextPalletScanPayload).contentType(APPLICATION_CONTENT_TYPE)
					.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
					.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
					.when().post(environment.getProperty(CREATE_MCB_PALLET_URL_REGULAR));

			Assert.assertEquals(ErrorCodes.MCB_CREATION_FAILED,Constants.CREATE_SUCESS_STATUS_CODE,
					createMCBPallet.getStatusCode());
		});
	}

	public void createMCBPalletforCombined(String mcbPalletName, String cntr) throws IOException {
		createMCBPallet=null;
		String mcbNextPalletScanPayload=mcbHelper.constructCreateMCBPalletPayload(mcbPalletName, cntr);
		Failsafe.with(retryPolicy).run(() -> {
			createMCBPallet = SerenityRest.given().body(mcbNextPalletScanPayload).contentType(APPLICATION_CONTENT_TYPE)
					.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
					.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
					.when().post(environment.getProperty(CREATE_MCB_PALLET_URL_COMBINED));

			Assert.assertEquals(ErrorCodes.MCB_CREATION_FAILED,Constants.CREATE_SUCESS_STATUS_CODE,
					createMCBPallet.getStatusCode());
		});
	}
	public void associatePalletsonMCBforRegular(String cntr, String oldPalletOnMCB, int storeNumber, String groupName, String groupId) throws IOException {
		addNextPallet=null;
		String associateNextPalletScanPayload=mcbHelper.constructAssociateNextPalletPayload(cntr,oldPalletOnMCB, storeNumber,groupName,groupId);
		Failsafe.with(retryPolicy).run(() -> {
			addNextPallet = SerenityRest.given().body(associateNextPalletScanPayload).contentType(APPLICATION_CONTENT_TYPE)
					.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
					.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
					.when().post(environment.getProperty(ASSOCIATE_NEXT_PALLET_REGULAR));

			Assert.assertEquals(ErrorCodes.MCB_ASSOCIATE_CHILD_TO_PARENT_MCB_FAILED,Constants.SUCESS_STATUS_CODE,
					addNextPallet.getStatusCode());
		});
	}

	public void associatePalletsonMCBforCombined(String cntr, String oldPalletOnMCB, int storeNumber) throws IOException {
		addNextPallet=null;
		String associateNextPalletScanPayload=mcbHelper.constructAssociateNextPalletPayload(cntr, oldPalletOnMCB, storeNumber);
		Failsafe.with(retryPolicy).run(() -> {
			addNextPallet = SerenityRest.given().body(associateNextPalletScanPayload).contentType(APPLICATION_CONTENT_TYPE)
					.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
					.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
					.when().post(environment.getProperty(ASSOCIATE_NEXT_PALLET_COMBINED));

			Assert.assertEquals(ErrorCodes.MCB_ASSOCIATE_CHILD_TO_PARENT_MCB_FAILED,Constants.SUCESS_STATUS_CODE,
					addNextPallet.getStatusCode());
		});
	}

	@Step
	public void completeMCBPalletRegularFlow(String groupName){
		int groupId=0;
		try {
			logger.info("Get groupID from the groupName {}",groupName);
			List<Map<String, Object>> groupNameMap = dbUtils.selectFrom(Config.DC,
					environment.getProperty(GET_GROUP_ID), groupName);
			if (groupNameMap.size() > 0) {
				groupId = (int) groupNameMap.get(0).get(MCB_STORE_GROUP_ID);
			}

			testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> storeList = testFlowDataJsonParser.read(DEST_NUMBER_JSON_PATH);
			int storeNumber=Integer.parseInt(storeList.get(0));
			List<String> mcbPalletList = testFlowDataJsonParser.read(MCB_PALLET_IN_TESTFLOWDATA_JSON_PATH);
			String mcbPallet=mcbPalletList.get(0);

			String completePalletPayload=mcbHelper.constructCompleteMCBPalletPayload(mcbPallet, storeNumber,groupName,groupId);
			logger.info("REGULAR* completePalletScanPayload : "+completePalletPayload );
			logger.info("Completing MCB pallet : {}",mcbPallet);
			completeAPallet=null;
			Failsafe.with(retryPolicy).run(() -> {
				completeAPallet = SerenityRest.given().body(completePalletPayload).contentType(APPLICATION_CONTENT_TYPE)
						.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
						.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
						.when().post(environment.getProperty(COMPLETE_MCB_PALLET_REGULAR));

				Assert.assertEquals(ErrorCodes.COMPLETE_MCB_PALLET_FAILED,Constants.SUCESS_STATUS_CODE,
						completeAPallet.getStatusCode());
			});
			logger.info("Completed MCB pallet : {}",mcbPallet);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while completing MCB pallet for Regular Flow", e);
		}
	}

	@Step
	public void completeMCBPalletCombinedFlow(){
		try {
			testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> storeList = testFlowDataJsonParser.read(DEST_NUMBER_JSON_PATH);
			int storeNumber=Integer.parseInt(storeList.get(0));
			List<String> mcbPalletList = testFlowDataJsonParser.read(MCB_PALLET_IN_TESTFLOWDATA_JSON_PATH);
			String mcbPallet=mcbPalletList.get(0);

			String completePalletPayload=mcbHelper.constructCompleteMCBPalletPayload(mcbPallet, storeNumber);
			logger.info("Completing MCB pallet : {}",mcbPallet);
			completeAPallet=null;
			Failsafe.with(retryPolicy).run(() -> {
				completeAPallet = SerenityRest.given().body(completePalletPayload).contentType(APPLICATION_CONTENT_TYPE)
						.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
						.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
						.when().post(environment.getProperty(COMPLETE_MCB_PALLET_COMBINED));

				Assert.assertEquals(ErrorCodes.COMPLETE_MCB_PALLET_FAILED,Constants.SUCESS_STATUS_CODE,
						completeAPallet.getStatusCode());
			});
			logger.info("Completed MCB pallet : {}",mcbPallet);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while completing MCB pallet for Combined Flow", e);
		}
	}

	public void setDataIntoTestflowdata(String mcbPalletName) throws IOException, ParseException {
		ObjectMapper objectMapper = new ObjectMapper();
		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		OutboundDetail obdDetails = new OutboundDetail();
		obdDetails.setMcbContainerID(mcbPalletName);
		List<OutboundDetail> OutboundDetailList = new ArrayList<OutboundDetail>();
		OutboundDetailList.add(obdDetails);

		JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
		ObjectMapper om = new ObjectMapper();
		DocumentContext context = JsonPath.parse(parser.parse(testFlowData));
		om.writeValueAsString(OutboundDetailList);
		context.set(OUTBOUND_ENTITY,
				JsonPath.parse(om.writeValueAsString(OutboundDetailList)).read("$", JSONArray.class));
		String str = context.jsonString();
		threadLocal.get().put(TESTFLOW_DATA, str);

		testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
		logger.info("test flow data after updating MCB container : {}",testFlowData);
	}

	@Step
	public void dissociateAllChildContainersFromMCB() {

		try {
			dissociateChild=null;
			testFlowData=String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> listOfChildCntrs = testFlowDataJsonParser.read(RECEIVE_INSTRUCTION_CONTAINER_JSON_PATH);
			List<String> mcbPalletList = testFlowDataJsonParser.read(MCB_PALLET_IN_TESTFLOWDATA_JSON_PATH);
			String mcbContianer=mcbPalletList.get(0);
			String removeChildContainersPayload=mcbHelper.constructRemoveChildContainersPayload(listOfChildCntrs);
			logger.info("REGULAR* removeChildContainersPayload : "+removeChildContainersPayload );

			Failsafe.with(retryPolicy).run(() -> {
				int mcbId=0;
				logger.info("Get MCB ID for the MCB pallet {}",mcbContianer);
				List<Map<String, Object>> mcbContainerIDMap = dbUtils.selectFrom(Config.DC,
						environment.getProperty(GET_MCB_ID), mcbContianer);
				if (mcbContainerIDMap.size() > 0) {
					mcbId = (int) mcbContainerIDMap.get(0).get(MCB_CTRN_ID);
				}
				logger.info("Dissociating all child containers from MCB {}",mcbContianer);
				dissociateChild = SerenityRest.given().body(removeChildContainersPayload).contentType(APPLICATION_CONTENT_TYPE)
						.header(FACILITY_COUNTRY_CODE, environment.getProperty(COUNTRY_CODE)).header(FACILITY_NUMBER, environment.getProperty(DC_NUMBER))
						.header(WMT_USER_ID, environment.getProperty(NEXTGEN_USER_NAME))
						.when().put(environment.getProperty(DISSOCIATE_CHILD_FROM_MCB)+mcbId);

				Assert.assertEquals(ErrorCodes.MCB_DISSOCIATION_OF_CHILD_FAILED,Constants.SUCESS_STATUS_CODE,
						dissociateChild.getStatusCode());
			});
			logger.info("Dissociated all child containers from MCB {}",mcbContianer);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while dissociating child containres from MCB pallet for Combined Flow", e);
		}

	}

	public Headers getMcbPallettHeaders() {
		Header accept = new Header("Accept", "application/json, text/plain, */*");
		Header Accept_encode = new Header("Accept-Encoding", "gzip, deflate");
		Header countryCode = new Header("facilityCountryCode", environment.getProperty(COUNTRY_CODE));
		Header facilityNum = new Header("facilityNum", environment.getProperty(DC_NUMBER));
		Header userId = new Header("WMT-UserId", "autosysadmin");
		logger.info("userId is " + userId);

		List<Header> headerList = new ArrayList<>();
		headerList.add(accept);
		headerList.add(Accept_encode);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		return new Headers(headerList);
	}

	public void completeStartMCBPalletNew(String mcbCompleteStartpayLoad, String completeStarturl, String masterTrackingId) throws IOException, ParseException {
		completeStartMCBPalletNew = RestAssured.given().relaxedHTTPSValidation().log().all().headers(getMcbPallettHeaders())
				.body(mcbCompleteStartpayLoad).with().contentType("application/json")
				.when()
				.post(completeStarturl);
		logger.info("Status code of completeStartMCBPallet API is " + completeStartMCBPalletNew.getStatusCode());
		Assert.assertEquals(ErrorCodes.COMPLETE_MCB_PALLET_FAILED, Constants.NO_CONTENT_STATUS_CODE,
				completeStartMCBPalletNew.getStatusCode());
		setDataIntoTestflowdata(masterTrackingId);
		String testData = (String) threadLocal.get().get(TESTFLOW_DATA);
		logger.info("TestFlowData after updating master tracking Id " + testData);
	}

	public void createMCBPalletforCombinedNew() {
		try {
			createMCBPalletNew = null;
			completeStartMCBPalletNew = null;
			String url = environment.getProperty(CREATE_MCB_PALLET_URL_COMBINED_REGULAR_NEW);
			String completeStarturl = environment.getProperty(CREATE_MCB_PALLET_COMPLETE_START);
			testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> listOfCntrs = testFlowDataJsonParser.read(RECEIVE_INSTRUCTION_CONTAINER_JSON_PATH);
			String cntr = listOfCntrs.get(0);
			List<String> destNbr = testFlowDataJsonParser.read(DEST_NUMBER_JSON_PATH);
			String payload = mcbHelper.mcbCreateNewPayload(cntr, destNbr.get(0));
			logger.info("payload is " + payload + " and the container is " + cntr);
			Failsafe.with(retryPolicy).run(() -> {
				createMCBPalletNew = RestAssured.given().relaxedHTTPSValidation().log().all().headers(getMcbPallettHeaders())
						.body(payload).with().contentType("application/json")
						.when()
						.post(url);
				logger.info("getStatusCode of createMCBPalletNew :: " + createMCBPalletNew.getStatusCode());
				logger.info(" createMCBPalletNew is " + createMCBPalletNew.asString());

				Assert.assertEquals(ErrorCodes.MCB_CREATION_FAILED, Constants.SUCESS_STATUS_CODE,
						createMCBPalletNew.getStatusCode());
			});
			DocumentContext parsedJson = JsonPath.parse(createMCBPalletNew.asString());
			String masterTrackingId = parsedJson.read(MASTER_TRACKING_ID);
			logger.info("masterTrackingId is " + masterTrackingId);
			String mcbCompleteStartpayLoad = mcbHelper.mcbCompleteStartPayload(masterTrackingId);
			Failsafe.with(retryPolicy).run(() -> {
				completeStartMCBPalletNew(mcbCompleteStartpayLoad, completeStarturl, masterTrackingId);
			});
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while completing MCB pallet", e);
		}
	}

	public void completeFinishMCBPalletNew() {
		try {
			completefinishMCBPalletNew = null;
			String completefinishurl = environment.getProperty(CREATE_MCB_PALLET_COMPLETE_FINISH);
			testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> masterTrackingIds = testFlowDataJsonParser.read("$.testFlowData.outboundDetails..mcbContainerID");
			String masterTrackingId = masterTrackingIds.get(0);
			logger.info("parentTrackingId is " + masterTrackingId);
			Failsafe.with(retryPolicy).run(() -> {
				String mcbCompleteFinishpayLoad = mcbHelper.mcbCompleteFinishPayload(masterTrackingId);
				completefinishMCBPalletNew = RestAssured.given().relaxedHTTPSValidation().log().all().headers(getMcbPallettHeaders())
						.body(mcbCompleteFinishpayLoad.toString()).with().contentType("application/json")
						.when()
						.post(completefinishurl);
				logger.info("Response code of complete-finish API is " + completefinishMCBPalletNew.getStatusCode());
				;
				Assert.assertEquals(ErrorCodes.COMPLETE_MCB_PALLET_FAILED, Constants.NO_CONTENT_STATUS_CODE,
						completefinishMCBPalletNew.getStatusCode());
			});

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while completing MCB pallet", e);
		}
	}

	public void createMCBPalletRegularNewFlow(String groupName) {
		try {
			logger.info("Started my things");
			completeStartMCBPalletNew = null;
			int groupId = 1;
			String regularmcbCreateUrl = environment.getProperty(CREATE_MCB_PALLET_URL_COMBINED_REGULAR_NEW);
			testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			DocumentContext testFlowDataJsonParser = JsonPath.parse(testFlowData);
			List<String> listOfCntrs = testFlowDataJsonParser.read(RECEIVE_INSTRUCTION_CONTAINER_JSON_PATH);
			String cntr = listOfCntrs.get(0);
			List<String> destNbr = testFlowDataJsonParser.read(DEST_NUMBER_JSON_PATH);
			//logger.info(" query for getting GroupID :: "+environment.getProperty(GET_REGULAR_MCB_GROUP_ID));
			//List<Map<String, Object>> groupIds = dbUtils.selectFrom(Config.DC, environment.getProperty(GET_REGULAR_MCB_GROUP_ID));
			//logger.info(	groupIds.get(0).get("destination_group_id").toString()+" is the group id");
			logger.info("container is " + cntr + "groupName is " + groupName + " and dest nbr is " + destNbr.get(0));
			String payload = mcbHelper.mcbCreateRegularNewPayload(cntr, String.valueOf(groupId), destNbr.get(0));
			logger.info("payload is " + payload + " and the container is " + cntr);
			testFlowData = String.valueOf(threadLocal.get().get(TESTFLOW_DATA));
			logger.info("scaning first label : {}", cntr);
			scanAPallet = null;
			Failsafe.with(retryPolicy).run(() -> {
				scanAPallet = RestAssured.given().relaxedHTTPSValidation().log().all()
						.headers(getMcbPallettHeaders()).body(payload).with().contentType("application/json")
						.when()
						.post(regularmcbCreateUrl);
				logger.info(scanAPallet.getStatusCode() + "is the status code");
				Assert.assertEquals(ErrorCodes.MCB_SCAN_FAILED, Constants.SUCESS_STATUS_CODE,
						scanAPallet.getStatusCode());

			});
			String completeStarturl = environment.getProperty(CREATE_MCB_PALLET_COMPLETE_START);
			DocumentContext parsedJson = JsonPath.parse(scanAPallet.asString());
			String masterTrackingId = parsedJson.read(MASTER_TRACKING_ID);
			logger.info("masterTrackingId is " + masterTrackingId);
			String mcbCompleteStartpayLoad = mcbHelper.mcbCompleteStartPayload(masterTrackingId);
			logger.info("complete Start API for container started");
			Failsafe.with(retryPolicy).run(() -> {
				completeStartMCBPalletNew(mcbCompleteStartpayLoad, completeStarturl, masterTrackingId);
			});

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating MCB pallet Regular flow", e);
		}
	}
}
