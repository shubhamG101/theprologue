package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.utilities.parsing.PropertyResolver;
import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DockManagementPage extends PageObject {

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	@FindBy(xpath = "//td[@id='Dock Management']")
	private WebElement dockManagementLink;

	@FindBy(xpath = "//*[contains(@href,'retainSearchCriteria.action')]")
	private WebElement dockManagerLink;
	
	@FindBy(xpath = "//strong[contains(text(),'Outbound')]")
	private WebElement outboundLink;
	
	@FindBy(xpath = "//a[contains(text(),'Outbound Trailer Move')]")
	private WebElement outboundTrailerMoveLink;

	public void clickDockManagement() {
		element(dockManagementLink).waitUntilVisible();
		logger.info("Clicking in DockManagementLink Link");
		element(dockManagementLink).click();
	}

	public void clickDockManager() {
		element(dockManagerLink).waitUntilVisible();
		logger.info("Clicking in DockManagerLink Link");
		element(dockManagerLink).click();

	}
	public void clickOutbound() {
		element(outboundLink).waitUntilVisible();
		logger.info("Clicking in outbound Link");
		element(outboundLink).click();
	}
	
	public void clickOutboundTrailerMove() {
		element(outboundTrailerMoveLink).waitUntilVisible();
		logger.info("Clicking in outboundTrailerMove Link");
		element(outboundTrailerMoveLink).click();
	}
}
