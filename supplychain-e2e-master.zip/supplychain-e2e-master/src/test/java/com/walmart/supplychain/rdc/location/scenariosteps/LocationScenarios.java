package com.walmart.supplychain.rdc.location.scenariosteps;

import com.walmart.supplychain.rdc.location.steps.LocationStep;
import com.walmart.supplychain.rdc.oms.steps.RDCOmsStep;
import com.walmart.supplychain.witron.oms.steps.WitronCreatePO;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class LocationScenarios {
	
	@Steps
	LocationStep locationStep;

	@Given("user validates the availability of door in Location")
	public void userValidatesTheAvailabilityOfDoorInLocation() {
		locationStep.validateDoor();
	}


}
