package com.walmart.supplychain.gdc;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;

import com.walmart.supplychain.atlas.receiving.steps.mobile.ReceivingSteps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class GdcScenarios {
	
	@Steps
	GdcSteps gdcSteps;
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	@Given("^user creates gdc problem \"([^\"]*)\"$")
	public void createProblem(String problem) throws JSONException {
		logger.info("GDC problem creation started...");
		gdcSteps.step1(problem);
	}

}
