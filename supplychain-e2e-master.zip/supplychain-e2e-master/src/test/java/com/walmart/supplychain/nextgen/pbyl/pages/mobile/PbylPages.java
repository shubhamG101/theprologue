package com.walmart.supplychain.nextgen.pbyl.pages.mobile;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.pbyl.steps.mobile.PbylHelper;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class PbylPages extends SerenityHelper {

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	JavaUtils javaUtils;

	@Autowired(required = true)
	@Qualifier(value = "pbylHelper")
	PbylHelper pbylHelper;

	Logger logger = LoggerFactory.getLogger(PbylPages.class);
	//private List<String> slotName = new ArrayList<>();

	@FindBy(xpath = "//h1[text()='Order Fulfillment']")
	private WebElement ofPannel;
	
	@FindBy(xpath = "//h3[text()='Trip Paused']")
	private WebElement tripPausedText;
	
	@FindBy(xpath = "//h3[text()='Scan Slot ID']")
	private WebElement scanSlotForShortage;
	
	@FindBy(xpath = "//h3[text()='Scan all remaining labels in hand']")
	private WebElement scanRemainingLabelsForShortage;
	
	@FindBy(xpath = "//span[text()='SCAN COMPLETE']")
	private WebElement completeScan;
	
	@FindBy(xpath = "//span[text()='CONTINUE']")
	private WebElement pauseTripContinueButton;

	@FindBy(xpath = "//div[text()='Printer']")
	private WebElement printerTab;

	@FindBy(xpath = "//input[contains(@id,'EnterPrinternametosearch')]")
	private WebElement searchPrinterTextbox;

	@FindBy(xpath = "//div[div[text()='Online Printers']]//div[2]/span")
	private WebElement onlinePrinterList;

	@FindBy(xpath = "//span[text()='PROCEED']")
	private WebElement proceedButton;

	@FindBy(xpath = "//ul//li//div")
	private List<WebElement> slotcaseDetails;

	@FindBy(xpath = "//span[text()='START TRIP']")
	private WebElement startTrip;

	@FindBy(xpath = "//span[text()='RESUME TRIP']")
	private WebElement resumeTrip;

	@FindBy(xpath = "//span[text()='COMPLETE TRIP']")
	private WebElement completeTrip;

	@FindBy(xpath = "//span[text()='CLOSE CONTAINER']")
	private WebElement closeContainer;

	@FindBy(xpath = "//div[text()='Incorrect barcode scanned']")
	private WebElement incorrectBarCodeSacnned;

	@FindBy(xpath = "//span[text()='OK']")
	private WebElement okButton;

	@FindBy(xpath = "//p[text()=' Cases']")
	private WebElement readCaseValueForSlots;

	@FindBy(xpath = "//button[span[contains(text(),'Continue')]]")
	private WebElement continueButton;

	@FindBy(xpath = "//header[div[div[span[text()='Pallet complete']]]]/div/*[name()='svg']")
	private WebElement receivecloseButton;

	@FindBy(xpath = "//div[@id='printer-settings-loader']/div/div/svg/circle")
	private WebElement pageloader;

	@FindBy(xpath = "//input[contains(@id,'ScanEnterContainerID')]")
	private WebElement scanOrEnterContainerId;

	@FindBy(xpath = "//div[contains(text(),'Scan Induct Label')]")
	private WebElement scanInductLabel;
	
	@FindBy(xpath = "(//button[@type=\"button\"])[2]")
	private WebElement menu;
	
	@FindBy(xpath = "//div[contains(text(),'Pause Trip')]")
	private WebElement pauseTripIcon;
	
	@FindBy(xpath = "//div[contains(text(),'Close container')]")
	private WebElement closeContainerIcon;
	
	@FindBy(xpath = "//div[contains(text(),'Shortage')]")
	private WebElement shortageIcon;
	
	@FindBy(xpath = "//div[contains(text(),'Overage')]")
	private WebElement overageIcon;
	
	@FindBy(xpath = "(//div[contains(text(),'Scan the Slot')])[2]")
	private WebElement scanSlotPopUp;
	
	@FindBy(xpath = "//h3[contains(text(),'Scan Slot ID')]")
	private WebElement scanSlotPopUpForCloseContainerDuringTrip;
	
	@FindBy(xpath = "//h3[contains(text(),'Scan Container ID')]")
	private WebElement scanContainerPopUpForCloseContainerDuringTrip;
	
	@FindBy(xpath = "//span[contains(text(),'SUBMIT')]")
	private WebElement submitOverage;
	
	@FindBy(id = "overage-count")
	private WebElement overageTextField;
	
	
	
	

	String incorrectBarCodeMessage = "//div[text()='Incorrect barcode scanned']";

	private static final String SCAN_COMMAND_START = "document.dispatchEvent(((() => {var scan = new CustomEvent('scanned', {}); scan.value = '";
	private static final String SCAN_COMMAND_END = "'; return scan;})()))";
	private static final String SLOT_XPATH="//p[text()='#0#']";
	public void launchPage(String pbylWebUrl) {
		WebDriver driver = getDriverInstance();
		logger.info("PBYL Web Url:{}",pbylWebUrl);
		driver.get(pbylWebUrl);
		logger.info("Launched the PBYL home page url");
		if(Config.DC!=DC_TYPE.ATLAS){
            element(searchPrinterTextbox).waitUntilClickable();
        }
	}

	public void clickOnPrinterTab() {
		element(printerTab).waitUntilVisible();
		element(printerTab).waitUntilClickable();
		element(printerTab).click();
		element(pageloader).waitUntilNotVisible();

	}

	public void enterPrinter(String printerName) {
		element(searchPrinterTextbox).waitUntilVisible();
		element(searchPrinterTextbox).waitUntilEnabled();
		element(searchPrinterTextbox).type(printerName);

	}

	public void selectOnlinePrinter() {
		element(onlinePrinterList).waitUntilVisible();
		element(onlinePrinterList).waitUntilClickable();
		element(onlinePrinterList).click();

	}

	public void clickOnProceedButton() {
		element(proceedButton).waitUntilVisible();
		element(proceedButton).waitUntilClickable();
		element(proceedButton).click();

	}

	public List<String> scanInductLpn(String inductPallet) {
		element(ofPannel).waitUntilVisible();
		logger.info("Induct Pallet is {}", inductPallet);
		scan(inductPallet);
		
		// This will be used for scanning
		return getSlotDetails();
	}
	public void scan(String scanVal) {
		WebDriver driver=getDriverInstance();
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String command=SCAN_COMMAND_START + scanVal + SCAN_COMMAND_END;
		logger.info("Scanning command :{}",command);
		js.executeScript(command);
		
	}

	private List<String> getSlotDetails() {
		WebDriver driver=getDriverInstance();
		List<String> slotNames=new ArrayList<>();
		element(startTrip).waitUntilVisible();
		List<WebElement> allElements = driver.findElements(By.xpath("//ul//li//div[1]"));
		for (WebElement ele : allElements) {
			logger.info(ele.getText());
			slotNames.add(ele.getText());
		}
		
		logger.info("SlotNames {}",slotNames);
		return slotNames;
	}

	public void startTrip() {
		element(startTrip).waitUntilVisible();
		element(startTrip).waitUntilClickable();
		element(startTrip).click();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			logger.error(e.toString());
			Thread.currentThread().interrupt();
		}
	}

	public void closeContiner() {
		element(closeContainer).waitUntilVisible();
		element(closeContainer).waitUntilClickable();
		element(closeContainer).click();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			logger.error(e.toString());
			Thread.currentThread().interrupt();
		}
	}

	public void scanInductLpnAndResumeTrip(String inductPallet) {
		element(ofPannel).waitUntilVisible();
		logger.info("Induct Pallet is {}", inductPallet);
		scan(inductPallet);
		element(resumeTrip).waitUntilVisible();
		element(resumeTrip).waitUntilClickable();
		element(resumeTrip).click();
	}

	public void clickOncontinueButton() {
		element(continueButton).waitUntilVisible();
		element(continueButton).waitUntilClickable();
		element(continueButton).click();
	}

	public void incorrectBarCodeOkButton() {
		element(okButton).waitUntilVisible();
		element(okButton).waitUntilClickable();
		element(okButton).click();
	}

	public void scanAllSlots(List<String> slotName) {
		WebDriver driver=getDriverInstance();
		String slotDetails;
		for (int slotCount = 0; slotCount < slotName.size(); slotCount++) {
			String xpathForSlot=javaUtils.format(SLOT_XPATH,  slotName.get(slotCount));
			slotDetails = driver.findElement(By.xpath(xpathForSlot)).getText();
			logger.info("Slot Detail:{}",slotDetails);
			Assert.assertEquals(slotDetails, slotName.get(slotCount));
			scan(slotName.get(slotCount));
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				logger.error(e.toString());
				Thread.currentThread().interrupt();
			}
		}
	}

	/*public void pbylCloseContainerBeforeTrip(String inductPallet) {
		String ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
		closeSlots(pbylHelper.getDistinctSlots(ofResponse),"Before Trip");
	}*/

	public Set<String> getDistinctSlotsForInductPallet(String inductPallet) {
		String ofResponse = pbylHelper.ofServiceResponseForLpn(inductPallet);
		return pbylHelper.getDistinctSlots(ofResponse);
	}
	
	public void completeTrip() {

		element(completeTrip).waitUntilVisible();
		element(completeTrip).click();

		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			logger.error(e.toString());
			Thread.currentThread().interrupt();
		}

		element(ofPannel).waitUntilVisible();
	}
	public void pauseTrip(String slotName) {
		click(menu);
		sleep();
		click(pauseTripIcon);
		element(scanSlotPopUp).waitUntilVisible();
		sleep();
		scan(slotName);
		element(tripPausedText).waitUntilVisible();
		click(pauseTripContinueButton);
	}
	public void reportOverage(int overageCount) {
		element(completeTrip).waitUntilVisible();
		click(menu);
		sleep();
		click(overageIcon);
		element(overageTextField).waitUntilVisible();
		sleep();
		element(overageTextField).clear();
		element(overageTextField).sendKeys(""+overageCount);
		click(submitOverage);
		element(ofPannel).waitUntilVisible();
		
	}
	public void reportShortage(List<String> listOfSlots,List<String> childContainerLabels) {
		click(menu);
		sleep();
		click(shortageIcon);
		element(scanSlotForShortage).waitUntilVisible();
		sleep();
		String firstSlot=listOfSlots.get(0);
		scan(firstSlot);
		element(scanRemainingLabelsForShortage).waitUntilVisible();
		sleep(3);
		for(String container:childContainerLabels) {
			sleep(3);
			scan(container);
		}
		click(completeScan);
		element(ofPannel).waitUntilVisible();
		
		
	}
	public void pickShortageCase(String shortageCase,String slotName) {
		WebDriver driver=getDriverInstance();
		element(ofPannel).waitUntilVisible();
		sleep();
		scan(shortageCase);
		String xpathForSlot=javaUtils.format(SLOT_XPATH, slotName);
		driver.findElement(By.xpath(xpathForSlot));
		scan(slotName);
		element(ofPannel).waitUntilVisible();
		
	}


	public boolean isElementVisible(String fieldName) {
		try {
			WebDriver driver=getDriverInstance();
			WebDriverWait wait = new WebDriverWait(driver, 6);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(fieldName)));
			return true;
		} catch (TimeoutException ex) {
			return false;
		}
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);
	}

	
	public void pbylCloseContainerDuringTrip(List<String> slotNames) {
		for(String slotName:slotNames) {
			click(menu);
			sleep();
			click(closeContainerIcon);
			element(scanSlotPopUpForCloseContainerDuringTrip).waitUntilVisible();
			sleep();
			scan(slotName);
			element(scanContainerPopUpForCloseContainerDuringTrip).waitUntilVisible();
			sleep();
			String reUsableContainer="PC"+slotName.substring(slotName.length()-2);
			scan(reUsableContainer);
			sleep(6);
		}
	}

	public void pbylCloseContainerAfterTrip(Set<String> distinctSlots) {
		WebDriver driver=getDriverInstance();
		try {
			Thread.sleep(2000);//wait for 2s before starting the scan
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String reUsableContainer = null;
		List<String> slots = new ArrayList<>();
		for (String slot : distinctSlots) {
			slots.add(slot);
		}
		for (int distinctSlotCount = 0; distinctSlotCount < distinctSlots.size(); distinctSlotCount++) {
			logger.info("Wait for Scan bar");
			element(scanInductLabel).waitUntilVisible();
			logger.info("Scan bar is visible now");
			reUsableContainer="PC"+slots.get(distinctSlotCount).substring(slots.get(distinctSlotCount).length()-2);
			logger.info("reUsableContainer {}", reUsableContainer);
			logger.info(SCAN_COMMAND_START
					+ slots.get(distinctSlotCount) + SCAN_COMMAND_END);
			js.executeScript(SCAN_COMMAND_START
					+ slots.get(distinctSlotCount) + SCAN_COMMAND_END);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					
				}
				element(closeContainer).waitUntilVisible();
				element(closeContainer).waitUntilClickable();
				element(closeContainer).click();
				element(scanOrEnterContainerId).waitUntilVisible();
				element(scanOrEnterContainerId).waitUntilClickable();
				js.executeScript(
						SCAN_COMMAND_START
								+ reUsableContainer + SCAN_COMMAND_END);
				try {
					Thread.sleep(4000);
				} catch (InterruptedException e) {
					logger.error(e.toString());
					Thread.currentThread().interrupt();
				}
				element(ofPannel).waitUntilVisible();
			
		}
	}

}
