package com.walmart.supplychain.nextgen.receiving.steps.mobile;

import static net.serenitybdd.rest.SerenityRest.given;

import java.io.IOException;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ProblemDetail;
import net.serenitybdd.rest.SerenityRest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mongodb.BasicDBObject;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.MongoUtil;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.witronutilities.WitronUtil;
import com.walmart.supplychain.nextgen.damage.steps.webservices.DamageSteps;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventorySteps;
import com.walmart.supplychain.nextgen.receiving.pages.mobile.ReceivingPage;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.webdriver.exceptions.ElementShouldBeVisibleException;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingSteps extends ScenarioSteps {

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	MongoUtil mongoUtil;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	TextParser textParser;

	@Autowired
	Environment environment;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	ReceivingPage ReceivingPage;

	@Autowired
	IDMSteps idmSteps;

	@Autowired
	WitronUtil witronUtils;

	@Steps
	InventorySteps inventoryStep;

	Logger logger = LogManager.getLogger(ReceivingSteps.class);

	private List<Integer> recQtyList = new ArrayList<>();
	private String deliveryNumber;
	private String inboundTrailNum;
	private String inboundDoor;
	private List<String> poNumberList;
	private DocumentContext parsedJson;
	String testFlowData;
	Response response;
	private final String POMATCH = "$.testFlowData.poDetails[?(@.poNumber == '";
	private final String ITMMATCH = "')].poLineDetails[?(@.itemNumber==";
	private static final String TOPIC = "topic";
	private static final String INSTRUCTIONID_JSONPATH = "$.instruction.id";
	private static final String INSTRUCTION_REQUEST_EP = "instruction_request_ep";
	static final String INSTRUCTIONID = "instructionId";
	private static final String PO_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..poNumbers[*]";
	private final String CHANNEL_METHOD = "$.testFlowData.poDetails[?(@.channelMethod == '";
	private final String PO_NUMBER = "')].poNumber";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_POLINES = "$.testFlowData.poDetails[*].poLineDetails[*]";
	private static final String SOURCE_DC_LIST_JSON_PATH = "$.testFlowData.poDetails[*].sourceNumber";
	private static final String LIST_OF_PO_NUMBERS_JSON_PATH = "$.testFlowData.poDetails[?(@.sourceNumber=='#0#')].poNumber";
	private static final String PO_VNPK_QTY_JSON_PATH = "$..testFlowData.poDetails[?(@.poNumber=='#0#')]..poVnpkQty";
	private static final String ITEM_NUMBERS_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails..itemNumber";
	ObjectMapper objectMapper = new ObjectMapper();

	public void readJSON_ThreadLocal() throws IOException, JSONException {
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		logger.info("Testflow data before receiving start : {}", testFlowData);

		parsedJson = JsonPath.parse(testFlowData);
		logger.info("Testflow data before IDM DB update : {}", testFlowData);
		List<String> deliveryNumber_list = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		deliveryNumber = deliveryNumber_list.get(0);
		List<String> inboundDoor_list = parsedJson.read("$.testFlowData.deliveryDetails..inboundDoorNumber");
		inboundDoor = inboundDoor_list.get(0);
//		List<String> inboundTrailNum_list = parsedJson.read("$.testFlowData.deliveryDetails..inboundTrailerNumber");
//		inboundTrailNum = inboundTrailNum_list.get(0);
		poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
		// need vendorPackCost for ovg calculation
	}

	public void readJSON_ThreadLocal_witron() throws IOException, JSONException {

		/* Will delete it later */

//		threadLocal.get().put("testFlowData",
//				"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"070516083\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"555998283\", \"poVnpkQty\": \"64\", \"vnpk\": \"4\", \"whpk\": \"4\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"256\", \"ti\": \"4\", \"hi\": \"16\", \"itemUpc\": \"00259991000005\", \"caseUpc\": \"90027182530470\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 524, \"wac\": 157.94, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"70.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10022\", \"isMergeable\": true, \"weight\": \"10.6\", \"height\": \"4.8\", \"width\": \"19.7\", \"depth\": \"23.8\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"688715\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-11-01\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 10.6, \"totalWeight\": 1388.6, \"averageWeightPerCase\": 10.6, \"croInd\": \"cro\", \"recvQty\": 256, \"osdrInd\": \"o\", \"problemQty\": \"0\", \"problemType\": \"noProblem\", \"recvType\": \"receiving\", \"cube\": 0 }, {\"poLineNumber\": \"2\", \"itemNumber\": \"555998283\", \"poVnpkQty\": \"64\", \"vnpk\": \"4\", \"whpk\": \"4\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"256\", \"ti\": \"4\", \"hi\": \"16\", \"itemUpc\": \"00259991000005\", \"caseUpc\": \"90027182530470\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"70.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10022\", \"isMergeable\": true, \"weight\": \"10.6\", \"height\": \"4.8\", \"width\": \"19.7\", \"depth\": \"23.8\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"688715\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-11-02\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 10.6, \"croInd\": \"cro\", \"recvQty\": 256, \"osdrInd\": \"o\", \"problemQty\": \"0\", \"problemType\": \"noProblem\", \"recvType\": \"receiving\", \"cube\": 0 }, {\"poLineNumber\": \"3\", \"itemNumber\": \"555998299\", \"poVnpkQty\": \"64\", \"vnpk\": \"4\", \"whpk\": \"4\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"256\", \"ti\": \"4\", \"hi\": \"16\", \"itemUpc\": \"00259957000001\", \"caseUpc\": \"90027182530104\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"70.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10022\", \"isMergeable\": true, \"weight\": \"13.6\", \"height\": \"5.0\", \"width\": \"19.8\", \"depth\": \"23.8\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"688780\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-11-03\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 13.6, \"croInd\": \"cro\", \"recvQty\": 256, \"osdrInd\": \"o\", \"problemQty\": \"0\", \"problemType\": \"noProblem\", \"recvType\": \"receiving\", \"cube\": 0 } ], \"uuid\": [\"279dcf56-cc71-421f-a20d-25b9f6c73609\"], \"zonetemperatures\": \"-10.0#0.0#10.0\"} ], \"deliveryDetailsRDC\": [], \"deliveryDetails\": [{\"inboundDoorNumber\": \"119\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T73651119\", \"poNumbers\": [\"070516083\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"shipments\": [], \"deliveryNumber\": \"73651119\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		logger.info("Testflow data before receiving start : {}", testFlowData);

		parsedJson = JsonPath.parse(testFlowData);
		logger.info("Testflow data before IDM DB update : {}", testFlowData);
		List<String> deliveryNumber_list = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		deliveryNumber = deliveryNumber_list.get(0);
		List<String> inboundDoor_list = parsedJson.read("$.testFlowData.deliveryDetails..inboundDoorNumber");
		inboundDoor = inboundDoor_list.get(0);
		List<String> inboundTrailNum_list = parsedJson.read("$.testFlowData.deliveryDetails..inboundTrailerNumber");
		inboundTrailNum = inboundTrailNum_list.get(0);
		poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
		// need vendorPackCost for ovg calculation
	}

	@Step
	public void searchforPrinter() {
		try {
			checkForReceivingHomePage();
			String printerName = environment.getProperty("printer_name");
			ReceivingPage.clickOnReceiveMenu();
			ReceivingPage.clickOnPrinterTab();
			ReceivingPage.enterPrinter(printerName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while trying to select the printer", e);
		}
	}

	@Step
	public void checkForReceivingHomePage() {
		try {
			if (Config.DC == DC_TYPE.WITRON) {
				readJSON_ThreadLocal_witron();

			} else {

				readJSON_ThreadLocal();
			}
			ReceivingPage.checkDoorScanPage();
		} catch (ElementShouldBeVisibleException e) {
			throw new TestCaseFailure(ErrorCodes.RECEIVING_UI_NOT_ACCESSIBLE, e);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while accessing scan door page", e);
		}
	}

	@Step
	public void createAllocations() {
		try {
			if (Config.DC == DC_TYPE.WITRON) {
				readJSON_ThreadLocal_witron();

			} else {

				readJSON_ThreadLocal();
			}
			SecureRandom random = new SecureRandom();
			String num1 = String.format("%04x", random.nextInt(0x10000));
			String num2 = String.format("%04x", random.nextInt(0x10000));
			String num3 = String.format("%04x", random.nextInt(0x10000));
			String num4 = String.format("%04x", random.nextInt(0x10000));
			String payload = textParser.readTextFile(FileNames.CREATE_ALLOCATION);
			List<String> itemNumber_list = parsedJson.read("$..poDetails..itemNumber");
			String itemNumber = itemNumber_list.get(0);
			String poNumber = poNumberList.get(0);
			String createAllocation = javaUtils.format(payload, num1, num2, num3, num4, itemNumber, poNumber);
			logger.info("Create Allocation body :{} ", createAllocation);
			Response responseAllocation = SerenityRest.given().relaxedHTTPSValidation().body(createAllocation)
					.header("facilityCountryCode","US")
					.header("facilityNum",environment.getProperty("dcNumber"))
					.contentType("application/json").post("https://allocation-mcc-stg-int.prod.us.walmart.net/v1/allocationOrders/bulk").then().extract().response();
			Assert.assertEquals(ErrorCodes.FIXIT_CREATE_ALLOCATION_FAILED, Constants.CREATE_SUCESS_STATUS_CODE,
					responseAllocation.getStatusCode());
			logger.info("Create Allocation response : {}", responseAllocation.toString());

		} catch (ElementShouldBeVisibleException e) {
			throw new TestCaseFailure(ErrorCodes.RECEIVING_UI_NOT_ACCESSIBLE, e);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while accessing scan door page", e);
		}
	}

	@Step
	public void performProblemReceiving() {
		ReceivingPage.clickOnReceiveMenu();
		ReceivingPage.clickOnProbrecvBtn();

		String testFlowJSON;
		testFlowJSON = (String) threadLocal.get().get(TEST_FLOW_DATA);
		JSONArray problemContainerArray = JsonPath.read(testFlowJSON, "$..problemDetails..problemContainer");
		String problemContainer = (String) problemContainerArray.get(0);
		JSONArray problemQtyArray = JsonPath.read(testFlowJSON, "$..problemDetails..problemQty");
		String problemQty = (String) problemQtyArray.get(0);
		logger.info(" Problem Container : " + problemContainer);
		ReceivingPage.scanProblemLabel(problemContainer);
		ReceivingPage.clickOnReceiveProbCntr();
		logger.info("Staring receiving for container " + problemContainer);
		ReceivingPage.enterQtyToReceive(problemQty);

		ReceivingPage.clickOnReceiveButton();
		ReceivingPage.clickOnFinishPallet();

	}

	@Step
	public void selectOnlinePrinter() {
		try {
			ReceivingPage.selectOnlinePrinter();
			ReceivingPage.clickOnProceedButton();
			ReceivingPage.clickOnInboundReceiveTab();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while selecting the online printer", e);
		}
	}

	@Step
	public void scanDoor() {
		try {
			logger.info("Door to be scanned : {} ", inboundDoor);

			ReceivingPage.scanDoor(String.valueOf(inboundDoor));
//			if (Config.DC == DC_TYPE.WITRON) {
//				ReceivingPage.proceedWithDelivery();
//			}
			if (ReceivingPage.isDoorAndTrailerValidationPageDisplayed()) {
				logger.info("Receiving App :: Door scan completed for the door :{}", inboundDoor);
			} else if (ReceivingPage.isWrongDoorScanErrorDisplayed()) {
				logger.error("Receiving App :: No delivery found for the door : {}", inboundDoor);
				Assert.fail(ErrorCodes.RECEIVING_NO_DELIVERY_FOUND);
			} else if (ReceivingPage.isdoorAssociatedWithMultiDilivery()) {
				logger.error("Receiving App :: Multiple delivery associated for the door : {}", inboundDoor);
				Assert.fail(ErrorCodes.RECEIVING_MULTIPLE_DELIVERIES_FOUND);
			} else {
				logger.error("Receiving App :: Something went wrong while scaning door : {}", inboundDoor);
				Assert.fail(ErrorCodes.RECEIVING_SOMETHING_WENT_WRONG_SCAN_DOOR);
			}
			String trailerNumOnRecApp = ReceivingPage.getTrailerNumber();
			logger.info("Expected Trailer number:{}", inboundTrailNum);
			logger.info("Actual Trailer number:{}", trailerNumOnRecApp);

			// NEED TO HAVE TRAILER NUMBER

//			Assert.assertEquals(ErrorCodes.RECEIVING_TRAILER_NUM_VALIDATION_FAILED, inboundTrailNum,
//					trailerNumOnRecApp);
			logger.info("Receiving App :: Validated Trailer number : " + trailerNumOnRecApp);
			ReceivingPage.trailerDetails_clickOncontinueButton();
			Thread.sleep(1000);
			if (Config.DC == DC_TYPE.ACC && ReceivingPage.isDoorIsOffline()) {
				logger.info("Receiving App :: Door scan completed for the door :{}", inboundDoor);
				ReceivingPage.clickOn_ConfirmationOkButton();
				Thread.sleep(1000);
			}

			String deliveryNumInRecApp = ReceivingPage.getDeliveryNumber();
			logger.info("Expected Delivery number:{}", deliveryNumber);
			logger.info("Actual Delivery number:{}", deliveryNumInRecApp);
			Assert.assertEquals(ErrorCodes.RECEIVING_DELIVERY_NUM_VALIDATION_FAILED, deliveryNumber,
					deliveryNumInRecApp);
			logger.info("Receiving App :: Validated Delivery number: " + deliveryNumInRecApp);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	@Step
	public void poConfirm() {
		try {
			logger.info("Strting PO confirmation");
			ReceivingPage.clickReviewAndPOConfirmButton();

//			String poConfirmDetail = ReceivingPage.clickPOConfirmButton();

			ReceivingPage.recordTrailerTemp();
			ReceivingPage.clickReviewAndPOConfirmButton();

			boolean flag = ReceivingPage.confirmPO();

			Assert.assertTrue(ErrorCodes.WITRON_RECEIVING_PO_CONFIRM_FAILED, flag);

			ReceivingPage.closePoConfirm();
			ReceivingPage.closeDiver();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	@Step
	public void rejectTheQty() {
		try {
//			
//			threadLocal.get().put("testFlowData",
//					"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"034144073\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 200, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"200\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"16.4\", \"ovgQty\": \"20\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.325\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-08\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"10\", \"shortQty\": \"60\", \"rejectQty\": \"30\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 100, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"3\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"200\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"20\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.0\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-02-03\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"200\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"notBOL\", \"recvQty\": 0, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"4\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"200\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.0\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-02-04\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"20\", \"shortQty\": \"80\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 100, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"5\", \"itemNumber\": \"552969717\", \"poVnpkQty\": \"200\", \"vnpk\": \"5\", \"whpk\": \"5\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"20\", \"ti\": \"5\", \"hi\": \"7\", \"itemUpc\": \"00201573000002\", \"caseUpc\": \"90076338332055\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10022\", \"isMergeable\": true, \"weight\": \"60.0\", \"height\": \"9.2\", \"width\": \"15.9\", \"depth\": \"23.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-02-05\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"200\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"croReject\", \"recvQty\": 0, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"6\", \"itemNumber\": \"552969717\", \"poVnpkQty\": \"200\", \"vnpk\": \"5\", \"whpk\": \"5\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"5\", \"hi\": \"7\", \"itemUpc\": \"00201573000002\", \"caseUpc\": \"90076338332055\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10022\", \"isMergeable\": true, \"weight\": \"60.0\", \"height\": \"9.2\", \"width\": \"15.9\", \"depth\": \"23.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-02-06\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"200\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 0, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"7\", \"itemNumber\": \"552571048\", \"poVnpkQty\": \"200\", \"vnpk\": \"1\", \"whpk\": \"1\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"20\", \"ti\": \"10\", \"hi\": \"9\", \"itemUpc\": \"00070800030118\", \"caseUpc\": \"00070800030118\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10018\", \"isMergeable\": true, \"weight\": \"16.0\", \"height\": \"5.8\", \"width\": \"10.6\", \"depth\": \"15.0\", \"wareHouseGroupCode\": \"DD\", \"wareHouseAreaCode\": \"2\", \"samePalletIndicator\": \"1\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2021-02-07\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"10\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 210, \"osdrInd\": \"o\"}, {\"poLineNumber\": \"8\", \"itemNumber\": \"552571048\", \"poVnpkQty\": \"100\", \"vnpk\": \"1\", \"whpk\": \"1\", \"whpkSellPrice\": \"18.9\", \"ovgQty\": \"10\", \"ti\": \"10\", \"hi\": \"9\", \"itemUpc\": \"00070800030118\", \"caseUpc\": \"00070800030118\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10018\", \"isMergeable\": true, \"weight\": \"16.0\", \"height\": \"5.8\", \"width\": \"10.6\", \"depth\": \"15.0\", \"wareHouseGroupCode\": \"DD\", \"wareHouseAreaCode\": \"2\", \"samePalletIndicator\": \"1\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2021-02-08\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"50\", \"rejectQty\": \"50\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 0, \"croInd\": \"cro\", \"recvQty\": 0, \"osdrInd\": \"s\"} ], \"uuid\": [\"f242f3f4-f8d0-48fc-b1de-e4546b0c907b\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"117\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T56716970\", \"poNumbers\": [\"034144073\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"56716970\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before receiving start : {}", testFlowData);

			String rejectQty;
			ReceivingPage.clickReviewAndPOConfirmButton();
			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					logger.info("Po Number{} " + poLineNumber);
					List<String> rejectQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].rejectQty");
					rejectQty = rejectQtyList.get(0).toString();

					if (Integer.parseInt(rejectQty) == 0) {
						logger.info("po line with reject qty : {} {}", poLineNumber, Integer.parseInt(rejectQty));

						continue;
					}
					ReceivingPage.rejectQty(rejectQty, poLineNumber);
				}
			}

//			logger.info("Complete value for short,damage ,reject : {}", shortRejectDamageValue);
//			allValues = validateShortRejectDamage(shortRejectDamageValue);
//			ReceivingPage.clickPOConfirmButton();
//			ReceivingPage.closePoConfirm();
//			ReceivingPage.closeDiver();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	@Step
	public void rejectTheQtyExceptionAtPoConfirm() {
		try {
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before Pallet rejection flow start : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			String rejectQty;
			ReceivingPage.clickReviewAndPOConfirmButton();
			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					logger.info("Po Number{} " + poLineNumber);
					List<String> rejectQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].rejectQty");
					rejectQty = rejectQtyList.get(0).toString();

					if (Integer.parseInt(rejectQty) == 0) {
						logger.info("po line with reject qty : {} {}", poLineNumber, Integer.parseInt(rejectQty));

						continue;
					}
					ReceivingPage.rejectQtyExceptionFlow(rejectQty, poLineNumber);
				}
			}
//			ReceivingPage.clickOnCloseButtonWitron();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	@Step
	public List<String> validateShortRejectDamage(String value) {
		try {

			boolean damageFlag = false;
//			String value="PO 013131520 173 Received FB Qty O 0 S 0 D 0 R 0 PF 0 Add Rejection Confirm PO";
			List<String> allValues = new ArrayList<String>();
			logger.info("Strting PO confirmation");
			int indexShort = value.indexOf("S", 1);
			int indexDamage = value.indexOf("D", 1);
			int indexReject = value.indexOf("O", 1);

			// String fbqVal = value.substring(24, 27);
			String shortVal = value.substring(indexShort + 1, indexShort + 4);
			String damageVal = value.substring(indexDamage + 1, indexDamage + 3);
			String rejectVal = value.substring(indexDamage + 5, indexDamage + 7);
			logger.info("Validate Short Val : {} Damage Val : {} Reject Val : {} ", shortVal, damageVal, rejectVal);
			allValues.add(shortVal);
			allValues.add(damageVal);
			allValues.add(rejectVal);
			// allValues.add(fbqVal);
			logger.info("damage value {} {} ", damageVal.trim(), String.valueOf(damageVal).trim().contains("0"));

			if (String.valueOf(damageVal).trim().contains("0")) {
				damageFlag = true;
			}
			textParser = new TextParser();

			String testData = String.valueOf(threadLocal.get().get("testFlowData"));

			JSONObject obj = new JSONObject();

			JSONArray poList = JsonPath.read(testData, "$.testFlowData.poDetails[*].poNumber");

			JSONArray referenceNumberList = JsonPath.read(testData,
					"$.testFlowData.poDetails[*].poLineDetails[*].poLineNumber");

			ObjectMapper objectMapper = new ObjectMapper();
			net.minidev.json.JSONArray listOfPoLineDetail = JsonPath.read(testData,
					"$.testFlowData.poDetails[?(@.poNumber == '" + poList.get(0).toString() + "')].poLineDetails[*]");
			String poLineDetailsJson = objectMapper.writeValueAsString(listOfPoLineDetail);
			List<PoLineDetail> poLineDetailList = (List<PoLineDetail>) jsonUtil.getPojoListfromPath(poLineDetailsJson,
					PoLineDetail.class);
			for (PoLineDetail poLineDetail : poLineDetailList) {
				if (damageFlag) {
					poLineDetail.setDamageQty((String.valueOf(damageVal)).trim());
				}
				poLineDetail.setRejectQty(String.valueOf(rejectVal).trim());
				poLineDetail.setShortQty((String.valueOf(shortVal)).trim());

			}

			net.minidev.json.JSONArray listofPoLineJson = jsonUtil.converyListToJsonArray(poLineDetailList);
			testData = jsonUtil.setJsonAtJsonPath(testData, listofPoLineJson,
					"$.testFlowData.poDetails[?(@.poNumber == '" + poList.get(0) + "')].poLineDetails");
			threadLocal.get().put("testFlowData", testData);
			logger.info("TestFlowJson updated with Short,Damage and Reject qty : {} ",
					threadLocal.get().get("testFlowData"));

			return allValues;

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	@Step
	public void scanDoorWitron() {
		try {
			logger.info("Door to be scanned : {} ", inboundDoor);

			ReceivingPage.scanDoor(String.valueOf(inboundDoor));
			if (ReceivingPage.isDoorAndTrailerValidationPageDisplayed()) {
				logger.info("Receiving App :: Door scan completed for the door :{}", inboundDoor);
			} else if (ReceivingPage.isWrongDoorScanErrorDisplayed()) {
				logger.error("Receiving App :: No delivery found for the door : {}", inboundDoor);
				Assert.fail(ErrorCodes.RECEIVING_NO_DELIVERY_FOUND);
			} else if (ReceivingPage.isdoorAssociatedWithMultiDilivery()) {
				logger.error("Receiving App :: Multiple delivery associated for the door : {}", inboundDoor);
				Assert.fail(ErrorCodes.RECEIVING_MULTIPLE_DELIVERIES_FOUND);
			} else {
				logger.error("Receiving App :: Something went wrong while scaning door : {}", inboundDoor);
				Assert.fail(ErrorCodes.RECEIVING_SOMETHING_WENT_WRONG_SCAN_DOOR);
			}
			String trailerNumOnRecApp = ReceivingPage.getTrailerNumber();
			logger.info("Expected Trailer number:{}", inboundTrailNum);
			logger.info("Actual Trailer number:{}", trailerNumOnRecApp);

			// Receiving needs to fix it////
//			Assert.assertEquals(ErrorCodes.RECEIVING_TRAILER_NUM_VALIDATION_FAILED, inboundTrailNum,
//					trailerNumOnRecApp);
//			logger.info("Receiving App :: Validated Trailer number : " + trailerNumOnRecApp);
			ReceivingPage.trailerDetails_clickOncontinueButton();
			Thread.sleep(1000);
			String deliveryNumInRecApp = ReceivingPage.getDeliveryNumber();
			logger.info("Expected Delivery number:{}", deliveryNumber);
			logger.info("Actual Delivery number:{}", deliveryNumInRecApp);
			Assert.assertEquals(ErrorCodes.RECEIVING_DELIVERY_NUM_VALIDATION_FAILED, deliveryNumber,
					deliveryNumInRecApp);
			logger.info("Receiving App :: Validated Delivery number: " + deliveryNumInRecApp);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning the door", e);
		}
	}

	@Step
	public void updateInboundDB() {
		try {
			if (Config.DC != DC_TYPE.ATLAS && Config.DC != DC_TYPE.MCC) {
				Bson updateQuery_CrossU = new Document().append("deliveryDocuments.$.poDCNumber", "32899")
						.append("deliveryDocuments.$.purchaseReferenceLegacyType", "33")
						.append("deliveryDocuments.$.legacyType", "AUTO");
				Bson updateQuery_SSTKU = new Document().append("deliveryDocuments.$.poDCNumber", "32899")
						.append("deliveryDocuments.$.purchaseReferenceLegacyType", "20")
						.append("deliveryDocuments.$.legacyType", "AUTO");
				Bson updateQuery_CROSSMU = new Document().append("deliveryDocuments.$.poDCNumber", "32899")
						.append("deliveryDocuments.$.purchaseReferenceLegacyType", "03")
						.append("deliveryDocuments.$.legacyType", "AUTO");
				for (String poNumber : poNumberList) {
					Thread.sleep(2000);
					logger.info(
							"Receiving App :: PO_DC and Legacy PO details Updated in Inbound DB for PO: " + poNumber);
					Bson whereQuery = new Document().append("_id", deliveryNumber)
							.append("deliveryDocuments.documentNbr", poNumber);
					List<String> channelType_list = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails..channelMethod");
					if (channelType_list.get(0).equalsIgnoreCase("CROSSU")) {
						mongoUtil.setDatatoDB("inbound_document", "delivery", whereQuery, updateQuery_CrossU);
						logger.info("Receiving App :: PO_DC and Legacy PO details Updated in Inbound DB for CROSSU PO: "
								+ poNumber);
					} else if (channelType_list.get(0).equalsIgnoreCase("SSTK")) {
						mongoUtil.setDatatoDB("inbound_document", "delivery", whereQuery, updateQuery_SSTKU);
						logger.info("Receiving App :: PO_DC and Legacy PO details Updated in Inbound DB for SSTKU PO: "
								+ poNumber);
					} else if (channelType_list.get(0).equalsIgnoreCase("CROSSMU")) {
						mongoUtil.setDatatoDB("inbound_document", "delivery", whereQuery, updateQuery_CROSSMU);
						logger.info(
								"Receiving App :: PO_DC and Legacy PO details Updated in Inbound DB for CROSSMU PO: "
										+ poNumber);
					}
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while updating the inbound DB", e);
		}
	}

	@Step
	public void startReceiving(String receiveType) {
		try {
//			if (Config.DC != DC_TYPE.ATLAS || Config.DC != DC_TYPE.ACC) {
//				searchforPrinter();
//				selectOnlinePrinter();
//				scanDoor();
//			}

			Set<String> uniqueItems;
			boolean noMoreReceiving = false;
			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Receiving App :: Started receiving for PO:{} and for item:{}", poNumber, itemNum);
					List<String> detail = returnUpcOpenQty(poNumber, itemNum);
					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(detail.get(1));
					String itemUPC = detail.get(0);
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					ReceivingPage.scanUPC(itemUPC);
					/*
					 * if (ReceivingPage.isHazmatErrorMsgDisplayed()) {//Add hazmat condition to
					 * avoid this check for non hazmat item
					 * ReceivingPage.clickOn_ConfirmationYesButton(); }
					 */
					if (receiveType.equalsIgnoreCase("partial")) {
						partialReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
					} else if (receiveType.equalsIgnoreCase("single pallet")) {
						firstPalletReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
						noMoreReceiving = true;
					} else if (receiveType.equalsIgnoreCase("first pallet")) {
						firstPalletReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
					} else if (receiveType.equalsIgnoreCase("multiple pallet")) {
						fullReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty, true);
					} else {
						fullReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
					}
					if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.ACC) {
						String containerResponse;
						containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
						logger.info("ContainerResponse for the given delivery::{}", containerResponse);
						receivingHelper.setReceivingInstruction(containerResponse, poNumber, itemNum);
					} else {
						receivingHelper.getDatafromDB_Rec("receive_container", "containers", deliveryNumber, poNumber,
								Integer.valueOf(itemNum));
					}
					logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
					if (noMoreReceiving) {
						break;
					}
				}
				if (noMoreReceiving) {
					break;
				}
			}
			ReceivingPage.closeDiver();
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void startReceivingLithiumOrLmitedQtyItem(String receiveType) {
		try {
//			if (Config.DC != DC_TYPE.ATLAS || Config.DC != DC_TYPE.ACC) {
//				searchforPrinter();
//				selectOnlinePrinter();
//				scanDoor();
//			}

			Set<String> uniqueItems;
			boolean noMoreReceiving = false;
			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Receiving App :: Started receiving for PO:{} and for item:{}", poNumber, itemNum);
					List<String> detail = returnUpcOpenQty(poNumber, itemNum);
					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(detail.get(1));
					String itemUPC = detail.get(0);
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					/*
					 * if (ReceivingPage.isHazmatErrorMsgDisplayed()) {//Add hazmat condition to
					 * avoid this check for non hazmat item
					 * ReceivingPage.clickOn_ConfirmationYesButton(); }
					 */
					if (receiveType.equalsIgnoreCase("partial")) {
						partialReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
					} else if (receiveType.equalsIgnoreCase("single pallet")) {
						firstPalletReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
						noMoreReceiving = true;
					} else if (receiveType.equalsIgnoreCase("first pallet")) {
						firstPalletReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
					} else if (receiveType.equalsIgnoreCase("multiple pallet")) {
						fullReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty, true);
					} else {
						fullReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);
					}
					if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.ACC) {
						String containerResponse;
						containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
						logger.info("ContainerResponse for the given delivery::{}", containerResponse);
						receivingHelper.setReceivingInstruction(containerResponse, poNumber, itemNum);
					} else {
						receivingHelper.getDatafromDB_Rec("receive_container", "containers", deliveryNumber, poNumber,
								Integer.valueOf(itemNum));
					}
					logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
					if (noMoreReceiving) {
						break;
					}
				}
				if (noMoreReceiving) {
					break;
				}
			}
			ReceivingPage.closeDiver();
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving Lithium Or LmitedQty items", e);
		}
	}

	@Step
	public void startReceivingOverage() {
		try {
			if (Config.DC == DC_TYPE.ATLAS) {
				checkForReceivingHomePage();
			} else {
				searchforPrinter();
				selectOnlinePrinter();
			}
			scanDoor();
			Set<String> uniqueItems;
			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Receiving App :: Started receiving for PO:{} and for item:{}", poNumber, itemNum);
					List<String> detail = returnUpcOpenQty(poNumber, itemNum);
					List<String> ovgQty = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].ovgQty");
					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(ovgQty.get(0));
					String itemUPC = detail.get(0);
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					ReceivingPage.scanUPC(itemUPC);
					fullReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty);

					if (Config.DC == DC_TYPE.ATLAS) {
						String containerResponse;
						containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
						logger.info("ContainerResponse for the given delivery::{}", containerResponse);
						receivingHelper.setReceivingInstruction(containerResponse, poNumber, itemNum);
					} else {
						receivingHelper.getDatafromDB_Rec("receive_container", "containers",

								deliveryNumber, poNumber, Integer.valueOf(itemNum));
					}
					logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
				}
			}
			ReceivingPage.closeDiver();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving overage", e);
		}
	}

	@Step
	public void deliveryComplete() {
		try {
			ReceivingPage.clickOnCompleteDeliveryButton();

			if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.SAMS || Config.DC == DC_TYPE.WITRON) {
				ReceivingPage.clickOnCompleteDeliveryPopup_ContinueButton();
			} else {
				ReceivingPage.clickOnCompleteDeliveryPopup_Confirm();
			}
			Object completeDelievrySucessMssg = ReceivingPage.getDeliveryCompleteSuccessMssg();
			Assert.assertEquals(ErrorCodes.RECEIVING_FINALIZE_DELIVERY_FAILED, "Great Job!",
					completeDelievrySucessMssg);
			ReceivingPage.closeDiver();
			logger.info("Receiving App :: Delivery :{} completed successfully", deliveryNumber);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Finalizing the delivery", e);
		}
	}

	public void partialReceiving(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty) {
		boolean receiveCompleteFlag = false;
		if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
			do {
				if (itemOnPoList.size() > 1) {
					ReceivingPage.selectPOfromRadioButton(poNumber);
					ReceivingPage.clickOn_itemOnMutiplePO_ContinueButton();
				}
				int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
				if (qtyToReceive == maxReceiveQty || (qtyToReceive + 1) == maxReceiveQty) {
					qtyToReceive = qtyToReceive - 1;
					receiveCompletion(qtyToReceive);
					recQtyList.add(qtyToReceive);
					receiveCompleteFlag = true;
					break;
				}
				ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
				ReceivingPage.clickOnReceiveButton();
				recQtyList.add(qtyToReceive);
				ReceivingPage.clickOnCloseButton();
				maxReceiveQty = maxReceiveQty - qtyToReceive;
				ReceivingPage.scanUPC(itemUPC);
			} while (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed());
		}
		if (!receiveCompleteFlag && !ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
			errorScenarios(itemUPC);
		}
	}

	public void firstPalletReceiving(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty) {
		selectPO(itemOnPoList, poNumber);
		if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {

			int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
			logger.info("Quantity to receive :{}", qtyToReceive);
			logger.info("Max Receive Qty:{}", maxReceiveQty);
			if (qtyToReceive > maxReceiveQty) {
				qtyToReceive = maxReceiveQty;
				receiveCompletion(qtyToReceive);
			} else {
				ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
				ReceivingPage.clickOnReceiveButton();
			}
			recQtyList.add(qtyToReceive);
			ReceivingPage.clickOnCloseButton();
		} else {
			errorScenarios(itemUPC);
		}
	}

	public int getChunkSize(String poNumber, String itemUPC, int qtyToReceive) {
		ObjectMapper objectMapper = new ObjectMapper();
		String defaultChunkVal = environment.getProperty("pallet_chunk_size");
		boolean useTiAsChunkSize = Boolean.parseBoolean(environment.getProperty("use_ti_as_chunk_size"));
		int chunk = 1;// this value will be overwritten below
		JSONArray listOfPOLines = JsonPath.read(testFlowData,
				"$..poDetails[?(@.poNumber==\"" + poNumber + "\")].poLineDetails[?(@.itemUpc==\"" + itemUPC + "\")]");
		try {
			PoLineDetail poLineDetail = (PoLineDetail) jsonUtil.getPojofromJsonObject(listOfPOLines.get(0),
					PoLineDetail.class);
			logger.info("Pallet Ti:{}", poLineDetail.getTi());
			String chunkVal = (!useTiAsChunkSize || poLineDetail.getTi() == null || poLineDetail.getTi().equals("null"))
					? defaultChunkVal
					: poLineDetail.getTi();
			chunk = Integer.parseInt(chunkVal);

		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			logger.error(e);
			logger.info("Default PBYL Pallet chunk:{}", defaultChunkVal);
			chunk = Integer.parseInt(defaultChunkVal);
		}
		if (qtyToReceive < chunk) {
			chunk = qtyToReceive;
		}
		return chunk;
	}

	public void fullReceiving(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty) {
		fullReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false);
	}

	public void fullReceiving(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty,
			boolean isMultipleChunks) {
		boolean receiveCompleteFlag = false;
		boolean waitForAllocation = false;
		selectPO(itemOnPoList, poNumber);
		if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
			do {
				int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
				logger.info("Max Receive Qty:{}", maxReceiveQty);
				logger.info("Quantity to receive :{}", qtyToReceive);
				int chunkSize = 1;
				if (isMultipleChunks) {
					chunkSize = getChunkSize(poNumber, itemUPC, qtyToReceive);
					logger.info("chunk size :{}", chunkSize);
				}
				if (isMultipleChunks && chunkSize < qtyToReceive) {
					qtyToReceive = chunkSize;
					receiveCompletion(qtyToReceive);
				} else if (qtyToReceive > maxReceiveQty) {
					qtyToReceive = maxReceiveQty;
					receiveCompletion(qtyToReceive);
				} else {
					ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
					ReceivingPage.clickOnReceiveButton();

					testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
					List<String> poType = JsonPath.read(testFlowData,
							"$..poDetails[?(@.poNumber=='" + poNumber + "')].channelMethod");
					if (poType.get(0).equalsIgnoreCase("POCON")) {
						ReceivingPage.clickOnFinshPalletButton();
						ReceivingPage.clickOnFinshPalletPopupButton();
					}
				}
				maxReceiveQty = maxReceiveQty - qtyToReceive;
				recQtyList.add(qtyToReceive);
				logger.info("Max Receive Qty after receiving:{}", maxReceiveQty);
				if (maxReceiveQty == 0) {
					ReceivingPage.clickOnCloseButton();
					receiveCompleteFlag = true;
					logger.info("exiting the scan upc loop");
					break;
				}
				ReceivingPage.clickOnCloseButton();
				if (isMultipleChunks) {
					logger.info("Waiting for 5Sec before scanning upc again");
					ReceivingPage.sleep(5);
				}
				ReceivingPage.scanUPC(itemUPC);
				selectPO(itemOnPoList, poNumber);
				if (!ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()
						&& ReceivingPage.isNoAllocationErrorMssgDisplayed()) {
					ReceivingPage.clickOn_ConfirmationOkButton();
					logger.info("Getting No Allocation..Looks like OF is little slow..re-trying");
					ReceivingPage.scanUPC(itemUPC);
					selectPO(itemOnPoList, poNumber);
				}
			} while (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed());
		}
		if (!receiveCompleteFlag && !ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
			errorScenarios(itemUPC);
		}
	}

	public void selectPO(List<String> itemOnPoList, String poNumber) {
		if (itemOnPoList.size() > 1) {
			if (ReceivingPage.isitemFoundOnMultiplePO()) {
				ReceivingPage.selectPOfromRadioButton(poNumber);
				ReceivingPage.clickOn_itemOnMutiplePO_ContinueButton();
			} else if (ReceivingPage.isiMultipleDeliveryDocumentLinesFound()) {
				ReceivingPage.selectPOLinefromRadioButton(poNumber);
				ReceivingPage.clickOn_multiple_Delivery_DocumentLines_ContinueButton();
			}
		}
	}

	public void errorScenarios(String itemUPC) {
		if (ReceivingPage.isNoAllocationErrorMssgDisplayed()) {
			logger.info("No Allocation for Item UPC {}", itemUPC);
			Assert.fail(ErrorCodes.RECEIVING_NO_ALLOCATION);
		} else if (ReceivingPage.isNoItemFoundErrorMssgDisplayed()) {
			logger.info("No item found for the scanned UPC {}", itemUPC);
			Assert.fail(ErrorCodes.RECEIVING_ITEM_NOT_FOUND);
		} else {
			logger.info("Something went wrong while scaning UPC {}", itemUPC);
			Assert.fail(ErrorCodes.RECEIVING_SOMETHING_WENT_WRONG_SCAN_UPC);
		}
	}

	public void receiveCompletion(int qtyToReceive) {
		ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
		ReceivingPage.clickOnReceiveButton();
		ReceivingPage.clickOnFinshPalletButton();
		ReceivingPage.clickOnFinshPalletPopupButton();
	}

	public List<String> returnUpcOpenQty(String poNumber, String itemNum) {
		List<String> arr = new LinkedList<>();
		List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
		List<String> openQty = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].poVnpkQty");
		arr.add(upc.get(0));
		arr.add(openQty.get(0));
		return arr;
	}

	public List<String> returnUpcOpenQtyForWitron(String poNumber, String poLineNumber, String itemNum) {
		List<String> arr = new LinkedList<>();
		List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
		List<String> openQty = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
				+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].poVnpkQty");
		arr.add(upc.get(0));
		arr.add(openQty.get(0));
		return arr;
	}

	@Step
	public void reReceiveVTRContainer() {
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		try {
			List<String> vtredContainerList = parsedJson
					.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.isVTR==true)].vtrContainer");
			for (String container : vtredContainerList) {
				int reReceiveQty = 0;
				// List<String> channelTypeList =
				// parsedJson.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.vtrContainer=='"+container+"')].channelType");
				String vtredPoNumber = getVTRedPONumber(container);
				int vtredPoLineNum = getVTRedPOLine(vtredPoNumber, container);
				List<String> itemUPCList = parsedJson.read("$.testFlowData..poDetails[?(@.poNumber=='" + vtredPoNumber
						+ "')].poLineDetails[?(@.poLineNumber ==" + vtredPoLineNum + ")].itemUpc");
				String itemUPC = itemUPCList.get(0);
				List<String> itemOnPoList = parsedJson.read("$.testFlowData..poDetails[?(@.poNumber=='" + vtredPoNumber
						+ "')].poLineDetails[?(@.poLineNumber ==" + vtredPoLineNum + ")].itemNumber");
				String itemNumber = itemOnPoList.get(0);
				List<String> rcvdContainerInstForVTRedCont = parsedJson
						.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.vtrContainer=='" + container
								+ "')]");
				List<String> rcvdParentContainerList = parsedJson
						.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.vtrContainer=='" + container
								+ "')].parentContainer");
				List<Integer> reReceiveQtyList = parsedJson
						.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.vtrContainer=='" + container
								+ "')].vtrQty");
				reReceiveQty = reReceiveQtyList.get(0);
				JSONArray chennalType = parsedJson
						.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.vtrContainer=='" + container
								+ "')].channelType");
				String channel = String.valueOf(chennalType.get(0).toString());
				logger.info("Receiving Channel Method == " + channel);
				ReceivingPage.scanUPC(itemUPC);
				reReceiveForVTR(reReceiveQty, itemNumber, vtredPoNumber);
				if (Config.DC == DC_TYPE.ATLAS) {

					receivingHelper.updateReReceivingInstructionPostVTR(vtredPoNumber, Integer.valueOf(itemNumber),
							channel);
				} else {

					receivingHelper.getDatafromDB_Rec_ForVTR("receive_container", "containers", deliveryNumber,
							vtredPoNumber, Integer.valueOf(itemNumber), rcvdParentContainerList,
							rcvdContainerInstForVTRedCont);
				}
			}
			logger.info("Receiving App :: Completed re-reiving of VTRed container");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while re-receiving VTR container", e);
		}
	}

	@Step
	public void checkContainerStatusAfterVTR(String containerStatus) {
		Response response;
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		List<String> vtredContainerList = parsedJson
				.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.isVTR==true)].vtrContainer");
		try {

			if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.WITRON) {
				deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
				String delNumber = deliveryNumberList.get(0);
				vtredContainerList = parsedJson
						.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.isVTR==true)].vtrContainer");
				response = given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders()).when()
						.get(environment.getProperty("receiving_container_url") + delNumber);
				logger.info("Receiving URL = " + environment.getProperty("receiving_container_url") + delNumber);

				parsedJson = JsonPath.parse(response.asString());
				for (String vtrContainer : vtredContainerList) {
					JSONArray statusList = parsedJson
							.read("$..[?(@.trackingId=='" + vtrContainer + "')].containerStatus");
					Assert.assertEquals(ErrorCodes.RECEIVING_VTR_STATUS_MISMATCH, containerStatus, statusList.get(0));
					logger.info("VTR status in receiving {} ", statusList.get(0));

				}
			} else {

				for (String container : vtredContainerList) {
					BasicDBObject containerSearchQuery = new BasicDBObject();
					containerSearchQuery.put("trackingId", container);
					List<String> containerStatusList = null;
					containerStatusList = mongoUtil.getDatafromDB("receive_container", "containers",
							containerSearchQuery, "containerStatus");
					Assert.assertEquals(ErrorCodes.RECEIVING_VTR_STATUS_MISMATCH, containerStatus,
							containerStatusList.get(0));
				}
				logger.info("Receiving App :: Validated satus check for the VTRed Container");
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status after VTR", e);
		}
	}

	@Step
	public void verifyContainerStatusAndQtyForVTR(String vtrContainer, String poLineNumber, String rcvQty) {
		Response response;
		String vtrContrStatus = "backout";
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		try {

			String delNumber = deliveryNumberList.get(0);
			response = given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders()).when()
					.get(environment.getProperty("receiving_container_url") + delNumber);
			logger.info("Receiving URL = " + environment.getProperty("receiving_container_url") + delNumber);

			parsedJson = JsonPath.parse(response.asString());
			JSONArray statusList = parsedJson.read("$..[?(@.trackingId=='" + vtrContainer + "')].containerStatus");
			Assert.assertEquals(ErrorCodes.RECEIVING_VTR_STATUS_MISMATCH, vtrContrStatus, statusList.get(0));
			logger.info("VTR status in receiving {} ", statusList.get(0));

			logger.info("Receiving App :: Validated status check for the VTRed Container");

			checkForReceivingHomePage();
			scanDoor();
			ReceivingPage.validateVtredQty(poLineNumber, rcvQty);
			ReceivingPage.closeWitronDiver();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status after VTR", e);
		}
	}

	@Step
	public void checkContainerStatusAfterVTRFromPalletCorrection(String containerStatus) {
		Response response;
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		List<String> vtredContainerList = parsedJson
				.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.isVTR==true)].vtrContainer");
		try {

			if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.WITRON) {
				deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
				String delNumber = deliveryNumberList.get(0);
				vtredContainerList = parsedJson.read(
						"$.testFlowData..poLineDetails..receivingInstructions.[?(@.isVTR==true&&@.vtrQty==0)].vtrContainer");
				response = given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders()).when()
						.get(environment.getProperty("receiving_container_url") + delNumber);
				logger.info("Receiving URL = " + environment.getProperty("receiving_container_url") + delNumber);

				parsedJson = JsonPath.parse(response.asString());
				for (String vtrContainer : vtredContainerList) {
					JSONArray statusList = parsedJson
							.read("$..[?(@.trackingId=='" + vtrContainer + "')].containerStatus");
					Assert.assertEquals(ErrorCodes.RECEIVING_VTR_STATUS_MISMATCH, containerStatus, statusList.get(0));
					logger.info("VTR status in receiving {} ", statusList.get(0));

				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating container status after VTR", e);
		}
	}

	@Step
	public void validateNegativeEntry() {
		int totalreceivedQtyOnPOLineDB = 0;
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
		List<String> vtredContainerList = parsedJson
				.read("$.testFlowData..poLineDetails..receivingInstructions.[?(@.isVTR==true)].vtrContainer");

		try {

			for (String container : vtredContainerList) {
				String vtredPoNumber = getVTRedPONumber(container);
				int vtredPoLineNum = getVTRedPOLine(vtredPoNumber, container);

				List<String> receivedQtyOnPOLineJSON = parsedJson
						.read("$.testFlowData..poDetails[?(@.poNumber=='" + vtredPoNumber
								+ "')].poLineDetails[?(@.poLineNumber==" + vtredPoLineNum + ")]..receivedQuantity");
				int totalreceivedQtyOnPOLineJSON = 0;
				for (String qty : receivedQtyOnPOLineJSON) {
					totalreceivedQtyOnPOLineJSON = totalreceivedQtyOnPOLineJSON + Integer.parseInt(qty);
				}

				String delNumber = deliveryNumberList.get(0);
				if (Config.DC == DC_TYPE.ATLAS) {

					Failsafe.with(retryPolicy).run(() -> {
						response = given().relaxedHTTPSValidation().headers(receivingHelper.getReceivingHeaders())
								.when().get(environment.getProperty("receiving_receipt_url") + delNumber);
						logger.info("Receiving URL = " + environment.getProperty("receiving_receipt_url") + delNumber);

						parsedJson = JsonPath.parse(response.getBody().asString());
						net.minidev.json.JSONArray vtrQtyListAssert = parsedJson.read("$..quantity");
						logger.info("VTR SIZE  = {} ", vtrQtyListAssert.size());
						Assert.assertTrue(ErrorCodes.RECEIVING_VTR_NEGATIVE_ENTRY_VALIDATION,
								vtrQtyListAssert.size() > 1);
					});

					for (String vtrContainer : vtredContainerList) {
						net.minidev.json.JSONArray vtrQtyList = parsedJson.read("$..quantity");
						for (int i = 0; i < vtrQtyList.size(); i++) {
							// totalreceivedQtyOnPOLineDB = totalreceivedQtyOnPOLineDB
							// + Integer.parseInt((String.valueOf(vtrQtyList.get(i))));
							int qty = (int) vtrQtyList.get(i);
							logger.info("Receiving vtr Qtys == " + qty);

							totalreceivedQtyOnPOLineDB = totalreceivedQtyOnPOLineDB + qty;
						}
					}
				} else {
					BasicDBObject containerSearchQuery = new BasicDBObject();
					containerSearchQuery.put("deliveryNumber", delNumber);
					containerSearchQuery.append("purchaseReferenceNumber", vtredPoNumber);
					containerSearchQuery.append("purchaseReferenceLineNumber", vtredPoLineNum);
					List<String> receivedQtyOnPODB = null;
					receivedQtyOnPODB = mongoUtil.getDatafromDB("receive", "receipts", containerSearchQuery,
							"quantity");
					for (String qty : receivedQtyOnPODB) {
						totalreceivedQtyOnPOLineDB = totalreceivedQtyOnPOLineDB + Integer.valueOf(qty);
					}
				}
				Assert.assertEquals(ErrorCodes.RECEIVING_VTR_NEGATIVE_ENTRY_VALIDATION, totalreceivedQtyOnPOLineJSON,
						totalreceivedQtyOnPOLineDB);

			}
			logger.info("Receiving App :: Validated -ve enrtry in receiving DB");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating -ve entry", e);
		}
	}

	@Step
	public void reReceiveForVTR(int reReceiveQty, String itemNumber, String poNumber) {
		try {
			if (ReceivingPage.isitemFoundOnMultiplePO()) {
				ReceivingPage.selectPOfromRadioButton(poNumber);
				logger.info("item found on multiple PO");
				Thread.sleep(5000);
				ReceivingPage.clickOn_itemOnMutiplePO_ContinueButton();
			} else if (ReceivingPage.isiMultipleDeliveryDocumentLinesFound()) {
				ReceivingPage.selectPOLinefromRadioButton(poNumber);
				ReceivingPage.clickOn_multiple_Delivery_DocumentLines_ContinueButton();
			}
			Thread.sleep(5000);
			if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
				ReceivingPage.enterQtyToReceive(String.valueOf(reReceiveQty));
				ReceivingPage.clickOnReceiveButton();
				if (ReceivingPage.isFinshPalletButtonDisplayed()) {
					ReceivingPage.clickOnFinshPalletButton();
					ReceivingPage.clickOnFinshPalletPopupButton();
					Thread.sleep(2000);
				}
				ReceivingPage.clickOnCloseButton();
				logger.info("Receiving App :: Re-receiving completed");
			} else if (ReceivingPage.isNoAllocationErrorMssgDisplayed()) {
				ReceivingPage.clickOn_ConfirmationOkButton();
				Assert.fail(ErrorCodes.RECEIVING_VTR_NO_ALLOCATION);
			} else if (ReceivingPage.isNoItemFoundErrorMssgDisplayed()) {
				ReceivingPage.clickOn_ConfirmationDismissButton();
				Assert.fail(ErrorCodes.RECEIVING_VTR_ITEM_NOT_FOUND);
			} else {
				Assert.fail(ErrorCodes.RECEIVING_VTR_SOMETHING_WENT_WRONG_SCAN_UPC);
			}
			logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNumber);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while re-receiving VTRed container", e);
		}
	}

	public String getVTRedPONumber(String vtredcontainer) {
		List<String> poNumberList = parsedJson
				.read("$.testFlowData.poDetails[?(@.poLineDetails[?(@.receivingInstructions[?(@.vtrContainer=='"
						+ vtredcontainer + "')])])].poNumber");
		String vtredPoNumber = null;
		for (String poNumber : poNumberList) {
			List<String> vtrContList = parsedJson
					.read("$.testFlowData.poDetails[?(@.poNumber=='" + poNumber + "')].poLineDetails..vtrContainer");
			if (vtrContList.contains(vtredcontainer)) {
				vtredPoNumber = poNumber;
				break;
			}
		}
		return vtredPoNumber;
	}

	public int getVTRedPOLine(String vtredPoNumber, String vtredContainer) {
		List<String> poLineList = parsedJson
				.read("$.testFlowData.poDetails[?(@.poNumber=='" + vtredPoNumber + "')].poLineDetails..poLineNumber");
		int vtredPoLine = 0;
		for (String poLineNum : poLineList) {
			List<String> vtrContList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber=='" + vtredPoNumber
					+ "')].poLineDetails[?(@.poLineNumber==" + poLineNum + ")].receivingInstructions[*].vtrContainer");
			if (vtrContList.contains(vtredContainer)) {
				vtredPoLine = Integer.parseInt(poLineNum);
				break;
			}
		}
		return vtredPoLine;
	}

	@Step
	public void reportOverageProblem() {

		try {
			if (Config.DC == DC_TYPE.ATLAS) {
				checkForReceivingHomePage();
			} else {
				searchforPrinter();
				selectOnlinePrinter();
			}
			scanDoor();
			Set<String> uniqueItems;
			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Receiving App :: Reporting problem for PO:{} and for item:{}", poNumber, itemNum);
					List<String> detail = returnUpcOpenQty(poNumber, itemNum);
					List<String> ovgQty = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].ovgQty");
					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(ovgQty.get(0));
					String itemUPC = detail.get(0);
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					ReceivingPage.scanUPC(itemUPC);
					reportProblem();
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}

	}

	public void reportProblem() {
		if (ReceivingPage.isOveragePopupDisplayed()) {
			ReceivingPage.clickOnReportProblem();
			ReceivingPage.clickOnNextButton();
			enterRequiredFields(environment.getProperty("problem_ti"), environment.getProperty("problem_hi"),
					environment.getProperty("problem_qty"));
			ReceivingPage.clickOnNextButton();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			// ReceivingPage.printLabels();
			// ReceivingPage.clickOnNextButton();
		}
	}

	public void enterRequiredFields(String Ti, String Hi, String Qty) {
		ReceivingPage.enterTIValue(Ti);
		ReceivingPage.enterHIValue(Hi);
		ReceivingPage.enterQty(Qty);
	}

	@Step
	public void clickOnProblemReceiveTab() {
		ReceivingPage.clickOnProblemReceiving();
	}

	@Step
	public void scanTheProblemLabel() {
		ReceivingPage.scanProblemContainer("");
	}

	@Step
	public void startReceivingACC(Boolean isConveyorValidationRequired) {
		try {
			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			List<String> poNumberList = parsedJson.read(PO_NUMBER_JSON_PATH);

			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Scanning item UPC for item {}", itemNum);
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
					ReceivingPage.scanUPC(itemUPC);

					if (Config.DC == DC_TYPE.ACC && idmSteps.validateUpcMisMatch(itemUPC, "D1")) {

						if (ReceivingPage.checkUpcUpdateDialog()) {
							logger.info("Entering for UPC updat for itemNum{}", itemNum);
							ReceivingPage.clickOnUpcUpdateButton();
							ReceivingPage.upcUpdateenterItemNumber(itemNum);
							ReceivingPage.upcUpdateclickOnNext();
							ReceivingPage.upcUpdated();
							idmSteps.validateUpcUpdateGDM(itemUPC, "D1");
							logger.info("Waiting for UPC to be updated for itemNum{}", itemNum);

							Thread.sleep(8000);
						}
					}
					if (isConveyorValidationRequired) {
						logger.info("Validating for Place on conveyor message");
						Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
								ReceivingPage.isPlaceOnConveyorDisplayed());
						Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
								ReceivingPage.isPlaceOnConveyorTextDisplayed());
					}
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	@Step
	public String receiveItemBasedOnPo(String poNumber) {
		String itemUPC = "";
		Set<String> uniqueItems;
		List<String> itemList = parsedJson
				.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
		uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
		Iterator<String> iterator = uniqueItems.iterator();
		while (iterator.hasNext()) {
			String itemNum = iterator.next();
			logger.info("Scanning item UPC for item {}", itemNum);
			List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
			itemUPC = upc.get(0);
			ReceivingPage.scanUPC(itemUPC);

			if (idmSteps.validateUpcMisMatch(itemUPC, "D1")) {

				try {
					if (ReceivingPage.checkUpcUpdateDialog()) {
						logger.info("Entering for UPC updat for itemNum{}", itemNum);
						ReceivingPage.clickOnUpcUpdateButton();
						ReceivingPage.upcUpdateenterItemNumber(itemNum);
						ReceivingPage.upcUpdateclickOnNext();
						ReceivingPage.upcUpdated();
						idmSteps.validateUpcUpdateGDM(itemUPC, "D1");
						logger.info("Waiting for UPC to be updated for itemNum{}", itemNum);

						Thread.sleep(8000);
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return itemUPC;
	}

	public void receiveSstkItems(String itemUpc) {
		ReceivingPage.enterQtyToReceive(String.valueOf("1"));
		ReceivingPage.clickOnReceiveButton();
		logger.info("SSTK item is received");
	}

	public void ScanSstk(Boolean reScan) {
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> poNumberList = parsedJson.read(CHANNEL_METHOD + "SSTK" + PO_NUMBER);
		for (String poNumber : poNumberList) {
			String itemUpc = receiveItemBasedOnPo(poNumber);
			logger.info("Scanned SSTK Item Upc " + itemUpc);
			if (reScan) {
				ReceivingPage.validateFreightIsNotConveyableDialogBox(itemUpc);
			}
			receiveSstkItems(itemUpc);
		}
	}

	public void scanCrossuTwice() {
		waitABit(8000);
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
//		List<String> poNumberList = parsedJson.read(CHANNEL_METHOD + "CROSSU" + PO_NUMBER);
		List<String> poNumberList = parsedJson.read("$.testFlowData.poDetails[?(@.channelMethod == 'CROSSU' || @.channelMethod == 'CROSSMU')].poNumber");
		for (String poNumber : poNumberList) {
			String itemUpc = receiveItemBasedOnPo(poNumber);
			logger.info("Scanned CROSSU Item Upc " + itemUpc);
			Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
					ReceivingPage.isPlaceOnConveyorDisplayed());
			Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
					ReceivingPage.isPlaceOnConveyorTextDisplayed());

			itemUpc = receiveItemBasedOnPo(poNumber);
			logger.info("Scanned CROSSU Item Upc " + itemUpc);
			// TODO to be changed
			// ReceivingPage.verifyScannedItemMessage(itemUpc);
		}
	}

	@Step
	public void startReceivingAccBasedOnChannel(String channelMethod) {
		try {
			// SSTK->CROSSU-> CROSSU
			if (channelMethod.equals("SSTK")) {
				ScanSstk(false);
				scanCrossuTwice();
			}
			// CROSSU->CROSSU->SSTK
			else if (channelMethod.equals("CROSSU")) {
				scanCrossuTwice();
				ScanSstk(true);
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	@Step
	public void updateTiHi(String tiHi) {
		ReceivingPage.updateTiHiValues(tiHi);

	}

	@Step
	public void validateMessageToPlaceOnConveyerBelt() {
		try {
			logger.info("Validating for Place on conveyor message");
			Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
					ReceivingPage.isPlaceOnConveyorDisplayed());
			Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
					ReceivingPage.isPlaceOnConveyorTextDisplayed());

			ReceivingPage.closePlaceOnConveyerPage();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	@Step
	public void startManualReceivingACC() {
		try {
			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			List<String> poNumberList = parsedJson.read(PO_NUMBER_JSON_PATH);

			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Scanning item UPC for item {}", itemNum);
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
					ReceivingPage.scanUPC(itemUPC);
					ReceivingPage.clickOnContinueButton();
					List<String> detail = returnUpcOpenQty(poNumber, itemNum);
					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(detail.get(1));
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					fullManualReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false, itemNum);

				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	@Step
	public void startReceivingMultiPO() {
		try {
			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			List<String> poNumberList = parsedJson.read(CHANNEL_METHOD + "CROSSMU" + PO_NUMBER);

			for (String poNumber : poNumberList) {
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Scanning item UPC for item {}", itemNum);
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
					ReceivingPage.scanUPC(itemUPC);
					ReceivingPage.clickOnContinueButton();
					List<String> detail = returnUpcOpenQty(poNumber, itemNum);
					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(detail.get(1));
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					fullManualReceiving(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false, itemNum);
					ScanSstk(false);
					ReceivingPage.clickOnFinshPalletButton();
					ReceivingPage.clickOnFinshPalletPopupButton();
				}
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	@Step
	public void startReceivingMultiPO(String manualOrNonManualReceiving) {
		try {
			boolean isManualReceiving = manualOrNonManualReceiving.equalsIgnoreCase("Manually");
			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			List<List<String>> poNumberList = parsedJson.read("$..deliveryDetails..poNumbers");
			List<String> poNumbers = poNumberList.get(0);
			for (int i=0; i< poNumbers.size(); i++) {
				String poNumber = poNumbers.get(i);
				String channelMethod = ((JSONArray) parsedJson.read("$.testFlowData..poDetails[?(@.poNumber == '" + poNumber + "')].channelMethod")).get(0).toString();
				logger.info("*******channelMethod=" + channelMethod);
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Scanning item UPC for item {}", itemNum);
					List<String> isConveyableInd = parsedJson.read("$..poLineDetails[?(@.itemNumber=='" + itemNum+ "')].isConveyable");
					boolean isItemConveyable = isConveyableInd.get(0).equalsIgnoreCase("true");
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
					ReceivingPage.scanUPC(itemUPC);
					if(i==0 && isManualReceiving) {
						ReceivingPage.clickOnContinueButton();
					}
					String sourceNumber = getSourceNumberFromOrders(poNumber, channelMethod);
					logger.info("PO Number being received for Multi PO Scenario {}", poNumber);
					// Non-Manual Receiving for DA-CON
					if(!isManualReceiving && channelMethod.equalsIgnoreCase("CROSSU") && isItemConveyable) {
						ReceivingPage.validateAddToFloorLinePalletMessage();
						ReceivingPage.validatePoTypeTextOnTop("DA Conveyable");
						Thread.sleep(10000);
					} // SSTK, Non-Manual Receiving for DA-NON-CON, POCON
					else {
						if (!isManualReceiving && channelMethod.equalsIgnoreCase("CROSSU") && !isItemConveyable && (sourceNumber.equalsIgnoreCase("32899") || sourceNumber.equalsIgnoreCase("32898"))) {
							ReceivingPage.validateFreightIsNotConveyableDialogBox(itemUPC);
						}
						List<String> detail = returnUpcOpenQty(poNumber, itemNum);
						int maxReceiveQty = 0;
						maxReceiveQty = Integer.parseInt(detail.get(1));
						List<String> itemOnPoList = parsedJson
								.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
						logger.info("itemOnPo_List :{}", itemOnPoList);
						ReceivingPage.validatePoTypeTextOnTop(getInboundChannelMethodOnReceiving(channelMethod, isItemConveyable, sourceNumber));
						if(isManualReceiving) {
							fullManualReceivingForAllPoType(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false, itemNum, channelMethod);
						} else {
							fullReceivingForAllPoType(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false, itemNum, channelMethod);
						}
					}
				}
			}
			ReceivingPage.clickOnFinshPalletButton();
			ReceivingPage.clickOnFinshPalletPopupButton();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	@Step
	public void startReceivingMultiPOOnlineDoor(String manualOrNonManualReceiving) {
		try {
			boolean isManualReceiving = manualOrNonManualReceiving.equalsIgnoreCase("Manually");
			Set<String> uniqueItems;
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			List<List<String>> poNumberList = parsedJson.read("$..deliveryDetails..poNumbers");
			List<String> poNumbers = poNumberList.get(0);
			for (int i=0; i< poNumbers.size(); i++) {
				String poNumber = poNumbers.get(i);
				String channelMethod = ((JSONArray) parsedJson.read("$.testFlowData..poDetails[?(@.poNumber == '" + poNumber + "')].channelMethod")).get(0).toString();
				logger.info("*******channelMethod=" + channelMethod);
				List<String> itemList = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
				uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
				Iterator<String> iterator = uniqueItems.iterator();
				while (iterator.hasNext()) {
					String itemNum = iterator.next();
					logger.info("Scanning item UPC for item {}", itemNum);
					List<String> isConveyableInd = parsedJson.read("$..poLineDetails[?(@.itemNumber=='" + itemNum+ "')].isConveyable");
					boolean isItemConveyable = isConveyableInd.get(0).equalsIgnoreCase("true");
					List<String> upc = parsedJson.read(POMATCH + poNumber + ITMMATCH + itemNum + ")].itemUpc");
					String itemUPC = upc.get(0);
					ReceivingPage.scanUPC(itemUPC);
					if(i==0 && isManualReceiving) {
						ReceivingPage.clickOnContinueButton();
					}
					String sourceNumber = getSourceNumberFromOrders(poNumber, channelMethod);
					// Non-Manual Receiving for DA-CON
					if(!isManualReceiving && channelMethod.equalsIgnoreCase("CROSSU") && isItemConveyable) {
						logger.info("Validating for Place on conveyor message");
						Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
								ReceivingPage.isPlaceOnConveyorDisplayed());
						Assert.assertTrue(ErrorCodes.RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN,
								ReceivingPage.isPlaceOnConveyorTextDisplayed());
						Thread.sleep(10000);
						boolean isPoTypeTextDisplayed = ReceivingPage.validatePoTypeTextOnTop(getInboundChannelMethodOnReceiving(channelMethod, isItemConveyable, sourceNumber));
						Assert.assertTrue(ErrorCodes.RECEIVING_CHNLMTHD_TEXT_NOT_DISPLAYED_CORRECTLY, isPoTypeTextDisplayed);
					} // SSTK, Non-Manual Receiving for DA-NON-CON, POCON
					else {
						if (!isManualReceiving && channelMethod.equalsIgnoreCase("CROSSU") && !isItemConveyable && (sourceNumber.equalsIgnoreCase("32899") || sourceNumber.equalsIgnoreCase("32898"))) {
							ReceivingPage.validateFreightIsNotConveyableDialogBox(itemUPC);
						}
						ReceivingPage.validatePoTypeTextOnTop(getInboundChannelMethodOnReceiving(channelMethod, isItemConveyable, sourceNumber));
						List<String> detail = returnUpcOpenQty(poNumber, itemNum);
						int maxReceiveQty = 0;
						maxReceiveQty = Integer.parseInt(detail.get(1));
						List<String> itemOnPoList = parsedJson
								.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
						logger.info("itemOnPo_List :{}", itemOnPoList);
						if(isManualReceiving) {
							fullManualReceivingForAllPoType(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false, itemNum, channelMethod);
						} else {
							fullReceivingForAllPoType(itemOnPoList, poNumber, itemUPC, maxReceiveQty, false, itemNum, channelMethod);
						}
					}
				}
			}
			ReceivingPage.clickOnFinshPalletButton();
			ReceivingPage.clickOnFinshPalletPopupButton();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while scanning item UPC", e);
		}
	}

	private String getSourceNumberFromOrders(String poNumber, String channelMethod) {
		String sourceNumber = "";
		try {
			sourceNumber = ((JSONArray) parsedJson.read("$.testFlowData..ordersDetails[?(@.plannedPo== '" + poNumber + "')].sourceNumber")).get(0).toString();
		} catch (Exception e) {
			if(channelMethod.equalsIgnoreCase("CROSSU")) {
				sourceNumber = "PO CON";
			}
		}
		return sourceNumber;
	}

	private void fullManualReceiving(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty,
			boolean b, String itemNum) {

		// if (!ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
		try {
			int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
			logger.info("Quantity to receive :{}", qtyToReceive);
			ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
			ReceivingPage.clickOnReceiveButton();

			Thread.sleep(10000);
			logger.info("Waiting to manually receive all the cases ");

			logger.info("Getting Delivery number ");

			List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");

			logger.info("Delivery number " + deliveryNumberList.get(0));
			deliveryNumber = deliveryNumberList.get(0);

			String containerResponse;
			containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
			logger.info("ContainerResponse for the given delivery::{}", containerResponse);
			receivingHelper.setReceivingInstructionForDSDCOrManualReceiving(containerResponse, poNumber, itemNum,
					"CROSSMU");

			logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
			// ReceivingPage.closeDiver();
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}

	}

	private void fullManualReceivingForAllPoType(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty, boolean b, String itemNum, String channelMethod) {
		try {
			int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
			logger.info("Quantity to receive :{}", qtyToReceive);
			ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
			ReceivingPage.clickOnReceiveButton();

			Thread.sleep(qtyToReceive * 1000);
			logger.info("Waiting to manually receive all the cases ");
			logger.info("Getting Delivery number ");
			List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
			logger.info("Delivery number " + deliveryNumberList.get(0));
			deliveryNumber = deliveryNumberList.get(0);

			String containerResponse;
			containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
			logger.info("ContainerResponse for the given delivery::{}", containerResponse);
//			receivingHelper.setReceivingInstructionForDSDCOrManualReceiving(containerResponse, poNumber, itemNum, channelMethod);
			logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}

	}

	private void fullReceivingForAllPoType(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty, boolean b, String itemNum, String channelMethod) {
		try {
			int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
			logger.info("Quantity to receive :{}", qtyToReceive);
			ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
			ReceivingPage.clickOnReceiveButton();
			Thread.sleep(qtyToReceive * 1000);
			logger.info("Waiting to manually receive all the cases ");

			logger.info("Getting Delivery number ");
			List<String> deliveryNumberList = parsedJson.read("$.testFlowData.deliveryDetails..deliveryNumber");
			logger.info("Delivery number " + deliveryNumberList.get(0));
			deliveryNumber = deliveryNumberList.get(0);
			String containerResponse;
			containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
			logger.info("ContainerResponse for the given delivery::{}", containerResponse);

//			receivingHelper.setReceivingInstruction(containerResponse, poNumber, itemNum, getOutboundChannelMethod(channelMethod));
			logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}

	}

	private String getOutboundChannelMethod(String chnlMthd) {
		String outBoundChnlMthd = "";
		switch(chnlMthd) {
			case "SSTK" : outBoundChnlMthd = "STAPLESTOCK";
			case "POCON" : outBoundChnlMthd = "POCON";
			case "CROSSU" : outBoundChnlMthd = "CROSSNA";
			case "CROSSMU" : outBoundChnlMthd = "CROSSNMA";
		}
		return outBoundChnlMthd;
	}

	private String getInboundChannelMethodOnReceiving(String chnlMthd, boolean isConveyable, String dcNbr) {
		String inboundChannelMethodOnReceiving = chnlMthd;
		if(chnlMthd.equalsIgnoreCase("SSTK")) {
			inboundChannelMethodOnReceiving = "SSTK";
		} else if(chnlMthd.equalsIgnoreCase("CROSSU") && (dcNbr.equalsIgnoreCase("32899") || dcNbr.equalsIgnoreCase("32898"))) {
			if(isConveyable) {
				inboundChannelMethodOnReceiving = "DA CON";
			} else {
				inboundChannelMethodOnReceiving = "DA NONCON";
			}
		} else {
			inboundChannelMethodOnReceiving = "PO CON";
		}

		return inboundChannelMethodOnReceiving;
	}

	@Step
	public void openreceivingApp() {
		ReceivingPage.openReceivingApp();
	}

	@Step
	public void scanUpcCancelReceipt() {

		String poNumber = poNumberList.get(0);
		logger.info("Cancelling the receipt for the PO number:{}", poNumber);
		List<String> itemList = parsedJson.read(
				"$.testFlowData.poDetails[?(@.poNumber == '" + poNumberList.get(0) + "')].poLineDetails..itemNumber");
		String itemNum = itemList.get(0);
		logger.info("Receiving App :: Started receiving for Cancel Receipt feature for PO:{} and for item:{}", poNumber,
				itemNum);
		List<String> detail = returnUpcOpenQty(poNumber, itemNum);
		String itemUPC = detail.get(0);
		List<String> itemOnPoList = parsedJson.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
		logger.info("itemOnPo_List :{}", itemOnPoList);
		ReceivingPage.scanUPC(itemUPC);

		if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {

			if (itemOnPoList.size() > 1) {
				ReceivingPage.selectPOfromRadioButton(poNumber);
				ReceivingPage.clickOn_itemOnMutiplePO_ContinueButton();
			}
			ReceivingPage.clickOnPageCloseButton();
			try {
				ReceivingPage.cancelPallet();
			} catch (Exception e) {
				throw new AutomationFailure("Something went wrong while cancelling a pallet ", e);
			}

		}
	}

	public void enterDeliveryNumber() {

		testFlowData = threadLocal.get().get("testFlowData").toString();
		JSONArray delNum = JsonPath.read(testFlowData,
				"$.testFlowData.deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber");
		deliveryNumber = delNum.get(0).toString();
		logger.info("Delivery number " + deliveryNumber);

		ReceivingPage.clickOnEnterDeliveryNumber();
		ReceivingPage.enterDeliveryNumber(deliveryNumber);
		ReceivingPage.clickOnopenDeliveryButton();

	}

	public void scanOldLocation() throws InterruptedException {

		testFlowData = threadLocal.get().get("testFlowData").toString();
		JSONArray doorNum = JsonPath.read(testFlowData,
				"$.testFlowData.deliveryDetails[?(@.deliveryName=='D1')].inboundDoorNumber");
		String doorNumber = doorNum.get(0).toString();
		logger.info("Door number " + doorNumber);
		ReceivingPage.enterDoorNumber(doorNumber);
	}

	public void openDeliveryPage() {

		ReceivingPage.validateAppUIScreen();

	}

	@Step
	public void receivingForWitron(String receiveType, String splitQty, String xrefItem) {
		try {

			for (String poNumber : poNumberList) {
				String itemNum;
				int ovgQtyVal = 0;
				String expiryDate;
				int damageQty;
				int rejectQty;
				int recvQty = 0;
				String croAction;

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					logger.info("Po Number{} " + poLineNumber);
					String itemUPC;
//					if (poLineNumber.contains("1")||poLineNumber.contains("10")||poLineNumber.contains("11")||poLineNumber.contains("5")||poLineNumber.contains("9") || poLineNumber.contains("2")|| poLineNumber.contains("4")||poLineNumber.contains("6") || poLineNumber.contains("7")|| poLineNumber.contains("8")) {
//						continue;
//					}
					List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemNumber");
					itemNum = itemList.get(0).toString();
					if (itemNum.contentEquals(splitQty))
						continue;

					List<String> damageQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].damageQty");
					damageQty = Integer.parseInt(damageQtyList.get(0).toString());

					List<String> rejectQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].rejectQty");
					rejectQty = Integer.parseInt(rejectQtyList.get(0).toString());

					List<Integer> recvQtyList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].recvQty");
					recvQty = recvQtyList.get(0);

					if (recvQty == 0) {
						continue;
					}

					List<String> croActionType = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].croInd");
					croAction = croActionType.get(0).toString();
					logger.info("damage reject receive {} {} {} " + damageQty, rejectQty, recvQty);

					if (receiveType.contains("overage")) {
						List<String> ovgQty = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].ovgQty");
						ovgQtyVal = Integer.parseInt(ovgQty.get(0).toString());

					}

					List<String> receiveDate = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].witronItemDetails.receiveDate");

					List<String> expiryDateCode = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].warehouseRotationType");

					List<String> expiryDateCodeWitron = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].witronItemDetails.warehouseRotationTypeCode");

					logger.info("expiryDateCode{} " + expiryDateCodeWitron.get(0).toString());

					if (Config.DC == DC_TYPE.WITRON && expiryDateCodeWitron.get(0).toString().contentEquals("3")) {

						expiryDate = receiveDate.get(0).toString();
						logger.info("Expiry Date :{} ", expiryDate);

					} else if (Config.DC == DC_TYPE.SAMS && expiryDateCode.get(0).toString().contentEquals("3")) {

						Calendar cal = Calendar.getInstance();
						cal.add(Calendar.MONTH, 3);
						Date date = cal.getTime();
						DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
						expiryDate = dateFormat.format(date);
						logger.info("Expiry Date :{} ", expiryDate);

					} else
						expiryDate = null;

					logger.info("Receiving App :: Started receiving for PO:{} and for item:{}", poNumber, itemNum);

					List<String> detail = returnUpcOpenQtyForWitron(poNumber, poLineNumber, itemNum);

					int maxReceiveQty = 0;
					maxReceiveQty = Integer.parseInt(detail.get(1));
					//// VTR///

					List<Integer> vtrReReceiveQty = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '"
							+ poNumber + "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[?(@.isVTR == true)].vtrQty");

					List<String> vtrChannel = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[?(@.isVTR == true)].channelType");

					if (vtrReReceiveQty.size() != 0) {
						maxReceiveQty = vtrReReceiveQty.get(0);

					}

					if (receiveType.contains("prime")) {
						itemUPC = witronUtils.getItemMDMDetailsUPCXref(splitQty, xrefItem);

					} else {
						itemUPC = detail.get(0);

					}
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					ReceivingPage.scanUPC(itemUPC);

					if (receiveType.contains("Correction")) {
						ReceivingPage.clickOnReceiveCorrectionBtn();
					}

					/// Validate multiline
					Thread.sleep(2000);
					boolean flag = ReceivingPage.multiLinevailableOrNot();
					logger.info("multi line variable " + flag + " croAction " + croAction);
					if (flag && croAction.contains("croReject")) {
						ReceivingPage.validateAndSelectMultiLine(poLineNumber, croAction);
						logger.info("CRO reject for expiry date :{}", croAction);
						continue;
					} else if (flag && croAction.contains("cro")) {
						ReceivingPage.validateAndSelectMultiLine(poLineNumber, croAction);
						logger.info("Selected Multi line for cro action CRO");

					}

					///////
					ReceivingPage.validateSelectPalletTypeScreen();
					List<String> ti = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')].ti");
					int tiVal = Integer.parseInt(ti.get(0).toString());

					List<String> hi = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')].hi");

					int hiVal = Integer.parseInt(hi.get(0).toString());

					List<String> poLineOpenQty = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')].poVnpkQty");

					osdrReceivingWitron(itemOnPoList, poNumber, itemUPC, maxReceiveQty, receiveType, ovgQtyVal,
							expiryDate, splitQty, poLineNumber, damageQty, rejectQty, recvQty, croAction);

					if (Config.DC == DC_TYPE.WITRON || Config.DC == DC_TYPE.SAMS) {
						String containerResponse;
						containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
						logger.info("ContainerResponse for the given delivery::{}", containerResponse);
						receivingHelper.setReceivingInstructionForWitron(containerResponse, poNumber, itemNum,
								poLineNumber, receiveType, splitQty);
					}
					logger.info("Receiving App :: Completed receiving for PO:{} and for item:{}", poNumber, itemNum);

				}
			}

			ReceivingPage.closeDiver();
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void cancelPallet() {
		try {

//			threadLocal.get().put("testFlowData",
//			"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"086072549\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"81\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"8\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 757320, \"wac\": 250.2861, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.9\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-04-01\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"10\", \"waw\": 15.9, \"totalWeight\": 602069.3997, \"averageWeightPerCase\": 15.9, \"croInd\": \"cro\", \"recvQty\": 81, \"osdrInd\": \"s\", \"problemQty\": \"0\"} ], \"uuid\": [\"24af0de3-8623-4a73-98d6-375b2537b44e\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"116\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T54898764\", \"poNumbers\": [\"086072549\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"54898764\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before Pallet cancel start : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			for (String poNumber : poNumberList) {
				String itemNum;

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					logger.info("Po Number{} " + poLineNumber);

//					if (poLineNumber.contains("1") || poLineNumber.contains("2")|| poLineNumber.contains("4")||poLineNumber.contains("6") || poLineNumber.contains("7")|| poLineNumber.contains("8")) {
//						continue;
//					}
					List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemNumber");
					itemNum = itemList.get(0).toString();

					logger.info("Receiving App :: Started receiving for PO:{} and for item:{}", poNumber, itemNum);

					List<String> detail = returnUpcOpenQtyForWitron(poNumber, poLineNumber, itemNum);

					String itemUPC = detail.get(0);
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);
					ReceivingPage.scanUPC(itemUPC);

					ReceivingPage.clickOnCloseButtonWitron();
					ReceivingPage.cancelPalletCase();

				}
			}
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void rejectPalletWhileReceiving() {
		try {

//			threadLocal.get().put("testFlowData",
//			"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"066806033\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"81\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"8\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [], \"thorUnitsPer\": 0, \"boh\": 757320, \"wac\": 250.2861, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.9\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-04-01\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"10\", \"waw\": 15.9, \"totalWeight\": 602069.3997, \"averageWeightPerCase\": 15.9, \"croInd\": \"cro\", \"recvQty\": 81, \"osdrInd\": \"s\", \"problemQty\": \"0\"} ], \"uuid\": [\"41f30b95-6748-4861-a302-f7d4922a1823\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"116\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T44073035\", \"poNumbers\": [\"066806033\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"44073035\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before Pallet cancel start : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);
			String croAction;

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			for (String poNumber : poNumberList) {
				String itemNum;

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					logger.info("Po Number{} " + poLineNumber);

//					if (poLineNumber.contains("1") || poLineNumber.contains("2")|| poLineNumber.contains("4")||poLineNumber.contains("6") || poLineNumber.contains("7")|| poLineNumber.contains("8")) {
//						continue;
//					}
					List<String> itemList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].itemNumber");
					itemNum = itemList.get(0).toString();

					List<String> croActionType = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].croInd");
					croAction = croActionType.get(0).toString();

					logger.info("Receiving App :: Started receiving for PO:{} and for item:{}", poNumber, itemNum);

					List<String> detail = returnUpcOpenQtyForWitron(poNumber, poLineNumber, itemNum);

					String itemUPC = detail.get(0);
					List<String> itemOnPoList = parsedJson
							.read("$..poDetails..poLineDetails[?(@.itemNumber=='" + itemNum + "')]");
					logger.info("itemOnPo_List :{}", itemOnPoList);

					for (int i = 0; i < 3; i++) {

						ReceivingPage.scanUPC(itemUPC);

//						Calendar cal = Calendar.getInstance();
//						Date date = cal.getTime();
						Date currDate = new Date();

						DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
						String expiryDate = desturl.format(currDate);

						logger.info("Expiry Date :{} ", expiryDate);

						boolean flag = ReceivingPage.multiLinevailableOrNot();

						if (flag && croAction.contains("cro")) {
							ReceivingPage.validateAndSelectMultiLine(poLineNumber, croAction);
						}

						ReceivingPage.validateSelectPalletTypeScreen();

						String qtyToReceive = ReceivingPage.getQtyToReceive();
						logger.info("Quantity to receive :{}", qtyToReceive);

						ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
						if (expiryDate != null) {
							ReceivingPage.selectExpiryDateWitron(expiryDate);
						}

						ReceivingPage.rejectFromInstructionPage(qtyToReceive, i);
					}
					// ReceivingPage.closeWitronDiver();

				}
				// ReceivingPage.closeWitronDiver();

			}
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void receivingOnHoldPallet() {
		try {
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before Pallet Hold start : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					ReceivingInstruction receivingInstruction = new ReceivingInstruction();
					logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

					List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[*].parentContainer");
					logger.info("Pallet count: {} ", contrList.size());

					///// Pallet hold update

					String holdCntr;

					JSONArray receivingInstructionArraySstk = parsedJson
							.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
									+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
									+ "')].receivingInstructions[*]");

					if (!receivingInstructionArraySstk.isEmpty()) {
						receivingInstruction = (ReceivingInstruction) jsonUtil.getPojofromJsonObject(
								receivingInstructionArraySstk.get(0), ReceivingInstruction.class);
					}

					if (receivingInstruction != null) {

						holdCntr = receivingInstruction.getParentContainer();
						logger.info("hold CONT === {} ", holdCntr);
						receivingInstruction.setOnHoldStatus(true);
						receivingInstruction.setpalletHoldQty(receivingInstruction.getReceivedQuantity());

						String runTimeDataForPalletHold = (String) threadLocal.get().get("testFlowData");
						JSONObject listOfReceivingInstruction;
						listOfReceivingInstruction = jsonUtil.convertToJsonObject(receivingInstruction);

						runTimeDataForPalletHold = jsonUtil.setJsonAtJsonPath(runTimeDataForPalletHold,
								listOfReceivingInstruction,
								"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
										+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
										+ "')].receivingInstructions[?(@.parentContainer == '" + holdCntr + "')]");

						threadLocal.get().put("testFlowData", runTimeDataForPalletHold);
						logger.info("testFlowData after pallet hold status and qty updated {}",
								threadLocal.get().get("testFlowData"));

						ReceivingPage.checkDoorScanPage();

						ReceivingPage.clickOnReceiveMenu();

						ReceivingPage.markPalletOnHold(holdCntr);

					}
				}
			}

			ReceivingPage.closeDiver();
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void receivingVTRPalletWitron(String val) {
		try {
//			/// remove it
//			threadLocal.get().put("testFlowData",
//					"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poLineDetails\": [{\"itemNumber\": \"9000050\", \"hi\": \"10\", \"receivingInstructions\": [{\"parentContainer\": \"E32612000020006528\", \"isDamage\": false, \"vtrContainer\": \"E32612000020006528\", \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"60644279-f501-4580-a015-ffa7c5bf4d01\", \"channelType\": \"SSTKU\", \"destNumber\": \"32612\", \"rotateDate\": \"2020-10-01\", \"onHoldStatus\": true, \"vtrQty\": 220, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"220\", \"isVTR\": true, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] }, {\"parentContainer\": \"E32612000020006529\", \"isDamage\": false, \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"6bdff325-868b-4022-ab68-4d99f5fa589c\", \"channelType\": \"SSTKU\", \"destNumber\": \"32612\", \"rotateDate\": \"2020-10-01\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"20\", \"isVTR\": false, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"vnpk\": \"12\", \"whpkSellPrice\": \"13.9\", \"poLineNumber\": \"1\", \"weight\": 0, \"caseUpc\": \"10070470003235\", \"thorUnitsPer\": 0, \"witronItemDetails\": {\"shipGroupId\": \"10012\", \"wareHouseAreaCode\": \"2\", \"wareHouseGroupCode\": \"DD\", \"warehouseRotationTypeCode\": \"3\", \"weight\": \"5.5\", \"receiveDate\": \"2020-10-01\", \"maxWeight\": \"2736.0\", \"xrefId\": \"0\", \"samePalletIndicator\": \"1\", \"maxCube\": \"75.0\", \"mergeable\": true, \"depth\": \"10.8\", \"outboundStackGroup\": \"Normal\", \"maxHeight\": \"90.0\", \"isMergeable\": true, \"profiledWarehouseArea\": \"OPM\", \"width\": \"8.1\", \"height\": \"3.8\"}, \"ti\": \"22\", \"itemUpc\": \"00070470003238\", \"promoInd\": \"N\", \"poVnpkQty\": \"240\", \"wac\": 0, \"boh\": 0, \"whpk\": \"12\", \"isVariableWeight\": false } ], \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"poNumber\": \"089748357\", \"uuid\": [\"7101d3c6-1ac5-423b-acb1-99b924d43b00\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"237\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T39584081\", \"poNumbers\": [\"089748357\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"39584081\", \"deliveryStatus\": \"CREATE_DELIVERY\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			if (val.contains("negativeVTRPostPOConfirm")) {

			} else {
				witronUtils.setBohWacWawTotalWeight();
			}

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before VTR : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					ReceivingInstruction receivingInstruction = new ReceivingInstruction();
					logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

					List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[*].parentContainer");
					logger.info("Pallet count: {} ", contrList.size());

					String vtrCntr = null;

					JSONArray receivingInstructionArraySstk = parsedJson
							.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
									+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
									+ "')].receivingInstructions[*]");

					if (!receivingInstructionArraySstk.isEmpty()) {
						receivingInstruction = (ReceivingInstruction) jsonUtil.getPojofromJsonObject(
								receivingInstructionArraySstk.get(0), ReceivingInstruction.class);
					}

					if (receivingInstruction != null) {

						vtrCntr = receivingInstruction.getParentContainer();
						logger.info("VTR CONT === {} ", vtrCntr);
						receivingInstruction.setvtrQty(Integer.parseInt(receivingInstruction.getReceivedQuantity()));
						receivingInstruction.setIsVTR(true);
						receivingInstruction.setVtrContainer(receivingInstruction.getParentContainer());

						String runTimeDataForPalletHold = (String) threadLocal.get().get("testFlowData");
						JSONObject listOfReceivingInstruction;
						listOfReceivingInstruction = jsonUtil.convertToJsonObject(receivingInstruction);

						runTimeDataForPalletHold = jsonUtil.setJsonAtJsonPath(runTimeDataForPalletHold,
								listOfReceivingInstruction,
								"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
										+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
										+ "')].receivingInstructions[?(@.parentContainer == '" + vtrCntr + "')]");

						threadLocal.get().put("testFlowData", runTimeDataForPalletHold);
						logger.info("testFlowData after pallet hold status and qty updated {}",
								threadLocal.get().get("testFlowData"));

					}
					ReceivingPage.checkDoorScanPage();

					ReceivingPage.clickOnReceiveMenu();

					ReceivingPage.markPalletCancel(vtrCntr, "");
				}
			}

			ReceivingPage.closeDiver();
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void receivingPalleCorrectiontWitron(String val) {
		try {
//			/// remove it
//			threadLocal.get().put("testFlowData",
//					"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"045880686\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"565878030\", \"poVnpkQty\": \"300\", \"vnpk\": \"6\", \"whpk\": \"6\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"30\", \"ti\": \"12\", \"hi\": \"21\", \"itemUpc\": \"00681131225052\", \"caseUpc\": \"10681131225059\", \"receivingInstructions\": [{\"parentContainer\": \"A32610000020274807\", \"isDamage\": false, \"vtrContainer\": \"A32610000020274807\", \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"7d6bc39c-ffe8-4be8-bc80-810764b5c993\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2020-10-22\", \"onHoldStatus\": false, \"vtrQty\": 0, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"252\", \"isVTR\": true, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] }, {\"parentContainer\": \"A32610000020274804\", \"messageId\": \"ffa60c40-b7c2-4bfc-b0ba-5a1d2cbb740b\", \"childContainers\": [], \"receivedQuantity\": \"48\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2020-10-22\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 71004, \"wac\": 14.9696, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.8\", \"height\": \"2.1\", \"width\": \"8.9\", \"depth\": \"13.8\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"756991\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-10-22\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 3.8, \"croInd\": \"cro\", \"recvQty\": 300, \"osdrInd\": \"s\", \"problemQty\": \"noProblem\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"566163978\", \"poVnpkQty\": \"100\", \"vnpk\": \"20\", \"whpk\": \"20\", \"whpkSellPrice\": \"14.9\", \"ovgQty\": \"10\", \"ti\": \"9\", \"hi\": \"10\", \"itemUpc\": \"00260948000009\", \"caseUpc\": \"10260948000006\", \"receivingInstructions\": [{\"parentContainer\": \"A32610000020274805\", \"isDamage\": false, \"vtrContainer\": \"A32610000020274805\", \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"7177aa1b-2c53-4aa0-b3f3-2be7eda2d418\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2021-04-02\", \"onHoldStatus\": false, \"vtrQty\": 71, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"81\", \"isVTR\": true, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] }, {\"parentContainer\": \"A32610000020274813\", \"messageId\": \"662e3ca9-b265-4e26-b3a9-d9be390894a8\", \"childContainers\": [], \"receivedQuantity\": \"19\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2021-04-02\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 154660, \"wac\": 239.9332, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10025\", \"isMergeable\": true, \"weight\": \"15.9\", \"height\": \"5.0\", \"width\": \"10.0\", \"depth\": \"22.5\", \"wareHouseGroupCode\": \"M\", \"wareHouseAreaCode\": \"1\", \"samePalletIndicator\": \"2\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"CPS\", \"receiveDate\": \"2021-04-02\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 15.9, \"totalWeight\": 122954.7, \"averageWeightPerCase\": 15.9, \"croInd\": \"cro\", \"recvQty\": 100, \"osdrInd\": \"s\", \"problemQty\": \"noProblem\"}, {\"poLineNumber\": \"3\", \"itemNumber\": \"555803977\", \"poVnpkQty\": \"30\", \"vnpk\": \"16\", \"whpk\": \"16\", \"whpkSellPrice\": \"13.9\", \"ovgQty\": \"3\", \"ti\": \"6\", \"hi\": \"5\", \"itemUpc\": \"00078742148397\", \"caseUpc\": \"10078742148394\", \"receivingInstructions\": [{\"parentContainer\": \"A32610000020274814\", \"isDamage\": false, \"vtrContainer\": \"A32610000020274814\", \"isPbylTripExecuted\": false, \"isPbyl\": false, \"messageId\": \"74db89ba-d51b-47c5-a554-b19e6ab6e721\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"rotateDate\": \"2021-04-03\", \"onHoldStatus\": false, \"vtrQty\": 30, \"damageQty\": 0, \"vtrContainerOrderIds\": [], \"receivedQuantity\": \"20\", \"isVTR\": true, \"isShipOut\": true, \"salesQty\": 0, \"orderIds\": [], \"isGFCS\": false, \"adjustedQty\": 0, \"childContainers\": [] } ], \"thorUnitsPer\": 0, \"boh\": 960, \"wac\": 13.9, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Intact\", \"shipGroupId\": \"10010\", \"isMergeable\": true, \"weight\": \"45.6\", \"height\": \"12.6\", \"width\": \"13.0\", \"depth\": \"23.6\", \"wareHouseGroupCode\": \"DD\", \"wareHouseAreaCode\": \"2\", \"samePalletIndicator\": \"1\", \"xrefId\": \"0\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2021-04-03\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 45.6, \"croInd\": \"cro\", \"recvQty\": 20, \"osdrInd\": \"o\", \"problemQty\": \"noProblem\"} ], \"uuid\": [\"24df21df-3a6a-4e1c-80b8-94f0a37db27c\"], \"zonetemperatures\": \"-10#0#10\"} ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"113\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T52773099\", \"poNumbers\": [\"045880686\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"52773099\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			if (val.contains("negativePOConfirm")) {

			} else {
				witronUtils.setBohWacWawTotalWeight();
			}
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before Pallet Correction : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {
				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					ReceivingInstruction receivingInstruction = new ReceivingInstruction();
					logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

					List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[*].parentContainer");
					logger.info("Pallet count: {} ", contrList.size());

					String vtrCntr = contrList.get(0).toString();
					int cntrQuantity;
					int tiHiValue;

					List<String> ti = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].ti");

					List<String> hi = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].hi");

					tiHiValue = Integer.parseInt(ti.get(0).toString()) * Integer.parseInt(hi.get(0).toString());

					JSONArray receivingInstructionArraySstk = parsedJson
							.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
									+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
									+ "')].receivingInstructions[*]");

					JSONArray ctrQty = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[?(@.parentContainer == '" + vtrCntr + "')].receivedQuantity");

					cntrQuantity = Integer.parseInt(ctrQty.get(0).toString());

					if (!receivingInstructionArraySstk.isEmpty()) {
						receivingInstruction = (ReceivingInstruction) jsonUtil.getPojofromJsonObject(
								receivingInstructionArraySstk.get(0), ReceivingInstruction.class);
					}

					if (receivingInstruction != null) {

						vtrCntr = receivingInstruction.getParentContainer();
						logger.info("CONT to be Corrected === {} ", vtrCntr);
						if (poLineNumber.contentEquals("1")) {
							receivingInstruction.setvtrQty(0);
						} else if (poLineNumber.contentEquals("2")) {
							receivingInstruction.setvtrQty(cntrQuantity - 10);

						} else if (poLineNumber.contentEquals("3")) {

							// will change it back once reveiving fix the issue.
							receivingInstruction.setvtrQty(tiHiValue);

							// receivingInstruction.setvtrQty(cntrQuantity+4);

						}
						receivingInstruction.setIsVTR(true);
						receivingInstruction.setVtrContainer(receivingInstruction.getParentContainer());

						String runTimeDataForPalletHold = (String) threadLocal.get().get("testFlowData");
						JSONObject listOfReceivingInstruction;
						listOfReceivingInstruction = jsonUtil.convertToJsonObject(receivingInstruction);

						runTimeDataForPalletHold = jsonUtil.setJsonAtJsonPath(runTimeDataForPalletHold,
								listOfReceivingInstruction,
								"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
										+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
										+ "')].receivingInstructions[?(@.parentContainer == '" + vtrCntr + "')]");

						threadLocal.get().put("testFlowData", runTimeDataForPalletHold);
						logger.info("testFlowData after pallet correction {}", threadLocal.get().get("testFlowData"));

					}
					ReceivingPage.checkDoorScanPage();

					ReceivingPage.clickOnReceiveMenu();

					ReceivingPage.doPalletCorrection(vtrCntr, cntrQuantity, tiHiValue, poLineNumber, val);

				}
			}

			ReceivingPage.closeDiver();
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void negativeVTRAndPOConfirm(String val) {
		try {
//			/// remove it
//			threadLocal.get().put("testFlowData",
//					"{\"testFlowData\": {\"ordersDetails\": [], \"releaseDetails\": [], \"problemDetails\": [], \"poDetails\": [{\"poNumber\": \"014753662\", \"sourceNumber\": \"32612\", \"baseDiv\": \"1\", \"srcCountryCode\": \"US\", \"poStatus\": \"Active\", \"poLineDetails\": [{\"poLineNumber\": \"1\", \"itemNumber\": \"553416891\", \"poVnpkQty\": \"60\", \"vnpk\": \"10\", \"whpk\": \"10\", \"whpkSellPrice\": \"13.9\", \"ovgQty\": \"6\", \"ti\": \"12\", \"hi\": \"5\", \"itemUpc\": \"00715141113563\", \"caseUpc\": \"10715141613053\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020033326\", \"messageId\": \"70bb8b2f-e6b7-476c-b8d7-c10d352631fd\", \"childContainers\": [], \"receivedQuantity\": \"60\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2021-02-01\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Intact\", \"shipGroupId\": \"10010\", \"isMergeable\": true, \"weight\": \"26.5\", \"height\": \"14.4\", \"width\": \"12.5\", \"depth\": \"12.9\", \"wareHouseGroupCode\": \"DD\", \"wareHouseAreaCode\": \"2\", \"samePalletIndicator\": \"1\", \"xrefId\": \"770286\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2021-02-01\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 26.5, \"croInd\": \"cro\", \"recvQty\": 60, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"2\", \"itemNumber\": \"564508244\", \"poVnpkQty\": \"108\", \"vnpk\": \"10\", \"whpk\": \"10\", \"whpkSellPrice\": \"13.9\", \"ovgQty\": \"10\", \"ti\": \"12\", \"hi\": \"9\", \"itemUpc\": \"00205332000005\", \"caseUpc\": \"10205332000002\", \"receivingInstructions\": [{\"parentContainer\": \"A67389000020034657\", \"messageId\": \"d5ead74a-c1f7-4c66-a278-e27701237a7a\", \"childContainers\": [], \"receivedQuantity\": \"108\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2021-03-27\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"Y\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"3\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10018\", \"isMergeable\": true, \"weight\": \"11.3\", \"height\": \"3.8\", \"width\": \"8.2\", \"depth\": \"16.6\", \"wareHouseGroupCode\": \"DD\", \"wareHouseAreaCode\": \"2\", \"samePalletIndicator\": \"1\", \"xrefId\": \"668855\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2021-02-02\", \"mergeable\": true }, \"isVariableWeight\": true, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 11.3, \"croInd\": \"cro\", \"recvQty\": 108, \"osdrInd\": \"s\"}, {\"poLineNumber\": \"3\", \"itemNumber\": \"570367405\", \"poVnpkQty\": \"48\", \"vnpk\": \"5\", \"whpk\": \"5\", \"whpkSellPrice\": \"13.9\", \"ovgQty\": \"4\", \"ti\": \"16\", \"hi\": \"3\", \"itemUpc\": \"00841152001985\", \"caseUpc\": \"10841152001982\", \"receivingInstructions\": [{\"parentContainer\": \"B67389000020032953\", \"messageId\": \"045fee72-7be1-45f9-b1e0-1fa39cdf0b5e\", \"childContainers\": [], \"receivedQuantity\": \"40\", \"channelType\": \"SSTKU\", \"destNumber\": \"32610\", \"isPbyl\": false, \"isShipOut\": true, \"isVTR\": false, \"isDamage\": false, \"orderIds\": [], \"vtrQty\": 0, \"salesQty\": 0, \"onHoldStatus\": false, \"isPbylTripExecuted\": false, \"isGFCS\": false, \"damageQty\": 0, \"rotateDate\": \"2020-09-14\", \"adjustedQty\": 0, \"vtrContainerOrderIds\": [] } ], \"thorUnitsPer\": 0, \"boh\": 0, \"wac\": 0, \"promoInd\": \"N\", \"witronItemDetails\": {\"maxCube\": \"75.0\", \"warehouseRotationTypeCode\": \"2\", \"maxHeight\": \"90.0\", \"maxWeight\": \"2736.0\", \"outboundStackGroup\": \"Normal\", \"shipGroupId\": \"10034\", \"isMergeable\": true, \"weight\": \"3.3245368\", \"height\": \"3.11023622047244\", \"width\": \"9.88188976377953\", \"depth\": \"14.6850393700787\", \"wareHouseGroupCode\": \"F\", \"wareHouseAreaCode\": \"4\", \"samePalletIndicator\": \"1\", \"xrefId\": \"728806\", \"profiledWarehouseArea\": \"OPM\", \"receiveDate\": \"2020-09-14\", \"mergeable\": true }, \"isVariableWeight\": false, \"weight\": 0, \"damageQty\": \"0\", \"shortQty\": \"0\", \"rejectQty\": \"0\", \"waw\": 0, \"totalWeight\": 0, \"averageWeightPerCase\": 3.325, \"croInd\": \"cro\", \"recvQty\": 40, \"osdrInd\": \"o\"} ], \"uuid\": [\"3879bbb5-b7bd-4b48-89e3-583dbfd7fa30\"] } ], \"deliveryDetails\": [{\"inboundDoorNumber\": \"118\", \"itemLabelId\": [], \"inboundTrailerNumber\": \"T33401865\", \"poNumbers\": [\"014753662\"], \"dockTags\": [], \"doorType\": \"online\", \"deliveryName\": \"D1\", \"deliveryNumber\": \"33401865\", \"deliveryStatus\": \"Create_Delivery\"} ], \"outboundDetails\": [], \"containerDetails\": [] } }");

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Testflow data before Pallet Correction : {}", testFlowData);

			parsedJson = JsonPath.parse(testFlowData);

			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");
			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					ReceivingInstruction receivingInstruction = new ReceivingInstruction();
					logger.info("PO Num and line count: {}  {} ", poNumber, poLineNumber);

					List<String> contrList = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[*].parentContainer");
					logger.info("Pallet count: {} ", contrList.size());

					String vtrCntr = contrList.get(0).toString();
					int cntrQuantity;
					int tiHiValue;

					List<String> ti = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].ti");

					List<String> hi = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber + "')].hi");

					tiHiValue = Integer.parseInt(ti.get(0).toString()) * Integer.parseInt(hi.get(0).toString());

					JSONArray receivingInstructionArraySstk = parsedJson
							.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
									+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
									+ "')].receivingInstructions[*]");

					JSONArray ctrQty = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
							+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
							+ "')].receivingInstructions[?(@.parentContainer == '" + vtrCntr + "')].receivedQuantity");

					cntrQuantity = Integer.parseInt(ctrQty.get(0).toString());

					ReceivingPage.doPalletCorrection(vtrCntr, cntrQuantity, tiHiValue, poLineNumber, val);
				}
			}

			ReceivingPage.closeDiver();
		} catch (AssertionError |

				FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	public void fullReceivingReceiveBySellDateWitron(List<String> itemOnPoList, String poNumber, String itemUPC,
			int maxReceiveQty, String receiveType, int overage, String rotateDate, String tempTiHi, String poLineNumber,
			int damageQty, int rejectQty, int recvQty) {

		boolean receiveCompleteFlag = false;
		String croAction = null;
		if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {

			if (overage != 0) {
				maxReceiveQty = maxReceiveQty + overage;
			}

			while (maxReceiveQty != 0) {

				int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
				logger.info("Max Receive Qty:{}", maxReceiveQty);
				logger.info("Quantity to receive :{}", qtyToReceive);

				if (tempTiHi.length() == 0) {
					logger.info("Temp ti hi if : {}{} ", tempTiHi, tempTiHi.length());

				} else {
					logger.info("Temp ti hi else: {} {}", tempTiHi, tempTiHi.length());
					boolean flag = ReceivingPage.verifyUpdateTiHi(tempTiHi);
					Assert.assertTrue(ErrorCodes.RECEIVING_TEMP_TI_HI_VALIDATION, flag);
				}

				if (maxReceiveQty != 0 && receiveType.contains("Partially")) {

					qtyToReceive = qtyToReceive - 40;

					ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
					if (rotateDate != null) {
						ReceivingPage.selectExpiryDateWitron(rotateDate);
					}
					ReceivingPage.clickOnReceiveButton();
					ReceivingPage.clickOnFinshPalletButtonWitron();
					ReceivingPage.clickOnFinshPalletPopupButton();
					ReceivingPage.clickOnCloseButtonWitron();
					receiveCompleteFlag = true;
					break;
				}

				if (maxReceiveQty < qtyToReceive) {
					qtyToReceive = maxReceiveQty;
					ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
					if (rotateDate != null) {
						ReceivingPage.selectExpiryDateWitron(rotateDate);
					}
					ReceivingPage.clickOnReceiveButton();
					ReceivingPage.clickOnFinshPalletButtonWitron();
					ReceivingPage.clickOnFinshPalletPopupButton();
					ReceivingPage.clickOnCloseButtonWitron();
				} else {
					ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
					if (rotateDate != null) {
						ReceivingPage.selectExpiryDateWitron(rotateDate);
					}
					ReceivingPage.clickOnReceiveButton();

					ReceivingPage.clickOnCloseButtonWitron();

				}
//				ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
//				if (rotateDate != null) {
//					ReceivingPage.selectExpiryDateWitron(rotateDate);
//				}
//				ReceivingPage.clickOnReceiveButton();
//				ReceivingPage.clickOnCloseButtonWitron();

				maxReceiveQty = maxReceiveQty - qtyToReceive;
				logger.info("Max Receive Qty after receiving:{}", maxReceiveQty);

				if (maxReceiveQty != 0 && !receiveType.contains("partial")) {
					ReceivingPage.scanUPC(itemUPC);
					ReceivingPage.validateAndSelectMultiLine(poLineNumber, croAction);

					ReceivingPage.validateSelectPalletTypeScreen();

				} else if (maxReceiveQty == 0) {
					receiveCompleteFlag = true;
					logger.info("exiting the scan upc loop");
					break;
				}

			}
			if (!receiveCompleteFlag && !ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
				errorScenarios(itemUPC);
			}
		}
	}

	public void osdrReceivingWitron(List<String> itemOnPoList, String poNumber, String itemUPC, int maxReceiveQty,
			String receiveType, int overage, String rotateDate, String tempTiHi, String poLineNumber, int damageQty,
			int rejectQty, int recvQty, String croInd) {

		boolean receiveCompleteFlag = false;
		int count = 0;
		if (ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {

			if (overage != 0) {
				maxReceiveQty = maxReceiveQty + overage;
			}

			if (croInd.contains("cro")) {

				int qtyToReceive = 0;
				while (recvQty != 0) {

					qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
					logger.info("Max PO Receive Qty:{}", maxReceiveQty);
					logger.info("Receive QTy receive :{}", recvQty);
					logger.info("Quantity to receive :{}", qtyToReceive);

					if (receiveType.contentEquals("completely")) {

						if (tempTiHi.length() == 0) {
							logger.info("Temp ti hi if : {}{} ", tempTiHi, tempTiHi.length());

						} else if (tempTiHi.contentEquals("556032643")) {
						} else {
							logger.info("Temp ti hi else: {} {}", tempTiHi, tempTiHi.length());
							boolean flag = ReceivingPage.verifyUpdateTiHi(tempTiHi);
							Assert.assertTrue(ErrorCodes.RECEIVING_TEMP_TI_HI_VALIDATION, flag);
						}
					}

					if (maxReceiveQty > recvQty) {
						if (qtyToReceive > recvQty) {
							// For Partial Pallet Case
							ReceivingPage.enterQtyToReceive(String.valueOf(recvQty));
							if (rotateDate != null) {
								ReceivingPage.selectExpiryDateWitron(rotateDate);
							}
							ReceivingPage.clickOnReceiveButton();
//							ReceivingPage.clickOnFinshPalletButtonWitron();
//							ReceivingPage.clickOnFinshPalletPopupButton();
//							ReceivingPage.clickOnCloseButtonWitron();
							ReceivingPage.clickOnPalletCompleted();

							recvQty = 0;
						} else {

							ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
							recvQty = recvQty - qtyToReceive;
							logger.info("Receive QTy receive :{}", recvQty);

							if (rotateDate != null && receiveType.contentEquals("overage")
									&& poLineNumber.contains("1")) {
								DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

//								Calendar cal = Calendar.getInstance();
								Date date = Calendar.getInstance().getTime();
								String rotateDateUpdated = dateFormat.format(date);
								logger.info("Expiry Date :{} ", rotateDateUpdated);

								ReceivingPage.selectExpiryDateWitron(rotateDateUpdated);

							} else {
								if (rotateDate != null) {
									ReceivingPage.selectExpiryDateWitron(rotateDate);
								}
							}

							if (receiveType.contentEquals("overage") && poLineNumber.contains("1") && count == 0) {

								ReceivingPage.handleCloseDate();

							} else {
								ReceivingPage.clickOnReceiveButton();
							}
							count = count + 1;
							logger.info("Count Value :{} ", count);

							// ReceivingPage.clickOnCloseButtonWitron();
							ReceivingPage.clickOnPalletCompleted();

							if (count == 2 && poLineNumber.contains("1")) {
								receiveCompleteFlag = true;
								logger.info("exiting the scan upc loop for line 1");
								break;
							}
							if (recvQty != 0) {
								logger.info("validate all the values {} {} {} {}", count, recvQty, qtyToReceive,
										poLineNumber);

								ReceivingPage.scanUPC(itemUPC);
								boolean flag = ReceivingPage.multiLinevailableOrNot();
								if (flag) {
									ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);
								}
								ReceivingPage.validateSelectPalletTypeScreen();
							}
						}
						if (recvQty == 0 && receiveType.contentEquals("overage") && poLineNumber.contains("2")
								&& count == 4) {
							ReceivingPage.scanUPC(itemUPC);
							boolean flag = ReceivingPage.multiLinevailableOrNot();
							if (flag) {
								ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);

							}
							ReceivingPage.validateSelectPalletTypeScreen();
							logger.info("Entered into overage block {} {} {} ", count, recvQty, qtyToReceive);

							ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));

							logger.info("Entered into overage block post reeceive deduction {} {} {} {}", count,
									recvQty, qtyToReceive, poLineNumber);
							ReceivingPage.selectExpiryDateWitron(rotateDate);
							ReceivingPage.clickOnReceiveButton();
							ReceivingPage.clickOnPalletCompleted();
///Receive Post overage override.

							ReceivingPage.scanUPC(itemUPC);
							boolean flag1 = ReceivingPage.multiLinevailableOrNot();
							if (flag1) {
								ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);
								ReceivingPage.handleOverageAlert(maxReceiveQty);
								ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);

							}
							ReceivingPage.validateSelectPalletTypeScreen();
							logger.info("Entered into overage block {} {} {} ", count, recvQty, qtyToReceive);

							ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
							// validtae here total received so far
							logger.info("Entered into overage block post reeceive deduction {} {} {} {}", count,
									recvQty, qtyToReceive, poLineNumber);
							ReceivingPage.selectExpiryDateWitron(rotateDate);
							ReceivingPage.clickOnReceiveButton();
							ReceivingPage.clickOnPalletCompleted();

							ReceivingPage.scanUPC(itemUPC);
							boolean flag3 = ReceivingPage.multiLinevailableOrNot();
							if (flag3) {
								ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);

							}
							ReceivingPage.validateSelectPalletTypeScreen();
							logger.info("Entered into overage block {} {} {} ", count, recvQty, qtyToReceive);

							ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));

							logger.info("Entered into overage block post reeceive deduction {} {} {} {}", count,
									recvQty, qtyToReceive, poLineNumber);
							ReceivingPage.selectExpiryDateWitron(rotateDate);
							ReceivingPage.clickOnReceiveButton();
							ReceivingPage.clickOnPalletCompleted();

							receiveCompleteFlag = true;
							logger.info("exiting the scan upc loop");
							break;

						} else if (recvQty == 0) {
							receiveCompleteFlag = true;
							logger.info("exiting the scan upc loop");
							break;
						}
					} else if (maxReceiveQty == recvQty) {
						if (qtyToReceive > recvQty) {
							ReceivingPage.enterQtyToReceive(String.valueOf(recvQty));

							if (rotateDate != null) {
								ReceivingPage.selectExpiryDateWitron(rotateDate);
							}
							ReceivingPage.clickOnReceiveButton();
//							ReceivingPage.clickOnFinshPalletButtonWitron();
//							ReceivingPage.clickOnFinshPalletPopupButton();
//							ReceivingPage.clickOnCloseButtonWitron();
							ReceivingPage.clickOnPalletCompleted();
							recvQty = maxReceiveQty - recvQty;
							if (recvQty != 0) {
								ReceivingPage.scanUPC(itemUPC);
								boolean flag = ReceivingPage.multiLinevailableOrNot();
								if (flag) {
									ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);
								}
								ReceivingPage.validateSelectPalletTypeScreen();
							}
						} else {
							ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
							recvQty = recvQty - qtyToReceive;

							if (rotateDate != null) {
								ReceivingPage.selectExpiryDateWitron(rotateDate);
							}
							ReceivingPage.clickOnReceiveButton();
							// ReceivingPage.clickOnCloseButtonWitron();
							ReceivingPage.clickOnPalletCompleted();
							if (recvQty != 0) {
								ReceivingPage.scanUPC(itemUPC);
								if (receiveType.contains("Correction")) {
									ReceivingPage.clickOnReceiveCorrectionBtn();
								}
								boolean flag = ReceivingPage.multiLinevailableOrNot();
								if (flag) {
									ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);
								}
								ReceivingPage.validateSelectPalletTypeScreen();
							}
						}
						if (recvQty == 0) {
							receiveCompleteFlag = true;
							logger.info("exiting the scan upc loop");
							break;
						}

					} else if (maxReceiveQty < recvQty) {
						if (qtyToReceive > recvQty) {
							ReceivingPage.enterQtyToReceive(String.valueOf(recvQty));

							if (rotateDate != null) {
								ReceivingPage.selectExpiryDateWitron(rotateDate);
							}
							ReceivingPage.clickOnReceiveButton();
							ReceivingPage.clickOnFinshPalletButtonWitron();
							ReceivingPage.clickOnFinshPalletPopupButton();
							ReceivingPage.clickOnCloseButtonWitron();
							recvQty = 0;
						} else {
							ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
							recvQty = recvQty - qtyToReceive;

							if (rotateDate != null) {
								ReceivingPage.selectExpiryDateWitron(rotateDate);
							}
							ReceivingPage.clickOnReceiveButton();
							// ReceivingPage.clickOnCloseButtonWitron();
							ReceivingPage.clickOnPalletCompleted();
							if (recvQty != 0) {
								ReceivingPage.scanUPC(itemUPC);
								boolean flag = ReceivingPage.multiLinevailableOrNot();
								if (flag) {
									ReceivingPage.validateAndSelectMultiLine(poLineNumber, croInd);
								}
								ReceivingPage.validateSelectPalletTypeScreen();
							}
						}
						if (recvQty == 0) {
							receiveCompleteFlag = true;
							logger.info("exiting the scan upc loop");
							break;
						}

					}

				}
				if (!receiveCompleteFlag && !ReceivingPage.iscontainerReceive_NewPalletPageDisplayed()) {
					errorScenarios(itemUPC);
				}
			} else if (croInd.contains("notBOL")) {
				int qtyToReceive = Integer.parseInt(ReceivingPage.getQtyToReceive());
				ReceivingPage.enterQtyToReceive(String.valueOf(qtyToReceive));
				if (rotateDate != null) {
					ReceivingPage.selectExpiryDateWitron(rotateDate);
				}
				ReceivingPage.clickOnReceiveButtonWitron(croInd);

			}
		}
	}

	public void selectManualReceiving() {
		ReceivingPage.selectManualReceiving();
	}

	public void clickonBackArrow() {
		ReceivingPage.clickOnBackArrow();

	}

	@Step
	public void reReceiveProblem() {
		try {
			String testData = String.valueOf(threadLocal.get().get("testFlowData"));
			logger.info("Test data before re-receiving : {}", testData);
			JSONArray problemContainerArray = JsonPath.read(testData, "$..problemDetails..problemContainer");
			String problemContainer = (String) problemContainerArray.get(0);
			JSONArray problemQtyArray = JsonPath.read(testData, "$..problemDetails..problemQty");
			String problemQty = (String) problemContainerArray.get(0);
			ReceivingPage.clickOnReceiveMenu();
			ReceivingPage.clickOnProbrecvBtn();
			ReceivingPage.scanProblemContainer(problemContainer);
			ReceivingPage.clickOnReceiveProbCntr();
			ReceivingPage.inputReceiveQty(problemQty);
			ReceivingPage.clickOnProbrecv();
			ReceivingPage.clickOnFinishPallet();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at re-receiving ", e);
		}
	}

	@Step
	public void navigateToDSDCScreen() {
		try {
			ReceivingPage.clickOnRecevingRightMenu();
			ReceivingPage.clickOnDSDCOption();
			ReceivingPage.checkForDSDCPage();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("unable to navigate to DSDC screen ", e);
		}
	}

	@Step
	public void selectDsdcPoAndClickNext() {
		try {
			ReceivingPage.clickOnPoCheckbox();
			ReceivingPage.clickOnNextBtn();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("unable to select PO  ", e);
		}
	}

	@Step
	public void startReceivingDsdcOrPocon(String poType) {
		try {
			if (Config.DC != DC_TYPE.ATLAS) {
				searchforPrinter();
				selectOnlinePrinter();
				scanDoor();
			}
			List<String> sourceDCList = parsedJson.read(SOURCE_DC_LIST_JSON_PATH);
			Set<String> sourceDCSet = new HashSet<>();
			for (int i = 0; i < sourceDCList.size(); i++) {
				sourceDCSet.add(sourceDCList.get(i));
			}
			for (String sourceDC : sourceDCList) {
				// ReceivingPage.selectSourceNumber(sourceDC);
				List<String> poNumberList = parsedJson.read(javaUtils.format(LIST_OF_PO_NUMBERS_JSON_PATH, sourceDC));
				for (String poNumber : poNumberList) {
					int poQty = 0;
					List<String> poQtyList = parsedJson.read(javaUtils.format(PO_VNPK_QTY_JSON_PATH, poNumber));
					for (String poQtyStr : poQtyList) {
						poQty = poQty + Integer.valueOf(poQtyStr);
					}
					ReceivingPage.enterQtyToReceivingField(poNumber, String.valueOf(poQty));
				}
				ReceivingPage.clickOnPrintLabelButton();
				String containerResponse;
				if (poType.equalsIgnoreCase("DSDC")) {
					ReceivingPage.checkForDSDCPalletCompletePage();
					ReceivingPage.clickOnCloseButtonDSDCScreen();
					containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
					logger.info("DSDC Container Response for the given delivery::{}", containerResponse);
					List<String> itemList = parsedJson.read(javaUtils.format(ITEM_NUMBERS_JSON_PATH, poNumberList.get(0)));
					receivingHelper.setReceivingInstructionForDSDCOrManualReceiving(containerResponse, poNumberList.get(0),
							itemList.get(0), "DSDC");
					logger.info("Receiving App :: Completed receiving for DSDC");

				} else if (poType.equalsIgnoreCase("POCON")) {
					ReceivingPage.checkForPOCONPalletCompletePage();
					ReceivingPage.clickOnCloseButtonPOCONScreen();
					containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
					logger.info("POCON Container Response for the given delivery::{}", containerResponse);
					List<String> itemList = parsedJson.read(javaUtils.format(ITEM_NUMBERS_JSON_PATH, poNumberList.get(0)));
					receivingHelper.setReceivingInstruction(containerResponse, poNumberList.get(0),
							itemList.get(0), "POCON");
					logger.info("Receiving App :: Completed receiving for POCON");

				}
			}
			ReceivingPage.closeDiver();
			logger.info("JSON:: " + threadLocal.get().get("testFlowData"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	public void validateReceivingVTR(String vtrType) {
		try {
			String testData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext parsedItemDetailsJson = JsonPath.parse(testData);
			List<String> vtrQtyList = null;
			List<String> cntrList = null;
			JSONArray listOfLines = JsonPath.read(testData, GET_POLINES);
			String linesString = listOfLines.toJSONString();
			List<PoLineDetail> linesList = objectMapper.readValue(linesString, new TypeReference<List<PoLineDetail>>() {
			});

			for (PoLineDetail detail : linesList) {
				if (vtrType.equals("receivingapp")) {
					vtrQtyList = parsedItemDetailsJson.read(
							"$.testFlowData.poDetails[*].poLineDetails[?(@.poLineNumber=='" + detail.getPoLineNumber()
									+ "')].receivingInstructions[?(@.isVTR==true)].receivedQuantity");

					cntrList = parsedItemDetailsJson.read(
							"$.testFlowData.poDetails[*].poLineDetails[?(@.poLineNumber=='" + detail.getPoLineNumber()
									+ "')].receivingInstructions[?(@.isVTR==true)].parentContainer");
					if (vtrQtyList.isEmpty()) {
						continue;
					}
				} else {
					vtrQtyList = parsedItemDetailsJson.read(
							"$.testFlowData.poDetails[*].poLineDetails[?(@.poLineNumber=='" + detail.getPoLineNumber()
									+ "')].receivingInstructions[?(@.isVTR==false)].receivedQuantity");

					cntrList = parsedItemDetailsJson.read(
							"$.testFlowData.poDetails[*].poLineDetails[?(@.poLineNumber=='" + detail.getPoLineNumber()
									+ "')].receivingInstructions[?(@.isVTR==false)].parentContainer");

					if (vtrQtyList.isEmpty()) {
						continue;
					}
				}
				int deltaQty = detail.getRecvQty() - Integer.parseInt(vtrQtyList.get(0));

				verifyContainerStatusAndQtyForVTR(cntrList.get(0), detail.getPoLineNumber(), String.valueOf(deltaQty));
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate VTR in Receiving", e);
		}
	}

	public void verifyUpcOnAttentionPopup() {
		Set<String> uniqueItems;
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		parsedJson = JsonPath.parse(testFlowData);
		List<String> poNumberList = parsedJson.read(PO_NUMBER_JSON_PATH);

		for (String poNumber : poNumberList) {
			List<String> itemList = parsedJson
					.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..itemNumber");
			uniqueItems = receivingHelper.getUniqueItemNumbers(itemList);
			Iterator<String> iterator = uniqueItems.iterator();
			while (iterator.hasNext()) {
				String itemNum = iterator.next();
				List<String> detail = returnUpcOpenQty(poNumber, itemNum);
				String itemUPC = detail.get(0);
				Assert.assertEquals(ErrorCodes.RECEIVING_SCANNNED_ITEM_UPC_NOT_MATCHING, "UPC " + itemUPC,
						ReceivingPage.verifyItemUpcOnAttentionPopup());
			}
		}
	}

	@Step
	public void verifyAndAcceptLimitedQtyAttentionPopup() {
		try {
			logger.info("Verifying the Scanned Upc Present on Limited Qty popup");
			verifyUpcOnAttentionPopup();
			logger.info("Verifying the Error Message displayed on Limited Qty popup");
			Assert.assertTrue(ErrorCodes.RECEIVING_LIMITED_QTY_ATTENTION_POPUP_MSG_NOT_FOUND,
					ReceivingPage.isLimitedQtyAttentionMsgDisplayed());
			Assert.assertTrue(ErrorCodes.RECEIVING_ATTENTION_POPUP_ERROR_MSG_NOT_FOUND,
					ReceivingPage.isErrorMsgDisplayed());
			logger.info("Accepting Limited Qty popup");
			ReceivingPage.clickOnAcceptButton();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying and accepting Limited Qty Popup ", e);
		}
	}

	@Step
	public void verifyAndAcceptLithiumIonAttentionPopup() {
		try {
			logger.info("Verifying the Scanned Upc Present on Lithium Ion popup");
			verifyUpcOnAttentionPopup();
			logger.info("Verifying the Error Message displayed on Lithium Ion popup");
			Assert.assertTrue(ErrorCodes.RECEIVING_LITHIUM_ION_ATTENTION_POPUP_MSG_NOT_FOUND,
					ReceivingPage.isLithiumIonAttentionMsgDisplayed());
			Assert.assertTrue(ErrorCodes.RECEIVING_ATTENTION_POPUP_ERROR_MSG_NOT_FOUND,
					ReceivingPage.isErrorMsgDisplayed());
			logger.info("Accepting Lithium Ion popup");
			ReceivingPage.clickOnAcceptButton();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while verifying and accepting Lithium Ion Popup ", e);
		}
	}

	@Step
	public void clickOnYesForMultiPOReceiving() {
		ReceivingPage.selectAllPoAndclickOnNextInDSDCScreen();
		ReceivingPage.clickOnYesForMultiPOReceiving();
	}

	@Step
	public void startReceivingMultiDsdcPO() {
		try {
			if (Config.DC != DC_TYPE.ATLAS) {
				searchforPrinter();
				selectOnlinePrinter();
				scanDoor();
			}
			List<String> poQtyList = null;
			List<String> sourceDCList = parsedJson.read(SOURCE_DC_LIST_JSON_PATH);
			Set<String> sourceDCSet = new HashSet<>();
			for (int i = 0; i < sourceDCList.size(); i++) {
				sourceDCSet.add(sourceDCList.get(i));
			}
			for (String sourceDC : sourceDCSet) {
				// ReceivingPage.selectSourceNumber(sourceDC);
				List<String> poNumberList = parsedJson.read(javaUtils.format(LIST_OF_PO_NUMBERS_JSON_PATH, sourceDC));
				for (String poNumber : poNumberList) {
					poQtyList = parsedJson.read(javaUtils.format(PO_VNPK_QTY_JSON_PATH, poNumber));
					poQtyList.addAll(poQtyList);
				}
				ReceivingPage.enterQtyToReceiveMultiPO(poQtyList);
				ReceivingPage.clickOnPrintLabelButton();
				ReceivingPage.checkForDSDCPalletCompletePage();
				ReceivingPage.clickOnCloseButtonDSDCScreen();
				for (String poNumber : poNumberList) {
				String containerResponse;
				containerResponse = receivingHelper.containerResponseForDelivery(deliveryNumber);
				logger.info("ContainerResponse for the given delivery::{}", containerResponse);
				List<String> itemList = parsedJson.read(javaUtils.format(ITEM_NUMBERS_JSON_PATH, poNumberList.get(0)));
				receivingHelper.setReceivingInstructionForDSDCOrManualReceiving(containerResponse, poNumber,
						itemList.get(0), "DSDC");
			}}
			logger.info("Receiving App :: Completed receiving for DSDC");
			ReceivingPage.closeDiver();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving the items", e);
		}
	}

	@Step
	public void selectPOCONPoAndClickNext() {
		try {
			ReceivingPage.clickOnPOCONcheckbox();
			ReceivingPage.clickOnNextBtn();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("unable to select POCON PO  ", e);
		}
	}

	@Step
	public void navigateToPOCONScreen() {
		try {
			ReceivingPage.clickOnRecevingRightMenu();
			ReceivingPage.clickOnPOCONOption();
			ReceivingPage.checkForPOCONPage();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("unable to navigate to POCON screen ", e);
		}
	}
}
