package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.annotations.findby.By;
import spring.SpringTestConfiguration;

public class ProblemReportExceptionPage extends MobilePageObject{
	Logger logger = LogManager.getLogger(this.getClass());
	
	public ProblemReportExceptionPage(WebDriver driver){
        super(driver);
    }
	
	//login elements
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/signin_username_button")
	private WebElement signIn_button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/shared_login_username_edit_text']")
	private WebElement userName_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/shared_login_password_edit_text']")
	private WebElement password_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.auth.app:id/shared_login_sign_in_button']")
	private WebElement sign_In_Button;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Select an exception type')]")
	private WebElement homePage_Text;

	@AndroidFindBy(xpath = "//android.widget.RadioButton[@text='PO Issue']")
	private WebElement poIssue_RadioBttn;
	
	@AndroidFindBy(xpath = "//android.widget.RadioButton[contains(@text,'Misshipment')]")
	private WebElement misshipment_RadioBttn;
	
	@AndroidFindBy(xpath = "//android.widget.RadioButton[contains(@text,'Item Issue')]")
	private WebElement itemIssue_RadioBttn;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Next']")
	private WebElement next_Button;
	
	//problem types
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Delivery Number']")
	private WebElement deliveryNum_Textbox;
	
	public void loginToApp(String userName,String password) {
		AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),signIn_button);
		signIn_button.click();
		AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),userName_Textbox);
		userName_Textbox.sendKeys(userName);
		AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),password_Textbox);
		password_Textbox.sendKeys(password);
		AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),sign_In_Button);
		sign_In_Button.click();
	}

	public ProblemExceptionSubTypePage selectPOIssueType() {
		try {
			Thread.sleep(5000);
			AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),poIssue_RadioBttn);
			poIssue_RadioBttn.click();
			AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),next_Button);
			next_Button.click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new ProblemExceptionSubTypePage(AppiumHelper.getWebdriverForPage());
	}
	
	public ProblemExceptionSubTypePage selectMisshipmentType() {
		try {
			Thread.sleep(5000);
			AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),misshipment_RadioBttn);
			misshipment_RadioBttn.click();
			AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),next_Button);
			next_Button.click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new ProblemExceptionSubTypePage(AppiumHelper.getWebdriverForPage());
	}
	
	public ProblemExceptionSubTypePage selectItemIssueType() {
		try {
			Thread.sleep(5000);
			AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),itemIssue_RadioBttn);
			itemIssue_RadioBttn.click();
			AppiumHelper.FluentWaitUntilVisible(AppiumHelper.getWebdriverForPage(),next_Button);
			next_Button.click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new ProblemExceptionSubTypePage(AppiumHelper.getWebdriverForPage());
	}

	public void closeDriver(WebDriver driver) {
		driver.quit();
		/*if(env.equalsIgnoreCase("LOCAL")) {
			new ContextDriver().getAppiumDriverInstance(null,null,null).quit();
		}else {
			new ContextDriver().getAppiumGridDriverInstance(null, null, null, null).quit();
		}*/
		
	}
}
