package com.walmart.supplychain.nextgen.yms.steps.ui;

import static net.serenitybdd.rest.SerenityRest.given;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.jms.JMSException;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.jms.JmsException;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.loading.loadingOutboundDoorAssign;
import com.walmart.framework.supplychain.domain.yms.YmsDoorAssign;
import com.walmart.framework.supplychain.domain.yms.YmsGateOut;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SchedulerConnectionUtil;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMHelper;
import com.walmart.supplychain.nextgen.loading.steps.db.LoadingDBSteps;
import com.walmart.supplychain.nextgen.loading.steps.ui.LoadingHelper;
import com.walmart.supplychain.nextgen.of.steps.db.RDCOrderFulfillmentHelper;

import android.widget.Switch;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.pages.PageObject;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class YMSHelper extends SerenityHelper {

	@Autowired
	TextParser textParser;
	
	@Autowired
	SpringJmsUtils springJmsUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	IDMHelper idmHelper;

	@Autowired
	Environment environment;

	@Autowired
	LoadingDBSteps loadingDBSteps;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	Environment queries;

	@Autowired
	StratiConnectionUtil stratiConnectionUtil;

	@Autowired
	SchedulerConnectionUtil schedulerConnectionUtil;
	
	@Autowired
	RDCOrderFulfillmentHelper rdcOrderFulfillmentHelper;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	LoadingHelper loadingHelper;
	
	@Autowired
	JavaUtils javaUtil;
	
	@Autowired
	BYUiHelper byUiHelper;

	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	JsonUtils jsonUtils = new JsonUtils();
	PropertyResolver envPropResolver = new PropertyResolver();
	ObjectMapper objectMapper = new ObjectMapper();
	JavaUtils javaUtils = new JavaUtils();
	private String[] doors = new String[2];
	private static final String RDCDELIVERYJSONPATH = "$..deliveryDetailsRDC[*].deliveryNumber";
	private static final String QUEUE = "queue";
	private static final long MAX_THREAD_WAIT_FOR_DOOR_AVAILABILITY_IN_MS = 300000;
	private List<String> inboundOccupiedDoors = Collections.synchronizedList(new ArrayList<String>());
	private List<String> outboundOccupiedDoors = Collections.synchronizedList(new ArrayList<String>());
	private static final String ALPHA_NUMERIC_DOOR_LITERAL = "D";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String OUTBOUND_DOORS_JSONPATH = "$.testFlowData.outboundDetails[*].outboundDoorNumber";
	private final String simple_date_time_format = "yyyy-MM-dd HH:mm:ss.SSS";
	private String testFlowData;
	private static final String DELIVERY_JSON_PATH = "$..deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber";
	private static final String DOOR_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..inboundDoorNumber";
	private static final String YARD_ZONE_JSON_PATH = "$.testFlowData.deliveryDetails..inboundYardZone";
	private static final String TRAILER_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..inboundTrailerNumber";
	
	private static final String OB_YARD_ZONE_JSON_PATH = "$.testFlowData.outboundDetails..ob_YardZone";
	private static final String OB_TRAILER_NUMBER_JSON_PATH = "$.testFlowData.outboundDetails..ob_TrailerNumber";
	
	private static final String DELIVERY_NUMBER_JSON_PATH = "$..deliveryDetails..deliveryNumber";
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	Response response;
	
	public List<String> getInboundOccupiedDoorsList() {
		return inboundOccupiedDoors;
	}

	public List<String> getOutboundOccupiedDoorsList() {
		return outboundOccupiedDoors;
	}

	public boolean isElementVisible(WebElement element) {
		boolean displayed = false;
		try {
			WebDriverWait wait = new WebDriverWait(getDriverInstance(), 3);
			element = wait.until(ExpectedConditions.visibilityOf(element));
			if (element.isDisplayed()) {
				displayed = true;
			}
		} catch (TimeoutException exe) {
			displayed = false;
		}
		return displayed;
	}

	public boolean isElementVisible(String xpath) {
		boolean displayed = false;
		try {
			WebDriverWait wait = new WebDriverWait(getDriverInstance(), 1);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			if (element.isDisplayed()) {
				displayed = true;
			}
		} catch (TimeoutException exe) {
			displayed = false;
		}
		return displayed;
	}

	public boolean isElementDisplayed(WebElement element) {
		boolean displayed = false;
		try {
			if (element.isDisplayed()) {
				displayed = true;
			}
		} catch (NoSuchElementException exe) {
			displayed = false;
		}
		return displayed;
	}

	public boolean isElementAvailable(String xpath) {
		boolean displayed = false;
		try {
			getDriverInstance().findElement(By.xpath(xpath));
			displayed = true;
		} catch (NoSuchElementException exe) {
			displayed = false;
		}
		return displayed;
	}

	public void switchWindows(WebElement element) {
		String mainWindow = getDriverInstance().getWindowHandle();
		Set<String> windowHandles = getDriverInstance().getWindowHandles();
		for (String childWindow : windowHandles) {
			if (!mainWindow.equalsIgnoreCase(childWindow)) {
				getDriverInstance().switchTo().window(childWindow);
				element.click();
			}
		}
		getDriverInstance().switchTo().window(mainWindow);
		getDriverInstance().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	public void waitUntilSpinnerNotVisible() {
		try {
			WebDriverWait wait = new WebDriverWait(getDriverInstance(), 60);
			logger.info("wait for loader");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='loadHolder']/img")));
			logger.info("found loader");
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@id='loadHolder']/img")));
			logger.info("loader disappeared");
		} catch (TimeoutException ex) {
			logger.info("Exceeded the timeout for loader.Proceeding");
		}
	}

	@SuppressWarnings("unchecked")
	public void publishGateOutEvent(String testFlowData) {

		String gateOutMesg = "";
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		try {
			List<OutboundDetail> outboundObj = (List<OutboundDetail>) jsonUtils.getPojoListfromPath(
					((JSONArray) JsonPath.read(testFlowData, "$.testFlowData.outboundDetails[*]")).toJSONString(),
					OutboundDetail.class);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		for (String destination : getDistinctDestinations(testFlowData)) {
			YmsGateOut gateOutMessage = constructGateOutMessage(testFlowData, destination);
			try {
				gateOutMesg = mapper.writeValueAsString(gateOutMessage);
				logger.info("Gate Out Message is :{}", gateOutMesg);
				if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.ACC) {
					stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_loading_yms_gateout_queue"),
							gateOutMesg, QUEUE, environment.getProperty("connection_factory"),
							environment.getProperty("loading_strati_username"),
							environment.getProperty("loading_strati"));
					logger.info("Published gateout to Loading");
					stratiConnectionUtil.publishStartiMessage(
							environment.getProperty("maas_inventory_yms_gateout_queue"), gateOutMesg, QUEUE,
							environment.getProperty("connection_factory"),
							environment.getProperty("inventory_strati_username"),
							environment.getProperty("inventory_strati"));
					logger.info("Published gateout to Inventory");
					stratiConnectionUtil.publishStartiMessage(
							environment.getProperty("maas_outbound_yms_gateout_queue"), gateOutMesg, QUEUE,
							environment.getProperty("connection_factory"),
							environment.getProperty("outbound_strati_username"),
							environment.getProperty("outbound_strati"));
					logger.info("Published gateout to Outbound");
					if (Config.DC == DC_TYPE.ACC) {
						stratiConnectionUtil.publishStartiMessage(
								environment.getProperty("maas_outbound_OT_gateout_queue"), gateOutMesg, QUEUE,
								environment.getProperty("connection_factory"),
								environment.getProperty("ot_strati_username"),
								environment.getProperty("ot_strati"));
					}else {
						stratiConnectionUtil.publishStartiMessage(
								environment.getProperty("maas_outbound_OT_gateout_queue"), gateOutMesg, QUEUE,
								environment.getProperty("connection_factory"),
								environment.getProperty("outbound_strati_username"),
								environment.getProperty("outbound_strati"));
					}
					logger.info("Published gateout to Order Tracker");

				} else {
					springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ, Config.DC,
							envPropResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "yms_gateout_topic", true),
							gateOutMesg);
					logger.info("Published GatOut Message to Topic");
				}

			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public void publishCreationOfContainerMessage(String dest, String trackingId) throws Exception {

		String creationOfContainerMessage = constructCreationOfContainerMessage(trackingId, dest);
		logger.info("Container creation Message is :{}", creationOfContainerMessage);
		logger.info(" Started publishing Container create event to Inventory");

		stratiConnectionUtil.publishStartiMessage(
				environment.getProperty("inventory_container_creation_queue"), creationOfContainerMessage, QUEUE,
				environment.getProperty("connection_factory"),
				environment.getProperty("inventory_strati_username"),
				environment.getProperty("inventory_strati"));
		logger.info("Published Container with id " + trackingId + " create event to Inventory");
	}
		


	@Autowired
	private ObjectMapper objmapper;

	public void doorAssignEventInbound(String testFlowData) {

		String doorType = "Inbound";
		String doorAssignMessage = "";
		List<DeliveryDetail> deliveryDetailObj = null;
		objmapper.enable(SerializationFeature.INDENT_OUTPUT);
		try {
			logger.info("testFlowData:{}", testFlowData);
			JSONArray deliveryDetailsArray = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[*]");
			logger.info("deliveryDetailsArrayYMS:{}", deliveryDetailsArray.toJSONString());
			deliveryDetailObj = (List<DeliveryDetail>) jsonUtils
					.getPojoListfromPath(deliveryDetailsArray.toJSONString(), DeliveryDetail.class);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		YmsDoorAssign doorAssignMesg = constructDoorAssignMessage(testFlowData, doorType, null);
		try {
			doorAssignMessage = objmapper.writeValueAsString(doorAssignMesg);
			logger.info("Door Assign Message from YMS is :{}", doorAssignMessage);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

			// publishDeliveryMessageToTopic(deliveryMessage); -- Currently
			// publishing to Maas queue

			stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_idm_ymsqueue"), doorAssignMessage,
					QUEUE, environment.getProperty("idm_connection_factory"),
					environment.getProperty("idm_starti_username"), environment.getProperty("idm_starti"));

		logger.info("Published Inbound Door assign message to Queue");
		deliveryDetailObj.get(0).setInboundDoorNumber(doorAssignMesg.getDoorNumber());
		deliveryDetailObj.get(0).setInboundTrailerNumber(doorAssignMesg.getTrailerId());
		try {
			JSONArray listOfDeliveryDetail = jsonUtils.converyListToJsonArray(deliveryDetailObj);
			testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listOfDeliveryDetail,
					"$.testFlowData.deliveryDetails");
			tl.get().put("testFlowData", testFlowData);
			logger.info("testFlowData after Door assign {}", tl.get().get("testFlowData"));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

	public void doorAssignEventOutbound(String testFlowData) {
		String doorType = "Outbound";
		String doorAssignMessage = "";
		ObjectMapper objmapper = new ObjectMapper();
		List<OutboundDetail> listOfOutboundObj = new ArrayList<>();
		objmapper.enable(SerializationFeature.INDENT_OUTPUT);
		for (String destination : getDistinctDestinations(testFlowData)) {
			YmsDoorAssign doorAssignMesg = constructDoorAssignMessage(testFlowData, doorType, destination);
			try {
				doorAssignMessage = objmapper.writeValueAsString(doorAssignMesg);
				logger.info("Door Assign Message from YMS is :{}", doorAssignMessage);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			
			if (Config.DC==DC_TYPE.ACC) {
				DocumentContext loadingResponseParsedJson = JsonPath.parse(doorAssignMessage);
				List<String> doorNumber  = loadingResponseParsedJson.read("$..doorNumber");
				List<String> trailerNumber  = loadingResponseParsedJson.read("$..trailerId");
				List<String> carrierCode  = loadingResponseParsedJson.read("$..carrier");
				List<String> trailerType  = loadingResponseParsedJson.read("$..trailerType");
				loadingOutboundDoorAssign loadingOutboudDoorAssignMssg = new loadingOutboundDoorAssign();
				loadingOutboudDoorAssignMssg.setDoorNbr(doorNumber.get(0));
				loadingOutboudDoorAssignMssg.setTrailerNbr(trailerNumber.get(0));
				loadingOutboudDoorAssignMssg.setCarrierCode(carrierCode.get(0));
				loadingOutboudDoorAssignMssg.setTrailerType(trailerType.get(0));
				ObjectMapper om = new ObjectMapper();
				
				Failsafe.with(retryPolicy).run(() -> {
					logger.info(om.writeValueAsString(loadingOutboudDoorAssignMssg).toString());
					logger.info(loadingHelper.getloadingHeaders().toString());
					logger.info(environment.getProperty("loading_door_trailer_mapping_uri"));
					response = SerenityRest.given().relaxedHTTPSValidation().contentType("application/json").headers(loadingHelper.getloadingHeaders()).body(om.writeValueAsString(loadingOutboudDoorAssignMssg).toString()).when().put(environment.getProperty("loading_door_trailer_mapping_uri"));
					
					logger.info(response.asString());
					com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.LOADING_UNABLE_TO_POST_DOOR_TRAILER_MAPP, Constants.SUCESS_STATUS_CODE,response.getStatusCode());

				});				
			}
			else {
			stratiConnectionUtil.publishStartiMessage(environment.getProperty("maas_loading_ymsqueue"),
				doorAssignMessage, QUEUE, environment.getProperty("loading_connection_factory"),
				environment.getProperty("loading_strati_username"),
				environment.getProperty("loading_strati"));
			}
			logger.info("Published Outbound Door assign message to Topic");
			OutboundDetail outboundDetail = new OutboundDetail();
			outboundDetail.setOutboundDoorNumber(doorAssignMesg.getDoorNumber().trim());
			outboundDetail.setTrailerNumber(doorAssignMesg.getTrailerId());
			outboundDetail.setDestNumber(destination);
			listOfOutboundObj.add(outboundDetail);
			try {
				JSONArray listofOutboundJson = jsonUtils.converyListToJsonArray(listOfOutboundObj);
				testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listofOutboundJson,
						"$.testFlowData.outboundDetails");
				tl.get().put("testFlowData", testFlowData);
				logger.info("testData {}", tl.get().get("testFlowData"));
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}

		}

	}

	public void doorAssignEventRDC(String testFlowData) {
		try {
			String doorAssignMessage = "";
			DocumentContext parsedJson = JsonPath.parse(testFlowData);
			List<String> deliveryNumberList = parsedJson.read(RDCDELIVERYJSONPATH);

			for (String deliveryNumber : deliveryNumberList) {
				rdcOrderFulfillmentHelper.clearInprocessandQueuedXdocRec();
				logger.info("Cleared XDOC records which are in IN_PROGRESS and QUEUED");
				YmsDoorAssign doorAssignMesg = constructDoorAssignMessageRDC(deliveryNumber);
				try {
					doorAssignMessage = objmapper.writeValueAsString(doorAssignMesg);
					logger.info("Door Assign Message from YMS is :{}", doorAssignMessage);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
				springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.AMQ, Config.DC ,
						envPropResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "yms_inbound_queue", true), doorAssignMessage);
				logger.info("Published Inbound GAteIn message to Queue");
			}
		} catch (JmsException e) {
			logger.error("Messaging Error:" + e);
			throw new AutomationFailure("Unable to publish door assign message");
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while publishing the door assign message");
		}
	}
	
	public void PublishReceivingReceiptEventRDC(String labelCout) {
		try {
			int labelCountInt=Integer.valueOf(labelCout);
			for (int i = 1; i <= labelCountInt; i++) {
				String baseReceiptsMessage = textParser.readTextFile(FileNames.RDC_RECEIVING_RECEIPTS_TEMPLATE_FILE);
				String containerLabel = "AUTO"+javaUtils.randonNumberGenerator(7)+javaUtils.randonNumberGenerator(7);
				String id = ""+javaUtils.randonNumberGenerator(3)+javaUtils.randonNumberGenerator(7)+javaUtils.randonNumberGenerator(7)+javaUtils.randonNumberGenerator(7);
				
				logger.info("containerLabel_"+i+" :{}", containerLabel);
//				logger.info("_id :{}", id);
				
				String receiptsMessage = javaUtils.format(baseReceiptsMessage,id, containerLabel);
//				logger.info("Inventory message :{}", receiptsMessage);
				
				springJmsUtils.sendMessageAMQRDC(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.AMQ, Config.DC ,
						environment.getProperty("receiving_amq_topic"), receiptsMessage);
				logger.info("Published Receiving receipts  to Topic");
				
				logger.info("Validating created container in Inventory for LPN: {}",containerLabel);
				
				Failsafe.with(retryPolicy).run(() -> {
					response = given().relaxedHTTPSValidation().headers(getInventoryHeaders()).when()
							.get(environment.getProperty("inventory_ep") + containerLabel
									+ environment.getProperty("inventory_ep_qp"));
//					logger.info("Waiting for Status 200 for Container Id:{}", containerLabel);
					com.walmart.framework.utilities.javautils.Assert.assertEquals(ErrorCodes.INVENTORY_INVALID_CONTAINER_RESPONSE, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					logger.info("Validated the response status returned for the LPN " + containerLabel
							+ " in Inventory and response {} ", response.asString());
				});
				Thread.sleep(5000);
			}
		} catch (JmsException e) {
			logger.error("Messaging Error:" + e);
			throw new AutomationFailure("Unable to Receiving receipt message");
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while publishing Receiving receipt message");
		}
	}
	
	public Headers getInventoryHeaders() {

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header appType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(appType);

		return new Headers(headerList);

	}


	private YmsGateOut constructGateOutMessage(String testFlowData, String destination) {

		JSONArray loadId = JsonPath.read(testFlowData,
				"$.testFlowData.outboundDetails[?(@.destNumber == '" + destination + "')].loadId");
		JSONArray trailerNumber = JsonPath.read(testFlowData,
				"$.testFlowData.outboundDetails[?(@.destNumber == '" + destination + "')].trailerNumber");
		YmsGateOut gateOutMessage = new YmsGateOut();
		gateOutMessage.setRouteNbr((String) loadId.get(0));
		gateOutMessage.setDcNbr(environment.getProperty("source_number"));
		gateOutMessage.setTelegramID("Y617711");
		gateOutMessage.setTrailerNbr((String) trailerNumber.get(0));
		gateOutMessage.setReeferActualTemp1("12");
		gateOutMessage.setReeferActualTemp2("12");
		gateOutMessage.setReeferActualTemp3("12");
		gateOutMessage.setReeferFuelLevel("100");
		gateOutMessage.setDriverID("adamb");
		gateOutMessage.setGateOutUserID("adamb");
		gateOutMessage.setDepartTimeStamp("2019-01-08 15:35:00.001 UTC");
		return gateOutMessage;
	}


	private String constructCreationOfContainerMessage(String trackingId, String destinationNum) throws Exception {
		String creationOfContainerMessage = "";
		String creationOfContainer = null;
		creationOfContainer = textParser.readTextFile(FileNames.ACC_CONTAINER_CREATION_MESSAGE);
		creationOfContainerMessage = javaUtils.format(creationOfContainer, trackingId, destinationNum );
		return creationOfContainerMessage;
	}

	private YmsDoorAssign constructDoorAssignMessage(String testFlowData, String doorType, String destination) {

		String testData = (String) tl.get().get("testFlowData");
		JSONArray deliveryNumbers = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[*].deliveryNumber");
		YmsDoorAssign doorAssignMessage = new YmsDoorAssign();
		doorAssignMessage.setDeliveryNumber((String) deliveryNumbers.get(0));
		doorAssignMessage.setSealNumber("SealNr");
		doorAssignMessage.setTrailerStatusCode("OB");
		doorAssignMessage.setCarrier("WM");
		String otherDoorAlreadyAssigned = System.getProperty("doorAlreadyAssigned");
		if(!(otherDoorAlreadyAssigned != null && otherDoorAlreadyAssigned.equalsIgnoreCase("true"))) {
			doorAssignMessage.setArrivalTimeStamp(javaUtils.getCurrentDateAndTime(simple_date_time_format));
		}
		doorAssignMessage.setDcNumber(environment.getProperty("dcNumber"));
		doorAssignMessage.setSubcenter("1");
		doorAssignMessage.setmoveType("Receiving");
		if (doorType.equalsIgnoreCase("Inbound")) {
			doorAssignMessage.setTrailerId("T" + (String) deliveryNumbers.get(0));

			if (Config.DC == DC_TYPE.ACC) {
				try {
					JSONArray listOfDoorType = JsonPath.read(testData, "$.testFlowData.deliveryDetails[*].doorType");
					String doorTypeString = listOfDoorType.toJSONString();
					List<String> doorTypeList = objectMapper.readValue(doorTypeString,
							new TypeReference<List<String>>() {
							});
					String doorTypeValue = doorTypeList.get(0);
					String isPureOfflineDoor = System.getProperty("pureOfflineDoor");
					String isOfflineDoor = System.getProperty("offlineDoor");
					if((isPureOfflineDoor != null && isPureOfflineDoor.equalsIgnoreCase("true")) || (isOfflineDoor != null && isOfflineDoor.equalsIgnoreCase("true"))){
						doorTypeValue = "offline";
					}
					if (doorTypeValue.equals("offline")) {
						if(isPureOfflineDoor != null && isPureOfflineDoor.equalsIgnoreCase("true")){
							String inboundDoorNumber = getFreeInboundDoor(envPropResolver
									.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_pureoffline_door_range", true));
							Assert.assertNotEquals("Door number can not be null", "", inboundDoorNumber);
							doorAssignMessage.setDoorNumber(inboundDoorNumber);
						} else {
							String inboundDoorNumber = getFreeInboundDoor(envPropResolver
									.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_offline_door_range", true));
							Assert.assertNotEquals("Door number can not be null", "", inboundDoorNumber);
							doorAssignMessage.setDoorNumber(inboundDoorNumber);
						}

					} else {
						String inboundDoorNumber = getFreeInboundDoor(envPropResolver
								.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_online_door_range", true));
						Assert.assertNotEquals("Door number can not be null", "", inboundDoorNumber);
						doorAssignMessage.setDoorNumber(inboundDoorNumber);
					}
				} catch (Exception e) {

					throw new AutomationFailure("Failed to assign doors for ACC", e);
				}

			} else if(Config.DC == DC_TYPE.PHARMACY) {
				String inboundDoorNumber = getFreeInboundDoor(
						envPropResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_door_range_pharmacy", true));
				Assert.assertNotEquals("All the doors are occupied with other deliveries", "", inboundDoorNumber);
				doorAssignMessage.setDoorNumber(inboundDoorNumber);
			}else {
				String inboundDoorNumber = getFreeInboundDoor(
						envPropResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_door_range", true));
				Assert.assertNotEquals("All the doors are occupied with other deliveries", "", inboundDoorNumber);
				doorAssignMessage.setDoorNumber(inboundDoorNumber);
			}
		} else {
			doorAssignMessage.setTrailerId("T" + (String) deliveryNumbers.get(0) + destination);
			String outboundDoorNumber = getFreeOutboundDoor(
					envPropResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "outbound_door_range", true));
			Assert.assertNotEquals("Door number can not be null", "", outboundDoorNumber);
			doorAssignMessage.setDoorNumber(outboundDoorNumber.trim());

		}

		doorAssignMessage.setTrailerType("53");
		doorAssignMessage.setTrailerTypeCode("34");
		doorAssignMessage.setTralrCntrlRecId("607754");
		return doorAssignMessage;
	}
	
	private YmsDoorAssign constructDoorAssignMessageWithoutDoor() {

		String testData = (String) tl.get().get("testFlowData");
		JSONArray deliveryNumbers = JsonPath.read(testData, "$.testFlowData.deliveryDetails[*].deliveryNumber");
		YmsDoorAssign doorAssignMessage = new YmsDoorAssign();
		doorAssignMessage.setDeliveryNumber((String) deliveryNumbers.get(0));
		doorAssignMessage.setSealNumber("SealNr");
		doorAssignMessage.setTrailerStatusCode("OB");
		doorAssignMessage.setCarrier("WM");
		doorAssignMessage.setArrivalTimeStamp(javaUtils.getCurrentDateAndTime(simple_date_time_format));
		doorAssignMessage.setDcNumber(environment.getProperty("dcNumber"));
		doorAssignMessage.setSubcenter("1");
		doorAssignMessage.setmoveType("Receiving");
		
			doorAssignMessage.setTrailerId("T" + (String) deliveryNumbers.get(0));

			
		doorAssignMessage.setDoorNumber(null);


		doorAssignMessage.setTrailerType("53");
		doorAssignMessage.setTrailerTypeCode("34");
		doorAssignMessage.setTralrCntrlRecId("607754");
		return doorAssignMessage;
	}

	private YmsDoorAssign constructDoorAssignMessageRDC(String deliveryNumber) {
		YmsDoorAssign doorAssignMessage = new YmsDoorAssign();
		doorAssignMessage.setDeliveryNumber(deliveryNumber);
		doorAssignMessage.setSealNumber("SealNr");
		doorAssignMessage.setTrailerStatusCode("OB");
		doorAssignMessage.setCarrier("WM");
		doorAssignMessage.setTrailerId("T" + deliveryNumber);
		doorAssignMessage.setArrivalTimeStamp("");
		doorAssignMessage.setDcNumber(environment.getProperty("facility_num"));
		doorAssignMessage.setSubcenter("1");
		doorAssignMessage.setDoorNumber("");

		return doorAssignMessage;
	}

	public String getFreeInboundDoor(String range) {
		boolean isDoorAlphaNumeric = environment.getProperty("is_door_alpha_numeric") == null ? false
				: Boolean.parseBoolean(environment.getProperty("is_door_alpha_numeric"));
		logger.info("Valid Door range is :{}", range);
		String[] doorsArray = range.split("-");
		final int firstValidDoor = Integer.parseInt(doorsArray[0]);
		final int lastValidDoor = Integer.parseInt(doorsArray[1]);

		Date firstDeliveryCreatedDate = null;
		List<String> deliveriesToBeDeleted = new ArrayList<>();
		String freeDoor = "";
		String cleanedUpDoor = "";
		int doorNumber = javaUtils.randomNrGeneratorRange(firstValidDoor, lastValidDoor);
		int totalNumberOfDoorsInRange = (lastValidDoor - firstValidDoor) + 1;
		synchronized (inboundOccupiedDoors) {
			long startTime = System.currentTimeMillis();
			long endTime = startTime + (MAX_THREAD_WAIT_FOR_DOOR_AVAILABILITY_IN_MS);
			// long threadExitTime = startTime +
			// (MAX_THREAD_WAIT_FOR_DOOR_AVAILABILITY_IN_SECS*2*1000);
			int noOfDoorsChecked = 0;
			while (noOfDoorsChecked < totalNumberOfDoorsInRange) {
				if (isDoorAlphaNumeric)
					freeDoor = ALPHA_NUMERIC_DOOR_LITERAL + doorNumber;
				else
					freeDoor = "" + doorNumber;

				if (!inboundOccupiedDoors.contains(freeDoor)) {
					Response response = getSearchDoorResponse(freeDoor);

					if (isInboundDoorAvailable(response)) {
						if (Config.isParallel) {
							inboundOccupiedDoors.add(freeDoor);
						}
						logger.info("Door number {} is free", freeDoor);
						return freeDoor;
					} else {
						logger.info("Door {} is not free..", freeDoor);
						JSONArray deliveryNumbers = JsonPath.read(response.asString(), "$..deliveryNumber");
						for (Object deliveryNumber : deliveryNumbers) {
							logger.debug("delNo:" + deliveryNumber.toString());
							String ts = ((JSONArray) JsonPath.read(response.asString(), "$.[?(@.deliveryNumber == '"
									+ deliveryNumber.toString() + "')].scheduledTimeStamp")).get(0).toString();
							logger.debug("created ts:" + ts);
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'+0000'");
							try {
								Date thisDeliveryCreatedDate = sdf.parse(ts);
								if (firstDeliveryCreatedDate == null
										|| thisDeliveryCreatedDate.compareTo(firstDeliveryCreatedDate) < 0) {
									logger.debug("oldest delivery among the given list of doors:"
											+ thisDeliveryCreatedDate.toString() + " for del"
											+ deliveryNumber.toString());
									firstDeliveryCreatedDate = thisDeliveryCreatedDate;
									deliveriesToBeDeleted.clear();
									for (Object deliveryNumberToBeDeleted : deliveryNumbers) {// If there are multiple
																								// deliveries attached
																								// to single door
										deliveriesToBeDeleted.add(deliveryNumberToBeDeleted.toString());
									}
									if (isDoorAlphaNumeric)
										cleanedUpDoor = ALPHA_NUMERIC_DOOR_LITERAL + doorNumber;
									else
										cleanedUpDoor = "" + doorNumber;

									logger.debug("Deliveries to be deleted to free up the door {} ==>{}", cleanedUpDoor,
											deliveriesToBeDeleted);
									break;/*
											 * already we have found a older delivery in this door ,We can delete all
											 * the deliveries attached to this door
											 */
								}
							} catch (java.text.ParseException e) {
								logger.error(e);
							}
						}
					}
				} else {
					logger.info("Door {} is used by another thread", freeDoor);
					if (noOfDoorsChecked == (totalNumberOfDoorsInRange - 1) && deliveriesToBeDeleted.isEmpty()) {
						// This is the last door available in the range and no delivery found to be
						// deleted
						logger.info("All the Doors are occupied by other threads");
						logger.info("Current time:{}", new Date());
						logger.info("Thread timeout:{}", new Date(endTime));
						if (System.currentTimeMillis() < endTime) {
							try {
								inboundOccupiedDoors.wait(MAX_THREAD_WAIT_FOR_DOOR_AVAILABILITY_IN_MS);
							} catch (Exception e) {
								logger.error(e);
							}

						}
						logger.info("Thread duration in door assign-> {} seconds",
								(System.currentTimeMillis() - startTime) / 1000);
						if (System.currentTimeMillis() < endTime) {
							logger.info("Looks like one of the door got detached..Got Notification from other thread");
							logger.info("Start searching for the door again");
							noOfDoorsChecked = -1;// will be increased by 1 below
						} else if (!inboundOccupiedDoors.isEmpty()) {
							logger.info("Take the  first door available in the list");
							doorNumber = Integer
									.parseInt(inboundOccupiedDoors.remove(0).replace(ALPHA_NUMERIC_DOOR_LITERAL, ""));
							doorNumber--;// door number will be increased by 1 below.
							noOfDoorsChecked = totalNumberOfDoorsInRange - 2;// just one iteration required,it will be
																				// increased by 1 below
						} else {
							logger.info("Thread timeout occured..exiting");
							break;// ideally it should never come to this else
						}
					}
				}
				doorNumber++;
				if (doorNumber > lastValidDoor) {
					doorNumber = firstValidDoor;
				}
				noOfDoorsChecked++;
			}
			if (Config.isParallel && !cleanedUpDoor.equals("")) {
				inboundOccupiedDoors.add(cleanedUpDoor);
			}
		}
		for (String deliveryToBeDeleted : deliveriesToBeDeleted) {
			logger.info("Delete delivery:{} to free the door {}", deliveryToBeDeleted, cleanedUpDoor);
			idmHelper.deleteDelivery(deliveryToBeDeleted);
		}
		logger.info("Free Door:{}", cleanedUpDoor);
		return cleanedUpDoor;
	}
	
	
	//******  Door assign catalyst ****//
	
		public String getFreeInboundDoorCatalyst(String range) {

			logger.info("Range of doors choosen :{}", range);
			String[] doorsArray = range.split("-");
			final int firstValidDoor = Integer.parseInt(doorsArray[0]);
			final int lastValidDoor = Integer.parseInt(doorsArray[1]);	
			//cleaning up inbound doors
			int deletedDoors = dbUtils.deleteFrom(PRODUCT_NAME.WMS, queries.getProperty("delete_inbound_doors"),String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			logger.info("Range of doors deleted :{}",deletedDoors);
			
			//updating locmst table to empty
			int updatedDoors = dbUtils.UpdateFrom(PRODUCT_NAME.WMS, queries.getProperty("update_inbound_doors_status"),String.valueOf(firstValidDoor),String.valueOf(lastValidDoor));
			
			
			//Assigning random door between specified range
			int doorNumber = javaUtils.randomNrGeneratorRange(firstValidDoor, lastValidDoor);
			logger.info("Inbound door assigned to trailer is :{}", doorNumber);
			return Integer.toString(doorNumber);
		}

	public Response getSearchDoorResponse(String door) {
		Response response = null;
		String idmDoorSearchUrl = environment.getProperty("idm_door_search_ep");
		String doorPayload = "";
			logger.info("Check for availability of door {}", door);
			response = SerenityRest.given().relaxedHTTPSValidation().headers(idmHelper.getIDMHeaders())
					.get(MessageFormat.format(idmDoorSearchUrl, door));
			logger.info("response code for door:{} is {}", door, response.getStatusCode());
		return response;
	}

	public boolean isInboundDoorAvailable(Response response) {
			return response.getStatusCode() == 404;
	}

	public String getFreeOutboundDoor(String range) {
		synchronized (outboundOccupiedDoors) {
			long startTime = System.currentTimeMillis();
			long endTime = startTime + (MAX_THREAD_WAIT_FOR_DOOR_AVAILABILITY_IN_MS);
			boolean isDoorAlphaNumeric = environment.getProperty("is_door_alpha_numeric") == null ? false
					: Boolean.parseBoolean(environment.getProperty("is_door_alpha_numeric"));
			List<String> listOfFreeDoors;
			String doorNumber = "";
			List<String> listOfValidDoorsForDBCheck = new ArrayList<>();
//			final String FREE_DOOR_STATUS = "Free";
//			final String CONVEYOR_INDICATOR = "Y";
			logger.debug("Door range is :{}", range);
			String[] doorsArray = range.split("-");
			final int firstValidDoor = Integer.parseInt(doorsArray[0]);
			final int lastValidDoor = Integer.parseInt(doorsArray[1]);
//			String freeDoorsInRangeJsonPathFreeAndConACC=null;
//			String freeDoorsInRangeJsonPathConACC=null;
//			final String freeDoorsInRangeJsonPath = "$.[?(@.doorStatus=='" + FREE_DOOR_STATUS + "')].number";
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
//			List<String> poType=JsonPath.read(testFlowData,"testFlowData..poDetails..channelMethod");
//			if (poType.contains("POCON")) {
//				freeDoorsInRangeJsonPathFreeAndConACC = "$.[?((@.doorStatus=='" + FREE_DOOR_STATUS
//						+ "') && (@.config.conveyorInd== 'N'))].number";
//				freeDoorsInRangeJsonPathConACC = "$.[?(@.config.conveyorInd== 'N')].number";
//			}
//			else {
//				freeDoorsInRangeJsonPathFreeAndConACC = "$.[?((@.doorStatus=='" + FREE_DOOR_STATUS
//						+ "') && (@.config.conveyorInd== '" + CONVEYOR_INDICATOR + "'))].number";
//				freeDoorsInRangeJsonPathConACC = "$.[?(@.config.conveyorInd== '" + CONVEYOR_INDICATOR
//						+ "')].number";
//			}
//
//			List<String> listOfAllFreeDoors = null;
//			List<String> listOfAllConDoorsACC = null;
			String testFlowData = String.valueOf(tl.get().get("testFlowData"));
			List<String> listOfOutboundDoorsfromthreadlocal = JsonPath.read(testFlowData,
					"$.testFlowData.outboundDetails[*].outboundDoorNumber");

			do {
//				if (Config.DC == DC_TYPE.ACC) {
//					Response response = SerenityRest.given().accept("application/json")
//							.get(environment.getProperty("loading_get_doors_ep"));
//					listOfAllConDoorsACC = JsonPath.read(response.asString(), freeDoorsInRangeJsonPathConACC);
//				}
				
				listOfValidDoorsForDBCheck.addAll(createListOfDoorsInRange(firstValidDoor, lastValidDoor,
						isDoorAlphaNumeric, listOfOutboundDoorsfromthreadlocal));
				//old code
//				listOfValidDoorsForDBCheck.addAll(createListOfDoorsInRange(firstValidDoor, lastValidDoor,
//						isDoorAlphaNumeric, listOfAllConDoorsACC, listOfOutboundDoorsfromthreadlocal));

//				if (Config.DC != DC_TYPE.ATLAS) {
//					Response response = SerenityRest.given().accept("application/json")
//							.get(environment.getProperty("loading_get_doors_ep"));
//					if (Config.DC == DC_TYPE.ACC) {
//						listOfAllFreeDoors = JsonPath.read(response.asString(), freeDoorsInRangeJsonPathFreeAndConACC);
//					} else {
//						listOfAllFreeDoors = JsonPath.read(response.asString(), freeDoorsInRangeJsonPath);
//					}
//					listOfFreeDoors = getValidFreeDoors(firstValidDoor, lastValidDoor,
//							listOfOutboundDoorsfromthreadlocal, listOfAllFreeDoors);
//				} else {
					listOfFreeDoors = getAtlasValidFreeDoors(listOfValidDoorsForDBCheck,
							listOfOutboundDoorsfromthreadlocal);
//				}

				logger.info("List Of Free Doors:{}", listOfFreeDoors);
				if (!listOfFreeDoors.isEmpty()) {
					int randomIndex = javaUtils.randomNrGeneratorRange(0, listOfFreeDoors.size() - 1);
					logger.info("Selected Door {}", listOfFreeDoors.get(randomIndex));
					doorNumber = listOfFreeDoors.get(randomIndex);
//					if (Config.DC != DC_TYPE.ATLAS) {
//						// Loading API for door search is not giving correct response hence we are
//						// cleaning by default
//						loadingDBSteps.cleanUpLoading(loadingDBSteps.getLoadIdsForDoor(doorNumber));
//					}
					if (Config.isParallel) {
						outboundOccupiedDoors.add(doorNumber);
					}
					return doorNumber;
				} else if (!listOfValidDoorsForDBCheck.isEmpty()) {
					return cleanUpOutboundDoor(listOfValidDoorsForDBCheck);
				} else if (!outboundOccupiedDoors.isEmpty()) {
					waitForOutboundDoorRelease(startTime, endTime);
				} else {
					logger.info("No Doors available");
					break;
				}
			} while (Config.isParallel);//Thread will wait inside method waitForOutboundDoorRelease and re check doors when it gets notified 
			return "";
		}
	}

	public void waitForOutboundDoorRelease(long startTime, long endTime) {
		logger.info("List of Occupied outbound doors:{}",outboundOccupiedDoors);
		logger.info("All the Doors are occupied by other threads");
		logger.info("Current time:{}", new Date());
		logger.info("Thread timeout:{}", new Date(endTime));
		if (System.currentTimeMillis() < endTime) {
			try {
				outboundOccupiedDoors.wait(MAX_THREAD_WAIT_FOR_DOOR_AVAILABILITY_IN_MS);
			} catch (Exception e) {
				logger.error(e);
			}
		}
		logger.info("Thread duration in outbound door assign-> {} seconds",
				(System.currentTimeMillis() - startTime) / 1000);
		if (System.currentTimeMillis() < endTime) {
			logger.info("Looks like one of the door got detached..Got Notification from other thread");
			logger.info("Start searching for the door again");
		} else if (!outboundOccupiedDoors.isEmpty()) {
			logger.info("Thread timeout occured");
			logger.info("Remove first door {} from the outbound occupied list",
					outboundOccupiedDoors.remove(0).replace(ALPHA_NUMERIC_DOOR_LITERAL, ""));
		}
	}

	public String cleanUpOutboundDoor(List<String> listOfValidDoorsForDBCheck) {
		String doorNumber;
//		if (Config.DC != DC_TYPE.ATLAS) {
//			doorNumber = loadingDBSteps.getDoorNumberForOldestLoad(listOfValidDoorsForDBCheck);
//			if (!doorNumber.equals("")) {
//				loadingDBSteps.cleanUpLoading(loadingDBSteps.getLoadIdsForDoor(doorNumber));
//			}
//		} else {
			loadingDBSteps.cleanUpLoadingUsingDoorNumber(listOfValidDoorsForDBCheck);
			int randomIndex = javaUtils.randomNrGeneratorRange(0, listOfValidDoorsForDBCheck.size() - 1);
			doorNumber = listOfValidDoorsForDBCheck.get(randomIndex);
//		}
		if (Config.isParallel) {
			outboundOccupiedDoors.add(doorNumber);
		}
		logger.info("Free Door:{}", doorNumber);
		return doorNumber;
	}

//	public List<String> createListOfDoorsInRange(int firstValidDoor, int lastValidDoor, boolean isDoorAlphaNumeric,
//			List<String> listOfAllConDoorsACC, List<String> listOfOutboundDoorsfromthreadlocal) {
	public List<String> createListOfDoorsInRange(int firstValidDoor, int lastValidDoor, boolean isDoorAlphaNumeric,
			List<String> listOfOutboundDoorsfromthreadlocal) {

		List<String> listOfValidDoorsForDBCheck = new ArrayList<>();
		String doorNumber;
		for (int door = firstValidDoor; door <= lastValidDoor; door++) {
			if (isDoorAlphaNumeric) {
				doorNumber = ALPHA_NUMERIC_DOOR_LITERAL + door;
			} else {
				doorNumber = String.valueOf(door);
			}
			if (!listOfOutboundDoorsfromthreadlocal.contains(doorNumber)
					&& !outboundOccupiedDoors.contains(doorNumber)) {
//				if (Config.DC == DC_TYPE.ACC) {
//					if (listOfAllConDoorsACC.contains(doorNumber)) {
//						listOfValidDoorsForDBCheck.add(doorNumber);
//					}
//				} else {
					listOfValidDoorsForDBCheck.add(doorNumber);
//				}
			}else {
				logger.info("Door {} is present in testflowdata or occupied list",doorNumber);
			}
		}
		return listOfValidDoorsForDBCheck;
	}

	public Set<String> getDistinctDestinations(String testFlowData) {
		JSONArray destinationDetails = JsonPath.read(testFlowData,
				"$.testFlowData.poDetails[*].poLineDetails[*].receivingInstructions[?(@.isPbyl == false&&@.isShipOut == true)].destNumber");
		Set<String> disctinctDest = new HashSet<>();
		for (int i = 0; i < destinationDetails.size(); i++) {
			if (!destinationDetails.get(i).toString().equals("")) {
				disctinctDest.add(destinationDetails.get(i).toString());
			}
		}
		logger.info("Distinct Destinations are :{}", disctinctDest);
		return disctinctDest;
	}

	public List<String> getValidFreeDoors(int firstValidDoor, int lastValidDoor,
			List<String> listOfOutboundDoorsfromthreadlocal, List<String> listOfAllFreeDoors) {
		List<String> listOfFreeDoors = new ArrayList<>();
		for (String doorNo : listOfAllFreeDoors) {
			int door = -1;
			if (StringUtils.isNumeric(doorNo))
				door = Integer.parseInt(doorNo);
			else
				continue;
			if (door >= firstValidDoor && door <= lastValidDoor && !listOfOutboundDoorsfromthreadlocal.contains(doorNo)
					&& !outboundOccupiedDoors.contains(doorNo)) {
				listOfFreeDoors.add("" + door);
			}
		}
		return listOfFreeDoors;
	}

	public List<String> getAtlasValidFreeDoors(List<String> doors, List<String> listOfOutboundDoorsfromthreadlocal) {
		List<String> listOfFreeDoors = new ArrayList<>();
		List<String> listOfUsedDoors = new ArrayList<>();
		Object[] arrDoors = new Object[doors.size()];
		for (int i = 0; i < doors.size(); i++) {
			arrDoors[i] = doors.get(i);
		}
		List<Map<String, Object>> listOfUsedDoorsFromDB = dbUtils.selectFrom(PRODUCT_NAME.LOADING,
				dbUtils.transformIntoSpringQuery(queries.getProperty("loading_used_doors"), doors.size()), arrDoors);

		for (Map<String, Object> usedDoor : listOfUsedDoorsFromDB) {
			listOfUsedDoors.add(usedDoor.get("door_nbr").toString());
		}
		for (String door : doors) {
			if (!listOfUsedDoors.contains(door) && !listOfOutboundDoorsfromthreadlocal.contains(door)
					&& !outboundOccupiedDoors.contains(door)) {
				listOfFreeDoors.add(door);
			} else {
				if (listOfOutboundDoorsfromthreadlocal.contains(door)) {
					logger.info("Door {} is used in testflowdata", door);
				} else if (outboundOccupiedDoors.contains(door)) {
					logger.info("Door {} is used by another thread", door);
				} else {
					logger.info("Door {} is used", door);
				}
			}
		}
		return listOfFreeDoors;
	}
	public List<String> getOutboundDoorsFromTestFlowData() {
		List<String> outboundDoors=new ArrayList<>();
		try {
			String runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			if(runTimeData!=null) {
				outboundDoors=JsonPath.parse(runTimeData).read(OUTBOUND_DOORS_JSONPATH);
				return outboundDoors;
			}
		} catch (PathNotFoundException e) {
			logger.info("Door is not yet assigned in Outbound");
		}
		return outboundDoors;
	}
	
	public void publishYMSMessage(String trailerCheckInMessage, String messageType) {
		switch (messageType.toUpperCase()) {
		case "CHECK_IN":
			synchronized (stratiConnectionUtil) {schedulerConnectionUtil.publishYMSMessage(
					environment.getProperty("maas_yms_checkin_queue"), trailerCheckInMessage, "queue","SCHEDULED");
			}
			break;
		case "DOOR_ASSIGN":
			synchronized (stratiConnectionUtil) {schedulerConnectionUtil.publishYMSMessage(
					environment.getProperty("maas_yms_door_assign_queue"), trailerCheckInMessage, "queue","ZONE_TO_DOOR");
			}
			break;
		case "GATE_OUT":
			synchronized (stratiConnectionUtil) {schedulerConnectionUtil.publishYMSMessage(
					environment.getProperty("maas_gate_out_assign_queue"), trailerCheckInMessage, "queue","EMPTY");
			}
			break;
		case "OB_GATEIN":
			synchronized (stratiConnectionUtil) {schedulerConnectionUtil.publishYMSMessage(
					environment.getProperty("maas_yms_checkin_queue"), trailerCheckInMessage, "queue","UNSCHEDULED");
			}
			break;
		case "VDOOR_TO_YARD_ASSIGN":
			synchronized (stratiConnectionUtil) 
			{
				schedulerConnectionUtil.publishYMSMessage(
						environment.getProperty("maas_yms_door_assign_queue"), trailerCheckInMessage, "queue","DOOR_TO_ZONE");
			}
		}
	}
	
	public String constructTrailerCheckInMessage(String frightType) throws URISyntaxException, IOException, ParseException {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> deliveryNumberList = JsonPath.read(testFlowData, DELIVERY_JSON_PATH);
		String deliveryType = "LIVE";
		String freightType = frightType;
		String arrivalTime = getTime(0);
		String currentSealNumber = "SL"+deliveryNumberList.get(0);
		String tractorNumber = "TC"+deliveryNumberList.get(0);
		String trailerId = "TL"+deliveryNumberList.get(0);
		String zoneName = "APPOINTMENT"; //get it from BY based on availability
		String temp="30";
		
		List<DeliveryDetail> deliveryDetailObj = null;
		JSONArray deliveryDetailsArray = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[*]");
		deliveryDetailObj = (List<DeliveryDetail>) jsonUtils
					.getPojoListfromPath(deliveryDetailsArray.toJSONString(), DeliveryDetail.class);
		
		deliveryDetailObj.get(0).setInboundYardZone(zoneName);
		deliveryDetailObj.get(0).setInboundTrailerNumber("TL"+deliveryNumberList.get(0));
		deliveryDetailObj.get(0).setInboundDoorNumber("");
		
		String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_CHECKIN_TEMPLATE_FILE);
		String doorAssignMessage = javaUtils.format(baseTemplateMssg, deliveryNumberList.get(0), deliveryType, freightType, arrivalTime, currentSealNumber, tractorNumber, trailerId, zoneName, temp);
		logger.info("GateIN Message  >> "+doorAssignMessage);
		
		JSONArray listOfDeliveryDetail = jsonUtils.converyListToJsonArray(deliveryDetailObj);
		testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listOfDeliveryDetail,
				"$.testFlowData.deliveryDetails");
		tl.get().put("testFlowData", testFlowData);

		return doorAssignMessage;
	}
	
	public String constructDoorAssignMessage(String frightType) throws URISyntaxException, IOException, ParseException {
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> deliveryNumberList = JsonPath.read(testFlowData, DELIVERY_JSON_PATH);
		String freightType = frightType;
		String moveType = "RECEIVING";
		String moveCreateTime = getTime(0);
		String moveCompleteTime = getTime(120);
		List<String> zoneNameList = JsonPath.read(testFlowData, YARD_ZONE_JSON_PATH);
		//String door = getFreeInboundDoorCatalyst(envPropResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_door_range_catalyst", true)); //get empty door from BY
//		String door = getFreeInboundDoorCatalyst(environment.getProperty("inbound_door_range"));
		
		List<String> doorNumber = JsonPath.read(testFlowData, DOOR_NUMBER_JSON_PATH);		
		String door = null;
		
		if(doorNumber.get(0).length() != 0) {
			logger.info("If Door is present in TFD >> {}", door);
			door = doorNumber.get(0);
		}else {
			door = getFreeInboundDoorCatalyst(environment.getProperty("inbound_door_range"));
		}
		
		List<String> trailerIdList = JsonPath.read(testFlowData, TRAILER_NUMBER_JSON_PATH);
		String trailerStatusCode = "IN";
		String dcNumber = environment.getProperty("facility_num");
		
		List<DeliveryDetail> deliveryDetailObj = null;
		JSONArray deliveryDetailsArray = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[*]");
		deliveryDetailObj = (List<DeliveryDetail>) jsonUtils
					.getPojoListfromPath(deliveryDetailsArray.toJSONString(), DeliveryDetail.class);
		
		deliveryDetailObj.get(0).setInboundDoorNumber(door);
		
		String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_DOORASSIGN_TEMPLATE_FILE);
		String doorAssignMessage = javaUtils.format(baseTemplateMssg, deliveryNumberList.get(0), freightType, moveType, moveCreateTime, moveCompleteTime, zoneNameList.get(0), door, trailerIdList.get(0), trailerStatusCode, dcNumber);
		logger.info("DoorAssign Message  >> "+doorAssignMessage);
		
		JSONArray listOfDeliveryDetail = jsonUtils.converyListToJsonArray(deliveryDetailObj);
		testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listOfDeliveryDetail,
				"$.testFlowData.deliveryDetails");
		tl.get().put("testFlowData", testFlowData);
		
		return doorAssignMessage;
	}
	
	
	public String constructTrailerOBGateInMessage(String frightType)
			throws URISyntaxException, IOException, ParseException {

//		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		String deliveryType = "LIVE";
		String freightType = frightType;
		String arrivalTime = getTime(0);
		String currentSealNumber = "SL" + javaUtil.randonNumberGenerator(4);
		String trailerId = "AUTOTL" + javaUtil.randonNumberGenerator(4);
		String tractorNumber = "TC" + javaUtil.randonNumberGenerator(4);
//	String trailerId = "TL"+javaUtil.randonNumberGenerator(4);
		String zoneName = "B1"; // get it from BY based on availability
		String temp = "30";

		String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_OB_GATEIN_TEMPLATE_FILE);
		String obGateInMsg = javaUtils.format(baseTemplateMssg, deliveryType, freightType, arrivalTime,
				currentSealNumber, tractorNumber, trailerId, zoneName, temp);
		logger.info("GateIN Message  >> " + obGateInMsg);

		byUiHelper.updateTestFlowDataForOutboundDetails("outboundYardZone", zoneName);
		logger.info("set the Outbound YardZone {} in TestFlowData", zoneName);
		byUiHelper.updateTestFlowDataForOutboundDetails("trailerNumber", trailerId);
		logger.info("set the Outbound TrailerID {} in TestFlowData ", trailerId);

		return obGateInMsg;
	}
	
	
	public String constructOBDoorAssignMessage(String frightType)
			throws URISyntaxException, IOException, ParseException {

		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);

		String freightType = frightType;
		String moveType = "RECEIVING";
		String moveCreateTime = getTime(0);
		String moveCompleteTime = getTime(120);
		List<String> zoneNameList = JsonPath.read(runTimeData, OB_YARD_ZONE_JSON_PATH);
		String doorAssign = "220"; // (131)//get empty door from BY
		List<String> trailerIdList = JsonPath.read(runTimeData, OB_TRAILER_NUMBER_JSON_PATH);

		String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_OB_DOORASSIGN_TEMPLATE_FILE);
		String doorAssignOBMsg = javaUtils.format(baseTemplateMssg, freightType, moveType, moveCreateTime,
				moveCompleteTime, zoneNameList.get(0), doorAssign, trailerIdList.get(0));
		logger.info("DoorAssign Message  >> " + doorAssignOBMsg);

		byUiHelper.updateTestFlowDataForOutboundDetails("outboundDoorNumber", doorAssign);
		logger.info("set the Outbound DoorNumber {} in TestFlowData", doorAssign);

		logger.info(" zone name {} is ", zoneNameList);
		logger.info(" trailer id {} is ", trailerIdList);
		logger.info(" trailer is assigned to the Door ", doorAssign);

		return doorAssignOBMsg;
	}
	
	
	public String constructGateOutMessage(String frightType) throws URISyntaxException, IOException, ParseException {

		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);
		String freightType = frightType;
		String departTime = getTime(0);
		String temp = "30";

		if (frightType.equalsIgnoreCase("Inbound")) {
			// Need to get it from TFD Inbound trailer id
			List<String> trailerIdList = JsonPath.read(runTimeData, TRAILER_NUMBER_JSON_PATH);
			String carrierId = "WMT";
			String trailerStatusCode = "IB"; // Not sure

			String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_GATEOUT_TEMPLATE_FILE);
			String inGateOutMsg = javaUtils.format(baseTemplateMssg, freightType, departTime, trailerIdList.get(0),
					carrierId, trailerStatusCode, temp);
			logger.info("Inbound DoorAssign Message  >> " + inGateOutMsg);
			return inGateOutMsg;
		} else {
			List<String> trailerIdList = JsonPath.read(runTimeData, OB_TRAILER_NUMBER_JSON_PATH);
			String carrierId = "SWDD";
			String trailerStatusCode = "OB";

			String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_GATEOUT_TEMPLATE_FILE);
			String obGateOutMsg = javaUtils.format(baseTemplateMssg, freightType, departTime, trailerIdList.get(0),
					carrierId, trailerStatusCode, temp);
			logger.info("Outbound DoorAssign Message  >> " + obGateOutMsg);
			return obGateOutMsg;
		}

	}

	
	public String getTime(int secToAdd) {
		Clock clock = Clock.system(ZoneId.of("Asia/Calcutta"));
		return clock.instant().plusSeconds(secToAdd).toString();
	}
	
	
	public String constructBumpMoveMessage(String frightType) throws URISyntaxException, IOException, ParseException {

		// OB - May need to change the TrailerStatusCode
		String runTimeData = (String) threadLocal.get().get(TEST_FLOW_DATA);

		List<String> deliveryNumber = JsonPath.read(runTimeData, DELIVERY_NUMBER_JSON_PATH);
		String freightType = frightType;
		String moveType = "RECEIVING";
		String moveCreateTime = getTime(0);
		String moveCompleteTime = getTime(120);
		List<String> doorNumber = JsonPath.read(runTimeData, DOOR_NUMBER_JSON_PATH);
		String zoneName = "APPOINTMENT";
		List<String> trailerIdList = JsonPath.read(runTimeData, TRAILER_NUMBER_JSON_PATH);
		String trailerStatusCode = "IB";

		String baseTemplateMssg = textParser.readTextFile(FileNames.CATALYST_YMS_VDOOR_TO_ZONE_MOVE_TEMPLATE_FILE);

		logger.info("Moving the trailer from VirtualDoor To Zone based on below data ====");

		logger.info("Delivery Number ====> {}", deliveryNumber.get(0));
		logger.info("Fright Type ====> {}", freightType);
		logger.info("Move Type ====> {}", moveType);
		logger.info("Move Create Time ====> {}", moveCreateTime);
		logger.info("Move Complete Type ====> {}", moveCompleteTime);
		logger.info("Door ID ====> {}", doorNumber.get(0));
		logger.info("Zone Name ====> {}", zoneName);
		logger.info("Trailer ID ====> {}", trailerIdList.get(0));
		logger.info("Trailer Status Code Type ====> {}", trailerStatusCode);

		String doorToZoneAssignMsg = javaUtils.format(baseTemplateMssg, deliveryNumber.get(0), freightType, moveType,
				moveCreateTime, moveCompleteTime, doorNumber.get(0), zoneName, trailerIdList.get(0), trailerStatusCode);
		logger.info("Trailer Assign Message  >> " + doorToZoneAssignMsg);

		logger.info("Successfullyt Moved the trailer from Virtual Door To Zone based on Above Mentioned fields ====");
		logger.info(" zone name {} is ", zoneName);
		
		return doorToZoneAssignMsg;
	}

}
