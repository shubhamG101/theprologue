package com.walmart.supplychain.acc.docktag.scenariosteps.mobile;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.walmart.supplychain.acc.docktag.steps.mobile.DockTagSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class DockTagScenarios {
	
	@Steps
	DockTagSteps docktagSteps;

	Logger logger = LogManager.getLogger(this.getClass());

	WebDriver driver;

	@Given("^user selects offline door for this receiving$")
	public void populateTestflowdataWithOfflineDoor() {
		docktagSteps.populateDoorType();
		
	}
	
	@Then("^user scan the item and builds dock tag pallet and complete the pallet$")
	public void buildDockTagPallet(){
		docktagSteps.createDockTagPallet();
	}
	
	@Then("^user prints PBYL dock tags$")
	public void printsPBYLDockTags(){
		docktagSteps.printPBYLDockTag();
	}
	
	@And("^user verifies dock tag pallet is created in receiving$")
	public void validatecretedDocktag() {
		docktagSteps.validateCreatedDocktag();

	}
	
	@And("^user verifies dock tag pallet is completed in receiving$")
	public void validateCompletedDocktagStatus() {
		docktagSteps.validateCompletedDocktagStatus();

	}
	
	@And("^user verifies dock tag pallet is created inventory with \"([^\"]*)\" status$")
	public void validateDockTagStatusInInv(String expDockTagStatus) {
		docktagSteps.validateDockTagStatusInInventory(expDockTagStatus);

	}
	
	@And("^user verifies dock tag pallet is deleted from inventory$")
	public void validateDockTagDeletedInInv() {
		docktagSteps.validateDockTagDeletedInInventory();

	}
	
	@Given("^user scan the floor line$")
	public void scanFloorLine(){
		docktagSteps.scanFloorLine();
	}
	
	@Then("^user starts receiving and completes the pallet by scanning the dock tag pallet$")
	public void receiveDockTagPallet(){
		docktagSteps.receiveDockTagPalletAndComplete();
	}
	
	@Then("^user starts receiving and completes the pallet by scanning PBYL dock tag pallet$")
	public void receivePBYLDockTagPallet(){
		docktagSteps.receivePBYLDockTagPalletAndComplete();
	}
	
	@Then("^user scan invalid dock tag pallet and verify error message should be shown$")
	public void receiveInvalidDockTagPallet(){
		docktagSteps.scanFloorLine();
		docktagSteps.receiveInvalidDockTagPallet();
	}
	
	@Then("^user scan completed dock tag pallet and verify error message should be shown$")
	public void receiveCompletedDockTagPallet(){
		docktagSteps.receiveCompletedDockTagPallet();
	}
	
}
