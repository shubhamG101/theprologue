package com.walmart.supplychain.nextgen.loading.pages.ui;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.thucydides.core.pages.PageObject;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class LoadingPage extends SerenityHelper {

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	JavaUtils utils = new JavaUtils();

	@FindBy(id = "loadId")
	private WebElement loadIdTxt;

	@FindBy(xpath = "//button[@id='importBottonId']")
	private WebElement routingFileUpload;
	
	@FindBy(css = "input[aria-label='From date']")
	private WebElement fromDate;

	@FindBy(id = "searchIcon")
	private WebElement searchIcon;

	@FindBy(xpath = "//table[@ng-model='selectedRow']/tbody/tr[@class='md-row ng-scope ng-isolate-scope']")
	private List<WebElement> rowCount;

	@FindBy(xpath = "//span[@md-highlight-text='vm.searchLoadId']/span")
	private WebElement selectLoadId;

	@FindBy(xpath = "//md-select-menu[@role='presentation']//div[contains(text(),'local')]")
	private WebElement selectLocalField;

	@FindBy(xpath = "//div[@class='loginButton']/button")
	private WebElement loginButton;

	@FindBy(xpath = "//*[contains(@class,'md-dialog']")
	private WebElement spinner;

	@FindBy(xpath = "//div[p[text()='Load Management']]/h1/button")
	private WebElement leftToggleButton;

	@FindBy(xpath = "//p[text()='Container Visibility']")
	private WebElement containerVisibilityOption;

	@FindBy(xpath = "//input[@ng-model='vm.selectedContainerIds']")
	private WebElement containerIdTextField;

	@FindBy(id = "searchIcon")
	private WebElement searchIconinContainerVisibility;

	@FindBy(xpath = "//table[@ng-model='selectedRow']/tbody/tr/td[2]")
	private WebElement loadingDoor;

	@FindBy(xpath = "//table[@ng-model='selectedRow']/tbody/tr/td[3]")
	private WebElement loadIdui;

	@FindBy(xpath = "//table[@ng-model='selectedRow']/tbody/tr/td[4]") // md-table-container[class='lm-sm'] table tbody
																		// tr td:nth-child(4)
	private WebElement tmsLoadIdUi;

	@FindBy(xpath = "//table[@ng-model='selectedRow']/tbody/tr/td[5]")
	private WebElement loadingTrailer;

	@FindBy(xpath = "//table[@ng-model='selectedRow']/tbody/tr/td[7]")
	private WebElement loadingStatus;
	
	@FindBy(xpath = "//ng-md-icon[@icon='more_vert']")
	private WebElement loadVerticalIcon;
	
	@FindBy(xpath = "//button[@ng-click='deleteConfirmation()']//ng-md-icon[@icon='delete']")
	private WebElement deleteIcon;
	
	@FindBy(xpath = "//button[contains(text(),'DELETE')]")
	private WebElement deletePopupIcon;

	public void waitForSpinner() {
		try {
			WebDriverWait wait = new WebDriverWait(getDriverInstance(), 5);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.cssSelector("md-progress-circular[md-mode='indeterminate']")));
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.cssSelector("md-progress-circular[md-mode='indeterminate']")));
			logger.info("loader disappeared");
		} catch (TimeoutException ex) {
			logger.info("Exceeded the timeout for loader.Proceeding");
		}
	}

	public void clickOnRoutingFileUpload() {
		click(routingFileUpload);
		logger.info("Clicked on routing file upload");
		
		try {
			//delay needed as it takes time to process the file in loading
			Thread.sleep(15000); 
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String searchLoadId(String loadId) {
		element(loadIdTxt).waitUntilVisible();
		String today = utils.getCurrentDateAndTime("MM/d/yyyy", "GMT");
		logger.info("current time in utc{}", utils.getCurrentDateAndTime("MM/d/YYYY hh:mm:ss", "GMT"));
		element(fromDate).type(today);
		element(loadIdTxt).type(loadId);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// element(loadIdTxt).sendKeys(Keys.ARROW_DOWN);
		// element(loadIdTxt).sendKeys(Keys.RETURN);

		element(selectLoadId).click();
		element(searchIcon).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// waitForSpinner();
		WebElement loadIdFromUIElement = element(
				By.xpath("//td[contains(@class, 'md-cell') and text() = '" + loadId + "']"));
		tmsLoadIdUi = element(By.cssSelector("table>tbody>tr td:nth-child(4)"));

		// logger.info("Found Load Id:{}",loadIdFromUIElement.getText());
		String tmsIdUi = tmsLoadIdUi.getText();
		logger.info("Transportation load Id:" + tmsIdUi);
		return tmsIdUi;

	}

	public String validateLoadStatus(String loadStatus) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String statusUi = loadingStatus.getText();
		logger.info("Validating load status |status expected: " + loadStatus + "|status ui " + statusUi);
		Assert.assertEquals(loadStatus, statusUi);
		return statusUi;

	}

	public void clickOnSearchIcon() {
		element(searchIcon).click();
	}

	public void clickOnLeftToggleButton() {
		waitFor(ExpectedConditions.elementToBeClickable(leftToggleButton));
		element(leftToggleButton).waitUntilVisible();
		element(leftToggleButton).click();
		logger.info("clicked toggle button");
		// waitForSpinner();
	}

	public void clickContainerVisibilityOption() {
		element(containerVisibilityOption).click();
		logger.info("clicked on container visibility option");
		// waitForSpinner();
	}

	public String validateLoadId(String loadId, String door, String trailer) throws InterruptedException {
		WebDriver driver = getDriverInstance();
		Thread.sleep(2000);

		String doorUi = loadingDoor.getText();
		String loadIdUi = loadIdui.getText();
		String tmsIdUi = tmsLoadIdUi.getText();
		String trailerUi = loadingTrailer.getText();
		String statusUi = loadingStatus.getText();

		Assert.assertEquals(1, rowCount.size());
		logger.info("Search count:" + rowCount.size());

		Assert.assertEquals(door.trim(), doorUi.trim());
		logger.info("door expected:" + doorUi + "|door ui" + doorUi);

		Assert.assertEquals(loadId, loadIdUi);
		logger.info("loadId expected:" + loadId + "|loadId ui" + Integer.parseInt(loadIdUi));

		Assert.assertNotEquals(tmsIdUi.length(), 0);
		logger.info("tms loadId" + tmsIdUi);

		Assert.assertEquals(trailer, trailerUi);
		logger.info("trailer expected:" + trailer + "|trailer ui" + trailerUi);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("Validating load status |status expected: Loading | status ui " + statusUi);
		Assert.assertEquals("Loading", statusUi);
		return tmsIdUi;
	}

	public void getUrl(String url) {
		getDriverInstance().get(url);

	}

	public void closeDriver() {
		getDriverInstance().close();
	}
	
	public void deleteLoad(String loadId) {
		WebDriver driver=getDriverInstance();
		WebElement loadText=driver.findElement(By.xpath("//td[text()="+loadId+"]"));
		element(loadText).click();
		element(deleteIcon).waitUntilClickable();
		element(deleteIcon).click();
		element(deletePopupIcon).waitUntilClickable();
		element(deletePopupIcon).click();
	}

}
