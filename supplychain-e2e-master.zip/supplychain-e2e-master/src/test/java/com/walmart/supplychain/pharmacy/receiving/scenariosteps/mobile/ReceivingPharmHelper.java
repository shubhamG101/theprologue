package com.walmart.supplychain.pharmacy.receiving.scenariosteps.mobile;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableMap;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ReceivingPharmHelper extends ScenarioSteps {
	
	@Autowired
	Environment environment;
	
	@Autowired
	JsonUtils jsonUtil;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	@Autowired
	DbUtils dbUtils;
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);
	private static final String TEST_FLOW_DATA = "testFlowData";
	private Response instructionResponse=null;
	private static final String DELIVERY_JSON_PATH = "$.testFlowData.deliveryDetails[?(@.deliveryName=='D1')].deliveryNumber";
	private static final String PO_NUMBER_JSON_PATH = "$.testFlowData.deliveryDetails..poNumbers[*]";
	String testFlowData;
	
//	public void performScan(String valueToScan) {
//		System.out.println("valueToScan : "+valueToScan);
//		List<String> scanAttributes = Arrays.asList("-a", "com.walmart.scanner.SCANNED", "-p",
//				"com.walmart.move.nim.receiving.mobile", "-e",
//				"com.motorolasolutions.emdk.datawedge.data_string " + valueToScan, "-e",
//				"com.motorolasolutions.emdk.datawedge.label_type LABEL_TYPE_EAN128");
//		Map<String, Object> scanEvent = ImmutableMap.of("command", "am broadcast", "args", scanAttributes);
//		getAndroidDriver().executeScript("mobile: shell", scanEvent);
//	}
//	
//	public AndroidDriver<AndroidElement> getAndroidDriver() {
//		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
//	}
	
	public String getcontainerResponseForDelivery(String deliveryNumber) {
		String responseAsString = null;
		String containerRequestUrl = MessageFormat.format(environment.getProperty("container_request_ep"),
				deliveryNumber);
		Failsafe.with(retryPolicy).run(() -> {
		instructionResponse = SerenityRest.given().relaxedHTTPSValidation().headers(getReceivingHeaders())
				.get(containerRequestUrl);
		Assert.assertEquals(ErrorCodes.PHARMACY_RECEIVING_UNBLE_TO_FETCH_INSTRUCTIONS, Constants.SUCESS_STATUS_CODE , instructionResponse.getStatusCode());
		});
		responseAsString = instructionResponse.getBody().asString();
		return responseAsString;
	}
	
	public Headers getReceivingHeaders() {
		Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		Header securityId = new Header("WMT-Security-ID", environment.getProperty("wmt_security_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(securityId);
		return new Headers(headerList);
	}
	
	public void storePtagInstructionsIntoTestflowData() throws JsonGenerationException, JsonMappingException, IOException, ParseException {
		ObjectMapper mapper = new ObjectMapper();
		boolean isLineHavingPtag=false;
		String testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
		List<String> deliveryNumberList = JsonPath.parse(testFlowData).read(DELIVERY_JSON_PATH);
		String containerResponse = getcontainerResponseForDelivery(deliveryNumberList.get(0));

		List<String> filteredContainerResponse=JsonPath.parse(containerResponse)
				.read("$.[?(@.publishTs!=null && @.containerStatus!='backout')]");
		String filteredContainerResponseStr = mapper.writeValueAsString(filteredContainerResponse);

		List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSON_PATH);
		for (String poNumber : poNumberList) {
			List<String> poLineNumbers = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
			for (String lineNumber : poLineNumbers) {
				List<ReceivingInstruction> instructionList = new ArrayList<>();
				List<String> ptagList=JsonPath.parse(filteredContainerResponseStr)
						.read("$..containerItems..[?(@.purchaseReferenceLineNumber=="+lineNumber+")].trackingId");
				//					List<String> ptagList=JsonPath.parse(containerResponseStr)
				//							.read("$..[?(@.containerItems[?(@.purchaseReferenceLineNumber=="+lineNumber+")] && @.publishTs!=null && @.containerStatus!='backout')].trackingId");
				isLineHavingPtag=false;
				for (String ptag : ptagList) {
					isLineHavingPtag=true;
					List<String> vnpkList=JsonPath.parse(testFlowData)
							.read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.poLineNumber == '"+lineNumber+"')].vnpk");
					List<String> whpkList=JsonPath.parse(testFlowData)
							.read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumber+"')].poLineDetails[?(@.poLineNumber == '"+lineNumber+"')].whpk");
					List<Integer> vnpkOrderQtyInEachesList=JsonPath.parse(containerResponse)
							.read("$..containerItems[?(@.trackingId=='"+ptag+"')].quantity");

					ReceivingInstruction recInstruction = new ReceivingInstruction();
					recInstruction.setParentContainer(ptag);
					recInstruction.setLabelType("normal");
					double vnpkOrderQtyInVendorPack=(double)vnpkOrderQtyInEachesList.get(0)/Double.parseDouble(vnpkList.get(0));
					recInstruction.setReceivedQuantity(String.valueOf(vnpkOrderQtyInVendorPack));
					instructionList.add(recInstruction);
				}
				if (isLineHavingPtag==true) {
					JSONArray instructJSONArry = jsonUtil.converyListToJsonArray(instructionList);
					String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, instructJSONArry,
							"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails[?(@.poLineNumber=="
									+ lineNumber + ")].receivingInstructions");
					threadLocal.get().put("testFlowData", testFlowData_updated);
					testFlowData = threadLocal.get().get(TEST_FLOW_DATA).toString();
					logger.info("TestFlowData after updating receive instructions:" + testFlowData_updated);
				}
			}
		}
	}
	
	public void validateReceivingDBAfterCancellingPallet() throws Exception {
		try{
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> deliveryNumbers=JsonPath.parse(testFlowData).read("$..deliveryNumber");
			List<String> poNumbers=JsonPath.parse(testFlowData).read("$..poNumber");
			String deliveryNumber = deliveryNumbers.get(0);
			String poNumber = poNumbers.get(0);
			
			List<Map<String, Object>> receiptQtyMap=dbUtils.selectFrom(PRODUCT_NAME.RECEIVING, environment.getProperty("select_sum_quantity_receiving_receipt"), deliveryNumber, poNumber);
			logger.info("Executed query to get sum of quantity in RECEIPT Table:"+ receiptQtyMap);
			int qty=(int) receiptQtyMap.get(0).get("");
			Assert.assertEquals(ErrorCodes.PHARMACY_RECIVING_RECEIPT_QTY_VALIDATION_FAILED, 0, qty);
			
			List<Map<String, Object>> containerMap=dbUtils.selectFrom(PRODUCT_NAME.RECEIVING, environment.getProperty("select_receiving_container"), deliveryNumber);
			logger.info("Executed query to get entries in CONTAINER Table:"+containerMap);
			boolean noEntryInContainer = false;
			try {
				noEntryInContainer = containerMap.isEmpty();
			} catch (Exception e) {
				logger.info("Something went wrong while Validating CONTAINER Table After Cancelling Pallet", e);
				throw e;
			}
			Assert.assertTrue(ErrorCodes.PHARMACY_RECIVING_CONTAINER_NO_DATA_VALIDATION_FAILED, noEntryInContainer);
			
			List<Map<String, Object>> containerItemMap = dbUtils.selectFrom(PRODUCT_NAME.RECEIVING, environment.getProperty("select_receiving_container_item"), deliveryNumber);
			logger.info("Executed query to get entries in CONTAINER ITEM Table:"+containerItemMap);
			boolean noEntryInContainerItem = false;
			try {
				noEntryInContainerItem = containerItemMap.isEmpty();
			} catch (Exception e) {
				logger.info("Something went wrong while Validating CONTAINER ITEM Table After Cancelling Pallet", e);
				throw e;
			}
			Assert.assertTrue(ErrorCodes.PHARMACY_RECIVING_CONTAINER_NO_DATA_VALIDATION_FAILED, noEntryInContainerItem);
			
			List<Map<String, Object>> instructionQtyMap=dbUtils.selectFrom(PRODUCT_NAME.RECEIVING, environment.getProperty("select_receivedQty_receiving_instruction"),deliveryNumber);
			logger.info("Executed query to get quantity in RECEIPT Table:"+instructionQtyMap);
			int receivedQty = (int) instructionQtyMap.get(0).get("RECEIVED_QUANTITY");
			Assert.assertEquals(ErrorCodes.PHARMACY_RECIVING_INSTRUCTION_QTY_VALIDATION_FAILED, 0, receivedQty);
			
		} catch (Exception e) {
			logger.info("Something went wrong while Validating Receiving DB After Cancelling Pallet", e);
			throw e;
		}
	}
}
