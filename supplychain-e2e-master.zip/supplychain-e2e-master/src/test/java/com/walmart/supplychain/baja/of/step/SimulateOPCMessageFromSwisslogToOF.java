package com.walmart.supplychain.baja.of.step;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.google.gson.JsonArray;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ContainerDetails;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class SimulateOPCMessageFromSwisslogToOF {

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	SpringJmsUtils springJmsUtils;

//	@Value("${opcPickConfirmation}")
//	String opcPickConfirmation;

	String xmlfileForBulkPick = FileNames.BAJA_ORDER_PICK_CONFIRMATION_BULKPICK;
	String xmlFileForTrip = FileNames.BAJA_ORDER_PICK_CONFIRMATION_TRIP;
	List<ContainerDetails> contDetails = new ArrayList<>();

	Logger logger = LogManager.getLogger(this.getClass());

	private final static String LOAD_UNIT_JSON_PATH = "$.testFlowData.containerDetails[?(@.itemNumber=='#0#')].loadUnitId";
	private final static String IS_USED_JSON_PATH = "$.testFlowData.containerDetails[?(@.loadUnitId=='#0#')].isUsed";

	@Step
	public void updateOPCMessageForBulkPick() throws ParseException {

		try {
			String testFlowData = tl.get().get("testFlowData").toString();

			// Generate random TUID
			String tuId = "TUID";
			Random rand = new Random();
			int randomValue = rand.nextInt(1000000);
			tuId += randomValue;

			// get messageID from the testflow data
			JSONArray messageID = JsonPath.parse(testFlowData).read("$..messageId");

			// get messageID from the testflow data
			JSONArray loadId = JsonPath.parse(testFlowData).read("$..loadId");
			List<String> LabelNbr = JsonPath.read(testFlowData, "$..parentContainer");
			List<String> itemNumberArray = JsonPath.read(testFlowData, "$..containerDetails[*].itemNumber");
			Set<String> uniqueItems = new HashSet<>(itemNumberArray);
			logger.info("Unique Item Numbers are-->{}: ", uniqueItems.toString());

			List<String> loadUnitIdsfor80 = JsonPath.read(testFlowData,
					javaUtils.format(LOAD_UNIT_JSON_PATH, environment.getProperty("item_number_80")));

			logger.info("Retriving the xml file path for Bulk pick", xmlfileForBulkPick);
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlfileForBulkPick);

			Node orderPickConfirmationMessageRequest = document
					.getElementsByTagName("orderPickConfirmationMessageRequest").item(0);

			// loop the orderPickConfirmationMessageRequest node and update the
			// Values
			NodeList nodes = orderPickConfirmationMessageRequest.getChildNodes();
			logger.info("Getting all the child nodes of:{}", orderPickConfirmationMessageRequest);
			for (int i = 0; i < nodes.getLength(); i++) {

				Node element = nodes.item(i);
				if ("orderId".equals(element.getNodeName())) {
					element.setTextContent(messageID.get(0).toString());
					logger.info("Value is updated with new Order ID");
				}

				if ("shipmentId".equals(element.getNodeName())) {
					element.setTextContent(loadId.get(0).toString());
					logger.info("Value is updated with new Shipment ID");
				}

				if ("orderLine".equals(element.getNodeName())) {

					NodeList orderLineList = element.getChildNodes();
					for (int j = 0; j < orderLineList.getLength(); j++) {
						Node listOrderLine = orderLineList.item(j);

						if ("orderTuId".equals(listOrderLine.getNodeName())) {
							listOrderLine.setTextContent(tuId);
							logger.info("Value is updated with new TUID");
						}
						if ("labelNumber".equals(listOrderLine.getNodeName())) {
							listOrderLine.setTextContent(LabelNbr.get(0).toString());
							logger.info("Value is updated with new Label Number");
						}
					}
				}
			}

			int getProductIDNbrs = document.getElementsByTagName("productId").getLength();
			logger.info("Check for the No. of product Ids-->{}", getProductIDNbrs);

			for (int len = 0; len < getProductIDNbrs; len++) {
				Node pr = document.getElementsByTagName("productId").item(len);
				if (uniqueItems.toString().contains(environment.getProperty("item_number_80"))) {
					logger.info("Need to update the load ID for -->{}", pr.getTextContent());
					for (int i = 0; i < 20; i++) {
						Node orderLoadUnitId = document.getElementsByTagName("orderLoadUnitId").item(i);
						orderLoadUnitId.setTextContent(loadUnitIdsfor80.get(i));
					}
				}
			}

			// write the DOM object to the file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();

			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);

			StreamResult streamResult = new StreamResult(new File(xmlfileForBulkPick));
			transformer.transform(domSource, streamResult);
			logger.info("The OPC XML File is updated ");

			logger.info("OPC message published for messageID " + messageID.get(0).toString());
			 springJmsUtils.sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE,
			 JMS_PROVIDER_TYPE.IMQ,
			 Config.DC, environment.getProperty("opcPickConfirmation"),
			 jsonUtil.readFile("src//test//resources//TestData//Baja//orderPickConfirmation_BulkPick.xml"));

		} catch (ParserConfigurationException | TransformerException | IOException | SAXException pce) {
			throw new AutomationFailure("Something went wrong while sending the pick confirmation message ", pce);
		}
	}

	public void updateOPCMessageForTrip(String newOrderID, String shipmentIdValue, List<String> listOfTUIDs)
			throws ParseException {

		try {

			String testFlowData = tl.get().get("TestFlowData").toString();
			List<String> itemNumberArray = JsonPath.read(testFlowData, "$..containerDetails[*].itemNumber");
			Set<String> uniqueItems = new HashSet<String>(itemNumberArray);

			logger.info("Unique Item Numbers are-->{}: ", uniqueItems.toString());

			List<String> list = new ArrayList<String>(uniqueItems);
			for (String itemNumber : list) {
				List<String> loadUnitIds = JsonPath.read(testFlowData,
						javaUtils.format(LOAD_UNIT_JSON_PATH, itemNumber));

				logger.info("Load Units for item:{} ==> {}", itemNumber, loadUnitIds);

			}
			List<String> loadUnitIdsfor80 = JsonPath.read(testFlowData,
					javaUtils.format(LOAD_UNIT_JSON_PATH, environment.getProperty("item_number_80")));
			List<String> loadUnitIdsfor81 = JsonPath.read(testFlowData,
					javaUtils.format(LOAD_UNIT_JSON_PATH, environment.getProperty("item_number_81")));

			logger.info("Retriving the xml file path for Trip", xmlFileForTrip);
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFileForTrip);

			Node orderPickConfirmationMessageRequest = document
					.getElementsByTagName("orderPickConfirmationMessageRequest").item(0);

			NodeList nodes = orderPickConfirmationMessageRequest.getChildNodes();
			logger.info("Getting all the child nodes of:{}", orderPickConfirmationMessageRequest);
			for (int i = 0; i < nodes.getLength(); i++) {

				Node element = nodes.item(i);
				if ("orderId".equals(element.getNodeName())) {
					element.setTextContent(newOrderID);
					logger.info("Value is updated with new Order ID");
				}

				if ("shipmentId".equals(element.getNodeName())) {
					element.setTextContent(shipmentIdValue);
					logger.info("Value is updated with new Shipment ID");
				}

			}

			NodeList orderTuIdList = document.getElementsByTagName("orderTuId");
			logger.info("Get the number of TUIDs-->{}", orderTuIdList.getLength());
			for (int j = 0; j < orderTuIdList.getLength(); j++) {
				Node listOrderLine = orderTuIdList.item(j);

				if ("orderTuId".equals(listOrderLine.getNodeName())) {
					listOrderLine.setTextContent(listOfTUIDs.get(j));
					logger.info("Value is updated with new TUID{} ", j);
				}

			}

			int getProductIDNbrs = document.getElementsByTagName("productId").getLength();

			logger.info("Check for the No. of product Ids-->{}", getProductIDNbrs);

			for (int len = 0; len < getProductIDNbrs; len++) {
				Node pr = document.getElementsByTagName("productId").item(len);
				if (uniqueItems.toString().contains(environment.getProperty("item_number_80"))) {
					logger.info("Need to update the load ID for -->{} ", pr.getTextContent());

					for (int i = 0; i < Integer.parseInt(environment.getProperty("trip_quantity")); i++) {
						testFlowData = tl.get().get("TestFlowData").toString();
						Node orderLoadUnitId = document.getElementsByTagName("orderLoadUnitId").item(i);
						orderLoadUnitId.setTextContent(loadUnitIdsfor80.get(i));

						String isUsedJsonPath = javaUtils.format(IS_USED_JSON_PATH, loadUnitIdsfor80.get(i));
						String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, "true", isUsedJsonPath);
						tl.get().put("TestFlowData", testFlowData_updated);

					}
				}
				if (uniqueItems.toString().contains(environment.getProperty("item_number_81"))) {
					logger.info("Need to update the load ID for -->{} ", pr.getTextContent());

					for (int j = 0; j < Integer.parseInt(environment.getProperty("trip_quantity")); j++) {
						testFlowData = tl.get().get("TestFlowData").toString();
						Node orderLoadUnitId = document.getElementsByTagName("orderLoadUnitId").item(j + 10);
						orderLoadUnitId.setTextContent(loadUnitIdsfor81.get(j));

						String isUsedJsonPath = javaUtils.format(IS_USED_JSON_PATH, loadUnitIdsfor81.get(j));

						String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, "true", isUsedJsonPath);

						tl.get().put("TestFlowData", testFlowData_updated);

					}

				}

			}
			logger.info("TestFlowData after updating container details or loadUnitID:{}",
					String.valueOf(tl.get().get("TestFlowData")));
			// write the DOM object to the file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();

			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);

			StreamResult streamResult = new StreamResult(new File(xmlFileForTrip));
			transformer.transform(domSource, streamResult);
			logger.info("The OPC XML File is updated ");

		} catch (ParserConfigurationException pce) {
			throw new AutomationFailure("Something went wrong while updating the Order ID", pce);
		} catch (TransformerException tfe) {
			throw new AutomationFailure("Something went wrong while updating the Order ID", tfe);
		} catch (IOException ioe) {
			throw new AutomationFailure("Something went wrong while updating the Order ID", ioe);
		} catch (SAXException sae) {
			throw new AutomationFailure("Something went wrong while updating the Order ID", sae);
		}
	}

}