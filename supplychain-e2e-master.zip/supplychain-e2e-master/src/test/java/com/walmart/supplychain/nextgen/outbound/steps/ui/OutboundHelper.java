package com.walmart.supplychain.nextgen.outbound.steps.ui;

import com.ibm.icu.text.MessageFormat;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.parsing.PdfParser;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OutboundHelper {
	private static final String DOWNLOAD_LOCATION=System.getProperty("user.dir")+"/target/";
	String[] keywords= {"BOL ID","Page","TRANSPORTATION LOAD ID","TRAILER","OUTBOUND SEAL NO","Destination#"};
	PdfParser pdfParser=new PdfParser();
	Logger logger = LogManager.getLogger(this.getClass());
	Map<String,String> contentParser=new HashMap<>();
	@Autowired
    DbUtils dbUtils;
	@Autowired
    Environment environment;
	public  String  getPDFFile(String pdfFile) {
		String path=DOWNLOAD_LOCATION+pdfFile;
		if(new File(path).exists())
			return path;
		return null;
	}

	public  Map<String,String> processPDF(String pdfFilePath) {
		String[] data=pdfParser.getPdfContents(pdfFilePath);
		Map<String,String> content=new HashMap<>();

		for(String line:data) {
			for(String keyword:keywords) {
				if(line.contains(keyword)&&content.get(keyword)==null) {
					String value=getValueForKey(line, keyword);
					content.put(keyword, value);
				}
			}
		}
		return content;

	}
	private String removeOtherKeywords(String val) {
		for(String key:keywords) {
			if(val.contains(key)) {
				return val.replace(key, "").trim();
			}
		}
		return val.trim();
	}
	private String getValueForKey(String line,String key) {
		String[] data=line.split(":");

		for(int index=0;index<data.length;index++) {
			if(data[index].contains(key)&&(index+1)<data.length) {
				return removeOtherKeywords(data[++index]);
			}
		}
		return null;
	}
	public String getDocumentId(String loadId,String tmsLoadId) {
//		if(Config.DC==DC_TYPE.ATLAS) {
			String outboundUrl=java.text.MessageFormat.format(environment.getProperty("outbound_get_doc_id_ep"),tmsLoadId);
			logger.info("outbound get bol id url:{}",outboundUrl);
			Response resp=SerenityRest.given().relaxedHTTPSValidation().headers(getHeaders()).accept("application/json").get(outboundUrl);
			String jiraDesc="Load Id:"+loadId+"\ntmsloadId:"+tmsLoadId+"\n Download Url:"+outboundUrl;
			Assert.assertEquals(ErrorCodes.OUTBOUND_DOWNLOAD_BOL_FAILED,Constants.SUCESS_STATUS_CODE, resp.getStatusCode(), jiraDesc);
			List<String> listOfDocs=JsonPath.read(resp.asString(), "$..[?(@.documentName=='BOL')].documentReferenceId");
			logger.info("documentReferenceId:{}",listOfDocs.get(0));
			return listOfDocs.get(0);
//		}else {
//			String getDocumentQuery=environment.getProperty("outbound_get_document_id");
//			logger.info("Get Document id query {}",getDocumentQuery);
//			List<Map<String, Object>> result = dbUtils.selectFrom(Config.DC,getDocumentQuery, loadId);
//			logger.info("DB Result for document request:{}",result);
//			return result.get(0).get("doc_content_id").toString();
//		}
	}
	public String getBOL(String documentId) throws IOException {
//		if(Config.DC==DC_TYPE.ATLAS) {
			File bolFile=new File(System.getProperty("user.dir") + "/target/"+documentId.concat(".pdf"));
			Response resp=SerenityRest.given().relaxedHTTPSValidation().headers(getHeaders()).body("{\"documentReferenceIds\" : [\""+documentId+"\"]}").post(environment.getProperty("outbound_get_document_ep"));
			OutputStream outStream = new FileOutputStream(bolFile);
			outStream.write(resp.getBody().asByteArray());
			outStream.close();
			return bolFile.getName();
//		}else {
//		String downloadUrl=MessageFormat.format(environment.getProperty("outbound_get_document_ep"), documentId);
//		File bolFile=new File(System.getProperty("user.dir") + "/target/"+documentId.concat(".pdf"));
//		try {
//		URL url=new URL(downloadUrl);
//		
//			FileUtils.copyURLToFile(url, bolFile);
//		} catch (IOException e) {
//			logger.error(e);
//		}
//		return bolFile.getName();
//		}
	}
	public Headers getHeaders() {
		Header facilityNum;

		facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));

		Header contentType = new Header("Content-Type", "application/json");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(contentType);
		return new Headers(headerList);
	}


}
