package com.walmart.supplychain.nextgen.fixit.mobile.problem.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.utilities.selenium.AppiumDriver;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.fixit.AppiumHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

public class ProblemLabelsPage extends MobilePageObject{
	Logger logger = LogManager.getLogger(this.getClass());
	
	public ProblemLabelsPage(WebDriver driver){
		super(driver);
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Report exception']")
	private WebElement reportException_Button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_qtyTiHi']")
	private WebElement qtyTiHi_Text;
	
	//printer
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CHOOSE PRINTER']")
	private WebElement choosePrinter_Link;
	
	@AndroidFindBy(xpath = "//*[@index='2']")
	private WebElement search_Icon;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@index='1']")
	private WebElement search_Textbox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/tv_problemId']")
	private WebElement problemTicketNum_Text;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.printing.printingandroidapp:id/imageBackButtonScanScreen']")
	private WebElement backAfterCreateProblem_Button;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.fixit.mobile:id/iv_close']")
	private WebElement close_Icon;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout[@index='0']")
	private WebElement firstPrinterOption;

	//Reprint
	@AndroidFindBy(xpath = "//*[@resource-id='com.walmart.move.nim.printing.printingandroidapp:id/imageSearchButton']")
	private WebElement printerSearch_Button;

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@index='0']")
	private WebElement printerOption;


	public void createProblem() {
		reportException_Button.click();
	}

	public void printLabel() {
		choosePrinter_Link.click();
		search_Icon.click();
		search_Textbox.sendKeys("E2ETest");
	}
	
	public void reportProblem() {
		element(reportException_Button).waitUntilVisible();
		reportException_Button.click();
		getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if(!getAndroidDriver().findElements(By.id("com.walmart.move.nim.printing.printingandroidapp:id/imageBackButtonScanScreen")).isEmpty()){
			logger.info("Scan back button visible");
			element(backAfterCreateProblem_Button).waitUntilClickable();
			element(backAfterCreateProblem_Button).click();
		}else if(!getAndroidDriver().findElements(By.xpath("//android.widget.LinearLayout[@index='0']")).isEmpty()){
			logger.info("Selecting Printer");
			element(firstPrinterOption).waitUntilVisible();
			element(firstPrinterOption).click();
		}
		else
			logger.info("Scan back button is not visible");
	}
	
	public String getProblemTicketNum() {
		return problemTicketNum_Text.getText();
	}
	
	public void closeAndroidDriver() {
		getAndroidDriver().close();
	}
	
	public AndroidDriver<AndroidElement> getAndroidDriver() {
	    return (AndroidDriver<AndroidElement>)
	            ((WebDriverFacade) getDriver()).getProxiedDriver();
	}
	
	public void navigateToHomePage() {
		element(close_Icon).waitUntilVisible();
		element(close_Icon).click();
	}

	public void selectPrinter() {
		element(printerSearch_Button).waitUntilVisible();
		element(printerSearch_Button).click();
		element(printerOption).waitUntilVisible();
		element(printerOption).click();
		element(printerSearch_Button).waitUntilVisible();
		element(printerSearch_Button).click();
	}

}
