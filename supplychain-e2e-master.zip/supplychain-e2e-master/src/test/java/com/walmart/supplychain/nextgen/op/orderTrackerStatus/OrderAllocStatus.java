package com.walmart.supplychain.nextgen.op.orderTrackerStatus;

import java.util.HashMap;
import java.util.Map;

public class OrderAllocStatus {
	
	private Map<Integer, String> valueToTextMapping = new HashMap<>();
	
	public OrderAllocStatus() {
		valueToTextMapping.put(0, "NEW");
		valueToTextMapping.put(1, "INPROGRESS");
		valueToTextMapping.put(64,"INACTIVE");
		valueToTextMapping.put(65,"INPROGRESS_INACTIVE");
		valueToTextMapping.put(128,"REJECTED");
		valueToTextMapping.put(129,"INPROGRESS_REJECTED");
		valueToTextMapping.put(192,"FINALIZED_REJECTED");
		valueToTextMapping.put(193,"INPROGRESS_FINALIZED_REJECTED");
	}
	
	public String getValue(int key){
        return valueToTextMapping.get(key);
    }

}
