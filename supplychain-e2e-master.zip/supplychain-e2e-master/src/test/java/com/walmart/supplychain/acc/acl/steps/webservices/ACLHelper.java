package com.walmart.supplychain.acc.acl.steps.webservices;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.domain.acc.ACLtoReceivingVerificationMsg;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class })
public class ACLHelper {
	@Value("${acl_receiving_topic_acc}")
	String aclToRecTopicACC;

	@Autowired
	SpringJmsUtils springJmsUtils;
	
    @Autowired
	StratiConnectionUtil stratiConnectionUtil;
    
    @Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	Logger logger = LoggerFactory.getLogger(ACLHelper.class);

	public void sendVerificationMssg(String deliveryNumber,String lpn) throws JsonProcessingException, JMSException, InterruptedException
	{
		ObjectMapper mapper = new ObjectMapper();
		ACLtoReceivingVerificationMsg verificationMssg = constructVerificationMssg(deliveryNumber, lpn);
		String aclVerificationMssg = mapper.writeValueAsString(verificationMssg);
		publishVerificationMessg(aclVerificationMssg);
	}

	public ACLtoReceivingVerificationMsg constructVerificationMssg(String deliveryNumber,String lpn)
	{
		ACLtoReceivingVerificationMsg verifiationMssg = new ACLtoReceivingVerificationMsg();
		verifiationMssg.setLocationId("D001");
		verifiationMssg.setGroupNbr(deliveryNumber);
		verifiationMssg.setLpn(lpn);
		verifiationMssg.setEventTs(getCurrentTimeStamp());
		return verifiationMssg;
	}

	public String getCurrentTimeStamp()
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime currentTs = LocalDateTime.now(); 
		return dtf.format(currentTs);
	}

	public void publishVerificationMessg(String verifcationMssg) throws JMSException, InterruptedException {
			Thread.sleep(5000);
		logger.info("ACL Verification :: Starting jms publisher... ACL verification message");

        Map headerMssg = new HashMap();
		stratiConnectionUtil.publishStartiMessage(environment.getProperty("receiving_acl_verification_queue"), 
				verifcationMssg, "queue", environment.getProperty("recv_connection_factory"), 
				environment.getProperty("recv_strati_username"),
				environment.getProperty("recv_strati"));
		logger.info("ACL Verification :: Published ACL verification message to Receiving Queue");

	}

}
