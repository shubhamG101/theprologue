package com.walmart.supplychain.atlas.of.scenarioSteps;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import org.json.JSONException;

import com.walmart.supplychain.atlas.of.step.OrderFulfillmentSteps;

public class OrderFulfillmentScenario {

	@Steps
	OrderFulfillmentSteps ofSteps;
	
	@Then("^user verifies soft allocation for all the pallets$")
	public void user_verifies_soft_allocation_() throws JSONException {
		ofSteps.verifySoftAllocation();
	}

	
}
