package com.walmart.supplychain.pharmacy.receiving.steps.mobile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.pharmacy.receiving.scenariosteps.mobile.ReceivingPharmSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ReceivingPharmScenarios {

	@Steps
	ReceivingPharmSteps receivingPharmSteps;

	@Given("^user logins to My app for Pharmacy$")
	public void userLoginsToMyApp() throws JsonProcessingException {
		receivingPharmSteps.loginToMyApps();
	}


	@Then("^user logins to My app for Pharmacy with a different User$")
	public void LoginsToMyApp() throws JsonProcessingException {

		receivingPharmSteps.signoutThenloginToMyAppsForTransferPallet();
	}

	@Given("^user scans door on receiving app$")
	public void userScansTheDoor() throws JsonProcessingException {
		receivingPharmSteps.performDoorScan();
		receivingPharmSteps.validateConfirmTrailerScreen();
		receivingPharmSteps.clickConfirmTrailer();
	}
	
	@Given("^user scans Delivery on receiving app$")
	public void userScansTheDelivery() throws JsonProcessingException {
		receivingPharmSteps.performDeliveryScan();
	}

	@When("^user scans Case and scan case 2D Barcode for \"([^\"]*)\" and \"([^\"]*)\" receiving$")
	public void userScansCaseAndCase2DBarcodesAndReceive(String receiveType, String partialOrFull) {
		receivingPharmSteps.scanSSCCAnd2DBarcodes(receiveType, partialOrFull, false);

	}
	
	@When("^user scans Case and scan case 2D Barcode for \"([^\"]*)\" and cancels pallet$")
	public void userScansCaseAndCase2DBarcodesAndCancelPallet(String receiveType)
			throws JsonProcessingException {
		receivingPharmSteps.scanSSCCAnd2DBarcodes(receiveType, "Complete", true);

	}
	
	@When("^user scans 2D Barcode for \"([^\"]*)\" and \"([^\"]*)\" receiving$")
	public void userScans2DBarcodesAndReceive(String receiveType, String partialOrFull)
			throws JsonProcessingException {
		receivingPharmSteps.scan2DBarcodes(receiveType, partialOrFull);

	}

	@Then("^user validates received Ptags$")
	public void validatePtag() {
		receivingPharmSteps.validatePtags();
	}

	@Given("^user completes the delivery from receiving app$")
	public void completesDeliveryFromReceiving() {
		receivingPharmSteps.deliveryComplete();
	}

	@Then("^validate OSDR in RDS$")
	public void validateOSDRInRDS() {
		receivingPharmSteps.validateOSDRInRDS();
	}

	@Then("^user scans item UPC and proceed for \"([^\"]*)\" receiving of D40$")
	public void fullReceivingOfD40(String partialOrFull) {
		receivingPharmSteps.upcScanForD40orSTO(partialOrFull, false, false);
	}

	@Then("^user scans item UPC and proceed for \"([^\"]*)\" receiving of STO$")
	public void fullReceivingOfSTO(String partialOrFull) {
		receivingPharmSteps.upcScanForD40orSTO(partialOrFull, false, false);
	}

	@Then("^user scans item UPC and proceed for catalogued receiving of D40$")
	public void cataloguedReceivingOfD40() {
		receivingPharmSteps.upcScanForD40orSTO("Complete", true, false);
	}

	@Then("^user scans item UPC and proceed for GTIN cataloguing with UPC \"([^\"]*)\" for D40$")
	public void cataloguedWithItemUPCReceivingOfD40(boolean catalogueWithUpc) {
		receivingPharmSteps.upcScanForD40orSTO("Complete", true, catalogueWithUpc);
	}


	@Then("^user cancels the Label$")
	public void cancelTheLabel() {
		receivingPharmSteps.cancelLabel(true);
	}

	@Then("^user verifies container status in receiving as \"([^\"]*)\" for the cancelled Label$")
	public void validateCancelledLabelContainerStatusInReceiving(String expectedContainerStatus) {
		receivingPharmSteps.validateCancelledLabelContainerStatusInReceiving(expectedContainerStatus);
	}

	@Then("^user validates cancelled Labels in RDS$")
	public void validateCancelledLabelInRDS() {
		receivingPharmSteps.validateCancelledLabelInRDS();
	}
	
	@Then("^user kills the app$")
	public void killApp() {
		try {
			Thread.sleep(5000);
			receivingPharmSteps.killApp();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Given("^user prints Delivery label and unloads Delivery$")
	public void userUnloadsDelivery() throws JsonProcessingException {
		receivingPharmSteps.userUnloadsDelivery();
	}
	
	@Given("^user validates whether door got detached from the Delivery$")
	public void validateDoorWhetherDoorGotDetached() throws JsonProcessingException {
		receivingPharmSteps.validateWhetherDoorGotDetached();
	}

	@Given("^user clicks on partial receiving link from UI$")
	public void clickspartialReceiving() throws JsonProcessingException {
		receivingPharmSteps.clicksOnReceivePartialCase();

	}

	@Then("^reopen the delivery by Key-in delivery$")
	public void reopendelivery() throws JsonProcessingException {
		receivingPharmSteps.performDeliveryScan();
		receivingPharmSteps.reopendelivery();

	}

	@Then("^user cancels the Label from inside the delivery$")
	public void cancelLabelFromInsideTheDelivery() {
		receivingPharmSteps.labelCancelFromInsideDelivery();
	}

	@Then("^user transfers the pallet and proceed for \"([^\"]*)\" receiving of D40$")
	public void receivingOfD40AfterTransferPallet(String partialOrFull) {
		receivingPharmSteps.receiveAfterTransferringPallet(partialOrFull, false, false);
	}

}
