package com.walmart.supplychain.baja.op.step;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.op.EnrichOrderSearchCriteria;
import com.walmart.framework.supplychain.domain.op.EnrichUpdateOrderWithSearchCriteria;
import com.walmart.framework.supplychain.domain.op.ModifyEnrichOrder;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OrderEnrichStep {

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Autowired
	ReleaseOrderStep releaseOrderStep;

	Logger logger = LogManager.getLogger(this.getClass());
	String time = "T00:00:00";
	String testFlowData;
	
	@Step
	public void userEnrichReleaseOrders() throws JSONException, IOException {
		
		testFlowData = String.valueOf(tl.get().get("testFlowData"));
		String cycleN, waveN;
		
		try {

			logger.info("$$$ TestFlowData before validating if order is enriched or not is :{}", 
					String.valueOf(tl.get().get("testFlowData")));
			
			List<String> itemnumber = JsonPath.read(testFlowData, "$..testFlowData.ordersDetails[*].itemNumber");
			Set<String> uniqueItems = new HashSet<>(itemnumber);
		    logger.info("Unique items size {}: ", uniqueItems.size());
		        
			List<String> destinationNum = JsonPath.read(testFlowData, "$..destinationNum");
			Set<String> uniqueDest = new HashSet<>(destinationNum);
		    logger.info("Unique dest size {}: ", uniqueDest.size());

			List<Integer> orgunit = new ArrayList<>();
			orgunit.add(2);
			List<Integer> releaseNbrs = new ArrayList<>();
			releaseNbrs.add(-1);

			ObjectMapper om = new ObjectMapper();
			EnrichOrderSearchCriteria enrichorderpayload = constructEnrichPayload(uniqueItems, uniqueDest, orgunit,
					releaseNbrs);
			String requestBody = om.writeValueAsString(enrichorderpayload);
			logger.info("Search Payload for verifying if orders are enriched{}", requestBody);

			String requestBodyFailSafe = requestBody;
			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 15)).run(() -> {

				Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
						.post(environment.getProperty("op_enrichorders"));
				Assert.assertEquals(ErrorCodes.BAJA_ORDER_ENRICH, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			});

			Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
					.post(environment.getProperty("op_enrichorders"));
			Assert.assertEquals(ErrorCodes.BAJA_ORDER_ENRICH, Constants.SUCESS_STATUS_CODE, response.getStatusCode());

			logger.info("Response from search enriched order " + response.getBody().asString());
			validateCreatedOrderIsEnriched(response);

			JSONArray effectiveReleaseDate = JsonPath.parse(response.getBody().asString()).read("$.listOfEntities[?(@.destNbr=='" + destinationNum.get(0) + "')]..effectiveReleaseDate",
					JSONArray.class);

			JSONArray cycleNbr = JsonPath.parse(response.getBody().asString())
					.read("$.listOfEntities[?(@.destNbr=='" + destinationNum.get(0) + "')]..cycleNbr", JSONArray.class);
			cycleN = cycleNbr.get(0).toString();
			
			JSONArray waveNbr = JsonPath.parse(response.getBody().asString())
					.read("$.listOfEntities[?(@.destNbr=='" + destinationNum.get(0) + "')]..waveNbr", JSONArray.class);
			waveN = waveNbr.get(0).toString();
			
			logger.info("Order Got Enriched with Effective Release date" + effectiveReleaseDate.get(0).toString());
			logger.info("Verify if the effective release is current date or it needs to be modified");

			logger.info("TestFlowData:" + tl.get().get("testFlowData").toString());

			if (effectiveReleaseDate.get(0).toString().contains(javaUtils.getCurrentDate())) {
				logger.info("Eff Release date is Today's-->Release the order");
				releaseOrderStep.userReleaseOrders(cycleN, waveN);
			} else {
				logger.info("Enriched order effective release date needs to be updated to current release date");
				modifyEnrichment(enrichorderpayload, cycleN, waveN);
				releaseOrderStep.userReleaseOrders(cycleN, waveN);
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while enriching the orders", e);
		}

	}

	private void validateCreatedOrderIsEnriched(Response response) {
		logger.info("Validaing the enriched orders are the one which was created during data setup");
		boolean match=false;
		
		try {
			JSONArray actualOrderTrackingNbr = JsonPath.parse(response.getBody().asString())
					.read("$..origTrackingNbr", JSONArray.class);		
			JSONArray expOrderTrackingNbr = JsonPath.read(testFlowData, "$..orderTrackingNumber");

			//this will check size of actual and expected tracking number
			Assert.assertTrue(ErrorCodes.BAJA_EXTRA_ORDER_ENRICH,actualOrderTrackingNbr.size()==expOrderTrackingNbr.size());		
			
			//this will compare the values in the 2 arrays
			for(int i=0;i<actualOrderTrackingNbr.size();i++){
				match = false;
				for(int j=0;j<expOrderTrackingNbr.size();j++){
					if(actualOrderTrackingNbr.get(i).equals(expOrderTrackingNbr.get(j)))
					{
						match=true;
						break;
					}
					}
			}
			
			if(!match)
			Assert.assertTrue(ErrorCodes.BAJA_WRONG_ORDER_ENRICH, false);			
			
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating the number of orders enriched", e);
		}
	}

	public void modifyEnrichment(EnrichOrderSearchCriteria enrichOrderSearchCriteriaPayload, String cycleNbr,
			String waveNbr) throws JsonProcessingException {
		try {
			logger.info("Modifying the effective release date for enriched order");
			EnrichUpdateOrderWithSearchCriteria modifyOrderenrichPayload = constructmodifyPayload(enrichOrderSearchCriteriaPayload, cycleNbr, waveNbr);
			ModifyEnrichOrder modifyenrichorderPayload = contructfullPayload(modifyOrderenrichPayload);
			logger.info("Modify Enrichment payload:-" + modifyenrichorderPayload);

			ObjectMapper om = new ObjectMapper();
			String requestBody = om.writeValueAsString(modifyenrichorderPayload);
			String requestBodyFailSafe = requestBody;

			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS, 10, 10)).run(() -> {

				Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
						.put(environment.getProperty("modify_enrich_orders"));
				Assert.assertEquals(ErrorCodes.BAJA_ORDER_MODIFY_ENRICHMENT, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
			});

			Response response = SerenityRest.given().contentType("application/json").body(requestBodyFailSafe)
					.put(environment.getProperty("modify_enrich_orders"));
			Assert.assertEquals(ErrorCodes.BAJA_ORDER_MODIFY_ENRICHMENT, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());

			JSONArray updateStatus = JsonPath.parse(response.getBody().asString()).read("$..successUpdateCount",
					JSONArray.class);
			logger.info("Orders enriched successfully with status " + updateStatus.get(0));
			
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while modifying the enriched orders", e);
		}
	}

	public EnrichOrderSearchCriteria constructEnrichPayload(Set<String> itemNumber, Set<String> destinationNum,
			List<Integer> orgunit, List<Integer> releaseNbrs) {
		EnrichOrderSearchCriteria enrichOrders = new EnrichOrderSearchCriteria();
		enrichOrders.setOrgUnitIds(orgunit);
		enrichOrders.setitemNbrs(itemNumber);
		enrichOrders.setdestNbrs(destinationNum);
		enrichOrders.seteffectiveRelDate(null);
		enrichOrders.setorderDownloadDate(null);
		enrichOrders.setcycleWave(null);
		enrichOrders.setreleaseNbrs(releaseNbrs);
		return enrichOrders;

	}

	public EnrichUpdateOrderWithSearchCriteria constructmodifyPayload(
			EnrichOrderSearchCriteria enrichOrderSearchCriteriapayload, String cycleNbr, String waveNbr)
			throws JsonProcessingException {

		EnrichUpdateOrderWithSearchCriteria enrichUpdateOrderWithSearchCriteria = new EnrichUpdateOrderWithSearchCriteria();
		enrichUpdateOrderWithSearchCriteria.setenrichOrderSearchCriteria(enrichOrderSearchCriteriapayload);
		enrichUpdateOrderWithSearchCriteria.setwaveNbr(waveNbr);
		enrichUpdateOrderWithSearchCriteria.setcycleNbr(cycleNbr);
		enrichUpdateOrderWithSearchCriteria.setStatus("New");
		enrichUpdateOrderWithSearchCriteria.seteffectiveReleaseDate(javaUtils.getCurrentDate().concat(time));
		ObjectMapper om = new ObjectMapper();
		logger.info(om.writeValueAsString(enrichUpdateOrderWithSearchCriteria));
		logger.info("Completed payload for modifying enrich order effec release date");
		return enrichUpdateOrderWithSearchCriteria;
	}

	public ModifyEnrichOrder contructfullPayload(EnrichUpdateOrderWithSearchCriteria eos)
			throws JsonProcessingException {
		logger.info("Creating payload for modifying enrich order effec release date");
		ModifyEnrichOrder modifyEnrichOrderPayload = new ModifyEnrichOrder();
		modifyEnrichOrderPayload.setenrichUpdateOrderWithSearchCriteria(eos);
		ObjectMapper om = new ObjectMapper();
		logger.info("Get the Payload-->" + om.writeValueAsString(modifyEnrichOrderPayload));
		return modifyEnrichOrderPayload;
	}
}
