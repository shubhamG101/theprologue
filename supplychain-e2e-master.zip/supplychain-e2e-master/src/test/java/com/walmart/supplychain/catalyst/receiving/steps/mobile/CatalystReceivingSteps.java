
package com.walmart.supplychain.catalyst.receiving.steps.mobile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import com.walmart.supplychain.catalyst.by.ui.steps.BYUiHelper;
import com.walmart.supplychain.catalyst.loading.pages.mobile.CatalystLoadingPage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystByMobilePage;
import com.walmart.supplychain.catalyst.receiving.pages.mobile.CatalystReceivingPage;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.idm.steps.webservices.IDMSteps;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.google.common.collect.ImmutableMap;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.catalystutilities.CatalystUtil;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmSteps;
import com.walmart.supplychain.pharmacy.receiving.pages.mobile.ReceivingPharmPage;

import cucumber.api.DataTable;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.strati.libs.commons.configuration.ConfigurationException;
import io.strati.libs.commons.configuration.PropertiesConfiguration;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystReceivingSteps extends ScenarioSteps {

	@Autowired
	CatalystReceivingPage catalystReceivingPage;

	@Autowired
	CatalystByMobilePage catalystByMobilePage;

	@Autowired
	CatalystLoadingPage catalystLoadingPage;

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	@Autowired
	GDMPharmSteps gdmPharmSteps;

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	IDMSteps idmSteps;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	GDMPharmHelper gdmPharmHelper;

	@Autowired
	JavaUtils javaUtils;
	
	@Autowired
	BYUiHelper byUiHelper;
	
	@Autowired
	CatalystUtil catalystUtil;
	
	@Autowired
	CatalystReceivingHelper catalystReceivingHelper;
	
	@Autowired
	PreRunCleanup preRunCleanup;

	private List<String> poNumberList;

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);
	
	RetryPolicy retryPolicy_50s = JavaUtils.getRetryPolicy(5,10);
	RetryPolicy retryPolicy_20s = JavaUtils.getRetryPolicy(2,10);
	private static final String TEST_FLOW_DATA = "testFlowData";
	public static final String POSITIVE_SAFETY_STATUS="Positive";
	

	Logger logger = LogManager.getLogger(this.getClass());

	static String LPN="";
	List<String> doorList = new ArrayList<String>();
	List<String> lpnList = new ArrayList<String>();
	List<String> lpnStatus = new ArrayList<String>();
	
	private static List<String> poNumber;
	private static List<String> itemNumbers;
	private List<ReceivingInstruction> totalRecInstList = new ArrayList<ReceivingInstruction>();
	
	private static int totalQuantity = 0;
	private static int totalReceivedQuantity = 0;
	private static int totalOverageQuantity = 0;
	private static int totalShortQuantity = 0;
	private static int totalDamagedQuantity = 0;
	private static int totalRejectedQuantity = 0;
	
	private Map<String, String> itemsWithReceivedLpnAsRocStatus = new HashMap<String, String>();
	
	int actualReceivedCasesAfterReceiving = 0;
	int initialReceivedCases = 0;
	
	@Step
	public void openAppFromLauncher(String appName) {
		try {
			logger.info("opening Launcher");
			//we can comment these killApp steps if needed
//			if(catalystReceivingPage.isPermissionDialogDisplayed()) {
//				catalystReceivingPage.clickOnAllowPermissionButton();
//			}
			killAppForCatalyst("RECEIVING");
			killAppForCatalyst("BY_MOBILE");
			killAppForCatalyst("LOADING");
			if(catalystReceivingPage.isPermissionDialogDisplayed()) {
				catalystReceivingPage.clickOnAllowPermissionButton();
			}
			catalystReceivingPage.clickOnSiteSelectBox();
			Failsafe.with(retryPolicy).run(() -> {
			catalystReceivingPage.selectSite(environment.getProperty("env"));
			});
			catalystReceivingPage.clickOnConfirmButton();
			catalystReceivingPage.clickOnContinueButton();

			switch (appName.toUpperCase()) {
			case "RECEIVING":
				catalystReceivingPage.clickOnReceivingIcon();
				break;

			case "BY_MOBILE":
				catalystReceivingPage.clickOnBYMobileAppIcon();
				break;

			case "LOADING":
				catalystReceivingPage.clickOnLoadingIcon();
				break;
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Open "+appName+" App from Launcher", e);
		}

	}

	public void killAppForCatalyst(String appName) throws ConfigurationException, InterruptedException {
		try {	
			if (getDriver() != null) {
				switch (appName.toUpperCase()) {
				case "RECEIVING":
					logger.info("Closing App=" + getDriver());
					killAppInBackground("com.walmart.logistics.receiving");
					getDriver().quit();
					logger.info("Closed App RECEIVING");
					break;

				case "BY_MOBILE":
					logger.info("Closing App=" + getDriver());
					killAppInBackground("com.walmart.logistics.blueyonder.mobile");
					getDriver().quit();
					logger.info("Closed App BY_MOBILE");
					break;

				case "LOADING":
					logger.info("Closing App=" + getDriver());
					killAppInBackground("com.walmart.logistics.loading");
					getDriver().quit();
					logger.info("Closed App LOADING");
					break;

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}




	@Step
	public void userLoginsAndEnterEnvDetails(String appName, String task) throws InterruptedException {
		try {
			
			Thread.sleep(2000);
			//	LPN="00LPN"+ javaUtils.randonNumberGenerator(5)+javaUtils.randonNumberGenerator(5);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");

			switch (appName.toUpperCase()) {
			case "RECEIVING":{
				Thread.sleep(2000);

				catalystReceivingPage.enterReceivingUserName(environment.getProperty("userName"));
				catalystReceivingPage.enterReceivingPassword(environment.getProperty("receiving_p"));
				catalystReceivingPage.clickOnReceivingSignInButton();
				catalystReceivingPage.enterDeviceNumber(environment.getProperty("deviceNumber"));
				catalystReceivingPage.clickOnSubmitButton();
				catalystReceivingPage.enterLocationNumber(doorList.get(0));
				catalystReceivingPage.clickOnSubmitButton();			
				break;

			}
			case "BY_MOBILE":{
				//catalystByMobilePage.clickOnByContinueButton();
				catalystByMobilePage.enterByUserName(environment.getProperty("userName"));
				catalystByMobilePage.enterByPassword(environment.getProperty("receiving_p"));
				catalystByMobilePage.clickOnBySignInButton();

				catalystByMobilePage.enterTerminalIdTextBox(environment.getProperty("deviceNumber"));
				catalystByMobilePage.clickOnByDismissButton();
				catalystReceivingPage.pressEnter();
				if(task.equalsIgnoreCase("putaway")) {
					if(catalystByMobilePage.isLocationTextBoxDisplayed()) {
					catalystByMobilePage.enterLocationValue(doorList.get(0));
					catalystByMobilePage.clickOnDownButton();
					catalystByMobilePage.enterVehicleTypeValue(environment.getProperty("vehicleType"));
					catalystByMobilePage.clickOnDownButton();
					catalystByMobilePage.enterWorkAreaValue(environment.getProperty("workArea"));
					catalystByMobilePage.clickOnDownButton();}
					
				}
				else if(task.equalsIgnoreCase("picking")) {
					List<String>	sourceLocationList=JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");			
					//	destinationLocationList=JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");			
					//  workOperation=	JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
					//catalystByMobilePage.enterLocationValue(sourceLocationList.get(0));
					catalystByMobilePage.enterLocationValue(sourceLocationList.get(0));
					catalystByMobilePage.clickOnDownButton();
					catalystByMobilePage.enterVehicleTypeValue(environment.getProperty("pickingVehicleType"));
					catalystByMobilePage.clickOnDownButton();
					catalystByMobilePage.enterWorkAreaValue(environment.getProperty("pickingWorkArea"));
					catalystByMobilePage.clickOnDownButton();
				}
				break;
			}
			case "LOADING":{
				Thread.sleep(2000);

				catalystLoadingPage.enterLoadingUserName(environment.getProperty("userName"));
				catalystLoadingPage.enterLoadingPassword(environment.getProperty("receiving_p"));
				catalystLoadingPage.clickOnLoadingSignInButton();
				catalystReceivingPage.enterDeviceNumber(environment.getProperty("deviceNumber"));
				catalystReceivingPage.pressEnter();
				catalystReceivingPage.clickOnSubmitButton();
				catalystReceivingPage.clickEquipmentExpandDropdownButton();
				if(task.equalsIgnoreCase("wrapping")) {
					catalystReceivingPage.scrollAndClick(environment.getProperty("wrapingEquipment"));
					catalystReceivingPage.clickOnSubmitButton();
					catalystReceivingPage.enterLocationNumber(environment.getProperty("wrapingLocation"));}
				else if(task.equalsIgnoreCase("loading")) {
					catalystReceivingPage.scrollAndClick(environment.getProperty("loadingEquipment"));
					catalystReceivingPage.clickOnSubmitButton();
					catalystReceivingPage.enterLocationNumber(environment.getProperty("loadingLocation"));

				}
				catalystReceivingPage.pressEnter();
				catalystReceivingPage.clickOnSubmitButton();
				break;
			}


			}
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to login and enter environment details", e);
		}
	}

	
	@Step
	public void enterByLoginAndEnvDetailsBasedOnWorkOperation( String workOperation) throws InterruptedException {
		try {
			Thread.sleep(2000);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
				catalystByMobilePage.enterByUserName(environment.getProperty("userName"));
				catalystByMobilePage.enterByPassword(environment.getProperty("receiving_p"));
				catalystByMobilePage.clickOnBySignInButton();

				catalystByMobilePage.enterTerminalIdTextBox(environment.getProperty("deviceNumber"));
				catalystByMobilePage.clickOnByDismissButton();
				catalystReceivingPage.pressEnter();
				if (!catalystByMobilePage.isLocationTextBoxDisplayed()) {
					performByLogout();
					catalystByMobilePage.enterByUserName(environment.getProperty("userName"));
					catalystByMobilePage.enterByPassword(environment.getProperty("receiving_p"));
					catalystByMobilePage.clickOnBySignInButton();

					catalystByMobilePage.enterTerminalIdTextBox(environment.getProperty("deviceNumber"));
					catalystByMobilePage.clickOnByDismissButton();
					catalystReceivingPage.pressEnter();
				} 
				
				catalystByMobilePage.enterLocationValue(doorList.get(0));
				catalystByMobilePage.clickOnDownButton();
				catalystByMobilePage.selectVehicleTypeValue(workOperation);
				//catalystByMobilePage.enterVehicleTypeValue(environment.getProperty("vehicleType"));
				catalystByMobilePage.clickOnDownButton();
				catalystByMobilePage.enterWorkAreaValue(environment.getProperty("workArea"));
				catalystByMobilePage.clickOnDownButton();
			
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
			
		} catch (Exception e) {
			throw new AutomationFailure("Failed to login and enter environment details", e);
		}
	}
	
	
	@Step
	public void performUnloading() throws InterruptedException {
		try {

			LPN="00LPN"+ javaUtils.randonNumberGenerator(5)+javaUtils.randonNumberGenerator(5);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");

			List<String> itemUPCList = JsonPath.read(testFlowData, "$..poDetails[*].poLineDetails..caseUpc");

			catalystReceivingPage.clickOnDropdownExpandButton();
			catalystReceivingPage.clickOnUnloadingOption();	
			catalystReceivingPage.clickOnTrySearchingLink();
			catalystReceivingPage.enterDoorNumber(doorList.get(0));
			Thread.sleep(1000);
			catalystReceivingPage.clickOnReceivingSearchButton();
			Thread.sleep(1000);
			catalystReceivingPage.clickOnSearchResultsCheckedInArrowButton();

			//Safety Questions

			catalystReceivingPage.clickOnOpenDoorButton();
			catalystReceivingPage.verifyDoorTitleIsDisplayed();
			Failsafe.with(retryPolicy).run(() -> {
			catalystReceivingPage.verifyTrailerDetailsIsDisplayed();
			});
			Failsafe.with(retryPolicy).run(() -> {
			catalystReceivingPage.verifyCorrectDockDoorSafetyQuestionIsDisplayed();
			});
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyCorrectCarrierTrailerNumberSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyDockPlateSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyTrailerLightSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyTrailerHeightSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyFloorBoardsSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyFloorFreeOfSpilledLiquidSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyTrailerDockDoorHeightSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyFreightStabilitySafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyPalletConditionSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyMerchandiseDamageFreeSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyPestFreeTrailerSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyHazardFreeTailerSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();


			//LPN
			catalystReceivingPage.performScan(LPN);
			catalystReceivingPage.enterUpc(itemUPCList.get(0));
			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.verifyUnloadFreightTitleIsDisplayed();
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnNavigateUpButton();
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to perform Unload ", e);
		}

	}

	@Step
	public void scanLocationAndDockDoor() throws InterruptedException {	
		try {
			
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			catalystReceivingPage.clickOnDropdownExpandButton();
			catalystReceivingPage.clickOnReceivingOption();	
			catalystReceivingPage.clickOnTrySearchingLink();
			catalystReceivingPage.enterDoorNumber(doorList.get(0));
			Thread.sleep(1000);
			catalystReceivingPage.clickOnReceivingSearchButton();
			Thread.sleep(1000);
			catalystReceivingPage.clickOnSearchResultsCheckedInArrowButton();
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to add Location and Dock door details", e);
		}

	}

	@Step
	public void scanLpnAndUpcAndStartReceiving(String receivedStatus) throws InterruptedException, ConfigurationException {	
		try {
			LocalDate date = LocalDate.now();
			LocalDate expdate=date.plusYears(1);
			Thread.sleep(20000);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> itemUPCList = JsonPath.read(testFlowData, "$..poDetails[*].poLineDetails..caseUpc");

			catalystReceivingPage.performScan(LPN);
			catalystReceivingPage.enterUpc(itemUPCList.get(0));
			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.enterReceivingQty("1");
			catalystReceivingPage.changeInventoryStatus(receivedStatus);
			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.enterCityOfOrigin(environment.getProperty("cityOfOrigin"));
			catalystReceivingPage.enterExpirationDate(expdate.toString());
			catalystReceivingPage.pressEnter();
			catalystReceivingPage.pressEnter();
			catalystReceivingPage.setReceivingDetails(LPN.substring(2), 1,receivedStatus, expdate.toString());
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to perform receiving", e);		
		}
	}

	@Step
	public void performPutaway() throws InterruptedException, ConfigurationException {	
		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			lpnStatus = JsonPath.read(testFlowData, "$..receivingInstructions..receivedStatus");
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyPickUpProductAtHeadingIsDisplayed();
			catalystByMobilePage.verifySourceLocationLabelIsDisplayed();
			catalystByMobilePage.verifySourceLocationValueIsDisplayed(doorList.get(0));
			catalystByMobilePage.clickOnNextButton();
			catalystByMobilePage.enterInventoryIdentifier(lpnList.get(0));
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.sleep(2);
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyInventoryDepositDialogIsDisplayed();
			catalystByMobilePage.clickOnOkButton();		
			catalystByMobilePage.verifyMrgProductDepositHeadingIsDisplayed();
			    if(lpnStatus.get(0).equalsIgnoreCase("Problems")) {
			    	catalystByMobilePage.verifyProblemItemHeadingIsDisplayed();
			    	catalystByMobilePage.verifyReworkLocationDisplayedForProblemItem();
//			    	Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_RECEIVED_CASES, expectedReceivedCasesAfterReceiving, actualReceivedCasesAfterReceiving);			    	
					catalystByMobilePage.enterDesiredPutawayLocationTextBox(environment.getProperty("penaltyBoxLocation"));
				} else {
					catalystByMobilePage.enterPutawayLocationTextBox();
				}
			catalystByMobilePage.clickOnDownButton();
			catalystByMobilePage.verifyUndirectedMenuHeadingIsDisplayed();
		}
		catch (AssertionError | FailsafeException e) {
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			preRunCleanup.cleanUpReceivedInventoryDetailsCatalyst();
			throw new AutomationFailure("Failed to perform Putaway", e);
		}
	}
	
	
	@Step
	public void performByLogout() throws InterruptedException {	
		try {
//			catalystByMobilePage.verifyUndirectedMenuHeadingIsDisplayed();
			if(catalystReceivingPage.elementPresentBasedOnPartialText("OK")) {
				catalystReceivingPage.clickOnElementBasedOnPartialText("OK");
			}
			Failsafe.with(retryPolicy_20s).run(() -> {
			catalystReceivingPage.clickOnNavigateUpButton();
			Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_BY_APP_LOGOUT_POPUP_NOT_VISIBLE, true, catalystReceivingPage.isElementPresentBasedOnPartialText("Logout"));
			
			});
			catalystByMobilePage.clickOnYesButton();
			catalystByMobilePage.clickOnYesButton();
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to perform Putaway", e);
		}
		
	}
	
	@Step
	public void performReceivingAppLogout() throws InterruptedException, ConfigurationException {	
		try {			
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnUserButton();
			catalystReceivingPage.clickOnSignOutButton();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.selectYesButton();
					
			
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to perform Putaway", e);
		}
		
	}
	
	@Step
	public void performManualPutaway() throws InterruptedException, ConfigurationException {	
		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			catalystByMobilePage.clickOnInventoryMenuOption();
			catalystByMobilePage.clickOnNextOption();
			catalystByMobilePage.clickOnPutawayOption();
			catalystByMobilePage.enterInventoryIdentifier(lpnList.get(0));
			catalystByMobilePage.clickOnDownButton();
			
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystByMobilePage.clickOnDirectedWorkOption();
			catalystByMobilePage.verifyInventoryDepositDialogIsDisplayed();
			catalystByMobilePage.clickOnOkButton();
			catalystByMobilePage.verifyMrgProductDepositHeadingIsDisplayed();
			catalystByMobilePage.enterDesiredPutawayLocationTextBox(environment.getProperty("RipeningRoomLocation"));
			catalystByMobilePage.clickOnDownButton();
			
		}
		catch (AssertionError | FailsafeException e) {
			catalystReceivingHelper.updateConfig("false"); 
			throw new TestCaseFailure(e);
			
		} catch (Exception e) {
			catalystReceivingHelper.updateConfig("false"); 
			throw new AutomationFailure("Failed to add perform Manual Putaway", e);
		}
	}
	

	public void killAppInBackground(String appPackage) {
		logger.info("Killing App in Background" + appPackage);
		List<String> scanAttributes = Arrays.asList(appPackage);
		getAndroidDriver().resetApp();
		Map<String, Object> scanEvent = ImmutableMap.of("command", "am force-stop", "args", scanAttributes);
		getAndroidDriver().executeScript("mobile: shell", scanEvent);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("Killed App in Background" + appPackage);
	}

	public AndroidDriver<AndroidElement> getAndroidDriver() {
		return (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
	}

	
	@Step
	public void performOverages(){	
		try {
		
		String overageLPN="00LPN"+ javaUtils.randonNumberGenerator(5)+javaUtils.randonNumberGenerator(5);
		LocalDate date = LocalDate.now();
		LocalDate expdate=date.plusYears(1);
		Thread.sleep(8000);
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		List<String> itemUPCList = JsonPath.read(testFlowData, "$..poDetails[*].poLineDetails..caseUpc");
		
		catalystReceivingPage.validateTextBeforeOverages();
		catalystReceivingPage.performScan(overageLPN);	
		catalystReceivingPage.enterUpc(itemUPCList.get(0));
		catalystReceivingPage.clickOnReceivingNextButton();
		//To perform Overages we are receiving Quantity as 1
		String overagesQty = "1";
		catalystReceivingPage.enterReceivingQty(overagesQty);
		catalystReceivingPage.clickOnReceivingStatusDropdownArrow();
		catalystReceivingPage.scrollAndClick("Available");
		catalystReceivingPage.enterReceivingQty(overagesQty);
		catalystReceivingPage.clickOnNextButton();
		catalystReceivingPage.confirmOverages();
		Thread.sleep(2000);
		catalystReceivingPage.enterCityOfOrigin(environment.getProperty("cityOfOrigin"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterExpirationDate(expdate.toString());
		catalystReceivingPage.pressEnter();
		Thread.sleep(4000);
		Failsafe.with(retryPolicy).run(() -> {
		String validteTotalReceivedCases = catalystReceivingPage.totalCasesNeedToBeReceived();	
		});
		catalystReceivingPage.setOverageReceivingDetails(overageLPN.substring(2),overagesQty);
		
		logger.info("WMT_RECEIVING : Received Item as Overages");
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing the Overages", e);
		}
	}	
	
	@Step
	public void performFullReceive(String receivedStatus) {
		try {

			String fullReceiveLPN = "00LPN" + javaUtils.randonNumberGenerator(5) + javaUtils.randonNumberGenerator(5);
			LocalDate date = LocalDate.now();
			LocalDate expdate = date.plusYears(1);
			Thread.sleep(5000);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> itemUPCList = JsonPath.read(testFlowData, "$..poDetails[*].poLineDetails..caseUpc");
			
			String totalCases = catalystReceivingPage.totalCasesNeedToBeReceived();
			int convertToInt = Integer.parseInt(totalCases);
			
			catalystReceivingPage.performScan(fullReceiveLPN);
			catalystReceivingPage.enterUpc(itemUPCList.get(0));
			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.enterReceivingQty(totalCases);
			catalystReceivingPage.clickOnReceivingStatusDropdownArrow();
			catalystReceivingPage.scrollAndClick(receivedStatus);
			catalystReceivingPage.enterReceivingQty(totalCases);
			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.enterCityOfOrigin(environment.getProperty("cityOfOrigin"));
			Thread.sleep(500);
			catalystReceivingPage.pressEnter();
			catalystReceivingPage.enterExpirationDate(expdate.toString());
			Thread.sleep(1000);
			catalystReceivingPage.pressEnter();
			
			catalystReceivingPage.setFullReceivingDetails(fullReceiveLPN.substring(2), convertToInt, receivedStatus,expdate.toString());
			logger.info("Received all the expected cases ===> {}", totalCases);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing full receive", e);
		}
	}
	
	public void validateTotalCasesAndHandleMoreFreightPopupForOverages() {
		catalystReceivingPage.handleMoreFreightPopUpWithYes();
		Failsafe.with(retryPolicy).run(() -> {
			String validteTotalReceivedCases = catalystReceivingPage.totalCasesNeedToBeReceived();
			});
	}
	
	public void handleHACCPComponents() {
		try {
		catalystReceivingPage.handleRecordExistsPopUp();
		catalystReceivingPage.validateHaccpScreen();
		catalystReceivingPage.enterHaccpTemp(environment.getProperty("temp_Reveiving"));
		catalystReceivingPage.pressEnter();
		Thread.sleep(4000);
		catalystReceivingPage.handleMoreFreightPopUpOrClickCompleteShipment();
		Thread.sleep(4000);
		catalystReceivingPage.handlePendingInspectionPopUp();
		}catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing full receive", e);
		}
	}
	
	@Step
	public void handleTiHiComponents(String receivedStatus) {
		try {

			String fullReceiveLPN = "00LPN" + javaUtils.randonNumberGenerator(5) + javaUtils.randonNumberGenerator(5);
			Thread.sleep(5000);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			List<String> itemUPCList = JsonPath.read(testFlowData, "$..poDetails[*].poLineDetails..caseUpc");
			List<String> itemNumber = JsonPath.read(testFlowData, "$..poDetails..itemNumber");
			String receivingQuantity = null;

			catalystReceivingPage.performScan(fullReceiveLPN);
			catalystReceivingPage.enterUpc(itemUPCList.get(0));
			catalystReceivingPage.clickOnReceivingNextButton();
			Thread.sleep(5000);
			receivingQuantity = catalystReceivingPage.countTiHiForAnItem();

			catalystReceivingPage.enterReceivingQty(receivingQuantity);
			catalystReceivingPage.clickOnReceivingStatusDropdownArrow();
			catalystReceivingPage.scrollAndClick(receivedStatus);
			catalystReceivingPage.enterReceivingQty(receivingQuantity);
			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.handleTiHiExceededPopUp();
			catalystReceivingPage.verifyEnteredQuantity(receivingQuantity);
			catalystReceivingPage.verifyTiHiItemNumber(itemNumber.get(0));
			catalystReceivingPage.clickOnOkButton();

			logger.info("WMT_RECEIVING : Validated TiHi Components Successfully");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while validating TiHi Components", e);
		}
	}
	
	@Step
	public void reverseLPN(String receivedStatus) {
		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			lpnStatus = JsonPath.read(testFlowData, "$..receivingInstructions..receivedStatus");
			
			catalystReceivingPage.clickOnContextMenu();
			catalystReceivingPage.selectReverseReceiptOption();
			catalystReceivingPage.enterLPNtoBeReversed(lpnList.get(0));
			catalystReceivingPage.validateReverseReceiptPage(receivedStatus);
			catalystReceivingPage.clickOnReverseReceiptButton();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("WMT_RECEIVING : Something went wrong while reversing LPN ", e);
		}
	}
	
	@Step
	public void performPutawayforAllLPNs() throws InterruptedException {	
		try {
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer");
			lpnList = JsonPath.read(testFlowData, "$..receivingInstructions..overrageLPN");

			lpnList.add(JsonPath.read(testFlowData, "$..receivingInstructions..parentContainer"));
			lpnList.add(JsonPath.read(testFlowData, "$..receivingInstructions..overrageLPN"));

			for(int i =0; i<lpnList.size(); i++) {
				//After completing the verifyUndirectedMenuHeadingIsDisplayed where the controller will be?
				catalystByMobilePage.clickOnDirectedWorkOption();
				catalystByMobilePage.verifyPickUpProductAtHeadingIsDisplayed();
				catalystByMobilePage.verifySourceLocationLabelIsDisplayed();
				catalystByMobilePage.verifySourceLocationValueIsDisplayed(doorList.get(0));
				//catalystByMobilePage.verifySourceLocationValueIsDisplayed(environment.getProperty("doorNumber"));
				catalystByMobilePage.clickOnNextButton();
				catalystByMobilePage.enterInventoryIdentifier(lpnList.get(i));
				//catalystByMobilePage.enterInventoryIdentifier(environment.getProperty("LPN").substring(2));
				catalystByMobilePage.clickOnDownButton();
				catalystReceivingPage.clickOnNavigateUpButton();
				catalystByMobilePage.verifyInventoryDepositDialogIsDisplayed();
				catalystByMobilePage.clickOnOkButton();
				catalystByMobilePage.verifyMrgProductDepositHeadingIsDisplayed();
				catalystByMobilePage.enterPutawayLocationTextBox();
				catalystByMobilePage.clickOnDownButton();
				catalystByMobilePage.verifyUndirectedMenuHeadingIsDisplayed();
			}
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failed to add Location and Dock door details", e);
		}
	}
	
	@Step
	public void completeShipment() throws InterruptedException {
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
		List<String> deliveryNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..deliveryNumber");
		List<Integer> totalQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
		List<Integer> recvQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..recvQty");
		//List<String> shortageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..shortageQty");
		List<String> damageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..damageQty");
//		List<String> normalReceivedQty = JsonPath.read(testFlowData, "$..poDetails..receivingInstructions..receivedQuantity");
		List<String> overageReceivedQty = JsonPath.read(testFlowData, "$..poDetails..receivingInstructions..overrageReceiveQty");
		
		catalystReceivingPage.handleMoreFreightPopUpOrClickCompleteShipment();
		catalystReceivingPage.verifyTrailerMultipleStopShipmentQuestionIsDisplayed();
		catalystReceivingPage.clickOnTrailerIsEmptyOption();
		catalystReceivingPage.verifyTempRecordQuestionIsDisplayed();
		catalystReceivingPage.clickYesOnTemperatureRecorderAvailableOption();
		catalystReceivingPage.enterZone1Temperature(environment.getProperty("zone1Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterZone2Temperature(environment.getProperty("zone2Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterZone3Temperature(environment.getProperty("zone3Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.verifyOsdrTitleIsDisplayed();
		catalystReceivingPage.verifyShipmentNumber(deliveryNumber.get(0));
		catalystReceivingPage.verifyTotalCasesReceivedHeadingIsDisplayed();
	//	catalystReceivingPage.verifyTotalOverageCases(overageReceivedQty.get(0));
		catalystReceivingPage.verifyTotalDamageCases(damageQty.get(0));
		catalystReceivingPage.clickOnConfirmOsdrButton();
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyDoorSafetyChecklist(doorList.get(0));
		});
		catalystReceivingPage.verifySweptOutTrailerSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyDockPlateRetractedSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifySwingDoorSafetyQuestionIsDisplayed();
		catalystReceivingPage.clickOnYesSwingDoorsOption();//Yes,swing doors
		catalystReceivingPage.verifyIsDockDoorClosedSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyTrophyIconIsDisplayed();
		catalystReceivingPage.verifyShipmentCompletedTextIsDisplayed();
		});
		catalystReceivingPage.verifyCompleteShipmentDescValue(deliveryNumber.get(0));
		
//		catalystReceivingPage.verifyShipmentFinalizedText();
//		catalystReceivingPage.verifyShipmentStatus();
	}
	
	
	@Step
	public void completeShipmentForOverage() throws InterruptedException {
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
		List<String> deliveryNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..deliveryNumber");
		List<Integer> totalQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
		List<Integer> recvQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..recvQty");
		//List<String> shortageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..shortageQty");
		List<String> damageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..damageQty");
//		List<String> normalReceivedQty = JsonPath.read(testFlowData, "$..poDetails..receivingInstructions..receivedQuantity");
		List<String> overageReceivedQty = JsonPath.read(testFlowData, "$..poDetails..receivingInstructions..overrageReceiveQty");
		
		
		catalystReceivingPage.handleMoreFreightPopUpOrClickCompleteShipment();
		catalystReceivingPage.verifyTrailerMultipleStopShipmentQuestionIsDisplayed();
		catalystReceivingPage.clickOnTrailerIsEmptyOption();
		catalystReceivingPage.verifyTempRecordQuestionIsDisplayed();
		catalystReceivingPage.clickYesOnTemperatureRecorderAvailableOption();
		catalystReceivingPage.enterZone1Temperature(environment.getProperty("zone1Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterZone2Temperature(environment.getProperty("zone2Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterZone3Temperature(environment.getProperty("zone3Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.verifyOsdrTitleIsDisplayed();
		catalystReceivingPage.verifyShipmentNumber(deliveryNumber.get(0));
		catalystReceivingPage.verifyTotalCasesReceivedHeadingIsDisplayed();
		catalystReceivingPage.verifyTotalOverageCases(overageReceivedQty.get(0));
		catalystReceivingPage.verifyTotalDamageCases(damageQty.get(0));
		catalystReceivingPage.clickOnConfirmOsdrButton();
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyDoorSafetyChecklist(doorList.get(0));
		});
		catalystReceivingPage.verifySweptOutTrailerSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyDockPlateRetractedSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifySwingDoorSafetyQuestionIsDisplayed();
		catalystReceivingPage.clickOnYesSwingDoorsOption();//Yes,swing doors
		catalystReceivingPage.verifyIsDockDoorClosedSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyShipmentCompletedTextIsDisplayed();
		});
		catalystReceivingPage.verifyCompleteShipmentDescValue(deliveryNumber.get(0));
	}
	
	
	
	@Step
	public void completeShipmentDynamic(String osdrName, String osdrQuantity) throws InterruptedException {
		
		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		//fetching Door Number
		doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
		logger.info("Expected Door Number : {} ", doorList);
		//fetching Delivery Number
		List<String> deliveryNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..deliveryNumber");
		logger.info("Expected Delivery Number : {} ", deliveryNumber);
		//fetching Total Quantity
		List<Integer> totalQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
		logger.info("Expected Total Quantity : {} ", totalQty);
		//fetching Received Quantity
		List<Integer> recvQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..recvQty");
		logger.info("Expected Received Quantity : {} ", recvQty);
		//fetching Shortage Quantity
		List<String> shortageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..shortageQty");
		logger.info("Expected Shortage Quantity : {} ", shortageQty);
		//fetching Damage Quantity
		List<String> damageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..damageQty");
		logger.info("Expected Damage Quantity : {} ", damageQty);
//		List<String> normalReceivedQty = JsonPath.read(testFlowData, "$..poDetails..receivingInstructions..receivedQuantity");
		//fetching overrage Receive Quantity
//		List<String> overageReceivedQty = JsonPath.read(testFlowData, "$..poDetails..receivingInstructions..overrageReceiveQty");
		
	
		catalystReceivingPage.handleMoreFreightPopUpOrClickCompleteShipment();
		catalystReceivingPage.verifyTrailerMultipleStopShipmentQuestionIsDisplayed();
		catalystReceivingPage.clickOnTrailerIsEmptyOption();
		catalystReceivingPage.verifyTempRecordQuestionIsDisplayed();
		catalystReceivingPage.clickYesOnTemperatureRecorderAvailableOption();
		catalystReceivingPage.enterZone1Temperature(environment.getProperty("zone1Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterZone2Temperature(environment.getProperty("zone2Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.enterZone3Temperature(environment.getProperty("zone3Temp"));
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.pressEnter();
		catalystReceivingPage.verifyOsdrTitleIsDisplayed();
		catalystReceivingPage.verifyShipmentNumber(deliveryNumber.get(0));
		catalystReceivingPage.verifyTotalCasesReceivedHeadingIsDisplayed();
		catalystReceivingPage.verifyTotalOverageCases("0");
		catalystReceivingPage.verifyTotalDamageCases(damageQty.get(0));
		
		//We can implement this code to verify the OVERAGE/SHORTAGE/DAMAGES/REJECTED QTY
		switch (osdrName) {
		
		case "Normal":
			catalystReceivingPage.verifyTotalOverageCasesValue(osdrQuantity);
			catalystReceivingPage.verifyTotalShortageCasesValue(totalQty.get(0) - recvQty.get(0));
			catalystReceivingPage.verifyTotalDamageCasesValue(damageQty.get(0));
			break;
		
		case "Overages":
			catalystReceivingPage.verifyTotalOverageCasesValue(osdrQuantity);
			catalystReceivingPage.verifyTotalShortageCasesValue(totalQty.get(0) - recvQty.get(0));
			catalystReceivingPage.verifyTotalDamageCasesValue(damageQty.get(0));
			break;

		case "Shortages":
			catalystReceivingPage.verifyTotalOverageCasesValue(osdrQuantity);
			catalystReceivingPage.verifyTotalShortageCasesValue(totalQty.get(0) - recvQty.get(0));
			catalystReceivingPage.verifyTotalDamageCasesValue(damageQty.get(0));
			break;

		case "Damages":
			catalystReceivingPage.verifyTotalOverageCasesValue(osdrQuantity);
			catalystReceivingPage.verifyTotalShortageCasesValue(totalQty.get(0) - recvQty.get(0));
			catalystReceivingPage.verifyTotalDamageCasesValue(damageQty.get(0));
			break;
			
		case "Reject":
			catalystReceivingPage.verifyTotalOverageCasesValue(osdrQuantity);
			catalystReceivingPage.verifyTotalShortageCasesValue(totalQty.get(0) - recvQty.get(0));
			catalystReceivingPage.verifyTotalDamageCasesValue(damageQty.get(0));
			break;
		}
		catalystReceivingPage.clickOnConfirmOsdrButton();
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyDoorSafetyChecklist(doorList.get(0));
		});
		catalystReceivingPage.verifySweptOutTrailerSafetyQuestionIsDisplayed();
		catalystReceivingPage.clickOnYesButton();
		catalystReceivingPage.verifyDockPlateRetractedSafetyQuestionIsDisplayed();
		catalystReceivingPage.clickOnYesButton();
		catalystReceivingPage.verifySwingDoorSafetyQuestionIsDisplayed();
		catalystReceivingPage.clickOnYesSwingDoorsOption();//Yes,swing doors
		catalystReceivingPage.verifyIsDockDoorClosedSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyTrophyIconIsDisplayed();
		});
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyShipmentCompletedTextIsDisplayed();
		});
		catalystReceivingPage.verifyCompleteShipmentDescValue(deliveryNumber.get(0));
		Failsafe.with(retryPolicy).run(() -> {
		catalystReceivingPage.verifyShipmentFinalizedText();
		});
		catalystReceivingPage.verifyShipmentStatus();
	}
	
	@Step
	public void performReceiving(DataTable data) throws InterruptedException {	
		try {
			
			List<List<String>> receivingData = data.asLists(String.class);
			int totalReceivedQuantity = 0;
			int rejectQuantity = 0;
			int damageQuantity = 0;
			LocalDate date = LocalDate.now();
			LocalDate expdate=date.plusYears(1);
			LocalDate expDateForDamage = date.plusDays(6);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			
			//fetching PO number
			poNumber = JsonPath.read(testFlowData, "$.testFlowData.poDetails..poNumber");
			logger.info("Expected PO number : {} ", poNumber);
			
			for(String currentPONumber : poNumber) {
				
				itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..itemNumber");
				logger.info("Expected Item numbers for LPN receiving corrosponding to PO number {} : {}", currentPONumber, itemNumbers);
				
				for(String currentItem : itemNumbers) {
					
					List<String> itemUPCList = JsonPath.read(testFlowData, 
							"$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')]..caseUpc");		
					
					for(int i=1; i<receivingData.size(); i++) {
						
						final int j = i;
						logger.info("Cycle: {}", i);
						
						//Fetching already received case for item before each receiving
						Failsafe.with(retryPolicy).run(() -> {
							List<String> received_TotalCaseCountBeforeReceiving = catalystReceivingPage.getItemReceivedAndTotalCasesUnderReceivingPage();
							initialReceivedCases = Integer.parseInt(received_TotalCaseCountBeforeReceiving.get(0));
							logger.info("Intial received cases count before {}st receiving: {}", j, initialReceivedCases);
						});
						
						//Scanning LPN, item upc and selecting LPN status and quantity  
						LPN="00LPN"+ javaUtils.randonNumberGenerator(5)+javaUtils.randonNumberGenerator(5);
						catalystReceivingPage.performScan(LPN);
						
						if (receivingData.get(i).get(2).equalsIgnoreCase("Problems")) {
							if(receivingData.get(i).get(4).equalsIgnoreCase("Unexpected")) {
							catalystReceivingPage.enterUpc(environment.getProperty("unexpectedItemUPC"));
							catalystReceivingPage.clickOnReceivingNextButton();
						Failsafe.with(retryPolicy_50s).run(() -> {
							catalystReceivingPage.verifyProblemPopUpText("Item not on shipment");
							catalystReceivingPage.clickUnexpectedItemReceiveButton();
						});
							catalystReceivingPage.verifyProblemReceivePage();							
							} 
						
						else if(receivingData.get(i).get(4).equalsIgnoreCase("Unidentified")) {
							catalystReceivingPage.enterUpc(environment.getProperty("unidentifiedItemUPC"));
							catalystReceivingPage.clickOnReceivingNextButton();							
							catalystReceivingPage.verifyUnidentifiablePopupIsDisplayed();
							catalystReceivingPage.clickOnButtonBasedOnText("Confirm");
							}
						}
						else {
						    catalystReceivingPage.enterUpc(itemUPCList.get(0));
						    catalystReceivingPage.clickOnReceivingNextButton();
						}
						catalystReceivingPage.enterReceivingQty(receivingData.get(j).get(1));
						catalystReceivingPage.clickOnReceivingStatusDropdownArrow();
						catalystReceivingPage.scrollAndClick(receivingData.get(j).get(2));
						catalystReceivingPage.enterReceivingQty(receivingData.get(j).get(1));
						catalystReceivingPage.clickOnReceivingNextButton();
						
						//Performing different actions based on received LPN status
						switch(receivingData.get(i).get(2)) {
						
							case "Available" 	:
								logger.info("There is no specific popup to handle");
								break;
								
							case "QC Inspect" 	:
								logger.info("There is no specific popup to handle");
								break;
								
							
							case "Return On Carrier" 	:
								catalystReceivingPage.clickOnElementBasedOnText(receivingData.get(i).get(3));
								break;	

							case "Problems" 			:
								catalystReceivingPage.clickOnElementBasedOnText(receivingData.get(i).get(3));
								catalystReceivingPage.clickOnElementBasedOnText("Receive");
								break;	
								
							case "Damage" 			:
								catalystReceivingPage.clickOnElementBasedOnText(receivingData.get(i).get(3));
								break;
								
						}

						if (!receivingData.get(i).get(2).equalsIgnoreCase("Problems")){				
						//Entering city of origin and expiry date for LPN
						catalystReceivingPage.enterCityOfOrigin(environment.getProperty("cityOfOrigin"));
						
						if (receivingData.get(i).get(3).equalsIgnoreCase("Warehouse Damage")) {
							//Entering city of origin and expiry date (current day + 6 days) for LPN
							catalystReceivingPage.enterExpirationDate(expDateForDamage.toString());
						} else {
							catalystReceivingPage.enterExpirationDate(expdate.toString());
						}
						
						catalystReceivingPage.pressEnter();
						catalystReceivingPage.pressEnter();
					}
						
						if (receivingData.get(i).get(3).equalsIgnoreCase("Warehouse Damage")){				
							//Handle Item Status PopUp for Damage
							catalystReceivingPage.verifyItemStatusPopUp();
							catalystReceivingPage.clickOnButtonBasedOnText("OK");
							}
						
						//Validating LPN is getting received or not
						Failsafe.with(retryPolicy).run(() -> {
							List<String> received_TotalCaseCountAfterReceiving = catalystReceivingPage.getItemReceivedAndTotalCasesUnderReceivingPage();
							actualReceivedCasesAfterReceiving = Integer.parseInt(received_TotalCaseCountAfterReceiving.get(0));
							logger.info("Actual Received cases count after {}st receiving: {}", j, actualReceivedCasesAfterReceiving);
							
							int expectedReceivedCasesAfterReceiving = initialReceivedCases + Integer.parseInt(receivingData.get(j).get(1));
							logger.info("Expected Received cases count after {}st receiving: {}", j, expectedReceivedCasesAfterReceiving);
							Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_RECEIVED_CASES, expectedReceivedCasesAfterReceiving, actualReceivedCasesAfterReceiving);
						});
						
						//Assigning actual received quantity to a variable
						totalReceivedQuantity = actualReceivedCasesAfterReceiving;
						
						//Storing reject quantity for ROC status LPN
						if(receivingData.get(i).get(2).equalsIgnoreCase("Return On Carrier")) {
							
							List<String> existingRejectQty=JsonPath.read(testFlowData, 
									"$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')]..rejectQty");
							rejectQuantity = Integer.parseInt(existingRejectQty.get(0));
							rejectQuantity += Integer.parseInt(receivingData.get(j).get(1));
						}
						
						//Initializing hashmap to store different fields of receiving instructions class
						HashMap<String, String> requiredRecInstructionDataToBeSet = new HashMap<String, String>();
						requiredRecInstructionDataToBeSet.put("lpn", LPN.substring(2));
						requiredRecInstructionDataToBeSet.put("recievedQty", receivingData.get(i).get(1));
						requiredRecInstructionDataToBeSet.put("receivedStatus", receivingData.get(i).get(2));
						requiredRecInstructionDataToBeSet.put("receivedStatus_Reason", receivingData.get(i).get(3));
						
						
						//Storing reject quantity for ROC status LPN
						if(receivingData.get(i).get(2).equalsIgnoreCase("Damage")) {
							
							List<String> existingDamageQty=JsonPath.read(testFlowData, 
									"$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')]..damageQty");
							damageQuantity = Integer.parseInt(existingDamageQty.get(0));
							damageQuantity += Integer.parseInt(receivingData.get(j).get(1));
							requiredRecInstructionDataToBeSet.put("isDamage", "TRUE");
							requiredRecInstructionDataToBeSet.put("damageQty", Integer.toString(damageQuantity));
							
						}
						
						totalRecInstList.add(catalystReceivingHelper.setRecInstructions(requiredRecInstructionDataToBeSet));
						
					}
					
					//Adding all received LPNs with details under receiving instructions
					catalystReceivingHelper.addFullReceivingInstructionUnderTestflowdata(totalRecInstList, currentPONumber, currentItem);
					
					//updating received, short and reject quantity in PO line details
					catalystReceivingHelper.updatePOLineDetailsSpecificFieldUnderTestflowdata(currentPONumber, currentItem, "recvQty", Integer.toString(totalReceivedQuantity));
					catalystReceivingHelper.updatePOLineDetailsSpecificFieldUnderTestflowdata(currentPONumber, currentItem, "shortQty", "");
					catalystReceivingHelper.updatePOLineDetailsSpecificFieldUnderTestflowdata(currentPONumber, currentItem, "rejectQty", Integer.toString(rejectQuantity));
					catalystReceivingHelper.updatePOLineDetailsSpecificFieldUnderTestflowdata(currentPONumber, currentItem, "damageQty", Integer.toString(damageQuantity));
					
					//updating received and expire date for an item under catalyst item details
					catalystReceivingHelper.updateCatalystItemsDetailsSpecificFieldUnderTestflowdata(currentPONumber, currentItem, "receiveDate", LocalDate.now().toString());
					catalystReceivingHelper.updateCatalystItemsDetailsSpecificFieldUnderTestflowdata(currentPONumber, currentItem, "rotateDate", expdate.toString());
					
				}
			}
		}
		catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while receiving items", e);
		}		
	}
	
	@Step
	public void updateConfig(String str) throws ConfigurationException, InterruptedException {
		catalystReceivingHelper.updateConfig(str); 
	}

	
	@Step
    public void performCompleteShipmentBasedOnStatus(String status) throws InterruptedException {
        
		try {
			
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
	        doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
	        List<String> deliveryNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..deliveryNumber");
	        List<String> totalQtyItemSpecific=JsonPath.read(testFlowData, "$.testFlowData.poDetails..poVnpkQty");
	        List<Integer> recvQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..recvQty");
	        List<String> shortQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..shortQty");
	        List<String> damageQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..damageQty");
	        List<String> rejectQty=JsonPath.read(testFlowData, "$.testFlowData.poDetails..rejectQty");
	        
	        //Fetching expected quantities for OSDR validation
	        for(int i=0; i<totalQtyItemSpecific.size(); i++) {
	        	totalQuantity += Integer.parseInt(totalQtyItemSpecific.get(i));
	        	totalReceivedQuantity += recvQty.get(i);
	        	totalShortQuantity += Integer.parseInt(shortQty.get(i));
	        	totalDamagedQuantity += Integer.parseInt(damageQty.get(i));
	        	totalRejectedQuantity += Integer.parseInt(rejectQty.get(i));        	
	        }
	        
	        if(totalReceivedQuantity > totalQuantity) 
				totalOverageQuantity = totalReceivedQuantity - totalQuantity;
	        
	        logger.info("Expected total quantity : {}", totalQuantity);
	        logger.info("Expected total received quantity : {}", totalReceivedQuantity);
	        logger.info("Expected total shortage quantity : {}", totalShortQuantity);
	        logger.info("Expected total damaged quantity : {}", totalDamagedQuantity);
	        logger.info("Expected total rejected quantity : {}", totalRejectedQuantity);
	        logger.info("Expected total overage quantity : {}", totalOverageQuantity);
	        
	        handleMoreFreightPopupAndEnterZoneTemperature();
	        
	        switch(status) {
	        
	        	case "Return On Carrier" :
	        		confirmRoc(deliveryNumber.get(0));
	        		break;
	        		
	        	default:
	        		logger.info("going to perform close door safety check segment after confirming OSDR");
	        }
	        
	        confirmOsdr(status, deliveryNumber.get(0));
	        performCloseDoorSafetyCheckSegmentAndVerifyCompleteShipment(deliveryNumber.get(0), status);
	        
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while completing shipment", e);
		}
        
    }
	
	
	public void handleMoreFreightPopupAndEnterZoneTemperature() throws InterruptedException {
		
		//Handling more freight pop up and selecting some questions 
    	catalystReceivingPage.handleMoreFreightPopUpOrClickCompleteShipment();
        catalystReceivingPage.verifyTrailerMultipleStopShipmentQuestionIsDisplayed();
        catalystReceivingPage.clickOnTrailerIsEmptyOption();
        catalystReceivingPage.verifyTempRecordQuestionIsDisplayed();
        catalystReceivingPage.clickYesOnTemperatureRecorderAvailableOption();
        
        //Entering zone temperatures
        catalystReceivingPage.enterZone1Temperature(environment.getProperty("zone1Temp"));
        catalystReceivingPage.pressEnter();
        catalystReceivingPage.enterZone2Temperature(environment.getProperty("zone2Temp"));
        catalystReceivingPage.pressEnter();
        catalystReceivingPage.enterZone3Temperature(environment.getProperty("zone3Temp"));
        catalystReceivingPage.pressEnter();
        catalystReceivingPage.pressEnter();
	}
	
	
	public void confirmOsdr(String itemStatus, String expectedDeliveryNumber) {
		
        //Validating OSDR values
		catalystReceivingPage.verifyOsdrTitleIsDisplayed();
        catalystReceivingPage.verifyShipmentNumber(expectedDeliveryNumber);
        catalystReceivingPage.verifyTotalCasesReceivedHeadingIsDisplayed();
        catalystReceivingPage.verifyTotalCasesReceivedValue(Integer.toString(totalReceivedQuantity));
        catalystReceivingPage.verifyTotalOverageCases(Integer.toString(totalOverageQuantity));
        
        if(itemStatus.equalsIgnoreCase("Return On Carrier"))
        	catalystReceivingPage.verifyTotalDamageCases(Integer.toString(totalRejectedQuantity));
        
        else
        	catalystReceivingPage.verifyTotalDamageCases(Integer.toString(totalDamagedQuantity));
        
        catalystReceivingPage.clickOnConfirmOsdrButton();
	}
	
	
	public void confirmRoc(String expectedDeliveryNumber) {
		
		//verifying user is navigated to Confirm ROC screen
		Failsafe.with(retryPolicy).run(() -> {
			boolean isRocScreenVisible = catalystReceivingPage.isElementPresentBasedOnExactText("Confirm ROC");
			logger.info("ROC screen is displayed: {}", isRocScreenVisible);
			Assert.assertTrue(ErrorCodes.CATALYST_MOBILE_RECEIVING_ROC_SCREEN_NOT_VISIBLE, isRocScreenVisible);
		});
		
		//validating expected shipment number is showing on confirm ROC screen
		boolean isShipmentNumberVisible = catalystReceivingPage.isElementPresentBasedOnPartialText(expectedDeliveryNumber);
		logger.info("Expected Shipment number is displayed: {}", isShipmentNumberVisible);
		Assert.assertTrue(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_SHIPMENT_NUMBER_UNDER_CONFIRM_ROC_SCREEN, isShipmentNumberVisible);
		
		//validating the count of received LPN with ROC status
		String actualReceivedRocPallets = catalystReceivingPage.getfieldValueForParticularField("ROC");
		logger.info("Actual Received ROC pallets: {}", actualReceivedRocPallets);
		Assert.assertEquals(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ROC_PALLETS_COUNT, Integer.toString(totalRejectedQuantity), actualReceivedRocPallets);
		
		
		String testFlowData = threadLocal.get().get("testFlowData").toString();
		
		//fetching PO number
		poNumber = JsonPath.read(testFlowData, "$.testFlowData.poDetails..poNumber");
		logger.info("Expected PO number : {} ", poNumber);
		
		for(String currentPONumber : poNumber) {
			
			itemNumbers = JsonPath.read(testFlowData, "$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..itemNumber");
			logger.info("Expected Item numbers corrosponding to PO number {} : {}", currentPONumber, itemNumbers);
			
			for(String currentItem : itemNumbers) {
				
				//Fetching received LPNs for current item
				logger.info("Current item: {}", currentItem);
				List<String> expectedReceivedLPNs = JsonPath.read(testFlowData,
						"$.testFlowData..poDetails[?(@.poNumber=='"+currentPONumber+"')]..poLineDetails[?(@.itemNumber=='"+currentItem+"')]..receivingInstructions[?(@.receivedStatus=='Return On Carrier')].parentContainer");
				
				
				logger.info("Expected Received LPNs as ROC status: {}", expectedReceivedLPNs);
				
				//Storing ROC status LPN with their respective item number
				for(String currentLpn : expectedReceivedLPNs) {
					itemsWithReceivedLpnAsRocStatus.put(currentLpn, currentItem);
				}
			}
		}
		
		logger.info("Expected Received LPNs as ROC status with respective items: {}", itemsWithReceivedLpnAsRocStatus);
		
		//Validating ROC status LPN and corresponding item number is available on confirm ROC screen
		for(Map.Entry<String, String> currentRecord : itemsWithReceivedLpnAsRocStatus.entrySet()) {
			
			logger.info("Current expected LPN: {}", currentRecord.getKey());
			boolean isLpnVisibleOnConfirmRocScreen = catalystReceivingPage.isElementPresentBasedOnPartialText(currentRecord.getKey());
			logger.info("LPN {} is displayed: {}", currentRecord.getKey(), isLpnVisibleOnConfirmRocScreen);
			Assert.assertTrue(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ROC_LPN, isLpnVisibleOnConfirmRocScreen);
			
			String actualItemNumberText = catalystReceivingPage.getfieldValueForParticularField(currentRecord.getKey());
			logger.info("Actual item text for LPN {} is : {}", currentRecord.getKey(), actualItemNumberText);
			logger.info("Expected item number for LPN {} is : {}", currentRecord.getKey(), currentRecord.getValue());
			Assert.assertTrue(ErrorCodes.CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ITEM_NUMBER_FOR_ROC_LPN, actualItemNumberText.contains(currentRecord.getValue()));
		}
		
		//clicking on confirm ROC button
		catalystReceivingPage.clickOnElementBasedOnText("Confirm ROC");
	}
	
	
	public void performCloseDoorSafetyCheckSegmentAndVerifyCompleteShipment(String expectedShipmentNumber, String receivedLpnStatus) throws InterruptedException {
		
		Failsafe.with(retryPolicy).run(() -> {
        catalystReceivingPage.verifyDoorSafetyChecklist(doorList.get(0));
        });
		
		//Performing close door safety questions
        catalystReceivingPage.verifySweptOutTrailerSafetyQuestionIsDisplayed();
        catalystReceivingPage.selectYesButton();
        catalystReceivingPage.verifyDockPlateRetractedSafetyQuestionIsDisplayed();
        catalystReceivingPage.selectYesButton();
        catalystReceivingPage.verifySwingDoorSafetyQuestionIsDisplayed();
        catalystReceivingPage.clickOnElementBasedOnPartialText("No");
        catalystReceivingPage.verifyIsTrailerDoorClosedSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
        
        switch(receivedLpnStatus) {

        case "Return On Carrier" :
    		//Entering trailer closing seal number
    		catalystReceivingPage.enterTrailerSealNumber("SL" + expectedShipmentNumber);
    		catalystReceivingPage.pressEnter();
    		break;
    		
    	default:
    		logger.info("Trailer closing seal is not required");
        }
        
        //last close door safety question
        catalystReceivingPage.verifyIsDockDoorClosedSafetyQuestionIsDisplayed();
        catalystReceivingPage.selectYesButton();
        
        //Validating shipment is completed
        Failsafe.with(retryPolicy).run(() -> {
        catalystReceivingPage.verifyShipmentCompletedTextIsDisplayed();
        });
        
        catalystReceivingPage.verifyCompleteShipmentDescValue(expectedShipmentNumber);
	}
	
	
	@Step
	public void performUnloadingBasedOnParams(String safetyStatus) throws InterruptedException {
		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			// fetching Door Number
			doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");
			logger.info("Expected Door Number : {} ", doorList);

			// Selecting Unloading option and enter door number to perform safety check
			catalystReceivingPage.clickOnDropdownExpandButton();
			catalystReceivingPage.clickOnUnloadingOption();
			catalystReceivingPage.clickOnTrySearchingLink();
			catalystReceivingPage.enterDoorNumber(doorList.get(0));
			Thread.sleep(1000);
			catalystReceivingPage.clickOnReceivingSearchButton();
			Thread.sleep(1000);
			catalystReceivingPage.clickOnSearchResultsCheckedInArrowButton();
			catalystReceivingPage.clickOnOpenDoorButton();
			catalystReceivingPage.verifyDoorTitleIsDisplayed();
			Failsafe.with(retryPolicy).run(() -> {
				catalystReceivingPage.verifyTrailerDetailsIsDisplayed();
			});
			
			// Perform Open door safety check based on status
			if (POSITIVE_SAFETY_STATUS.equalsIgnoreCase(safetyStatus)) {
				logger.info("Safety Status is ====> " + safetyStatus);
				performOpenDoorSafetyCheckSegmentBasedOnStatus(safetyStatus);
			} else {
//				performBumpRequestWithInfastationReason();
				logger.info("Safety Status is ====> " + safetyStatus);
				performOpenDoorSafetyCheckSegmentBasedOnStatus(safetyStatus);
				return;
			}

			// Scan the LPN
			performLPNScan();
			// Scan the UPC
			performUPCScan();

			// Actions after scanning LPN & UPC - Navigating back to Home screen
//			catalystReceivingPage.clickOnReceivingNextButton();
			catalystReceivingPage.verifyUnloadFreightTitleIsDisplayed();
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnNavigateUpButton();
			catalystReceivingPage.clickOnNavigateUpButton();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("WMT_Unloading : Failed to perform Unload ", e);
		}

	}

	public void performOpenDoorSafetyCheckSegmentBasedOnStatus(String status) throws InterruptedException {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		doorList = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..inboundDoorNumber");

		Failsafe.with(retryPolicy).run(() -> {
			catalystReceivingPage.verifyCorrectDockDoorSafetyQuestionIsDisplayed();
		});
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyCorrectCarrierTrailerNumberSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyDockPlateSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyTrailerLightSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyTrailerHeightSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyFloorBoardsSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyFloorFreeOfSpilledLiquidSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyTrailerDockDoorHeightSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyFreightStabilitySafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyPalletConditionSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();
		catalystReceivingPage.verifyMerchandiseDamageFreeSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();

		if (POSITIVE_SAFETY_STATUS.equalsIgnoreCase(status)) {
			catalystReceivingPage.verifyPestFreeTrailerSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			logger.info("Selected {} for Pest Free Trailer Safety Question", status);
		} else {
			catalystReceivingPage.verifyPestFreeTrailerSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectNoButton();
			logger.info("Selected {} for Pest Free Trailer Safety Question", status);
		}

		catalystReceivingPage.verifyHazardFreeTailerSafetyQuestionIsDisplayed();
		catalystReceivingPage.selectYesButton();

		logger.info("Open Door Safety Check is Completed ====");
	}

	public void performLPNScan() throws InterruptedException {

		// Generates Randon LPN
		LPN = "00LPN" + javaUtils.randonNumberGenerator(5) + javaUtils.randonNumberGenerator(5);

		// Scanning LPN
		catalystReceivingPage.performLPNandUPCScanning("EAN128", LPN);
		logger.info("Scanned LPN ====");
	}
	
	public void performUPCScan() throws InterruptedException {

		String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));

		// fetching Case UPC from TFD
		List<String> itemUPCList = JsonPath.read(testFlowData, "$..poDetails[*].poLineDetails..caseUpc");
		logger.info("Expected Case UPC : {} ", itemUPCList);

		// Scanning UPC
		catalystReceivingPage.performLPNandUPCScanning("UPC", itemUPCList.get(0));
		logger.info("Scanned UPC ====");

	}

	@Step
	public void performBumpRequestWithInfestationReason() {

		try {

			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			// fetching Delivery number
			List<String> deliveryNumber = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails..deliveryNumber");

			// Safety Inspection Popup
			catalystReceivingPage.verifySafetyInspectionFailedPopUp();
			catalystReceivingPage.clickOnButtonBasedOnText("OK");

			// Context Menu Action Button
			catalystReceivingPage.clickOnContextActionButton();
			catalystReceivingPage.selectOptionTailerManagement();
			Failsafe.with(retryPolicy).run(() -> {
				catalystReceivingPage.verifyTrailerManagementScreen();
			});
			Thread.sleep(2000);
			Failsafe.with(retryPolicy).run(() -> {
				catalystReceivingPage.clickOnChooseTrailerOperation();
			});
//			catalystReceivingPage.clickOnDropdownExpandButton();
			catalystReceivingPage.selectCloseTrailerOption();
			Failsafe.with(retryPolicy).run(() -> {
				catalystReceivingPage.clickOnChooseTrailerAction();
			});
//			catalystReceivingPage.clickOnDropdownExpandButton();
			catalystReceivingPage.selectRejectInfestationOption();
			catalystReceivingPage.clickOnButtonBasedOnText("Submit");

			// Verify and handling Trailer Safety and Dock Plate Retracted Questions
			catalystReceivingPage.verifySweptOutTrailerSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.verifyDockPlateRetractedSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();

			// Verify and handling Swing door safety and Trailer door close Questions
			catalystReceivingPage.verifySwingDoorSafetyQuestionIsDisplayed();
			catalystReceivingPage.clickOnElementBasedOnPartialText("No");
			catalystReceivingPage.verifyIsTrailerDoorClosedSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();
			catalystReceivingPage.enterTrailerSealNumber("SL" + deliveryNumber.get(0));
			catalystReceivingPage.pressEnter();
			catalystReceivingPage.verifyIsDockDoorClosedSafetyQuestionIsDisplayed();
			catalystReceivingPage.selectYesButton();

			logger.info("WMT_RECEIVING : Performed Infestation with Trailer door close questions ");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while performing Infestation ", e);
		}

	}

}
