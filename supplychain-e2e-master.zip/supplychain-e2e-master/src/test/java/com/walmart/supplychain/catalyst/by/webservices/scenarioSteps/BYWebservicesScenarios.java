package com.walmart.supplychain.catalyst.by.webservices.scenarioSteps;

import java.io.IOException;
import java.util.List;

import com.walmart.supplychain.catalyst.by.webservices.steps.BYWebservicesSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.minidev.json.parser.ParseException;
import net.thucydides.core.annotations.Steps;

public class BYWebservicesScenarios {
	
	
	@Steps
	BYWebservicesSteps byWebservicesSteps;
	
	
	
	@Then("^user verifies inbound shipment status as \"([^\"]*)\" and equipment status as \"([^\"]*)\"$")
	public void userVerifyInboundShipmentStatus_Service(String inboundShipmentStatus, String equipmentStatus) {
		
		byWebservicesSteps.verifyInboundShipment_EqiupmentStatus(inboundShipmentStatus, equipmentStatus);
	}
	
	
	@Then("^user verifies the appropiate check in location corresponding to the shipment$")
	public void userValidateCheckedInLocation() {
		
		byWebservicesSteps.verifyCheckedInLocation();
	}
	
	
	@Then("^user verifies the assigned door location corresponding to the shipment after door assign$")
	public void userValidateAssignedDoor() {
		
		byWebservicesSteps.verifyAssignedDoorLocation();
	}
	
	
	@Then("^user verifies the safety check status for the trailer as \"([^\"]*)\"$")
	public void userValidateTrailerSafetyCheckStatus(String safetyCheckStatus) {
		
		byWebservicesSteps.verifyTrailerSafetyCheckStatus(safetyCheckStatus);
	}
	
	
	@Then("^user verifies the received container details$")
	public void userValidateContainerDetails() {
		
		byWebservicesSteps.verifyReceivedContainerDetails();
	}
	
	@Given("^user verifies new PO added to delivery$")
	public void userValidateNewPOaddedEvent() throws IOException, ParseException {
		
		byWebservicesSteps.verifyNewAddedPODetails();
//		byWebservicesSteps.setPONumbersInTestflowdata("");
	}

	@Then("^user verifies Inventory status as \"([^\"]*)\"$")
    public void user_verifies_inventory_status_as_something(String lpnStatus) throws Throwable {

		byWebservicesSteps.validateLPNStatusInInventoryModule(lpnStatus);
    }
	
	
	@Then("^user verifies that the received LPNs with ROC status are moved to permanent storage location \"([^\"]*)\"$")
    public void userValidateRocStatusLpnMovedToStorageLocation(String storageLocation) {

		byWebservicesSteps.verifyRocStatusLpnMovedToPermanentStorageLocation(storageLocation);
    }
}
