package com.walmart.supplychain.nextgen.outbound.steps.ui;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.outbound.pages.ui.OutboundHomePage;
import com.walmart.supplychain.nextgen.outbound.pages.ui.OutboundLoginPage;

import cucumber.api.java8.En;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.TimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OutboundSteps extends ScenarioSteps implements En {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	private static final String OUTBOUND_GET_ENTITY = "$.testFlowData.outboundDetails[*]";
	@Autowired
	OutboundLoginPage outboundLoginPage;
	@Autowired
	OutboundHomePage outboundHomePage;
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	Logger logger = LogManager.getLogger(OutboundSteps.class);
	String bolFileName = null;
	String documentId = null;
	PropertyResolver propertyResolver = new PropertyResolver();
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(15, 10);
	@Autowired
	OutboundHelper outboundHelper;
	@Autowired
	Environment endpoints;
	@Autowired
	Environment environment;

	@Step
	public void validateOutbound() {
		try {
			Thread.sleep(3000);
			String testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			JSONArray listOfLoads = JsonPath.read(testFlowData, OUTBOUND_GET_ENTITY);
			String outboundJson = objectMapper.writeValueAsString(listOfLoads);
			@SuppressWarnings("unchecked")
			List<OutboundDetail> outboundDetailList = (List<OutboundDetail>) jsonUtil.getPojoListfromPath(outboundJson,
					OutboundDetail.class);
			for (OutboundDetail outbound : outboundDetailList) {
				// showStepMessage("step message for load id "+outbound.getLoadId());
				validateOutboundForLoad(outbound);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception ex) {
			throw new AutomationFailure("Outbound Load Validation is failed for load:", ex);
		}
	}

	@Step
	public void validateOutboundForLoad(OutboundDetail outbound) {
		try {
			loginToOutbound();
			searchAndSelectLoad(outbound.getLoadId(), outbound.getTrailerNumber());
			validateLoadDetails(outbound.getDestNumber(), outbound.getLoadId(), outbound.getOutboundDoorNumber(),
					outbound.getTrailerNumber());
			validateSealDetails(outbound.getSealNumber());
			downloadBOL(outbound.getLoadId(), outbound.getTmsLoadId());
			validateBOL(outbound.getDestNumber(), outbound.getTmsLoadId(), outbound.getTrailerNumber(),
					outbound.getSealNumber());
			outboundLoginPage.closeDriver();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception ex) {
			throw new AutomationFailure("Outbound Load Validation is failed for load:" + outbound.getLoadId(), ex);
		}
	}

	/*@Step
	public void openOutboundLoginPage() {
		try {

			outboundLoginPage.getUrl(endpoints.getProperty("outbound_ui_url"));
		} catch (AssertionError e) {
			throw new TestCaseFailure(e);
		} catch (Exception ex) {
			throw new AutomationFailure("Unable to Open Outbound Login Page", ex);
		}
	}*/

	@Step
	public void loginToOutbound() {
		try {
			logger.info("Logging into outbound UI");
				outboundLoginPage.getUrl(endpoints.getProperty("outbound_ui_url"));
				outboundLoginPage.enteruserIdField(environment.getProperty("outbound_username"));
				outboundLoginPage.enterPasswordField(environment.getProperty("outbound"));
				outboundLoginPage.enterFacilityNumField(environment.getProperty("facility_num"));
				outboundLoginPage.selectDomain();
				outboundLoginPage.clickLogInButton();
				logger.info("Waiting for load input text box");
				outboundHomePage.waitForOutboundLoadSearchInputTextBox();
			logger.info("Successfully logged into Outbound UI");
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OUTBOUND_UNABLE_TO_LOGIN, e);
		} catch (Exception ex) {
			throw new AutomationFailure("Unable to login to Outbound", ex);
		}

	}

	@Step
	public void searchAndSelectLoad(String loadId, String trailerNum) {
		try {
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Search for Load ID:{}", loadId);
				outboundHomePage.inputLoadNumber(loadId);
				outboundHomePage.clickOnSearch();
				outboundHomePage.clickOnTrailerNum(trailerNum);
			});
		} catch (ElementNotFoundException | ElementNotVisibleException | TimeoutException e) {
			throw new TestCaseFailure(ErrorCodes.OUTBOUND_UNABLE_TO_SEARCH_FOR_LOAD, e);
		} catch (Exception ex) {
			throw new AutomationFailure("Unable to find the load in outbound", ex);
		}
	}

	@Step
	public void validateLoadDetails(String dest, String loadId, String outboundDoor, String trailerNumber) {
		try {
			String destination = "DC " + dest;// hard coded DC as MCC will always ship to RDC
			List<String> expectedData = new ArrayList<>();
			expectedData.add(loadId);
			expectedData.add(outboundDoor);
			expectedData.add(trailerNumber);
			expectedData.add(destination);
			List<String> actualData = null;
			actualData = outboundHomePage.getLoadDetails();
			logger.info(actualData);

			Assert.assertArrayEquals(ErrorCodes.OUTBOUND_LOAD_DETAILS_VALIDATION_FAILED, expectedData.toArray(),
					actualData.toArray());
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Outbound Load validation is failed", e);
		}
	}

	@Step
	public void validateSealDetails(String sealNo) {
		try {
			outboundHomePage.clickOnSealLabel();
			Assert.assertEquals(ErrorCodes.OUTBOUND_SEAL_DETAILS_VALIDATION_FAILED, outboundHomePage.getSealDetails(),
					sealNo);
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Outbound Seal validation is failed");
		}

	}

	@Step
	public void downloadBOL(String loadId, String tmsId) {
		try {
			outboundHomePage.clickOnPrintDocuments();
			outboundHomePage.clickOnPrint();
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Waiting for BOL generation for load {}", loadId);
				documentId = outboundHelper.getDocumentId(loadId, tmsId);
				logger.info("BOL Document Id from DB: {}", documentId);
			});
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Downloading BOL File for load {}", loadId);
				bolFileName = outboundHelper.getBOL(documentId);
				logger.info("Generated BOL File Name : {}", bolFileName);
				bolFileName = outboundHomePage.waitForPresenceOfFile(bolFileName);
				logger.info("Downloaded the file successfully");
				Assert.assertNotNull(ErrorCodes.OUTBOUND_DOWNLOAD_BOL_FAILED, bolFileName);
			});
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			logger.error("ER:" + e);
			throw new AutomationFailure("Outbound BOL Download is failed");
		}
	}

	@Step
	public void validateBOL(String destination, String tmsLoadId, String trailerNo, String sealNo) {
		try {
			List<String> expectedData = new ArrayList<>();
			expectedData.add(tmsLoadId);
			expectedData.add(trailerNo);
			expectedData.add(sealNo);
			expectedData.add(destination);
			List<String> actualData = outboundHomePage.getBOLDetails(bolFileName);
			Assert.assertArrayEquals(ErrorCodes.OUTBOUND_BOL_BASIC_DATA_VALIDATION_FAILED, expectedData.toArray(),
					actualData.toArray());
			logger.info("Validated BOL Successfully");
		} catch (FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Outbound BOL Validation is failed");
		}
	}

	/*
	 * public void showStepMessage(String message) { // TODO: escape message string
	 * String escapedMessage = StringUtils.replace(message, " ", "&nbsp;");
	 * StepEventBus.getEventBus().stepStarted(ExecutedStepDescription.withTitle(
	 * escapedMessage)); StepEventBus.getEventBus().stepFinished();
	 * StepEventBus.getEventBus().
	 * addDescriptionToCurrentTest("This is Close loadfor load");
	 * StepEventBus.getEventBus().takeScreenshot(); }
	 */

}
