/*
 * Please use FeatureList.java to add/remove feature
 */

/*package com.walmart.supplychain.thor.manifestservices;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.framework.supplychain.constants.FileNames;

import cucumber.api.CucumberOptions;


@RunWith(com.walmart.supplychain.CustomSerenityRunner.class)
@CucumberOptions(features= {
		FileNames.THOR_BASE_FILE
		},monochrome=true,
		glue = { "com.walmart.supplychain.nextgen","com.walmart.supplychain.thor"})

public class ThorRunner {
	static Logger logger = LoggerFactory.getLogger(ThorRunner.class);
	@BeforeClass
    public static void executeBeforeAllTests() {

		logger.info("This will run before all the test features triggered by this runner");
		
    }


    @AfterClass
    public static void executeAfterAllTests() {
    	logger.info("This will run after all the test features triggered by this runner");

    }

	
}
 */