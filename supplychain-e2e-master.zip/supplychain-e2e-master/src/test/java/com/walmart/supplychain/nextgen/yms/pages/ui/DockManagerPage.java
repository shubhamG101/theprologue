package com.walmart.supplychain.nextgen.yms.pages.ui;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;
import com.walmart.supplychain.nextgen.yms.steps.ui.YMSHelper;

import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.pages.PageObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;

public class DockManagerPage extends SerenityHelper {

	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	YMSHelper ymsHelper = new YMSHelper();

	@FindBy(id = "dcNbr")
	private WebElement dcNumberDropDown;

	@FindBy(id = "subcenterId")
	private WebElement subCenterDropDown;

	@FindBy(id = "logicalDockName")
	private WebElement logicalDockNameDropDown;

	@FindBy(id = "dockUsageCode")
	private WebElement logicalDockViewDropDown;

	@FindBy(id = "Retrieve")
	private WebElement retrieveButton;

	@FindBy(xpath = "//*[@id='dockHolder']/table")
	private WebElement dockHolderTable;

	@FindBy(xpath = "//div[@class='Open']")
	private List<WebElement> openDoors;
	
	@FindBy(xpath ="//div[@id='loadHolder']/img")
	private WebElement loadingImage;

	public void selectFilterCriteria(String view) {
		String logicalDockName="";
		element(dcNumberDropDown).selectByVisibleText(
				propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "source_number", true));
		element(subCenterDropDown)
				.selectByVisibleText(propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "sub_center", true));
		if("Inbound".equalsIgnoreCase(view))
			logicalDockName=propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "inbound_dock");
		else if("Outbound".equalsIgnoreCase(view))
			logicalDockName=propertyResolver.getPropertyValue(FileNames.YMS_PROPERTIES, "outbound_dock");
		element(logicalDockNameDropDown).selectByVisibleText(logicalDockName);
		element(logicalDockViewDropDown).selectByVisibleText(view);
		element(retrieveButton).click();
		logger.info("Filter criteria is selected and clicked on retrieve button");
		ymsHelper.waitUntilSpinnerNotVisible();
		element(dockHolderTable).waitUntilVisible();
	}

	public List<String> getOpenDoors() {
		List<String> doorNumbers = new ArrayList<>();
		for (int i = 1; i <= openDoors.size(); i++) {
			doorNumbers.add(getDriverInstance().findElement(By.xpath("(//div[@class='Open'])[" + i + "]/div")).getText());
		}
		logger.info("Open doorNumbers Available in YMS" + doorNumbers);
		return doorNumbers;
	}

}
