package com.walmart.supplychain.baja.of.step;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.walmart.framework.supplychain.constants.FileNames;

import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class PublishTruckupFile {

	@Autowired
	Environment environment;
	Logger logger = LogManager.getLogger(this.getClass());

	@Step
	public void uploadTruckUpfile() throws IOException {

		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		logger.info("preparing the host information for sftp.");

		try {
			JSch jsch = new JSch();
			String remoteDir = "/shortrec/OMR_US_DC_7390_CRT/SHORTREC/BRANCHES/Data/Interface/Export/WM_GLS2_TRUCK_UP/";
			
			session = jsch.getSession(environment.getProperty("sftp_user"), environment.getProperty("sftp_host"),
					Integer.valueOf(environment.getProperty("sftp_port")));
			session.setPassword(environment.getProperty("sftp_pass"));
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect();
			logger.info("Host connected.");
			channel = session.openChannel("sftp");
			channel.connect();
			logger.info("sftp channel opened and connected.");
			channelSftp = (ChannelSftp) channel;
			File f = new File(FileNames.BAJA_TRUCKUP_FILE);
			channelSftp.put(new FileInputStream(f), remoteDir + f.getName());

		} catch (Exception ex) {
			logger.info("Exception found while tranfer the response." + ex);
		} finally {
			channelSftp.exit();
			logger.info("sftp Channel exited.");
			channel.disconnect();
			logger.info("Channel disconnected.");
			session.disconnect();
			logger.info("Host Session disconnected.");
		}
	}
}
