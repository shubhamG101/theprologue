package com.walmart.supplychain.pharmacy.gdm.scenariosteps.webservices;

import org.springframework.test.context.ContextConfiguration;

import com.walmart.supplychain.pharmacy.gdm.steps.webservices.GDMPharmSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class GDMPharmScenarios {
	
	@Steps
	GDMPharmSteps gdmPharmSteps;
	
	@And("Creates shipment with \"([^\"]*)\", \"([^\"]*)\" for \"([^\"]*)\" receiving")
	public void userCreateShipmentForPalletReceiving(String loadNumber, String numOfpacksOnShipmentForEachPOLine, String receivingType) {
		gdmPharmSteps.createMultiShipment("1", loadNumber, numOfpacksOnShipmentForEachPOLine, receivingType);
	}
	
	@And("Creates multi shipment with \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" for \"([^\"]*)\" receiving")
	public void userCreateMultiShipmentForPalletReceiving(String noOfShipments, String loadNumber, String numOfpacksOnShipmentForEachPOLine, String receivingType) {
		gdmPharmSteps.createMultiShipment(noOfShipments, loadNumber, numOfpacksOnShipmentForEachPOLine, receivingType);
	}

	@Then("^user verifies delivery is created and verify shipment status in Delivery$")
	public void user_verifies_shipment() {
		gdmPharmSteps.getDeliveryResponseForPharmacy("D1");
	}
	
	@And("^User updates palletTi \"([^\"]*)\" and palletHi \"([^\"]*)\"$")
	public void user_updates_palletTiHi(String palletTi, String palletHi) {
		gdmPharmSteps.updateTiHi(palletTi, palletHi);
	}
}
