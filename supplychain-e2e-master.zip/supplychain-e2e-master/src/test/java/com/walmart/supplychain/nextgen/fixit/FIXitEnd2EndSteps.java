package com.walmart.supplychain.nextgen.fixit;

import static net.serenitybdd.rest.SerenityRest.given;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.walmart.framework.utilities.selenium.CustomDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.util.encoders.Base64;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ProblemDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.framework.utilities.selenium.ContextDriver;
import com.walmart.supplychain.gdc.fixit.web.pages.POLinePage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.FixitMobileHomePage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemDeliveryNumberPage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemEnterDetailPage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemExceptionSubTypePage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemLabelsPage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemPOLinePage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemReportExceptionPage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemScanPage;
import com.walmart.supplychain.nextgen.fixit.mobile.problem.pages.ProblemSelectItemPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.AttachmentPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.DcTcDeliveryUpcPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.DcTcExceptionDetailPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.DcTcExceptionTypePage;
import com.walmart.supplychain.nextgen.fixit.web.pages.DcTcHomePage;
import com.walmart.supplychain.nextgen.fixit.web.pages.DcTcPoLInePage;
import com.walmart.supplychain.nextgen.fixit.web.pages.DcTcSuccessfulPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.FixitHomePage;
import com.walmart.supplychain.nextgen.fixit.web.pages.ListViewPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.LoginPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.ResolutionPage;
import com.walmart.supplychain.nextgen.fixit.web.pages.TicketDetailPage;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.strati.libs.commons.configuration.ConfigurationException;
import io.strati.libs.commons.configuration.PropertiesConfiguration;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Screenshots;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.webdriver.WebDriverFacade;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class FIXitEnd2EndSteps extends ScenarioSteps {

	@Autowired
	FixitHomePage fixitHomePage;

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	TextParser textParser;

	@Autowired
	JsonUtils jsonUtil;

	Map<String, String> testData;

	private static final String TEST_FLOW_DATA = "testFlowData";

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(5, 10);// 15 times with a delay of 10s

	// manually entered when testing single flow
	// private static String problemtTicket = "HZM3289819121300483";
	// private static final String DELIVERY_NUMBER = "19495018";
	// private static final String UPC_NUMBER = "10044600002528";
	// private static final String UPC_NUMBEROTHERS="00028000114701";

	private static String problemtTicket = null;
	private static final String PROBLEM_QTY = "10";
	private static final String TI = "5";
	private static final String HI = "2";
//	private static final String PO_NUMBER="12345678";
	private static final String COMMENTS = "Test comment";
	private static final String new_PONumber = "1234567878";
	private static final String DC_NUMBER = "32898";
	private static final String ANOTHER_DC = "32899";
	private static final String TOTAL_COST_ITEM = "1000";
	private static final String TOTAL_RETAIL_ITEM = "2000";
	private static final String WMRA = "1234";
	private static final String NEW_POLINE_NUM = "2";
	private static final String QTY_TO_RECEIVE = "10";
	private static final String receivedVNPK = "6";
	private static final String receivedWNPK = "6";
	private static String PO_NUMBER = null;

	private static String poNumber;
	private static String upcNumber;
	private static String deliveryNumber;
	private static String poLine;
	private static String market;
	private DocumentContext parsedJson;
	private List<String> poNumberList;
	private static final String LIST_OF_PO_NUMBERS_JSON_PATH = "$.testFlowData.deliveryDetails..poNumbers[*]";
	private static final String PO_LINE_NUMBERS_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails..poLineNumber";
	private static final String DELIVERY_NUMBERS_JSON_PATH = "$..deliveryDetails..deliveryNumber";
	private static final String ITEM_NUMBERS_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails..itemNumber";
	private static final String ITEM_UPC_JSON_PATH =  "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails[?(@.itemNumber=='#1#')].itemUpc";
	private static final String PO_LINE_DETAILS_JSON_PATH =  "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails[*]";
	private static final String CP_DAMAGE_QTY_JSON_PATH = "$.[?(@.location=='CP'&& @.poNumber=='#0#')].quantity";
	private static final String RDC_DAMAGE_QTY_JSON_PATH = "$.[?(@.location=='RDC'&& @.poNumber=='#0#')].quantity";
	private static final String ALL_PO_LINE_DETAILS_JSON_PATH = "$.testFlowData.poDetails[?(@.poNumber=='#0#')].poLineDetails";
	
	ProblemDeliveryNumberPage problemDeliveryNumberPage;
	ProblemPOLinePage problemPOLinePage;
	ProblemExceptionSubTypePage problemExceptionSubTypePage;
	ProblemEnterDetailPage problemEnterDetailPage;
	ProblemScanPage problemScanPage;
	ProblemLabelsPage problemLabelsPage;
	ProblemSelectItemPage problemSelectItemPage;
	FixitMobileHomePage fixitMobileHomePage;

	LoginPage loginPage;
	ResolutionPage resolutionPage;
	
	@Autowired
	ListViewPage listViewPage; 
	
	@Autowired
	JavaUtils javaUtils;
	
	AttachmentPage attachmentPage;
	TicketDetailPage ticketDetailPage;

	DcTcHomePage dCTCHomePage;
	DcTcDeliveryUpcPage dCTCDeliveryUPCPage;
	DcTcExceptionTypePage dCTCExceptionTypePage;
	DcTcExceptionDetailPage dCTCExceptionDetailPage;
	DcTcSuccessfulPage dCTCSuccessfulPage;
	DcTcPoLInePage dcTcPoLInePage;

	@Step
	public void createProblemTicket(String problemName) {
		try {
			createProblemFromFixitApp(problemName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with creating problem ticket", e);
		}
	}

	@Step
	public void createProblemTicketWeb(String problemName) {
		try {
			createProblemFromFixitWeb(problemName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with creating problem ticket", e);
		}
	}

	@Step
	public void createProblemTicketForSams(String problemName) {
		try {
			createProblemFromFixitAppSams(problemName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with creating problem ticket", e);
		}
	}

	@Step
	public void loginOneTimeWebdashbaord(String user,String dc) {
		try {
			loginPage.loginIntoFixit(getFixitLoginURL(user), decryptPass(getUser()), decryptPass(getPass()),dc,user);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Unable to login into Fixit Web Dashboard ", e);
		}
	}



	@Step
	public void updateConfig(String str) throws ConfigurationException, InterruptedException {
		PropertiesConfiguration config = null;
		config = new PropertiesConfiguration("./src/test/resources/env.properties");
		String configValue = (String) config.getProperty("webdriver.drivertype");
		try {
			if (getDriver() != null) {
				getDriver().quit();
			}
			/*
			 * if (problemLabelsPage.getAndroidDriver() != null) {
			 * problemLabelsPage.closeAndroidDriver(); }
			 */
			if ((str.equals("false")) && (configValue.equals("appium"))) {
				config.setProperty("webdriver.drivertype", "notappium");
				config.save();
				Thread.sleep(10000);
			}
			else if ((str.equals("true")) && (configValue.equals("notappium"))) {
				config.setProperty("webdriver.drivertype", "appium");
				config.save();
				Thread.sleep(10000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Step
	public void verifyResolutionTicket(String resolution, String user) {
		try {
			verifyResolutionFromWeb(resolution, user);
		//	ticketDetailPage.clickAttachment();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with validation of resolution ", e);
		}
	}
	
//	@Step
//	public void verifyResolutionTicketGdc(String resolution, String user) {
//		try {
//			verifyResolutionFromWebGdc(resolution, user);
//		} catch (AssertionError | FailsafeException e) {
//			throw new TestCaseFailure(e);
//		} catch (Exception e) {
//			throw new AutomationFailure("Something went wrong with validation of resolution ", e);
//		}
//	}

	@Step
	public void verifyResolutionTicketWeb(String resolution, String user) {
		try {
			verifyResolutionFromWebDashboard(resolution, user);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with validation of resolution ", e);
		}
	}

	@Step
	public void assigneProblemTicketTOHO(String groupName) {
		try {
			fixitHomePage.submitnotOnPOFromDCNewLane(groupName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with DC assigns problem ticket to HO	", e);
		}
	}

	@Step
	public void hoAssignsProblemToAnotherHO() {
		try {
			fixitHomePage.hoAssignsProblemToAnotherHOUser("user1");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with HO assigns problem ticket another HO	", e);
		}
	}

	@Step
	public void hoRequestForMoreInfo() {
		try {
			fixitHomePage.clickOnWorkingLaneProblemTicketHO(problemtTicket); // HO assigns to DC
			fixitHomePage.hoRequestForMoreInfoFromDC();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with HO user requesting info from DC	", e);
		}
	}

	@Step
	public void dcUserResubmitsProblemTicket(String userName) {
		try {
			// loginPage.loginIntoFixit(environment.getProperty("fixit_tracker_web_url"));
			// // tracker submits ticket
			fixitHomePage.submitAwaitingInfoTicketFromDC(problemtTicket);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure(
					"Something went wrong with DC user re-submit problem from Awaiting Info. lane	", e);
		}
	}

	@Step
	public void provideResolutionForProblem(String resolutionName, String userName,String market) {
		try {
			provideResolutionFromWebDasboard(resolutionName, userName,market);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}
	
	@Step
	public void provideResolution(String resolutionName, String userName,String market) {
		try {
			provideResolutionFromWebDashboard(resolutionName, userName,market);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}




	@Step
	public void provideResolutionEdit(String resolutionName, String userName,String market) {
		try {
			provideResolutionFromWebDashboardEdit(resolutionName, userName,market);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}

	@Step
	public void editTicket() {
		try {
                editTicketDetails();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}

	@Step
	public void editSlot(String slotId) {
		try {
			editSlotWeb(slotId);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}



	@Step
	public void provideDispositionForDamage(String dispositionName) {
		try {
			provideDispositionFromWebDashboardDamage(dispositionName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}

	@Step
	public void verifyDispositionForDamage(String dispositionName) {
		try {
			verifyDispositionFromWebDashboardDamage(dispositionName);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}

	@Step
	public void cancelContainers() {
		try {
			cancelContainersFromWeb();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolution	", e);
		}
	}

	private void provideDispositionFromWebDashboardDamage(String disposition) throws InterruptedException {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			Thread.sleep(1000);
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchDamage(ticketNumber);
			listViewPage.clickOnFirstTicket();
			resolutionPage.provideDispositionForDamage(disposition, WMRA);
			Thread.sleep(3000);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolutions", e);
		}
	}

	private void verifyDispositionFromWebDashboardDamage(String disposition) throws InterruptedException {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			Thread.sleep(1000);
			ticketDetailPage.goBackToListView();
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchDamage(ticketNumber);
			listViewPage.clickOnFirstTicket();
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					resolutionPage.getDispositionText().trim().equalsIgnoreCase(disposition.trim()));
			logger.info("Disposition Type is Expected : {} & Actual : {}",disposition,
					resolutionPage.getDispositionText());
			Thread.sleep(3000);
			if(getDriver()!=null) {
				getDriver().close();
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolutions", e);
		}
	}

	private void cancelContainersFromWeb() throws InterruptedException {
		try {
			String ticketNumber;
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}

//			Map<String,String> testData=AppiumHelper.getmapTestData();
//			System.out.println(testData);
//			String ticketNumber = testData.get("ticketID");
			Thread.sleep(1000);
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchDamage(ticketNumber);
			listViewPage.clickOnFirstTicket();
			resolutionPage.cancelContainersFromWeb();
			Thread.sleep(3000);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolutions", e);
		}
	}


	private String getEnvironmentToRunScript() {
		String environement = null;
		if (environment.getProperty("fixit_run_config").equalsIgnoreCase("LOCAL")) {
			environement = environment.getProperty("fixit_run_config");
		} else {
			environement = "GRID";
		}
		return environement;
	}

	private String getFixitLoginURL(String user) {
		if (user.equalsIgnoreCase("TRACKER")) {
			user = environment.getProperty("fixit_tracker_web_url");
		} else if(user.equalsIgnoreCase("RESOLVE")){
			user = environment.getProperty("fixit_resolve_web_url");
		}else if(user.equalsIgnoreCase("DAMAGE")){
			user = environment.getProperty("fixit_damage_web_url");
		}
		return user;
	}

	private String getUser() throws ConfigurationException {
		PropertiesConfiguration envProperties = new PropertiesConfiguration("./src/test/resources/env.properties");
		return (String) envProperties.getProperty("fixit_dashboard_user");
	}

	private String getPass() throws ConfigurationException {
		PropertiesConfiguration envProperties = new PropertiesConfiguration("./src/test/resources/env.properties");
		return (String) envProperties.getProperty("fixit_dashboard_pass");
	}

	private String decryptPass(String pass) {
		byte[] decodedBytes = Base64.decode(pass.getBytes());
		return new String(decodedBytes);
	}

	@Step
	public void searchProblemTicket(String searchField, String user) {
		try {
			loginPage.loginIntoFixit(getFixitLoginURL(user), getUser(), getPass());
			logger.info("searching problem ticket");
			fixitHomePage.searchProblemTicket(searchField, problemtTicket);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with searching problem ticket	", e);
		}
	}

	@Step
	public void searchProblemTicket() {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			Thread.sleep(1000);
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchTicket(ticketNumber);
			listViewPage.clickOnFirstTicket();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with searching problem ticket	", e);
		}
	}

	@Step
	public void verifyProblemTicketNotVisible() {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info("testFlowData before providing resolution :: {}", testData);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			Thread.sleep(1000);
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchDamage(ticketNumber);
			Boolean ticketNotFound = !getDriver().findElements(By.xpath("//*[text()='No results found']")).isEmpty();
			Assert.assertTrue(ErrorCodes.FIXIT_DAMAGE_TICKET_FOUND, ticketNotFound);
			String count = listViewPage.getResultcount();
			count = count.substring(0,count.indexOf(" "));
			Assert.assertEquals(ErrorCodes.FIXIT_SEARCH_RESULT_COUNT, count, "0");

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with searching problem ticket	", e);
		}
	}

	@Step
	public void verifyProblemDetails() {
		try {
			Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
					fixitHomePage.verifyProblemTicketStatus("ASSIGNED"));
			Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_GROUP_MISMATCH,
					fixitHomePage.verifyProblemTicketGroup("DC"));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with verifying problem ticket details	", e);
		}
	}

	private void createProblemFromFixitApp(String problemName) {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info("Test flow data before creating problem : {}", testData);
		JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
		PO_NUMBER = (String) poNumberArray.get(0);
		JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
		String UPC_NUMBER = (String) itemUpcArray.get(0);
		JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
		String POLINENUMBER = (String) poLineNumberArray.get(0);
		JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
		String DELIVERY_NUMBER = (String) deliveryArray.get(0);
		logger.info("Creating Problem ticket for : {}", problemName);

		switch (problemName.trim()) {
		case "NOP":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.navigateToSelectNOP();
			logger.info("Select item not in list");
			problemSelectItemPage.navigateToNOP();
			problemExceptionSubTypePage.selectNotOnPO();
			logger.info("Selected not on po");
			problemEnterDetailPage.enterExceptionDetails(PROBLEM_QTY, TI, HI, PO_NUMBER, COMMENTS);
			logger.info("Entered exception details");
			break;

		case "NOTWALMARTFREIGHT":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.navigateToSelectNWF();
			logger.info("Select item not in list");
			logger.info("Select item not in list");
			problemExceptionSubTypePage.selectnotWalmartFreight();
			logger.info("Selected not walmart freight");
			problemEnterDetailPage.enterExceptionDetailsForNotWalmartFreight(PROBLEM_QTY, TI, HI, ANOTHER_DC, COMMENTS);
			logger.info("Entered exception details");
			break;

		case "HAZMAT":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Selected PO Line");
			problemExceptionSubTypePage.selectHazmat();
			logger.info("Selected hazmat");
			problemEnterDetailPage.enterExceptionDetailsForHazmat(PROBLEM_QTY, TI, HI, COMMENTS);
			logger.info("Entered exception details");
			break;

		case "WRONGDC":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.navigateToSelectNOP();
			logger.info("Select item not in list");
			problemSelectItemPage.navigateToNOP();
			problemExceptionSubTypePage.selectwrongDC();
			logger.info("Selected not on po");
			problemEnterDetailPage.enterExceptionDetailsForWrongDC(PROBLEM_QTY, TI, HI, ANOTHER_DC, COMMENTS);
			logger.info("Entered exception details");
			break;

		case "WRONGPACK":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Selected PO Line");
			problemExceptionSubTypePage.selectWrongPack();
			logger.info("Selected wrong pack");
			problemEnterDetailPage.enterExceptionDetailsForWrongPack(PROBLEM_QTY, TI, HI, COMMENTS, receivedVNPK,
					receivedWNPK);
			logger.info("Entered exception details");
			break;

		case "NOPNOTINITEM":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.navigateToSelectNWF();
			logger.info("Select not in PO");
			logger.info("Select item not in list");
			problemExceptionSubTypePage.selectNotOnPO();
			logger.info("Selected not on po");
			problemEnterDetailPage.enterExceptionDetails(PROBLEM_QTY, TI, HI, PO_NUMBER, COMMENTS);
			logger.info("Entered exception details");
			break;

		case "WRONGDCNOTINITEM":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.scanUPCForNotWalmartFreight(UPC_NUMBER);
			logger.info("Scanned UPC Number");
			problemPOLinePage.navigateToSelectNWF();
			logger.info("Select not in PO");
			logger.info("Select item not in list");
			problemExceptionSubTypePage.selectwrongDC();
			logger.info("Selected not on po");
			problemEnterDetailPage.enterExceptionDetailsForWrongDC(PROBLEM_QTY, TI, HI, ANOTHER_DC, COMMENTS);
			logger.info("Entered exception details");
			break;

		default:
			logger.info("Problem type not available...");
		}
		problemLabelsPage.reportProblem();
		problemtTicket = problemLabelsPage.getProblemTicketNum();

		ProblemDetail problemDetail = new ProblemDetail();
		problemDetail.setProblemTicketNumber(problemtTicket);
		updateTestFlowDataForProblem(problemDetail);
		logger.info("Problem creation completed...");
		logger.info("Problem ticket No. from fixit mobile app is : {}", problemtTicket);
		problemLabelsPage.navigateToHomePage();
		String containerId = getContainerID(problemtTicket);
		fixitMobileHomePage.scanProblemTicket(containerId);
		logger.info("Scanned problem container...");

		logger.info("Problem ticket validation started...");

		Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_CASES_MISMATCH,
				fixitMobileHomePage.getProblemCasesCount().trim().equalsIgnoreCase(PROBLEM_QTY));
		logger.info("Exception qty is Expected : {} & Actual : {}", PROBLEM_QTY,
				fixitMobileHomePage.getProblemCasesCount());

		Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_NAME_MISMATCH,
				fixitMobileHomePage.getProblemName().trim().equalsIgnoreCase(getProblemName(problemName.trim())));
		logger.info("Problem name is Expected : {} & Actual : {}", getProblemName(problemName.trim()),
				fixitMobileHomePage.getProblemName());

		Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_TICKET_NUMBER_MISMATCH,
				fixitMobileHomePage.getTicketNum().trim().equalsIgnoreCase(problemtTicket));
		logger.info("Ticket Number is Expected : {} & Actual : {}", problemtTicket,
				fixitMobileHomePage.getTicketNum().trim());

		Assert.assertTrue(ErrorCodes.FIXIT_DELIVERY_NUMBER_MISMATCH,
				fixitMobileHomePage.getDeliveryNum().trim().equalsIgnoreCase(DELIVERY_NUMBER));
		logger.info("Deliver Number is Expected : {} & Actual : {}", DELIVERY_NUMBER,
				fixitMobileHomePage.getDeliveryNum().trim());

		Assert.assertTrue(ErrorCodes.FIXIT_TICKET_ASSIGNED_GROUP_FIELD_MISMATCH,
				fixitMobileHomePage.getAssignedGroup().trim().equalsIgnoreCase("DC"));
		logger.info("Assigned Group is Expected : DC & Actual : {}", fixitMobileHomePage.getAssignedGroup().trim());

		Assert.assertTrue(ErrorCodes.FIXIT_TICKET_CREATEDBY_FIELD_MISMATCH,
				fixitMobileHomePage.getCreatedBy().trim().equalsIgnoreCase("sysadmin"));
		logger.info("Created By is Expected : sysadmin & Actual : {}", fixitMobileHomePage.getCreatedBy().trim());

		// Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_PO_NUMBER_MISMATCH,fixitMobileHomePage.getProblemPONumebr().trim().equalsIgnoreCase(PO_NUMBER));
		// logger.info("Problem PO number is Expected : {} & Actual : {}",
		// PO_NUMBER,fixitMobileHomePage.getProblemPONumebr().trim());

		Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_CONTAINER_ID_MISMATCH,
				fixitMobileHomePage.getProblemContainerId().trim().equalsIgnoreCase(containerId));
		logger.info("Problem container ID is Expected : {} & Actual : {}", containerId,
				fixitMobileHomePage.getProblemContainerId().trim());
		logger.info("Problem ticket  validation completed...");
	}

	private void createProblemFromFixitWeb(String problemName) {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info("Test flow data before creating problem : {}", testData);
		JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
		PO_NUMBER = (String) poNumberArray.get(0);
		JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
		String UPC_NUMBER = (String) itemUpcArray.get(0);
		JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
		String POLINENUMBER = (String) poLineNumberArray.get(0);
		JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
		String DELIVERY_NUMBER = (String) deliveryArray.get(0);
		logger.info("Creating Problem ticket for : {}", problemName);

		switch (problemName.trim()) {
		case "NOTWALMARTFREIGHT":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, "123456789");
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dCTCExceptionTypePage.selectNotWalmartFreight();
			logger.info("Selected Not a Walmart Freight");
			dCTCExceptionDetailPage.enterNotWalmartFreightDetails(PROBLEM_QTY, TI, DC_NUMBER, COMMENTS);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		case "HAZMAT":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickFirstPOLine();
			logger.info("Selected first PO line ");
			dCTCExceptionTypePage.clickHazmat();
			logger.info("Selected Hazmat problem");
			dCTCExceptionDetailPage.enterHazmatDetails(PROBLEM_QTY, TI, COMMENTS);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		case "WRONGPACK":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickFirstPOLine();
			logger.info("Selected first PO line ");
			dCTCExceptionTypePage.clickWrongPack();
			logger.info("Selected Wrong Pack problem");
			dCTCExceptionDetailPage.enterWrongPackDetails(PROBLEM_QTY, TI,receivedVNPK,
					receivedWNPK, COMMENTS);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		case "WRONGDCNOTINITEM":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickOnPOLineNotFound();
			logger.info("Selected PO Line not found");
			dcTcPoLInePage.clickItemNotFound();
			logger.info("Selected item not found");
			dCTCExceptionTypePage.clickWrongShipment();
			logger.info("Selected Wrong DC Not In Item problem");
			dCTCExceptionDetailPage.enterWrongShipmentDetails(PROBLEM_QTY, TI,COMMENTS,ANOTHER_DC);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		case "NOPNOTINITEM":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickOnPOLineNotFound();
			logger.info("Selected PO Line not found");
			dcTcPoLInePage.clickItemNotFound();
			logger.info("Selected item not found");
			dCTCExceptionTypePage.clickNOP();
			logger.info("Selected NOP NOT IN ITEM problem");
			dCTCExceptionDetailPage.enterNOPDetails(PROBLEM_QTY, TI,COMMENTS,PO_NUMBER);
			logger.info("Entered exception details for : " + problemName);
			break;

		case "NOP":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickOnPOLineNotFound();
			logger.info("Selected PO Line not found");
			dcTcPoLInePage.clickFirstItem();
			logger.info("Selected first item ");
			dCTCExceptionTypePage.clickNOP();
			logger.info("Selected Not on PO problem");
			dCTCExceptionDetailPage.enterNOPDetails(PROBLEM_QTY, TI,COMMENTS,PO_NUMBER);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		case "WRONGDC":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickOnPOLineNotFound();
			logger.info("Selected PO Line not found");
			dcTcPoLInePage.clickFirstItem();
			logger.info("Selected first item ");
			dCTCExceptionTypePage.clickWrongShipment();
			logger.info("Selected Wrong DC problem");
			dCTCExceptionDetailPage.enterWrongShipmentDetails(PROBLEM_QTY, TI,COMMENTS,ANOTHER_DC);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		case "OVERAGE":
			listViewPage.clickOnCreateTicket();
			dCTCHomePage.navigateToDeliveryPage();
			logger.info("Delivery and UPC page displayed");
			dCTCDeliveryUPCPage.submitDeliveryUPC(DELIVERY_NUMBER, UPC_NUMBER);
			logger.info("Delivery number entered");
			logger.info("Scanned UPC Number");
			dcTcPoLInePage.clickFirstPOLine();
			logger.info("Selected first PO line ");
			dCTCExceptionTypePage.clickOverrage();
			logger.info("Selected OVERAGE problem");
			dCTCExceptionDetailPage.enterHazmatDetails(PROBLEM_QTY, TI, COMMENTS);
			logger.info("Entered exception details for : " + problemName);
			break;
			
		default:
			logger.info("Problem type not available...");
		}
		dCTCExceptionDetailPage.selectPrinter();
		logger.info("Selected printer");
		dCTCExceptionDetailPage.submitProblem();
		String ticketID = dCTCSuccessfulPage.getTikcetID();
		problemtTicket = ticketID;
		logger.info("Problem ticket ID : " + ticketID);

		ProblemDetail problemDetail = new ProblemDetail();
		problemDetail.setProblemTicketNumber(ticketID);
		problemDetail.setproblemQty(PROBLEM_QTY);
		updateTestFlowDataForProblem(problemDetail);
		getContainerID(ticketID);
	}

	private String getProblemName(String problemName) {
		if (problemName.equalsIgnoreCase("NOP")) {
			return "Not on PO";
		} else if (problemName.equalsIgnoreCase("NOTWALMARTFREIGHT")) {
			return "Not Walmart Freight";
		} else if (problemName.equalsIgnoreCase("HAZMAT")) {
			return "Hazmat";
		} else if (problemName.equalsIgnoreCase("WRONGDC")) {
			return "Wrong DC";
		} else if (problemName.equalsIgnoreCase("WRONGPACK")) {
			return "Wrong Pack";
		} else if (problemName.equalsIgnoreCase("NOPNOTINITEM")) {
			return "Not on PO";
		} else if (problemName.equalsIgnoreCase("WRONGDCNOTINITEM")) {
			return "Wrong DC";
		}else if (problemName.equalsIgnoreCase("OVERAGE")) {
			return "Overage";
		}
		return "No problem match";
	}
	
	private String getResolutionName(String resolutionName) {
		if (resolutionName.trim().equalsIgnoreCase("Added a PO Line")) {
			return "Added a PO line";
		} else if (resolutionName.trim().equalsIgnoreCase("Destroy")) {
			return "Destroy";
		}else if (resolutionName.trim().equalsIgnoreCase("Receive Against Original Line")) {
			return "Receive against original line";
		}else if (resolutionName.trim().equalsIgnoreCase("Return To Vendor")) {
			return "Return to vendor";
		}else if (resolutionName.trim().equalsIgnoreCase("Rework and Receive")) {
			return "Rework and Receive";
		}else if (resolutionName.trim().equalsIgnoreCase("Receive Against Another PO")) {
			return "Receive against another PO";
		}
		return "No resolution match found";
	}

	@Step
	public void updateOMSPOForResolution(String resolutionName) {
		switch (resolutionName.trim()) {
		case "Added a PO Line":
			postAddPOLine();
			break;

		case "Receive against another PO":
			break;

		default:
			logger.info("Resolution is not applicable");
		}
	}

	@Step
	public void validateResolutionMobile(String resolution) {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info("Test data before resolution validation : {}", testData);
		JSONArray problemContainerArray = JsonPath.read(testData, "$..problemDetails..problemContainer");
		String problemContainer = (String) problemContainerArray.get(0);
		fixitMobileHomePage.scanProblemTicket(problemContainer);
		fixitMobileHomePage.clickOnResolutionIcon();
		switch (resolution.trim()) {
		case "Receive against another PO":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Receive against another PO"));
			logger.info("Ticket Number is Expected : Receive against another PO & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());
			break;

		case "Destroy":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Destroy"));
			logger.info("Ticket Number is Expected : Destroy & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());

			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_CASES_MISMATCH,
					fixitMobileHomePage.getQtyToReceive().trim().equalsIgnoreCase(PROBLEM_QTY));
			logger.info("Problem cases is Expected : {} & Actual : {}", PROBLEM_QTY,
					fixitMobileHomePage.getQtyToReceive().trim());
			break;

		case "Donate":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Donate"));
			logger.info("Ticket Number is Expected : Donate & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());

			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_CASES_MISMATCH,
					fixitMobileHomePage.getQtyToReceive().trim().equalsIgnoreCase(PROBLEM_QTY));
			logger.info("Problem cases is Expected : {} & Actual : {}", PROBLEM_QTY,
					fixitMobileHomePage.getQtyToReceive().trim());
			break;

		case "Added a PO Line":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Added a PO line"));
			logger.info("Problem resolution name is Expected : Added a PO line & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());
			break;

		case "Receive against original line":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Receive against original line"));
			logger.info("Ticket Number is Expected : Receive against original line & Actual : {}", 
					fixitMobileHomePage.getResolutionName().trim());
			break;

		case "Transfer to another DC":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Transfer to another DC"));
			logger.info("Ticket Number is Expected : Transfer to another DC & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_CASES_MISMATCH,
					fixitMobileHomePage.getQtyToReceive().trim().equalsIgnoreCase(PROBLEM_QTY));
			logger.info("Problem cases is Expected : {} & Actual : {}", PROBLEM_QTY,
					fixitMobileHomePage.getQtyToReceive().trim());
			break;

		case "Salvage":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equalsIgnoreCase("Salvage"));
			logger.info("Ticket resolution is Expected : Salvage & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());
			break;
			
		case "Return to vendor":
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					fixitMobileHomePage.getResolutionName().trim().equals("Return to vendor"));
			logger.info("Ticket resolution is Expected : Return to vendor & Actual : {}",
					fixitMobileHomePage.getResolutionName().trim());
			break;

		default:
			logger.info("Resolution parameter is not applicable");
		}
	}

	public String getContainerID(String ticketNumber) {
		String containerID = null;
		String market = Config.DC.getValue();
		logger.info("Market is {} ", market);
		logger.info("Ticket Number is {} ", ticketNumber);
		if(market.equalsIgnoreCase(DC_TYPE.RDC.getValue())){
			try {
				Response responseProblemContainer = null;
				responseProblemContainer = given().relaxedHTTPSValidation().headers(getProblemHeaders()).when()
						.get(environment.getProperty("fixit_problem_container"), ticketNumber);
				logger.info("Problem container response is : {}", responseProblemContainer.getStatusCode());
				Assert.assertEquals(ErrorCodes.FIXIT_PROBLEM_TICKET_CONTAINER_ID_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						responseProblemContainer.getStatusCode());
				JSONArray containerIDArray = JsonPath.read(responseProblemContainer.asString(), "$.containers..label");
				containerID = (String) containerIDArray.get(0);
				logger.info("Problem container ID : {}", containerIDArray.get(0));
//				problemDetail.setproblemContainer((String) containerIDArray.get(0));
//				JSONArray statusArray = JsonPath.read(responseProblemContainer.asString(), "$..status");
//				problemDetail.setproblemStatus((String) statusArray.get(0));
//				updateTestFlowDataForProblem(problemDetail);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			String url = null;
			if(market.equalsIgnoreCase("ACC"))
				url = "https://fixit-platform-application.qa.walmart.net/graphql";
			else
				url = "https://fixit-platform-application.stg.walmart.net/graphql";
			String query = "{\"query\":\"{ searchException ( searchInput:{identifier:\\\"" + ticketNumber + "\\\"},pageSize:25 ) { issues  { cases  { label } } }}\"}";
			//String payload = "{ searchException ( searchInput:{identifier:" + ticketNumber + "},pageSize:25 ) { issues  { cases  { label } } }}";
			Response responseProblemContainer = SerenityRest.given().relaxedHTTPSValidation().body(query)
			        .headers(getProblemHeaders())
					.header("wmt-source","FIXIT")
					.header("wmt-channel","WEB")
					.contentType("application/json").post(environment.getProperty("fixit_container_label")).then().extract().response();
			Assert.assertEquals(ErrorCodes.FIXIT_PROBLEM_TICKET_CONTAINER_ID_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					responseProblemContainer.getStatusCode());
			JSONArray containerIDArray = JsonPath.read(responseProblemContainer.asString(), "$..cases..label");
			containerID = (String) containerIDArray.get(0);
			logger.info("Problem container ID : {}", containerIDArray.get(0));
//			problemDetail.setproblemContainer((String) containerIDArray.get(0));
//			JSONArray statusArray = JsonPath.read(responseProblemContainer.asString(), "$..status");
//			problemDetail.setproblemStatus((String) statusArray.get(0));
//			updateTestFlowDataForProblem(problemDetail);
		}

		return containerID;
	}

	public void postAddPOLine() {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info("testFlowData before updating PO Line :: {}", testData);
		JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
		String poNumber = (String) poNumberArray.get(0);
		JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
		String DELIVERY_NUMBER = (String) deliveryArray.get(0);
		JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
		String UPC_NUMBER = (String) itemUpcArray.get(0);
		JSONArray itemArray = JsonPath.read(testData, "$..poDetails..itemNumber");
		String itemNum = (String) itemArray.get(0);
		String problemResolutionMessage = null;
		JSONObject jsonMessage = null;
		Response omsResponse = null;
		try {
			problemResolutionMessage = textParser.readTextFile(FileNames.FIXIT_PROBLEM_ATLASPOLINEUPDATE);
			problemResolutionMessage = format(problemResolutionMessage, DELIVERY_NUMBER, poNumber, itemNum, UPC_NUMBER);
			jsonMessage = new JSONObject(problemResolutionMessage);
			logger.info("Request body for Creation of problem :: {}", jsonMessage);
			omsResponse = SerenityRest.given().contentType("application/json").relaxedHTTPSValidation()
					.headers(getProblemHeaders()).body(jsonMessage.toString()).when()
					.post(environment.getProperty("po_line_add"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String format(String text, String... val2) {
		for (int occurence = 0; occurence < val2.length; occurence++) {
			text = text.replace("#" + occurence + "#", val2[occurence]);
		}
		return text;
	}

	private Headers getProblemHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		return new Headers(headerList);
	}

	@Step
	public void cancelTicket(String app) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
			String ticketNumber = (String) poNumberArray.get(0);
			if (app.equalsIgnoreCase("mobile")) {
				cancelMobileTicket();
			} else {
				listViewPage.searchTicket(ticketNumber);
				listViewPage.clickOnFirstTicket();
				ticketDetailPage.cancelWebTicket();
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with testFlowData update", e);
		}
	}
	
	@Step
	public void cancelTicketGdc(String app) {
		try {
			Map<String,String> testData=AppiumHelper.getmapTestData();
			String ticketNumber = testData.get("ticketID");
			if (app.equalsIgnoreCase("mobile")) {
				cancelMobileTicketGdc();
			} else {
				listViewPage.searchTicket(ticketNumber);
				listViewPage.clickOnFirstTicket();
				ticketDetailPage.cancelWebTicket();
			}
			if(getDriver()!=null)
				getDriver().close();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with testFlowData update", e);
		}
	}

	@Step
	public void cancelTicketFromPlatform(String app) {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			if (app.equalsIgnoreCase("mobile")) {
				fixitMobileHomePage.searchProblemTicket(ticketNumber);
				logger.info("Scanned problem ticket : {} ", ticketNumber);
				Thread.sleep(2000);
				fixitMobileHomePage.cancelTicket();
			} else {
				listViewPage.searchTicket(ticketNumber);
				listViewPage.clickOnFirstTicket();
				ticketDetailPage.cancelWebTicket();
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with ticket cancellation", e);
		}
	}

	@Step
	public void cancelDamageTicketFromPlatform(String app) {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			if (app.equalsIgnoreCase("mobile")) {
				fixitMobileHomePage.searchProblemTicket(ticketNumber);
				logger.info("Scanned problem ticket : {} ", ticketNumber);
				Thread.sleep(2000);
				fixitMobileHomePage.cancelTicket();
			} else {
				listViewPage.searchDamage(ticketNumber);
				listViewPage.clickOnFirstTicket();
				ticketDetailPage.cancelDamageWebTicket();
				Failsafe.with(retryPolicy).run(() -> {
					Thread.sleep(1000);
					String actualStatus=ticketDetailPage.getDamageStatus().trim();
					String expectedStatus = "Canceled";
					logger.info("Problem ticket status actual : {} & expected : {} ",actualStatus,expectedStatus);
					Assert.assertEquals(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
							actualStatus, expectedStatus);

				});
				ticketDetailPage.goBackToListView();
			}

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with ticket cancellation", e);
		}
	}

	private void cancelMobileTicket() {
		String containerId = getContainerID(problemtTicket);
		fixitMobileHomePage.cancelTicket();
	}
	
	private void cancelMobileTicketGdc() throws InterruptedException {
		/*Map<String,String> testData=AppiumHelper.getmapTestData();
		String ticketNumber = testData.get("ticketID");
		String containerId=getContainerID(ticketNumber);
		fixitMobileHomePage.scanProblemTicket(containerId);*/
		logger.info("Scanned problem container...");
		Thread.sleep(2000);
		fixitMobileHomePage.cancelTicket();
	}

	public void validateCanceledTicket(String status, String dc) {
		String containerId = getContainerID(problemtTicket);
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info("testFlowData before validating CANCEL ticket :: {}", testData);
		if (status.equalsIgnoreCase("CANCELED")) {
			JSONArray problemStatusArray = JsonPath.read(testData, "$..problemDetails[3]..problemStatus");
			String problemStatus = (String) problemStatusArray.get(0);
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "CANCELED", problemStatus);
			logger.info("Ticket status is Expected : CANCELED & Actual : {}", problemStatus);
		} else if (status.equalsIgnoreCase("CLOSED")) {
			JSONArray problemStatusClosedArray = JsonPath.read(testData, "$..problemDetails[2]..problemStatus");
			String problemStatusClosed = (String) problemStatusClosedArray.get(0);
			logger.info("Ticket status is Expected : CLOSED & Actual : {}", problemStatusClosed);
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "CLOSED", problemStatusClosed);
		} else if (status.equalsIgnoreCase("CLOSED") && Config.DC == DC_TYPE.SAMS) {
			logger.info("Ticket status is Expected : CLOSED & Actual : {}", " ");
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "CLOSED", " ");
		} else {
			JSONArray problemStatusArray = JsonPath.read(testData, "$..problemDetails[2]..problemStatus");
			String problemStatus = (String) problemStatusArray.get(0);
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "CANCELED", problemStatus);
			logger.info("Ticket status is Expected : CANCELED & Actual : {}", problemStatus);
		}
	}
	
	public void validateCanceledTicketGdc(String status, String dc) {
		Response responseProblemContainer = null;
		Map<String,String> testData=AppiumHelper.getmapTestData();
		String problemtTicket = testData.get("ticketID");
		logger.info("Searching for ticket - {}", problemtTicket);
		
	 if (status.equalsIgnoreCase("CLOSED")  && Config.DC == DC_TYPE.GDC) {
		
			responseProblemContainer = given().relaxedHTTPSValidation().headers(getProblemHeaders()).when()
					.get(environment.getProperty("fixit_problem_container"), problemtTicket);
			logger.info("Problem container response is : {}", responseProblemContainer.getStatusCode());
			Assert.assertEquals(ErrorCodes.FIXIT_PROBLEM_TICKET_CONTAINER_ID_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					responseProblemContainer.getStatusCode());
			JSONArray statusArray = JsonPath.read(responseProblemContainer.asString(), "$..status");
			
			String problemStatusClosed=(String) statusArray.get(0);
			
			logger.info("Ticket status is Expected : CLOSED & Actual : {}", problemStatusClosed);
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "CLOSED", problemStatusClosed);
		} else {
			responseProblemContainer = given().relaxedHTTPSValidation().headers(getProblemHeaders()).when()
					.get(environment.getProperty("fixit_problem_container"), problemtTicket);
			logger.info("Problem container response is : {}", responseProblemContainer.getStatusCode());
			Assert.assertEquals(ErrorCodes.FIXIT_PROBLEM_TICKET_CONTAINER_ID_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
					responseProblemContainer.getStatusCode());
			JSONArray statusArray = JsonPath.read(responseProblemContainer.asString(), "$..status");
			//JSONArray problemStatusArray = JsonPath.read(testData, "$..problemDetails[2]..problemStatus");
			String problemStatus=(String) statusArray.get(0);
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "CANCELED", problemStatus);
			logger.info("Ticket status is Expected : CANCELED & Actual : {}", problemStatus);
		}
	}

	public void verifyCancelledTicket(String status, String dc) {
		String problemStatus = fixitMobileHomePage.getTicketStatus();
		if (status.equalsIgnoreCase("CANCELLED")) {
			Assert.assertEquals(ErrorCodes.FIXIT_TICKET_STATUS_MISMATCH, "Cancelled", problemStatus);
			logger.info("Ticket status is Expected : Cancelled & Actual : {}", problemStatus);
		}
	}

	@Step
	public void assignProblemTicketToHO() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
			String ponum = (String) poNumberArray.get(0);
			JSONArray itemnumArray = JsonPath.read(testData, "$..poDetails..itemNumber");
			String itemnum = (String) itemnumArray.get(0);
			JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
			String poline = (String) poLineNumberArray.get(0);
			JSONArray departmentNumArray = JsonPath.read(testData, "$..poDetails..departmentNumber");
			String itemdep = (String) departmentNumArray.get(0);
			JSONArray potypeArray = JsonPath.read(testData, "$..poDetails..channelMethod");
			String potype = (String) potypeArray.get(0);
			JSONArray poeventArray = JsonPath.read(testData, "$..poDetails..poEvent");
			String poevent = (String) poeventArray.get(0);
			JSONArray problemContainerArray = JsonPath.read(testData, "$..problemDetails..problemContainer");
			String problemContainer = (String) problemContainerArray.get(0);
			JSONArray channelMethodArray = JsonPath.read(testData, "$..poDetails..channelMethod");
			String channelMethod = (String) channelMethodArray.get(0);
			fixitMobileHomePage.scanProblemTicket(problemContainer);
			fixitMobileHomePage.assignToHO();
			if (channelMethod.equalsIgnoreCase("CROSSU")) {
				fixitMobileHomePage.submitToHoNotWalmartFreight(ponum, poline, itemnum, "item number 1", itemdep, "33",
						poevent);
			} else if (channelMethod.equalsIgnoreCase("CROSSMU")) {
				fixitMobileHomePage.submitToHoNotWalmartFreight(ponum, poline, itemnum, "item number 1", itemdep, "3",
						poevent);
			} else if (channelMethod.equalsIgnoreCase("SSTK")) {
				fixitMobileHomePage.submitToHoNotWalmartFreight(ponum, poline, itemnum, "item number 1", itemdep, "20",
						poevent);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with DC assigns problem ticket to HO	", e);
		}
	}

	@Step
	public void assignToHOMobile() {
		try {
			String ticketID;
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info("testFlowData before Assigning to HO :: {}", testData);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketID = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketID = testData.get("ticketID");
			}

//			Map<String,String> testData=AppiumHelper.getmapTestData();
//			String ticketID = testData.get("ticketID");

//			String containerId=getContainerID(ticketID);
//			fixitMobileHomePage.scanProblemTicket(containerId);
			fixitMobileHomePage.searchProblemTicket(ticketID);
			String exceptionType = fixitMobileHomePage.getProblemName();
			logger.info("Exception Type: {}",exceptionType.trim());
			fixitMobileHomePage.assignToHO();


			fixitMobileHomePage.assignTicketToHO(exceptionType);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with DC assigns problem ticket to HO	", e);
		}
	}

	public void updateTestFlowDataForProblem(ProblemDetail problemDetail) {
		String testFlowData = tl.get().get("testFlowData").toString();
		List<ProblemDetail> listOfProblemDetail = JsonPath.read(testFlowData, "$.testFlowData.problemDetails[*]");
		listOfProblemDetail.add(problemDetail);
		JSONArray listofProblemJson;
		try {
			listofProblemJson = jsonUtil.converyListToJsonArray(listOfProblemDetail);
			testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofProblemJson, "$.testFlowData.problemDetails");
			tl.get().put("testFlowData", testFlowData);
			logger.info("Updated problem testflow data : {} ", testFlowData);
		} catch (AssertionError | FailsafeException | JsonProcessingException | ParseException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with testFlowData update", e);
		}
	}

	@Step
	public void validateAssignedGroup(String group) {
		try {
			logger.info("Ticket Number is Expected : Home Office & Actual : {}",
					fixitMobileHomePage.getAssignedGroup().trim());
			Assert.assertTrue(ErrorCodes.FIXIT_TICKET_ASSIGNED_GROUP_FIELD_MISMATCH,
					fixitMobileHomePage.getAssignedGroup().trim().equalsIgnoreCase(group));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with validating assigned group", e);
		}
	}

	@Step
	public void markResolved() {
		String ticketID;
		if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue())){
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("testFlowData before marking resolved :: {}", testData);
			JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
			ticketID = (String) poNumberArray.get(0);
		}
		else{
			testData=AppiumHelper.getmapTestData();
			ticketID = testData.get("ticketID");
		}

//		Map<String,String> testData=AppiumHelper.getmapTestData();
//		String ticketID = testData.get("ticketID");

		String containerId=getContainerID(ticketID);
		fixitMobileHomePage.scanProblemTicket(containerId);

		fixitMobileHomePage.clickOnDetailIcon();
		fixitMobileHomePage.markResolved();
	}

	private void createProblemFromFixitAppSams(String problemName) {
		String PO_NUMBER = "1234567";
		String DELIVERY_NUMBER = "43215681";
		String UPC = "00074570650972";
		logger.info("Creating Problem ticket for : {}", problemName);
		switch (problemName.trim()) {
		case "QUALITYISSUE":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.enterUPCorPLU(UPC);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Scanned PO Number");
			problemExceptionSubTypePage.selectQualityIssue();
			logger.info("Selected Quality Issue");
			problemEnterDetailPage.enterExceptionDetailsForQualityIssue(PROBLEM_QTY, TI, HI, COMMENTS, "null", "null");
			logger.info("Entered exception details");
			break;

		case "DATEISSUE":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.enterUPCorPLU(UPC);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Scanned PO Number");
			problemExceptionSubTypePage.selectDateIssue();
			logger.info("Selected Date Issue");
			problemEnterDetailPage.enterExceptionDetailsForQualityIssue(PROBLEM_QTY, TI, HI, COMMENTS, "null", "null");
			logger.info("Entered exception details");
			break;

		case "OVERRAGE":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.enterUPCorPLU(UPC);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Scanned PO Number");
			problemExceptionSubTypePage.selectOverrage();
			logger.info("Selected Date Issue");
			problemEnterDetailPage.enterExceptionDetailsForQualityIssue(PROBLEM_QTY, TI, HI, COMMENTS, "null", "null");
			logger.info("Entered exception details");
			break;

		case "NOP":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.enterUPCorPLU(UPC);
			logger.info("Scanned UPC Number");
			problemPOLinePage.navigateToSelectNWF();
			logger.info("Select not in PO");
			logger.info("Select item not in list");
			problemExceptionSubTypePage.selectNotOnPO();
			logger.info("Selected NOP");
			problemEnterDetailPage.enterExceptionDetailsForQualityIssue(PROBLEM_QTY, TI, HI, COMMENTS, "NOP",
					PO_NUMBER);
			logger.info("Entered exception details");
			break;

		case "WRONGPACK":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.enterUPCorPLU(UPC);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Scanned PO Number");
			problemExceptionSubTypePage.selectWrongPack();
			logger.info("Selected Date Issue");
			problemEnterDetailPage.enterExceptionDetailsWrongPackForSams(PROBLEM_QTY, TI, HI, COMMENTS, "1", "1");
			logger.info("Entered exception details");
			break;

		case "WRONGDC":

			break;

		case "NOTWALMARTFREIGHT":
			problemDeliveryNumberPage.enterDeliveryNumber(DELIVERY_NUMBER);
			logger.info("Delivery number entered");
			problemScanPage.enterUPCorPLU(UPC);
			logger.info("Scanned UPC Number");
			problemPOLinePage.selectPOLine();
			logger.info("Scanned PO Number");
			problemExceptionSubTypePage.selectOverrage();
			logger.info("Selected Date Issue");
			problemEnterDetailPage.enterExceptionDetailsForQualityIssue(PROBLEM_QTY, TI, HI, COMMENTS, "null", "null");
			logger.info("Entered exception details");
			break;

		default:
			logger.info("Problem type not available...");
		}

		problemLabelsPage.reportProblem();
		problemtTicket = problemLabelsPage.getProblemTicketNum();
		logger.info("Problem ticket No. from fixit mobile app is : {}", problemtTicket);
	}

	@Step
	public void resolveProblemTicketForSams(String resolution, String dc) {

	}

	private void provideResolutionFromWebDasboard(String resolution, String userName,String market) throws InterruptedException {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		logger.info("testFlowData before providing resolution :: {}", testData);
		JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
		String ticketNumber = (String) poNumberArray.get(0);
		logger.info("Searching problem ticket number : {}", ticketNumber);
		listViewPage.searchTicket(ticketNumber);
		listViewPage.clickOnFirstTicket();
		resolutionPage.provideResolution(resolution, problemtTicket, WMRA, TOTAL_COST_ITEM, TOTAL_RETAIL_ITEM,
				ANOTHER_DC, QTY_TO_RECEIVE, new_PONumber, NEW_POLINE_NUM,market);

		// attachmentPage.sendAttachment(AppiumHelper.takeScreenShot(getDriver()));
	}
	
	private void provideResolutionFromWebDashboard(String resolution, String userName,String market) throws InterruptedException {
		try {
			String ticketNumber, poNumber, poLine, quantity;
			if(market.equalsIgnoreCase(DC_TYPE.MCC.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info("testFlowData before providing resolution :: {}", testData);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
				poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
				poNumber = (String) poNumberArray.get(0);
				JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
				poLine = (String) poLineNumberArray.get(0);
				JSONArray problemQtyArray = JsonPath.read(testData, "$..problemDetails..problemQty");
				quantity = (String) problemQtyArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
				poNumber = testData.get("PONumber");
				poLine = testData.get("POLine");
				quantity = testData.get("Quantity");

			}
			Thread.sleep(1000);
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchTicket(ticketNumber);
//			if(market.equalsIgnoreCase("wfs") && userName.equalsIgnoreCase("tracker")){
//				listViewPage.selectAssignmentGroup("SELLER_SUPPORT");
//			}
			listViewPage.clickOnFirstTicket();
			Thread.sleep(2000);
			resolutionPage.verifyHistoryButton();
			resolutionPage.provideResolution(resolution, ticketNumber, WMRA, TOTAL_COST_ITEM, TOTAL_RETAIL_ITEM,
					ANOTHER_DC, quantity, poNumber, poLine,market);
			Thread.sleep(3000);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolutions", e);
		}
	}


	private void provideResolutionFromWebDashboardEdit(String resolution, String userName,String market) throws InterruptedException {
		try {
			Map<String,String> testData=AppiumHelper.getmapTestData();
			String ticketNumber = testData.get("ticketID");
			String poNumber = testData.get("PONumber");
			Thread.sleep(1000);
			logger.info("Searching for ticket : {}", ticketNumber);
			listViewPage.searchTicket(ticketNumber);
//			if(market.equalsIgnoreCase("wfs") && userName.equalsIgnoreCase("tracker")){
//				listViewPage.selectAssignmentGroup("SELLER_SUPPORT");
//			}
			listViewPage.clickOnFirstTicket();
			Thread.sleep(2000);
			resolutionPage.editResolution();
			resolutionPage.provideResolution(resolution, ticketNumber, WMRA, TOTAL_COST_ITEM, TOTAL_RETAIL_ITEM,
					ANOTHER_DC, testData.get("Quantity"), poNumber, testData.get("POLine"),market);
			Thread.sleep(3000);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with providing resolutions", e);
		}
	}

	//adding for edit ticket
	private void editTicketDetails(){

		try {
			listViewPage.clickOnFirstTicket();
			resolutionPage.editTicket();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	private void editSlotWeb(String slot){

		try {
			listViewPage.clickOnFirstTicket();
			resolutionPage.editSlot(slot);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	private void verifyResolutionFromWeb(String resolution, String user) {
		String testData = (String) tl.get().get(TEST_FLOW_DATA);
		JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
		String ticketNumber = (String) poNumberArray.get(0);
		try {
			ticketDetailPage.goBackToListView();
			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS,Constants.RETRY_EXECUTION_DELAY_18S, Constants.RETRY_EXECUTION_COUNT_15)).run(() ->  {
				listViewPage.searchTicket(ticketNumber);
				listViewPage.clickOnFirstTicket();
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
						ticketDetailPage.getTicketStatus().trim().equals("Answered"));
				logger.info("Problem ticket status validated");
				Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
						resolutionPage.getResolutionText().trim().equals((resolution).trim()));
				logger.info("Problem ticket resolution name validated");
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with validating resolution ", e);
		}

		/*
		 * switch (resolution.trim()) { case "Salvage": try { if
		 * (user.equalsIgnoreCase("TRACKER")) {
		 * logger.info("Problem ticket resolution name validated"); } else {
		 * 
		 * } } catch (AssertionError | FailsafeException e) { throw new
		 * TestCaseFailure(e); } catch (Exception e) { throw new
		 * AutomationFailure("Something went wrong with validating resolution ", e); }
		 * break;
		 * 
		 * default: logger.info("Resolution type not available..."); }
		 */
	}
	
//	private void verifyResolutionFromWebGdc(String resolution, String user) {
//		Map<String,String> testData=AppiumHelper.getmapTestData();
//		String ticketNumber = testData.get("ticketID");
//		logger.info("Searching for ticket - {}", ticketNumber);
//		try {
//			ticketDetailPage.goBackToListView();
//			Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS,Constants.RETRY_EXECUTION_DELAY_18S, Constants.RETRY_EXECUTION_COUNT_15)).run(() ->  {
//				listViewPage.searchTicket(ticketNumber);
//				listViewPage.clickOnFirstTicket();
//				if(resolution.trim().equals("Added a PO Line") || resolution.trim().equals("Receive Against Original Line")) {
//					logger.info("Problem ticket status actual : {} & expected : Ready to Receive or Answered",ticketDetailPage.getTicketStatus().trim());
//					Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
//							getTicketStatus().contains(ticketDetailPage.getTicketStatus().trim()));
//					/*Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
//							ticketDetailPage.getTicketStatus().trim().equals("Ready to Receive"));*/
//				} else {
//					logger.info("Problem ticket status actual : {} & expected : Solution Available",ticketDetailPage.getTicketStatus().trim());
//					Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
//							ticketDetailPage.getTicketStatus().trim().equals("Solution Available"));
//				}
//			});
//			logger.info("Problem ticket resolution name actual : {} & expected : {}",resolutionPage.getResolutionText().trim(),getResolutionName(resolution).trim());
//			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
//					resolutionPage.getResolutionText().trim().equals(getResolutionName(resolution).trim()));
//			logger.info("Problem ticket status and resolution name validated");
//			if(getDriver()!=null) {
//				getDriver().close();
//			}
//		} catch (AssertionError | FailsafeException e) {
//			throw new TestCaseFailure(e);
//		} catch (Exception e) {
//			throw new AutomationFailure("Something went wrong with validating resolution ", e);
//		}
//	}

	private void verifyResolutionFromWebDashboard(String resolution, String user) {
		String ticketNumber;
		market = Config.DC.getValue();
		if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
			ticketNumber = (String) poNumberArray.get(0);
		}
		else{
			Map<String,String> testData=AppiumHelper.getmapTestData();
			ticketNumber = testData.get("ticketID");
		}
		logger.info("Searching for ticket - {}", ticketNumber);
//		String testData = (String) tl.get().get(TEST_FLOW_DATA);
//		JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
//		String ticketNumber = (String) poNumberArray.get(0);
		try {
			ticketDetailPage.goBackToListView();
			//Failsafe.with(JavaUtils.getRetryPolicy(TimeUnit.SECONDS,Constants.RETRY_EXECUTION_DELAY_18S, Constants.RETRY_EXECUTION_COUNT_15)).run(() ->  {
				listViewPage.searchTicket(ticketNumber);
//				if(environment.getProperty("dcNumber").equals("9201") && user.equalsIgnoreCase("tracker"))
//					listViewPage.selectAssignmentGroup("SELLER_SUPPORT");
				listViewPage.clickOnFirstTicket();
				if(resolution.trim().equals("Added a PO Line") || resolution.trim().equals("Receive Against Original Line") || resolution.trim().equals("Rework and Receive") || resolution.trim().equals("Receive Against Another PO")) {
					logger.info("Problem ticket status actual : {} & expected : Ready to Receive or Answered",ticketDetailPage.getTicketStatus().trim());
					Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
							getTicketStatus().contains(ticketDetailPage.getTicketStatus().trim()));
					/*Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
							ticketDetailPage.getTicketStatus().trim().equals("Ready to Receive"));*/
				} else {
					logger.info("Problem ticket status actual : {} & expected : Solution Available",ticketDetailPage.getTicketStatus().trim());
					Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
							ticketDetailPage.getTicketStatus().trim().equals("Solution Available"));
				}
			//});
			logger.info("Problem ticket resolution name actual : {} & expected : {}",resolutionPage.getResolutionText().trim(),getResolutionName(resolution).trim());
			Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
					resolutionPage.getResolutionText().trim().equals(getResolutionName(resolution).trim()));
			logger.info("Problem ticket status and resolution name validated");
			if(getDriver()!=null) {
				getDriver().close();
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with validating resolution ", e);
		}
	}
	
	@Step
	public void verifyResolverTicket(String resolution) {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("testFlowData after ticket resolved by resolve user :: {}", testData);
			JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
			String ticketNumber = (String) poNumberArray.get(0);
			loginPage.navigateToTracker(environment.getProperty("fixit_tracker_web_url"));
			loginPage.selectAtlas();
			Failsafe.with(retryPolicy).run(() -> {
				listViewPage.searchTicket(ticketNumber);
				listViewPage.clickOnFirstTicket();
				Thread.sleep(3000);
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
						ticketDetailPage.getTicketStatus().trim().equals("Answered"));
				logger.info("Problem ticket status validated");
				Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
						resolutionPage.getResolutionText().trim().equals((resolution).trim()));
				logger.info("Problem ticket resolution name validated");
			});
			ticketDetailPage.goBackToListView();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at verifying resolution ", e);
		}
	}
	
	@Step
	public void closeWebTicket() {
		try {
			String ticketNumber;
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info("testFlowData before closing ticket :: {}", testData);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}

//			Map<String,String> testData=AppiumHelper.getmapTestData();
//			String ticketNumber = testData.get("ticketID");
			listViewPage.searchTicket(ticketNumber);
			logger.info("Searching problem ticket");
			listViewPage.clickOnFirstTicket();
			Thread.sleep(4000);
			logger.info("Clicking on ticket");
			resolutionPage.clickCloseTicket();
			//Thread.sleep(3000);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at closing problem ticket ", e);
		}
	}
	
//	@Step
//	public void createRdcExceptionMobile(String exceptionName) {/*
//		String poNumber="5765978191";
//		String upcNumber = "00051596513269";
//		//String POLINENUMBER = "";
//		String deliveryNumber = "21396321";
//		String dcNumber="32818";
//		String qty="3";
//		String pallet1="1";
//		String pallet2="2";
//		String comments="added comments for e2e testing";
//		String receivedVNPK="5";
//		String receivedWHPK="5";
//		logger.info("Creating Problem ticket from mobile for : {}", exceptionName);
//
//		try {
//			switch (exceptionName.trim()) {
//			case "RECALL":
//				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
//				logger.info("Delivery number entered : "+deliveryNumber);
//				problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
//				logger.info("Scanned UPC Number : "+upcNumber);
//				problemPOLinePage.selectPOLine();
//				logger.info("Selected PO Line");
//				problemExceptionSubTypePage.selectRecall();
//				logger.info("Selected Recall exception");
//				problemEnterDetailPage.enterExceptionDetailsForRecallRdc(qty, pallet1, pallet2,comments);
//				logger.info("Entered exception details : "+exceptionName);
//				break;
//
//			case "NOTWALMARTFREIGHT":
//				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
//				logger.info("Delivery number entered : "+deliveryNumber);
//				problemScanPage.scanUPCForNotWalmartFreight("987654321");
//				logger.info("Scanned UPC Number : "+upcNumber);
//				problemExceptionSubTypePage.selectnotWalmartFreight();
//				logger.info("Selected NWF exception");
//				problemEnterDetailPage.enterExceptionDetailsForNotWalmartFreightRdc(qty, pallet1, pallet2,comments,dcNumber,poNumber);
//				logger.info("Entered exception details : "+exceptionName);
//				break;
//
//
//			case "WRONGPACK":
//				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
//				logger.info("Delivery number entered : "+deliveryNumber);
//				problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
//				logger.info("Scanned UPC Number : "+upcNumber);
//				problemPOLinePage.selectPOLine();
//				logger.info("Selected PO Line");
//				problemExceptionSubTypePage.selectWrongPack();
//				logger.info("Selected Wrong Pack exception");
//				problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
//				logger.info("Entered exception details : "+exceptionName);
//				break;
//
//			default:
//				logger.info("Problem type not available...");
//			}
//			problemLabelsPage.reportProblem();
//			problemLabelsPage.navigateToHomePage();
//			String ticketID = problemLabelsPage.getProblemTicketNum();
//			logger.info("Problem ticket ID : " + ticketID);
//			problemLabelsPage.navigateToHomePage();
//
//			Map<String,String> testData=new HashMap<String,String>();
//			testData.put(exceptionName, ticketID);
//
//			AppiumHelper.setmapTestData(testData);
//
//		} catch (AssertionError | FailsafeException e) {
//			throw new TestCaseFailure(e);
//		} catch (Exception e) {
//			throw new AutomationFailure("Failing at problem creation from mobile app ", e);
//		}
//	*/}
	
//	@Step
//	public void createRdcExceptionWeb(String exceptionName) {
//		Map<String,String> testData=AppiumHelper.getmapTestData();
//		String poNumber= testData.get("PONumber");
//		String upcNumber = testData.get("Upc");
//		String deliveryNumber = testData.get("Delivery");
//		String dcNumber="32818";
//		String qty="3";
//		String pallet1="1";
//		String pallet2="2";
//		String comments="added comments for e2e testing";
//		String receivedVNPK="5";
//		String receivedWHPK="5";
//		String poLine="5";
//		testData.put("POLine",poLine);
//		logger.info("Creating Problem ticket from web for : {}", exceptionName);
//
//		try {
//			switch (exceptionName.trim()) {
//
//			case "NOTWALMARTFREIGHT":
//				listViewPage.clickOnCreateTicket();
//				dCTCHomePage.navigateToDeliveryPage();
//				logger.info("Delivery and UPC page displayed");
//				dCTCDeliveryUPCPage.submitDeliveryUPCRdc(deliveryNumber, "987654321");
//				logger.info("Delivery number entered");
//				logger.info("Scanned UPC Number");
//				dCTCExceptionTypePage.selectNotWalmartFreight();
//				logger.info("Selected Not a Walmart Freight");
//				dCTCExceptionDetailPage.enterNotWalmartFreightDetailsRdc(qty, pallet1, pallet2, "6655443322", dcNumber, comments);
//				logger.info("Entered exception details for : " + exceptionName);
//				break;
//
//
//			case "WRONGPACK":
//			case "OVERAGE":
//			case "DATEISSUE":
//			case "RECALL":
//				listViewPage.clickOnCreateTicket();
//				dCTCHomePage.navigateToDeliveryPage();
//				logger.info("Delivery and UPC page displayed");
//				dCTCDeliveryUPCPage.submitDeliveryUPCRdc(deliveryNumber, upcNumber);
//				logger.info("Delivery number entered");
//				logger.info("Scanned UPC Number");
//				dcTcPoLInePage.clickFirstPO();
//				logger.info("Selected first PO line ");
//				if(exceptionName.equals("OVERAGE")) {
//					dCTCExceptionTypePage.clickOverrage();
//					logger.info("Selected Overage problem type");
//					dCTCExceptionDetailPage.enterOverageDetailsRdc(qty, pallet1, pallet2, comments, receivedVNPK, receivedWHPK);
//				} else if(exceptionName.equals("DATEISSUE")) {
//					dCTCExceptionTypePage.clickDateIssue();
//					logger.info("Selected Date Issue problem type");
//					dCTCExceptionDetailPage.enterOverageDetailsRdc(qty, pallet1, pallet2, comments, receivedVNPK, receivedWHPK);
//				} else if(exceptionName.equals("RECALL")){
//					dCTCExceptionTypePage.clickRecall();
//					logger.info("Selected Recall problem type");
//					dCTCExceptionDetailPage.enterWrongPackDetailsRdc(qty, pallet1, pallet2, comments, receivedVNPK, receivedWHPK);
//				}else{
//					dCTCExceptionTypePage.clickWrongPack();
//					logger.info("Selected Wrong Pack problem type");
//					dCTCExceptionDetailPage.enterWrongPackDetailsRdc(qty, pallet1, pallet2, comments, receivedVNPK, receivedWHPK);
//				}
//				logger.info("Entered exception details for : " + exceptionName);
//				break;
//
//			case "WRONGDCNOTINITEM":
//				listViewPage.clickOnCreateTicket();
//				dCTCHomePage.navigateToDeliveryPage();
//				logger.info("Delivery and UPC page displayed");
//				dCTCDeliveryUPCPage.submitDeliveryUPCRdc(deliveryNumber, upcNumber);
//				logger.info("Delivery number entered");
//				logger.info("Scanned UPC Number");
//				dcTcPoLInePage.clickOnPOLineNotFound();
//				logger.info("Selected PO Line not found");
//				dcTcPoLInePage.clickItemNotFound();
//				logger.info("Selected item not found");
//				dCTCExceptionTypePage.clickWrongShipment();
//				logger.info("Selected Wrong DC Not In Item problem");
//				dCTCExceptionDetailPage.enterWrongShipmentDetailsRdc( qty, pallet1, pallet2, comments, dcNumber, poNumber);
//				logger.info("Entered exception details for : " + exceptionName);
//				break;
//
//			case "NOP":
//				listViewPage.clickOnCreateTicket();
//				dCTCHomePage.navigateToDeliveryPage();
//				logger.info("Delivery and UPC page displayed");
//				dCTCDeliveryUPCPage.submitDeliveryUPCRdc(deliveryNumber, upcNumber);
//				logger.info("Delivery number entered");
//				logger.info("Scanned UPC Number");
//				dcTcPoLInePage.clickOnPOLineNotFound();
//				logger.info("Selected PO Line not found");
//				dcTcPoLInePage.clickFirstItem();
//				dCTCExceptionTypePage.clickNOP();
//				logger.info("Selected NOP ");
//				dCTCExceptionDetailPage.enterNOPDetailsRdc(qty, pallet1, pallet2, poNumber, dcNumber, comments);
//				logger.info("Entered exception details for : " + exceptionName);
//				break;
//
//			default:
//				logger.info("Problem type not available...");
//			}
//			dCTCExceptionDetailPage.selectPrinter();
//			logger.info("Selected printer");
//			Thread.sleep(6000);
//			dCTCExceptionDetailPage.submitProblem();
//			/*if(exceptionName.equals("NOTWALMARTFREIGHT")) {
//				dCTCExceptionDetailPage.confirmPopUp();
//			}*/
//			String ticketID = dCTCSuccessfulPage.getTikcetID();
//			logger.info("Problem ticket ID : " + ticketID);
//
//			testData.put("ticketID", ticketID);
//			testData.put("Quantity", qty);
//			AppiumHelper.setmapTestData(testData);
//		} catch (AssertionError | FailsafeException e) {
//			throw new TestCaseFailure(e);
//		} catch (Exception e) {
//			throw new AutomationFailure("Failing at problem creation from web app ", e);
//		}
//	}

	@Step
	public void createExceptionWeb(String exceptionName) {
		market = Config.DC.getValue();
		if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("Test flow data before creating problem : {}", testData);
			JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
			poNumber = (String) poNumberArray.get(0);
			JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
			upcNumber = (String) itemUpcArray.get(0);
			JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
			poLine = (String) poLineNumberArray.get(0);
			JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
			deliveryNumber = (String) deliveryArray.get(0);
			logger.info("Creating Problem ticket for : {}", exceptionName);
		}
		else{
			testData = AppiumHelper.getmapTestData();
			poNumber = testData.get("PONumber");
			upcNumber = testData.get("Upc");
			deliveryNumber = testData.get("Delivery");
			poLine = "5";
		}

		String dcNumber = environment.getProperty("dcNumber");
		//String market = Config.DC.getValue();
		System.out.println("The DC number is " + dcNumber);
		String qty = "3";
		String pallet1 = "1";
		String pallet2 = "2";
		String comments = "added comments for e2e testing";
		String receivedVNPK = "5";
		String receivedWHPK = "5";
		String reclaims = "1";
		String destory = "0";
		String sendBackToCarrier = "2";

		logger.info("Creating Problem ticket from web for : {}", exceptionName);

		if (market.equalsIgnoreCase(DC_TYPE.WFS.getValue()) || market.equalsIgnoreCase(DC_TYPE.IMPORTS.getValue())) {
			try {
				listViewPage.clickOnCreateTicket();
				logger.info("Create ticket details page displayed");
				dCTCExceptionDetailPage.enterExceptionDetails(exceptionName, qty, deliveryNumber, poNumber, upcNumber, comments, market);
				Thread.sleep(4000);
				JavascriptExecutor jse = (JavascriptExecutor)getDriver();
				jse.executeScript("window.scrollBy(0,250)");
				dCTCExceptionDetailPage.submitProblem();
				String ticketID = dCTCSuccessfulPage.getTikcetID();
				logger.info("Problem ticket ID : " + ticketID);
				testData.put("POLine", poLine);
				testData.put("ticketID", ticketID);
				testData.put("Quantity", qty);
				AppiumHelper.setmapTestData(testData);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			try {
				listViewPage.clickOnCreateTicket();
				dCTCHomePage.navigateToDeliveryPage();
				logger.info("Delivery and UPC page displayed");
				dCTCDeliveryUPCPage.submitDeliveryUPCWeb(deliveryNumber, upcNumber);
				logger.info("Delivery number entered");
				logger.info("Scanned UPC Number");
				switch (exceptionName.trim()) {

					case "NOTWALMARTFREIGHT":
						dcTcPoLInePage.clickOnPOLineNotFound();
						logger.info("Selected PO Line not found");
						dcTcPoLInePage.clickItemNotFound();
						logger.info("Selected item not found");
						dCTCExceptionTypePage.selectNotWalmartFreight();
						logger.info("Selected Not a Walmart Freight");
						break;

					case "WRONGPACK":
						dcTcPoLInePage.clickFirstPO();
						logger.info("Selected first PO line ");
						dCTCExceptionTypePage.clickWrongPack();
						logger.info("Selected Wrong Pack problem type");
						break;

					case "OVERAGE":
						dcTcPoLInePage.clickFirstPO();
						logger.info("Selected first PO line ");
						dCTCExceptionTypePage.clickOverrage();
						logger.info("Selected Overage problem type");
						break;

					case "DATEISSUE":
						dcTcPoLInePage.clickFirstPO();
						logger.info("Selected first PO line ");
						dCTCExceptionTypePage.clickDateIssue();
						logger.info("Selected Date Issue problem type");
						break;

					case "QUALITYISSUE":
						dcTcPoLInePage.clickFirstPO();
						logger.info("Selected first PO line ");
						dCTCExceptionTypePage.clickQualityIssue();
						logger.info("Selected Date Issue problem type");
						break;

					case "RECALL":
						dcTcPoLInePage.clickFirstPO();
						logger.info("Selected first PO line ");
						dCTCExceptionTypePage.clickRecall();
						logger.info("Selected Recall problem type");
						break;

					case "WRONGDCNOTINITEM":
						dcTcPoLInePage.clickOnPOLineNotFound();
						logger.info("Selected PO Line not found");
						dcTcPoLInePage.clickItemNotFound();
						logger.info("Selected item not found");
						dCTCExceptionTypePage.clickWrongShipment();
						logger.info("Selected Wrong DC Not In Item problem");
						break;

					case "NOP":
						dcTcPoLInePage.clickOnPOLineNotFound();
						logger.info("Selected PO Line not found");
						dcTcPoLInePage.clickFirstItem();
						dCTCExceptionTypePage.clickNOP();
						logger.info("Selected NOP ");
						break;

					default:
						logger.info("Problem type not available...");
				}
				dCTCExceptionDetailPage.enterExceptionDetails(exceptionName,qty,pallet1,pallet2,poNumber,dcNumber,comments,receivedVNPK,receivedWHPK,dcNumber);
				dCTCExceptionDetailPage.selectPrinter();
				logger.info("Selected printer");
				Thread.sleep(6000);
				dCTCExceptionDetailPage.submitProblem();
				String ticketID = dCTCSuccessfulPage.getTikcetID();
				logger.info("Problem ticket ID : " + ticketID);
				Thread.sleep(2000);
				String containerID = getContainerID(ticketID);
				if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
					ProblemDetail problemDetail = new ProblemDetail();
					problemDetail.setProblemTicketNumber(ticketID);
					problemDetail.setproblemQty(qty);
					problemDetail.setproblemContainer(containerID);
					updateTestFlowDataForProblem(problemDetail);
				}
				else{
					testData.put("POLine", poLine);
					testData.put("ticketID", ticketID);
					testData.put("Quantity", qty);
					testData.put("containerID", containerID);
					AppiumHelper.setmapTestData(testData);
				}
	//			getContainerID(ticketID);
				getDriver().close();
			} catch (AssertionError | FailsafeException e) {
				throw new TestCaseFailure(e);
			} catch (Exception e) {
				throw new AutomationFailure("Failing at problem creation from web app ", e);
			}
	}
	}

	@Step
	public void createDisputeExceptionWeb(String exceptionName, String issue_cause) {
		Map<String, String> testData = AppiumHelper.getmapTestData();
		String poNumber = testData.get("PONumber");
		String upcNumber = testData.get("Upc");
		String dcNumber = environment.getProperty("dcNumber");
		System.out.println("The DC number is " + dcNumber);
		String comments = "added comments for e2e testing";
		String qty="3";
		String partnerID = "Part123";
		String salesforceID = "Sale123";
		String poLine = "5";
		testData.put("POLine", poLine);
		logger.info("Creating Problem ticket from web for : {}", exceptionName);
		try{
			listViewPage.clickOnCreateTicket();
			logger.info("Create ticket details page displayed");
			dCTCExceptionDetailPage.enterDisputeExceptionDetails(exceptionName, issue_cause, qty, poNumber, upcNumber, comments, partnerID, salesforceID, dcNumber);
			Thread.sleep(4000);
			dCTCExceptionDetailPage.submitProblem();
			String ticketID = dCTCSuccessfulPage.getTikcetID();
			logger.info("Problem ticket ID : " + ticketID);
			testData.put("ticketID", ticketID);
			testData.put("Quantity", qty);
			AppiumHelper.setmapTestData(testData);
			getDriver().close();
			} catch (AssertionError | FailsafeException e) {
				throw new TestCaseFailure(e);
			} catch (Exception e) {
				throw new AutomationFailure("Failing at problem creation from web app ", e);
			}
		}
	
	@Step
	public void createRdcDamageMobile(String damageName,String market) {

		if(market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("Test flow data before creating problem : {}", testData);
			JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
			poNumber = (String) poNumberArray.get(0);
			JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
			upcNumber = (String) itemUpcArray.get(0);
			JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
			poLine = (String) poLineNumberArray.get(0);
			JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
			deliveryNumber = (String) deliveryArray.get(0);
			logger.info("Creating Damage ticket for : {}", damageName);
		}
		else{
			testData = AppiumHelper.getmapTestData();
			poNumber = testData.get("PONumber");
			upcNumber = testData.get("Upc");
			deliveryNumber = testData.get("Delivery");
			poLine = "5";
		}

//		Map<String,String> testData=AppiumHelper.getmapTestData();
//		String poNumber= testData.get("PONumber");
//		String upcNumber = testData.get("Upc");
//		String deliveryNumber = testData.get("Delivery");
		
		/*String pysicalDmg="3";
		String reclaims="1";
		String consealed="2";*/
		String comments="added comments for e2e testing";
		
		String reclaims="1";
		String destory="0";
		String sendBackToCarrier="2";
		
		logger.info("Creating damage ticket from mobile for : {}", damageName);

		try {
			switch (damageName.trim()) {
			case "PHYSICAL":
			case "CONCEALED":
			case "WET":
				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
				logger.info("Delivery number entered : "+deliveryNumber);
				problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
				logger.info("Scanned UPC Number : "+upcNumber);
				problemPOLinePage.selectPOLine();
				logger.info("Selected PO Line");
				problemExceptionSubTypePage.selectDamage();
				logger.info("Selected Damage");
				problemEnterDetailPage.enterDamageDetailsForPhysicalDamage( reclaims,  destory, sendBackToCarrier, comments,damageName,market);
				logger.info("Entered exception details : "+damageName);
				break;
				
			default:
				logger.info("Damage type not available...");
			}
			problemLabelsPage.reportProblem();
		//	problemLabelsPage.navigateToHomePage();
			String ticketID = problemLabelsPage.getProblemTicketNum();
			logger.info("Damage ticket ID " + damageName + " : " + ticketID);
			problemLabelsPage.navigateToHomePage();
			String containerID = getContainerID(ticketID);
			if(market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
				ProblemDetail problemDetail = new ProblemDetail();
				problemDetail.setProblemTicketNumber(ticketID);
				problemDetail.setproblemContainer(containerID);
				updateTestFlowDataForProblem(problemDetail);
			}
			else{
				testData.put("ticketID", ticketID);
				testData.put("containerID", containerID);
				AppiumHelper.setmapTestData(testData);
			}
//			testData.put("ticketID", ticketID);
//			AppiumHelper.setmapTestData(testData);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at damage creation from mobile app ", e);
		}
	}

	@Step
	public void createDamageMobile(String damageName) {

		Map<String,String> testData=AppiumHelper.getmapTestData();
		String poNumber= testData.get("PONumber");
		String upcNumber = testData.get("Upc");
		String deliveryNumber = testData.get("Delivery");
		String market = Config.DC.getValue();
		String comments="added comments for e2e testing";
		String reclaims="1";
		String destory="0";
		String sendBackToCarrier="2";

		logger.info("Creating damage ticket from mobile for : {}", damageName);

		try {
			switch (damageName.trim()) {
				case "PHYSICAL":
				case "CONCEALED":
				case "WET":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectDamage();
					logger.info("Selected Damage");
					problemEnterDetailPage.enterDamageDetailsForPhysicalDamage(reclaims,destory,sendBackToCarrier,comments,damageName,market);
					logger.info("Entered exception details : "+damageName);
					break;

				default:
					logger.info("Damage type not available...");
			}
			problemLabelsPage.reportProblem();
			String ticketID = problemLabelsPage.getProblemTicketNum();
			logger.info("Damage ticket ID " + damageName + " : " + ticketID);
			problemLabelsPage.navigateToHomePage();
			testData.put("ticketID", ticketID);
			AppiumHelper.setmapTestData(testData);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at damage creation from mobile app ", e);
		}
	}
	
	@Step
	public void createRdcDamageWeb(String damageName) {
		String poNumber="5765978191";
		String upcNumber = "00051596513269";
		//String POLINENUMBER = "";
		String deliveryNumber = "20805727";
		String dcNumber="32818";
		String qty="3";
		String pallet1="1";
		String pallet2="2";
		String comments="added comments for e2e testing";
		
		String reclaims="1";
		String destory="0";
		String sendBackToCarrier="2";
		
		logger.info("Creating damage ticket from mobile for : {}", damageName);

		try {
			switch (damageName.trim()) {
			case "PHYSICAL":
			case "CONCEALED":
			case "WET":
				listViewPage.clickOnCreateTicket();
				dCTCHomePage.navigateToDeliveryPage();
				logger.info("Delivery and UPC page displayed");
				dCTCDeliveryUPCPage.submitDeliveryUPCWeb(deliveryNumber, upcNumber);
				logger.info("Delivery number entered");
				logger.info("Scanned UPC Number");
				dcTcPoLInePage.clickFirstPO();
				logger.info("Selected first PO line ");
				
				dCTCExceptionTypePage.clickDamage();
				logger.info("Selected Damage");
				
				dCTCExceptionDetailPage.enterDamageDetailsRdc( reclaims,  destory, sendBackToCarrier, comments, damageName);
				logger.info("Entered damage details for : " + damageName);
				break;
				
			default:
				logger.info("Damage type not available...");
			}
			dCTCExceptionDetailPage.selectPrinter();
			logger.info("Selected printer");
			Thread.sleep(6000);
			dCTCExceptionDetailPage.submitProbleUsingAction();
			String ticketID = dCTCSuccessfulPage.getTikcetID();
			logger.info("Problem ticket ID : " + ticketID);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at damage creation from web app ", e);
		}
	}

	@Step
	public void createDamageWeb(String damageName) {
		market = Config.DC.getValue();
		if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("Test flow data before creating problem : {}", testData);
			JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
			poNumber = (String) poNumberArray.get(0);
			JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
			upcNumber = (String) itemUpcArray.get(0);
			JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
			poLine = (String) poLineNumberArray.get(0);
			JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
			deliveryNumber = (String) deliveryArray.get(0);
			logger.info("Creating Damage ticket for : {}", damageName);
		}
		else{
			testData = AppiumHelper.getmapTestData();
			poNumber = testData.get("PONumber");
			upcNumber = testData.get("Upc");
			deliveryNumber = testData.get("Delivery");
			poLine = "5";
		}

//		Map<String,String> testData=AppiumHelper.getmapTestData();
//		String poNumber= testData.get("PONumber");
//		String upcNumber = testData.get("Upc");
//		String deliveryNumber = testData.get("Delivery");
		String dcNumber=environment.getProperty("dcNumber");
		String qty="3";
		String pallet1="1";
		String pallet2="2";
		String comments="added comments for e2e testing";
		//String poLine="5";
		String reclaims="1";
		String destory="0";
		String sendBackToCarrier="2";
		//testData.put("POLine",poLine);


		logger.info("Creating damage ticket for : {}", damageName);

		try {
			switch (damageName.trim()) {
				case "PHYSICAL":
				case "CONCEALED":
				case "WET":
					listViewPage.clickOnCreateTicket();
					dCTCHomePage.navigateToDeliveryPage();
					logger.info("Delivery and UPC page displayed");
					dCTCDeliveryUPCPage.submitDeliveryUPCWeb(deliveryNumber, upcNumber);
					logger.info("Delivery number entered");
					logger.info("Scanned UPC Number");
					dcTcPoLInePage.clickFirstPO();
					logger.info("Selected first PO line ");

					dCTCExceptionTypePage.clickDamage();
					logger.info("Selected Damage");

					dCTCExceptionDetailPage.enterDamageDetailsRdc( reclaims,  destory, sendBackToCarrier, comments, damageName);
					logger.info("Entered damage details for : " + damageName);
					break;

				default:
					logger.info("Damage type not available...");
			}
			dCTCExceptionDetailPage.selectPrinter();
			logger.info("Selected printer");
			Thread.sleep(6000);
			dCTCExceptionDetailPage.submitProbleUsingAction();
			String ticketID = dCTCSuccessfulPage.getTikcetID();
			logger.info("Problem ticket ID : " + ticketID);
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				ProblemDetail problemDetail = new ProblemDetail();
				problemDetail.setProblemTicketNumber(ticketID);
				problemDetail.setproblemQty(qty);
				updateTestFlowDataForProblem(problemDetail);
			}
			else{
				testData.put("POLine", poLine);
				testData.put("ticketID", ticketID);
				testData.put("Quantity", qty);
				AppiumHelper.setmapTestData(testData);
			}

//			testData.put("ticketID", ticketID);
//			testData.put("Quantity", qty);
			AppiumHelper.setmapTestData(testData);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at damage creation from web app ", e);
		}
	}
	
	@Step
	public void createGdcExceptionMobile(String exceptionName,String market) {
		if(market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			logger.info("Test flow data before creating problem : {}", testData);
			JSONArray poNumberArray = JsonPath.read(testData, "$..poDetails..poNumber");
			poNumber = (String) poNumberArray.get(0);
			JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
			upcNumber = (String) itemUpcArray.get(0);
			JSONArray poLineNumberArray = JsonPath.read(testData, "$..poDetails..poLineNumber");
			poLine = (String) poLineNumberArray.get(0);
			JSONArray deliveryArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
			deliveryNumber = (String) deliveryArray.get(0);
			logger.info("Creating Problem ticket for : {}", exceptionName);
		}
		else{
			testData = AppiumHelper.getmapTestData();
			poNumber = testData.get("PONumber");
			upcNumber = testData.get("Upc");
			deliveryNumber = testData.get("Delivery");
			poLine = "5";
		}

//		Map<String,String> testData=AppiumHelper.getmapTestData();
//		String poNumber= testData.get("PONumber");
//		String upcNumber = testData.get("Upc");
//		String deliveryNumber = testData.get("Delivery");
		
		//String poNumber="70102069";
		//String upcNumber = "1085662400413";
		//String POLINENUMBER = "";
		//String deliveryNumber = "999000090";
		String dcNumber=environment.getProperty("dcNumber");
		String qty="10";
		String pallet1="5";
		String pallet2="5";
		String comments="added comments for e2e testing";
		String receivedVNPK="5";
		String receivedWHPK="5";
		logger.info("Creating Problem ticket from mobile for : {}", exceptionName);
		
		try {
			switch (exceptionName.trim()) {
			
			case "NOTWALMARTFREIGHT":
				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
				logger.info("Delivery number entered : "+deliveryNumber);
				problemScanPage.scanUPCForNotWalmartFreight("987654321");
				logger.info("Scanned UPC Number : "+"987654321");
				if(market.equals("gdc"))
					problemScanPage.clickContinue();
				problemExceptionSubTypePage.selectnotWalmartFreight();
				logger.info("Selected NWF exception");
				problemEnterDetailPage.enterExceptionDetailsForNotWalmartFreightRdc(qty, pallet1, pallet2,comments,dcNumber,poNumber);
				logger.info("Entered exception details : "+exceptionName);
				break;

			case "WRONGPACK":
			case "OVERAGE":
			case "QUALITYISSUE":
			case "DATEISSUE":
			case "QUALITYISSUEPLU":
			case "RECALL":
			case "HAZMAT":
				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
				logger.info("Delivery number entered : "+deliveryNumber);
				if(exceptionName.equals("QUALITYISSUEPLU")) {
					problemScanPage.clickPLU();
				}
				problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
				logger.info("Scanned UPC Number : "+upcNumber);
				problemPOLinePage.selectPOLine();
				logger.info("Selected PO Line");
				
				if(exceptionName.equals("WRONGPACK")) {
					problemExceptionSubTypePage.selectWrongPack();
					logger.info("Selected Wrong Pack exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}else if(exceptionName.equals("OVERAGE")) {
					problemExceptionSubTypePage.selectOverrage();
					logger.info("Selected Overage exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}else if(exceptionName.equals("QUALITYISSUE")) {
					problemExceptionSubTypePage.selectQualityIssue();
					logger.info("Selected Quality exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}else if(exceptionName.equals("DATEISSUE")) {
					problemExceptionSubTypePage.selectDateIssue();
					logger.info("Selected Date exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}else if(exceptionName.equals("QUALITYISSUEPLU")) {
					problemExceptionSubTypePage.selectQualityIssue();
					logger.info("Selected Quality exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}else if(exceptionName.equals("RECALL")) {
					problemExceptionSubTypePage.selectRecall();
					logger.info("Selected Date exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}else if(exceptionName.equals("HAZMAT")) {
					problemExceptionSubTypePage.selectHazmat();
					logger.info("Selected Date exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
				}
				logger.info("Entered exception details : "+exceptionName);
				break;
				
			case "WRONGDCNOTINPO":
				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
				logger.info("Delivery number entered : "+deliveryNumber);
				problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
				logger.info("Scanned UPC Number : "+upcNumber);
				
				problemPOLinePage.navigateToSelectNWF();
//				logger.info("Select item not in list");
//				problemSelectItemPage.navigateToNOP();
				problemExceptionSubTypePage.selectwrongDC();
				logger.info("Selected wrong dc");
				
				problemEnterDetailPage.enterExceptionDetailsForWrongDCRdc(qty, pallet1, pallet2,comments,dcNumber,poNumber);
				logger.info("Entered exception details : "+exceptionName);
				break;

			case "NOTONPO":
				problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
				logger.info("Delivery number entered : "+deliveryNumber);
				problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
				logger.info("Scanned UPC Number : "+upcNumber);
				problemPOLinePage.navigateToSelectNWF();
//				problemScanPage.selectPOListing();
//				problemPOLinePage.skipPOSelection();
				problemExceptionSubTypePage.selectNotOnPO();
				logger.info("Selected NOP Exception");
				problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
				logger.info("Entered exception details : "+exceptionName);
				break;
			default:
				logger.info("Problem type not available...");
			}
			problemLabelsPage.reportProblem();
		//	problemLabelsPage.navigateToHomePage();
			String ticketID = problemLabelsPage.getProblemTicketNum();
			logger.info("Problem ticket ID : " + ticketID);
			problemLabelsPage.navigateToHomePage();
			
//			String containerId=getContainerID(ticketID);
//			fixitMobileHomePage.scanProblemTicket(containerId);
			String containerID = getContainerID(ticketID);
			if(market.equalsIgnoreCase(DC_TYPE.MCC.getValue())){
				ProblemDetail problemDetail = new ProblemDetail();
				problemDetail.setProblemTicketNumber(ticketID);
				problemDetail.setproblemQty(qty);
				problemDetail.setproblemContainer(containerID);
				updateTestFlowDataForProblem(problemDetail);
			}
			else{
				testData.put("POLine", poLine);
				testData.put("ticketID", ticketID);
				testData.put("Quantity", qty);
				testData.put("containerID", containerID);
				AppiumHelper.setmapTestData(testData);
			}


//			testData.put("ticketID", ticketID);
//			testData.put("Quantity", qty);
//
//			AppiumHelper.setmapTestData(testData);
			AndroidDriver<AndroidElement> driver = (AndroidDriver<AndroidElement>)
					((WebDriverFacade) getDriver()).getProxiedDriver();
			driver.closeApp();

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at problem creation from mobile app ", e);
		}
	}

	@Step
	public void createExceptionMobile(String exceptionName, String subtype) {
		Map<String,String> testData=AppiumHelper.getmapTestData();
		String poNumber= testData.get("PONumber");
		String upcNumber = testData.get("Upc");
		String deliveryNumber = testData.get("Delivery");
		String market = Config.DC.getValue();
		String dcNumber=environment.getProperty("dcNumber");
		String qty="10";
		String pallet1="5";
		String pallet2="5";
		String comments="added comments for e2e testing";
		String receivedVNPK="5";
		String receivedWHPK="5";
		String poLine = "5";
		testData.put("POLine", poLine);
		logger.info("Creating Problem ticket from mobile for : {}", exceptionName);

		try {
			switch (exceptionName.trim()) {

				case "NOTWALMARTFREIGHT":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight("987654321");
					logger.info("Scanned UPC Number : "+"987654321");
					if(market.equalsIgnoreCase(DC_TYPE.GDC.getValue()))
						problemScanPage.clickContinue();
					problemExceptionSubTypePage.selectnotWalmartFreight();
					logger.info("Selected NWF exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "NOTONPO":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPC(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.navigateToSelectNWF();
					problemExceptionSubTypePage.selectNotOnPO();
					problemExceptionSubTypePage.selectSubType(subtype);
					logger.info("Selected NOP Exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "WRONGPACK":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectWrongPack();
					problemExceptionSubTypePage.selectSubType(subtype);
					logger.info("Selected Wrong Pack exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "OVERAGE":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectOverrage();
					problemExceptionSubTypePage.selectSubType(subtype);
					logger.info("Selected Overage exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "QUALITYISSUE":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectQualityIssue();
					logger.info("Selected Quality exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "DATEISSUE":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectDateIssue();
					problemExceptionSubTypePage.selectSubType(subtype);
					logger.info("Selected Date exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "QUALITYISSUEPLU":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					if(exceptionName.equals("QUALITYISSUEPLU")) {
						problemScanPage.clickPLU();
					}
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectQualityIssue();
					logger.info("Selected Quality exception");
					problemEnterDetailPage.enterExceptionDetailsForWrongPackRdc(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "RECALL":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectRecall();
					logger.info("Selected Recall exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "SUSPECT":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemExceptionSubTypePage.selectSuspect();
					logger.info("Selected Suspect exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "NOLABEL":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.clickASN();
					problemScanPage.scanSSCC(upcNumber);
//					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
//					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.selectPOLine();
					logger.info("Selected PO Line");
					problemScanPage.clickNext();
					problemExceptionSubTypePage.selectNoLabel();
					logger.info("Selected No Label exception");
					problemExceptionSubTypePage.selectSubType(subtype);
					logger.info("Selected Missing all label sub type");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "WRONGDC":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.scanUPCForNotWalmartFreight(upcNumber);
					logger.info("Scanned UPC Number : "+upcNumber);
					problemPOLinePage.navigateToSelectNWF();
					problemExceptionSubTypePage.selectwrongDC();
					logger.info("Selected wrong dc");
					problemExceptionSubTypePage.selectSubType(subtype);
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				case "ASNNOTDOWNLOADED":
					problemDeliveryNumberPage.enterDeliveryManifestNumber(deliveryNumber);
					logger.info("Delivery number entered : "+deliveryNumber);
					problemScanPage.clickASN();
					problemScanPage.scanSSCC(upcNumber);
					logger.info("Scanned SSCC Number : "+upcNumber);
					problemScanPage.clickContinue();
					problemScanPage.addSSCC();
					problemExceptionSubTypePage.selectAsnNotDownloaded();
					logger.info("Selected ASN not downloaded exception");
					problemEnterDetailPage.enterExceptionDetails(qty, pallet1, pallet2,comments,receivedVNPK,receivedWHPK,exceptionName, poNumber, dcNumber, market);
					logger.info("Entered exception details : "+exceptionName);
					break;

				default:
					logger.info("Problem type not available...");
			}
			problemLabelsPage.reportProblem();
			//	problemLabelsPage.navigateToHomePage();
			String ticketID = problemLabelsPage.getProblemTicketNum();
			logger.info("Problem ticket ID : " + ticketID);
			problemLabelsPage.navigateToHomePage();

//			String containerId=getContainerID(ticketID);
//			fixitMobileHomePage.scanProblemTicket(containerId);

			testData.put("ticketID", ticketID);
			testData.put("Quantity", qty);

			AppiumHelper.setmapTestData(testData);

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at problem creation from mobile app ", e);
		}
	}
	
	@Step
	public void loginIntoMyApp(String dc) {
		problemDeliveryNumberPage.loginIntoMyapp(dc,"user1","pass1");
		logger.info("Logged in into MyApp successfully");
	}
	
	@Step
	public void readTestData(String delivery,String upc,String ponumber) {
		Map<String,String> testData=new HashMap<String,String>();
		testData.put("Delivery", delivery);
		logger.info("Delivery number : {}",delivery);
		testData.put("Upc", upc);
		logger.info("Upc : {}",upc);
		testData.put("PONumber", ponumber);
		logger.info("PO number : {}",ponumber);
		AppiumHelper.setmapTestData(testData);
	}
	
	@Step
	public void assignToHO() {
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			listViewPage.searchTicket(ticketNumber);
			logger.info("Searching problem ticket");
			listViewPage.clickOnFirstTicket();
			logger.info("Clicking on ticket");
			//ticketDetailPage.editTicket();//for overge required this step
			Thread.sleep(2000);
			ticketDetailPage.assignToHo();
			logger.info("Assigned to HO user");
			Thread.sleep(2000);
			getDriver().close();
		}catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Assign to HO is failing in web : ", e);
		}
	}

	@Step
	public void assignToWfsProgram() {
		try {
			Map<String,String> testData=AppiumHelper.getmapTestData();
			String ticketNumber = testData.get("ticketID");
			listViewPage.searchTicket(ticketNumber);
			logger.info("Searching problem ticket");
			listViewPage.selectAssignmentGroup("SELLER_SUPPORT");
			listViewPage.clickOnFirstTicket();
			logger.info("Clicking on ticket");
			Thread.sleep(2000);
			ticketDetailPage.assignToWfsProgram();
			logger.info("Assigned to HO user");
			Thread.sleep(2000);
			getDriver().close();
		}catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Assign to HO is failing in web : ", e);
		}
	}
	
	private List getTicketStatus() {
		List status=new ArrayList();
		status.add("Ready to Receive");
		status.add("Answered");
		return status;
	}

	public void launchFixitThruNextGenMyApps(String dcType) {
		
		if(dcType.equalsIgnoreCase("Pharmacy"))
			dcType="32899";
		else if(dcType.equalsIgnoreCase("MCC"))
			dcType="32899";
		else if(dcType.equalsIgnoreCase("GDC"))
			dcType="32821";
		else if(dcType.equalsIgnoreCase("RDC"))
			dcType="32818";
		else if(dcType.equalsIgnoreCase("ACC"))
			dcType="32898";
		
		try {
			problemDeliveryNumberPage.loginNextGenMyapps(environment.getProperty("nextGenUserName"),
					environment.getProperty("nextGen"),
					dcType);
			problemDeliveryNumberPage.launchFIXitApp();

		} catch (Exception e) {
			problemDeliveryNumberPage.launchFIXitApp();
		}
	}

	public void appSwitchFixitToReceiving() {
		try {
			problemDeliveryNumberPage.appSwitchFixitToReceiving();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at logging out from fixit application : ", e);
		}
	}

	public void logoutMyApps(){
		AndroidDriver<AndroidElement> driver = (AndroidDriver<AndroidElement>) ((WebDriverFacade) getDriver()).getProxiedDriver();
		driver.launchApp();
        problemDeliveryNumberPage.logoutMyApps();
	}

	@Step
	public void reprintLabelMobile(){
		try {
			String ticketID, upcNumber;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				logger.info("testFlowData before Assigning to HO :: {}", testData);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketID = (String) poNumberArray.get(0);
				JSONArray itemUpcArray = JsonPath.read(testData, "$..poDetails..itemUpc");
				upcNumber = (String) itemUpcArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketID = testData.get("ticketID");
				upcNumber = testData.get("Upc");
			}

			fixitMobileHomePage.navigateToReprintLabel();
			problemScanPage.scanUPCForReprint(upcNumber);
			problemScanPage.scanTicketForReprint(ticketID);
			fixitMobileHomePage.reprintLabel();
			problemLabelsPage.selectPrinter();
			logger.info("Reprinted Label");

		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with DC assigns problem ticket to HO	", e);
		}

	}
	
	@Step
	public void verifyGroup(String group) {
		try {
			Map<String,String> testData=AppiumHelper.getmapTestData();
			String ticketNumber = testData.get("ticketID");
			if(group.equals("Home Office")) {
				listViewPage.searchTicket(ticketNumber);
				logger.info("Searching problem ticket");
				listViewPage.clickOnFirstTicket();
				logger.info("Clicking on ticket");
			}else if(group.equals("Replenishment")) {
				//ticketDetailPage.clickBackLink();
			}else if(group.equals("DC/FC")) {
				getDriver().navigate().to(environment.getProperty("fixit_tracker_web_url"));
				loginPage.selectDc("32818");
				listViewPage.searchTicket(ticketNumber);
				logger.info("Searching problem ticket");
				listViewPage.clickOnFirstTicket();
				logger.info("Clicking on ticket");
			}
			Failsafe.with(retryPolicy).run(() -> {
				Thread.sleep(4000);
				String groupName=ticketDetailPage.getAssignedGroup().trim();
				logger.info("Problem ticket assigned group Actual : {} & Expected : {} ",groupName,group);
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_GROUP_MISMATCH,
						groupName.equals(group.trim()));
				if(group.equals("DC")) {
					getDriver().quit();
				}
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at verifying Assigned Group : ", e);
		}
	}
	
	@Step
	public void assignToReplenishment(String groupName) {
		if(groupName.equals("Replenishment")) {
			ticketDetailPage.assignToReplenishment();
		}else if(groupName.equals("DC")) {
			ticketDetailPage.assignToDC();
		}
		logger.info("Problem ticket assigned to {} group",groupName);
	}
	
	@Step
	public void addBulkResolution() {
		try {
			String deliveryNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue())){
				JSONArray deliveryNumberArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
				deliveryNumber = (String) deliveryNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				deliveryNumber = testData.get("Delivery");
			}
			listViewPage.searchTicketByDelivery(deliveryNumber);
			listViewPage.selectTicketStatus("ASSIGNED");
			listViewPage.selectMultipleTickets();
			listViewPage.clickResolution();
			Thread.sleep(2000);
			List<String> ticketsList=listViewPage.getTicketList();
			Thread.sleep(1000);
			AppiumHelper.setListTestData(ticketsList);
			resolutionPage.addBulkResolution("Destroy", "1234", "12.13", "122.22", market);
			Thread.sleep(3000);
			getDriver().close();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at bulk resolution : ", e);
		}
	}

	@Step
	public void addBulkComment() {
		try {
			String deliveryNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue())){
				JSONArray deliveryNumberArray = JsonPath.read(testData, "$..deliveryDetails..deliveryNumber");
				deliveryNumber = (String) deliveryNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				deliveryNumber = testData.get("Delivery");
			}
			listViewPage.searchTicketByDelivery(deliveryNumber);
			listViewPage.selectTicketStatus("ASSIGNED");
			listViewPage.selectMultipleTickets();
			listViewPage.clickComment();
			Thread.sleep(2000);
			List<String> ticketsList=listViewPage.getTicketList();
			Thread.sleep(1000);
			AppiumHelper.setListTestData(ticketsList);
			resolutionPage.addBulkComment();
			Thread.sleep(3000);
			getDriver().close();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at bulk resolution : ", e);
		}
	}




	@Step
	public void verifyBulkResolution(String resolution) {
		try {
			List<String> tickets=AppiumHelper.getListTestData();
			for (int i = 0; i < tickets.size(); i++) {
				String ticketNumber=tickets.get(i).trim();
				listViewPage.searchTicket(ticketNumber);
				logger.info("Searching problem ticket : {} ",ticketNumber);
				listViewPage.clickOnFirstTicket();
				logger.info("Clicking on ticket");
				Thread.sleep(4000);
				logger.info("Problem ticket status actual : {} & expected : Solution Available",ticketDetailPage.getTicketStatus().trim());
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
						ticketDetailPage.getTicketStatus().trim().equals("Solution Available"));
				logger.info("Problem ticket resolution name actual : {} & expected : {}",resolutionPage.getResolutionText().trim(),getResolutionName(resolution).trim());
				Assert.assertTrue(ErrorCodes.FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH,
						resolutionPage.getResolutionText().trim().equals(getResolutionName(resolution).trim()));
				logger.info("Problem ticket status and resolution name validated");
				ticketDetailPage.goBackToListView();
				Thread.sleep(1000);
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at verifying bulk resolution : ", e);
		}
	}
	
	@Step
	public void logoutFixit() {
		try {
			listViewPage.closeBrowser();
			//listViewPage.logout();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at logging out from fixit application : ", e);
		}
	}
	
	@Step
	public void reassignTicket() {
		try {
			Map<String,String> testData=AppiumHelper.getmapTestData();
			String ticketNumber = testData.get("ticketID");
			listViewPage.searchTicket(ticketNumber);
			logger.info("Searching problem ticket");
			listViewPage.clickOnFirstTicket();
			logger.info("Clicking on ticket");
			ticketDetailPage.clickReAssign();
			ticketDetailPage.clickAssign();
			logger.info("Problem ticket Re-Assigned to HO");
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at Re-Assign ticket : ", e);
		}
	}
	
	@Step
	public void verifyStatus(String expectedStatus) {
		try {
			Failsafe.with(retryPolicy).run(() -> {
				Thread.sleep(1000);
				String actualStatus=ticketDetailPage.getTicketStatus().trim();
				logger.info("Problem ticket status actual : {} & expected : {} ",actualStatus,expectedStatus);
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
						actualStatus.equals(expectedStatus.trim()));

			});
			ticketDetailPage.goBackToListView();
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at verifying Problem ticket status : ", e);
		}
	}
	
	@Step
	public void verifyDamageTicketStatus(String expectedStatus,String expectedClaimStatus) {
		try {
			Map<String,String> testData=AppiumHelper.getmapTestData();
			String claimId= testData.get("ClaimId");
			Failsafe.with(retryPolicy).run(() -> {
				Thread.sleep(1000);
				listViewPage.navigateToReceivingDamage();
				Thread.sleep(2000);
				listViewPage.searchDamageTicketByCliamID(claimId);
				Thread.sleep(2000);
				listViewPage.clickOnFirstTicket();
				Thread.sleep(4000);
				String actualStatus=ticketDetailPage.getReceivingDmgTicketStatus().trim();
				String actualClaimStatus=ticketDetailPage.getClaimStatus().trim();
				logger.info("Damage ticket status actual : {} & expected : {} ",actualStatus,expectedStatus);
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
						actualStatus.equals(expectedStatus.trim()));
				logger.info("Damage claim status actual : {} & expected : {} ",actualClaimStatus,expectedClaimStatus);
				Assert.assertTrue(ErrorCodes.FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH,
						actualClaimStatus.equals(expectedClaimStatus.trim()));
			});
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Failing at verifying damage ticket status : ", e);
		}
	}

	@Step
	public void moreInfo(){
		try {
			String ticketNumber, market;
			market = Config.DC.getValue();
			if(market.equalsIgnoreCase(DC_TYPE.ATLAS.getValue()) || market.equalsIgnoreCase(DC_TYPE.ACC.getValue())){
				String testData = (String) tl.get().get(TEST_FLOW_DATA);
				JSONArray poNumberArray = JsonPath.read(testData, "$..problemDetails..problemTicketNumber");
				ticketNumber = (String) poNumberArray.get(0);
			}
			else{
				testData=AppiumHelper.getmapTestData();
				ticketNumber = testData.get("ticketID");
			}
			listViewPage.searchTicket(ticketNumber);
			logger.info("Searching problem ticket");
			listViewPage.clickOnFirstTicket();
			logger.info("Clicking on ticket");
			ticketDetailPage.getMoreInfo();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	@Step
	public void exportData(){
		listViewPage.exportData();

	}

	@Step
	public void verifyMetricsDashboard(String presence){
		try {
			listViewPage.verifyMetricsDashboard(presence);
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong with creating problem ticket", e);
		}

	}

	private Headers getGFCSHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header source = new Header("WMT-Source", "FIXIT");
		Header channel = new Header("WMT-Channel", "WEB");
		Header exceptionCategory = new Header("WMT-ExceptionCategory", "DAMAGE");
		Header exceptiontype = new Header("WMT-ExceptionType", "RECDMG");

		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(source);
		headerList.add(channel);
		headerList.add(exceptionCategory);
		headerList.add(exceptiontype);
		return new Headers(headerList);
	}

	public int getDamage(String deliveryNumber, String poNumber, String damageLocation) {
		Response getDamageQty;
		int cpDamageQty = 0;
		int rdcDamageQty = 0;

		List<Integer> damage;
		getDamageQty = SerenityRest.given().contentType("application/json").relaxedHTTPSValidation()
				.headers(getGFCSHeaders()).when().get(environment.getProperty("get_damage_qty"), deliveryNumber);
		if (damageLocation.equalsIgnoreCase("CP")) {
			damage = JsonPath.read(getDamageQty.asString(), javaUtils.format(CP_DAMAGE_QTY_JSON_PATH, poNumber));

			for (int damageQty : damage) {
				cpDamageQty = cpDamageQty + damageQty;
			}
			logger.info(cpDamageQty + " ::  CP Damage Qty for PO " + poNumber);
			return cpDamageQty;
		} else {
			damage = JsonPath.read(getDamageQty.asString(), javaUtils.format(RDC_DAMAGE_QTY_JSON_PATH, poNumber));

			for (int damageQty : damage) {
				rdcDamageQty = rdcDamageQty + damageQty;
			}
			logger.info(rdcDamageQty + " ::  RDC Damage Qty for PO " + poNumber);
			return rdcDamageQty;
		}
	}

	@Step
	public void createDamage(String damageLocation) {
		String testFlowData;
		try {

			testFlowData = String.valueOf(tl.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			poNumberList = parsedJson.read(LIST_OF_PO_NUMBERS_JSON_PATH);
			for (String poNumber : poNumberList) {
				List<String> poLineNumbers = parsedJson.read(javaUtils.format(PO_LINE_NUMBERS_JSON_PATH, poNumber));
				for (String poLineNumber : poLineNumbers) {
					JSONArray deliveryArray = JsonPath.read(testFlowData, DELIVERY_NUMBERS_JSON_PATH);
					String deliveryNumber = (String) deliveryArray.get(0);
					JSONArray itemArray = parsedJson.read(javaUtils.format(ITEM_NUMBERS_JSON_PATH, poNumber));
					String itemNum = (String) itemArray.get(0);
					List<String> itemUpcArray = parsedJson
							.read(javaUtils.format(ITEM_UPC_JSON_PATH, poNumber, itemNum));
					String upcnumber = (String) itemUpcArray.get(0);
					Response createDamageResponse = null;
					logger.info("PO Number :: " + poNumber + " PO Line number :: " + poLineNumber + " UPC Number:: "
							+ upcnumber + "  Item Number :: " + itemNum + " Damage location ::" + damageLocation);
					String body = textParser.readTextFile(FileNames.GFCS_DAMAGE_CREATION_TEMPLATE_FILE);
					body = format(body, itemNum, upcnumber, deliveryNumber, poNumber, poLineNumber);
					RequestSpecBuilder reqSpecBuilder = new RequestSpecBuilder();
					reqSpecBuilder.setContentType("application/json; charset=UTF-8");
					reqSpecBuilder.setBody(body);
					createDamageResponse = SerenityRest.given().contentType("application/json").relaxedHTTPSValidation()
							.headers(getGFCSHeaders()).body(body.toString()).when()
							.post(environment.getProperty("create_damage"));
					logger.info("Create damage response is ::: " + createDamageResponse.getBody().asString());
					Assert.assertEquals(ErrorCodes.GFCS_CREATE_DAMAGE_STATUS_CODE_MISMATCH, 200,
							createDamageResponse.getStatusCode());
					int damageQty = getDamage(deliveryNumber, poNumber, damageLocation);
					ObjectMapper objectMapper = new ObjectMapper();
					JSONArray listOfPoLineDetail = parsedJson
							.read(javaUtils.format(PO_LINE_DETAILS_JSON_PATH, poNumber));
					String poLineDetailsJson = objectMapper.writeValueAsString(listOfPoLineDetail);
					List<PoLineDetail> poLineDetailList = (List<PoLineDetail>) jsonUtil
							.getPojoListfromPath(poLineDetailsJson, PoLineDetail.class);
					for (PoLineDetail poLineDetail : poLineDetailList) {
						if (poLineDetail.getPoLineNumber().equals(poLineNumber)) {
							poLineDetail.setDamageQty(String.valueOf(damageQty).trim());
						}
					}
					net.minidev.json.JSONArray listofPoLineJson = jsonUtil.converyListToJsonArray(poLineDetailList);
					testFlowData = jsonUtil.setJsonAtJsonPath(testFlowData, listofPoLineJson,
							javaUtils.format(ALL_PO_LINE_DETAILS_JSON_PATH, poNumber));
					tl.get().put("testFlowData", testFlowData);
					logger.info("Testflowdata after upadting damage quantity {} ", testFlowData);
				}
			}

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while creating damage", e);
		}
	}

}
