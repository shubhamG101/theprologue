package com.walmart.supplychain.thor.DCFIN.steps;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.thor.WAC;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.acc.acl.db.ACCMongoSteps;
import com.walmart.supplychain.thor.podetails.steps.webservices.ThorHelper;

import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class DCFINSteps {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	private static final double DELTA = 0.001;
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";

	private static final String RECEIVING_STATION = "R1";
	List itemLabelList = null;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired(required = true)
	ThorHelper thorHelper;

	@Autowired
	Environment environment;

	Response response;

	@Autowired
	JavaUtils javaUtil;

	ObjectMapper om = new ObjectMapper();

	private static final String GET_POLINES = "$.testFlowData.poDetails[*].poLineDetails[*]";
	private static final String GET_WAC_EP = "get_wac_url";
	private static final String BASE_DIV_CODE = "WM";
	private static final String FINANCIAL_REPORTING_GROUP_CODE = "US";
	private static final String BALANCEONHAND = "$.foundItemsCostDetail[*].balanceOnHandQuantity";
	private static final String WAREHOUSECOST = "$.foundItemsCostDetail[*].weightedAverageCost";

	@Step
	public void validateWavandBOH() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfPoLines = JsonPath.read(testData, GET_POLINES);
			String poLineString = listOfPoLines.toJSONString();
			List<PoLineDetail> poLineList = objectMapper.readValue(poLineString,
					new TypeReference<List<PoLineDetail>>() {
					});

			for (PoLineDetail poLineDetail : poLineList) {
				String item = poLineDetail.getItemNumber();
				WAC wac = new WAC();
				List wacList = new ArrayList();
				wac.setBaseDivCode(BASE_DIV_CODE);
				wac.setFinancialReportingGroupCode(FINANCIAL_REPORTING_GROUP_CODE);
				wac.setItemNumber(item);
				wacList.add(wac);
				logger.info("wac body:" + om.writeValueAsString(wacList));
				logger.info("wac url:" + environment.getProperty(GET_WAC_EP));
				Failsafe.with(retryPolicy).run(() -> {
					response = given().relaxedHTTPSValidation().headers(thorHelper.getDCFINHeaders())
							.body(om.writeValueAsString(wacList)).when().post(environment.getProperty(GET_WAC_EP));
					Assert.assertEquals(ErrorCodes.THOR_WAC_RECEIVING, Constants.SUCESS_STATUS_CODE,
							response.getStatusCode());
					logger.info(response.asString());

					JSONArray bohArray = JsonPath.read(response.asString(), BALANCEONHAND);
					String bohString = bohArray.toJSONString();
					List<String> bohList = objectMapper.readValue(bohString, new TypeReference<List<String>>() {
					});

					JSONArray wacArray = JsonPath.read(response.asString(), WAREHOUSECOST);
					String wacString = wacArray.toJSONString();
					List<String> wacListDB = objectMapper.readValue(wacString, new TypeReference<List<String>>() {
					});
					String boh = bohList.get(0);
					String wacDB = wacListDB.get(0);

					// DecimalFormat round = new DecimalFormat("0.00"); //Make new decimal format
					Assert.assertEquals(ErrorCodes.THOR_BOH_RECEIVING, poLineDetail.getBoh(), Integer.parseInt(boh));
					Assert.assertEquals(ErrorCodes.THOR_WAC_RECEIVING, poLineDetail.getWac(),
							Double.parseDouble(wacDB),DELTA);
				});
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to Validate WAC and BOH", e);
		}

	}

}