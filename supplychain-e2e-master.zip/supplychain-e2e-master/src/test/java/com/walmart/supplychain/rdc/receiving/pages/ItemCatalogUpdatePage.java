package com.walmart.supplychain.rdc.receiving.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import net.jodah.failsafe.RetryPolicy;

public class ItemCatalogUpdatePage extends SerenityHelper {

	WebDriver driver;
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(20, 10);// 15 times with a delay of 10s

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/tv_newGtinValue']")
	private WebElement newGTINTxt;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/tv_itemNumberValue']")
	private WebElement itemTxt;

	@FindBy(xpath = ".//*[@resource-id='com.walmart.move.nim.receiving.mobile:id/btn_primaryAction']")
	private WebElement updateBtn;

	public String getupdatedGTIN() {

		element(newGTINTxt).waitUntilVisible();
		return element(newGTINTxt).getText();
	}

	public String getItem() {

		element(itemTxt).waitUntilVisible();
		return element(itemTxt).getText();
	}

	public void clickUpdate() {

		element(updateBtn).waitUntilVisible();
		element(updateBtn).click();
	}
}
