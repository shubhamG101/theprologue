package com.walmart.supplychain.nextgen.oms.scenariosteps.webservices;

import static com.jayway.jsonpath.JsonPath.parse;
import static com.jayway.jsonpath.JsonPath.read;

import java.io.File;
import java.io.IOException;
import java.util.*;

import com.jayway.jsonpath.PathNotFoundException;
import com.walmart.framework.utilities.parsing.TextParser;
import org.apache.commons.lang3.ArrayUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.CHANNELS;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowData;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.TestFlowDataMain;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = SpringTestConfiguration.class)
public class OmsSteps {
	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	JsonUtils jsonUtils;

	@Autowired
	TextParser textParser;

	private static final Logger LOGGER = LoggerFactory.getLogger(OmsSteps.class);

	private final int ZERO = 0;
	private final int ONE = 1;
	private double ACCEPTED_OVERAGE_PRICE_THRESHOLD = 499.99d;
	private static final String PO_GET_ENTITY = "$.testFlowData.poDetails[*]";
	private static final String PO_SET_ENTITY = "$.testFlowData.poDetails";
	private static final String DYNAMIC_PO_APPENDER = "07";
	private static final String MOCK_ADMIN_URL = "mock_admin_url";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String IS_PO_DC_UPDATE_REQUIED = "is_po_dc_nbr_update_required";
	private static final String DYNAMIC_PO_KEY = "is_dynamic_po";
	private static final String DYNAMIC_PO_DETAILS = "DYNAMIC_PO_DETAILS";
	private static final String OMS_PO_PATH="/NEXTGEN/OMSPubSubGenericRead2";
	public static final String MOCK_PO_PREFIX = "222";
	Response itemMdmResponseForFailSafe = null;
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);

	@Step
	public void userHitsOmsAndPopulatesPolineData(String scenarioType, String poNumbers, String ovgFlag,
			String channelFlipVal) throws JsonProcessingException, JSONException, ParseException {
		try {
			boolean isDynamicPONumberRequired = false;
			boolean isPoDcNumberUpdationRequired = false;
			if (poNumbers.equals("MANUAL_CON_PO")) {
				poNumbers = environment.getProperty("MANUAL_CON_PO");
			} else if (poNumbers.equals("MANUAL_NON_CON_PO")) {
				poNumbers = environment.getProperty("MANUAL_NON_CON_PO");
			} else if (poNumbers.equals("MANUAL_PO_ORDER_REOPEN")) {
				poNumbers = environment.getProperty("MANUAL_PO_ORDER_REOPEN");
			}
			LOGGER.info("Called with parameters scenarioType : {} & poNumbers : {}", scenarioType, poNumbers);
			String fetchFromEnterpriseMDMVal = environment.getProperty("fetch_from_enterprise_mdm");
			boolean isFetchFromEnterpriseMDM = false;
			if (fetchFromEnterpriseMDMVal != null) {
				isFetchFromEnterpriseMDM = Boolean.parseBoolean(fetchFromEnterpriseMDMVal);
			}
			LOGGER.info("Fetch From Enterprise MDM:{}", isFetchFromEnterpriseMDM);
			String[] poNumArr = poNumbers.split(";");
			// boolean isCert =
			// environment.getProperty("CONTEXT_URL").contains(environment.getProperty("dcNumber"));
			// poNumArr = isCert ? poNumbers.split(";") :
			// tl.get().get("poNumbers").toString().split(";");

			String[] plannedPoNumbersArr = poNumArr[ZERO].split(",");
			String[] additionalPoNumbersArr;

			int plannedPoLength = plannedPoNumbersArr.length;

			String[] allPosArr;
			boolean isSurplusScen = scenarioType.toLowerCase().contains("surplus");
			boolean isDCtoDCTransfer = scenarioType.equalsIgnoreCase("DCtoDCTransfer");
			LOGGER.info("Is this is a surplus scenario with additional PO's :{}", isSurplusScen);

			if (isSurplusScen) {
				additionalPoNumbersArr = poNumArr[ONE].split(",");
				allPosArr = ArrayUtils.addAll(plannedPoNumbersArr, additionalPoNumbersArr);
			} else {
				allPosArr = plannedPoNumbersArr;
			}

			TestFlowDataMain root = new TestFlowDataMain();
			TestFlowData testFlowData = new TestFlowData();
			List<PoDetail> listOfPOs = new ArrayList<>();

			for (int i = ZERO; i < allPosArr.length; i++) {

				List<PoLineDetail> listOfPLines = new ArrayList<>();
				LOGGER.info("Is Dynamic po number required:{}", environment.getProperty(DYNAMIC_PO_KEY));
				isDynamicPONumberRequired = environment.getProperty(DYNAMIC_PO_KEY) != null && Boolean.parseBoolean(environment.getProperty(DYNAMIC_PO_KEY));
				isPoDcNumberUpdationRequired = environment.getProperty(IS_PO_DC_UPDATE_REQUIED) != null && Boolean.parseBoolean(environment.getProperty(IS_PO_DC_UPDATE_REQUIED));
				if (isDynamicPONumberRequired) {
					allPosArr[i] = getMockedPONumber(allPosArr[i]);
				}
				PoDetail poDetail = new PoDetail();
				poDetail.setPoName("PO"+(i+1));
				if (allPosArr[i].equalsIgnoreCase("DYNAMIC")) { // This code is specific to scenarios where Mock PO is created from scratch and not from mock JSON content
					if(Config.DC == DC_TYPE.ACC || Config.DC == DC_TYPE.ATLAS) {
						String[] dynamicPOArr = tl.get().get(DYNAMIC_PO_DETAILS).toString().split(",");
						if(dynamicPOArr.length == allPosArr.length) {
							allPosArr[i] = dynamicPOArr[i].trim();
						} else {
							allPosArr[i] = dynamicPOArr[0].trim();
						}
						LOGGER.info("Dynamic PO=" + allPosArr[i]);
					}
				}
				String omsUrl = environment.getProperty("oms_ep") + allPosArr[i] + environment.getProperty("oms_ep_qp");
				LOGGER.info("OMS Url:{}",omsUrl);
				Response omsResponse = SerenityRest.given().accept("application/json").get(omsUrl);
				LOGGER.info("OMS Response status code:{}", omsResponse.getStatusCode());
				Assert.assertEquals(ErrorCodes.OMS_PO_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE,
						omsResponse.getStatusCode());
				String jsonObject = null;
				jsonObject = omsResponse.getBody().asString();
				net.minidev.json.JSONObject omsPoObj = jsonUtils.convertStringToMinidevJsonObject(jsonObject);

				LOGGER.info(
						"OMS GET call to fetch PO details : " + environment.getProperty("oms_ep") + allPosArr[i]
								+ environment.getProperty("oms_ep_qp") + " and headers : " + "Accept",
						ContentType.JSON);

				String omsRespStr = omsPoObj.toJSONString();

				final String datatJp = "$..Data..";
				if(!isDCtoDCTransfer){
				poDetail.setPoNumber(((JSONArray) read(omsRespStr, datatJp + "omspo.xrefponbr")).get(0).toString());

				poDetail.setOmsPONumber(((JSONArray) read(omsRespStr, datatJp + "omspo.oponbr")).get(0).toString());

				String poTypeCd = ((JSONArray) read(omsRespStr, datatJp + "omspo..subpoext..potypecd")).get(0)
						.toString();
				if(Config.DC==DC_TYPE.SAMS) {
					poTypeCd="3";
				}
				String poDcNumber=((JSONArray) read(omsRespStr, datatJp + "omspo..dcnbr")).get(0)
						.toString();
				String facilityNumber=environment.getProperty("facility_num");
				String poconDCNumber=environment.getProperty("pocon_dcnum");
				if(isPoDcNumberUpdationRequired) {
					if(poDcNumber.equals(facilityNumber)||(poconDCNumber!=null && poDcNumber.equals(poconDCNumber))) {
						LOGGER.info("Facility Number is matching PO DC number.. No Mock changes required");
					}else {
						LOGGER.info("PO DC Number needs to be changed from {} to {}", poDcNumber, facilityNumber);
					updateDcNumberWithFacilityNumber(poDetail.getPoNumber(), poDcNumber, facilityNumber);
					}
				}
				/*
				 * Do not delete this commented line.
				 */
				// poDetail.setSourceNumber(read(poArr, "$[0].omspo.dcnbr"));
				poDetail.setSourceNumber("6938");
				poDetail.setPoStatus(((JSONArray) read(omsRespStr, datatJp + "omspo.postatcdtext")).get(0).toString());
				poDetail.setBaseDiv(((JSONArray) read(omsRespStr, datatJp + "omspo.basediv")).get(0).toString());
				poDetail.setSrcCountryCode(((JSONArray) read(omsRespStr, datatJp + "omspo.dccc")).get(0).toString());

				String isPlannedPO = (i > plannedPoLength - 1) ? "false" : "true";
				poDetail.setIsPlannedPo(isPlannedPO);
				poDetail.setIsChannelFlipRequired("false");
				if (channelFlipVal != null && !channelFlipVal.equals("")) {
					String[] channelFlipValArr = channelFlipVal.split(",");
					if (i < channelFlipValArr.length) {
						poDetail.setIsChannelFlipRequired(channelFlipValArr[i]);
					} else if (channelFlipValArr.length > 0 && i >= channelFlipValArr.length) {
						poDetail.setIsChannelFlipRequired(channelFlipValArr[channelFlipValArr.length - 1]);
					}

				}
				String channelMethod = "";
				if (poDetail.getIsChannelFlipRequired().equals("true")) {
					channelMethod = getOpFlippedChannelMethod(poTypeCd);
				} else {
					channelMethod = getOpChannelMethod(poTypeCd);
				}
				poDetail.setChannelMethod(channelMethod);
				if (channelMethod.equalsIgnoreCase(CHANNELS.DSDC.getValue())) {
					poDetail.setSourceNumber(((JSONArray) read(omsRespStr, datatJp + "omspo.dcnbr")).get(0).toString());
				}
				JSONArray poLinesArr, poLineDestArr;
				if (((JSONArray) parse(omsRespStr).read(datatJp + "omspo..omspol")).get(0).getClass().toString()
						.contains("LinkedHashMap")) {
					poLinesArr = parse(omsRespStr).read(datatJp + "omspo..omspol", JSONArray.class);
				} else {
					poLinesArr = parse(omsRespStr).read(datatJp + "omspo..omspol.*", JSONArray.class);
				}

				if (((JSONArray) parse(omsRespStr).read(datatJp + "omspo..omspol..omspolinedest")).get(0).getClass()
						.toString().contains("LinkedHashMap")) {
					poLineDestArr = parse(omsRespStr).read(datatJp + "omspo..omspol..omspolinedest", JSONArray.class);
				} else {
					poLineDestArr = parse(omsRespStr).read(datatJp + "omspo..omspol..omspolinedest.*", JSONArray.class);
				}

				LOGGER.info(
						"poLinesArr size is " + poLinesArr.size() + " poLineDestArr size is " + poLineDestArr.size());

				for (int j = ZERO; j < poLinesArr.size(); j++) {

					PoLineDetail pold = new PoLineDetail();

					LinkedHashMap poLine = (LinkedHashMap) poLinesArr.get(j);
					LinkedHashMap poLineDest = (LinkedHashMap) poLineDestArr.get(j);

					pold.setPoLineNumber(String.valueOf(poLine.get("opolnbr")));
					String itmnbr = String.valueOf(poLine.get("itmnbr"));

					pold.setItemNumber(itmnbr);
					pold.setVnpk(String.valueOf(poLine.get("vnpkqty")));
					pold.setWhpk(String.valueOf(poLine.get("whpkqty")));
					LinkedHashMap poDestMap = null;
					Double whpkSellCost = null;
					Double vnpkQty = null;
					LinkedHashMap omsPolineArr = null;

					poDestMap = (LinkedHashMap) poLineDest.get("podeststttxt");
					if ((String) (poLineDest.get("destcntrycd")) != null)
						pold.setDestCountryCode((String) (poLineDest.get("destcntrycd")));
					pold.setPoVnpkQty(String.valueOf(poLineDest.get("vnpkordqty")));
					if ((String) (poLineDest.get("whpkordqty")) != null)
						pold.setPoWhpkQty(String.valueOf(poLineDest.get("whpkordqty")));
					pold.setWhpkSellPrice(String.valueOf(poLineDest.get("whpksellcostamt")));
					whpkSellCost = Double.parseDouble((String) poLineDest.get("whpksellcostamt"));
					vnpkQty = Double.parseDouble(String.valueOf(poLineDest.get("vnpkordqty")));

					LinkedHashMap poLineMap = (LinkedHashMap) poLine.get("polstcdtx");
					LinkedHashMap poEventMap = (LinkedHashMap) poLine.get("poevtabbr");
					pold.setOverageFlag(ovgFlag);
					Double whpk = Double.parseDouble(String.valueOf(poLine.get("whpkqty")));
					Double vnpk = Double.parseDouble(String.valueOf(poLine.get("vnpkqty")));

					Double vnpkSellCost = (whpkSellCost / whpk) * vnpk;

					int ovgQty;
					double allowedOverage = ACCEPTED_OVERAGE_PRICE_THRESHOLD / vnpkSellCost;
					ovgQty = (int) Math.ceil((allowedOverage < vnpkQty) ? allowedOverage : vnpkQty);

					pold.setOvgQty(String.valueOf(ovgQty));

					pold.setOmsChannelMethod(poTypeCd);
					pold.setChannelMethod(channelMethod);

					if (!channelMethod.equalsIgnoreCase("crossmu")) {
						if (String.valueOf(poLineDest.get("deststorenbr")) != null)
							pold.setDestNumber(String.valueOf(poLineDest.get("deststorenbr")));
					} else {
						pold.setDestNumber(((JSONArray) read(omsRespStr,
								datatJp + "OMSAllocOrder[?(@.allcpoline==" + (j + 1) + ")]..tostrnbr")).toString());
					}
					if (poDestMap != null)
						pold.setPoDestStatus((String) poDestMap.get("podestcdtext"));
					pold.setPoLineStatus((String) poLineMap.get("polnstcdtext"));
					pold.setPoEvent((String) poEventMap.get("poevtapprtxt"));

					JSONArray itmArr = new JSONArray();
					itmArr.add(itmnbr);
					Response itemMdmResponse = null;
					LOGGER.info("Call to item MDM to fetch the item details : " + environment.getProperty("item_mdm_ep")
							+ " with the header :" + "api-key", environment.getProperty("item_mdm_api_key"));
					if (isFetchFromEnterpriseMDM) {
						Failsafe.with(retryPolicy).run(() -> {
							itemMdmResponseForFailSafe = SerenityRest.given().relaxedHTTPSValidation()
									.header("Content-Type", ContentType.JSON)
									.header("Accept",
											"application/vnd.com.walmart.canonical.masterItem.MasterProduct-7+json")
									.header("WMT-API-KEY", environment.getProperty("enterprise_mdm_api_key"))
									.header("itemNumbers", itmnbr).get(environment.getProperty("enterprise_mdm_ep"));
							JSONArray itemMdmArr = JsonPath.read(itemMdmResponseForFailSafe.asString(),
									"$..tradeItemsSupplyItems[*].consumableTradeItems[*]");
							LOGGER.info("Enterprise MDM consumableTradeItems Arr size:{} for item:{}",
									itemMdmArr.size(), itmnbr);
							if (itemMdmArr.isEmpty()) {
								Assert.fail(ErrorCodes.MDM_ITEM_DETAILS_NOT_FOUND);
							}
						});
						itemMdmResponse = itemMdmResponseForFailSafe;
					}else if(Config.DC==DC_TYPE.SAMS) {
						itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
								.headers(getHeaders())
								.header("Content-Type", ContentType.JSON)
								.header("api-key", environment.getProperty("item_mdm_api_key"))
								.post(environment.getProperty("item_mdm_ep"));
					}
					else if (Config.DC==DC_TYPE.ACC || Config.DC==DC_TYPE.ATLAS || Config.DC==DC_TYPE.RDC || Config.DC==DC_TYPE.CATALYST) {
						itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
								.headers(getHeaders())
								.header("Content-Type", ContentType.JSON)
								.header("api-key", environment.getProperty("item_mdm_api_key"))
								.post(environment.getProperty("item_mdm_ep"));
					}
					//Have to remove this once we start updating item details into Testflow data from SCIS
					else if(Config.DC==DC_TYPE.PHARMACY ) {
						System.setProperty("itemMDMFacility", "32898");
						itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
								.headers(getHeaders())
								.header("Content-Type", ContentType.JSON)
								.header("api-key", environment.getProperty("item_mdm_api_key"))
								.post(environment.getProperty("item_mdm_ep"));
						String itemMdmRespStr = itemMdmResponse.getBody().asString();
						DocumentContext itmMdmDocCxt = parse(itemMdmRespStr);
						System.setProperty("itemMDMFacility", "32899");
						try {
							JSONArray itemMdmArr = itmMdmDocCxt.read("$.foundSupplyItems");
						} catch(PathNotFoundException e) {
							System.setProperty("itemMDMFacility", "32899");
							itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
									.headers(getHeaders())
									.header("Content-Type", ContentType.JSON)
									.header("api-key", environment.getProperty("item_mdm_stg_api_key"))
									.post(environment.getProperty("item_mdm_ep_stg"));
						}
					} else {

						itemMdmResponse = SerenityRest.given().body(itmArr.toJSONString())
								.header("Content-Type", ContentType.JSON)
								.header("api-key", environment.getProperty("item_mdm_api_key"))
								.post(environment.getProperty("item_mdm_ep"));
					}

					String itemMdmRespStr = itemMdmResponse.getBody().asString();

					DocumentContext itmMdmDocCxt = parse(itemMdmRespStr);

					JSONArray itemMdmArr = null;
					if (isFetchFromEnterpriseMDM) {
						String orderableGtin = ((JSONArray) itmMdmDocCxt.read("$..orderableGTIN")).get(0).toString();
						LOGGER.info("Orderable GTIN/Case UPC:{}", orderableGtin);// consumableGTIN is itemUPC
						itemMdmArr = itmMdmDocCxt.read("$..[?(@.gtin==\"" + orderableGtin + "\")]");
					} else {
						itemMdmArr = itmMdmDocCxt.read("$.foundSupplyItems");
					}

					LinkedHashMap supItms = (LinkedHashMap) itemMdmArr.get(ZERO);

					boolean containsTi = supItms.containsKey("palletTi");
					boolean containsHi = supItms.containsKey("palletHi");

					String palletTi = containsTi ? String.valueOf(supItms.get("palletTi")) : null;
					String palletHi = containsHi ? String.valueOf(supItms.get("palletHi")) : null;
					String deptNumber = "";
					//String gtin = "";
					String itemUpc="";
					String isConveyable = "";
					if (isFetchFromEnterpriseMDM) {
						JSONArray deptNumberArr = JsonPath.read(itemMdmRespStr,
								"$..tradeItemsSupplyItems[*].supplyItemTradeItemPack[*].supplyItem.deptNumber");// GDM
						// Fetch
						// from
						// diff
						// place,Need
						// to
						// correct
						// it
						deptNumber = deptNumberArr.isEmpty() ? "" : deptNumberArr.get(0).toString();
					} else {
						deptNumber = String.valueOf(supItms.get("deptNumber"));
					}

					pold.setDepartmentNumber(deptNumber);
					if (isFetchFromEnterpriseMDM) {
						itemUpc = String.valueOf(supItms.get("gtin"));
						isConveyable = String.valueOf(supItms.get("isConveyable"));
						if (Config.DC == DC_TYPE.THOR) {
							List<String> caseUPCList = JsonPath.read(itemMdmRespStr,
									"$..tradeItemsSupplyItems[*]..orderableGTIN");
							pold.setCaseUpc(caseUPCList.get(0));
						}
					} else {
						JSONArray tradeItems = (JSONArray) supItms.get("tradeItems");
						LinkedHashMap tradeItem = (LinkedHashMap) tradeItems.get(ZERO);
						String caseUpc = (String) tradeItem.get("gtin");
//						if (Config.DC==DC_TYPE.ACC) {
//							itemUpc=caseUpc;
//						} else {
							itemUpc=(String) supItms.get("consumableGTIN");
//						}
						LOGGER.info("case upc:{}", caseUpc);
						pold.setCaseUpc(caseUpc);
						isConveyable = String.valueOf(tradeItem.get("isConveyable"));
						if(Config.DC==DC_TYPE.SAMS) {
							JSONArray tradeItemArrByVnpk=JsonPath.read(tradeItems, "$[?(@.tradeItemType.code==\"CA\")]");
							LinkedHashMap tradeItemByVnpk = (LinkedHashMap) tradeItemArrByVnpk.get(ZERO);
							palletTi = tradeItemByVnpk.get("palletTi") != null ? String.valueOf(tradeItemByVnpk.get("palletTi")) : null;
							palletHi = tradeItemByVnpk.get("palletHi") != null ? String.valueOf(tradeItemByVnpk.get("palletHi")) : null;
							double weight;
							String weightFormatType = JsonPath.read(tradeItemByVnpk, "$.weightFormatType.code");
							LOGGER.info("weightFormatType:{} ", weightFormatType);
							//boolean isVariableWeight=weightFormatType!=null&&weightFormatType.equals("V");
							boolean isVariableWeight = (boolean) supItms.get("isVariableWeight");
							weight = JsonPath.read(tradeItemByVnpk, "$.weight.amount");
							String warehouseRotationType = JsonPath.read(supItms, "$.warehouseRotationType.code");
							String warehouseArea = JsonPath.read(supItms, "$.warehouseArea.code");
							LOGGER.info("Weight:{} isVariableWeight:{} Pallet Ti:{} palletHi:{}", weight, isVariableWeight, palletTi, palletHi);
							LOGGER.info("warehouseRotationType:{} warehouseArea:{} ", warehouseRotationType, warehouseArea);
							pold.setWeight(weight);
							pold.setIsVariableWeight(isVariableWeight);
							pold.setWarehouseArea(warehouseArea);
							pold.setWarehouseRotationType(warehouseRotationType);
						} else if (Config.DC == DC_TYPE.ATLAS || Config.DC == DC_TYPE.ACC) {
							palletTi =tradeItem.get("palletTi") != null ? String.valueOf(tradeItem.get("palletTi")) : null;
							palletHi =tradeItem.get("palletHi") != null ? String.valueOf(tradeItem.get("palletHi")) : null;
							double weight=JsonPath.read(tradeItem, "$.weight.amount");
							double cube=JsonPath.read(tradeItem, "$.cube.amount");
							LOGGER.info("Weight:{} Pallet Ti:{} palletHi:{} Cube:{}", weight, palletTi, palletHi, cube);
							pold.setWeight(weight);
							pold.setCube(cube);
						}
					}
					pold.setHi(palletHi);
					pold.setTi(palletTi);
					pold.setItemUpc(itemUpc);
					pold.setIsConveyable(isConveyable);
					listOfPLines.add(pold);
				}
				poDetail.setPoLineDetails(listOfPLines);

				listOfPOs.add(poDetail);
			} else {
					poDetail.setPoNumber(((JSONArray) read(omsRespStr, datatJp + "sto.stoxrefpo")).get(0).toString());

					poDetail.setOmsPONumber(((JSONArray) read(omsRespStr, datatJp + "sto.stoxrefpo")).get(0).toString());

					String poTypeCd = ((JSONArray) read(omsRespStr, datatJp + "sto.stounitcd")).get(0)
							.toString();
//					String poDcNumber=((JSONArray) read(omsRespStr, datatJp + "sto..dcnbr")).get(0)
//							.toString();
					String facilityNumber=environment.getProperty("facility_num");

					/*
					 * Do not delete this commented line.
					 */
					// poDetail.setSourceNumber(read(poArr, "$[0].omspo.dcnbr"));
					poDetail.setSourceNumber("6938");
					poDetail.setPoStatus(((JSONArray) read(omsRespStr, datatJp + "sto.stostatcdtxt")).get(0).toString());
					poDetail.setBaseDiv(((JSONArray) read(omsRespStr, datatJp + "sto.stobasediv")).get(0).toString());
					poDetail.setSrcCountryCode(((JSONArray) read(omsRespStr, datatJp + "OMSAllocOrder..fromcntrycd")).get(0).toString());

					String isPlannedPO = (i > plannedPoLength - 1) ? "false" : "true";
					poDetail.setIsPlannedPo(isPlannedPO);
					poDetail.setIsChannelFlipRequired("false");
					if (channelFlipVal != null && !channelFlipVal.equals("")) {
						String[] channelFlipValArr = channelFlipVal.split(",");
						if (i < channelFlipValArr.length) {
							poDetail.setIsChannelFlipRequired(channelFlipValArr[i]);
						} else if (channelFlipValArr.length > 0 && i >= channelFlipValArr.length) {
							poDetail.setIsChannelFlipRequired(channelFlipValArr[channelFlipValArr.length - 1]);
						}

					}
					String channelMethod = ((JSONArray) read(omsRespStr, datatJp + "sto.stochnlmthd")).get(0).toString();
					poDetail.setChannelMethod(channelMethod);

					JSONArray poLinesArr, poLineDestArr;
					poLinesArr = parse(omsRespStr).read(datatJp + "OMSAllocOrder[?(@.allcpoline==1)]", JSONArray.class);
					poLineDestArr = parse(omsRespStr).read(datatJp + "OMSAllocOrder[?(@.allcpoline==1)]..tostrnbr", JSONArray.class);

					LOGGER.info(
							"poLinesArr size is " + poLinesArr.size() + " poLineDestArr size is " + poLineDestArr.size());

					for (int j = ZERO; j < poLinesArr.size(); j++) {

						PoLineDetail pold = new PoLineDetail();

						LinkedHashMap poLine = (LinkedHashMap) poLinesArr.get(j);
						pold.setPoLineNumber(String.valueOf(poLine.get("allcpoline")));
						String itmnbr = String.valueOf(poLine.get("allcitmnbr"));

						pold.setItemNumber(itmnbr);
						pold.setVnpk(String.valueOf(poLine.get("allcvnpkqty")));
						pold.setWhpk(String.valueOf(poLine.get("allcwhpkqty")));
						LinkedHashMap poDestMap = null;
						Double whpkSellCost = null;
						Double vnpkQty = 100.0;
						LinkedHashMap omsPolineArr = null;

						Double whpk = Double.parseDouble(String.valueOf(poLine.get("allcwhpkqty")));
						Double vnpk = Double.parseDouble(String.valueOf(poLine.get("allcvnpkqty")));
						if ((String) (poLine.get("destcntrycd")) != null)
							pold.setDestCountryCode((String) (poLine.get("destcntrycd")));
						int poVNPKQty = Integer.parseInt(poLine.get("allcwhpkordqty").toString())/(int) (vnpk/whpk);
						pold.setPoVnpkQty(String.valueOf(poVNPKQty));
						if ((String) (poLine.get("allcwhpkordqty")) != null)
							pold.setPoWhpkQty(String.valueOf(poLine.get("allcwhpkordqty")));
						pold.setWhpkSellPrice(String.valueOf(poLine.get("allcwhpksell")));
						whpkSellCost = Double.parseDouble((String) poLine.get("allcwhpksell"));
//						vnpkQty = Double.parseDouble(String.valueOf(poLineDest.get("vnpkordqty")));

						LinkedHashMap poLineMap = (LinkedHashMap) poLine.get("polstcdtx");
						LinkedHashMap poEventMap = (LinkedHashMap) poLine.get("poevtabbr");
						pold.setOverageFlag(ovgFlag);

						Double vnpkSellCost = (whpkSellCost / whpk) * vnpk;

						int ovgQty;
						double allowedOverage = ACCEPTED_OVERAGE_PRICE_THRESHOLD / vnpkSellCost;
						ovgQty = (int) Math.ceil((allowedOverage < vnpkQty) ? allowedOverage : vnpkQty);

						pold.setOvgQty(String.valueOf(ovgQty));

						pold.setOmsChannelMethod(poTypeCd);
						pold.setChannelMethod(channelMethod);
						pold.setDestNumber(poLineDestArr.get(j).toString());

//						if (poDestMap != null)
//							pold.setPoDestStatus((String) poDestMap.get("podestcdtext"));
//						pold.setPoLineStatus((String) poLineMap.get("polnstcdtext"));
//						pold.setPoEvent((String) poEventMap.get("poevtapprtxt"));

						JSONArray itmArr = new JSONArray();
						itmArr.add(itmnbr);
						Response itemMdmResponse = null;
						LOGGER.info("Call to item MDM to fetch the item details : " + environment.getProperty("item_mdm_ep")
								+ " with the header :" + "api-key", environment.getProperty("item_mdm_api_key"));
						if (isFetchFromEnterpriseMDM) {
							Failsafe.with(retryPolicy).run(() -> {
								itemMdmResponseForFailSafe = SerenityRest.given().relaxedHTTPSValidation()
										.header("Content-Type", ContentType.JSON)
										.header("Accept",
												"application/vnd.com.walmart.canonical.masterItem.MasterProduct-7+json")
										.header("WMT-API-KEY", environment.getProperty("enterprise_mdm_api_key"))
										.header("itemNumbers", itmnbr).get(environment.getProperty("enterprise_mdm_ep"));
								JSONArray itemMdmArr = JsonPath.read(itemMdmResponseForFailSafe.asString(),
										"$..tradeItemsSupplyItems[*].consumableTradeItems[*]");
								LOGGER.info("Enterprise MDM consumableTradeItems Arr size:{} for item:{}",
										itemMdmArr.size(), itmnbr);
								if (itemMdmArr.isEmpty()) {
									Assert.fail(ErrorCodes.MDM_ITEM_DETAILS_NOT_FOUND);
								}
							});
							itemMdmResponse = itemMdmResponseForFailSafe;
						}else if(Config.DC==DC_TYPE.SAMS) {
							itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
									.headers(getHeaders())
									.header("Content-Type", ContentType.JSON)
									.header("api-key", environment.getProperty("item_mdm_api_key"))
									.post(environment.getProperty("item_mdm_ep"));
						}
						else if(Config.DC==DC_TYPE.ACC || Config.DC==DC_TYPE.ATLAS || Config.DC==DC_TYPE.RDC || Config.DC==DC_TYPE.CATALYST){
							itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
									.headers(getHeaders())
									.header("Content-Type", ContentType.JSON)
									.header("api-key", environment.getProperty("item_mdm_api_key"))
									.post(environment.getProperty("item_mdm_ep"));
						}
						//Have to remove this once we start updating item details into Testflow data from SCIS
						else if(Config.DC==DC_TYPE.PHARMACY )  {
							System.setProperty("itemMDMFacility", "32899");
							itemMdmResponse = SerenityRest.given().relaxedHTTPSValidation().body(itmArr.toJSONString())
									.headers(getHeaders())
									.header("Content-Type", ContentType.JSON)
									.header("api-key", environment.getProperty("item_mdm_api_key"))
									.post(environment.getProperty("item_mdm_ep"));
						}
						else {

							itemMdmResponse = SerenityRest.given().body(itmArr.toJSONString())
									.header("Content-Type", ContentType.JSON)
									.header("api-key", environment.getProperty("item_mdm_api_key"))
									.post(environment.getProperty("item_mdm_ep"));
						}

						String itemMdmRespStr = itemMdmResponse.getBody().asString();

						DocumentContext itmMdmDocCxt = parse(itemMdmRespStr);

						JSONArray itemMdmArr = null;
						if (isFetchFromEnterpriseMDM) {
							String orderableGtin = ((JSONArray) itmMdmDocCxt.read("$..orderableGTIN")).get(0).toString();
							LOGGER.info("Orderable GTIN/Case UPC:{}", orderableGtin);// consumableGTIN is itemUPC
							itemMdmArr = itmMdmDocCxt.read("$..[?(@.gtin==\"" + orderableGtin + "\")]");
						} else {
							itemMdmArr = itmMdmDocCxt.read("$.foundSupplyItems");
						}

						LinkedHashMap supItms = (LinkedHashMap) itemMdmArr.get(ZERO);

						boolean containsTi = supItms.containsKey("palletTi");
						boolean containsHi = supItms.containsKey("palletHi");

						String palletTi = containsTi ? String.valueOf(supItms.get("palletTi")) : null;
						String palletHi = containsHi ? String.valueOf(supItms.get("palletHi")) : null;
						String deptNumber = "";
						//String gtin = "";
						String itemUpc="";
						String isConveyable = "";
						if (isFetchFromEnterpriseMDM) {
							JSONArray deptNumberArr = JsonPath.read(itemMdmRespStr,
									"$..tradeItemsSupplyItems[*].supplyItemTradeItemPack[*].supplyItem.deptNumber");// GDM
							// Fetch
							// from
							// diff
							// place,Need
							// to
							// correct
							// it
							deptNumber = deptNumberArr.isEmpty() ? "" : deptNumberArr.get(0).toString();
						} else {
							deptNumber = String.valueOf(supItms.get("deptNumber"));
						}

						pold.setDepartmentNumber(deptNumber);
						if (isFetchFromEnterpriseMDM) {
							itemUpc = String.valueOf(supItms.get("gtin"));
							isConveyable = String.valueOf(supItms.get("isConveyable"));
							if (Config.DC == DC_TYPE.THOR) {
								List<String> caseUPCList = JsonPath.read(itemMdmRespStr,
										"$..tradeItemsSupplyItems[*]..orderableGTIN");
								pold.setCaseUpc(caseUPCList.get(0));
							}
						} else {
							JSONArray tradeItems = (JSONArray) supItms.get("tradeItems");
							LinkedHashMap tradeItem = (LinkedHashMap) tradeItems.get(ZERO);
							String caseUpc = (String) tradeItem.get("gtin");
							if(Config.DC==DC_TYPE.ACC) {
								itemUpc=caseUpc;
							}else {
								itemUpc=(String) supItms.get("consumableGTIN");
							}
							LOGGER.info("case upc:{}",caseUpc);
							pold.setCaseUpc(caseUpc);
							isConveyable = String.valueOf(tradeItem.get("isConveyable"));
							if(Config.DC==DC_TYPE.SAMS) {
								JSONArray tradeItemArrByVnpk=JsonPath.read(tradeItems, "$[?(@.tradeItemType.code==\"CA\")]");
								LinkedHashMap tradeItemByVnpk = (LinkedHashMap) tradeItemArrByVnpk.get(ZERO);
								palletTi =tradeItemByVnpk.get("palletTi")!=null?String.valueOf(tradeItemByVnpk.get("palletTi")):null;
								palletHi = tradeItemByVnpk.get("palletHi")!=null?String.valueOf(tradeItemByVnpk.get("palletHi")):null;
								double weight;
								String weightFormatType=JsonPath.read(tradeItemByVnpk, "$.weightFormatType.code");
								LOGGER.info("weightFormatType:{} ",weightFormatType);
								//boolean isVariableWeight=weightFormatType!=null&&weightFormatType.equals("V");
								boolean isVariableWeight=(boolean)supItms.get("isVariableWeight");
								weight=JsonPath.read(tradeItemByVnpk, "$.weight.amount");
								String warehouseRotationType=JsonPath.read(supItms, "$.warehouseRotationType.code");
								String warehouseArea=JsonPath.read(supItms, "$.warehouseArea.code");
								LOGGER.info("Weight:{} isVariableWeight:{} Pallet Ti:{} palletHi:{}",weight,isVariableWeight,palletTi,palletHi);
								LOGGER.info("warehouseRotationType:{} warehouseArea:{} ",warehouseRotationType,warehouseArea);
								pold.setWeight(weight);
								pold.setIsVariableWeight(isVariableWeight);
								pold.setWarehouseArea(warehouseArea);
								pold.setWarehouseRotationType(warehouseRotationType);

							} else if(Config.DC==DC_TYPE.ATLAS || Config.DC==DC_TYPE.ACC) {
								palletTi =tradeItem.get("palletTi")!=null?String.valueOf(tradeItem.get("palletTi")):null;
								palletHi = tradeItem.get("palletHi")!=null?String.valueOf(tradeItem.get("palletHi")):null;
								double weight=JsonPath.read(tradeItem, "$.weight.amount");
								double cube=JsonPath.read(tradeItem, "$.cube.amount");
								LOGGER.info("Weight:{} Pallet Ti:{} palletHi:{} Cube:{}",weight,palletTi,palletHi, cube);
								pold.setWeight(weight);
								pold.setCube(cube);
							}
						}
						pold.setHi(palletHi);
						pold.setTi(palletTi);
						pold.setItemUpc(itemUpc);
						pold.setIsConveyable(isConveyable);
						listOfPLines.add(pold);
					}
					poDetail.setPoLineDetails(listOfPLines);

					listOfPOs.add(poDetail);
				}
		}

			testFlowData.setPoDetails(listOfPOs);
			root.setTestFlowData(testFlowData);

			ObjectMapper om = new ObjectMapper();

			LOGGER.info("After parsing the OMS po details, the testFlowData object with the PO details is : "
					+ om.writeValueAsString(root));

			tl.get().put("testFlowData", om.writeValueAsString(root));
			if (isDynamicPONumberRequired) {
				addDynamicMockIdsToTestFlowData();
			}
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while getting PO Details", e);
		}
	}

	@Step
	public void userHitsOmsAndPopulatesPolineData(String scenarioType, String poNumbers, String ovgFlag)
			throws JsonProcessingException, JSONException, ParseException {
		userHitsOmsAndPopulatesPolineData(scenarioType, poNumbers, ovgFlag, "");
	}

	private String getOpChannelMethod(String omsChannelMethod) {
		if (omsChannelMethod.equals("3") || omsChannelMethod.equals("53") || omsChannelMethod.equals("43")) {
			return CHANNELS.CROSSMU.getValue().toUpperCase();
		} else if (omsChannelMethod.equals("20")) {
			return CHANNELS.SSTK.getValue().toUpperCase();
		} else if (omsChannelMethod.equals("73")) {
			return CHANNELS.DSDC.getValue().toUpperCase();
		} else
			return CHANNELS.CROSSU.getValue().toUpperCase();
	}

	private String getOpFlippedChannelMethod(String omsChannelMethod) {
		if (omsChannelMethod.equals("20")) {
			return CHANNELS.CROSSU.getValue().toUpperCase();
		} else
			return CHANNELS.SSTK.getValue().toUpperCase();
	}

	private String getMockedPONumber(String poNumber) throws IOException {
		synchronized (this) {
			List<LinkedHashMap<String, String>> mappings = getMappingFromPONumber(poNumber);
			String newPoNumber = DYNAMIC_PO_APPENDER + javaUtils.randonNumberGenerator(8);
			if (!mappings.isEmpty()) {
				for (LinkedHashMap<String, String> mapping : mappings) {
					String uuid = javaUtils.getUUID();
					mapping.put("id", uuid);
					mapping.put("uuid", uuid);
					String mockPayload = new ObjectMapper().writeValueAsString(mapping);
					mockPayload = mockPayload.replaceAll(poNumber, newPoNumber);
					LOGGER.info("Mock Payload:{}", mockPayload);
					Response poCreateMockResponse = SerenityRest.given().body(mockPayload)
							.contentType("application/json").post(environment.getProperty(MOCK_ADMIN_URL));
					LOGGER.info("Mock Post Response code:{}", poCreateMockResponse.statusCode());
					if (poCreateMockResponse.statusCode() == Constants.CREATE_SUCESS_STATUS_CODE) {
						if (tl.get().get(DYNAMIC_PO_DETAILS) != null) {
							tl.get().put(DYNAMIC_PO_DETAILS,
									tl.get().get(DYNAMIC_PO_DETAILS).toString() + "," + newPoNumber + ";" + uuid);
						} else {
							tl.get().put(DYNAMIC_PO_DETAILS, newPoNumber + ";" + uuid);
						}

					} else {
						return poNumber;
					}
				}
			}
			return newPoNumber;
		}
	}
	private void updateDcNumberWithFacilityNumber(String poNumber,String poDcNumber,String facilityNum) throws IOException {
		synchronized (this) {
			List<LinkedHashMap<String, String>> mappings = getExactMappingFromPONumber(poNumber);
			if (!mappings.isEmpty()) {
				for (LinkedHashMap<String, String> mapping : mappings) {
					String mockEndPoint = environment.getProperty(MOCK_ADMIN_URL)+mapping.get("uuid");
					String mockPayload = new ObjectMapper().writeValueAsString(mapping);
					mockPayload = mockPayload.replaceAll(poDcNumber, facilityNum);
					LOGGER.info("Mock Endpoint:{}", mockEndPoint);
					Response poCreateMockResponse = SerenityRest.given().body(mockPayload)
							.contentType("application/json").put(mockEndPoint);
					LOGGER.info("Mock PUT Response code:{}", poCreateMockResponse.statusCode());
					if (poCreateMockResponse.statusCode() == Constants.SUCESS_STATUS_CODE) {
						LOGGER.info("Successfully updated the po dc number with facility number:{}", facilityNum);
					} else {
						LOGGER.info("Something went wrong while updating po dc number response code:{}", poCreateMockResponse.statusCode());
					}
				}
			}else {
				LOGGER.info("No mapping found for PO{}", poNumber);
			}
		}
	}

	private List<LinkedHashMap<String, String>> getMappingFromPONumber(String poNumber) throws IOException {
		List<LinkedHashMap<String, String>> mappings = JsonPath
				.read(new File(System.getProperty("user.dir") + FileNames.PO_MOCK_FILE), "$.mappings[*]");
		List<LinkedHashMap<String, String>> matchedMappings = new ArrayList<>();
		for (LinkedHashMap<String, String> mapping : mappings) {
			List<String> urlPatternArr = JsonPath.read(mapping, "$..urlPattern");
			String urlPattern = urlPatternArr.get(0);
			if (urlPattern.startsWith("/") && urlPattern.endsWith(".*") && urlPattern.contains(poNumber)) {
				matchedMappings.add(mapping);
			}

		}
		return matchedMappings;
	}
	private List<LinkedHashMap<String, String>> getExactMappingFromPONumber(String poNumber) throws IOException {
		List<LinkedHashMap<String, String>> mappings = JsonPath
				.read(new File(System.getProperty("user.dir") + FileNames.PO_MOCK_FILE), "$.mappings[*]");
		List<LinkedHashMap<String, String>> matchedMappings = new ArrayList<>();
		for (LinkedHashMap<String, String> mapping : mappings) {
			List<String> urlPatternArr = JsonPath.read(mapping, "$..urlPattern");
			String urlPattern = urlPatternArr.get(0);
			if (urlPattern.contains(OMS_PO_PATH)&& urlPattern.contains(poNumber)) {
				matchedMappings.add(mapping);
			}

		}
		return matchedMappings;
	}

	private void addDynamicMockIdsToTestFlowData() throws IOException, ParseException {
		if (tl.get().get(DYNAMIC_PO_DETAILS) != null) {
			LOGGER.info("Dynamic Mock Details:{}", tl.get().get(DYNAMIC_PO_DETAILS).toString());
			String[] mockDetails = tl.get().get(DYNAMIC_PO_DETAILS).toString().split(",");
			for (String mockDetail : mockDetails) {
				String poNumber = mockDetail.split(";")[0];
				String uuid = mockDetail.split(";")[1];
				String testFlowData = tl.get().get(TEST_FLOW_DATA).toString();
				ObjectMapper objectMapper = new ObjectMapper();
				net.minidev.json.JSONArray listOfPoDetails = JsonPath.read(testFlowData, PO_GET_ENTITY);
				String poDetailsJson = objectMapper.writeValueAsString(listOfPoDetails);
				List<PoDetail> poDetailList = (List<PoDetail>) jsonUtils.getPojoListfromPath(poDetailsJson,
						PoDetail.class);
				for (PoDetail poDetail : poDetailList) {
					if (poDetail.getPoNumber().equals(poNumber)) {
						poDetail.getUuid().add(uuid);
					}
				}
				net.minidev.json.JSONArray listofPoJson = jsonUtils.converyListToJsonArray(poDetailList);
				testFlowData = jsonUtils.setJsonAtJsonPath(testFlowData, listofPoJson, PO_SET_ENTITY);
				tl.get().put(TEST_FLOW_DATA, testFlowData);
			}
		}
	}
	public Headers getHeaders() {
		Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = null;
		if (Config.DC==DC_TYPE.RDC) {
			facilityNum = new Header("facilityNum", "32898");
		} else if (Config.DC==DC_TYPE.PHARMACY){
			facilityNum = new Header("facilityNum", System.getProperty("itemMDMFacility"));
		}
		else {
			facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		}
		Header userId = new Header("WMT-UserId", environment.getProperty("wmt_user_id"));
		Header securityId = new Header("WMT-Security-ID", environment.getProperty("wmt_security_id"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(contentType);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(securityId);
		return new Headers(headerList);
	}

	@Step
	public boolean mockPO(String poNumber, String itemNumber, String vnpkQty, String whpkQty, String orderQty, String whpkSellCost, String chnlMthd, String poType, String dcNbr) {
		List<String> uuidList = null;
		try {
			uuidList = new ArrayList<>();
			String[] poNumbers = poNumber.split(",");
			String[] poTypes = poType.split(",");
			String[] itemList = itemNumber.split(",");
			String[] vnpkQtyArr = vnpkQty.split(",");
			String[] whpkQtyArr = whpkQty.split(",");
			String[] chnlMthdArr = chnlMthd.split(",");
			String[] orderQtyArr = orderQty.split(",");
			String[] whpkSellCostArr = whpkSellCost.split(",");
			String[] dcNbrArr = dcNbr.split(",");
			int noOfItems = itemList.length;
			boolean areItemDetailsCorrect = vnpkQtyArr.length == noOfItems && whpkQtyArr.length == noOfItems && chnlMthdArr.length == noOfItems && orderQtyArr.length == noOfItems && whpkSellCostArr.length == noOfItems;

			// Validation of Inputs provided
			Assert.assertTrue(ErrorCodes.OMS_PO_ARRAY_SIZE_MORE_THAN_ITEM_ARRAY, poNumbers.length <= itemList.length);
			Assert.assertTrue(ErrorCodes.OMS_ITEM_ARRAY_DETAILS_NOT_CORRECT, areItemDetailsCorrect);

			for (int i = 0; i < poNumbers.length; i++) {
				String currentPOType = poTypes[i].trim();
				String currentPONum = poNumbers[i];
				String currentDC = dcNbrArr[i].trim();
				if(currentPONum.equalsIgnoreCase("DYNAMIC")) {
					currentPONum = getUniquePONum();
				}
				boolean mockJSONAlreadyExists = verifyPOAlreadyExistsInOMS(currentPONum, "JSON");
				boolean mockXMLAlreadyExists = verifyPOAlreadyExistsInOMS(currentPONum, "XML");
				if(!mockJSONAlreadyExists && !mockXMLAlreadyExists) {
					String baseOMSPOLineJSON = textParser.readTextFile(FileNames.MOCK_OMS_PO_LINE_TEMPLATE_FILE_JSON);
					String baseOMSPOBodyJSON = textParser.readTextFile(FileNames.MOCK_OMS_PO_BODY_TEMPLATE_FILE_JSON);
					String baseOMSPOPayloadJSON = textParser.readTextFile(FileNames.MOCK_OMS_PO_PAYLOAD_TEMPLATE_FILE_JSON);
					String uuidForJSON = UUID.randomUUID().toString();

					// XML Mock for ACC/MCC
					String baseOMSPOLineXML = textParser.readTextFile(FileNames.MOCK_OMS_PO_LINE_TEMPLATE_FILE_XML);
					String baseOMSPOBodyXML = textParser.readTextFile(FileNames.MOCK_OMS_PO_BODY_TEMPLATE_FILE_XML);
					String baseOMSPOPayloadXML = textParser.readTextFile(FileNames.MOCK_OMS_PO_PAYLOAD_TEMPLATE_FILE_XML);
					String uuidForXML = UUID.randomUUID().toString();

					String crtsysid = "GRS";
					String mancrtind = "N";

					String mockOMSPoLineJSON = "";
					String mockOMSPoLineXML ="";
					String[] itemListCurrentPO = itemList[i].split(";");
					int noOfItemsCurrentPO = itemListCurrentPO.length;
					String[] vnpkQtyArrCurrentPO = vnpkQtyArr[i].split(";");
					String[] whpkQtyArrCurrentPO = whpkQtyArr[i].split(";");
					String[] chnlMthdArrCurrentPO = chnlMthdArr[i].split(";");
					String[] orderQtyArrCurrentPO = orderQtyArr[i].split(";");
					String[] whpkSellCostArrCurrentPO = whpkSellCostArr[i].split(";");
					for (int j = 0; j < noOfItemsCurrentPO; j++) {
						String chnlMthdCode = chnlMthdArrCurrentPO[j].trim();
						if(chnlMthdCode.equalsIgnoreCase("1") && currentPOType.equalsIgnoreCase("3")) {
							crtsysid = "";
							mancrtind = "Y";
						}
						mockOMSPoLineJSON = mockOMSPoLineJSON + javaUtils.format(baseOMSPOLineJSON, String.valueOf(j + 1), itemListCurrentPO[j].trim(), vnpkQtyArrCurrentPO[j].trim(), whpkQtyArrCurrentPO[j].trim(), chnlMthdArrCurrentPO[j], getChannelMethodText(chnlMthdArrCurrentPO[j]), orderQtyArrCurrentPO[j].trim(), whpkSellCostArrCurrentPO[j].trim(), mancrtind);
						if (j < noOfItemsCurrentPO - 1) {
							mockOMSPoLineJSON = mockOMSPoLineJSON + ",";
						}

						if(Config.DC == DC_TYPE.ACC || Config.DC == DC_TYPE.ATLAS) {
							mockOMSPoLineXML = mockOMSPoLineXML + javaUtils.format(baseOMSPOLineXML, String.valueOf(j + 1), itemListCurrentPO[j].trim(), vnpkQtyArrCurrentPO[j].trim(), whpkQtyArrCurrentPO[j].trim(), chnlMthdArrCurrentPO[j], getChannelMethodText(chnlMthdArrCurrentPO[j]), orderQtyArrCurrentPO[j].trim(), whpkSellCostArrCurrentPO[j].trim(), mancrtind);
						}
					}
					String mockOMSPOBodyJSON = javaUtils.format(baseOMSPOBodyJSON, currentPONum, currentDC, currentPOType, mockOMSPoLineJSON, crtsysid, mancrtind);
					String mockOMSPOPayloadJSON = javaUtils.format(baseOMSPOPayloadJSON, uuidForJSON, currentPONum, mockOMSPOBodyJSON);
					mockOMSPOWithPayload(mockOMSPOPayloadJSON, "JSON");
					uuidList.add(uuidForJSON);

					if(Config.DC == DC_TYPE.ACC || Config.DC == DC_TYPE.ATLAS) {
						String mockOMSPOBodyXML = javaUtils.format(baseOMSPOBodyXML, currentPONum, currentDC, currentPOType, mockOMSPoLineXML, crtsysid, mancrtind);
						String mockOMSPOPayloadXML = javaUtils.format(baseOMSPOPayloadXML, uuidForXML, currentPONum, mockOMSPOBodyXML);
						mockOMSPOWithPayload(mockOMSPOPayloadXML, "XML");
					}
					uuidList.add(uuidForXML);
					if (tl.get().get(DYNAMIC_PO_DETAILS) != null) {
						tl.get().put(DYNAMIC_PO_DETAILS,
								tl.get().get(DYNAMIC_PO_DETAILS).toString() + "," + currentPONum);
					} else {
						tl.get().put(DYNAMIC_PO_DETAILS, currentPONum);
					}
				} else {
					LOGGER.info("Mock already exists for PO Number " + currentPONum + ". Hence not mocking it again.");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AutomationFailure("Something went wrong while mocking OMS PO");
		} finally {
			LOGGER.info("UUIDs for Mocked POs {}", uuidList);
		}
		return false;
	}

	private void mockOMSPOWithPayload(String mockOMSPO, String contentType) {
		String contentTypeDesc = "application/json";
		if(contentType.equalsIgnoreCase("XML")) {
			contentTypeDesc = "application/xml";
		}
		Response omsPOMockResponse = SerenityRest.given().relaxedHTTPSValidation().body(mockOMSPO)
				.header("Content-Type", contentTypeDesc)
				.post(environment.getProperty("oms_mock_admin_url"));
		Assert.assertEquals(ErrorCodes.OMS_PO_NOT_CREATED, Constants.CREATE_SUCESS_STATUS_CODE, omsPOMockResponse.getStatusCode());
		Response omsPOMockSaveResponse = SerenityRest.given().relaxedHTTPSValidation().body(mockOMSPO)
				.header("Content-Type", contentTypeDesc)
				.post(environment.getProperty("oms_mock_admin_save_url"));
		Assert.assertEquals(ErrorCodes.OMS_PO_NOT_SAVED, Constants.SUCESS_STATUS_CODE, omsPOMockSaveResponse.getStatusCode());
	}

	private String getChannelMethodText(String chnlMthdCd) {
		switch (chnlMthdCd) {
			case "1":
			case "4":
				return "Crossdock";
			case "2":
				return "Staplestock";
			default:
				return "";
		}
	}

	private String getUniquePONum() {
		String uniquePONum;
		int omsResponseStatusCodeJSON;
		int omsResponseStatusCodeXML;
		int faliureStatusCode = Constants.FALIURE_STATUS_CODE;
		do {
			uniquePONum = MOCK_PO_PREFIX + javaUtils.randonNumberGenerator(7);
			LOGGER.info("UniquePONum=" + uniquePONum);
			omsResponseStatusCodeJSON = getOMSResponse(uniquePONum, "JSON").getStatusCode();
			omsResponseStatusCodeXML = getOMSResponse(uniquePONum, "XML").getStatusCode();
		} while(omsResponseStatusCodeJSON != faliureStatusCode && omsResponseStatusCodeXML != faliureStatusCode);
		return uniquePONum;
	}

	public boolean verifyPOAlreadyExistsInOMS(String currentPONum, String contentType) {
		int omsResponseStatusCode = getOMSResponse(currentPONum, contentType).getStatusCode();
		LOGGER.info("OMS Response status code:{}", omsResponseStatusCode);
		boolean poAlreadyExistsInOMS = true;
		try {
			Assert.assertEquals(ErrorCodes.OMS_PO_DETAILS_NOT_FOUND, Constants.SUCESS_STATUS_CODE, omsResponseStatusCode);
		} catch (java.lang.AssertionError e) {
			if (omsResponseStatusCode == Constants.FALIURE_STATUS_CODE) {
				LOGGER.info("PO Number " + currentPONum + " was not found in OMS. Creating mock PO now");
				poAlreadyExistsInOMS = false;
			} else {
				throw new AutomationFailure("Mock OMS Server seems down.");
			}
		}
		return poAlreadyExistsInOMS;
	}

	private Response getOMSResponse(String currentPONum, String contentType) {
		String oms_ep_prefix = "oms_ep";
		String acceptType = "application/json";
		// In case of XML PO, accept type and get PO URL changes
		if(contentType.equalsIgnoreCase("XML")) {
			oms_ep_prefix = "oms_xml_ep";
			acceptType = "application/xml";
		}
		String omsUrl = environment.getProperty(oms_ep_prefix) + currentPONum + environment.getProperty("oms_ep_qp");
		LOGGER.info("OMS Url:{}", omsUrl);
		Response omsResponse = null;
		try {
			omsResponse = SerenityRest.given().accept(acceptType).get(omsUrl);
		} catch (RuntimeException re) {
			throw new AutomationFailure("Mock OMS Server seems down.");
		}
		return omsResponse;
	}
}
