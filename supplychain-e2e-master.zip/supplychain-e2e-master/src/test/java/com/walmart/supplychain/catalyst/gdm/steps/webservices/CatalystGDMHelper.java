package com.walmart.supplychain.catalyst.gdm.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.supplychain.domain.yms.YmsGateOut;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetailsRDC;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.RDCDeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.WitronItemDetails;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.jms.JMS_PROVIDER_TYPE;
import com.walmart.framework.utilities.jms.JMS_SUBSCRIPTION_TYPE;
import com.walmart.framework.utilities.jms.SchedulerConnectionUtil;
import com.walmart.framework.utilities.jms.SpringJmsUtils;
import com.walmart.framework.utilities.jms.StratiConnectionUtil;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.TextParser;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.common.PreRunCleanup;
import com.walmart.supplychain.nextgen.oms.gluecode.webservices.Oms;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystGDMHelper {
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;
	
	@Autowired
	Environment environment;
	
	Logger logger = LogManager.getLogger(this.getClass());
	String TEST_FLOW_DATA = "testFlowData";
	private String inboundDoorNumber = "";
	private static final String INBOUND_DOOR_JSONPATH = "$.testFlowData.deliveryDetails[0].inboundDoorNumber";
	private static final String WMT_USER_ID = "system";
	
	public String getDoorNumber() {
		try {
			String runTimeData;
			runTimeData = (String) tl.get().get(TEST_FLOW_DATA);
			if (runTimeData != null) {
				inboundDoorNumber = JsonPath.parse(runTimeData).read(INBOUND_DOOR_JSONPATH);
				return inboundDoorNumber;
			}
		} catch (PathNotFoundException e) {
			logger.info("Door is not yet assigned in Inbound");
		}
		return "";
	}
	
	
	public Headers getGDMHeaders() {

		return getIDMHeaders(null); 

	}
	
	public Headers getIDMHeaders(String eventType) {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		Header appType = new Header("Content-Type", "application/json");

		
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);

		if(eventType!=null) {
			Header eventTypeHeader = new Header("eventType", eventType.toUpperCase());
			headerList.add(eventTypeHeader);
		}
		if (Config.DC == DC_TYPE.CATALYST) {
			Header contentType = new Header("Content-Type", environment.getProperty("content_type"));
			headerList.add(contentType);
		}
		return new Headers(headerList);
	}
	
}
