package com.walmart.supplychain.rdc.gdm.steps.webservices;


import java.time.Clock;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.parsing.TextParser;

import net.jodah.failsafe.RetryPolicy;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class RdcGDMHelper {

	@Autowired
	TextParser textParser;

	@Autowired
	Environment environment;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	Logger logger = LogManager.getLogger(this.getClass());
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_15);

	private ArrayList<String> containerData;
	String testFlowData;

	private static final String PO_NUMBER_JSONPATH = "$..poDetails..poNumber";

	public String prepareShipmentData(String numOfpacksOnShipmentForEachPOLine, String loadNumber) throws Exception{
		try{
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			String containerLabel=null;
			String containerId=null;
			String asnNumber=null;
			String baseContainerData=null;
			baseContainerData = textParser.readTextFile(FileNames.RDC_CONTAINER_TEMPLATE_FILE);
			
			String destNumber=environment.getProperty("facility_num");
			String sourceNumber=environment.getProperty("consolidation_center_source");
			asnNumber = loadNumber+sourceNumber+destNumber;
			String asnDate = getCurrentDateAndTime();
			String bolNumber = sourceNumber+"-"+loadNumber;
			String invoiceNumber = sourceNumber+javaUtils.randonNumberGenerator(6);

			containerData = new ArrayList<String>();

			List<String> poNumberList = JsonPath.parse(testFlowData).read(PO_NUMBER_JSONPATH);
			for (int poNumberCount = 0; poNumberCount < poNumberList.size(); poNumberCount++) {
			
				List<String> poLineNumberList = JsonPath.parse(testFlowData).read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumberList.get(poNumberCount) + "')].poLineDetails..poLineNumber");
				List<String> poChannelTypeList = JsonPath.parse(testFlowData).read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumberList.get(poNumberCount) + "')].channelMethod");
					for (int polineCount = 0; polineCount < poLineNumberList.size(); polineCount++) {
						List<String> itemNumberList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].itemNumber");
						List<String> vnpkQtyList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].vnpk");
						List<String> whpkQtyList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].whpk");
						List<String> poQtyList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].poVnpkQty");
						List<String> itemUPCList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].itemUpc");
						List<String> whpkSellCostList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].whpkSellPrice");
						List<String> itemChannelTypeList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].channelMethod");
						List<String> itemChannelTypeCodeList = JsonPath.parse(testFlowData).read("$.testFlowData.poDetails[?(@.poNumber == '"+poNumberList.get(poNumberCount)+"')].poLineDetails[?(@.poLineNumber == '"+poLineNumberList.get(polineCount)+"')].omsChannelMethod");

						int poQty=Integer.valueOf(poQtyList.get(0));
						int vnpkQty=Integer.valueOf(vnpkQtyList.get(0));
						int whpkQty=Integer.valueOf(whpkQtyList.get(0));
						
						for (int packCount = 0; packCount < Integer.parseInt(numOfpacksOnShipmentForEachPOLine); packCount++) {
							containerLabel="AUTO"+javaUtils.randonNumberGenerator(7)+javaUtils.randonNumberGenerator(7);
							containerId = asnNumber+"_"+loadNumber+"_"+containerLabel;
							
							containerData.add(javaUtils.format(baseContainerData, containerId,containerLabel,asnNumber,asnDate,bolNumber,loadNumber,itemChannelTypeList.get(0),invoiceNumber,
									destNumber,sourceNumber,poNumberList.get(poNumberCount),poLineNumberList.get(polineCount),itemChannelTypeCodeList.get(0),itemNumberList.get(0),itemUPCList.get(0),
									String.valueOf(whpkQty),vnpkQtyList.get(0),whpkQtyList.get(0),whpkSellCostList.get(0)));
						}
						logger.info("Prepared Container Data for the item {}",itemNumberList.get(0));

					}
					logger.info("Prepared Container Data for the PO {}",poNumberList.get(poNumberCount));
					//			logger.info("Prepared PACK Data is : "+packData);
					//			logger.info("Prepared PALLET Data is : "+palletData);
			}
			return containerData.toString();
		}
		catch (Exception e) {
			logger.info("Something went wrong while preparing shipmnet data for RDC", e);
			throw e;
		}
	}
	
	public String getCurrentDateAndTime() {
		Clock clock = Clock.system(ZoneId.of("Asia/Calcutta"));
		return clock.instant().toString();
	}

	
}
