package com.walmart.supplychain.nextgen.of.scenariosteps.db;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import org.json.JSONException;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.supplychain.nextgen.of.steps.db.RDCOrderFulfillmentSteps;
import com.walmart.supplychain.nextgen.of.steps.webservices.OrderFulfillmentSteps;

public class RDCOrderFulfillmentScenario {

	@Steps
	RDCOrderFulfillmentSteps ofRDCSteps;

	@And("^user verifies that X-DOCK file is generated$")
	public void user_verifies_that_xdock_file_is_generated(){
		ofRDCSteps.vadlidateXDOCandDeliveryStatus();
	}
}
