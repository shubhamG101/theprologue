package com.walmart.supplychain.nextgen.op.steps.webservices;

import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class OrderTrackerValidationSteps extends ScenarioSteps {
    @Autowired(required=true)
    OrderTrackerHelper orderTrackerHelper;
    private Logger logger = LogManager.getLogger(this.getClass());
    private RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY, Constants.RETRY_EXECUTION_COUNT);

    @Step
    public void getAllOrderIDsForGivenStatus(String status) {
        Failsafe.with(retryPolicy).run(() -> {
            logger.info("Executing getAllOrderIDsForGivenStatus");
            orderTrackerHelper.checkOrderTrackerStatus(status);
            logger.info("Executed getAllOrderIDsForGivenStatus successfully for status: "+status);
        });
    }

    @Step
    public void  validatePickedQty(String status) {
        Failsafe.with(retryPolicy).run(() -> {
            logger.info("Executing validatePickedQty");
            Assert.assertTrue(orderTrackerHelper.checkPickedQtyInOrderTracker(status));
            logger.info("Executed validatePickedQty successfully");
        });
    }

    @Step
    public void validateStatusPostVTR(String status) {
        Failsafe.with(retryPolicy).run(() -> {
            logger.info("Executing validateStatusPostVTR");
            Assert.assertTrue(orderTrackerHelper.validateOrderTrackerPostVTR(status));
        });
    }
    
    @Step
    public void validatePickedLoadedShippedQtyInOrderTracker(String status) {
    	try {
    		orderTrackerHelper.checkPickedLoadedShippedQtyInOrderTracker(status);
    	} catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validting order status in Order Tracker",e);
		}
    }
    
    @Step
    public void validateOrderStatusAndFnlIndicator(String status, String fnlIndicator) {
    	try {
    		orderTrackerHelper.validateOTOrderStatusAndFnlindicator(status, fnlIndicator);
    	} catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validting order status and Fnl Indicator in Order Tracker",e);
		}
    }
    
    @Step
    public void validateOrderStatus(String status) {
    	try {
    		orderTrackerHelper.validateOTOrderStatus(status);
    	} catch(AssertionError|FailsafeException e) {
			throw new TestCaseFailure(e);
		}catch(Exception e) {
			throw new AutomationFailure("Something went wrong while validting order status Order Tracker",e);
		}
    }
}
