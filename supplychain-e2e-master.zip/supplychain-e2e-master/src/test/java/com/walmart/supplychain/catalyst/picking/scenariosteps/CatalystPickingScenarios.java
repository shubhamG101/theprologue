package com.walmart.supplychain.catalyst.picking.scenariosteps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.supplychain.catalyst.picking.steps.mobile.CatalystPickingSteps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class CatalystPickingScenarios {

	@Steps
	CatalystPickingSteps catalystPickingSteps;
	
	@Given("^user performs picking task$")
	public void userPerformsPicking() throws JsonProcessingException, InterruptedException {
		catalystPickingSteps.performPicking();
	}
}
