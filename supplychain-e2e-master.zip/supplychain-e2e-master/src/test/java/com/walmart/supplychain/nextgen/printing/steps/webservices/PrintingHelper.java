package com.walmart.supplychain.nextgen.printing.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.JsonPath;

import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = {SpringTestConfiguration.class})
public class PrintingHelper extends ScenarioSteps {
	@Autowired
	Environment environment;
	String emulatorServiceUrl="http://us32847s4000d0a.s32847.us.wal-mart.com:10117/printer-emulator-service/us/32847/emulator-services/start-printers";
	Logger logger = LogManager.getLogger(this.getClass());
	private String buildPrinterSearchUrl() {
		String printingUrl=environment.getProperty("printing_ep");
		logger.info("Printer url:{}",printingUrl);
		return printingUrl+"/printers";
	}
	public boolean isPrinterOnline(int printerId) {
		Response response = when().get(buildPrinterSearchUrl()+"/"+printerId);
		return JsonPath.read(response.asString(), "$.isOnline");
	}
	public int getPrinterId(String printerName) {
		try {
			Response response = given().get(buildPrinterSearchUrl());
			logger.info("Printer reponse {}",response.asString());
			JSONArray status = JsonPath.read(response.asString(), "$.[?(@.printerName == '"+printerName+"')].printerId");
			//response.then().statusCode(Constants.SUCESS_STATUS_CODE);
			if(status.size()>0)
				return Integer.parseInt(status.get(0).toString());
			else
				return 0;
		}catch(Exception ex) {
			ex.printStackTrace();
			return -1;
		}
		
	}
	public String getNewEmulatorConnectionString() {
		try {
		Date date=new Date();
		Response response=given().accept("application/json").contentType("application/json").body("[{\"printerType\":\"MONARCH\",\"printerName\":\"Emulator-"+date.getTime()+"\"}]").put(emulatorServiceUrl);
		System.out.println("PUT response:"+response.asString());
		String host = JsonPath.read(response.asString(), "$[0].hostName");
		int port = JsonPath.read(response.asString(), "$[0].printerConnectionPort");
		String connectionString="SOCKET://"+host+":"+port;
		return connectionString;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	}
	public int updatePrinterWithNewConnection(int printerId,String printerName,String connectionString) {
		try {
		Response response=given().accept("application/json").contentType("application/json").body("{\"printerName\":\""+printerName+"\",\"location\":\"\",\"enable\":\"true\",\"printerDescription\":\"dummy printer\",\"connectionString\":\""+connectionString+"\",\"printerType\":\"MONARCH\",\"printerMode\":\"Continuous\"}").put(buildPrinterSearchUrl()+"/"+printerId);
		System.out.println("PUT response:"+response.asString());
		return response.getStatusCode();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return 0;
		
	}
	public int createPrinterWithNewConnection(int printerId,String printerName,String connectionString) {
		try {
		Response response=given().accept("application/json").contentType("application/json").body("{\"printerName\":\""+printerName+"\",\"location\":\"\",\"enable\":\"true\",\"printerDescription\":\"dummy printer\",\"connectionString\":\""+connectionString+"\",\"printerType\":\"MONARCH\",\"printerMode\":\"Continuous\"}").post(buildPrinterSearchUrl());
		System.out.println("POST response:"+response.asString());
		return response.getStatusCode();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return 0;
		
	}



}
