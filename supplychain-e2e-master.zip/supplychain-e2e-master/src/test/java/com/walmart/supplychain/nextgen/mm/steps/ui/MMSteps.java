package com.walmart.supplychain.nextgen.mm.steps.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.supplychain.nextgen.mm.pages.ui.MMHomePage;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingHelper;
import net.minidev.json.JSONArray;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.nextgen.mm.pages.ui.MMLoginPage;
import com.walmart.supplychain.nextgen.receiving.steps.mobile.ReceivingSteps;

import io.restassured.response.Response;
import net.jodah.failsafe.FailsafeException;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class MMSteps extends ScenarioSteps {
//	MMLoginPage mmLoginPage;
//	PropertyResolver propertyResolver = new PropertyResolver();
//	Config config = new Config();

	@Autowired
	Environment environment;

	@Autowired
	MMLoginPage mmLoginPageWitron;

	@Autowired
	MMHomePage mmHomePage;

	@Autowired
	ReceivingHelper receivingHelper;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	private List<String> poNumberList;
	private DocumentContext parsedJson;
	private static final String TRACKING_ID_JSON_PATH = "$..trackingId";
	private List<String> trackingId = new ArrayList<String>();
	String testFlowData;
	Response response;
	Logger logger = LogManager.getLogger(ReceivingSteps.class);

//	@Step
//	public void open_MM_home_page() {
////		mmLoginPage.getUrl(config.mmUiUrl);
//	}

//	@Step
//	public void login_to_MM() {
//		mmLoginPage.enteruserIdField(propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "mm_username"));
//		mmLoginPage.enterPasswordField(propertyResolver.getPropertyValue(FileNames.ENVIRONMENT_FILE, "mm"));
//		mmLoginPage.clickLogInButton();
//	}

	@Step
	public void open_MM_home_page_Witron() {
		mmLoginPageWitron.getUrl(environment.getProperty("mm_app_url"));
	}

	@Step
	public void login_to_MM_Witron() {

		try {
			String LoginId = environment.getProperty("outbound_username");
			String pVal = environment.getProperty("outbound");

			String siteNumber = environment.getProperty("facility_num");

			String countryCode = environment.getProperty("country_code");

			mmLoginPageWitron.loginIntoMM(LoginId, pVal, siteNumber, countryCode);

		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while logging into MM Applications", e);
		}

	}

	@Step
	public void validateOhHoldContainer(String value) {

		List<String> onHoldContainer = null;
		List<String> receivedContainer = null;

		List<String> onHoldFinalContainerList = new ArrayList<String>();
		List<String> receivedFinalContainerList = new ArrayList<String>();
		List<String> allContainer = new ArrayList<String>();

//		threadLocal.get().put("testFlowData",
//				"{\"testFlowData\":{\"ordersDetails\":[],\"releaseDetails\":[],\"problemDetails\":[],\"poDetails\":[{\"poNumber\":\"023295438\",\"sourceNumber\":\"32612\",\"baseDiv\":\"1\",\"srcCountryCode\":\"US\",\"poStatus\":\"Active\",\"poLineDetails\":[{\"poLineNumber\":\"1\",\"itemNumber\":\"565878030\",\"poVnpkQty\":\"504\",\"vnpk\":\"6\",\"whpk\":\"6\",\"whpkSellPrice\":\"14.9\",\"ovgQty\":\"2016\",\"ti\":\"12\",\"hi\":\"21\",\"itemUpc\":\"00681131225052\",\"caseUpc\":\"10681131225059\",\"receivingInstructions\":[{\"parentContainer\":\"A32610000020513791\",\"isDamage\":false,\"isPbylTripExecuted\":false,\"isPbyl\":false,\"messageId\":\"e9880d64-51ac-42e8-84d7-e02b22507b9e\",\"channelType\":\"SSTKU\",\"destNumber\":\"32610\",\"rotateDate\":\"2021-01-21\",\"onHoldStatus\":true,\"vtrQty\":0,\"damageQty\":0,\"vtrContainerOrderIds\":[],\"receivedQuantity\":\"252\",\"isVTR\":false,\"isShipOut\":true,\"salesQty\":0,\"orderIds\":[],\"isGFCS\":false,\"palletHoldQty\":\"252\",\"adjustedQty\":0,\"childContainers\":[]},{\"parentContainer\":\"A32610000020513790\",\"messageId\":\"9b33f444-b8b3-4bd8-aa71-8279dad9f6f2\",\"childContainers\":[],\"receivedQuantity\":\"252\",\"channelType\":\"SSTKU\",\"destNumber\":\"32610\",\"isPbyl\":false,\"isShipOut\":true,\"isVTR\":false,\"isDamage\":false,\"orderIds\":[],\"vtrQty\":0,\"salesQty\":0,\"onHoldStatus\":false,\"isPbylTripExecuted\":false,\"isGFCS\":false,\"damageQty\":0,\"rotateDate\":\"2021-01-21\",\"adjustedQty\":0,\"vtrContainerOrderIds\":[]}],\"thorUnitsPer\":0,\"boh\":1913916,\"wac\":14.9763,\"promoInd\":\"N\",\"witronItemDetails\":{\"maxCube\":\"70.0\",\"warehouseRotationTypeCode\":\"2\",\"maxHeight\":\"90.0\",\"maxWeight\":\"2736.0\",\"outboundStackGroup\":\"Normal\",\"shipGroupId\":\"10034\",\"isMergeable\":true,\"weight\":\"3.8\",\"height\":\"2.1\",\"width\":\"8.9\",\"depth\":\"13.8\",\"wareHouseGroupCode\":\"F\",\"wareHouseAreaCode\":\"4\",\"samePalletIndicator\":\"1\",\"xrefId\":\"756991\",\"profiledWarehouseArea\":\"OPM\",\"receiveDate\":\"2021-01-21\",\"mergeable\":true},\"isVariableWeight\":false,\"weight\":0.0,\"damageQty\":\"0\",\"shortQty\":\"0\",\"rejectQty\":\"0\",\"waw\":0.0,\"totalWeight\":0.0,\"averageWeightPerCase\":3.8,\"croInd\":\"cro\",\"recvQty\":504,\"osdrInd\":\"s\",\"problemQty\":\"0\",\"problemType\":\"noProblem\"},{\"poLineNumber\":\"2\",\"itemNumber\":\"566163978\",\"poVnpkQty\":\"162\",\"vnpk\":\"20\",\"whpk\":\"20\",\"whpkSellPrice\":\"14.9\",\"ovgQty\":\"648\",\"ti\":\"9\",\"hi\":\"10\",\"itemUpc\":\"00260948000009\",\"caseUpc\":\"10260948000006\",\"receivingInstructions\":[{\"parentContainer\":\"B32610000020611403\",\"isDamage\":false,\"isPbylTripExecuted\":false,\"isPbyl\":false,\"messageId\":\"712afd75-1563-47ca-8912-564e3fb0384b\",\"channelType\":\"SSTKU\",\"destNumber\":\"32610\",\"rotateDate\":\"2021-02-20\",\"onHoldStatus\":true,\"vtrQty\":0,\"damageQty\":0,\"vtrContainerOrderIds\":[],\"receivedQuantity\":\"81\",\"isVTR\":false,\"isShipOut\":true,\"salesQty\":0,\"orderIds\":[],\"isGFCS\":false,\"palletHoldQty\":\"81\",\"adjustedQty\":0,\"childContainers\":[]},{\"parentContainer\":\"A32610000020511149\",\"messageId\":\"c492ead3-97f5-47c5-a7c8-4544e5be44c0\",\"childContainers\":[],\"receivedQuantity\":\"81\",\"channelType\":\"SSTKU\",\"destNumber\":\"32610\",\"isPbyl\":false,\"isShipOut\":true,\"isVTR\":false,\"isDamage\":false,\"orderIds\":[],\"vtrQty\":0,\"salesQty\":0,\"onHoldStatus\":false,\"isPbylTripExecuted\":false,\"isGFCS\":false,\"damageQty\":0,\"rotateDate\":\"2021-02-20\",\"adjustedQty\":0,\"vtrContainerOrderIds\":[]}],\"thorUnitsPer\":0,\"boh\":2845780,\"wac\":241.6808,\"promoInd\":\"N\",\"witronItemDetails\":{\"maxCube\":\"70.0\",\"warehouseRotationTypeCode\":\"3\",\"maxHeight\":\"90.0\",\"maxWeight\":\"2736.0\",\"outboundStackGroup\":\"Normal\",\"shipGroupId\":\"10025\",\"isMergeable\":true,\"weight\":\"15.9\",\"height\":\"5.0\",\"width\":\"10.0\",\"depth\":\"22.5\",\"wareHouseGroupCode\":\"M\",\"wareHouseAreaCode\":\"1\",\"samePalletIndicator\":\"1\",\"xrefId\":\"0\",\"profiledWarehouseArea\":\"CPS\",\"receiveDate\":\"2021-09-02\",\"mergeable\":true},\"isVariableWeight\":true,\"weight\":0.0,\"damageQty\":\"0\",\"shortQty\":\"0\",\"rejectQty\":\"0\",\"waw\":15.9,\"totalWeight\":2262395.1,\"averageWeightPerCase\":15.9,\"croInd\":\"cro\",\"recvQty\":162,\"osdrInd\":\"s\",\"problemQty\":\"0\",\"problemType\":\"noProblem\"}],\"uuid\":[\"3a5154d5-db37-47c8-93d1-cc97ed282596\"],\"zonetemperatures\":\"-10.0#0.0#10.0\"}],\"deliveryDetailsRDC\":[],\"deliveryDetails\":[{\"inboundDoorNumber\":\"119\",\"itemLabelId\":[],\"inboundTrailerNumber\":\"T86340120\",\"poNumbers\":[\"023295438\"],\"dockTags\":[],\"doorType\":\"online\",\"deliveryName\":\"D1\",\"shipments\":[],\"deliveryNumber\":\"86340120\",\"deliveryStatus\":\"Create_Delivery\"}],\"outboundDetails\":[],\"containerDetails\":[]}}");

		try {
			testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
			parsedJson = JsonPath.parse(testFlowData);
			logger.info("Testflow data before IDM DB update : {}", testFlowData);
			poNumberList = parsedJson.read("$.testFlowData.deliveryDetails..poNumbers[*]");

			for (String poNumber : poNumberList) {

				List<String> poLineNumbers = parsedJson.read(
						"$.testFlowData.poDetails[?(@.poNumber == '" + poNumber + "')].poLineDetails..poLineNumber");
				for (String poLineNumber : poLineNumbers) {
					logger.info("Po Number{} " + poLineNumber);

					if (value.contains("rtc")) {
						allContainer = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
								+ "')].receivingInstructions[*].parentContainer");
					} else {
						onHoldContainer = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
								+ "')].receivingInstructions[?(@.onHoldStatus == true)].parentContainer");
//					logger.info("container hold {} ", onHoldContainer.get(0).toString());
//					onHoldFinalContainerList.add(onHoldContainer.get(0).toString());

						receivedContainer = parsedJson.read("$.testFlowData.poDetails[?(@.poNumber == '" + poNumber
								+ "')].poLineDetails[?(@.poLineNumber == '" + poLineNumber
								+ "')].receivingInstructions[?(@.onHoldStatus == false)].parentContainer");
//					logger.info("container received {} ", receivedContainer.get(0).toString());
//
//					receivedFinalContainerList.add(receivedContainer.get(0).toString());
					}

				}
			}
			if (value.contentEquals("holdContainer")) {
				mmLoginPageWitron.validateContainerStatus(onHoldContainer, value);

			} else if (value.contentEquals("receivedContainer")) {
				mmLoginPageWitron.validateContainerStatus(receivedContainer, value);

			} else {
				mmLoginPageWitron.validateContainerStatus(allContainer, value);

			}

		}

		catch (Exception e) {
			throw new AutomationFailure("Something went wrong while Move Creation and Validation", e);
		}

	}

	@Step
	public void validate_move_status(String moveStatus, String delvryName) throws Exception {
		testFlowData = String.valueOf(threadLocal.get().get("testFlowData"));
		JSONArray delNum = JsonPath.read(testFlowData, "$.testFlowData.deliveryDetails[?(@.deliveryName=='" + delvryName + "')].deliveryNumber");
		String deliveryNbr = delNum.get(0).toString();
		String deliveryContainerResponse = receivingHelper.containerResponseForDelivery(deliveryNbr);
		trackingId = JsonPath.parse(deliveryContainerResponse).read(TRACKING_ID_JSON_PATH);
		logger.info("tracking id is " + trackingId.get(0));
		String actualMoveStatus = mmHomePage.moveStatus(trackingId.get(0));
		logger.info("actualMoveStatus  is " + actualMoveStatus);
		Assert.assertEquals(ErrorCodes.MOVE_STATUS_NOT_UPDATED, moveStatus,
				actualMoveStatus);
	}
}
