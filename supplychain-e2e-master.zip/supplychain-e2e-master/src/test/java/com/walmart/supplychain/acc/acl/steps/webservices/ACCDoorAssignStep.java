package com.walmart.supplychain.acc.acl.steps.webservices;

import static net.serenitybdd.rest.SerenityRest.given;
import static net.serenitybdd.rest.SerenityRest.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.parsing.PropertyResolver;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;
import com.walmart.supplychain.acc.acl.db.ACCMongoSteps;
import com.walmart.supplychain.acc.acl.db.ACLDBSteps;
import com.walmart.supplychain.acc.docktag.steps.mobile.DockTagHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import kafka.utils.threadsafe;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ACCDoorAssignStep {
	PropertyResolver propertyResolver = new PropertyResolver();
	Logger logger = LogManager.getLogger(this.getClass());
	Config config = new Config();
	ObjectMapper objectMapper = new ObjectMapper();
	JsonUtils jsonUtil = new JsonUtils();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String CHANNEL_FLIP = "$..isChannelFlipRequired";
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	boolean retry = false;
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_LABEL_COLLECTION = "deliverydocumentsbylpns";
	private static final String MONGO_SCHEMA = "receive";
	private static final String WMT_USER_ID = "system";
	String delivery = "";
	List itemLabelList = null;
	private Response aclLabelResponse=null;

	@Autowired
	ThreadLocal<HashMap<String, Object>> tl;

	@Autowired
	ACLDBSteps aclDBSteps;

	@Autowired
	ACCMongoSteps accMongoSteps;
	Map lpnLabelsMap;

	@Autowired
	DockTagHelper dockTagHelper;
	
	@Autowired
	Environment environment;

	private static final String JSON_PATH_DELIVERY = "$.testFlowData.deliveryDetails[*].deliveryNumber";

	@Step
	public void validateLabels(String labelType) {

		try {
			Thread.sleep(5000);
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			String updatedtestflowdata = testData;

			JSONArray channelFlipStatus = JsonPath.read(testData, CHANNEL_FLIP);
			if (channelFlipStatus.get(0).toString().equals("true")) {
				logger.info("Inside channel flip");

				updatedtestflowdata = jsonUtil.setJsonAtJsonPath(updatedtestflowdata, "CROSSU",
						"$..testFlowData.poDetails[*].channelMethod");

				updatedtestflowdata = jsonUtil.setJsonAtJsonPath(updatedtestflowdata, "CROSSU",
						"$..testFlowData.poDetails[*].poLineDetails[*].channelMethod");

				logger.info(updatedtestflowdata);

				tl.get().put(TEST_FLOW_DATA, updatedtestflowdata);
				testData = String.valueOf(tl.get().get(TEST_FLOW_DATA));
				logger.info("TestFlowData after updating channel method for channel flip scenario {}", testData);
			}

			JSONArray listOfDeliveries = JsonPath.read(testData, JSON_PATH_DELIVERY);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> vtrCntrList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = vtrCntrList.get(0);

			JSONArray listOfPOs = JsonPath.read(testData, GET_PONUMBERS);
			String poJson = null;
			poJson = objectMapper.writeValueAsString(listOfPOs);
			@SuppressWarnings("unchecked")
			List<PoDetail> poDetailList;

			poDetailList = (List<PoDetail>) jsonUtil.getPojoListfromPath(poJson, PoDetail.class);

			List<PoDetail> listOfPOObj = new ArrayList<>();
			for (PoDetail poObj : poDetailList) {
				String poNum = poObj.getPoNumber();
				List poLineDetailsList = new ArrayList();
				validateNonConveyableFrieghts();
				JSONArray listOfPOLines = JsonPath.read(testData, "$.testFlowData.poDetails[?(@.poNumber == \"" + poNum
						+ "\")].poLineDetails[?((@.channelMethod == \"CROSSU\" || @.channelMethod == \"CROSSMU\") && @.isConveyable == \"true\")]");
				String poLineJson = null;
				poLineJson = objectMapper.writeValueAsString(listOfPOLines);
				List<PoLineDetail> poLineDetails;
				poLineDetails = (List<PoLineDetail>) jsonUtil.getPojoListfromPath(poLineJson, PoLineDetail.class);
				Assert.assertNotEquals(ErrorCodes.LABEL_ERROR_MSG, 0, poLineDetails.size());

				for (PoLineDetail poLineObj : poLineDetails) {
					List totalLPNLabelsList = new ArrayList();
					List recvingInstructionList = new ArrayList();
					String itemNbr = poLineObj.getItemNumber();
					double poQty;
					
					try {
						 poQty =  Integer.parseInt(poLineObj.getPoUpdateQty());
					} catch (NumberFormatException e) {
						logger.info("PO update qty present in the instrcution");
						 poQty = Integer.parseInt(poLineObj.getPoVnpkQty());
					}

					int ovgQty = Integer.parseInt(poLineObj.getOvgQty());
					double calcul = 15.00 * Double.parseDouble(poLineObj.getPoVnpkQty()) / 100;
					int exceptionQty = (int) Math.round(calcul);
					
					if(exceptionQty==0) {
						exceptionQty=1;
					}
					
					logger.info("Expected exception qty: " + exceptionQty);

					Failsafe.with(retryPolicy).run(() -> {
						Thread.sleep(20000);
					aclLabelResponse = given().relaxedHTTPSValidation().headers(getReceivingHeaders()).when()
							.get(environment.getProperty("get_acl_labels_for_delivery") + deliveryNum);
					Assert.assertEquals(ErrorCodes.RECEIVING_ACL_LABEL_DATA_NOTFOUND, Constants.SUCESS_STATUS_CODE, aclLabelResponse.getStatusCode());
					
					});
					DocumentContext aclLabelResponseJson = JsonPath.parse(aclLabelResponse.getBody().asString());
					List<String> opnLpnlist = aclLabelResponseJson.read("$..[?(@.labelType=='ORDERED' && @.purchaseReferenceNumber=='"+poNum+"' && @.itemNumber=="+itemNbr+")].lpns");
					List<String> ovgLpnlist = aclLabelResponseJson.read("$..[?(@.labelType=='OVERAGE' && @.purchaseReferenceNumber=='"+poNum+"' && @.itemNumber=="+itemNbr+")].lpns");
					List<String> expLpnlist = aclLabelResponseJson.read("$..[?(@.labelType=='EXCEPTION' && @.purchaseReferenceNumber=='"+poNum+"' && @.itemNumber=="+itemNbr+")].lpns");

					List lpnLabels = null;
					List ovgLabels = null;
					List exceptionLabels = null;
					if(labelType.equalsIgnoreCase("ZERO")){
						Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_ACL, totalLPNLabelsList.size(),
								0);
						logger.info("Labels are NOT persisted in ACL labels DB");
					} else {
						String opnLpnStr=opnLpnlist.get(0).replace("\\", "");
						opnLpnStr=opnLpnStr.replace("\"", "");
						opnLpnStr=opnLpnStr.replace("[", "");
						opnLpnStr=opnLpnStr.replace("]", "");
						String ovgLpnStr=ovgLpnlist.get(0).replace("\\", "");
						ovgLpnStr=ovgLpnStr.replace("\"", "");
						ovgLpnStr=ovgLpnStr.replace("[", "");
						ovgLpnStr=ovgLpnStr.replace("]", "");
						String expLpnStr=expLpnlist.get(0).replace("\\", "");
						expLpnStr=expLpnStr.replace("\"", "");
						expLpnStr=expLpnStr.replace("[", "");
						expLpnStr=expLpnStr.replace("]", "");

						lpnLabels = Arrays.asList(opnLpnStr.split(","));
						ovgLabels = Arrays.asList(ovgLpnStr.split(","));
						exceptionLabels = Arrays.asList(expLpnStr.split(","));

						logger.info("Normal lpn labels:" + lpnLabels);
						logger.info("Allowable Overage lpn labels:" + ovgLabels);
						logger.info("Exception lpn labels:" + exceptionLabels);

						totalLPNLabelsList.addAll(lpnLabels);
						totalLPNLabelsList.addAll(ovgLabels);
						totalLPNLabelsList.addAll(exceptionLabels);

						Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_NORMAL, poQty, (double) lpnLabels.size());
						Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_OVERAGE, ovgQty, ovgLabels.size());

						Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_EXCEPTION, exceptionQty,
								exceptionLabels.size());
						Failsafe.with(retryPolicy).run(() -> {
							int dbLabelsCnt = aclDBSteps.getLabelCountFromACL(totalLPNLabelsList);

						// Commenting due to setup issue
							Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_ACL, totalLPNLabelsList.size(),
									dbLabelsCnt);
							logger.info("Labels are persisted successfully in ACL labels DB");
						});
					}
					if(labelType.equalsIgnoreCase("ZERO")) {
						// do nothing
					} else if (labelType.equalsIgnoreCase("PO_OPEN_QTY")) {
						for (int i = 0; i < lpnLabels.size(); i++) {
							ReceivingInstruction recv = new ReceivingInstruction();
							List childList = new ArrayList();
							String cntr = (String) lpnLabels.get(i);
							childList.add(cntr);
							recv.setParentContainer(cntr);
							recv.setLabelType("normal");
							recv.setDestNumber("");
							recv.setChildContainers(childList);
							recv.setChannelType(poLineObj.getChannelMethod());
							recv.setIsPbyl(false);
							recv.setIsVTR(false);
							recv.setIsDamage(false);
							recv.setReceivedQuantity("1");
							recvingInstructionList.add(recv);
						}

					} else {
						for (int i = 0; i < lpnLabels.size(); i++) {
							ReceivingInstruction recv = new ReceivingInstruction();
							List childList = new ArrayList();
							String cntr = (String) lpnLabels.get(i);
							childList.add(cntr);
							recv.setParentContainer(cntr);
							recv.setLabelType("normal");
							recv.setDestNumber("");
							recv.setChildContainers(childList);
							recv.setChannelType(poLineObj.getChannelMethod());
							recv.setIsPbyl(false);
							recv.setIsVTR(false);
							recv.setIsDamage(false);
							recv.setReceivedQuantity("1");
							recvingInstructionList.add(recv);

						}

						for (int i = 0; i < ovgLabels.size(); i++) {
							ReceivingInstruction recv = new ReceivingInstruction();
							List childList = new ArrayList();
							String cntr = (String) ovgLabels.get(i);
							childList.add(cntr);
							recv.setParentContainer(cntr);
							recv.setLabelType("normal");
							recv.setDestNumber("");
							recv.setChildContainers(childList);
							recv.setChannelType(poLineObj.getChannelMethod());
							recv.setIsPbyl(false);
							recv.setIsVTR(false);
							recv.setIsDamage(false);
							recv.setReceivedQuantity("1");
							recvingInstructionList.add(recv);

						}

						for (int i = 0; i < exceptionLabels.size(); i++) {
							ReceivingInstruction recv = new ReceivingInstruction();
							List childList = new ArrayList();
							String cntr = (String) exceptionLabels.get(i);
							childList.add(cntr);
							recv.setParentContainer(cntr);
							recv.setLabelType("exception");
							recv.setDestNumber("");
							recv.setChildContainers(childList);
							recv.setChannelType(poLineObj.getChannelMethod());
							recv.setIsPbyl(false);
							recv.setIsVTR(false);
							recv.setIsDamage(false);
							recv.setReceivedQuantity("1");
							recvingInstructionList.add(recv);

						}
					}
					poLineObj.setReceivingInstructions(recvingInstructionList);
					poLineDetailsList.add(poLineObj);

				}

				poObj.setPoLineDetails(poLineDetailsList);
				listOfPOObj.add(poObj);
			}
			// String updatedtestflowdata;
			JSONArray listofPOJson = jsonUtil.converyListToJsonArray(listOfPOObj);
			updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofPOJson, "$.testFlowData.poDetails");
			tl.get().put(TEST_FLOW_DATA, updatedtestflowdata);
			logger.info("test flow data after building the receiving instruction for all the labels:"
					+ tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate labels in acl", e);
		}

	}

	@Step
	public void validateDoorNumber() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfDelivery = JsonPath.read(testData, "$.testFlowData.deliveryDetails[*]");
			String listOfDeliveryString = listOfDelivery.toJSONString();
			logger.info("Outbound List {}", listOfDeliveryString);
			List<DeliveryDetail> deliveryList = null;
			deliveryList = objectMapper.readValue(listOfDeliveryString, new TypeReference<List<DeliveryDetail>>() {
			});
			List deliveryListNew = new ArrayList();

			for (DeliveryDetail deliveryObj : deliveryList) {
				Failsafe.with(retryPolicy).run(() -> {
					String doorActual = aclDBSteps.getDoorNumber(deliveryObj.getDeliveryNumber());
					Assert.assertEquals(ErrorCodes.ACL_DOOR_MISMATCH, deliveryObj.getInboundDoorNumber(), doorActual);
					List itemLabelList = aclDBSteps.getItemLabelsForDelivery(deliveryObj.getDeliveryNumber());
					deliveryObj.setItemLabelId(itemLabelList);
					deliveryListNew.add(deliveryObj);

				});
			}

			String updatedtestflowdata;
			JSONArray listofDeliveryJson = jsonUtil.converyListToJsonArray(deliveryListNew);
			updatedtestflowdata = jsonUtil.setJsonAtJsonPath(testData, listofDeliveryJson,
					"$.testFlowData.deliveryDetails");
			tl.get().put(TEST_FLOW_DATA, updatedtestflowdata);
			logger.info("test flow data after building the receiving instruction for all the labels:"
					+ tl.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate door number in acl", e);

		}

	}

	public void validateFloorNumber() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfDelivery = JsonPath.read(testData, "$.testFlowData.deliveryDetails[*]");
			String listOfDeliveryString = listOfDelivery.toJSONString();
			logger.info("Outbound List {}", listOfDeliveryString);
			List<DeliveryDetail> deliveryList = null;
			deliveryList = objectMapper.readValue(listOfDeliveryString, new TypeReference<List<DeliveryDetail>>() {
			});
			for (DeliveryDetail deliveryObj : deliveryList) {
				Failsafe.with(retryPolicy).run(() -> {
					String mappedFloorLine = dockTagHelper.getFloorLineForTheDoor(deliveryObj.getInboundDoorNumber());
					String doorActual = aclDBSteps.getDoorNumber(deliveryObj.getDeliveryNumber());
					Assert.assertEquals(ErrorCodes.ACL_DOOR_MISMATCH, mappedFloorLine, doorActual);
				});
				logger.info("Validated Floor line for the delivery {}", deliveryObj);
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Floor number in acl", e);

		}

	}

	@Step
	public void validateCompleteDeliveryForACL() {
		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);
			JSONArray listOfDelivery = JsonPath.read(testData, "$.testFlowData.deliveryDetails[*]");
			String listOfDeliveryString = listOfDelivery.toJSONString();
			logger.info("Outbound List {}", listOfDeliveryString);
			List<DeliveryDetail> deliveryList = null;
			deliveryList = objectMapper.readValue(listOfDeliveryString, new TypeReference<List<DeliveryDetail>>() {
			});
			delivery = deliveryList.get(0).getDeliveryNumber();
			itemLabelList = deliveryList.get(0).getItemLabelId();

			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Checking whether data cleared in ITEM_LABEL table for delievry {}", delivery);
				Assert.assertEquals(ErrorCodes.ACL_COMPLETE_DELIVERY_ITEM_LABEL, 0,
						aclDBSteps.getItemLabelsForDelivery(delivery).size());
				logger.info("Data cleared in ITEM_LABEL table for delivery {}", delivery);
			});
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Checking whether data cleared in LABEL_GRP table for delievry {}", delivery);
				Assert.assertEquals(ErrorCodes.ACL_COMPLETE_DELIVERY_LABEL_GRP, 0,
						aclDBSteps.getLabelGrpMappingCount(delivery));
				logger.info("Data cleared in LABEL_GROUP_MAPPING table for delivery {}", delivery);
			});
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("Checking whether data cleared in LABEL_DATA table for delievry {}", delivery);
				Assert.assertEquals(ErrorCodes.ACL_COMPLETE_DELIVERY_LABEL_DATA, 0,
						aclDBSteps.getLabelDataCount(itemLabelList));
				logger.info("Data cleared in LABEL_DATA table for delivery {}", delivery);
			});

		} catch (Exception e) {
			throw new AutomationFailure("Complete delivery validation Failed in acl", e);
		}

	}

	public void validateNonConveyableFrieghts() {

		try {

			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray listOfDeliveries = JsonPath.read(testData, JSON_PATH_DELIVERY);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> vtrCntrList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = vtrCntrList.get(0);

			JSONArray listOfPOs = JsonPath.read(testData, GET_PONUMBERS);
			String poJson = null;
			poJson = objectMapper.writeValueAsString(listOfPOs);
			@SuppressWarnings("unchecked")
			List<PoDetail> poDetailList;

			poDetailList = (List<PoDetail>) jsonUtil.getPojoListfromPath(poJson, PoDetail.class);

			List<PoDetail> listOfPOObj = new ArrayList<>();
			for (PoDetail poObj : poDetailList) {
				String poNum = poObj.getPoNumber();
				List poLineDetailsList = new ArrayList();
				JSONArray listOfPOLines = JsonPath.read(testData, "$.testFlowData.poDetails[?(@.poNumber == \"" + poNum
						+ "\")].poLineDetails[?(@.channelMethod == \"SSTKU\" || (@.channelMethod == \"CROSSU\" && @.isConveyable == \"false\") || (@.channelMethod == \"CROSSMU\" && @.isConveyable == \"false\" ))]");
				String poLineJson = null;
				poLineJson = objectMapper.writeValueAsString(listOfPOLines);

				if (listOfPOLines.size() != 0) {
					List<PoLineDetail> poLineDetails;
					poLineDetails = (List<PoLineDetail>) jsonUtil.getPojoListfromPath(poLineJson, PoLineDetail.class);
					for (PoLineDetail poLineObj : poLineDetails) {
						String itemNbr = poLineObj.getItemNumber();
						Failsafe.with(retryPolicy).run(() -> {
							String status = accMongoSteps.getProcessedLabelsForDelivery(MONGO_SCHEMA,
									GET_LABEL_COLLECTION, deliveryNum, poNum, itemNbr);
							Assert.assertEquals(ErrorCodes.LABEL_COUNT_MISMATCH_NONCON, "NO_NEED_TO_PROCESS", status);
							logger.info("status of non con items is :" + status);
						});
					}
				} else {
					logger.info("There are no non conveyable or SSTK items in the Delivery");
				}
			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate SSTK and non-con labels in acl", e);
		}

	}

	public void getExceptionLabels() {

		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray listOfDeliveries = JsonPath.read(testData, JSON_PATH_DELIVERY);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> delNumberList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = delNumberList.get(0);
			logger.info("Delivery number is " + deliveryNum);

			String exceptionURL = aclDBSteps.getExceptionURl(deliveryNum);
			logger.info("Exeption URL " + exceptionURL);

			Response response = given().relaxedHTTPSValidation().headers(getReceivingHeaders()).when()
					.get(exceptionURL);
			logger.info("Waiting for Status 200 for Exception URL:{}");

			Assert.assertEquals(ErrorCodes.RECEIVING_EXCEPTION_LABELS, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
			logger.info("Validated the response status returned for the exceptionURL");
			Assert.assertTrue(ErrorCodes.RECEIVING_EXCEPTION_LABELS, getLpnDetails(response));
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while fetching exception lables from exception URL", e);
		}

	}

	private boolean getLpnDetails(Response response) {
		boolean getLPNDetails = false;
		logger.info("Validating the body for the exception generation response");
		JSONArray listOfLpn = JsonPath.read(response.getBody().asString(), "$..lpns");
		if (!listOfLpn.isEmpty()) {
			getLPNDetails = true;
		}
		return getLPNDetails;
	}

	public void verifyLabelRejected(String labelStatus) {

		try {
			String testData = (String) tl.get().get(TEST_FLOW_DATA);

			JSONArray listOfDeliveries = JsonPath.read(testData, JSON_PATH_DELIVERY);
			String deliveryString = listOfDeliveries.toJSONString();
			List<String> delNumberList = objectMapper.readValue(deliveryString, new TypeReference<List<String>>() {
			});
			String deliveryNum = delNumberList.get(0);
			logger.info("Delivery number is " + deliveryNum);

			String rejectCode = aclDBSteps.getRejectCode(deliveryNum);
			logger.info("Reject Code " + rejectCode);
			
			if(labelStatus.equals("Rejected")) {
				Assert.assertEquals(ErrorCodes.ACL_REJECT_CODE, "GLS-RCV-BE-0001", rejectCode);
			} else {
				Assert.assertEquals(ErrorCodes.ACL_REJECT_CODE, "", rejectCode);
			}
		
		} catch (AssertionError | FailsafeException e) {
			throw new TestCaseFailure(e);
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while reject code details from ACL DB", e);
		}
		
	}
	
	public Headers getReceivingHeaders() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		Header appType = new Header("Content-Type", "application/json");
		
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);
		return new Headers(headerList);
	}
}
