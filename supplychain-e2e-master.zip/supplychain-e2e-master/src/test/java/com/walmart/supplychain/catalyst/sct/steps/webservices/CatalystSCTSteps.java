package com.walmart.supplychain.catalyst.sct.steps.webservices;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.witron.ExpectedPicks;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OrdersDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.OutboundDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ReceivingInstruction;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import spring.SpringTestConfiguration;
import io.restassured.response.Response;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CatalystSCTSteps extends ScenarioSteps  {

	
	Logger LOGGER = LogManager.getLogger(this.getClass());	
	
	@Autowired
	CatalystSCTHelper catalystSCTHelper;

	String responseBody;

	@Autowired
	Environment environment;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadlocal;
	
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT_5);

	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";

	private static final String GET_INBOUND_DOOR_NUMBER= "$.testFlowData.deliveryDetails..inboundDoorNumber";
	private static final String TEST_FLOW_DATA = "testFlowData";
	private static final String GET_ORDERS = "$.testFlowData.ordersDetails[*]";
	private static final String GET_OUTBOUND = "$.testFlowData.outboundDetails[*]";

	private static final String SCT_UNLOAD_USER_ID = "$..unload_user_id";
	private static final String SCT_OPEN_DOOR_USER_ID = "$..door_open_user_id";
	private static final String SCT_MASTER_CONTAINER_ID="$..master_container_id";
	private static final String SCT_DOC_NUMBER="$..doc_number";
	private static final String SCT_ITEM_NUMBER="$..item_nbr";
	private static final String SCT_ITEM_QTY="$..item_qty";
	private static final String SCT_DOOR_NUMBER= "$..door_num";
	private static final String SCT_DELIVERY_STATUS="$..delivery_status";	
	private static final String SCT_INVENTORY_STATUS="$..inventory_status";
	private static final String SCT_DOOR_CLOSE_USER_ID="$..door_close_user_id";
	private static final String SCT_DOOR_CLOSE_REASON= "$..door_close_reason";
	private static final String SCT_DELIVERY_COMPLETE_USER_ID="$..delivery_complete_user_id";
	private static final String SCT_TOTAL_DAMAGE_QTY="$..tot_damage_qty";
	private static final String SCT_PICKED_UNIT_QTY="$..picked_unit_qty";
	private static final String SCT_ALLOCATION_ORDER_ID="$..alloc_order_id";
	private static final String SCT_CONTAINER_ID="$..container_id";
	private static final String SCT_PICK_STATUS="$..pick_status";
	private static final String SCT_STORE_ORDER_NUMBER="$..so_number";
	private static final String SCT_ALLOCATION_ORDER_STATUS="$..ao_order_status";
	private static final String SCT_DESTINATION_STORE_NUMBER="$..dest_store_nbr";
	private static final String SCT_STORE_ORDER_STATUS="$..so_order_status";
	private static final String SCT_ORDER_QTY="$..order_qty";
	private static final String SCT_ALLOCATION_ORDER_LINE_ORDER_STATUS="$..ao_line_order_status";
	private static final String SCT_ALLOC_TO_PICK_QTY="$..alloc_to_pick_qty";
	private static final String SCT_TOTAL_ALLOC_QTY="$..ao_line_order_status";
	private static final String SCT_DESTINATION_BU_NUMBER="$..dest_bu_number";
	private static final String SCT_STORE_ORDER_LINE_ORDER_STATUS="$..so_line_order_status";


	ObjectMapper om = new ObjectMapper();


	@Step
	public void validateDeliveryAfterUnload(String entityType) {
		try {
			
			String expectedUserID="slInAdapter_";
			String testFlowData = (String) threadlocal.get().get(TEST_FLOW_DATA);
			List<String> unloadDoorNumber=JsonPath.read(testFlowData, GET_INBOUND_DOOR_NUMBER);	
			
			Failsafe.with(retryPolicy).run(() -> {

				responseBody=catalystSCTHelper.getSCTResponse(entityType);
				List<String> actualUnloadUserId = JsonPath.read(responseBody, SCT_UNLOAD_USER_ID);
				LOGGER.info("Expected Unload User ID: "+ actualUnloadUserId.get(0));
				Assert.assertTrue(ErrorCodes.CATALYST_SCT_UNLOAD_USERID_MISMATCH,  actualUnloadUserId.get(0).toLowerCase().contains(expectedUserID.toLowerCase()));
				
			});
			
			List<String> doorOpenUserId = JsonPath.read(responseBody, SCT_OPEN_DOOR_USER_ID);
			List<String> sctDoorNum = JsonPath.read(responseBody,SCT_DOOR_NUMBER);
			LOGGER.info("Expected unload door: "+ unloadDoorNumber.get(0));
			LOGGER.info("SCT Delivery Response Door Open User ID: "+ doorOpenUserId.get(0));
			
			Assert.assertTrue(ErrorCodes.CATALYST_SCT_DOOR_OPEN_USERID_MISMATCH,  doorOpenUserId.get(0).toLowerCase().contains(expectedUserID.toLowerCase()));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DOOR_NUM_MISMATCH, unloadDoorNumber.get(0), sctDoorNum.get(0));
			
			LOGGER.info("Successfully Validated Delivery After Unload");
			
		} catch (Exception e) {	
			throw new AutomationFailure("Failed to validate Delivery after unload in SCT", e);
		}
	}



	@Step
	public void validateDeliveryAfterFirstReceipt(String entityType) {
		try {
			
			int recvQty = 0;
			int receivedQtyInEaches=0;
			String receivedItemNumber="";
			String lpn = "";
			String receiveStatus = "";
			String expectedreceiveStatus="";
			String testFlowData = (String) threadlocal.get().get(TEST_FLOW_DATA);
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			for (PoDetail poDetail : poList) {
				String receivedPoNumber=poDetail.getPoNumber();
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				for (PoLineDetail poLineDetail : poLineList) {
					List<ReceivingInstruction> recvInstrList = poLineDetail.getReceivingInstructions();
					for (ReceivingInstruction recv : recvInstrList) {
						recvQty += Integer.parseInt(recv.getReceivedQuantity());
						lpn=recv.getParentContainer();
						receiveStatus=recv.getReceivedStatus();
					}
					receivedQtyInEaches = recvQty * Integer.parseInt(poLineDetail.getVnpk());
					receivedItemNumber=poLineDetail.getItemNumber();

				} 
				
				switch(receiveStatus.toUpperCase())
				{
					case "QC INSPECT":
					{
						expectedreceiveStatus="QCI";
						break;
					}
					case "AVAILABLE":{
						expectedreceiveStatus="AVAL";
						break;
					}
					case "DAMAGE":{
						expectedreceiveStatus="DMG";
						break;

					}
					
					case "RETURN ON CARRIER" :
						expectedreceiveStatus = "ROC";
						break;
						
					case "PROBLEMS" :
						expectedreceiveStatus = "PROB";
						List<String> poNumberList = JsonPath.read(testFlowData, "$..deliveryDetails..poNumbers[1]");
						receivedPoNumber = poNumberList.get(0);
//						receivedItemNumber = "PROBLEM1";
						break;
				}
				
				final String expectedLPN = lpn;
				
				Failsafe.with(retryPolicy).run(() -> {
					responseBody=catalystSCTHelper.getSCTResponse(entityType);
					JSONArray  sctMasterCotainerId = JsonPath.read(responseBody,SCT_MASTER_CONTAINER_ID);
					Assert.assertEquals(ErrorCodes.CATALYST_SCT_MASTER_CONTAINER_ID_MISMATCH, expectedLPN, sctMasterCotainerId.get(0));
					
				});
				
				JSONArray sctDocNumber =JsonPath.read(responseBody, SCT_DOC_NUMBER);
				JSONArray sctItemQty =JsonPath.read(responseBody, SCT_ITEM_QTY); 
				JSONArray sctInventoryStatus =JsonPath.read(responseBody, SCT_INVENTORY_STATUS); 
				
				if(!receiveStatus.equalsIgnoreCase("PROBLEMS")) {
					JSONArray sctItemNumber = JsonPath.read(responseBody, SCT_ITEM_NUMBER);
					Assert.assertEquals(ErrorCodes.CATALYST_SCT_RECEIVED_ITEM_NUMBER_MISMATCH,receivedItemNumber, sctItemNumber.get(0).toString());
				}
				
				Assert.assertEquals(ErrorCodes.CATALYST_SCT_RECEIVED_ITEM_QTY_USERID_MISMATCH,receivedQtyInEaches, sctItemQty.get(0));
				Assert.assertEquals(ErrorCodes.CATALYST_SCT_PO_NUMBER_MISMATCH,receivedPoNumber, sctDocNumber.get(0).toString());
				Assert.assertEquals(ErrorCodes.CATALYST_SCT_INVENTORY_STATUS_MISMATCH,expectedreceiveStatus.toLowerCase(), sctInventoryStatus.get(0).toString().toLowerCase());
				validateDeliveryStatusinSct("WORKING");
				
				LOGGER.info("Successfully Validated "+entityType+" After First Receipt");
				
			}} catch (Exception e) {
				throw new AutomationFailure("Failed to validate "+entityType+" After First Receipt in SCT", e);
			}
	}


	@Step
	public void validateDeliveryAfterCompleteShipment(String entityType) {
		try {
			Failsafe.with(retryPolicy).run(() -> {
			responseBody=catalystSCTHelper.getSCTResponse(entityType);
			JSONArray sctDoorCloseUserId =  JsonPath.read(responseBody,SCT_DOOR_CLOSE_USER_ID);
			JSONArray sctDoorCloseReason = JsonPath.read(responseBody,SCT_DOOR_CLOSE_REASON);
			JSONArray sctDeliveryCompleteUserId = JsonPath.read(responseBody,SCT_DELIVERY_COMPLETE_USER_ID);
			JSONArray sctDeliveryStatus = JsonPath.read(responseBody,SCT_DELIVERY_STATUS);

			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DOOR_CLOSE_USER_ID_MISMATCH, environment.getProperty(("userName")).toLowerCase(), sctDoorCloseUserId.get(0).toString().toLowerCase());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DELIVERY_COMPLETE_USER_ID_MISMATCH, environment.getProperty(("userName")).toLowerCase(), sctDeliveryCompleteUserId.get(0).toString().toLowerCase());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DOOR_CLOSE_REASON_MISMATCH, "RELEASE_TRAILER", sctDoorCloseReason.get(0).toString().toUpperCase());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DELIVERY_STATUS_MISMATCH, "FINALIZED", sctDeliveryStatus.get(0).toString().toUpperCase());
			});

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Delivery after Complete Shipment in SCT", e);
		}
	}


	@Step
	public void validatePickInSct(String entityType) {
		try {
			responseBody=catalystSCTHelper.getSCTResponse(entityType);
			JSONArray sctTotalDamageQty  =  JsonPath.read(responseBody,SCT_TOTAL_DAMAGE_QTY);
			JSONArray  sctPickedUnitQty = JsonPath.read(responseBody,SCT_PICKED_UNIT_QTY);
			JSONArray  sctOrderItemNumber= JsonPath.read(responseBody,SCT_ITEM_NUMBER);
			JSONArray  sctAllocOrderId= JsonPath.read(responseBody,SCT_ALLOCATION_ORDER_ID);
			JSONArray  sctContainerId= JsonPath.read(responseBody,SCT_CONTAINER_ID);
			JSONArray sctPickStatus = JsonPath.read(responseBody,SCT_PICK_STATUS);
			JSONArray sctSoNumber = JsonPath.read(responseBody,SCT_STORE_ORDER_NUMBER);


			String testFlowData = (String) threadlocal.get().get(TEST_FLOW_DATA);
			JSONArray listOfOrders = JsonPath.read(testFlowData, GET_ORDERS);
			String orderDetailsString = listOfOrders.toJSONString();
			List<OrdersDetail> orderDetailsList = null;
			orderDetailsList = om.readValue(orderDetailsString, new TypeReference<List<OrdersDetail>>() {
			});
			String itemNumber=orderDetailsList.get(0).getItemNumber();
			String allocationOrderId=orderDetailsList.get(0).getAllocationOrderId();
			List<ExpectedPicks> expectedPicksList=orderDetailsList.get(0).getExpectedAllocation().getExpectedPicks();
			String fulfilledQty=	expectedPicksList.get(0).getFulfilledQty();


			Assert.assertEquals(ErrorCodes.CATALYST_SCT_TOTAL_DAMAGE_QTY_MISMATCH,"0" , sctTotalDamageQty.get(0).toString());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_PICKED_UNIT_QTY_MISMATCH,fulfilledQty, sctPickedUnitQty.get(0).toString());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_ORDER_ITEM_NUMBER_MISMATCH, itemNumber, sctOrderItemNumber.get(0).toString());
			//Assert.assertEquals(ErrorCodes.CATALYST_SCT_ALLOC_ORDER_ID_MISMATCH,allocationOrderId, sctAllocOrderId.get(0).toString());
			//Assert.assertEquals(ErrorCodes.CATALYST_SCT_CONTAINER_ID_MISMATCH,, sctContainerId.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_PICK_STATUS_MISMATCH,"SHIPPED" , sctPickStatus.get(0));
			//Assert.assertEquals(ErrorCodes.CATALYST_SCT_SO_NUMBER_MISMATCH,, sctSoNumber.get(0));


		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Pick in SCT", e);
		}
	}

	@Step
	public void validateAllocationOrderStoreOrderInSct(String entityType) {
		try {
			responseBody=catalystSCTHelper.getSCTResponse(entityType);
			JSONArray sctAoOrderStatus  =  JsonPath.read(responseBody,SCT_ALLOCATION_ORDER_STATUS);
			JSONArray  sctDestinationStoreNumber= JsonPath.read(responseBody,SCT_DESTINATION_STORE_NUMBER);
			JSONArray  sctSoNumber= JsonPath.read(responseBody,SCT_STORE_ORDER_NUMBER);
			JSONArray  sctSoOrderStatus= JsonPath.read(responseBody,SCT_STORE_ORDER_STATUS);
			JSONArray  sctOrderQty= JsonPath.read(responseBody,SCT_ORDER_QTY);


			String testFlowData = (String) threadlocal.get().get(TEST_FLOW_DATA);
			JSONArray listOfOrders = JsonPath.read(testFlowData, GET_ORDERS);
			String orderDetailsString = listOfOrders.toJSONString();
			List<OrdersDetail> orderDetailsList = null;
			orderDetailsList = om.readValue(orderDetailsString, new TypeReference<List<OrdersDetail>>() {
			});
			String itemNumber=orderDetailsList.get(0).getItemNumber();
			String destinationNumber=orderDetailsList.get(0).getDestinationNum();
			//	String allocationOrderId=orderDetailsList.get(0).getAllocationOrderId();
			List<ExpectedPicks> expectedPicksList=orderDetailsList.get(0).getExpectedAllocation().getExpectedPicks();
			String fulfilledQty=	expectedPicksList.get(0).getFulfilledQty();


			Assert.assertEquals(ErrorCodes.CATALYST_SCT_ALLOCATION_ORDER_STATUS_MISMATCH,"RELEASED" , sctAoOrderStatus.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DESTINATION_STORE_NUMBER_MISMATCH,destinationNumber, sctDestinationStoreNumber.get(0).toString());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_STORE_ORDER_STATUS_MISMATCH,"RELEASED", sctSoOrderStatus.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_ORDER_QTY_MISMATCH,fulfilledQty,  sctOrderQty.get(0).toString());
			//Assert.assertEquals(ErrorCodes.CATALYST_SCT_SO_NUMBER_MISMATCH,, sctSoNumber.get(0));


		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate AO SO in SCT", e);
		}
	}

	@Step
	public void validateAllocationOrderLineInSct(String entityType) {
		try {
			responseBody=catalystSCTHelper.getSCTResponse(entityType);
			JSONArray sctAoLineOrderStatus  =  JsonPath.read(responseBody,SCT_ALLOCATION_ORDER_LINE_ORDER_STATUS);
			JSONArray  sctAllocToPickQty= JsonPath.read(responseBody,SCT_ALLOC_TO_PICK_QTY);



			String testFlowData = (String) threadlocal.get().get(TEST_FLOW_DATA);
			JSONArray listOfOrders = JsonPath.read(testFlowData, GET_ORDERS);
			String orderDetailsString = listOfOrders.toJSONString();
			List<OrdersDetail> orderDetailsList = null;
			orderDetailsList = om.readValue(orderDetailsString, new TypeReference<List<OrdersDetail>>() {
			});
			List<ExpectedPicks> expectedPicksList=orderDetailsList.get(0).getExpectedAllocation().getExpectedPicks();
			String fulfilledQty=	expectedPicksList.get(0).getFulfilledQty();


			Assert.assertEquals(ErrorCodes.CATALYST_SCT_ALLOCATION_ORDER_LINE_STATUS_MISMATCH,"RELEASED" , sctAoLineOrderStatus.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_ALLOC_TO_PICK_QTY_MISMATCH,fulfilledQty,  sctAllocToPickQty.get(0).toString());

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate AO SO in SCT", e);
		}
	}

	@Step
	public void validateStoreOrderLineInSct(String entityType) {
		try {
			responseBody=catalystSCTHelper.getSCTResponse(entityType);
			JSONArray sctTotalAllocQty  =  JsonPath.read(responseBody,SCT_TOTAL_ALLOC_QTY);
			JSONArray  sctAllocOrderId= JsonPath.read(responseBody,SCT_ALLOCATION_ORDER_ID);
			JSONArray  sctDestinationStoreNumber= JsonPath.read(responseBody,SCT_DESTINATION_BU_NUMBER);
			JSONArray  sctSoLineOrderStatus= JsonPath.read(responseBody,SCT_STORE_ORDER_LINE_ORDER_STATUS);



			String testFlowData = (String) threadlocal.get().get(TEST_FLOW_DATA);
			JSONArray listOfOrders = JsonPath.read(testFlowData, GET_ORDERS);
			String orderDetailsString = listOfOrders.toJSONString();
			List<OrdersDetail> orderDetailsList = null;
			orderDetailsList = om.readValue(orderDetailsString, new TypeReference<List<OrdersDetail>>() {
			});
			//String itemNumber=orderDetailsList.get(0).getItemNumber();
			String destinationNumber=orderDetailsList.get(0).getDestinationNum();
			String allocationOrderId=orderDetailsList.get(0).getAllocationOrderId();
			//	String allocationOrderId=orderDetailsList.get(0).getAllocationOrderId();
			List<ExpectedPicks> expectedPicksList=orderDetailsList.get(0).getExpectedAllocation().getExpectedPicks();
			String fulfilledQty=	expectedPicksList.get(0).getFulfilledQty();


			Assert.assertEquals(ErrorCodes.CATALYST_SCT_TOTAL_ALLOC_QTY_MISMATCH,fulfilledQty , sctTotalAllocQty.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_ALLOCATION_ORDER_ID_MISMATCH,allocationOrderId, sctAllocOrderId.get(0));
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DESTINATION_STORE_NUMBER_MISMATCH,destinationNumber, sctDestinationStoreNumber.get(0).toString());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_STORE_ORDER_LINE_ORDER_STATUS_MISMATCH,"RELEASED",  sctSoLineOrderStatus.get(0));


		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate AO SO in SCT", e);
		}
	}
	
	
	@Step
	public void validateSctEntityAfterCompleteShipment(String entityType, String receiveStatus) {
		try {
			
			Failsafe.with(retryPolicy).run(() -> {
				responseBody=catalystSCTHelper.getSCTResponse(entityType);
				List<String> sctDoorCloseUserId =  JsonPath.read(responseBody,SCT_DOOR_CLOSE_USER_ID);
				Assert.assertEquals(ErrorCodes.CATALYST_SCT_DOOR_CLOSE_USER_ID_MISMATCH, environment.getProperty(("userName")).toLowerCase(), sctDoorCloseUserId.get(0).toLowerCase());
			});
			
			List<String> sctDeliveryStatus = JsonPath.read(responseBody,SCT_DELIVERY_STATUS);
			List<String> sctDeliveryCompleteUserId = JsonPath.read(responseBody,SCT_DELIVERY_COMPLETE_USER_ID);
			List<String> sctDoorCloseReason = JsonPath.read(responseBody,SCT_DOOR_CLOSE_REASON);
			
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DELIVERY_COMPLETE_USER_ID_MISMATCH, environment.getProperty(("userName")).toLowerCase(), sctDeliveryCompleteUserId.get(0).toLowerCase());
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DELIVERY_STATUS_MISMATCH, "FINALIZED", sctDeliveryStatus.get(0).toUpperCase());
			
			switch(receiveStatus) {
			
				case "Return On Carrier":
					Assert.assertEquals(ErrorCodes.CATALYST_SCT_DOOR_CLOSE_REASON_MISMATCH, "RETURN_ON_CARRIER", sctDoorCloseReason.get(0).toUpperCase());
					break;
				
				default:
					Assert.assertEquals(ErrorCodes.CATALYST_SCT_DOOR_CLOSE_REASON_MISMATCH, "RELEASE_TRAILER", sctDoorCloseReason.get(0).toUpperCase());
			}

		} catch (Exception e) {
			throw new AutomationFailure("Failed to validate Delivery after Complete Shipment in SCT", e);
		}
	}
	
	
	public void validateDeliveryStatusinSct(String deliveryStatus) throws URISyntaxException, IOException {
		
		Failsafe.with(retryPolicy).run(() -> {
			responseBody = catalystSCTHelper.getSCTResponse("DELIVERY");
			List<String> sctDeliveryStatus =JsonPath.read(responseBody, SCT_DELIVERY_STATUS);
			Assert.assertEquals(ErrorCodes.CATALYST_SCT_DELIVERY_STATUS_MISMATCH, deliveryStatus.toUpperCase(), sctDeliveryStatus.get(0).toUpperCase());
		});
		
	}

}
