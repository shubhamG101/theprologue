package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "number", "description", "divBaseDivision", "departments" })
public class DivisionDepartment {
	@JsonProperty("number")
	private int number;
	@JsonProperty("description")
	private String description;
	@JsonProperty("divBaseDivision")
	private BaseDivision divBaseDivision;
	@JsonProperty("departments")
	private List<Department> departments;

	@JsonProperty("number")
	public int getNumber() {
		return number;
	}

	@JsonProperty("number")
	public void setNumber(int number) {
		this.number = number;
	}

	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	@JsonProperty("divBaseDivision")
	public BaseDivision getDivBaseDivision() {
		return divBaseDivision;
	}

	@JsonProperty("divBaseDivision")
	public void setDivBaseDivision(BaseDivision divBaseDivision) {
		this.divBaseDivision = divBaseDivision;
	}

	@JsonProperty("departments")
	public List<Department> getDepartments() {
		return departments;
	}

	@JsonProperty("departments")
	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}
}
