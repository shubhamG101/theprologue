package com.walmart.framework.utilities.jms;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.strati.StratiServiceProvider;
import io.strati.messaging.jms.MessagingJMSService;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class StratiConnectionUtil {

	TextMessage message = null;
	@Autowired
	Environment env;

	@Autowired
	JavaUtils javaUtils;

	static final Logger LOGGER = LogManager.getLogger(StratiConnectionUtil.class);

	public void publishStartiMessage(String subModelName, String messageString, String subscriptionModel,
			String connFactory, String username, String password) {
		publishStartiMessage(subModelName, messageString, subscriptionModel, connFactory, username, password, null);
	}

	public void publishStartiMessage(String subModelName, String messageString, String subscriptionModel,
			String connFactory, String username, String password, String eventType) {
		synchronized (this) {
			System.setProperty("runtime.context.appName", "maas");
			String environmentType;
			if (Config.ENV == ENVIRONMENT.CERT && Config.DC == DC_TYPE.WITRON) {
				System.setProperty("runtime.context.environmentType", "dev");
				environmentType = "dev";
			} else if (Config.ENV == ENVIRONMENT.QA && Config.DC == DC_TYPE.WITRON) {
				System.setProperty("runtime.context.environmentType", "qa");
				environmentType = "qa";
			} else if (Config.ENV == ENVIRONMENT.CERT) {
				System.setProperty("runtime.context.environmentType", "stg");
				environmentType = "UAT";
			} else if (Config.ENV == ENVIRONMENT.QA && Config.DC == DC_TYPE.WITRON) {
				System.setProperty("runtime.context.environmentType", "qa");
				environmentType = "qa";
			} else if (Config.ENV == ENVIRONMENT.PROD) {
				System.setProperty("runtime.context.environmentType", "prod");
				environmentType = "PROD";
			} else if (Config.ENV == ENVIRONMENT.QA && Config.DC == DC_TYPE.RDC) {
				System.setProperty("runtime.context.environmentType", "qa");
				environmentType = "qa";
			} else {
				System.setProperty("runtime.context.environmentType", "qa");
				environmentType = "TEST";
			}

			System.setProperty("runtime.context.system.property.override.enabled", "true");
			System.setProperty("com.ibm.mq.cfg.jmqi.useMQCSPauthentication", "Y");

			MessageProducer msgSender = null;
			Session session = null;
			Connection connection = null;
			ConnectionFactory connectionFactory = null;
			Destination destination;
			MessagingJMSService messagingService;
			if (StratiServiceProvider.SERVICE_PROVIDER_ATOMIC_REFERENCE.get() == null) {
				LOGGER.info("STRATI Publish Service is null creating new one");
				messagingService = StratiServiceProvider.getInstance().getMessagingJMSService().orElse(null);
				LOGGER.info("STRATI Publish Service is created successfully {} ", messagingService);
			} else {
				messagingService = StratiServiceProvider.getInstance().getMessagingJMSService().orElse(null);
			}
			try {
				connectionFactory = messagingService.getConnectionFactory(connFactory);
				connection = connectionFactory.createConnection(username, password);
				connection.start();
				session = StratiConnectionUtil.getSession(connection);
				if (session != null) {
					if (subscriptionModel.equalsIgnoreCase("queue")) {
						destination = session.createQueue(subModelName);
					} else {
						destination = session.createTopic(subModelName);
					}
					msgSender = session.createProducer(destination);
					msgSender.setDeliveryMode(DeliveryMode.PERSISTENT);
					message = session.createTextMessage(messageString);
					message.setStringProperty("sourceDcNbr", env.getProperty("facility_num"));
					message.setStringProperty("sourceCountryCd", env.getProperty("country_code"));
					if (Config.ENV != ENVIRONMENT.PROD) {
						message.setStringProperty("environmentId", env.getProperty("facility_num"));
					}
					message.setStringProperty("environmentType", environmentType);
					message.setStringProperty("WMT_UserId", "sysadmin");
					message.setStringProperty("WMT_CorrelationId", UUID.randomUUID().toString());
					message.setStringProperty("facilityNum", env.getProperty("facility_num"));
					message.setStringProperty("facilityCountryCode", env.getProperty("country_code"));
					message.setStringProperty("sourceNumber", env.getProperty("facility_num"));
					message.setStringProperty("country", "us");

					if (Config.DC == DC_TYPE.WITRON) {
						message.setStringProperty("source", env.getProperty("idm_header_source"));
					}

					if (eventType != null) {
						message.setStringProperty("eventType", eventType);

						if (Config.DC == DC_TYPE.ACC && eventType.equals("CHANNEL_UPDATE")) {
							// Specific to ACC for Channel Flip simulation fetching itemnumber from message
							JSONObject obj = new JSONObject(messageString);
							String itemNumber = obj.getString("itemNumber");

							message.setStringProperty("itemNumber", itemNumber);
							message.setStringProperty("idempotencyKey", javaUtils.getUUID());
						}
						Date currDate = new Date();
						DateFormat desturl = new SimpleDateFormat("yyyy-MM-dd");
						String dateUrlStr = desturl.format(currDate);
						if (Config.DC == DC_TYPE.WITRON && eventType.contains("predth")) {
							message.setStringProperty("messageType", "PLANNED");
							message.setJMSCorrelationID(String.valueOf(javaUtils.randonNumberGenerator(6)));
							message.setStringProperty("msgTimestamp", dateUrlStr + "T14:43:45.090Z");
						} else if (Config.DC == DC_TYPE.WITRON && eventType.contains("postdth")) {
							String[] eventyArr = eventType.split("#");
							String container = eventyArr[1];
							message.setStringProperty("messageType", "PICKED");
							message.setJMSCorrelationID(String.valueOf(javaUtils.randonNumberGenerator(6)));
							message.setStringProperty("msgTimestamp", dateUrlStr + "T14:43:45.090Z");
							message.setStringProperty("SSCC", container);
						} else if (Config.DC == DC_TYPE.WITRON && eventType.contains("ohcolc")) {
							String[] eventyArr = eventType.split("#");
							String fulfillmentId = eventyArr[1];
							message.setJMSCorrelationID(String.valueOf(javaUtils.randonNumberGenerator(6)));
							message.setStringProperty("messageType", "COMPLETED");
							message.setStringProperty("fulfillmentId", fulfillmentId);
						} else if (eventType != null && Config.DC == DC_TYPE.WITRON && eventType.equals("itemMDM")) {
							message.setStringProperty("eventType", "Item Update");
							message.setStringProperty("requestorId", "mdm-Item");
							message.setIntProperty("facilityNum", Integer.parseInt(env.getProperty("facility_num")));
							message.setStringProperty("facilityCountryCode", env.getProperty("country_code"));

						} else if (eventType.equals("createasn")) {
							message.setStringProperty("facilitySubType", "MCC");
							message.setStringProperty("documentType", "ASN");
							message.setIntProperty("facilityNum", 32898);
							message.setIntProperty("destinationFacilityNumber",
									Integer.parseInt(env.getProperty("facility_num")));
						}
						else if (eventType.equals("divert")) {
							message.setStringProperty("facilityNum", "32679");
							message.setStringProperty("facilityCountryCode","US");
						}

						if (Config.DC == DC_TYPE.WITRON && eventType.contains("gateout")) {
							message.setStringProperty("environmentType", "PROD");
							message.setStringProperty("sourceCountryCd", "US");
							message.setStringProperty("sourceDcNbr", env.getProperty("facility_num"));
							message.setStringProperty("environmentId", env.getProperty("facility_num"));
							message.setStringProperty("WMT_UserId", "sysadmin");
						}
					}
					LOGGER.info("Message Header:{}", message.toString());
					msgSender.send(message);
					session.commit();

				}
				msgSender.close();
				session.close();
				connection.close();
			} catch (Exception e) {
				LOGGER.error(e);
				throw new AutomationFailure("Unable to Publish the message in Straati", e);
			}
		}

	}

	public static Session getSession(Connection conn) {
		try {
			return conn.createSession(Session.SESSION_TRANSACTED);
		} catch (JMSException e) {
			e.printStackTrace();
		}
		return null;

	}
}
