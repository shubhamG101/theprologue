package com.walmart.framework.utilities.javautils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import spring.SpringTestConfiguration;


@ContextConfiguration(classes = SpringTestConfiguration.class)
//@RunWith(SpringRunner.class)
public class ThreadLocalFactory {

    @Autowired
    ThreadLocal threadLocal;

    public ThreadLocalFactory(){

    }

    public  ThreadLocal getThreadLocalInstance(){
        return threadLocal;
    }


}
