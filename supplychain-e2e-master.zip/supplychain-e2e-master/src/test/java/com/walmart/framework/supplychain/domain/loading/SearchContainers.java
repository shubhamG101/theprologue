package com.walmart.framework.supplychain.domain.loading;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "loads", "destinations", "containerStatus", "startDate", "endDate" })
public class SearchContainers {
	
	@JsonProperty("loads")
	private List<Load> loads;
	@JsonProperty("destinations")
	private List<String> destinations;
	@JsonProperty("containerStatus")
	private List<String> containerStatus;
	@JsonProperty("startDate")
	private String startDate;
	@JsonProperty("endDate")
	private String endDate;
	
	public List<Load> getLoads() {
		return loads;
	}
	public void setLoads(List<Load> loads) {
		this.loads = loads;
	}
	public List<String> getDestinations() {
		return destinations;
	}
	public void setDestinations(List<String> destinations) {
		this.destinations = destinations;
	}
	public List<String> getContainerStatus() {
		return containerStatus;
	}
	public void setContainerStatus(List<String> containerStatus) {
		this.containerStatus = containerStatus;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
