package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "item", "boh" })
public class InventoryBOH {
	@JsonProperty("item")
	private String item;
	@JsonProperty("boh")
	private String boh;

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getBoh() {
		return boh;
	}

	public void setBoh(String boh) {
		this.boh = boh;
	}
}
