package com.walmart.framework.utilities.javautils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.walmart.execution.security.SecurityUtil;

public class EncryptionAndDecryption {
	private static final Logger LOGGER = LogManager.getLogger(EncryptionAndDecryption.class);
	public static void main(String[] args)  {
		SecurityUtil securityUtil=new SecurityUtil();
		String dir = "/src/test/resources/properties/atlas/cert";
		String fileNamesOrValue = "db.properties,message.properties,env.properties";
		LOGGER.info(securityUtil.encryptOrDecrypt(dir,fileNamesOrValue, SecurityUtil.Type.ENCRYPTION, true, true));
	}

	
}
