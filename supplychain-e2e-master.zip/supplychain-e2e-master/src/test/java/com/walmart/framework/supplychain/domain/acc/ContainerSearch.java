package com.walmart.framework.supplychain.domain.acc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "loads", "destinations", "containerStatus", "containerTagId"})
public class ContainerSearch {

	@JsonProperty("loads")
	private List<String> loads;
	@JsonProperty("destinations")
	private List<String> destinations;
	@JsonProperty("containerStatus")
	private List<String> containerStatus;
	@JsonProperty("containerTagId")
	private String containerTagId;
	
	@JsonProperty("loads")
	public List<String> getLoads() {
		return loads;
	}
	@JsonProperty("loads")
	public void setLoads(List<String> loads) {
		this.loads = loads;
	}
	@JsonProperty("destinations")
	public List<String> getDestinations() {
		return destinations;
	}
	@JsonProperty("destinations")
	public void setDestinations(List<String> destinations) {
		this.destinations = destinations;
	}
	@JsonProperty("containerStatus")
	public List<String> getContainerStatus() {
		return containerStatus;
	}
	@JsonProperty("containerStatus")
	public void setContainerStatus(List<String> containerStatus) {
		this.containerStatus = containerStatus;
	}
	@JsonProperty("containerTagId")
	public String getContainerTagId() {
		return containerTagId;
	}
	@JsonProperty("containerTagId")
	public void setContainerTagId(String containerTagId) {
		this.containerTagId = containerTagId;
	}
}

