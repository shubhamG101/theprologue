package com.walmart.framework.supplychain.constants;
/*
 * This class is used to define the keys used in Thread local
 */

public class ThreadLocalKeys {
	public static final String TEST_FLOW_DATA_KEY = "testFlowData";
	public static final String FEATURE_FILE_NAME_KEY = "featureFileName";
	public static final String PBYL_SLOTS_FOR_TRIP="PBYL_SLOTS_FOR_PALLET_";
	public static final String PBYL_SLOTS_TO_BE_CLOSED="PBYL_SLOTS_TO_BE_CLOSED";
	public static final String PBYL_PICKED_SLOTS_FOR_TRIP="PBYL_PICKED_SLOTS_FOR_PALLET_";
	public static final String PBYL_SHORTAGE_CASES_FOR_TRIP="PBYL_SHORTAGE_CASES_FOR_PALLET_";
	
	
	
	 ThreadLocalKeys() {
	}
}
