package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "lineNbr", "logicalCntr", "actualCntr", "qty", "itemNbr", "pickId", "expiryDate", "groupingId", "poType" })
public class FulfillmentUnit {
	@JsonProperty("lineNbr")
	private String lineNbr;
	@JsonProperty("logicalCntr")
	private String logicalCntr;
	@JsonProperty("actualCntr")
	private String actualCntr;
	@JsonProperty("qty")
	private String qty;
	@JsonProperty("itemNbr")
	private String itemNbr;
	@JsonProperty("pickId")
	private String pickId;
	@JsonProperty("expiryDate")
	private String expiryDate;
	@JsonProperty("groupingId")
	private String groupingId;
	@JsonProperty("poType")
	private String poType;

	public String getLineNbr() {
		return lineNbr;
	}

	public void setLineNbr(String lineNbr) {
		this.lineNbr = lineNbr;
	}

	public String getLogicalCntr() {
		return logicalCntr;
	}

	public void setLogicalCntr(String logicalCntr) {
		this.logicalCntr = logicalCntr;
	}

	public String getActualCntr() {
		return actualCntr;
	}

	public void setActualCntr(String actualCntr) {
		this.actualCntr = actualCntr;
	}

	public String getQty() {
		return qty;
	}

	public void setQty(String qty) {
		this.qty = qty;
	}

	public String getItemNbr() {
		return itemNbr;
	}

	public void setItemNbr(String itemNbr) {
		this.itemNbr = itemNbr;
	}

	public String getPickId() {
		return pickId;
	}

	public void setPickId(String pickId) {
		this.pickId = pickId;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getGroupingId() {
		return groupingId;
	}

	public void setGroupingId(String groupingId) {
		this.groupingId = groupingId;
	}

	public String getPoType() {
		return poType;
	}

	public void setPoType(String poType) {
		this.poType = poType;
	}
}
