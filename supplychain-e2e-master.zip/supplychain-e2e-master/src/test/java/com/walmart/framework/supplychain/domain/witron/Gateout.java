package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "routeNbr", "dcNbr", "telegramID", "trailerNbr", "reeferActualTemp1", "reeferActualTemp2", "reeferActualTemp3", "reeferFuelLevel", "driverID", "gateOutUserID", "departTimeStamp" })
public class Gateout {
	@JsonProperty("routeNbr")
	private String routeNbr;
	@JsonProperty("dcNbr")
	private String dcNbr;
	@JsonProperty("telegramID")
	private String telegramID;
	@JsonProperty("trailerNbr")
	private String trailerNbr;
	@JsonProperty("reeferActualTemp1")
	private String reeferActualTemp1;
	@JsonProperty("reeferActualTemp2")
	private String reeferActualTemp2;
	@JsonProperty("reeferActualTemp3")
	private String reeferActualTemp3;
	@JsonProperty("reeferFuelLevel")
	private String reeferFuelLevel;
	@JsonProperty("driverID")
	private String driverID;
	@JsonProperty("gateOutUserID")
	private String gateOutUserID;
	@JsonProperty("departTimeStamp")
	private String departTimeStamp;
	
	@JsonProperty("routeNbr")
	public String getRouteNbr() {
		return routeNbr;
	}
	@JsonProperty("routeNbr")
	public void setRouteNbr(String routeNbr) {
		this.routeNbr = routeNbr;
	}
	@JsonProperty("dcNbr")
	public String getDcNbr() {
		return dcNbr;
	}
	@JsonProperty("dcNbr")
	public void setDcNbr(String dcNbr) {
		this.dcNbr = dcNbr;
	}
	@JsonProperty("telegramID")
	public String getTelegramID() {
		return telegramID;
	}
	@JsonProperty("telegramID")
	public void setTelegramID(String telegramID) {
		this.telegramID = telegramID;
	}
	@JsonProperty("trailerNbr")
	public String getTrailerNbr() {
		return trailerNbr;
	}
	@JsonProperty("trailerNbr")
	public void setTrailerNbr(String trailerNbr) {
		this.trailerNbr = trailerNbr;
	}
	@JsonProperty("reeferActualTemp1")
	public String getReeferActualTemp1() {
		return reeferActualTemp1;
	}
	@JsonProperty("reeferActualTemp1")
	public void setReeferActualTemp1(String reeferActualTemp1) {
		this.reeferActualTemp1 = reeferActualTemp1;
	}
	@JsonProperty("reeferActualTemp2")
	public String getReeferActualTemp2() {
		return reeferActualTemp2;
	}
	@JsonProperty("reeferActualTemp2")
	public void setReeferActualTemp2(String reeferActualTemp2) {
		this.reeferActualTemp2 = reeferActualTemp2;
	}
	@JsonProperty("reeferActualTemp3")
	public String getReeferActualTemp3() {
		return reeferActualTemp3;
	}
	@JsonProperty("reeferActualTemp3")
	public void setReeferActualTemp3(String reeferActualTemp3) {
		this.reeferActualTemp3 = reeferActualTemp3;
	}
	@JsonProperty("reeferFuelLevel")
	public String getReeferFuelLevel() {
		return reeferFuelLevel;
	}
	@JsonProperty("reeferFuelLevel")
	public void setReeferFuelLevel(String reeferFuelLevel) {
		this.reeferFuelLevel = reeferFuelLevel;
	}
	@JsonProperty("driverID")
	public String getDriverID() {
		return driverID;
	}
	@JsonProperty("driverID")
	public void setDriverID(String driverID) {
		this.driverID = driverID;
	}
	@JsonProperty("gateOutUserID")
	public String getGateOutUserID() {
		return gateOutUserID;
	}
	@JsonProperty("gateOutUserID")
	public void setGateOutUserID(String gateOutUserID) {
		this.gateOutUserID = gateOutUserID;
	}
	@JsonProperty("departTimeStamp")
	public String getDepartTimeStamp() {
		return departTimeStamp;
	}
	@JsonProperty("departTimeStamp")
	public void setDepartTimeStamp(String departTimeStamp) {
		this.departTimeStamp = departTimeStamp;
	}
}
