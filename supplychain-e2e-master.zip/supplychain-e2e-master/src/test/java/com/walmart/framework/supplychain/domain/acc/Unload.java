package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "containerTagId" })
public class Unload {

	@JsonProperty("containerTagId")
	private String containerTagId;

	@JsonProperty("containerTagId")
	public String getContainerTagId() {
		return containerTagId;
	}
	@JsonProperty("containerTagId")
	public void setContainerTagId(String containerTagId) {
		this.containerTagId = containerTagId;
	}
	
}