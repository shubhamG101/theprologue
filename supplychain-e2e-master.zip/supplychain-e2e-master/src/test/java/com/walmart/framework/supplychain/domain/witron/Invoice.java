package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "invoiceNbr", "destination", "invoiceItems", "division"})
public class Invoice {
	@JsonProperty("invoiceNbr")
	private String invoiceNbr;
	@JsonProperty("destination")
	private String destination;
	@JsonProperty("invoiceItems")
	private List<InvoiceItemQty> invoiceItems;
	@JsonProperty("division")
	private String division;
	
	@JsonProperty("invoiceNbr")
	public String getInvoiceNbr() {
		return invoiceNbr;
	}
	@JsonProperty("invoiceNbr")
	public void setInvoiceNbr(String invoiceNbr) {
		this.invoiceNbr = invoiceNbr;
	}
	@JsonProperty("destination")
	public String getDestination() {
		return destination;
	}
	@JsonProperty("destination")
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	@JsonProperty("division")
	public String getDivision() {
		return division;
	}
	@JsonProperty("division")
	public void setDivision(String division) {
		this.division = division;
	}
	@JsonProperty("invoiceItems")
	public List<InvoiceItemQty> getInvoiceItems() {
		return invoiceItems;
	}
	@JsonProperty("invoiceItems")
	public void setInvoiceItems(List<InvoiceItemQty> invoiceItems) {
		this.invoiceItems = invoiceItems;
	}
	
}
