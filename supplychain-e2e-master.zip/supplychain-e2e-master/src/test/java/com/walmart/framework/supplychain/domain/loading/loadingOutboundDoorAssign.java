package com.walmart.framework.supplychain.domain.loading;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"carrierCode",
"doorNbr",
"trailerNbr",
"trailerType"
})
public class loadingOutboundDoorAssign {

@JsonProperty("carrierCode")
private String carrierCode;
@JsonProperty("doorNbr")
private String doorNbr;
@JsonProperty("trailerNbr")
private String trailerNbr;
@JsonProperty("trailerType")
private String trailerType;
public String getCarrierCode() {
	return carrierCode;
}
public void setCarrierCode(String carrierCode) {
	this.carrierCode = carrierCode;
}
public String getDoorNbr() {
	return doorNbr;
}
public void setDoorNbr(String doorNbr) {
	this.doorNbr = doorNbr;
}
public String getTrailerNbr() {
	return trailerNbr;
}
public void setTrailerNbr(String trailerNbr) {
	this.trailerNbr = trailerNbr;
}
public String getTrailerType() {
	return trailerType;
}
public void setTrailerType(String trailerType) {
	this.trailerType = trailerType;
}


}
