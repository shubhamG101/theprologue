package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "tostrnbr", "tocntrycd", "fromstrnbr", "fromcntrycd", "allcdeptnbr", "allcacdeptnbr",
		"allcacdepttxt", "allcshipdt", "allcitmnbr", "allcchnlmthdcd", "allchntxt", "allcwhpkordqty", "allcschdarrdt",
		"allcpoline", "allcstatcd", "allcstatxt", "allcmancrtind", "allcwhpkrcvqty", "allcvnpkqty", "allcwhpkqty",
		"allcstoleg", "allcwhpksell", "allcprombuyind", "allcvnpkwgtqty", "allcplttiqty", "allcplthiqty" })
public class StoLine {
	@JsonProperty("tostrnbr")
	private String tostrnbr;
	@JsonProperty("tocntrycd")
	private String tocntrycd;
	@JsonProperty("fromstrnbr")
	private String fromstrnbr;
	@JsonProperty("fromcntrycd")
	private String fromcntrycd;
	@JsonProperty("allcdeptnbr")
	private String allcdeptnbr;
	@JsonProperty("allcacdeptnbr")
	private String allcacdeptnbr;
	@JsonProperty("allcacdepttxt")
	private String allcacdepttxt;
	@JsonProperty("allcshipdt")
	private String allcshipdt;
	@JsonProperty("allcitmnbr")
	private String allcitmnbr;
	@JsonProperty("allcchnlmthdcd")
	private String allcchnlmthdcd;
	@JsonProperty("allchntxt")
	private StoChnText allchntxt;
	@JsonProperty("allcwhpkordqty")
	private String allcwhpkordqty;
	@JsonProperty("allcschdarrdt")
	private String allcschdarrdt;
	@JsonProperty("allcpoline")
	private String allcpoline;
	@JsonProperty("allcstatcd")
	private String allcstatcd;
	@JsonProperty("allcstatxt")
	private String allcstatxt;
	@JsonProperty("allcmancrtind")
	private String allcmancrtind;
	@JsonProperty("allcwhpkrcvqty")
	private String allcwhpkrcvqty;
	@JsonProperty("allcvnpkqty")
	private String allcvnpkqty;
	@JsonProperty("allcwhpkqty")
	private String allcwhpkqty;
	@JsonProperty("allcstoleg")
	private String allcstoleg;
	@JsonProperty("allcwhpksell")
	private String allcwhpksell;
	@JsonProperty("allcprombuyind")
	private String allcprombuyind;
	@JsonProperty("allcvnpkwgtqty")
	private String allcvnpkwgtqty;
	@JsonProperty("allcplttiqty")
	private String allcplttiqty;
	@JsonProperty("allcplthiqty")
	private String allcplthiqty;

	@JsonProperty("tostrnbr")
	public String getTostrnbr() {
		return tostrnbr;
	}

	@JsonProperty("tostrnbr")
	public void setTostrnbr(String tostrnbr) {
		this.tostrnbr = tostrnbr;
	}

	@JsonProperty("tocntrycd")
	public String getTocntrycd() {
		return tocntrycd;
	}

	@JsonProperty("tocntrycd")
	public void setTocntrycd(String tocntrycd) {
		this.tocntrycd = tocntrycd;
	}

	@JsonProperty("fromstrnbr")
	public String getFromstrnbr() {
		return fromstrnbr;
	}

	@JsonProperty("fromstrnbr")
	public void setFromstrnbr(String fromstrnbr) {
		this.fromstrnbr = fromstrnbr;
	}

	@JsonProperty("fromcntrycd")
	public String getFromcntrycd() {
		return fromcntrycd;
	}

	@JsonProperty("fromcntrycd")
	public void setFromcntrycd(String fromcntrycd) {
		this.fromcntrycd = fromcntrycd;
	}

	@JsonProperty("allcdeptnbr")
	public String getAllcdeptnbr() {
		return allcdeptnbr;
	}

	@JsonProperty("allcdeptnbr")
	public void setAllcdeptnbr(String allcdeptnbr) {
		this.allcdeptnbr = allcdeptnbr;
	}

	@JsonProperty("allcacdeptnbr")
	public String getAllcacdeptnbr() {
		return allcacdeptnbr;
	}

	@JsonProperty("allcacdeptnbr")
	public void setAllcacdeptnbr(String allcacdeptnbr) {
		this.allcacdeptnbr = allcacdeptnbr;
	}

	@JsonProperty("allcacdepttxt")
	public String getAllcacdepttxt() {
		return allcacdepttxt;
	}

	@JsonProperty("allcacdepttxt")
	public void setAllcacdepttxt(String allcacdepttxt) {
		this.allcacdepttxt = allcacdepttxt;
	}

	@JsonProperty("allcshipdt")
	public String getAllcshipdt() {
		return allcshipdt;
	}

	@JsonProperty("allcshipdt")
	public void setAllcshipdt(String allcshipdt) {
		this.allcshipdt = allcshipdt;
	}

	@JsonProperty("allcitmnbr")
	public String getAllcitmnbr() {
		return allcitmnbr;
	}

	@JsonProperty("allcitmnbr")
	public void setAllcitmnbr(String allcitmnbr) {
		this.allcitmnbr = allcitmnbr;
	}

	@JsonProperty("allcchnlmthdcd")
	public String getAllcchnlmthdcd() {
		return allcchnlmthdcd;
	}

	@JsonProperty("allcchnlmthdcd")
	public void setAllcchnlmthdcd(String allcchnlmthdcd) {
		this.allcchnlmthdcd = allcchnlmthdcd;
	}

	@JsonProperty("allchntxt")
	public StoChnText getAllchntxt() {
		return allchntxt;
	}

	@JsonProperty("allchntxt")
	public void setAllchntxt(StoChnText allchntxt) {
		this.allchntxt = allchntxt;
	}

	@JsonProperty("allcwhpkordqty")
	public String getAllcwhpkordqty() {
		return allcwhpkordqty;
	}

	@JsonProperty("allcwhpkordqty")
	public void setAllcwhpkordqty(String allcwhpkordqty) {
		this.allcwhpkordqty = allcwhpkordqty;
	}

	@JsonProperty("allcschdarrdt")
	public String getAllcschdarrdt() {
		return allcschdarrdt;
	}

	@JsonProperty("allcschdarrdt")
	public void setAllcschdarrdt(String allcschdarrdt) {
		this.allcschdarrdt = allcschdarrdt;
	}

	@JsonProperty("allcpoline")
	public String getAllcpoline() {
		return allcpoline;
	}

	@JsonProperty("allcpoline")
	public void setAllcpoline(String allcpoline) {
		this.allcpoline = allcpoline;
	}

	@JsonProperty("allcstatcd")
	public String getAllcstatcd() {
		return allcstatcd;
	}

	@JsonProperty("allcstatcd")
	public void setAllcstatcd(String allcstatcd) {
		this.allcstatcd = allcstatcd;
	}

	@JsonProperty("allcstatxt")
	public String getAllcstatxt() {
		return allcstatxt;
	}

	@JsonProperty("allcstatxt")
	public void setAllcstatxt(String allcstatxt) {
		this.allcstatxt = allcstatxt;
	}

	@JsonProperty("allcmancrtind")
	public String getAllcmancrtind() {
		return allcmancrtind;
	}

	@JsonProperty("allcmancrtind")
	public void setAllcmancrtind(String allcmancrtind) {
		this.allcmancrtind = allcmancrtind;
	}

	@JsonProperty("allcwhpkrcvqty")
	public String getAllcwhpkrcvqty() {
		return allcwhpkrcvqty;
	}

	@JsonProperty("allcwhpkrcvqty")
	public void setAllcwhpkrcvqty(String allcwhpkrcvqty) {
		this.allcwhpkrcvqty = allcwhpkrcvqty;
	}

	@JsonProperty("allcvnpkqty")
	public String getAllcvnpkqty() {
		return allcvnpkqty;
	}

	@JsonProperty("allcvnpkqty")
	public void setAllcvnpkqty(String allcvnpkqty) {
		this.allcvnpkqty = allcvnpkqty;
	}

	@JsonProperty("allcwhpkqty")
	public String getAllcwhpkqty() {
		return allcwhpkqty;
	}

	@JsonProperty("allcwhpkqty")
	public void setAllcwhpkqty(String allcwhpkqty) {
		this.allcwhpkqty = allcwhpkqty;
	}

	@JsonProperty("allcstoleg")
	public String getAllcstoleg() {
		return allcstoleg;
	}

	@JsonProperty("allcstoleg")
	public void setAllcstoleg(String allcstoleg) {
		this.allcstoleg = allcstoleg;
	}

	@JsonProperty("allcwhpksell")
	public String getAllcwhpksell() {
		return allcwhpksell;
	}

	@JsonProperty("allcwhpksell")
	public void setAllcwhpksell(String allcwhpksell) {
		this.allcwhpksell = allcwhpksell;
	}

	@JsonProperty("allcprombuyind")
	public String getAllcprombuyind() {
		return allcprombuyind;
	}

	@JsonProperty("allcprombuyind")
	public void setAllcprombuyind(String allcprombuyind) {
		this.allcprombuyind = allcprombuyind;
	}

	@JsonProperty("allcvnpkwgtqty")
	public String getAllcvnpkwgtqty() {
		return allcvnpkwgtqty;
	}

	@JsonProperty("allcvnpkwgtqty")
	public void setAllcvnpkwgtqty(String allcvnpkwgtqty) {
		this.allcvnpkwgtqty = allcvnpkwgtqty;
	}

	@JsonProperty("allcplttiqty")
	public String getAllcplttiqty() {
		return allcplttiqty;
	}

	@JsonProperty("allcplttiqty")
	public void setAllcplttiqty(String allcplttiqty) {
		this.allcplttiqty = allcplttiqty;
	}

	@JsonProperty("allcplthiqty")
	public String getAllcplthiqty() {
		return allcplthiqty;
	}

	@JsonProperty("allcplthiqty")
	public void setAllcplthiqty(String allcplthiqty) {
		this.allcplthiqty = allcplthiqty;
	}
}
