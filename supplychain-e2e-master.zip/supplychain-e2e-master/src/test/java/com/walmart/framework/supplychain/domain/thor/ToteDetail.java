package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "width", "depth", "height", "availableForReplen", "availableForSale"})
public class ToteDetail {
	
	@JsonProperty("width")
	private int width;
	@JsonProperty("depth")
	private int depth;
	@JsonProperty("height")
	private int height;
	@JsonProperty("availableForReplen")
	private boolean availableForReplen;
	@JsonProperty("availableForSale")
	private boolean availableForSale;
	
	@JsonProperty("width")
	public int getWidth() {
		return width;
	}
	@JsonProperty("width")
	public void setWidth(int width) {
		this.width = width;
	}
	@JsonProperty("depth")
	public int getDepth() {
		return depth;
	}
	@JsonProperty("depth")
	public void setDepth(int depth) {
		this.depth = depth;
	}
	@JsonProperty("height")
	public int getHeight() {
		return height;
	}
	@JsonProperty("height")
	public void setHeight(int height) {
		this.height = height;
	}
	@JsonProperty("availableForReplen")
	public boolean isAvailableForReplen() {
		return availableForReplen;
	}
	@JsonProperty("availableForReplen")
	public void setAvailableForReplen(boolean availableForReplen) {
		this.availableForReplen = availableForReplen;
	}
	@JsonProperty("availableForSale")
	public boolean isAvailableForSale() {
		return availableForSale;
	}
	@JsonProperty("availableForSale")
	public void setAvailableForSale(boolean availableForSale) {
		this.availableForSale = availableForSale;
	}
	

}
