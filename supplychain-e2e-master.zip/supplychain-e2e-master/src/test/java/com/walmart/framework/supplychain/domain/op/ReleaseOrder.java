package com.walmart.framework.supplychain.domain.op;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(

{ "releaseMsgTxt", "orgUnitId", "effectiveReleaseDate", "createTs", "createUserId", "cycleWaveList" })

public class ReleaseOrder {

	@JsonProperty("cycleWaveList")
	private List<CycleWavelist> cycleWaveList;

	public List<CycleWavelist> getCycleWaveList() {
		return cycleWaveList;
	}

	public void setCycleWaveList(List<CycleWavelist> cycleWaveList) {
		this.cycleWaveList = cycleWaveList;
	}

	@JsonProperty("releaseMsgTxt")
	private String releaseMsgTxt = null;

	@JsonProperty("releaseMsgTxt")
	public String getreleaseMsgTxt() {
		return this.releaseMsgTxt;
	}

	@JsonProperty("releaseMsgTxt")
	public void setreleaseMsgTxt(String releaseMsgTxt) {
		this.releaseMsgTxt = releaseMsgTxt;
	}

	@JsonProperty("orgUnitId")
	private int orgUnitId = 0;

	@JsonProperty("orgUnitId")
	public int getorgUnitId() {
		return this.orgUnitId;
	}

	@JsonProperty("orgUnitId")
	public void setorgUnitId(int orgUnitId) {
		this.orgUnitId = orgUnitId;
	}

	@JsonProperty("effectiveReleaseDate")
	private String effectiveReleaseDate = null;

	@JsonProperty("effectiveReleaseDate")
	public String geteffectiveReleaseDate() {
		return this.effectiveReleaseDate;
	}

	@JsonProperty("effectiveReleaseDate")
	public void seteffectiveReleaseDate(String effectiveReleaseDate) {
		this.effectiveReleaseDate = effectiveReleaseDate;
	}

	@JsonProperty("createUserId")
	private String createUserId = null;

	@JsonProperty("createUserId")
	public String getcreateUserId() {
		return this.createUserId;
	}

	@JsonProperty("createUserId")
	public void setcreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	@JsonProperty("createTs")
	private String createTs = null;

	@JsonProperty("createTs")
	public String getcreateTs() {
		return this.createTs;
	}

	@JsonProperty("createTs")
	public void setcreateTs(String createTs) {
		this.createTs = createTs;
	}

}
