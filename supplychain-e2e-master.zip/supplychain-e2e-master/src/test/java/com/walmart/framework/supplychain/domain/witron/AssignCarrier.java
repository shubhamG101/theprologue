package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "routeId", "carrierId", "carrierCompanyName", "carrierServiceName", "carrierType" })
public class AssignCarrier {
	@JsonProperty("routeId")
	private String routeId;
	@JsonProperty("carrierId")
	private String carrierId;
	@JsonProperty("carrierCompanyName")
	private String carrierCompanyName;
	@JsonProperty("carrierServiceName")
	private String carrierServiceName;
	@JsonProperty("carrierType")
	private String carrierType;
	public String getRouteId() {
		return routeId;
	}
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}
	public String getCarrierId() {
		return carrierId;
	}
	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}
	public String getCarrierCompanyName() {
		return carrierCompanyName;
	}
	public void setCarrierCompanyName(String carrierCompanyName) {
		this.carrierCompanyName = carrierCompanyName;
	}
	public String getCarrierServiceName() {
		return carrierServiceName;
	}
	public void setCarrierServiceName(String carrierServiceName) {
		this.carrierServiceName = carrierServiceName;
	}
	public String getCarrierType() {
		return carrierType;
	}
	public void setCarrierType(String carrierType) {
		this.carrierType = carrierType;
	}
}
