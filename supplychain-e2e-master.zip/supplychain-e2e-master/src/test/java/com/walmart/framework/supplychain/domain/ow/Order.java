package com.walmart.framework.supplychain.domain.ow;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"sourceNumber",
"orderDate",
"wmtItemNumber",
"destinationNumber",
"orderTrackingNumber",
"baseDivNumber",
"departmentNumber",
"destCountryCode",
"needType",
"messageType",
"orderRecordType",
"packType",
"poLineNumber",
"poNumber",
"poType",
"priorityReason",
"priorityNbr",
"processName",
"quantity",
"reason",
"sourceCountryCode",
"status",
"upcNumber",
"vnpkQuantity",
"whpkQuantity"
})
public class Order {

public Order() {
	this.needType = "";
	this.priorityReason = "";
	this.reason = "";
	}

@JsonProperty("sourceNumber")
private Integer sourceNumber;
@JsonProperty("orderDate")
private String orderDate;
@JsonProperty("wmtItemNumber")
private Integer wmtItemNumber;
@JsonProperty("destinationNumber")
private Integer destinationNumber;
@JsonProperty("orderTrackingNumber")
private String orderTrackingNumber;
@JsonProperty("baseDivNumber")
private Integer baseDivNumber;
@JsonProperty("departmentNumber")
private Integer departmentNumber;
@JsonProperty("destCountryCode")
private String destCountryCode;
@JsonProperty("needType")
private String needType;
@JsonProperty("messageType")
private String messageType;
@JsonProperty("orderRecordType")
private String orderRecordType;
@JsonProperty("packType")
private String packType;
@JsonProperty("poLineNumber")
private Integer poLineNumber;
@JsonProperty("poNumber")
private Double poNumber;
@JsonProperty("poType")
private String poType;
@JsonProperty("priorityReason")
private String priorityReason;
@JsonProperty("priorityNbr")
private Integer priorityNbr;
@JsonProperty("processName")
private String processName;
@JsonProperty("quantity")
private Integer quantity;
@JsonProperty("reason")
private String reason;
@JsonProperty("sourceCountryCode")
private String sourceCountryCode;
@JsonProperty("status")
private String status;
@JsonProperty("upcNumber")
private Double upcNumber;
@JsonProperty("vnpkQuantity")
private Double vnpkQuantity;
@JsonProperty("whpkQuantity")
private Integer whpkQuantity;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("sourceNumber")
public Integer getSourceNumber() {
return sourceNumber;
}

@JsonProperty("sourceNumber")
public void setSourceNumber(Integer sourceNumber) {
this.sourceNumber = sourceNumber;
}

@JsonProperty("orderDate")
public String getOrderDate() {
return orderDate;
}

@JsonProperty("orderDate")
public void setOrderDate(String orderDate) {
this.orderDate = orderDate;
}

@JsonProperty("wmtItemNumber")
public Integer getWmtItemNumber() {
return wmtItemNumber;
}

@JsonProperty("wmtItemNumber")
public void setWmtItemNumber(Integer wmtItemNumber) {
this.wmtItemNumber = wmtItemNumber;
}

@JsonProperty("destinationNumber")
public Integer getDestinationNumber() {
return destinationNumber;
}

@JsonProperty("destinationNumber")
public void setDestinationNumber(Integer destinationNumber) {
this.destinationNumber = destinationNumber;
}

@JsonProperty("orderTrackingNumber")
public String getOrderTrackingNumber() {
return orderTrackingNumber;
}

@JsonProperty("orderTrackingNumber")
public void setOrderTrackingNumber(String orderTrackingNumber) {
this.orderTrackingNumber = orderTrackingNumber;
}

@JsonProperty("baseDivNumber")
public Integer getBaseDivNumber() {
return baseDivNumber;
}

@JsonProperty("baseDivNumber")
public void setBaseDivNumber(Integer baseDivNumber) {
this.baseDivNumber = baseDivNumber;
}

@JsonProperty("departmentNumber")
public Integer getDepartmentNumber() {
return departmentNumber;
}

@JsonProperty("departmentNumber")
public void setDepartmentNumber(Integer departmentNumber) {
this.departmentNumber = departmentNumber;
}

@JsonProperty("destCountryCode")
public String getDestCountryCode() {
return destCountryCode;
}

@JsonProperty("destCountryCode")
public void setDestCountryCode(String destCountryCode) {
this.destCountryCode = destCountryCode;
}

@JsonProperty("needType")
public String getNeedType() {
return needType;
}

@JsonProperty("needType")
public void setNeedType(String needType) {
this.needType = needType;
}

@JsonProperty("messageType")
public String getMessageType() {
return messageType;
}

@JsonProperty("messageType")
public void setMessageType(String messageType) {
this.messageType = messageType;
}

@JsonProperty("orderRecordType")
public String getOrderRecordType() {
return orderRecordType;
}

@JsonProperty("orderRecordType")
public void setOrderRecordType(String orderRecordType) {
this.orderRecordType = orderRecordType;
}

@JsonProperty("packType")
public String getPackType() {
return packType;
}

@JsonProperty("packType")
public void setPackType(String packType) {
this.packType = packType;
}

@JsonProperty("poLineNumber")
public Integer getPoLineNumber() {
return poLineNumber;
}

@JsonProperty("poLineNumber")
public void setPoLineNumber(Integer poLineNumber) {
this.poLineNumber = poLineNumber;
}

@JsonProperty("poNumber")
public Double getPoNumber() {
return poNumber;
}

@JsonProperty("poNumber")
public void setPoNumber(Double poNumber) {
this.poNumber = poNumber;
}

@JsonProperty("poType")
public String getPoType() {
return poType;
}

@JsonProperty("poType")
public void setPoType(String poType) {
this.poType = poType;
}

@JsonProperty("priorityReason")
public String getPriorityReason() {
return priorityReason;
}

@JsonProperty("priorityReason")
public void setPriorityReason(String priorityReason) {
this.priorityReason = priorityReason;
}

@JsonProperty("priorityNbr")
public Integer getPriorityNbr() {
return priorityNbr;
}

@JsonProperty("priorityNbr")
public void setPriorityNbr(Integer priorityNbr) {
this.priorityNbr = priorityNbr;
}

@JsonProperty("processName")
public String getProcessName() {
return processName;
}

@JsonProperty("processName")
public void setProcessName(String processName) {
this.processName = processName;
}

@JsonProperty("quantity")
public Integer getQuantity() {
return quantity;
}

@JsonProperty("quantity")
public void setQuantity(Integer quantity) {
this.quantity = quantity;
}

@JsonProperty("reason")
public String getReason() {
return reason;
}

@JsonProperty("reason")
public void setReason(String reason) {
this.reason = reason;
}

@JsonProperty("sourceCountryCode")
public String getSourceCountryCode() {
return sourceCountryCode;
}

@JsonProperty("sourceCountryCode")
public void setSourceCountryCode(String sourceCountryCode) {
this.sourceCountryCode = sourceCountryCode;
}

@JsonProperty("status")
public String getStatus() {
return status;
}

@JsonProperty("status")
public void setStatus(String status) {
this.status = status;
}

@JsonProperty("upcNumber")
public Double getUpcNumber() {
return upcNumber;
}

@JsonProperty("upcNumber")
public void setUpcNumber(Double upcNumber) {
this.upcNumber = upcNumber;
}

@JsonProperty("vnpkQuantity")
public Double getVnpkQuantity() {
return vnpkQuantity;
}

@JsonProperty("vnpkQuantity")
public void setVnpkQuantity(Double vnpkQuantity) {
this.vnpkQuantity = vnpkQuantity;
}

@JsonProperty("whpkQuantity")
public Integer getWhpkQuantity() {
return whpkQuantity;
}

@JsonProperty("whpkQuantity")
public void setWhpkQuantity(Integer whpkQuantity) {
this.whpkQuantity = whpkQuantity;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}