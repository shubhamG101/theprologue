package com.walmart.framework.utilities.logging;

public enum Project {
    BAJA("BAJA"),
    MCC("MCC"),
    RDC("RDC"),
    ACC("ACC"),
    ALL("ALL"),
    CLASSIC("CLASSIC");

    String project;
    public void setProject(String project) {
        this.project = project;
    }

    public String getProject() {
        return project;
    }

    Project(String project) {
        this.project = project;
    }
}
