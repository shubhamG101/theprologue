package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "whseAreaCodes", "orderDate"})
public class OrderWellTrigger {
	@JsonProperty("whseAreaCodes")
	private String whseAreaCodes;
	@JsonProperty("orderDate")
	private String orderDate;
	
	@JsonProperty("whseAreaCodes")
	public String getWhseAreaCodes() {
		return whseAreaCodes;
	}
	@JsonProperty("whseAreaCodes")
	public void setWhseAreaCodes(String whseAreaCodes) {
		this.whseAreaCodes = whseAreaCodes;
	}
	@JsonProperty("orderDate")
	public String getOrderDate() {
		return orderDate;
	}
	@JsonProperty("orderDate")
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
}