package com.walmart.framework.utilities.selenium;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.walmart.ste.devicelab.client.DeviceLabClient;
import com.walmart.ste.devicelab.client.lib.Reservation;
import com.walmart.ste.devicelab.client.lib.ReservationCapabilities;
import com.walmart.ste.devicelab.client.lib.UserCredentials;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class AppiumDriver {

	Logger logger = LogManager.getLogger(this.getClass());
	private DeviceLabClient dlClient;
	private Reservation reservation;
	private static final String MY_APPS_PACKAGE = "com.walmart.myapps.app";
	private static final String MY_APPS_ACTIVITY = ".MainActivity";
	private static final String DEVICE_MODEL = "TC70X";
	private static final String LAB_WEB_APP_BASE_URL = "http://plexus.walmart.com:8080";
	private static final String LAB_USER_ID = "GLS_Mavericks";
	private static final String LAB_USER_KEY = "d7646691-8060-4745-a1f8-76d8435ec956";
	private static final int RESERVATION_DURATION = 15;
	private static final String RX_APP_APK = "Receiving.apk";
	private static final String PBLM_APP_APK = "Problem.apk";// Add the required APKs for the tests below

	public AndroidDriver getAppiumDriver() throws Exception {

		AndroidDriver androidDriver;
		reserveDevice();
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities = reservation.getDeviceCapabilitiesObject();
		capabilities.setCapability("deviceName", reservation.getDeviceSerial());
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("udid", reservation.getDeviceSerial());
		capabilities.setCapability("appPackage", MY_APPS_PACKAGE);
		capabilities.setCapability("appActivity", MY_APPS_ACTIVITY);
		installAppPlexus();
		logger.info("Remote Driver url is:{}", dlClient.getWebDriverHubUrl());
		androidDriver = new AndroidDriver(dlClient.getWebDriverHubUrl(), capabilities);
		androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		logger.info("Plexus set up is completed and returning driver");
		return androidDriver;

	}

	public void installAppPlexus() throws Exception {

		List<String> appsToInstall = Arrays.asList(RX_APP_APK, PBLM_APP_APK);
		for (String app : appsToInstall) {
			File appFile = new File(this.getClass().getClassLoader().getResource(app).getFile());
			dlClient.uploadFile(appFile);
			reservation.installApp(app);
			logger.info("Installed app : {}", app);
			Thread.sleep(5000);
		}

		logger.info("Succesfully installed all the apks on the device in Plexus");
	}

	public void reserveDevice() throws Exception {

		System.setProperty("LAB_WEB_APP_BASE_URL", LAB_WEB_APP_BASE_URL);
		System.setProperty("LAB_USER_ID", LAB_USER_ID);
		System.setProperty("LAB_USER_KEY", LAB_USER_KEY);
		dlClient = new DeviceLabClient(UserCredentials.fromEnvironmentVariables());
		ReservationCapabilities reservationCapabilities = new ReservationCapabilities();
		reservationCapabilities.setReservationName("GLS_Mavericks: Mobile Lab : " + System.currentTimeMillis());
		reservationCapabilities.setReservationDuration(RESERVATION_DURATION);
		reservationCapabilities.setCapability("deviceModel", DEVICE_MODEL);
		reservation = dlClient.reserveDevice(reservationCapabilities);
		logger.info("Succesfully reserved a :{} device in Plexus with Device ID:{} and Device Serial: {} for the tests", DEVICE_MODEL,reservation.getDeviceId(),reservation.getDeviceSerial());

	}
	
	public AndroidDriver<AndroidElement> getMobileDriver(String ... args) {
		
		AndroidDriver<AndroidElement> driver=null;
		URL serverURL=null;
		DesiredCapabilities capabilities = new DesiredCapabilities();
		
		try {
			if(args[0].equals("LOCAL")){
			capabilities.setCapability("deviceName", "testDevice");
			capabilities.setCapability(CapabilityType.PLATFORM, "Android");
			capabilities.setCapability("automationName", "uiautomator2");
			capabilities.setCapability("appPackage", args[1]);
			logger.info("appPackage : {}",args[1]);
			capabilities.setCapability("appActivity", args[2]);
			logger.info("appActivity : {}",args[2]);
			capabilities.setCapability("platformVersion", args[3]);
			logger.info("platformVersion : {}",args[3]);
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
			capabilities.setCapability("avd", args[8]);
			logger.info("avd : {}", args[8]);
			serverURL=new URL(args[7]);
			} else {
			capabilities.setCapability("appium:deviceName", "Android");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("appium:automationName", "UIAutomator2");
			capabilities.setCapability("appium:app",args[4]);
			logger.info("app : {}", args[4]);
			capabilities.setCapability("appium:appActivity",args[2]);
			logger.info("appActivity : {}", args[2]);
			capabilities.setCapability("appium:appPackage", args[1]);
			logger.info("appPackage : {}", args[1]);
			capabilities.setCapability("appium:appWaitActivity", args[5]);
			logger.info("appWaitActivity : {}", args[5]);
			capabilities.setCapability("appium:appWaitDuration", "10000");
				//capabilities.setCapability("headless", "False");
			capabilities.setCapability("appium:noReset", "False");
			capabilities.setCapability("appium:fullReset", "True");
			capabilities.setCapability("appium:adbExecTimeout", 50000);
			serverURL=new URL(args[6]);
			}
			driver = new AndroidDriver<AndroidElement>(serverURL, capabilities);
			logger.info("Mobile app launched... ");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
		return driver;
	}

}
