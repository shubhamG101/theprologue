package com.walmart.framework.supplychain.constants;

public enum CHANNELS {

	SSTK("sstk"), CROSSU("crossu"), CROSSMU("crossmu"), CROSSNA("crossna"), CROSSNMA(
			"crossnma"), SSTKU("sstku"), STAPLESTOCK("staplestock"),POCON("pocon"),DSDC("dsdc");

	private String value;

	CHANNELS(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
