package com.walmart.framework.supplychain.domain.op;


import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({

"origTrackingNbrs"
})
public class OrderDownload {


@JsonProperty("origTrackingNbrs")
private List<String> origTrackingNbrs = null;


@JsonProperty("origTrackingNbrs")
public List<String> getOriginTrackingNum() {
return this.origTrackingNbrs;
}

@JsonProperty("origTrackingNbrs")
public void setOriginTrackingNum(List<String> origTrackingNbrs) {
this.origTrackingNbrs = origTrackingNbrs;
}


}
