package com.walmart.framework.supplychain.config;

public enum ENVIRONMENT {

    CERT("CERT"),QA("QA"),DEV("DEV"),PROD("PROD");

    String env;

    ENVIRONMENT(String env){
        this.env = env;
    }
    public String getValue() {
		return env;
	}
}