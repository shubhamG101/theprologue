package com.walmart.framework.supplychain.domain.rdc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "departmentNumber", "poNumber", "poLineNumber", "orderNumber", "gtin", "itemNumber", "financialReportingCode", "baseDivCode", 
	"quantity", "quantityUOM", "vendorPackQty", "warehousePackQty", "warehousePackSell", "currency" })
public class ASNItemDetails {
	@JsonProperty("departmentNumber")
	private String departmentNumber;
	@JsonProperty("poNumber")
	private String poNumber;
	@JsonProperty("poLineNumber")
	private String poLineNumber;
	@JsonProperty("orderNumber")
	private String orderNumber;
	@JsonProperty("gtin")
	private String gtin;
	@JsonProperty("itemNumber")
	private String itemNumber;
	@JsonProperty("financialReportingCode")
	private String financialReportingCode;
	@JsonProperty("baseDivCode")
	private String baseDivCode;
	@JsonProperty("quantity")
	private int quantity;
	@JsonProperty("quantityUOM")
	private String quantityUOM;
	@JsonProperty("vendorPackQty")
	private int vendorPackQty;
	@JsonProperty("warehousePackQty")
	private int warehousePackQty;
	@JsonProperty("warehousePackSell")
	private double warehousePackSell;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("departmentNumber")
	public String getDepartmentNumber() {
		return departmentNumber;
	}
	@JsonProperty("departmentNumber")
	public void setDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	@JsonProperty("poNumber")
	public String getPoNumber() {
		return poNumber;
	}
	@JsonProperty("poNumber")
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	@JsonProperty("poLineNumber")
	public String getPoLineNumber() {
		return poLineNumber;
	}
	@JsonProperty("poLineNumber")
	public void setPoLineNumber(String poLineNumber) {
		this.poLineNumber = poLineNumber;
	}
	@JsonProperty("orderNumber")
	public String getOrderNumber() {
		return orderNumber;
	}
	@JsonProperty("orderNumber")
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	@JsonProperty("gtin")
	public String getGtin() {
		return gtin;
	}
	@JsonProperty("gtin")
	public void setGtin(String gtin) {
		this.gtin = gtin;
	}
	@JsonProperty("itemNumber")
	public String getItemNumber() {
		return itemNumber;
	}
	@JsonProperty("itemNumber")
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	@JsonProperty("financialReportingCode")
	public String getFinancialReportingCode() {
		return financialReportingCode;
	}
	@JsonProperty("financialReportingCode")
	public void setFinancialReportingCode(String financialReportingCode) {
		this.financialReportingCode = financialReportingCode;
	}
	@JsonProperty("baseDivCode")
	public String getBaseDivCode() {
		return baseDivCode;
	}
	@JsonProperty("baseDivCode")
	public void setBaseDivCode(String baseDivCode) {
		this.baseDivCode = baseDivCode;
	}
	@JsonProperty("quantity")
	public int getQuantity() {
		return quantity;
	}
	@JsonProperty("quantity")
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@JsonProperty("quantityUOM")
	public String getQuantityUOM() {
		return quantityUOM;
	}
	@JsonProperty("quantityUOM")
	public void setQuantityUOM(String quantityUOM) {
		this.quantityUOM = quantityUOM;
	}
	@JsonProperty("vendorPackQty")
	public int getVendorPackQty() {
		return vendorPackQty;
	}
	@JsonProperty("vendorPackQty")
	public void setVendorPackQty(int vendorPackQty) {
		this.vendorPackQty = vendorPackQty;
	}
	@JsonProperty("warehousePackQty")
	public int getWarehousePackQty() {
		return warehousePackQty;
	}
	@JsonProperty("warehousePackQty")
	public void setWarehousePackQty(int warehousePackQty) {
		this.warehousePackQty = warehousePackQty;
	}
	@JsonProperty("warehousePackSell")
	public double getWarehousePackSell() {
		return warehousePackSell;
	}
	@JsonProperty("warehousePackSell")
	public void setWarehousePackSell(double warehousePackSell) {
		this.warehousePackSell = warehousePackSell;
	}
	@JsonProperty("currency")
	public String getCurrency() {
		return currency;
	}
	@JsonProperty("currency")
	public void setCurrency(String currency) {
		this.currency = currency;
	}
}

