package com.walmart.framework.supplychain.domain.witron;

import java.util.UUID;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "request","response","id","uuid" })
public class FinalObj {
		@JsonProperty("request") 
		private Request request;
		@JsonProperty("response") 
		private MockResponse response;
		@JsonProperty("id") 
		private String id;
		@JsonProperty("uuid") 
		private String uuid;
		public Request getRequest() {
			return request;
		}
		public void setRequest(Request request) {
			this.request = request;
		}
		public MockResponse getResponse() {
			return response;
		}
		public void setResponse(MockResponse response) {
			this.response = response;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getUuid() {
			return uuid;
		}
		public void setUuid(String uuid) {
			this.uuid = uuid;
		}
}


