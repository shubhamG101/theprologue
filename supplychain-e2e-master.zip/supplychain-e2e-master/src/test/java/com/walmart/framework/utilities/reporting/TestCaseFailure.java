package com.walmart.framework.utilities.reporting;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.walmart.framework.supplychain.constants.ErrorCodes;

public class TestCaseFailure extends AssertionError{
	public static final Logger LOGGER = LogManager.getLogger(TestCaseFailure.class);
	private static final String CLASS_NAME_IN_MSG="TestCaseFailure:";
	private static final String JUNIT_PACKAGE_NAME_IN_MSG="org.junit.ComparisonFailure: ";
	private static final String ASSERTION_PACKAGE_NAME_IN_MSG="java.lang.AssertionError: ";
	private static final String SERENITY_PACKAGE_NAME_IN_MSG="net.serenitybdd.core.exceptions.SerenityManagedException: ";

	public TestCaseFailure(ErrorCodes errorCode, Throwable cause) {  
        super(getErrorMessage(errorCode), cause);
        LOGGER.error("#Failure-TestCaseFailure:"+cause);
    }
	
	@Deprecated
	/*
	 * This method has been deprecated and will be removed eventually.. Please add your error message in Error code class and use 
	 * the method TestCaseFailure(ErrorCodes errorCode, Throwable cause) to throw your testcase failures/create jira ticket.
	 * Otherwise this will lead to rising multiple jira tickets for the same issue
	 */
	public TestCaseFailure(String message, Throwable cause) {  
        super(getExceptionMessage(cause, message), cause);
        LOGGER.error(cause);
    }
	
	public TestCaseFailure(String message) {  
        super(message);
    }
	public TestCaseFailure(Throwable cause) {  
        super(getErrorMessage(cause),cause);
    }
	private static String getErrorMessage(Throwable cause) {
		return processErrorMessage(cause.getMessage());
	}
	private static String getExceptionMessage(Throwable cause,String message) {
		return processErrorMessage(cause.getMessage(),message);
	}
	private static String getErrorMessage(ErrorCodes errorCode) {
		return processErrorMessage(errorCode.getErrorMessage());
	}
	private static String processErrorMessage(String errorMessage) {
		return processErrorMessage(null, errorMessage);
	}
	private static String processErrorMessage(String messageFromThrowable,String errorMessage) {
		if(messageFromThrowable!=null&&messageFromThrowable.contains(CLASS_NAME_IN_MSG)) {
			errorMessage= messageFromThrowable.substring(messageFromThrowable.lastIndexOf(CLASS_NAME_IN_MSG)+CLASS_NAME_IN_MSG.length(), messageFromThrowable.length());
		}
		if(errorMessage.contains(JUNIT_PACKAGE_NAME_IN_MSG)) {
			errorMessage=errorMessage.replaceAll(JUNIT_PACKAGE_NAME_IN_MSG, "");
		}
		if(errorMessage.contains(ASSERTION_PACKAGE_NAME_IN_MSG)) {
			errorMessage=errorMessage.replaceAll(ASSERTION_PACKAGE_NAME_IN_MSG, "");
		}
		if(errorMessage.contains(SERENITY_PACKAGE_NAME_IN_MSG)) {
			errorMessage=errorMessage.replaceAll(SERENITY_PACKAGE_NAME_IN_MSG, "");
		}
		
		return errorMessage;
	}
}
