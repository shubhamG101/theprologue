package com.walmart.framework.supplychain.domain.thor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "docLineNumber", "outboundChannelMethod", "baseDivCode", "financialReportGrpCode", "itemNumber", "shippedPrimaryQty", "shippedPrimaryUOM"})
public class SalesLine {
	
	@JsonProperty("docLineNumber")
	private int docLineNumber;
	@JsonProperty("outboundChannelMethod")
	private String outboundChannelMethod;
	@JsonProperty("baseDivCode")
	private String baseDivCode;
	@JsonProperty("financialReportGrpCode")
	private String financialReportGrpCode;
	@JsonProperty("itemNumber")
	private String itemNumber;
	@JsonProperty("shippedPrimaryQty")
	private int shippedPrimaryQty;
	@JsonProperty("shippedPrimaryUOM")
	private String shippedPrimaryUOM;
	
	@JsonProperty("docLineNumber")
	public int getDocLineNumber() {
		return docLineNumber;
	}
	@JsonProperty("docLineNumber")
	public void setDocLineNumber(int docLineNumber) {
		this.docLineNumber = docLineNumber;
	}
	@JsonProperty("outboundChannelMethod")
	public String getOutboundChannelMethod() {
		return outboundChannelMethod;
	}
	@JsonProperty("outboundChannelMethod")
	public void setOutboundChannelMethod(String outboundChannelMethod) {
		this.outboundChannelMethod = outboundChannelMethod;
	}
	@JsonProperty("baseDivCode")
	public String getBaseDivCode() {
		return baseDivCode;
	}
	@JsonProperty("baseDivCode")
	public void setBaseDivCode(String baseDivCode) {
		this.baseDivCode = baseDivCode;
	}
	@JsonProperty("financialReportGrpCode")
	public String getFinancialReportGrpCode() {
		return financialReportGrpCode;
	}
	@JsonProperty("financialReportGrpCode")
	public void setFinancialReportGrpCode(String financialReportGrpCode) {
		this.financialReportGrpCode = financialReportGrpCode;
	}
	@JsonProperty("itemNumber")
	public String getItemNumber() {
		return itemNumber;
	}
	@JsonProperty("itemNumber")
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	@JsonProperty("shippedPrimaryQty")
	public int getShippedPrimaryQty() {
		return shippedPrimaryQty;
	}
	@JsonProperty("shippedPrimaryQty")
	public void setShippedPrimaryQty(int shippedPrimaryQty) {
		this.shippedPrimaryQty = shippedPrimaryQty;
	}
	@JsonProperty("shippedPrimaryUOM")
	public String getShippedPrimaryUOM() {
		return shippedPrimaryUOM;
	}
	@JsonProperty("shippedPrimaryUOM")
	public void setShippedPrimaryUOM(String shippedPrimaryUOM) {
		this.shippedPrimaryUOM = shippedPrimaryUOM;
	}
}
