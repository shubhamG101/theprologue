package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "SSC" })
public class SSCBean {
	@JsonProperty("SSC")
	private SSC SSC;

	@JsonProperty("SSC")
	public SSC getSSC() {
		return SSC;
	}

	@JsonProperty("SSC")
	public void setSSC(SSC sSC) {
		SSC = sSC;
	}
}
