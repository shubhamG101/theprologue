package com.walmart.framework.utilities.db;

import java.util.HashMap;
import java.util.Map;

public class QueryHelper {
	private Map<String, String> QueryParam = new HashMap<String, String>();
	
	public String getSQLQueryParam(String query)  {
		String sNewQuery = "";
		if (query.contains("#")) {
			String[] partQuery = query.split("#");
				for (int i = 1; i < partQuery.length; i = i + 2) {
					partQuery[i] = QueryParam.get(partQuery[i]);
				}
				// loop again to combine the new value of the parameter into SQL
				for (int i = 0; i < partQuery.length; i++) {
					sNewQuery = sNewQuery + partQuery[i];
				}
		
		} else {
			sNewQuery = query;
		}
		return sNewQuery;
	}

	public void setQueryParam(String key, String value) {
		QueryParam.put(key, value);
	}
}
