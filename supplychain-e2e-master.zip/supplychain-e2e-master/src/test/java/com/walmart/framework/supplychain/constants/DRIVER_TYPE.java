package com.walmart.framework.supplychain.constants;

public enum DRIVER_TYPE {

	WEB_DRIVER("web_driver"),APPIUM_DRIVER("appium_driver");

	private String value;

	DRIVER_TYPE(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
