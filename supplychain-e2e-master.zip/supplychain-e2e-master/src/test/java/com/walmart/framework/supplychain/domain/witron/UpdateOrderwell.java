package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "updateList" })
public class UpdateOrderwell {
	@JsonProperty("updateList")
	private List<OTNList> updateList;
	@JsonProperty("updateList")
	public List<OTNList> getUpdateList() {
		return updateList;
	}
	@JsonProperty("updateList")
	public void setUpdateList(List<OTNList> updateList) {
		this.updateList = updateList;
	}
}
