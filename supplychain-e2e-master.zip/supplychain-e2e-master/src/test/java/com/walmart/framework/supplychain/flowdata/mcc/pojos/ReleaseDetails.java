package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "releaseNumber",
    "cycleNumber",
    "waveNumber",
    "loadId"
    })
public class ReleaseDetails {

    @JsonProperty("releaseNumber")
    private String releaseNumber;
    @JsonProperty("cycleNumber")
    private String cycleNumber;
    @JsonProperty("waveNumber")
    private String waveNumber;
    @JsonProperty("loadId")
    private String loadId;
   
    @JsonProperty("releaseNumber")
    public String getReleaseNumber() {
        return releaseNumber;
    }

    @JsonProperty("releaseNumber")
    public void setReleaseNumber(String releaseNumber) {
        this.releaseNumber = releaseNumber;
    }
    
    @JsonProperty("loadId")
    public String getLoadId() {
        return loadId;
    }

    @JsonProperty("loadId")
    public void setLoadId(String loadId) {
        this.loadId = loadId;
    }

    @JsonProperty("cycleNumber")
    public String getCycleNumber() {
        return cycleNumber;
    }

    @JsonProperty("cycleNumber")
    public void setCycleNumber(String cycleNumber) {
        this.cycleNumber = cycleNumber;
    }
 
   @JsonProperty("waveNumber")
    public String getWaveNumber() {
        return waveNumber;
    }

    @JsonProperty("waveNumber")
    public void setWaveNumber(String waveNumber) {
        this.waveNumber = waveNumber;
    }
}
