package com.walmart.framework.supplychain.domain.rdc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "packNumber", "destinationNumber", "destinationType", "destinationCountry", "channelMethod", "invoiceNumber", "items"})
public class ASNPackDetails {
	@JsonProperty("packNumber")
	private String packNumber;
	@JsonProperty("destinationNumber")
	private String destinationNumber;
	@JsonProperty("destinationType")
	private String destinationType;
	@JsonProperty("destinationCountry")
	private String destinationCountry;
	@JsonProperty("channelMethod")
	private String channelMethod;
	@JsonProperty("invoiceNumber")
	private String invoiceNumber;
	@JsonProperty("items")
	private List<ASNItemDetails> items;
	
	@JsonProperty("packNumber")
	public String getPackNumber() {
		return packNumber;
	}
	@JsonProperty("packNumber")
	public void setPackNumber(String packNumber) {
		this.packNumber = packNumber;
	}
	@JsonProperty("destinationNumber")
	public String getDestinationNumber() {
		return destinationNumber;
	}
	@JsonProperty("destinationNumber")
	public void setDestinationNumber(String destinationNumber) {
		this.destinationNumber = destinationNumber;
	}
	@JsonProperty("destinationType")
	public String getDestinationType() {
		return destinationType;
	}
	@JsonProperty("destinationType")
	public void setDestinationType(String destinationType) {
		this.destinationType = destinationType;
	}
	@JsonProperty("destinationCountry")
	public String getDestinationCountry() {
		return destinationCountry;
	}
	@JsonProperty("destinationCountry")
	public void setDestinationCountry(String destinationCountry) {
		this.destinationCountry = destinationCountry;
	}
	@JsonProperty("channelMethod")
	public String getChannelMethod() {
		return channelMethod;
	}
	@JsonProperty("channelMethod")
	public void setChannelMethod(String channelMethod) {
		this.channelMethod = channelMethod;
	}
	@JsonProperty("invoiceNumber")
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	@JsonProperty("invoiceNumber")
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	@JsonProperty("items")
	public List<ASNItemDetails> getItems() {
		return items;
	}
	@JsonProperty("items")
	public void setItems(List<ASNItemDetails> items) {
		this.items = items;
	}
}

