package com.walmart.framework.supplychain.domain.acc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "scannedInput",
    "storeNumber",
    "storeGroupName",
    "storeGroupId"
})
public class CompleteMCB {
	
	@JsonProperty("scannedInput")
    private String scannedInput;
    @JsonProperty("storeNumber")
    private int storeNumber;
    @JsonProperty("storeGroupName")
    private String storeGroupName;
    @JsonProperty("storeGroupId")
    private int storeGroupId;
    
	public String getStoreGroupName() {
		return storeGroupName;
	}
	public void setStoreGroupName(String storeGroupName) {
		this.storeGroupName = storeGroupName;
	}
	public int getStoreGroupId() {
		return storeGroupId;
	}
	public void setStoreGroupId(int storeGroupId) {
		this.storeGroupId = storeGroupId;
	}
	public String getScannedInput() {
		return scannedInput;
	}
	public void setScannedInput(String scannedInput) {
		this.scannedInput = scannedInput;
	}
	public int getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(int storeNumber) {
		this.storeNumber = storeNumber;
	}
    
}