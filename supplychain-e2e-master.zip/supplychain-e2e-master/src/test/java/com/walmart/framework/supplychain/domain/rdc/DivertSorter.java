package com.walmart.framework.supplychain.domain.rdc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "scannedLabel", "inductNumber", "labelStatus", "destination", "countryCode", "labelType",
		"cameraId", "msgEvent", "sorterId", "dispositionTimeStamp", "actualLane", "intendedLane" })
public class DivertSorter {
	@JsonProperty("scannedLabel")
	private String scannedLabel;
	@JsonProperty("inductNumber")
	private int inductNumber;
	@JsonProperty("labelStatus")
	private String labelStatus;
	@JsonProperty("destination")
	private String destination;
	@JsonProperty("countryCode")
	private String countryCode;
	@JsonProperty("labelType")
	private String labelType;
	@JsonProperty("cameraId")
	private String cameraId;
	@JsonProperty("msgEvent")
	private String msgEvent;
	@JsonProperty("sorterId")
	private String sorterId;
	@JsonProperty("dispositionTimeStamp")
	private String dispositionTimeStamp;
	@JsonProperty("actualLane")
	private String actualLane;
	@JsonProperty("intendedLane")
	private String intendedLane;

	@JsonProperty("scannedLabel")
	public String getScannedLabel() {
		return scannedLabel;
	}

	@JsonProperty("scannedLabel")
	public void setScannedLabel(String scannedLabel) {
		this.scannedLabel = scannedLabel;
	}

	@JsonProperty("inductNumber")
	public int getInductNumber() {
		return inductNumber;
	}

	@JsonProperty("inductNumber")
	public void setInductNumber(int inductNumber) {
		this.inductNumber = inductNumber;
	}

	@JsonProperty("labelStatus")
	public String getLabelStatus() {
		return labelStatus;
	}

	@JsonProperty("labelStatus")
	public void setLabelStatus(String labelStatus) {
		this.labelStatus = labelStatus;
	}

	@JsonProperty("destination")
	public String getDestination() {
		return destination;
	}

	@JsonProperty("destination")
	public void setDestination(String destination) {
		this.destination = destination;
	}

	@JsonProperty("countryCode")
	public String getCountryCode() {
		return countryCode;
	}

	@JsonProperty("countryCode")
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@JsonProperty("labelType")
	public String getLabelType() {
		return labelType;
	}

	@JsonProperty("labelType")
	public void setLabelType(String labelType) {
		this.labelType = labelType;
	}

	@JsonProperty("cameraId")
	public String getCameraId() {
		return cameraId;
	}

	@JsonProperty("cameraId")
	public void setCameraId(String cameraId) {
		this.cameraId = cameraId;
	}

	@JsonProperty("msgEvent")
	public String getMsgEvent() {
		return msgEvent;
	}

	@JsonProperty("msgEvent")
	public void setMsgEvent(String msgEvent) {
		this.msgEvent = msgEvent;
	}

	@JsonProperty("sorterId")
	public String getSorterId() {
		return sorterId;
	}

	@JsonProperty("sorterId")
	public void setSorterId(String sorterId) {
		this.sorterId = sorterId;
	}

	@JsonProperty("dispositionTimeStamp")
	public String getDispositionTimeStamp() {
		return dispositionTimeStamp;
	}

	@JsonProperty("dispositionTimeStamp")
	public void setDispositionTimeStamp(String dispositionTimeStamp) {
		this.dispositionTimeStamp = dispositionTimeStamp;
	}

	@JsonProperty("actualLane")
	public String getActualLane() {
		return actualLane;
	}

	@JsonProperty("actualLane")
	public void setActualLane(String actualLane) {
		this.actualLane = actualLane;
	}

	@JsonProperty("intendedLane")
	public String getIntendedLane() {
		return intendedLane;
	}

	@JsonProperty("intendedLane")
	public void setIntendedLane(String intendedLane) {
		this.intendedLane = intendedLane;
	}
}
