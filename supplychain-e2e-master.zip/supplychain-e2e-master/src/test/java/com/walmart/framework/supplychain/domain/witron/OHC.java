package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Owner", "OrderIdent", "DispatchDate", "OrderCompletionTime", "OrderReceiptDateTime", "OLC" })
public class OHC {
	@JsonProperty("Owner")
	private OwnerBean Owner;
	@JsonProperty("OrderIdent")
	private String OrderIdent;
	@JsonProperty("DispatchDate")
	private String DispatchDate;
	@JsonProperty("OrderCompletionTime")
	private String OrderCompletionTime;
	@JsonProperty("OrderReceiptDateTime")
	private String OrderReceiptDateTime;
	@JsonProperty("OLC")
	private List<OLC> OLC;
	@JsonProperty("Owner")
	public OwnerBean getOwner() {
		return Owner;
	}
	@JsonProperty("Owner")
	public void setOwner(OwnerBean owner) {
		Owner = owner;
	}
	@JsonProperty("OrderIdent")
	public String getOrderIdent() {
		return OrderIdent;
	}
	@JsonProperty("OrderIdent")
	public void setOrderIdent(String orderIdent) {
		OrderIdent = orderIdent;
	}
	@JsonProperty("DispatchDate")
	public String getDispatchDate() {
		return DispatchDate;
	}
	@JsonProperty("DispatchDate")
	public void setDispatchDate(String dispatchDate) {
		DispatchDate = dispatchDate;
	}
	@JsonProperty("OrderCompletionTime")
	public String getOrderCompletionTime() {
		return OrderCompletionTime;
	}
	@JsonProperty("OrderCompletionTime")
	public void setOrderCompletionTime(String orderCompletionTime) {
		OrderCompletionTime = orderCompletionTime;
	}
	@JsonProperty("OrderReceiptDateTime")
	public String getOrderReceiptDateTime() {
		return OrderReceiptDateTime;
	}
	@JsonProperty("OrderReceiptDateTime")
	public void setOrderReceiptDateTime(String orderReceiptDateTime) {
		OrderReceiptDateTime = orderReceiptDateTime;
	}
	@JsonProperty("OLC")
	public List<OLC> getOLC() {
		return OLC;
	}
	@JsonProperty("OLC")
	public void setOLC(List<OLC> oLC) {
		OLC = oLC;
	}
}
