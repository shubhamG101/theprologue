package com.walmart.framework.utilities.logging;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.restclient.SpringRestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import spring.SpringTestConfiguration;

import java.io.FileNotFoundException;

@ContextConfiguration(classes = SpringTestConfiguration.class)
//@RunWith(SpringRunner.class)
public class LoggingUtils {

    @Autowired
    SpringRestClient restClient;

    @Autowired
    JsonUtils jsonUtils;

    @Autowired
    Environment environment;

    final String userDir = System.getProperty("user.dir");

    public void changeLogLevels(LogLevels ll, Project project) throws FileNotFoundException {

        String projectName = project.getProject().toLowerCase();

        String[] warComponentsArr = null, jarComponentsArr = null;

        warComponentsArr = environment.getRequiredProperty(projectName +"_op_war_components").split(",");

        jarComponentsArr = environment.getRequiredProperty(projectName +"_op_jar_components").split(",");


        final int ASSUMED_MAX_NO_OF_KUBE_PODS = 4;

        String logLevel = jsonUtils.getJsonStringFromFile(userDir + environment.getRequiredProperty("op_log_level_json_payload"));

        DocumentContext dc = JsonPath.parse(logLevel).set("logLevel", ll.getLogLevel());

        dc = dc.set("rootLogLevel", ll.getLogLevel());

        changeLogLevelForComponents(warComponentsArr, ASSUMED_MAX_NO_OF_KUBE_PODS, restClient, dc, "/logs/changeLogLevel");

        changeLogLevelForComponents(jarComponentsArr, ASSUMED_MAX_NO_OF_KUBE_PODS, restClient, dc, "/changeLogLevel");

    }

    private void changeLogLevelForComponents(String[] jarComponentsArr, int ASSUMED_MAX_NO_OF_KUBE_PODS, SpringRestClient restClient, DocumentContext dc, String s) {
        for (int i = 0; i < jarComponentsArr.length; i++) {
            for (int j = 0; j < ASSUMED_MAX_NO_OF_KUBE_PODS; j++) {
                ResponseEntity responseEntity = restClient.putResource(
                        environment.getRequiredProperty("CONTEXT_URL") + "/" + jarComponentsArr[i] + s, dc.jsonString(), String.class);
                System.out.println("Changed log level for " + jarComponentsArr[i] + " response code of : "
                        + responseEntity.getStatusCode());
            }
        }
    }

//    @Test
    public void testLogger() throws FileNotFoundException {
        changeLogLevels(LogLevels.ALL,Project.BAJA);
    }
}
