package com.walmart.framework.utilities;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.bean.OpencsvUtils;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CSVHandlerUtil {

    public static List<String> getFeatureList(String dcType) {
        return getFeatureList(dcType, ',');
    }

    public static List<String> getFeatureList(String dcType, char seperator) {
        List<String> featureList = new ArrayList<>();
        CSVReader reader = null;
        try {
            String fileName = "./src/test/resources/" + dcType + "FeatureRunner.csv";
            CSVParser parser = new CSVParserBuilder().withSeparator(seperator).build();
            reader = new CSVReaderBuilder(new FileReader(fileName))
                    .withSkipLines(1).withCSVParser(parser)
                    .build();
            List<String[]> allData = reader.readAll();
            int noOfFeaturesToBeRun = 0;
            for(String[] row : allData){
                if(row[0].trim().equalsIgnoreCase("Yes")) {
                    featureList.add(row[1].trim());
                    noOfFeaturesToBeRun++;
                }
            }
            System.out.println("noOfFeaturesToBeRun="+ noOfFeaturesToBeRun);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return featureList;
        }
    }
}