package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "childLabel",
    "masterLabel",
    "scannedLabel",
    "validateInventory",
    "contextLabel",
    "storeGroupId",
    "storeGroupName",
    "generateMasterLabel"
})
public class ScanFirstPalletForMCB {
	
	@JsonProperty("childLabel")
    private String childLabel;
    @JsonProperty("masterLabel")
    private String masterLabel;
    @JsonProperty("scannedLabel")
    private String scannedLabel;
    @JsonProperty("validateInventory")
    private boolean validateInventory;
    @JsonProperty("contextLabel")
    private String contextLabel;
    @JsonProperty("storeGroupId")
    private int storeGroupId;
    @JsonProperty("storeGroupName")
    private String storeGroupName;
    @JsonProperty("generateMasterLabel")
    private boolean generateMasterLabel;
	public String getChildLabel() {
		return childLabel;
	}
	public void setChildLabel(String childLabel) {
		this.childLabel = childLabel;
	}
	public String getMasterLabel() {
		return masterLabel;
	}
	public void setMasterLabel(String masterLabel) {
		this.masterLabel = masterLabel;
	}
	public String getScannedLabel() {
		return scannedLabel;
	}
	public void setScannedLabel(String scannedLabel) {
		this.scannedLabel = scannedLabel;
	}
	public boolean isValidateInventory() {
		return validateInventory;
	}
	public void setValidateInventory(boolean validateInventory) {
		this.validateInventory = validateInventory;
	}
	public String getContextLabel() {
		return contextLabel;
	}
	public void setContextLabel(String contextLabel) {
		this.contextLabel = contextLabel;
	}
	public int getStoreGroupId() {
		return storeGroupId;
	}
	public void setStoreGroupId(int storeGroupId) {
		this.storeGroupId = storeGroupId;
	}
	public String getStoreGroupName() {
		return storeGroupName;
	}
	public void setStoreGroupName(String storeGroupName) {
		this.storeGroupName = storeGroupName;
	}
	public boolean isGenerateMasterLabel() {
		return generateMasterLabel;
	}
	public void setGenerateMasterLabel(boolean generateMasterLabel) {
		this.generateMasterLabel = generateMasterLabel;
	}

    
	
    
}