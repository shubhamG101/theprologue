package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "dcNumber", "deliveryNbr", "includeDc" })
public class ProblemSearch {

	@JsonProperty("dcNumber")
	private int dcNumber;
	@JsonProperty("deliveryNbr")
	private int deliveryNbr;
	@JsonProperty("includeDc")
	private boolean includeDc;

	@JsonProperty("dcNumber")
	public int getDcNumber() {
		return dcNumber;
	}
	@JsonProperty("dcNumber")
	public void setDcNumber(int dcNumber) {
		this.dcNumber = dcNumber;
	}
	@JsonProperty("deliveryNbr")
	public int getDeliveryNbr() {
		return deliveryNbr;
	}
	@JsonProperty("deliveryNbr")
	public void setDeliveryNbr(int deliveryNbr) {
		this.deliveryNbr = deliveryNbr;
	}
	@JsonProperty("includeDc")
	public boolean isIncludeDc() {
		return includeDc;
	}
	@JsonProperty("includeDc")
	public void setIncludeDc(boolean includeDc) {
		this.includeDc = includeDc;
	}
	
	
}