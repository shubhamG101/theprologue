package com.walmart.framework.utilities.logging.pojo;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "logLevel",
    "rootLogLevel"
})
public class ChangeLogLevel {

    @JsonProperty(value = "logLevel")
    private String logLevel = "INFO";

    @JsonProperty(value = "rootLogLevel")
    private String rootLogLevel = "INFO";

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("logLevel")
    public String getLogLevel() {
        return logLevel;
    }

    @JsonProperty("logLevel")
    public void setLogLevel(String logLevel) {
        if(logLevel!=null){
            this.logLevel = logLevel;
        }
    }

    public ChangeLogLevel withLogLevel(String logLevel) {
        this.logLevel = logLevel;
        return this;
    }

    @JsonProperty("rootLogLevel")
    public String getRootLogLevel() {
        return rootLogLevel;
    }

    @JsonProperty("rootLogLevel")
    public void setRootLogLevel(String rootLogLevel) {
        if(rootLogLevel!=null){
            this.rootLogLevel = rootLogLevel;
        }
    }

    public ChangeLogLevel withRootLogLevel(String rootLogLevel) {
        this.rootLogLevel = rootLogLevel;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChangeLogLevel withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("logLevel", logLevel).append("rootLogLevel", rootLogLevel).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalProperties).append(logLevel).append(rootLogLevel).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChangeLogLevel) == false) {
            return false;
        }
        ChangeLogLevel rhs = ((ChangeLogLevel) other);
        return new EqualsBuilder().append(additionalProperties, rhs.additionalProperties).append(logLevel, rhs.logLevel).append(rootLogLevel, rhs.rootLogLevel).isEquals();
    }

}
