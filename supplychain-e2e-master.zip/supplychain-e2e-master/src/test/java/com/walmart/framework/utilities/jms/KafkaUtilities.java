package com.walmart.framework.utilities.jms;

import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import net.minidev.json.JSONObject;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class KafkaUtilities {
	public enum Server {
		CLUSTER1,CLUSTER2
		,CLUSTER3
		;
		public String getValue() {
			return this.name();
		}
	}
	Logger logger = LogManager.getLogger(KafkaUtils.class);

	@Autowired
	Environment environment;

	@Autowired
	@Qualifier("KafkaTemplate")
	KafkaTemplate<String, String> kafkaTemplate;

//	@Autowired
//	@Qualifier("KafkaTemplateHE")
//	KafkaTemplate<String, String> kafkaTemplateHawkeyePublish;
//	
//	@Autowired
//	@Qualifier("KafkaTemplateCluster3")
//	KafkaTemplate<String, String> kafkaTemplateCluster3;


	KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> listenerFactory;

	private static final String WMT_USER_ID = "system";
	JavaUtils javaUtils = new JavaUtils();
	ObjectMapper  om=new ObjectMapper();
	private static final Integer SUBCENTERID = 224;

	public Properties getKakfaServerProperties(String bootstrapServer) {

		Properties properties = new Properties();
		properties.put("bootstrap.servers", bootstrapServer);
		properties.put("acks", "all");
		properties.put("retries", 0);
		properties.put("batch.size", 16384);
		properties.put("linger.ms", 1);
		properties.put("buffer.memory", 33554432);
		properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		return properties;
	}

	public void publishKafkaMessage(String bootstrapServer, String topicName, JSONObject message1) {
		try {
			if(Config.ENV==ENVIRONMENT.CERT) {
				publishKafkaMessage(topicName, om.writeValueAsString(message1),Server.CLUSTER1);
			}else {
				publishKafkaMessage(topicName, om.writeValueAsString(message1),Server.CLUSTER2);
			}
		} catch (JsonProcessingException e) {
			throw new AutomationFailure("Something went wrong while constructing message for kafka Message");
		}
	}
	public void publishKafkaMessageHE(String bootstrapServer, String topicName, JSONObject message1) {
		try {
			publishKafkaMessage(topicName, om.writeValueAsString(message1),Server.CLUSTER1);
		} catch (JsonProcessingException e) {
			throw new AutomationFailure("Something went wrong while constructing message for kafka Message");
		}
	}
	public void publishKafkaMessage(String topicName, String message,Server server,String... headerKeyAndValues) {
		publishKafkaMessage(topicName, message, server, true, headerKeyAndValues);
	}
	public void publishKafkaMessage(String topicName, String message,Server server,boolean isExistingHeadersRequired,String... headerKeyAndValues) {
		String uuid = javaUtils.getUUID();
		logger.info("Topic:{} correlationId:{} ",topicName,uuid);
		 MessageBuilder<String> messageBuilder = MessageBuilder.withPayload(message)
		        .setHeader(KafkaHeaders.TOPIC, topicName.getBytes())
		        .setHeader(KafkaHeaders.MESSAGE_KEY, uuid);
		 if(isExistingHeadersRequired) {
			 
			 BigInteger facilityNum = BigInteger.valueOf(Integer.parseInt(environment.getProperty("facility_num")));
			 messageBuilder .setHeader("sourceNumber", facilityNum.toByteArray())
		        .setHeader("country",environment.getProperty("country_code").getBytes(Charset.forName("UTF-8")));
//		        .setHeader("WMT-UserId", WMT_USER_ID.getBytes())
//		        .setHeader("correlationId", uuid.getBytes())
//		        .setHeader("subcenterId", SUBCENTERID.toString().getBytes());
		 }
		 if(headerKeyAndValues!=null&&headerKeyAndValues.length>0&&headerKeyAndValues.length%2==0) {
			 for(int i=0;i+1<headerKeyAndValues.length;i+=2 ) {
				 messageBuilder.setHeader(headerKeyAndValues[i], headerKeyAndValues[i+1].getBytes());
			 }
		 }
		   Message<String> messages = messageBuilder.build();
       try {
       		if(server==Server.CLUSTER1) {
       			kafkaTemplate.send(messages).get();
     		}
 //      			else if(server==Server.CLUSTER2) {
//       			kafkaTemplateHawkeyePublish.send(messages).get();
//       		}
//       		else if(server==Server.CLUSTER3) {
//       			kafkaTemplateCluster3.send(messages).get();
//       		}
		} catch (InterruptedException | ExecutionException e) {
			Thread.currentThread().interrupt();
			throw new AutomationFailure("Something went wrong while publishing kafka Message",e);
		}
      logger.info("Published message->{}",message);
	}


	/*@KafkaListener(topics = "${hawkeye_print_ack_topic}")
	public void receive(@Payload String data, @Headers MessageHeaders messageHeaders) {
		logger.info("received Print message='{}'", data);
		// messageHeaders.keySet().forEach(key -> {
		// Object value = messageHeaders.get(key);
		// if (key.equals("Header")){
		// logger.info("{}: {}", key, new String((byte[])value));
		// } else {
		// logger.info("{}: {}", key, value);
		// }
		// }); If Needed to check header details, Then enable it
	}
	@KafkaListener(topics = "${hawkeye_scan_topic}")
	public void receive(@Payload String data) {
		logger.info("received Scan message='{}'", data);
	}*/
}


