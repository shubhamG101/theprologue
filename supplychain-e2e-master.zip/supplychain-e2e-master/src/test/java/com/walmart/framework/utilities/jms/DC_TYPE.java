package com.walmart.framework.utilities.jms;

public enum DC_TYPE {

    MCC("MCC"),MCC_RDC("MCC_RDC"),ATLAS_RDC("ATLAS_RDC"),ACC_RDC("ACC_RDC"),ATLAS("ATLAS"),ACC("ACC"),
    ATLASPROD("ATLASPROD"),THOR("THOR"),BAJA("BAJA"),WITRON("WITRON"),GDC("GDC"),SAMS("SAMS"),PHARMACY("PHARMACY"),RDC("RDC"),CATALYST("CATALYST"),WFS("WFS"),IMPORTS("IMPORTS"),VCOE("VCOE"), DPB("DPB");

    String dcType;

    DC_TYPE(String dcType){
        this.dcType = dcType;
    }
    public String getValue() {
		return dcType;
	}
}
