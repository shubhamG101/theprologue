package com.walmart.framework.utilities.jms;

import java.time.Clock;
import java.time.ZoneId;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import io.strati.StratiServiceProvider;
import io.strati.messaging.jms.MessagingJMSService;
import io.strati.messaging.jms.spi.AxonMessagingJMSServiceImpl;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class SchedulerConnectionUtil {

	TextMessage message = null;

	@Autowired
	Environment env;

	@Autowired
	JavaUtils javaUtils;

	@Autowired
	@Qualifier("schedulerJmsConnectionFactory")
	ConnectionFactory schedulerJmsConnectionFactory;
	
	@Autowired
	@Qualifier("ymsJmsConnectionFactory")
	ConnectionFactory ymsJmsConnectionFactory;
	
	@Autowired
	AxonMessagingJMSServiceImpl axonMessagingJMSService;

	static final Logger LOGGER = LogManager.getLogger(StratiConnectionUtil.class);

	public void publishCreateDeliveryMessage(String subModelName, String messageString, String subscriptionModel,String eventType) {
		synchronized (this) {
			String environmentType;
			MessageProducer msgSender = null;
			Session session = null;
			Connection connection = null;
			ConnectionFactory connectionFactory = null;
			Destination destination;

			try {
				connection = schedulerJmsConnectionFactory.createConnection();
				connection.start();
				session =connection.createSession(Session.SESSION_TRANSACTED);
				if (session != null) {
					if (subscriptionModel.equalsIgnoreCase("queue")) {
						destination = session.createQueue(subModelName);
					} else {
						destination = session.createTopic(subModelName);
					}
					msgSender = session.createProducer(destination);
					msgSender.setDeliveryMode(DeliveryMode.PERSISTENT);
					message = session.createTextMessage(messageString);
					message.setStringProperty("sourceDcNbr", env.getProperty("facility_num"));
					message.setStringProperty("sourceCountryCd", env.getProperty("country_code"));
					if (Config.ENV != ENVIRONMENT.PROD) {
						message.setStringProperty("environmentId", env.getProperty("facility_num"));
					}
					message.setStringProperty("WMT_UserId", "sysadmin");
					message.setStringProperty("WMT_CorrelationId", UUID.randomUUID().toString());
					message.setStringProperty("facilityNum", env.getProperty("facility_num"));
					message.setStringProperty("facilityCountryCode", env.getProperty("country_code"));
					if (Config.DC == DC_TYPE.WITRON) {
						message.setStringProperty("source", env.getProperty("idm_header_source"));
					}

					if (eventType != null) {
						message.setStringProperty("eventType", eventType);

						if (Config.DC == DC_TYPE.ACC && eventType.equals("CHANNEL_UPDATE")) {
							// Specific to ACC for Channel Flip simulation fetching itemnumber from message
							JSONObject obj = new JSONObject(messageString);
							String itemNumber = obj.getString("itemNumber");

							message.setStringProperty("itemNumber", itemNumber);
							message.setStringProperty("idempotencyKey", javaUtils.getUUID());

						}
					}

					LOGGER.info("Message Header:{}", message.toString());
					msgSender.send(message);
					session.commit();
				}
				msgSender.close();
				session.close();
				connection.close();
			} catch (Exception e) {
				LOGGER.error(e);
				throw new AutomationFailure("Unable to Publish the delivery message in Straati", e);
			}
		}
	}
	
	public void publishYMSMessage(String subModelName, String messageString, String subscriptionModel,String eventType) {
		synchronized (this) {
			MessageProducer msgSender = null;
			Session session = null;
			Connection connection = null;
			Destination destination;

			try {
				connection = ymsJmsConnectionFactory.createConnection();
				connection.start();
				session =connection.createSession(Session.SESSION_TRANSACTED);
				if (session != null) {
					if (subscriptionModel.equalsIgnoreCase("queue")) {
						destination = session.createQueue(subModelName);
					} else {
						destination = session.createTopic(subModelName);
					}
					msgSender = session.createProducer(destination);
					msgSender.setDeliveryMode(DeliveryMode.PERSISTENT);
					message = session.createTextMessage(messageString);
					message.setStringProperty("sourceId", env.getProperty("yms_sourceId_id"));
					message.setStringProperty("dcNumber", env.getProperty("facility_num"));
					message.setStringProperty("countryCode", env.getProperty("country_code"));
					message.setStringProperty("correlationId", UUID.randomUUID().toString());
					message.setStringProperty("eventType", eventType);
					message.setStringProperty("eventTimeStamp", getTime(100));
					message.setStringProperty("version", env.getProperty("yms_version"));
					message.setStringProperty("userId", env.getProperty("yms_user_id"));
					LOGGER.info("Message Header:{}", message.toString());
					msgSender.send(message);
					session.commit();
				}
				msgSender.close();
				session.close();
				connection.close();
			} catch (Exception e) {
				LOGGER.error(e);
				throw new AutomationFailure("Unable to Publish the delivery message in Straati", e);
			}
		}
	}
	
	public String getTime(int secToAdd) {
		Clock clock = Clock.system(ZoneId.of("Asia/Calcutta"));
		return clock.instant().plusSeconds(secToAdd).toString();
	}
}
