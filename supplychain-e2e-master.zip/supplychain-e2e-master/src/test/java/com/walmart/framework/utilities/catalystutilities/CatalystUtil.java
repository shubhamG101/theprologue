package com.walmart.framework.utilities.catalystutilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.catalyst.BOH;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.selenium.SerenityHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;

public class CatalystUtil extends SerenityHelper {
	@Autowired
	Environment environment;
	
	@Autowired
	DbUtils dbUtils;
	
	private static final String TEST_FLOW_DATA = "testFlowData";

	private static final String BOH = "boh";
	private static final String TOTAL_WEIGHT = "totalWeight";
	private static final String WAC = "wac";
	private static final String WAW = "waw";
	
	private static final String TURN = "TURN";
	private static final String DISTRO = "DISTRO";
	private static final String ALL = "ALL";
	private static final String GROUP_BY_ATTRIBUTE = "rotateDate";
	private static final String GROUP_BY_ATTRIBUTE_ORDER_BY = "asc";
	private static final String BASEDIVISION_CODE = "WM";
	private static final String FINANCIAL_REPORTING_GROUP = "US";
	private static final String INVENTORY_STATUS = "AVAILABLE";
	private static final String BOH_QTY = "1";
	private static final String BOH_QTY_UOM = "EA";
	private static final String WMT_USER_ID = "sysadmin";
	private static final String CONETENT_TYPE = "application/json";
	private static final String CORRELATIONID = "676726";
	
	private List<String> poNumberList;
	private DocumentContext parsedJson;
	
	ObjectMapper om = new ObjectMapper();
	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	
	Response response;
	
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	//private static final String TEST_FLOW_DATA = "testFlowData";
	
	Logger logger = LogManager.getLogger(this.getClass());
	
	
	 public void verifyElementIsDisplayed(WebElement element) {
			Boolean isDisplayed=element.isDisplayed();
			logger.info("Element " + (isDisplayed ? element.getText() : "NOT ") + " is displayed.");
			Assert.assertTrue(ErrorCodes.CATALYST_LABEL_MISMATCH,isDisplayed);	
		}
		
		
		 public void verifyElementValue(WebElement element, String expectedValue) {
			logger.info("VerifyElement Value -> Actual Value: "+element.getText()+" Expected Value: "+expectedValue);
			Assert.assertEquals(ErrorCodes.CATALYST_LABEL_MISMATCH,"Value Mismatch-> Actual Value: "+element.getText()+" Expected Value: "+expectedValue,element.getText(), expectedValue);	
		}
		  
		 public void verifyElementValue1(WebElement element, String expectedValue) {
				logger.info("VerifyElement Value -> Actual Value is :=>"+element.getText()+"&Expected Value is :=>"+expectedValue);
				String actualValue = element.getText().trim();
//				Assert.assertEquals(ErrorCodes.CATALYST_LABEL_MISMATCH,"Value Mismatch-> Actual Value: "+element.getText()+" Expected Value: "+expectedValue,element.getText(), expectedValue);	
//				Assert.assertEquals(ErrorCodes.CATALYST_LABEL_MISMATCH,"Value Mismatch-> Expected Value:=>"+expectedValue+"Actual Value:=>"+element.getText().trim(),expectedValue.trim(),element.getText().trim());
				Assert.assertEquals(ErrorCodes.CATALYST_LABEL_MISMATCH, expectedValue.trim(),actualValue.contains(expectedValue));
			} 
		 
		 
		 
		public void verifyElementValues(WebElement element, String expectedValue) {
			logger.info("VerifyElement Value -> Actual Value:"+element.getText()+" Expected Value:"+expectedValue);
			
			String actualValue = element.getText().trim();
			String acctualValueToBeValidated = null;
			
			if(actualValue.contains(":")){
				int delimiter = actualValue.indexOf(":");
				
				acctualValueToBeValidated = actualValue.substring(delimiter+1).trim();
				
			}else {
				acctualValueToBeValidated = actualValue;
			}
			logger.info(""+acctualValueToBeValidated);
			Assert.assertEquals(ErrorCodes.CATALYST_LABEL_MISMATCH, expectedValue, acctualValueToBeValidated);	
		}
		
		public void verifyElementValuesByContainsText(WebElement element, String expectedValue) {
			
			logger.info("VerifyElement Value -> Actual Value:"+element.getText()+" Expected Value:"+expectedValue);
			
			String actualValue = element.getText().trim();
			boolean acctualValueToBeValidated;
			
			acctualValueToBeValidated = actualValue.contains(expectedValue);
				
			logger.info(""+acctualValueToBeValidated);
//			Assert.assertEquals(ErrorCodes.CATALYST_LABEL_MISMATCH, true, acctualValueToBeValidated);
			Assert.assertTrue(ErrorCodes.CATALYST_LABEL_MISMATCH, acctualValueToBeValidated);
		}
		

	
	public String getItemBOH(List<String> itemNumList) {

		List orderTypeList = new ArrayList();
		orderTypeList.add(ALL);
	//	orderTypeList.add(DISTRO);

		BOH boh = new BOH();
		boh.setGroupByAttr(GROUP_BY_ATTRIBUTE);
		boh.setGroupByAttrOrderBy(GROUP_BY_ATTRIBUTE_ORDER_BY);
		boh.setItemList(itemNumList);
		boh.setPoTypeList(orderTypeList);
		boh.setBaseDivisionCode(BASEDIVISION_CODE);
		boh.setFinancialReportingGroup(FINANCIAL_REPORTING_GROUP);
		boh.setInventoryStatus(INVENTORY_STATUS);
		boh.setInventoryStatus(INVENTORY_STATUS);
		boh.setBohQty(BOH_QTY);
		boh.setBohQtyUom(BOH_QTY_UOM);

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().body(om.writeValueAsString(boh))
					.headers(getHeaderForInventoryBOH()).post(environment.getProperty("catalyst_inventory_boh"));
			Assert.assertEquals(ErrorCodes.WITRON_GET_BOH_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}
	
	public Headers getHeaderForInventoryBOH() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("witron_facility_country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		//Header userId = new Header("WMT-CorrelationId", CORRELATIONID);
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		//headerList.add(userId);
		headerList.add(appType);
		return new Headers(headerList);

	}

	public void setBoh() {
		try {
			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<String> item = new ArrayList();
			List<PoDetail> newPOList = new ArrayList<PoDetail>();
			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					String promoInd = null;
				String itemNumber=	lineDetail.getItemNumber();
				item.add(itemNumber);
					boolean isVariable = lineDetail.getIsVariableWeight();

					if (lineDetail.getPromoInd().equals("N")) {
						promoInd = "TURN";
					} else {
						promoInd = "DISTRO";
					}
					String inventoryBOHResponse =getItemBOH(item);
					logger.info("Inventory BOh Response is :"+inventoryBOHResponse);
					JSONArray listOfBOH = JsonPath.read(inventoryBOHResponse, "$.itemBohDistribution[?(@.itemNumber == '"+itemNumber+ "')].groupByAttrBohDistribution[*].bohQty");
					String bohString = listOfBOH.toJSONString();
					List<String> bohList = om.readValue(bohString, new TypeReference<List<String>>() {
					});
					int bohQty = 0;
					for (String qty : bohList) {
						bohQty += Integer.parseInt(qty);
					}
					lineDetail.setBoh(bohQty);
     				lineDetail.setWac(Double.parseDouble(lineDetail.getWhpkSellPrice()));
					newpoLineList.add(lineDetail);
				}
				poDetail.setPoLineDetails(newpoLineList);
				newPOList.add(poDetail);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			threadLocal.get().put(TEST_FLOW_DATA, str);
			logger.info((String) threadLocal.get().get(TEST_FLOW_DATA));

		} catch (Exception e) {
			throw new AutomationFailure("Failed to set BOH, WAW, WAW, Total weight", e);
		}
	}
	
	
	public boolean elementIsPresentOrNot(WebElement element) {
		boolean flag;
		List<WebElement> elements = new ArrayList<WebElement>();
		elements.add(element);
		
		if(elements.size() > 0)
			flag = true;
		else
			flag = false;
		
		return flag;
	}
	
	public boolean isElementVisible(WebElement elementToCheck) {
		try {
			element(elementToCheck).waitUntilVisible().withTimeoutOf(10, TimeUnit.SECONDS);
			return true;
		} catch (Exception e) {
			logger.info("Expected element is not visible on the screen");
			return false;
		}
	}
		
		
}


	

