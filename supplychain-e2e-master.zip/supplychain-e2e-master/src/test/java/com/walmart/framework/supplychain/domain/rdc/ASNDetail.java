package com.walmart.framework.supplychain.domain.rdc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "destinationNumber", "destinationCountry", "destinationType", "sourceNumber", "sourceCountry", "sourceType", "asnId", "asnDate", 
	"carrierId", "shipperName", "shipDate", "loadNumber", "trailerSealNumber", "billOfLadingNumber", "trailerNumber", "packs" })
public class ASNDetail {
	@JsonProperty("destinationNumber")
	private String destinationNumber;
	@JsonProperty("destinationCountry")
	private String destinationCountry;
	@JsonProperty("destinationType")
	private String destinationType;
	@JsonProperty("sourceNumber")
	private String sourceNumber;
	@JsonProperty("sourceCountry")
	private String sourceCountry;
	@JsonProperty("sourceType")
	private String sourceType;
	@JsonProperty("asnId")
	private String asnId;
	@JsonProperty("asnDate")
	private String asnDate;
	@JsonProperty("carrierId")
	private String carrierId;
	@JsonProperty("shipperName")
	private String shipperName;
	@JsonProperty("shipDate")
	private String shipDate;
	@JsonProperty("loadNumber")
	private String loadNumber;
	@JsonProperty("trailerSealNumber")
	private String trailerSealNumber;
	@JsonProperty("billOfLadingNumber")
	private String billOfLadingNumber;
	@JsonProperty("trailerNumber")
	private String trailerNumber;
	@JsonProperty("packs")
	private List<ASNPackDetails> packs;
	
	@JsonProperty("destinationNumber")
	public String getDestinationNumber() {
		return destinationNumber;
	}
	@JsonProperty("destinationNumber")
	public void setDestinationNumber(String destinationNumber) {
		this.destinationNumber = destinationNumber;
	}
	@JsonProperty("destinationCountry")
	public String getDestinationCountry() {
		return destinationCountry;
	}
	@JsonProperty("destinationCountry")
	public void setDestinationCountry(String destinationCountry) {
		this.destinationCountry = destinationCountry;
	}
	@JsonProperty("destinationType")
	public String getDestinationType() {
		return destinationType;
	}
	@JsonProperty("destinationType")
	public void setDestinationType(String destinationType) {
		this.destinationType = destinationType;
	}
	@JsonProperty("sourceNumber")
	public String getSourceNumber() {
		return sourceNumber;
	}
	@JsonProperty("sourceNumber")
	public void setSourceNumber(String sourceNumber) {
		this.sourceNumber = sourceNumber;
	}
	@JsonProperty("sourceCountry")
	public String getSourceCountry() {
		return sourceCountry;
	}
	@JsonProperty("sourceCountry")
	public void setSourceCountry(String sourceCountry) {
		this.sourceCountry = sourceCountry;
	}
	@JsonProperty("sourceType")
	public String getSourceType() {
		return sourceType;
	}
	@JsonProperty("sourceType")
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	@JsonProperty("asnId")
	public String getAsnId() {
		return asnId;
	}
	@JsonProperty("asnId")
	public void setAsnId(String asnId) {
		this.asnId = asnId;
	}
	@JsonProperty("asnDate")
	public String getAsnDate() {
		return asnDate;
	}
	@JsonProperty("asnDate")
	public void setAsnDate(String asnDate) {
		this.asnDate = asnDate;
	}
	@JsonProperty("carrierId")
	public String getCarrierId() {
		return carrierId;
	}
	@JsonProperty("carrierId")
	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}
	@JsonProperty("shipperName")
	public String getShipperName() {
		return shipperName;
	}
	@JsonProperty("shipperName")
	public void setShipperName(String shipperName) {
		this.shipperName = shipperName;
	}
	@JsonProperty("shipDate")
	public String getShipDate() {
		return shipDate;
	}
	@JsonProperty("shipDate")
	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}
	@JsonProperty("loadNumber")
	public String getLoadNumber() {
		return loadNumber;
	}
	@JsonProperty("loadNumber")
	public void setLoadNumber(String loadNumber) {
		this.loadNumber = loadNumber;
	}
	@JsonProperty("trailerSealNumber")
	public String getTrailerSealNumber() {
		return trailerSealNumber;
	}
	@JsonProperty("trailerSealNumber")
	public void setTrailerSealNumber(String trailerSealNumber) {
		this.trailerSealNumber = trailerSealNumber;
	}
	@JsonProperty("billOfLadingNumber")
	public String getBillOfLadingNumber() {
		return billOfLadingNumber;
	}
	@JsonProperty("billOfLadingNumber")
	public void setBillOfLadingNumber(String billOfLadingNumber) {
		this.billOfLadingNumber = billOfLadingNumber;
	}
	@JsonProperty("trailerNumber")
	public String getTrailerNumber() {
		return trailerNumber;
	}
	@JsonProperty("trailerNumber")
	public void setTrailerNumber(String trailerNumber) {
		this.trailerNumber = trailerNumber;
	}
	@JsonProperty("packs")
	public List<ASNPackDetails> getPacks() {
		return packs;
	}
	@JsonProperty("packs")
	public void setPacks(List<ASNPackDetails> packs) {
		this.packs = packs;
	}
}
