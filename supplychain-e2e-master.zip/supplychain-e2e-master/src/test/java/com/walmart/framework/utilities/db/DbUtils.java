package com.walmart.framework.utilities.db;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.config.ENVIRONMENT;
import com.walmart.framework.utilities.jms.DC_TYPE;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class DbUtils {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    DataSource mccDataSource;

    @Autowired
    DataSource rdcDataSource;
    
    @Autowired
    DataSource idmAtlasDataSource;
    
    @Autowired
    DataSource dpbAPDataSource;

    @Autowired
    DataSource dpbFESDataSource;

    @Autowired
    DataSource receivingAtlasDataSource;

    @Autowired
    DataSource smartSlottingDataSource;

    @Autowired
    DataSource rdsDataSource;
    
    @Autowired
    DataSource wmsDataSource;

    @Autowired
    DataSource opAtlasDataSource;
    @Autowired
    DataSource otAtlasDataSource;
    @Autowired
    DataSource oaAtlasDataSource;
    @Autowired
    DataSource omAtlasDataSource;
    
    @Autowired
    DataSource shoreWitronDataSource;

    @Autowired
    DataSource plannerAtlasDataSource;
    
    @Autowired
    DataSource fmAtlasDataSource;
    
    @Autowired
    DataSource ofAtlasDataSource;
    
    @Autowired
    DataSource dcfinDataSource;
    
    @Autowired
    DataSource dcfinTransportDataSource;
    
    @Autowired
    DataSource loadingAtlasDataSource;
    
    @Autowired
    DataSource inventoryWitronDataSource;
    
    Logger logger = LogManager.getLogger(this.getClass());
    @Deprecated
    public List<Map<String, Object>> selectFrom(String query, Object... objectArgs) {
        return jdbcTemplate.queryForList(query, objectArgs);
    }

    public List<Map<String, Object>> selectFrom(DC_TYPE dcType, String query, Object... objectArgs) {
        configureJdbcTemplate(jdbcTemplate, dcType);
        return jdbcTemplate.queryForList(query, objectArgs);
    }
    
    public List<Map<String, Object>> selectFrom(PRODUCT_NAME productName, String query, Object... objectArgs ) {
    		logger.info("Select Query:{}",query);
    		if(objectArgs!=null) {
    			logger.info("DB Query Arguments:{}",Arrays.toString(objectArgs));
    		}
        configureJdbcTemplateAtlas(jdbcTemplate, productName);
        return jdbcTemplate.queryForList(query, objectArgs);
    }
    
    public List<Map<String, Object>> selectFrom(PRODUCT_NAME productName, String query) {
		logger.info("Select Query:{}",query);
    configureJdbcTemplateAtlas(jdbcTemplate, productName);
    return jdbcTemplate.queryForList(query);
}

    private JdbcTemplate configureJdbcTemplateAtlas(JdbcTemplate jdbcTemplate, PRODUCT_NAME productName) {


          	if (productName.toString().equals(PRODUCT_NAME.IDM.toString())){
          		 jdbcTemplate.setDataSource(idmAtlasDataSource);
          	}else if (productName==PRODUCT_NAME.RECEIVING){
         		 jdbcTemplate.setDataSource(receivingAtlasDataSource);
         	}else if (productName==PRODUCT_NAME.SMARTSLOTTING){
                jdbcTemplate.setDataSource(smartSlottingDataSource);
            }else if (productName==PRODUCT_NAME.OP){
         		 jdbcTemplate.setDataSource(opAtlasDataSource);
          	}else if (productName==PRODUCT_NAME.OT){
        		 jdbcTemplate.setDataSource(otAtlasDataSource);
         	}else if (productName==PRODUCT_NAME.OA){
        		 jdbcTemplate.setDataSource(oaAtlasDataSource);
          	}else if (productName==PRODUCT_NAME.OM){
        		 jdbcTemplate.setDataSource(omAtlasDataSource);
          	}else if (productName==PRODUCT_NAME.OF){
        		 jdbcTemplate.setDataSource(ofAtlasDataSource);
          	}else if (productName==PRODUCT_NAME.PLANNER){
          		if(Config.ENV==ENVIRONMENT.PROD) {
          			jdbcTemplate.setDataSource(plannerAtlasDataSource);
          		}else {
          			jdbcTemplate.setDataSource(ofAtlasDataSource);
          		}
         	}else if (productName==PRODUCT_NAME.FM){
         		if(Config.ENV==ENVIRONMENT.PROD) {
         			jdbcTemplate.setDataSource(fmAtlasDataSource);
         		}else {
         			jdbcTemplate.setDataSource(ofAtlasDataSource);
         		}
         	}
          	else if (productName==PRODUCT_NAME.LOADING){
       		 jdbcTemplate.setDataSource(loadingAtlasDataSource);
         	}
          	else if (productName==PRODUCT_NAME.DCFIN){
          		 jdbcTemplate.setDataSource(dcfinDataSource);
            	}
          	else if (productName==PRODUCT_NAME.INV){
			jdbcTemplate.setDataSource(inventoryWitronDataSource);
           	}
          	else if (productName==PRODUCT_NAME.SHORE){
        		 jdbcTemplate.setDataSource(shoreWitronDataSource);
          	}
          	else if (productName==PRODUCT_NAME.DCFINTRANS){
       		 jdbcTemplate.setDataSource(dcfinTransportDataSource);
         	}
        	else if (productName==PRODUCT_NAME.RDS){
          		 jdbcTemplate.setDataSource(rdsDataSource);
            	}
        	else if (productName==PRODUCT_NAME.WMS){
        		 jdbcTemplate.setDataSource(wmsDataSource);
          	} else if (productName == PRODUCT_NAME.FES) {
                jdbcTemplate.setDataSource(dpbFESDataSource);
            } else if (productName == PRODUCT_NAME.AP) {
                jdbcTemplate.setDataSource(dpbAPDataSource);
            }

         return jdbcTemplate;
    	
		
	}

	@Deprecated
    public List<Map<String, Object>> selectFrom(String query) {
        return jdbcTemplate.queryForList(query);
    }


    public List<Map<String, Object>> selectFrom(DC_TYPE dcType,  String query) {
        configureJdbcTemplate(jdbcTemplate, dcType);
        return jdbcTemplate.queryForList(query);
    }

    @Deprecated
    public int insertInto(String query, Object... objectArgs) {
        return jdbcTemplate.update(query, objectArgs);
    }

    public int insertInto(DC_TYPE dcType, String query, Object... objectArgs) {
        configureJdbcTemplate(jdbcTemplate, dcType);
        return jdbcTemplate.update(query, objectArgs);
    }

    @Deprecated
    public int deleteFrom(String query, Object... objectArgs) {
        return jdbcTemplate.update(query, objectArgs);
    }

    public int deleteFrom(DC_TYPE dcType, String query, Object... objectArgs) {
        configureJdbcTemplate(jdbcTemplate, dcType);
        return jdbcTemplate.update(query, objectArgs);
    }
    
    public int deleteFrom(PRODUCT_NAME productName, String query, Object... objectArgs ) {
        configureJdbcTemplateAtlas(jdbcTemplate, productName);
        return jdbcTemplate.update(query, objectArgs);
    }

    public int insertInto(PRODUCT_NAME productName, String query) {
        configureJdbcTemplateAtlas(jdbcTemplate, productName);
        return jdbcTemplate.update(query);
    }

    public int UpdateFrom(PRODUCT_NAME productName, String query, Object... objectArgs ) {
        configureJdbcTemplateAtlas(jdbcTemplate, productName);
        return jdbcTemplate.update(query, objectArgs);
    }

    private JdbcTemplate configureJdbcTemplate(JdbcTemplate jdbcTemplate, DC_TYPE dct) {

        if (dct == DC_TYPE.MCC || dct == DC_TYPE.ACC || dct == DC_TYPE.BAJA) {
            jdbcTemplate.setDataSource(mccDataSource);
        } else if (dct==DC_TYPE.MCC_RDC || dct==DC_TYPE.ATLAS_RDC || dct==DC_TYPE.ACC_RDC || dct==DC_TYPE.RDC) {
            jdbcTemplate.setDataSource(rdcDataSource);
        }
        else if(dct == DC_TYPE.ATLAS){
        	
        	 jdbcTemplate.setDataSource(idmAtlasDataSource);
        } 

        else if (dct == DC_TYPE.PHARMACY || dct == DC_TYPE.RDC) {
        	jdbcTemplate.setDataSource(rdsDataSource);
        }
        return jdbcTemplate;
    }

    public String transformIntoSpringQuery(String query, int arrLength) {

        String[] split = query.split("\\(");

        if (arrLength == 1)
            return split[0] + "(?" + split[1];
        else {
            for (int i = 0; i < arrLength - 1; i++) {
                if (i == 0)
                    split[0] += "(";
                split[0] += "?,";
            }

            System.out.println(split[0] + "?" + split[1]);
            return split[0] + "?" + split[1];
        }

    }
    
    public int updateFrom(DC_TYPE dcType, String query, Object... objectArgs) {
        configureJdbcTemplate(jdbcTemplate, dcType);
        return jdbcTemplate.update(query, objectArgs);
    }
}
