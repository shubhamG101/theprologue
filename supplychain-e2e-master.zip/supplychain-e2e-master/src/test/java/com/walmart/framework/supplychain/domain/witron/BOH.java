package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "groupByAttr", "groupByAttrOrderBy","itemList","poTypeList","baseDivisionCode","financialReportingGroup","inventoryStatus","bohQtyUom" })
public class BOH {
	@JsonProperty("groupByAttr")
	private String groupByAttr;
	@JsonProperty("groupByAttrOrderBy")
	private String groupByAttrOrderBy;
	@JsonProperty("itemList")
	private List<String> itemList;
	@JsonProperty("poTypeList")
	private List<String> poTypeList;
	@JsonProperty("baseDivisionCode")
	private String baseDivisionCode;
	@JsonProperty("financialReportingGroup")
	private String financialReportingGroup;
	@JsonProperty("inventoryStatus")
	private String inventoryStatus;
	@JsonProperty("bohQtyUom")
	private String bohQtyUom;
	public String getGroupByAttr() {
		return groupByAttr;
	}
	public void setGroupByAttr(String groupByAttr) {
		this.groupByAttr = groupByAttr;
	}
	public String getGroupByAttrOrderBy() {
		return groupByAttrOrderBy;
	}
	public void setGroupByAttrOrderBy(String groupByAttrOrderBy) {
		this.groupByAttrOrderBy = groupByAttrOrderBy;
	}
	public List<String> getItemList() {
		return itemList;
	}
	public void setItemList(List<String> itemList) {
		this.itemList = itemList;
	}
	public List<String> getPoTypeList() {
		return poTypeList;
	}
	public void setPoTypeList(List<String> poTypeList) {
		this.poTypeList = poTypeList;
	}
	public String getBaseDivisionCode() {
		return baseDivisionCode;
	}
	public void setBaseDivisionCode(String baseDivisionCode) {
		this.baseDivisionCode = baseDivisionCode;
	}
	public String getFinancialReportingGroup() {
		return financialReportingGroup;
	}
	public void setFinancialReportingGroup(String financialReportingGroup) {
		this.financialReportingGroup = financialReportingGroup;
	}
	public String getInventoryStatus() {
		return inventoryStatus;
	}
	public void setInventoryStatus(String inventoryStatus) {
		this.inventoryStatus = inventoryStatus;
	}
	public String getBohQtyUom() {
		return bohQtyUom;
	}
	public void setBohQtyUom(String bohQtyUom) {
		this.bohQtyUom = bohQtyUom;
	}
}
