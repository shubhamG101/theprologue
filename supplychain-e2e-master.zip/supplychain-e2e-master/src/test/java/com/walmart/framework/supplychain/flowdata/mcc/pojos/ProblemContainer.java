package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "containerId",
    "containerQty",
    "problemSlot",
    "createTs"
})
public class ProblemContainer {
	
	@JsonProperty("containerId")
    private String containerId;
    
    @JsonProperty("containerQty")
    private int containerQty;
    
    @JsonProperty("problemSlot")
    private JSONObject problemSlot;
    
	@JsonProperty("createTs")
    private long createTs;

    @JsonProperty("containerId")
    public String getContainerId() {
		return containerId;
	}

    @JsonProperty("containerId")
	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

    @JsonProperty("containerQty")
	public int getContainerQty() {
		return containerQty;
	}

    @JsonProperty("containerQty")
	public void setContainerQty(int containerQty) {
		this.containerQty = containerQty;
	}
    
    @JsonProperty("problemSlot")
    public JSONObject getProblemSlot() {
		return problemSlot;
	}

    @JsonProperty("problemSlot")
	public void setProblemSlot(JSONObject problemSlot) {
		this.problemSlot = problemSlot;
	}

    @JsonProperty("createTs")
	public long getCreateTs() {
		return createTs;
	}

    @JsonProperty("createTs")
	public void setCreateTs(long createTs) {
		this.createTs = createTs;
	}

	
}