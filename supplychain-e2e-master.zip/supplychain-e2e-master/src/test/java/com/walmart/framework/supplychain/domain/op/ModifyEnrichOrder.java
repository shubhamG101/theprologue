package com.walmart.framework.supplychain.domain.op;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(

{
"enrichUpdateOrderWithSearchCriteria"
})




public class ModifyEnrichOrder {
	
	@JsonProperty("enrichUpdateOrderWithSearchCriteria")
	 private EnrichUpdateOrderWithSearchCriteria enrichUpdateOrderWithSearchCriteria;
	 
	public EnrichUpdateOrderWithSearchCriteria getenrichUpdateOrderWithSearchCriteria() {
			return enrichUpdateOrderWithSearchCriteria;
		}

	public void setenrichUpdateOrderWithSearchCriteria(EnrichUpdateOrderWithSearchCriteria enrichUpdateOrderWithSearchCriteria) {
			this.enrichUpdateOrderWithSearchCriteria = enrichUpdateOrderWithSearchCriteria;
		}

}
