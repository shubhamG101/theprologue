package com.walmart.framework.supplychain.domain.op;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.RDCDeliveryDetail;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonPropertyOrder({
	"orgUnitIds",
	"destNbrs",
	"effectiveRelDate",
	"orderDownloadDate",
	"cycleWave",
	"releaseNbrs",
	"itemNbrs"
	})
	
	
	public class EnrichOrderSearchCriteria {
		
		
		@JsonProperty("orgUnitIds")
		private List<Integer> orgUnitIds = null;


		@JsonProperty("orgUnitIds")
		public List<Integer>  getOrgUnitIds() {
		return this.orgUnitIds;
		}

		@JsonProperty("orgUnitIds")
		public void setOrgUnitIds(List<Integer>  orgUnitIds) {
		this.orgUnitIds=orgUnitIds;
		}

		
		
		@JsonProperty("destNbrs")
		private Set<String> destNbrs = null;


		@JsonProperty("destNbrs")
		public Set<String> getdestNbrs() {
		return this.destNbrs;
		}

		@JsonProperty("destNbrs")
		public void setdestNbrs(Set<String> destNbrs) {
		this.destNbrs = destNbrs;
		}

		
		
		@JsonProperty("effectiveRelDate")
		private Object effectiveRelDate=null ;


		@JsonProperty("effectiveRelDate")
		public Object geteffectiveRelDate() {
		return this.effectiveRelDate;
		}

		@JsonProperty("effectiveRelDate")
		public void seteffectiveRelDate(Object effectiveRelDate) {
		this.effectiveRelDate = effectiveRelDate;
		}
		
		

		@JsonProperty("orderDownloadDate")
		private Object orderDownloadDate = null;

		@JsonProperty("orderDownloadDate")
		public Object getorderDownloadDate() {
		return this.orderDownloadDate;
		}

		@JsonProperty("orderDownloadDate")
		public void setorderDownloadDate(Object orderDownloadDate) {
		this.orderDownloadDate = orderDownloadDate;
		}

		
		@JsonProperty("cycleWave")
		private Integer cycleWave = null;
		
		@JsonProperty("cycleWave")
		public Integer getcycleWave() {
		return this.cycleWave;
		}

		@JsonProperty("cycleWave")
		public void setcycleWave(Integer cycleWave) {
		this.cycleWave = cycleWave;
		}
		
		
		
		
		@JsonProperty("releaseNbrs")
		private List<Integer>  releaseNbrs = null;
		
		@JsonProperty("releaseNbrs")
		public List<Integer>  getreleaseNbrs() {
		return this.releaseNbrs;
		}

		@JsonProperty("releaseNbrs")
		public void setreleaseNbrs(List<Integer>  releaseNbrs) {
		this.releaseNbrs = releaseNbrs;
		}
		
		
		
		@JsonProperty("itemNbrs")
		private Set<String> itemNbrs = null;


		@JsonProperty("itemNbrs")
		public Set<String> getitemNbrs() {
		return this.itemNbrs;
		}

		@JsonProperty("itemNbrs")
		public void setitemNbrs(Set<String> itemNbrs) {
		this.itemNbrs = itemNbrs;
		}

		
		@Override
	    public String toString() {
	        return new ToStringBuilder(this).append("orgUnitIds", orgUnitIds).append("destNbrs", destNbrs).append("effectiveRelDate", effectiveRelDate).append("orderDownloadDate",orderDownloadDate).append("cycleWave",cycleWave).append("releaseNbrs",releaseNbrs).append("itemNbrs",itemNbrs)
	        		.toString();
	    }

	    

	    @Override
	    public boolean equals(Object other) {
	        if (other == this) {
	            return true;
	        }
	        if ((other instanceof EnrichOrderSearchCriteria) == false) {
	            return false;
	        }
	        EnrichOrderSearchCriteria rhs = ((EnrichOrderSearchCriteria) other);
	        return new EqualsBuilder().append(orgUnitIds, rhs.orgUnitIds).append(destNbrs, rhs.destNbrs).append(effectiveRelDate, rhs.effectiveRelDate).append(orderDownloadDate, rhs.orderDownloadDate).append(cycleWave, rhs.cycleWave).append(releaseNbrs, rhs.releaseNbrs).append(itemNbrs, rhs.itemNbrs).
	        		isEquals();
	    }

		
		
		
		

	

	}
