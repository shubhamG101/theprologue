package com.walmart.framework.supplychain.domain.acc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "scannedLabel",
    "validateInventory",
    "masterLabel",
    "childLabel",
    "storeGroupName",
    "storeGroupId",
    "scannedInput",
    "storeNumber",
    "generateMasterLabel"
})
public class CreateMCBPallet {
	
	@JsonProperty("scannedLabel")
    private String scannedLabel;
    @JsonProperty("validateInventory")
    private String validateInventory;
    @JsonProperty("masterLabel")
    private String masterLabel;
    @JsonProperty("childLabel")
    private String childLabel;
    @JsonProperty("storeGroupName")
    private String storeGroupName;
    @JsonProperty("storeGroupId")
    private int storeGroupId;
    public String getScannedLabel() {
		return scannedLabel;
	}
	public void setScannedLabel(String scannedLabel) {
		this.scannedLabel = scannedLabel;
	}
	public String getValidateInventory() {
		return validateInventory;
	}
	public void setValidateInventory(String validateInventory) {
		this.validateInventory = validateInventory;
	}
	public String getMasterLabel() {
		return masterLabel;
	}
	public void setMasterLabel(String masterLabel) {
		this.masterLabel = masterLabel;
	}
	public String getChildLabel() {
		return childLabel;
	}
	public void setChildLabel(String childLabel) {
		this.childLabel = childLabel;
	}
	public String getStoreGroupName() {
		return storeGroupName;
	}
	public void setStoreGroupName(String storeGroupName) {
		this.storeGroupName = storeGroupName;
	}
	public int getStoreGroupId() {
		return storeGroupId;
	}
	public void setStoreGroupId(int storeGroupId) {
		this.storeGroupId = storeGroupId;
	}
	public String getScannedInput() {
		return scannedInput;
	}
	public void setScannedInput(String scannedInput) {
		this.scannedInput = scannedInput;
	}
	public String getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}
	public boolean isGenerateMasterLabel() {
		return generateMasterLabel;
	}
	public void setGenerateMasterLabel(boolean generateMasterLabel) {
		this.generateMasterLabel = generateMasterLabel;
	}
	@JsonProperty("scannedInput")
    private String scannedInput;
    @JsonProperty("storeNumber")
    private String storeNumber;
    @JsonProperty("generateMasterLabel")
    private boolean generateMasterLabel;
    
    
	
    
}