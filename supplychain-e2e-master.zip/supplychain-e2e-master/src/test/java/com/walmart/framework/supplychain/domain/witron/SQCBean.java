package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "SQC" })
public class SQCBean {
	@JsonProperty("SQC")
	private SQC SQC;

	@JsonProperty("SQC")
	public SQC getSQC() {
		return SQC;
	}
	@JsonProperty("SQC")
	public void setSQC(SQC sQC) {
		SQC = sQC;
	}
	
	


}
