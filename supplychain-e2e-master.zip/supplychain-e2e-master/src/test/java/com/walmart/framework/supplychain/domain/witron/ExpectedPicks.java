package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "fulfilledItemNbr", "fulfilledQty", "rotateDate", "pickId", "pickOrderType", "expectedVnpk" })
public class ExpectedPicks implements Comparable<ExpectedPicks> {
	@JsonProperty("fulfilledItemNbr")
	private String fulfilledItemNbr;
	@JsonProperty("fulfilledQty")
	private String fulfilledQty;
	@JsonProperty("rotateDate")
	private String rotateDate;
	@JsonProperty("pickId")
	private String pickId;
	@JsonProperty("pickOrderType")
	private String pickOrderType;
	@JsonProperty("expectedVnpk")
	private String expectedVnpk;
	
	public String getFulfilledItemNbr() {
		return fulfilledItemNbr;
	}
	public void setFulfilledItemNbr(String fulfilledItemNbr) {
		this.fulfilledItemNbr = fulfilledItemNbr;
	}
	public String getFulfilledQty() {
		return fulfilledQty;
	}
	public void setFulfilledQty(String fulfilledQty) {
		this.fulfilledQty = fulfilledQty;
	}
	public String getRotateDate() {
		return rotateDate;
	}
	public void setRotateDate(String rotateDate) {
		this.rotateDate = rotateDate;
	}
	public String getPickId() {
		return pickId;
	}
	public void setPickId(String pickId) {
		this.pickId = pickId;
	}
	public String getPickOrderType() {
		return pickOrderType;
	}
	public void setPickOrderType(String pickOrderType) {
		this.pickOrderType = pickOrderType;
	}
	public String getExpectedVnpk() {
		return expectedVnpk;
	}
	public void setExpectedVnpk(String expectedVnpk) {
		this.expectedVnpk = expectedVnpk;
	}
	@Override
	public int compareTo(ExpectedPicks pick) {
		return getRotateDate().compareTo(pick.getRotateDate());
	}
}
