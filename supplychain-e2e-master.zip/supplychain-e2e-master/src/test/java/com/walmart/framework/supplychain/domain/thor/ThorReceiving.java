package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "purchaseOrderId", "receivingStationId", "receivingIntoLocationId", "thorSku", "totalUnitCount", "placedDate", "expirationDate", "lpnId"})
public class ThorReceiving {
	
	@JsonProperty("purchaseOrderId")
	private int purchaseOrderId;
	@JsonProperty("receivingStationId")
	private String receivingStationId;
	@JsonProperty("receivingIntoLocationId")
	private String receivingIntoLocationId;
	@JsonProperty("thorSku")
	private String thorSku;
	@JsonProperty("totalUnitCount")
	private int totalUnitCount;
	@JsonProperty("placedDate")
	private String placedDate;
	@JsonProperty("expirationDate")
	private String expirationDate;
	@JsonProperty("lpnId")
	private String lpnId;
	
	@JsonProperty("purchaseOrderId")
	public int getPurchaseOrderId() {
		return purchaseOrderId;
	}
	@JsonProperty("purchaseOrderId")
	public void setPurchaseOrderId(int purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}
	@JsonProperty("receivingStationId")
	public String getReceivingStationId() {
		return receivingStationId;
	}
	@JsonProperty("receivingStationId")
	public void setReceivingStationId(String receivingStationId) {
		this.receivingStationId = receivingStationId;
	}
	@JsonProperty("receivingIntoLocationId")
	public String getReceivingIntoLocationId() {
		return receivingIntoLocationId;
	}
	@JsonProperty("receivingIntoLocationId")
	public void setReceivingIntoLocationId(String receivingIntoLocationId) {
		this.receivingIntoLocationId = receivingIntoLocationId;
	}
	@JsonProperty("thorSku")
	public String getThorSku() {
		return thorSku;
	}
	@JsonProperty("thorSku")
	public void setThorSku(String thorSku) {
		this.thorSku = thorSku;
	}
	@JsonProperty("totalUnitCount")
	public int getTotalUnitCount() {
		return totalUnitCount;
	}
	@JsonProperty("totalUnitCount")
	public void setTotalUnitCount(int totalUnitCount) {
		this.totalUnitCount = totalUnitCount;
	}
	@JsonProperty("placedDate")
	public String getPlacedDate() {
		return placedDate;
	}
	@JsonProperty("placedDate")
	public void setPlacedDate(String placedDate) {
		this.placedDate = placedDate;
	}
	@JsonProperty("expirationDate")
	public String getExpirationDate() {
		return expirationDate;
	}
	@JsonProperty("expirationDate")
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	@JsonProperty("lpnId")
	public String getLpnId() {
		return lpnId;
	}
	@JsonProperty("lpnId")
	public void setLpnId(String lpnId) {
		this.lpnId = lpnId;
	}
	

}
