
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "deliveryNumber",
    "inboundDoorNumber",
    "inboundTrailerNumber",
})
public class RDCDeliveryDetail {

    @JsonProperty("deliveryNumber")
    private String deliveryNumber;
    @JsonProperty("inboundDoorNumber")
    private String inboundDoorNumber;
    @JsonProperty("inboundTrailerNumber")
    private String inboundTrailerNumber;
   

    @JsonProperty("deliveryNumber")
    public String getDeliveryNumber() {
        return deliveryNumber;
    }

    @JsonProperty("deliveryNumber")
    public void setDeliveryNumber(String deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
    }

    public RDCDeliveryDetail withDeliveryNumber(String deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
        return this;
    }

    @JsonProperty("inboundDoorNumber")
    public String getInboundDoorNumber() {
        return inboundDoorNumber;
    }

    @JsonProperty("inboundDoorNumber")
    public void setInboundDoorNumber(String inboundDoorNumber) {
        this.inboundDoorNumber = inboundDoorNumber;
    }

    public RDCDeliveryDetail withInboundDoorNumber(String inboundDoorNumber) {
        this.inboundDoorNumber = inboundDoorNumber;
        return this;
    }

    @JsonProperty("inboundTrailerNumber")
    public String getInboundTrailerNumber() {
        return inboundTrailerNumber;
    }

    @JsonProperty("inboundTrailerNumber")
    public void setInboundTrailerNumber(String inboundTrailerNumber) {
        this.inboundTrailerNumber = inboundTrailerNumber;
    }

    public RDCDeliveryDetail withInboundTrailerNumber(String inboundTrailerNumber) {
        this.inboundTrailerNumber = inboundTrailerNumber;
        return this;
    }

   

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("deliveryNumber", deliveryNumber).append("inboundDoorNumber", inboundDoorNumber).append("inboundTrailerNumber", inboundTrailerNumber).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(inboundDoorNumber).append(inboundTrailerNumber).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RDCDeliveryDetail) == false) {
            return false;
        }
        RDCDeliveryDetail rhs = ((RDCDeliveryDetail) other);
        return new EqualsBuilder().append(inboundDoorNumber, rhs.inboundDoorNumber).append(inboundTrailerNumber, rhs.inboundTrailerNumber).append(deliveryNumber, rhs.deliveryNumber).isEquals();
    }

}
