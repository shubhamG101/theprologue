package com.walmart.framework.utilities.parsing;

import com.walmart.framework.supplychain.constants.FileNames;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Properties;

public class PropertyResolver {
	
	Properties prop;
	Logger logger = LogManager.getLogger(this.getClass());
	
	public void initializeProperties(String fileName){
		File file=null;
		try {
			prop = new Properties();
			if(fileName.contains("/")) {
			logger.info("file "+getClass().getResource(fileName).getFile());
			 file = new File(getClass().getResource(fileName).getFile());
			
			} else {
				try {
					file = new File(getClass().getClassLoader().getResource(fileName).toURI());
					
				} catch (URISyntaxException e) {
					e.printStackTrace();
				}
			}
			FileInputStream inputStream = new FileInputStream(file);
			prop.load(inputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String getPropertyValue(String propertyName) {
		if(prop==null) {
			initializeProperties(FileNames.ENVIRONMENT_FILE);
		}
		return prop.getProperty(propertyName);
	}
	
	public String getPropertyValue(String fileName,String propertyName) {
		if(prop==null) {
			initializeProperties(fileName);
		}
		return prop.getProperty(propertyName);
	}
	public String getPropertyValue(String fileName,String propertyName,boolean isPropertyFileChanged) {
		if(isPropertyFileChanged||prop==null) {
			initializeProperties(fileName);
		}
		return prop.getProperty(propertyName);
	}
}
