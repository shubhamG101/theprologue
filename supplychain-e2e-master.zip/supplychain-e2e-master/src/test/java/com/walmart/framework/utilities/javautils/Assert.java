package com.walmart.framework.utilities.javautils;

import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.framework.utilities.reporting.TestCaseFailure;

public class Assert {
	private static final Logger LOGGER = LoggerFactory.getLogger(Assert.class);
	private static final double DELTA = 0.001;
	public static  void updateDescription(ErrorCodes errorCode,String... jiraExtraInformation) {
		try {
			if(jiraExtraInformation!=null&&jiraExtraInformation.length>0) {
				String jiraDesc=(String)jiraExtraInformation[0];
				synchronized (Assert.class) {
					ErrorCodes.addDescription(errorCode, Thread.currentThread().getName(),jiraDesc);
					LOGGER.info(jiraDesc);
				}
			}
		}catch(Exception e) {
			LOGGER.error("updateDescriptionFailure:"+e.getMessage());//No need to fail due this method failure
		}
	}
	/**
	 * @param errorCode
	 * @param condition
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertTrue(ErrorCodes errorCode, boolean condition,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
	        org.junit.Assert.assertTrue(errorCode.getErrorMessage(),condition);
			}catch(AssertionError e) {
				if(isFailSafeCall(e,errorCode)) throw e;
				else throw new TestCaseFailure(errorCode, e);
			}
    }
	/**
	 * @param errorCode
	 * @param condition
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertFalse(ErrorCodes errorCode, boolean condition,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
	        org.junit.Assert.assertFalse(errorCode.getErrorMessage(),condition);
			}catch(AssertionError e) {
				if(isFailSafeCall(e,errorCode)) throw e;
				else throw new TestCaseFailure(errorCode, e);
			}
    }
	/**
	 * @param errorCode
	 * @param obj1
	 * @param obj2
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertEquals(ErrorCodes errorCode, Object obj1,Object obj2,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
        org.junit.Assert.assertEquals(errorCode.getErrorMessage(),obj1, obj2);
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	/**
	 * @param errorCode
	 * @param obj1
	 * @param obj2
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertArrayEquals(ErrorCodes errorCode, Object[] obj1,Object[] obj2,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
        org.junit.Assert.assertArrayEquals(errorCode.getErrorMessage(),obj1, obj2);
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	/**
	 * @param errorCode
	 * @param obj1
	 * @param obj2
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertNotEquals(ErrorCodes errorCode, Object obj1,Object obj2,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
        org.junit.Assert.assertNotEquals(errorCode.getErrorMessage()+ ". Expected != "+obj1,obj1, obj2);
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	
	/**
	 * @param errorCode
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void fail(ErrorCodes errorCode,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
        org.junit.Assert.fail(errorCode.getErrorMessage());
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	/**
	 * @param errorCode
	 * @param val1
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertNotNull(ErrorCodes errorCode, Object val1,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
        org.junit.Assert.assertNotNull(errorCode.getErrorMessage(),val1);
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	
	
	/**
	 * @param errorCode
	 * @param val1
	 * @param val2
	 * @param delta
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	static public void assertEquals(ErrorCodes errorCode, double val1,double val2,double delta,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
        org.junit.Assert.assertEquals(errorCode.getErrorMessage(),val1, val2,delta);
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	/**
	 * @param errorCode
	 * @param expected
	 * @param actual
	 * @param jiraExtraInformation 1st argument jira description 2nd argument for isScreenshotRequired boolean flag
	 */
	public static <K,V>  void assertMaps(ErrorCodes errorCode, Map<K, V> expected,Map<K, V> actual,String... jiraExtraInformation) {
		try {
			updateDescription(errorCode, jiraExtraInformation);
			if(expected==null||expected.isEmpty()) {
				throw new AutomationFailure(errorCode.getErrorMessage()+" -Expected data can not be empty");
			}
			org.junit.Assert.assertNotNull(errorCode.getErrorMessage(), actual);
			org.junit.Assert.assertNotEquals(errorCode.getErrorMessage(), 0,actual.size());
			for(Entry<K, V> key:expected.entrySet()) {
				if(key.getValue() instanceof Double) {
					org.junit.Assert.assertNotNull(errorCode.getErrorMessage()+" due to NULL value for "+key.getKey(), actual.get(key.getKey()));
					org.junit.Assert.assertEquals(errorCode.getErrorMessage()+" for "+key.getKey(),(Double)expected.get(key.getKey()), (Double)actual.get(key.getKey()),DELTA);
				}else {
					org.junit.Assert.assertEquals(errorCode.getErrorMessage()+" for "+key.getKey(),String.valueOf(expected.get(key.getKey())), String.valueOf(actual.get(key.getKey())));
				}
			}
		}catch(AssertionError e) {
			if(isFailSafeCall(e,errorCode)) throw e;
			else throw new TestCaseFailure(errorCode, e);
		}
    }
	
	static boolean isFailSafeCall(AssertionError e,ErrorCodes errorCode) {
		StackTraceElement[] stackTraceElementArray=e.getStackTrace();
		for(int level=0;level<stackTraceElementArray.length&&level<10;level++) {
			StackTraceElement stackTraceElement=stackTraceElementArray[level];
			if(stackTraceElement.getClassName().contains("failsafe")) {
				LOGGER.error("Failsafe:"+e.getMessage());
				return true;
			}
		}
		return false;
	}
	
}
