
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "deliveryNumber",
    "deliveryName",
    "inboundDoorNumber",
    "inboundTrailerNumber",
    "dcFinPurchaseValue",
    "poNumbers",
    "itemLabelId",
    "doorType",
    "mappedFloorLine",
    "dockTags",
    "inboundLoadNumber",
    "shipments"
})
public class DeliveryDetail {

    @JsonProperty("deliveryNumber")
    private String deliveryNumber;
    @JsonProperty("deliveryName")
    private String deliveryName;
    @JsonProperty("deliveryStatus")
    private String deliveryStatus;
    @JsonProperty("inboundDoorNumber")
    private String inboundDoorNumber;
    @JsonProperty("inboundTrailerNumber")
    private String inboundTrailerNumber;
    @JsonProperty("dcFinPurchaseValue")
    private String dcFinPurchaseValue;
    @JsonProperty("doorType")
    private String doorType;
    @JsonProperty("mappedFloorLine")
    private String mappedFloorLine;
	@JsonProperty("poNumbers")
    private List<String> poNumbers = new ArrayList<String>();
	@JsonProperty("dockTags")
    private List<String> dockTags = new ArrayList<String>();
	@JsonProperty("shipments")
    private List<String> shipments = new ArrayList<String>();
	@JsonProperty("inboundYardZone")
	private String inboundYardZone;
	
    public String getInboundYardZone() {
		return inboundYardZone;
	}
	public void setInboundYardZone(String inboundYardZone) {
		this.inboundYardZone = inboundYardZone;
	}
	public List<String> getshipments() {
		return shipments;
	}
	public void setshipments(List<String> shipments) {
		this.shipments = shipments;
	}
	public String getMappedFloorLine() {
		return mappedFloorLine;
	}
    public String getInboundLoadNumber() {
		return inboundLoadNumber;
	}

	public void setInboundLoadNumber(String inboundLoadNumber) {
		this.inboundLoadNumber = inboundLoadNumber;
	}
	@JsonProperty("inboundLoadNumber")
    private String inboundLoadNumber;

	public void setMappedFloorLine(String mappedFloorLine) {
		this.mappedFloorLine = mappedFloorLine;
	}

	public List<String> getDockTags() {
		return dockTags;
	}
	

	public void setDockTags(List<String> dockTags) {
		this.dockTags = dockTags;
	}
	
	public String getDeliveryName() {
		return deliveryName;
	}
	
	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}
	
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	@JsonProperty("itemLabelId")
    private List<String> itemLabelId = new ArrayList<String>();

	@JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("deliveryNumber")
    public String getDeliveryNumber() {
        return deliveryNumber;
    }

    @JsonProperty("deliveryNumber")
    public void setDeliveryNumber(String deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
    }

    public DeliveryDetail withDeliveryNumber(String deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
        return this;
    }

    @JsonProperty("inboundDoorNumber")
    public String getInboundDoorNumber() {
        return inboundDoorNumber;
    }

    @JsonProperty("inboundDoorNumber")
    public void setInboundDoorNumber(String inboundDoorNumber) {
        this.inboundDoorNumber = inboundDoorNumber;
    }

    public DeliveryDetail withInboundDoorNumber(String inboundDoorNumber) {
        this.inboundDoorNumber = inboundDoorNumber;
        return this;
    }

    @JsonProperty("inboundTrailerNumber")
    public String getInboundTrailerNumber() {
        return inboundTrailerNumber;
    }

    @JsonProperty("inboundTrailerNumber")
    public void setInboundTrailerNumber(String inboundTrailerNumber) {
        this.inboundTrailerNumber = inboundTrailerNumber;
    }
    
    @JsonProperty("doorType")
    public String getDoorType() {
		return doorType;
	}

    @JsonProperty("doorType")
	public void setDoorType(String doorType) {
		this.doorType = doorType;
	}

    public DeliveryDetail withInboundTrailerNumber(String inboundTrailerNumber) {
        this.inboundTrailerNumber = inboundTrailerNumber;
        return this;
    }

    @JsonProperty("dcFinPurchaseValue")
    public String getDcFinPurchaseValue() {
        return dcFinPurchaseValue;
    }

    @JsonProperty("dcFinPurchaseValue")
    public void setDcFinPurchaseValue(String dcFinPurchaseValue) {
        this.dcFinPurchaseValue = dcFinPurchaseValue;
    }

    public DeliveryDetail withDcFinPurchaseValue(String dcFinPurchaseValue) {
        this.dcFinPurchaseValue = dcFinPurchaseValue;
        return this;
    }

    @JsonProperty("poNumbers")
    public List<String> getPoNumbers() {
        return poNumbers;
    }

    @JsonProperty("poNumbers")
    public void setPoNumbers(List<String> poNumbers) {
        this.poNumbers = poNumbers;
    }
    
    @JsonProperty("itemLabelId")
    public List<String> getItemLabelId() {
		return itemLabelId;
	}

    @JsonProperty("itemLabelId")
	public void setItemLabelId(List<String> itemLabelId) {
		this.itemLabelId = itemLabelId;
	}

    public DeliveryDetail withPoNumbers(List<String> poNumbers) {
        this.poNumbers = poNumbers;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DeliveryDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("deliveryNumber", deliveryNumber).append("inboundDoorNumber", inboundDoorNumber).append("inboundTrailerNumber", inboundTrailerNumber).append("dcFinPurchaseValue", dcFinPurchaseValue).append("poNumbers", poNumbers).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(inboundDoorNumber).append(inboundTrailerNumber).append(poNumbers).append(additionalProperties).append(deliveryNumber).append(dcFinPurchaseValue).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DeliveryDetail) == false) {
            return false;
        }
        DeliveryDetail rhs = ((DeliveryDetail) other);
        return new EqualsBuilder().append(inboundDoorNumber, rhs.inboundDoorNumber).append(inboundTrailerNumber, rhs.inboundTrailerNumber).append(poNumbers, rhs.poNumbers).append(additionalProperties, rhs.additionalProperties).append(deliveryNumber, rhs.deliveryNumber).append(dcFinPurchaseValue, rhs.dcFinPurchaseValue).isEquals();
    }

}
