
package com.walmart.framework.supplychain.constants;

import com.walmart.framework.supplychain.config.Config;

public class FileNames {

	public static final String DELIVERY_MESSAGE_FILE = "/TestData/IDMDeliveryCreation.txt";
	public static final String GFCS_FILES = "src/test/resources/TestData/GFCS/";
	public static final String PO_MOCK_FILE = "/src/test/resources/TestData/mocks.json";
	public static final String TEAM_DETAILS_FILE = "/src/test/resources/team_details.json";

	public static final String ENVIRONMENT_FILE = "env.properties";
	public static final String YMS_PROPERTIES = "/TestData/YMS.properties";
	public static final String MESSAGE_PROPERTIES = "/properties/message.properties";
	public static final String DA_CON = "src/test/resources/Features/mcc/da_conveyable.feature";
	public static final String SSTK = "src/test/resources/Features/mcc/sstk.feature";
	public static final String DA_NON_CON = "src/test/resources/Features/mcc/da_non_conveyable.feature";
	public static final String DA_CON_PBYL = "src/test/resources/Features/mcc/pbyl.feature";
	public static final String DA_NON_CON_MANUAL = "src/test/resources/Features/mcc/da_non_conveyable_manual.feature";
	public static final String DA_CON_MANUAL = "src/test/resources/Features/mcc/da_conveyable_manual.feature";
	public static final String PROBLEM = "src/test/resources/Features/mcc/problem.feature";
	public static final String PO_LINE_ADD_UPDATE = "src/test/resources/Features/mcc/po_line_add_and_update.feature";
	public static final String RECEIVING_INSTRUCTION = "/TestData/ReceivingInstruction.txt";
	public static final String UPDATE_INSTRUCTION = "/TestData/UpdateInstruction.txt";
	public static final String CLOSE_LOAD = "/TestData/CloseLoad.txt";
	public static final String CREATE_LOAD = "/TestData/CreateLoad.txt";
	public static final String PRE_RECEIVING_DAMAGE = "/TestData/PreReceivingDamage.txt";
	public static final String LOADING_CNTR_CREATION_PAYLOAD = "/TestData/LoadingContainerCreationPayLoad.txt";
	public static final String RECEIVE_FULL = "src/test/resources/Features/mcc/receive_full.feature";
	public static final String RECEIVE_PARTIAL = "src/test/resources/Features/mcc/receive_partial.feature";
	public static final String DELIVERY_MESSAGE_FILE_ATLAS = "/TestData/IDMDeliveryCreationAtlas.txt";
	public static final String GFCS_MESSAGE_FILE_ATLAS = "/TestData/GFCS/GfcsContainerWithChild.txt";
	public static final String CREATE_ALLOCATION = "/TestData/CreateAllocation.txt";

	public static final String MOCK_OMS_PO_PAYLOAD_TEMPLATE_FILE_JSON = "/TestData/mockOMSPOPayloadJSON.txt";
	public static final String MOCK_OMS_PO_BODY_TEMPLATE_FILE_JSON = "/TestData/mockOMSPOBodyJSON.txt";
	public static final String MOCK_OMS_PO_LINE_TEMPLATE_FILE_JSON = "/TestData/mockOMSPOLineJSON.txt";

	public static final String MOCK_OMS_PO_PAYLOAD_TEMPLATE_FILE_XML = "/TestData/mockOMSPOPayloadXML.txt";
	public static final String MOCK_OMS_PO_BODY_TEMPLATE_FILE_XML = "/TestData/mockOMSPOBodyXML.txt";
	public static final String MOCK_OMS_PO_LINE_TEMPLATE_FILE_XML = "/TestData/mockOMSPOLineXML.txt";

	public static final String INVENTORY_CREATION_PAYLOAD = "/TestData/InventoryCreationPayLoad.txt";
	public static final String VTR = "src/test/resources/Features/mcc/vtr.feature";
	public static final String ACC_DAMAGE = "src/test/resources/Features/acc/damage.feature";
	public static final String ACC_MULTIPO = "src/test/resources/Features/acc/acc_multiPO.feature";
	public static final String ACC_CHANNEL_FLIP = "src/test/resources/Features/acc/acc_channel_Flip.feature";
	public static final String ACC_MANUALPO_BASE_FILE = "src/test/resources/Features/acc/acc_base_ManualPO.feature";
	public static final String ACC_MANUAL_RECEIVING = "src/test/resources/Features/acc/acc_manual_receiving.feature";
	public static final String ACC_DA_SSTK_FILE = "src/test/resources/Features/acc/acc_da_sstk.feature";
	public static final String ACC_NO_ALLOCATION_FILE = "src/test/resources/Features/acc/acc_noallocation.feature";
	public static final String ACC_PO_UPDATE_FILE = "src/test/resources/Features/acc/acc_po_update.feature";
	public static final String ACC_TWO_DELLIVERY_FILE = "src/test/resources/Features/acc/acc_twodelivery.feature";
	public static final String ACC_SSTK_OFFLINE_ONLINE_DOOR_FILE = "src/test/resources/Features/acc/sstk_online_door.feature";
	public static final String ACC_DELIVERY_FINALIZATION_FILE = "src/test/resources/Features/acc/acc_delivery_finalization.feature";
	public static final String ACC_DOCK_TAG = "src/test/resources/Features/acc/acc_dockTag_ReOpenDel.feature";
	public static final String ACC_PRERECEIVING_DAMAGE_LOADING = "src/test/resources/Features/acc/acc_preDamage_loading_overshoot.feature";
	public static final String ACC_PROBLEM_NA_APP = "src/test/resources/Features/acc/acc_problem_na.feature";
	public static final String ACC_PROBLEM_OV_APP = "src/test/resources/Features/acc/acc_problem_ov.feature";
	public static final String ACC_DA_NONCON_ONLINE = "src/test/resources/Features/acc/da_non_conveyable.feature";
	public static final String ACC_BUMER_EXCEPTION_LPN = "src/test/resources/Features/acc/acc_bumer_exception_message.feature";
	public static final String ACC_CLOSE_LOAD_WITHOUT_STOP_DIVERSION = "src/test/resources/Features/acc/aac_base_CloseLoad_without_Stop_diversion.feature";
	public static final String ACC_POUPDATE_DELETE_LOAD = "src/test/resources/Features/acc/acc_poUpdate_delete_load.feature";
	public static final String ACC_MCB_COMBINED_FLOW = "src/test/resources/Features/acc/acc_mcb_combinedflow.feature";
	public static final String ACC_MCB_REGULAR_FLOW = "src/test/resources/Features/acc/acc_mcb_regularflow.feature";
	public static final String ACC_BASE_POCON = "src/test/resources/Features/acc/acc_base_pocon.feature";
	public static final String TRANSPORTATION_MODE_JSON_FOR_LIMITED_ION = "/TestData/acc/limitedQtyTransportationModevalue.txt";
	public static final String TRANSPORTATION_MODE_JSON_FOR_LITHIUM_ION = "/TestData/acc/lithiumIonTransportationModevalue.txt";
	public static final String TRANSPORTATION_MODE_JSON_FOR_LITHIUM_AND_LIMITED_ION = "/TestData/acc/lithiumAndlimitedQtyTransportationModevalue.txt";

	public static final String S2S_RDC_OFFLINE_RECEIVE = "src/test/resources/Features/acc/rdc_s2s.feature";
	public static final String S2S_RDC_ECOM_FILE_SRC_BASE = "/TestData/US_7038_BASEAUTO065720.CUST";
	public static final String S2S_RDC_ECOM_FILE_SRC_UPDATED = "/src/test/resources/TestData/US_7038_11223344065720.CUST";
	public static final String S2S_RDC_ECOM_FILE_DEST = "/shared/u/data/global/asn/prod/failed/Sep18";

	
	public static final String JIRA_SCENARIO_TEST_ID_MAPPING_FILE = "/src/test/resources/TestData/"+Config.DC.getValue().toLowerCase()+"/jira/scenario_to_jira_id_mapping.json";

	public static final String ATLAS_MULTI_PO = "src/test/resources/Features/atlas/atlas_multi_po.feature";
	public static final String ATLAS_SSTK = "src/test/resources/Features/atlas/atlas_sstk.feature";
	public static final String ATLAS_CANCEL_DELIVERY = "src/test/resources/Features/atlas/atlas_cancel_delivery.feature";
	public static final String ATLAS_PO_LINE_ADD_UPDATE = "src/test/resources/Features/atlas/po_line_add_and_update.feature";
	public static final String ATLAS_PO_LINE_ADD_LOC = "src/test/resources/TestData/Atlas_POLineAdd/";
	public static final String ATLAS_PO_LINE_ADD_FILE = "/TestData/Atlas_POLineAdd/atlas_po_line_add.txt";
	public static final String ATLAS_PO_LINE_UPDATE = "/TestData/Atlas_POLineAdd/atlas_po_line_update.txt";
	public static final String ATLAS_POCON = "src/test/resources/Features/atlas/atlas_pocon.feature";
	public static final String ATLAS_DA_NON_CON_MANUAL = "src/test/resources/Features/atlas/atlas_da_non_conveyable_manual.feature";
	public static final String ATLAS_DA_NON_CON = "src/test/resources/Features/atlas/atlas_da_non_conveyable.feature";
	public static final String ATLAS_PBYL = "src/test/resources/Features/atlas/atlas_pbyl.feature";
	public static final String ATLAS_DA_CON_MANUAL = "src/test/resources/Features/atlas/atlas_da_conveyable_manual.feature";
	public static final String ATLAS_RECEIVE_FULL = "src/test/resources/Features/atlas/receive_full.feature";
	public static final String ATLAS_VTR_DA = "src/test/resources/Features/atlas/atlas_vtr_da.feature";
	public static final String ATLAS_VTR_SSTK = "src/test/resources/Features/atlas/atlas_vtr_sstk.feature";
	public static final String ATLAS_DAMAGE_DA = "src/test/resources/Features/atlas/atlas_damage_da.feature";
	public static final String ATLAS_DAMAGE_SSTK = "src/test/resources/Features/atlas/atlas_damage_sstk.feature";
	public static final String ATLAS_HAZMAT_ITEM = "src/test/resources/Features/atlas/atlas_hazmat_item.feature";
	public static final String ATLAS_MANUAL_PO_ORDER_REOPEN = "src/test/resources/Features/atlas/atlas_manualpo_reopen.feature";
	public static final String ATLAS_ORDER_RERESH = "src/test/resources/Features/atlas/atlas_order_refresh.feature";
	public static final String ATLAS_DSDC = "src/test/resources/Features/atlas/atlas_dsdc.feature";
	
	public static final String ATLAS_MULTIPLE_LINES = "src/test/resources/Features/atlas/multiple_lines.feature";
	public static final String ATLAS_RECEIVE_PARTIAL = "src/test/resources/Features/atlas/receive_partial.feature";
	public static final String ATLAS_PROBLEM = "src/test/resources/Features/atlas/problem.feature";
	public static final String OMS_PO = "/TestData/OMSPO.txt";
	public static final String OMS_PO_UPDATE = "/TestData/OMSPOUpdate.txt";
	public static final String PROBLEM_RESOLUTION = "/TestData/problemResolution.txt";
	public static final String PROBLEM_CREATION = "/TestData/problemCreation.txt";
	public static final String GFCS_DAMAGE_CREATION_TEMPLATE_FILE ="/TestData/Atlas/gfcs_damage_create.txt";


	public static final String THOR_BASE_FILE = "src/test/resources/Features/thor/thor_base.feature";
	public static final String THOR_PO_LINE_ADD = "src/test/resources/Features/thor/thor_po_line_add.feature";
	public static final String THOR_PO_LINE_ADD_DELIVERED = "src/test/resources/Features/thor/thor_po_line_add_delivered.feature";
	public static final String THOR_PO_QTY_UPDATE = "src/test/resources/Features/thor/thor_poqty_update.feature";
	public static final String THOR_PO_QTY_UPDATE_DELIVERED = "src/test/resources/Features/thor/thor_poqty_update_delivered.feature";
	public static final String THOR_PO_LINE_CANCEL_DELIVERED = "src/test/resources/Features/thor/thor_po_line_cancel_delivered.feature";
	public static final String THOR_PO_LINE_CANCEL = "src/test/resources/Features/thor/thor_po_line_cancel.feature";
	public static final String THOR_WAREHOUSE_DAMAGE = "src/test/resources/Features/thor/thor_warehouse_damage.feature";
	public static final String THOR_CYCLE_COUNT_DECREASE = "src/test/resources/Features/thor/thor_cyclecount_decrease.feature";
	public static final String THOR_CYCLE_COUNT_INCREASE = "src/test/resources/Features/thor/thor_cyclecount_increase.feature";
	public static final String THOR_WAC_NOCHANGE = "src/test/resources/Features/thor/thor_wac_nochange.feature";
	public static final String THOR_SALES = "src/test/resources/Features/thor/thor_sales.feature";
	public static final String THOR_WAC_INCREASE = "src/test/resources/Features/thor/thor_wac_increase.feature";
	public static final String THOR_WAC_DECREASE = "src/test/resources/Features/thor/thor_wac_decrease.feature";
	public static final String THOR_CREATE_MOCK_PO = "/TestData/thor/create_mock_po.txt";
	public static final String THOR_CREATE_MOCK_FOR_PO_LINE_ADD = "/TestData/thor/create_mock_po_for_po_line_add.txt";

	public static final String THOR_PO_CREATE_KAFKA_SINGLE_LINE = "/TestData/thor/po_create_kafka_singleline.txt";
	public static final String THOR_PO_CREATE_KAFKA_MULTI_LINE = "/TestData/thor/po_create_Kafka_multiline.txt";

	public static final String THOR_POLINE_UPDATE_KAFKA = "/TestData/thor/poline_update_kafka.txt";
	public static final String THOR_POLINE_CANCEL_KAFKA = "/TestData/thor/poline_cancel_kafka.txt";
	public static final String THOR_PO_UPDATE_KAFKA = "/TestData/thor/po_update_kafka.txt";
	public static final String THOR_POLINE_ADD_KAFKA = "/TestData/thor/poline_add_kafka.txt";
	public static final String BAJA_BULKPICK = "src/test/resources/Features/baja/baja_e2e_bulkpick.feature";
	public static final String BAJA_BULKPICK_INVALID_QUANTITY = "src/test/resources/Features/baja/baja_e2e_invalid_quantity_forbulkpick.feature";
	public static final String BAJA_BULKPICK_INVALID_STORE = "src/test/resources/Features/baja/baja_e2e_invalid_store.feature";
	public static final String BAJA_INVENTORY_CREATION_80 = "src/test/resources/TestData/Baja/InventoryCreation80.xml";
	public static final String BAJA_INVENTORY_CREATION_81 = "src/test/resources/TestData/Baja/InventoryCreation81.xml";
	public static final String BAJA_TRUCKUP_FILE = "src/test/resources/TestData/Baja/Truckup_gls2.dat";

	public static final String WITRON_SSTK = "src/test/resources/Features/witron/witron_sstk.feature";

	public static final String BAJA_ORDER_ID_FILE = "src/test/resources/TestData/Baja/OrderStatusChangeName.xml";
	public static final String BAJA_ORDER_PICK_CONFIRMATION_BULKPICK = "src/test/resources/TestData/Baja/orderPickConfirmation_BulkPick.xml";
	public static final String BAJA_ORDER_PICK_CONFIRMATION_TRIP = "src/test/resources/TestData/Baja/orderPickConfirmation_Trip.xml";
	public static final String BAJA_BULK_PICK_FILE = "src/test/resources/TestData/Baja/BulkPick/BulkPick.dat";

	public static final String FIXIT_PROBLEM_DCHO = "src/test/resources/Features/atlas/fixit_problem_DCHO.feature";
	public static final String FIXIT_PROBLEM_DC = "src/test/resources/Features/atlas/fixit_problem_DC.feature";
	public static final String FIXIT_PROBLEM_NOTWALMARTFREIGHT = "src/test/resources/Features/atlas/fixit_problem_notwalmartfreight.feature";
	public static final String FIXIT_PROBLEM_WRONGDC = "src/test/resources/Features/atlas/fixit_problem_wrongdc.feature";
	public static final String FIXIT_PROBLEM_WRONGPACK = "src/test/resources/Features/atlas/fixit_problem_wrongpack.feature";
	public static final String FIXIT_PROBLEM_NOP_NOTINITEM = "src/test/resources/Features/atlas/fixit_problem_nop_notinitem.feature";
	public static final String FIXIT_PROBLEM_WRONGDC_NOTINITEM = "src/test/resources/Features/atlas/fixit_problem_wrongdc_notinitem.feature";
	public static final String FIXIT_PROBLEM_WEB_CANCEL = "src/test/resources/Features/atlas/fixit_web_cancel.feature";
	public static final String FIXIT_PROBLEM_MOBILE_CANCEL = "src/test/resources/Features/atlas/fixit_mobile_cancel.feature";
	public static final String FIXIT_PROBLEM_MARK_RESOLVED = "src/test/resources/Features/atlas/fixit_mobile_markresolved.feature";
	public static final String FIXIT_PROBLEM_ASSIGNED_HO = "src/test/resources/Features/atlas/fixit_mobile_assigntoho.feature";
	public static final String FIXIT_PROBLEM_SEARCHCRETERIA = "src/test/resources/Features/atlas/fixit_problem_searchfilterdepartment.feature";

	public static final String FIXIT_DCTC_NOTWALMARTFREIGHT = "src/test/resources/Features/atlas/fixit_dctc_notwalmartfreight.feature";
	public static final String FIXIT_DCTC_NOP = "src/test/resources/Features/atlas/fixit_dctc_nop.feature";
	public static final String FIXIT_DCTC_WRONGDC = "src/test/resources/Features/atlas/fixit_dctc_wrongdc.feature";
	public static final String FIXIT_DCTC_WRONGPACK = "src/test/resources/Features/atlas/fixit_dctc_wrongpack.feature";
	public static final String FIXIT_DCTC_HAZMAT = "src/test/resources/Features/atlas/fixit_dctc_hazmat_close.feature";
	public static final String FIXIT_DCTC_OVERRAGE = "src/test/resources/Features/atlas/fixit_dctc_overrage.feature";
	public static final String FIXIT_DCTC_NOPNOTINITEM = "src/test/resources/Features/atlas/fixit_dctc_nop_notinitem.feature";
	public static final String FIXIT_DCTC_WRONGDCNOTINITEM = "src/test/resources/Features/atlas/fixit_dctc_wrongdc_notinitem.feature";

	public static final String FIXIT_PROBLEM_ATLASPOLINEUPDATE = "/TestData/Atlas_POLineAdd/fixit_atlas_addpoline.txt";
	
	public static final String FIXIT_RDC_PROBLEMS= "src/test/resources/Features/atlas/fixit_rdc_problems.feature";

	public static final String WITRON_PALLET_HOLD = "src/test/resources/Features/witron/witron_pallet_hold.feature";
	public static final String WITRON_INBOUND_OUTBOUND_BASE = "src/test/resources/Features/witron/witron_inbound_outbound_base.feature";
	public static final String WITRON_FIFO = "src/test/resources/Features/witron/witron_FIFO.feature";
	public static final String WITRON_FEFO = "src/test/resources/Features/witron/witron_FEFO.feature";
	public static final String WITRON_PO_LINE_ADD = "src/test/resources/Features/witron/witron_PO_Line_Add.feature";
	public static final String WITRON_PO_LINE_UPDATE = "src/test/resources/Features/witron/witron_po_update.feature";
	public static final String WITRON_RIPENING = "src/test/resources/Features/witron/witron_ripening.feature";
	public static final String WITRON_SQC = "src/test/resources/Features/witron/witron_sqc.feature";
	public static final String WITRON_SSC = "src/test/resources/Features/witron/witron_ssc.feature";
	public static final String WITRON_BATCH_PLANNER = "src/test/resources/Features/witron/witron_batch_planner.feature";
	public static final String WITRON_OSDR = "src/test/resources/Features/witron/witron_OSDR.feature";
	public static final String WITRON_VTR = "src/test/resources/Features/witron/witron_vtr_from_receiving_app.feature";
	public static final String WITRON_PALLET_CORRECTION = "src/test/resources/Features/witron/witron_pallet_correction.feature";
	public static final String WITRON_MDM = "src/test/resources/Features/witron/witron_mdm.feature";
	public static final String WITRON_STO_OSDR = "src/test/resources/Features/witron/witron_sto.feature";
	public static final String WITRON_SPLIT_PALLET = "src/test/resources/Features/witron/witron_split_pallet.feature";
	public static final String WITRON_DISTRO_TURN_ADJ = "src/test/resources/Features/witron/witron_distro_turn_adj.feature";
	public static final String WITRON_WAVE_REVERSAL = "src/test/resources/Features/witron/witron_reverse_wave.feature";
	public static final String WITRON_RECEIVING_EXCEPTION = "src/test/resources/Features/witron/receivingException.feature";
	public static final String WITRON_INVOICE = "src/test/resources/Features/witron/witron_invoice.feature";
	public static final String WITRON_MODIFY_CANCEL_WAVE = "src/test/resources/Features/witron/witron_modify_cancel_wave.feature";
	public static final String WITRON_ORDERS_CREATE = "src/test/resources/Features/witron/witron_prod_ordercreate.feature";
	
	public static final String WITRON_MODIFY_ITEM_ATTRIBUTE = "src/test/resources/Features/witron/witron_modify_item_attribute.feature";

	public static final String WITRON_OUTS = "src/test/resources/Features/witron/witron_outs.feature";

	public static final String SAMS_BASE_FEATURE = "src/test/resources/Features/sams/base_flow.feature";
	public static final String SAMS_FIXIT_PROBLEM = "src/test/resources/Features/sams/sams_problem.feature";
	public static final String SAMS_DAMAGE = "src/test/resources/Features/sams/sams_pre_receiving_damage.feature";

	public static final String CREATE_DELIVERY_SCHEDULER2_MESSAGE = "/TestData/IDMDeliveryCreationSch2.txt";
	public static final String RDC_CREATE_DELIVERY_SCHEDULER2_MESSAGE = "/TestData/rdc/GDMDeliveryCreationSch2.txt";
	public static final String RTC_MESSAGE = "/TestData/RTC.txt";
	
	public static final String EVENT_AUDITOR = "/TestData/EventAuditor.txt";
	public static final String EVENT_AUDITOR_ITEM_MDM="/TestData/EventAuditItemMDM.txt";

	public static final String CREATE_RECEIVING_PROBLEM_NWF= "/TestData/ReceivingProblem.txt";
	public static final String CREATE_RECEIVING_PROBLEM_OVG= "/TestData/receivingProblemOvg.txt";
	public static final String RESOLUTION_FOR_RECEIVING_PROBLEM = "/TestData/receivingProblemResolution.txt";
	public static final String CREATE_RECEIVING_PROBLEM_NOP= "/TestData/receivingProblemNOP.txt";

	public static final String QTC_CONTAINER_CREATION = "/TestData/qtcContainerCreation.txt";

	public static final String ITEM_MDM_FETCH = "/TestData/item_mdm_fetch.txt";
	
	public static final String GDC_WEB_OVG = "src/test/resources/Features/gdc/fixit_web_wrongpack.feature";
	public static final String GDC_WEB_CANCEL = "src/test/resources/Features/gdc/fixit_web_wrongpack_cancel.feature";
	public static final String GDC_WEB_OVERAGE = "src/test/resources/Features/gdc/fixit_web_overage.feature";
	public static final String GDC_WEB_ASSIGNHO = "src/test/resources/Features/gdc/fixit_web_overage_assigntoho.feature";
	public static final String GDC_WEB_NWF = "src/test/resources/Features/gdc/fixit_web_nwf.feature";
	public static final String GDC_WEB_NOP = "src/test/resources/Features/gdc/fixit_web_nop.feature";
	public static final String GDC_WEB_DATEISSUE = "src/test/resources/Features/gdc/fixit_web_dateissue.feature";
	
	public static final String GDC_FIXIT_MOBILE_CANCEL= "src/test/resources/Features/gdc/fixit_mobile_nwf_cancel.feature";
	public static final String GDC_FIXIT_MOBILE_NWF= "src/test/resources/Features/gdc/fixit_mobile_nwf.feature";
	
	public static final String RDC_FIXIT_WEB_OVERAGE = "src/test/resources/Features/gdc/fixit_web_rdc_overage.feature";
	public static final String RDC_FIXIT_WEB_ASSIGNEDTOHO = "src/test/resources/Features/gdc/fixit_web_rdc_assigntoho.feature";
	public static final String RDC_FIXIT_WEB_CANCEL = "src/test/resources/Features/gdc/fixit_web_rdc_cancel.feature";

	public static final String RDC_FIXIT_MOBILE_NWF = "src/test/resources/Features/gdc/fixit_mobile_rdc_nwf.feature";
	public static final String RDC_FIXIT_MOBILE_OVG = "src/test/resources/Features/gdc/fixit_mobile_rdc_ovg.feature";
	public static final String RDC_FIXIT_MOBILE_WRONGDC = "src/test/resources/Features/gdc/fixit_mobile_rdc_wrongdc.feature";
	
	public static final String WITRON_MODIFY_ITEM_MDM_ATTRIBUTE = "/TestData/witronModifyItemAttribute.txt";

	public static final String PHARMACY_PACKDATA_TEMPLATE_FILE = "/TestData/pharmacy/PackTemplate.txt";
	public static final String PHARMACY_MULTISKU_PACKDATA_TEMPLATE_FILE = "/TestData/pharmacy/MultiSKUPackTemplate.txt";
	public static final String PHARMACY_MULTISKU_ITEMDATA_TEMPLATE_FILE = "/TestData/pharmacy/ItemInPackTemplate.txt";
	public static final String PHARMACY_SHIPMENT_TEMPLATE_FILE = "/TestData/pharmacy/ShipmentTemplate.txt";
	public static final String PHARMACY_CASE_RECEIVING = "src/test/resources/Features/pharmacy/pharmacy_caseReceivingE2E.feature";
	public static final String PHARMACY_PALLET_RECEIVING = "src/test/resources/Features/pharmacy/pharmacy_PalletReceivingE2E.feature";
	public static final String PHARMACY_PARTIAL_CASE_RECEIVING = "src/test/resources/Features/pharmacy/pharmacy_partialCaseReceivingE2E.feature";
	public static final String PHARMACY_PARTIAL_PALLET_RECEIVING = "src/test/resources/Features/pharmacy/pharmacy_partialPalletReceivingE2E.feature";
	public static final String PHARMACY_LABEL_CANCEL = "src/test/resources/Features/pharmacy/pharmacy_LabelCancelE2E.feature";
	public static final String PHARMACY_UNIT_RECEIVING = "src/test/resources/Features/pharmacy/pharmacy_unitReceivingE2E.feature";
	public static final String PHARMACY_PARTIAL_UNIT_RECEIVING = "src/test/resources/Features/pharmacy/pharmacy_partialUnitReceivingE2E.feature";
	public static final String PHARMACY_D40_FULL_PALLET_RECEIVING = "src/test/resources/Features/pharmacy/Pharmacy_D40_Pallet_Full_Receiving.feature";
	public static final String PHARMACY_D40_PARTIAL_PALLET_RECEIVING = "src/test/resources/Features/pharmacy/Pharmacy_Manual_slotting_D40_Partial_pallet_Receiving.feature";
	public static final String PHARMACY_FALLBACK_FLOW ="src/test/resources/Features/pharmacy/pharmacy_FallBackE2E.feature";
	public static final String PHARMACY_DELIVERY_UNLOAD ="src/test/resources/Features/pharmacy/pharmacy_DeliveryUnload.feature";
	public static final String PHARMACY_2DBARCODE_CASE_RECEIVING ="src/test/resources/Features/pharmacy/pharmacy_2DBarcodeCaseReceivingE2E.feature";
	public static final String PHARMACY_2DBARCODE_UNIT_RECEIVING ="src/test/resources/Features/pharmacy/pharmacy_2DBarcodeUnitReceivingE2E.feature";
	public static final String PHARMACY_2DBARCODE_PARTIAL_UNIT_RECEIVING ="src/test/resources/Features/pharmacy/pharmacy_2DBarcodePartialUnitReceivingE2E.feature";
	public static final String PHARMACY_CASE_MULTI_PACK_RECEIVING ="src/test/resources/Features/pharmacy/pharmacy_caseReceivingMultiPackE2E.feature";
	public static final String PHARMACY_PALLET_MULTI_SHIPMENT_RECEIVING ="src/test/resources/Features/pharmacy/pharmacy_palletReceivingMultiShipmentE2E.feature";
	public static final String PHARMACY_FALLBACK_LABELCANCEL_UNIT_RECEIVING ="src/test/resources/Features/pharmacy/pharmacy_FallbackLabelCancelUnitReceivingE2E.feature";
	public static final String FIXIT_PHARMACY_OVG = "src/test/resources/Features/pharmacy/fixit_pharma_ovg.feature";

	public static final String RDC_CONTAINER_TEMPLATE_FILE = "/TestData/rdc/ContainerTemplate.txt";
	public static final String RDC_RECEIVING_RECEIPTS_TEMPLATE_FILE = "/TestData/rdc/ReceivingReceiptsTemplate.txt";
	public static final String MCB_CREATE_FILE = "/TestData/acc/mcb_Payloads/mcbCreate.txt";
	public static final String MCB_COMPLETE_START = "/TestData/acc/mcb_Payloads/mcbCompleteStart.txt";
	public static final String MCB_COMPLETE_FINISH ="/TestData/acc/mcb_Payloads/mcbCompleteFinish.txt";
	public static final String MCB_CREATE_FILE_FOR_REGULAR_FLOW ="/TestData/acc/mcb_Payloads/mcbCreateForRegularFlow.txt";
	public static final String ACC_CONTAINER_CREATION_MESSAGE ="/TestData/acc/containerCreationData.txt";

	
	public static final String CATALYST_YMS_CHECKIN_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsCheckInTemplate.txt";
	public static final String CATALYST_YMS_DOORASSIGN_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsDoorAssignTemplate.txt";
	public static final String CATALYST_OMS_PO_CREATION_DATA = "/src/test/resources/TestData/Catalyst/oms/catalystPoBaseFlow.csv";
	public static final String CATALYST_OMS_HACCP_PO_CREATION_DATA = "/src/test/resources/TestData/Catalyst/oms/catalystPoHaccpFlow.csv";
	public static final String CATALYST_OMS_TIHI_PO_CREATION_DATA = "/src/test/resources/TestData/Catalyst/oms/catalystPoTiHiFlow.csv";
	public static final String CATALYST_OMS_BANANA_PO_CREATION_DATA = "/src/test/resources/TestData/Catalyst/oms/catalystPoBananaFlow.csv";
	public static final String CATALYST_OMS_RECALL_HOLD_PO_CREATION_DATA = "/src/test/resources/TestData/Catalyst/oms/catalystPoRecallHoldFlow.csv";

	public static final String CATALYST_YMS_OB_GATEIN_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsOBGateInTemplate.txt";
	public static final String CATALYST_YMS_OB_DOORASSIGN_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsOBDoorAssignTemplate.txt";
//	public static final String CATALYST_YMS_OB_GATEOUT_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsOBGateOutTemplate.txt";
	public static final String CATALYST_YMS_GATEOUT_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsGateOutTemplate.txt";
	public static final String CATALYST_YMS_VDOOR_TO_ZONE_MOVE_TEMPLATE_FILE = "/TestData/Catalyst/yms/ymsBumpMoveTemplate.txt";
	

	public static final String CATALYST_SCT_SEARCH_TEMPLATE_FILE = "/TestData/Catalyst/sct/sctSearchTemplate.txt";
	public static final String DPB_CREATE_TRIP_JSON = "/TestData/dpb/tripCreateJSON.txt";
	public static final String DPB_ITEM_DETAILS_CREATE_TRIP_JSON = "/TestData/dpb/itemDetailsTripCreateJSON.txt";
	public static final String DPB_ASSIGN_TRIP_JSON = "/TestData/dpb/AssignTripJSON.txt";
	public static final String DPB_PICK_CONFIRMATION_JSON = "/TestData/dpb/PickConfirmationJSON.txt";
	public static final String DPB_COMPLETE_TRIP_JSON = "/TestData/dpb/ResumeOrCompleteTripJSON.txt";
	public static final String DPB_UNASSIGN_TRIP_JSON = "/TestData/dpb/UnassignTripJSON.txt";
	public static final String DPB_CANCEL_TRIP_JSON = "/TestData/dpb/CancelTripJSON.txt";
	public static final String DPB_PAUSE_TRIP_JSON = "/TestData/dpb/PauseTripJSON.txt";
}
