package com.walmart.framework.utilities.db;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class Casandra {

	
	@Autowired
	Environment environment;

	private Cluster cluster;
	private Session session;

	Logger logger = LogManager.getLogger(this.getClass());

	public Session connectToDb() {

		String hostname = environment.getProperty("casandra_hostname");
		String keySpace = environment.getProperty("casandra_keySpace");
		String username = environment.getProperty("casandra_username");
		String password = environment.getProperty("casandra");

		logger.info("hostname:{} keySpace:{} username:{} password:{} ",hostname,keySpace,username,password );
		cluster = Cluster.builder().addContactPoint(hostname).withCredentials(username, password).build();
		session = cluster.connect(keySpace);

		logger.info("Casandra DB Connection successful");

		return session;
	}

	public ResultSet executeQuery(Session session, String cqlStat) {
		return session.execute(cqlStat);
		
	}

	public void closeSession() {
		if (cluster != null) {
			cluster.close();
		}

		if (session != null) {
			session.close();
		}
	}
}
