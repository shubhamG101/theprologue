
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import com.walmart.framework.supplychain.domain.witron.ExpectedAllocation;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "orderId",
        "orderTrackingNumber",
        "orderRecordType",
        "ow_status",
        "op_status",
        "allocationOrderId",
        "priority",
        "destinationNum",
        "sourceNumber",
        "quantity",
        "itemNumber",
        "channelMethod",
        "whpk",
        "vnpk",
        "plannedPo",
        "whpkSellPrice",
        "omsChannelMethod",
        "opChannelMethod",
        "isOverage",
        "releaseNbr",
        "orderType",
        "substitutionFlag",
        "wareHouseAreaCode",
        "expectedAllocation",
        "outQty"
})
public class OrdersDetail {

    @JsonProperty("orderId")
    private String orderId;
    @JsonProperty("plannedPo")
    private String plannedPo;
    @JsonProperty("sourceNumber")
    private String sourceNumber;
    @JsonProperty("orderTrackingNumber")
    private String orderTrackingNumber;
    @JsonProperty("orderRecordType")
    private String orderRecordType;
    @JsonProperty("ow_status")
    private String owStatus;
    @JsonProperty("op_status")
    private String opStatus;
    @JsonProperty("allocationOrderId")
    private String allocationOrderId;
    @JsonProperty("priority")
    private String priority;
    @JsonProperty("destinationNum")
    private String destinationNum;
    @JsonProperty("quantity")
    private String quantity;
    @JsonProperty("itemNumber")
    private String itemNumber;
    @JsonProperty("channelMethod")
    private String channelMethod;
    @JsonProperty("whpk")
    private String whpk;
    @JsonProperty("vnpk")
    private String vnpk;
    @JsonProperty("whpkSellPrice")
    private String whpkSellPrice;
    @JsonProperty("omsChannelMethod")
    private String omsChannelMethod;
    @JsonProperty("opChannelMethod")
    private String opChannelMethod;
    @JsonProperty("isOverage")
    private Boolean isOverage;
    @JsonProperty("releaseNbr")
    private String releaseNbr;
    @JsonProperty("orderType")
    private String orderType;
    @JsonProperty("substitutionFlag")
    private boolean substitutionFlag;
    @JsonProperty("wareHouseAreaCode")
    private String wareHouseAreaCode;
    @JsonProperty("outQty")
    private String outQty;
    @JsonProperty("expectedAllocation")
    private ExpectedAllocation expectedAllocation;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    
    public OrdersDetail() {
		this.isOverage=false;
	}
    @JsonProperty("orderId")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("orderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public OrdersDetail withOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }
    
    @JsonProperty("releaseNbr")
    public String getReleaseNbr() {
        return releaseNbr;
    }

    @JsonProperty("releaseNbr")
    public void setReleaseNbr(String releaseNbr) {
        this.releaseNbr = releaseNbr;
    }

    public OrdersDetail withReleaseNbr(String releaseNbr) {
        this.releaseNbr = releaseNbr;
        return this;
    }

    @JsonProperty("orderTrackingNumber")
    public String getOrderTrackingNumber() {
        return orderTrackingNumber;
    }

    @JsonProperty("orderTrackingNumber")
    public void setOrderTrackingNumber(String orderTrackingNumber) {
        this.orderTrackingNumber = orderTrackingNumber;
    }

    public OrdersDetail withOrderTrackingNumber(String orderTrackingNumber) {
        this.orderTrackingNumber = orderTrackingNumber;
        return this;
    }

    public String getVnpk() {
        return vnpk;
    }

    public void setVnpk(String vnpk) {
        this.vnpk = vnpk;
    }

    public OrdersDetail withVnpk(String vnpk) {
        this.vnpk = vnpk;
        return this;
    }

    public String getPlannedPo() {
        return plannedPo;
    }

    public void setPlannedPo(String plannedPo) {
        this.plannedPo = plannedPo;
    }

    public OrdersDetail withPlannedPo(String plannedPo) {
        this.plannedPo = plannedPo;
        return this;
    }

    @JsonProperty("orderRecordType")
    public String getOrderRecordType() {
        return orderRecordType;
    }

    @JsonProperty("orderRecordType")
    public void setOrderRecordType(String orderRecordType) {
        this.orderRecordType = orderRecordType;
    }

    public OrdersDetail withOrderRecordType(String orderRecordType) {
        this.orderRecordType = orderRecordType;
        return this;
    }

    @JsonProperty("ow_status")
    public String getOwStatus() {
        return owStatus;
    }

    @JsonProperty("ow_status")
    public void setOwStatus(String owStatus) {
        this.owStatus = owStatus;
    }

    public OrdersDetail withOwStatus(String owStatus) {
        this.owStatus = owStatus;
        return this;
    }

    @JsonProperty("op_status")
    public String getOpStatus() {
        return opStatus;
    }

    @JsonProperty("op_status")
    public void setOpStatus(String opStatus) {
        this.opStatus = opStatus;
    }

    public OrdersDetail withOpStatus(String opStatus) {
        this.opStatus = opStatus;
        return this;
    }

    @JsonProperty("allocationOrderId")
    public String getAllocationOrderId() {
        return allocationOrderId;
    }

    @JsonProperty("allocationOrderId")
    public void setAllocationOrderId(String allocationOrderId) {
        this.allocationOrderId = allocationOrderId;
    }

    public OrdersDetail withAllocationOrderId(String allocationOrderId) {
        this.allocationOrderId = allocationOrderId;
        return this;
    }

    @JsonProperty("priority")
    public String getPriority() {
        return priority;
    }

    @JsonProperty("priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }

    public OrdersDetail withPriority(String priority) {
        this.priority = priority;
        return this;
    }

    @JsonProperty("destinationNum")
    public String getDestinationNum() {
        return destinationNum;
    }

    @JsonProperty("destinationNum")
    public void setDestinationNum(String destinationNum) {
        this.destinationNum = destinationNum;
    }

    public OrdersDetail withDestinationNum(String destinationNum) {
        this.destinationNum = destinationNum;
        return this;
    }

    @JsonProperty("quantity")
    public String getQuantity() {
        return quantity;
    }

    @JsonProperty("quantity")
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public OrdersDetail withQuantity(String quantity) {
        this.quantity = quantity;
        return this;
    }

    @JsonProperty("itemNumber")
    public String getItemNumber() {
        return itemNumber;
    }

    @JsonProperty("itemNumber")
    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public OrdersDetail withItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
        return this;
    }

    public String getSourceNumber() {
        return sourceNumber;
    }

    public void setSourceNumber(String sourceNumber) {
        this.sourceNumber = sourceNumber;
    }

    public OrdersDetail withSourceNumber(String sourceNumber) {
        this.sourceNumber = sourceNumber;
        return this;
    }

    @JsonProperty("channelMethod")
    public String getChannelMethod() {
        return channelMethod;
    }

    @JsonProperty("channelMethod")
    public void setChannelMethod(String channelMethod) {
        this.channelMethod = channelMethod;
    }

    public OrdersDetail withChannelMethod(String channelMethod) {
        this.channelMethod = channelMethod;
        return this;
    }

    @JsonProperty("whpk")
    public String getWhpk() {
        return whpk;
    }

    @JsonProperty("whpk")
    public void setWhpk(String whpk) {
        this.whpk = whpk;
    }

    public OrdersDetail withWhpk(String whpk) {
        this.whpk = whpk;
        return this;
    }

    @JsonProperty("whpkSellPrice")
    public String getWhpkSellPrice() {
        return whpkSellPrice;
    }

    @JsonProperty("whpkSellPrice")
    public void setWhpkSellPrice(String whpkSellPrice) {
        this.whpkSellPrice = whpkSellPrice;
    }

    public OrdersDetail withWhpkSellPrice(String whpkSellPrice) {
        this.whpkSellPrice = whpkSellPrice;
        return this;
    }

    @JsonProperty("omsChannelMethod")
    public String getOmsChannelMethod() {
        return omsChannelMethod;
    }

    @JsonProperty("omsChannelMethod")
    public void setOmsChannelMethod(String omsChannelMethod) {
        this.omsChannelMethod = omsChannelMethod;
    }

    public OrdersDetail withOmsChannelMethod(String omsChannelMethod) {
        this.omsChannelMethod = omsChannelMethod;
        return this;
    }

    @JsonProperty("opChannelMethod")
    public String getOpChannelMethod() {
        return opChannelMethod;
    }

    @JsonProperty("opChannelMethod")
    public void setOpChannelMethod(String opChannelMethod) {
        this.opChannelMethod = opChannelMethod;
    }

    public OrdersDetail withOpChannelMethod(String opChannelMethod) {
        this.opChannelMethod = opChannelMethod;
        return this;
    }
    
    @JsonProperty("isOverage")
    public Boolean getIsOverage() {
    	return isOverage;
    }

    @JsonProperty("isOverage")
    public void setIsOverage(Boolean isOverage) {
    	this.isOverage = isOverage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public OrdersDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("orderId", orderId).append("orderTrackingNumber", orderTrackingNumber).append("orderRecordType", orderRecordType).append("owStatus", owStatus).append("opStatus", opStatus).append("allocationOrderId", allocationOrderId).append("priority", priority).append("destinationNum", destinationNum).append("quantity", quantity).append("itemNumber", itemNumber).append("channelMethod", channelMethod).append("whpk", whpk).append("whpkSellPrice", whpkSellPrice).append("omsChannelMethod", omsChannelMethod).append("opChannelMethod", opChannelMethod).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(owStatus).append(itemNumber).append(opChannelMethod).append(quantity).append(orderId).append(whpkSellPrice).append(priority).append(omsChannelMethod).append(destinationNum).append(channelMethod).append(orderTrackingNumber).append(allocationOrderId).append(orderRecordType).append(whpk).append(additionalProperties).append(opStatus).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OrdersDetail) == false) {
            return false;
        }
        OrdersDetail rhs = ((OrdersDetail) other);
        return new EqualsBuilder().append(owStatus, rhs.owStatus).append(itemNumber, rhs.itemNumber).append(opChannelMethod, rhs.opChannelMethod).append(quantity, rhs.quantity).append(orderId, rhs.orderId).append(whpkSellPrice, rhs.whpkSellPrice).append(priority, rhs.priority).append(omsChannelMethod, rhs.omsChannelMethod).append(destinationNum, rhs.destinationNum).append(channelMethod, rhs.channelMethod).append(orderTrackingNumber, rhs.orderTrackingNumber).append(allocationOrderId, rhs.allocationOrderId).append(orderRecordType, rhs.orderRecordType).append(whpk, rhs.whpk).append(additionalProperties, rhs.additionalProperties).append(opStatus, rhs.opStatus).isEquals();
    }
	public String isOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public boolean getSubstitutionFlag() {
		return substitutionFlag;
	}
	public void setSubstitutionFlag(boolean substitutionFlag) {
		this.substitutionFlag = substitutionFlag;
	}
	public String getWareHouseAreaCode() {
		return wareHouseAreaCode;
	}
	public void setWareHouseAreaCode(String wareHouseAreaCode) {
		this.wareHouseAreaCode = wareHouseAreaCode;
	}
	public ExpectedAllocation getExpectedAllocation() {
		return expectedAllocation;
	}
	public void setExpectedAllocation(ExpectedAllocation expectedAllocation) {
		this.expectedAllocation = expectedAllocation;
	}
	public String getOutQty() {
		return outQty;
	}
	public void setOutQty(String outQty) {
		this.outQty = outQty;
	}
}
