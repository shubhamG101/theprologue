package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Owner", "SSCC", "OrderIdent", "OrderLineIdent", "ProdIdent", "QtyPickedUm", "UM", "PoIdent",
		"PoLineIdent", "WeightPicked", "Cube", "BatchNo", "QState", "ExpiryDate", "OriginDate", "TemperatureZone",
		"MessageType", "ReceivingPalletId", "UserId" })
public class DTL {
	@JsonProperty("Owner")
	private OwnerBean Owner;
	@JsonProperty("SSCC")
	private String SSCC;
	@JsonProperty("OrderIdent")
	private String OrderIdent;
	@JsonProperty("OrderLineIdent")
	private String OrderLineIdent;
	@JsonProperty("ProdIdent")
	private String ProdIdent;
	@JsonProperty("QtyPickedUm")
	private int QtyPickedUm;
	@JsonProperty("UM")
	private String UM;
	@JsonProperty("PoIdent")
	private String PoIdent;
	@JsonProperty("PoLineIdent")
	private String PoLineIdent;
	@JsonProperty("WeightPicked")
	private GrossWeightBean WeightPicked;
	@JsonProperty("Cube")
	private CubeBean Cube;
	@JsonProperty("BatchNo")
	private String BatchNo;
	@JsonProperty("QState")
	private int QState;
	@JsonProperty("ExpiryDate")
	private String ExpiryDate;
	@JsonProperty("OriginDate")
	private String OriginDate;
	@JsonProperty("TemperatureZone")
	private String TemperatureZone;
	@JsonProperty("MessageType")
	private int MessageType;
	@JsonProperty("ReceivingPalletId")
	private String ReceivingPalletId;
	@JsonProperty("UserId")
	private String UserId;

	@JsonProperty("Owner")
	public OwnerBean getOwner() {
		return Owner;
	}
	@JsonProperty("Owner")
	public void setOwner(OwnerBean owner) {
		Owner = owner;
		
	}
	@JsonProperty("SSCC")
	public String getSSCC() {
		return SSCC;
	}
	@JsonProperty("SSCC")
	public void setSSCC(String sSCC) {
		SSCC = sSCC;
	}
	@JsonProperty("OrderIdent")
	public String getOrderIdent() {
		return OrderIdent;
	}
	@JsonProperty("OrderIdent")
	public void setOrderIdent(String orderIdent) {
		OrderIdent = orderIdent;
	}
	@JsonProperty("OrderLineIdent")
	public String getOrderLineIdent() {
		return OrderLineIdent;
	}
	@JsonProperty("OrderLineIdent")
	public void setOrderLineIdent(String orderLineIdent) {
		OrderLineIdent = orderLineIdent;
	}
	@JsonProperty("ProdIdent")
	public String getProdIdent() {
		return ProdIdent;
	}
	@JsonProperty("ProdIdent")
	public void setProdIdent(String prodIdent) {
		ProdIdent = prodIdent;
	}
	@JsonProperty("QtyPickedUm")
	public int getQtyPickedUm() {
		return QtyPickedUm;
	}
	@JsonProperty("QtyPickedUm")
	public void setQtyPickedUm(int qtyPickedUm) {
		QtyPickedUm = qtyPickedUm;
	}
	@JsonProperty("UM")
	public String getUM() {
		return UM;
	}
	@JsonProperty("UM")
	public void setUM(String uM) {
		UM = uM;
	}
	@JsonProperty("PoIdent")
	public String getPoIdent() {
		return PoIdent;
	}
	@JsonProperty("PoIdent")
	public void setPoIdent(String poIdent) {
		PoIdent = poIdent;
	}
	@JsonProperty("PoLineIdent")
	public String getPoLineIdent() {
		return PoLineIdent;
	}
	@JsonProperty("PoLineIdent")
	public void setPoLineIdent(String poLineIdent) {
		PoLineIdent = poLineIdent;
	}
	@JsonProperty("WeightPicked")
	public GrossWeightBean getWeightPicked() {
		return WeightPicked;
	}
	@JsonProperty("WeightPicked")
	public void setWeightPicked(GrossWeightBean weightPicked) {
		WeightPicked = weightPicked;
	}
	@JsonProperty("Cube")
	public CubeBean getCube() {
		return Cube;
	}
	@JsonProperty("Cube")
	public void setCube(CubeBean cube) {
		Cube = cube;
	}
	@JsonProperty("BatchNo")
	public String getBatchNo() {
		return BatchNo;
	}
	@JsonProperty("BatchNo")
	public void setBatchNo(String batchNo) {
		BatchNo = batchNo;
	}
	@JsonProperty("QState")
	public int getQState() {
		return QState;
	}
	@JsonProperty("QState")
	public void setQState(int qState) {
		QState = qState;
	}
	@JsonProperty("ExpiryDate")
	public String getExpiryDate() {
		return ExpiryDate;
	}
	@JsonProperty("ExpiryDate")
	public void setExpiryDate(String expiryDate) {
		ExpiryDate = expiryDate;
	}
	@JsonProperty("OriginDate")
	public String getOriginDate() {
		return OriginDate;
	}
	@JsonProperty("OriginDate")
	public void setOriginDate(String originDate) {
		OriginDate = originDate;
	}
	@JsonProperty("TemperatureZone")
	public String getTemperatureZone() {
		return TemperatureZone;
	}
	@JsonProperty("TemperatureZone")
	public void setTemperatureZone(String temperatureZone) {
		TemperatureZone = temperatureZone;
	}
	@JsonProperty("MessageType")
	public int getMessageType() {
		return MessageType;
	}
	@JsonProperty("MessageType")
	public void setMessageType(int messageType) {
		MessageType = messageType;
	}
	@JsonProperty("ReceivingPalletId")
	public String getReceivingPalletId() {
		return ReceivingPalletId;
	}
	@JsonProperty("ReceivingPalletId")
	public void setReceivingPalletId(String receivingPalletId) {
		ReceivingPalletId = receivingPalletId;
	}
	@JsonProperty("UserId")
	public String getUserId() {
		return UserId;
	}
	@JsonProperty("UserId")
	public void setUserId(String userId) {
		UserId = userId;
	}
}
