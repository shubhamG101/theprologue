package com.walmart.framework.utilities.db;

public enum PRODUCT_NAME {

	 IDM("IDM"),OP("OP"),OT("OT"), OF("OF"),LOADING("LOADING"),DCFIN("DCFIN"),INV("INV"),
	 OA("OA"),OM("OM"),PLANNER("PLANNER"),FM("FM"), SHORE("SHORE"), DCFINTRANS("DCFINTRANS"), RECEIVING("RECEIVING"), SMARTSLOTTING("SMARTSLOTTING"), RDS("RDS") , WMS("WMS"), AP("AP"), FES("FES");

	String productName;

	PRODUCT_NAME(String productName) {
		this.productName = productName;
	}

	public String getValue() {

		return productName;

	}
}
