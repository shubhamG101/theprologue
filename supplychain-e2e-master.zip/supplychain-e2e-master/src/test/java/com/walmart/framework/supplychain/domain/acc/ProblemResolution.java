package com.walmart.framework.supplychain.domain.acc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "problemResolutions", "versionNbr", "lastChangeUserId" })
public class ProblemResolution {

	@JsonProperty("problemResolutions")
	private List<ProblemResolutionDetail> problemResolutions;
	@JsonProperty("versionNbr")
	private int versionNbr;
	@JsonProperty("lastChangeUserId")
	private String lastChangeUserId;
	
	@JsonProperty("problemResolutions")
	public List<ProblemResolutionDetail> getProblemResolutions() {
		return problemResolutions;
	}
	@JsonProperty("problemResolutions")
	public void setProblemResolutions(List<ProblemResolutionDetail> problemResolutions) {
		this.problemResolutions = problemResolutions;
	}
	@JsonProperty("versionNbr")
	public int getVersionNbr() {
		return versionNbr;
	}
	@JsonProperty("versionNbr")
	public void setVersionNbr(int versionNbr) {
		this.versionNbr = versionNbr;
	}
	@JsonProperty("lastChangeUserId")
	public String getLastChangeUserId() {
		return lastChangeUserId;
	}
	@JsonProperty("lastChangeUserId")
	public void setLastChangeUserId(String lastChangeUserId) {
		this.lastChangeUserId = lastChangeUserId;
	}
	
}