package com.walmart.framework.utilities.reporting;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.jayway.jsonpath.JsonPath;
import com.walmart.execution.dto.FeatureStatus;
import com.walmart.execution.generator.HtmlGenerator;
import com.walmart.execution.dto.Scenario;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.javautils.JsonPathHelper;

import jiraintegration.domain.issue.Issue;
import net.minidev.json.JSONObject;
import net.thucydides.core.model.TestOutcome;
import net.thucydides.core.model.TestStep;
import net.thucydides.core.model.screenshots.Screenshot;
import net.thucydides.core.steps.StepEventBus;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class GenerateExecutionStatus {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	static final String FEATURE_STATUS_KEY = "featureStatus";
	static final String DATA_FILE = "data.json";
	private static final String ERROR_CODE_SEPARATOR = ":-";
	private static final String TEAM_ID_SEPARATOR = "-";
	private static final String TARGET_LOG_DIR="/target/site/logs";
	private static final String TESTCASE_MAPPING_FILE="/target/site/scenario_map.json";
	private static final String REMOTE_LOG_DIR="/logs/";
	private static final String TEAM_EMAIL = "$.#0#.team_email";
	private static final String JIRA_ASSIGNEE = "$.#0#.assignee_user_id";
	private static final String COMPONENT = "$.#0#.component";
	static final String REPO_URL = "https://repository.walmart.com/repository/mvn-site/nextgen/nextgene2e-";
	private static final String SCREENSHOT_LOCATION=System.getProperty("user.dir")+"/target/site/serenity/";
	private static DecimalFormat df = new DecimalFormat("#.##");
	private static final File JIRA_TEST_ID_FILE = new File(
			System.getProperty("user.dir") + FileNames.JIRA_SCENARIO_TEST_ID_MAPPING_FILE);
	private static final String GET_MESSAGE_BODY_PATH = "$";
	Logger logger = LogManager.getLogger(GenerateExecutionStatus.class);
	SimpleDateFormat sdf = new SimpleDateFormat(Constants.SIMPLE_DATE_FORMAT);
	HtmlGenerator htmlGen = new HtmlGenerator();
	@Autowired
	JiraMiddleware jiraMiddleware;
	List<FeatureStatus> listOfStatus = Collections.synchronizedList(new ArrayList<>());
	@Autowired
	Environment applicationProperties;
	@Autowired
	JavaUtils javaUtil;
	@Autowired
	JsonPathHelper jsonPath;
	
	
	ObjectMapper mapper = new ObjectMapper();
	
	private static final String JIRA_REQUIRED = "is_jira_required";
	private static final String IS_CLOSE_JIRA_REQUIRED = "is_close_jira_required";
	private static final String IS_TEST_EXEC_REQUIRED = "is_test_exec_required";
	private static final String IS_DYNAMIC_TESTCASE_REQUIRED = "is_dynamic_testcase_creation_required";
	private static final String EMAIL_TO_DEV_REQUIRED = "send_email_to_dev";
	String listOfComponentsRequiresScreenshot[]= {""};
	public void generateExecStatus(String featureFileName) {
		try {
			synchronized (listOfStatus) {
				String targetLogFilePath=null;
				logger.info("Feature file name "+featureFileName);
					FeatureStatus featureStatus = getExecStatus(featureFileName);
					if(Config.isParallel) {
						 targetLogFilePath=segragateLogsByThread(featureStatus);
					}
					boolean isJiraRequired = isJiraRequired();
					boolean isCloseJiraRequired = isCloseJiraRequired();
					boolean isTestExecInJiraRequired = isTestExecInJiraRequired();
					List<String> listOfTicketsFoundInThisExec=getListOfTicketsInThisExecution(listOfStatus);
					logger.info("List of Tickets created in this execution so far:{} ",listOfTicketsFoundInThisExec);
					listOfStatus.add(featureStatus);
					setAdditionalFeatureDetails(featureStatus, isJiraRequired,isCloseJiraRequired,isTestExecInJiraRequired,listOfTicketsFoundInThisExec,targetLogFilePath);
					int errorCount = getNumberOfFailures();
					boolean isLastFeature=listOfStatus.size()==Config.totalNumberOfFeatures;
					logger.info("Is Last Feature:{} ",isLastFeature);
					if (!listOfStatus.isEmpty()) {
						sortCollectionOnFeature(listOfStatus);
						sortCollectionOnStatus(listOfStatus);
						String duration = getTotalDuration(listOfStatus);
						String text = htmlGen.converStatusToText(listOfStatus,
								Config.featureFileToNameMap.get(featureFileName), duration, isJiraRequired);
						if (Config.isPipeline) {
							writeToFile(text, errorCount, featureStatus,isLastFeature);
						}	
					}
				}			
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
	private synchronized List<String> getListOfTicketsInThisExecution(List<FeatureStatus> listOfStatus){
		List<String> listOfTickets=new ArrayList<>();
		for(FeatureStatus status:listOfStatus) {
			if(status.getJiraId()!=null&&!status.getJiraId().equals("")) {
				listOfTickets.add(status.getJiraId());
			}
		}
		return listOfTickets;
	}

	private int getNumberOfFailures() {
		int errorCount = 0;
		for (FeatureStatus status : listOfStatus) {
			if (status.isFailed()) {
				errorCount++;
			}
		}
		return errorCount;
	}

	@SuppressWarnings("unchecked")
	private FeatureStatus getExecStatus(String featureKey) {
		Map<String, FeatureStatus> featuresMap = (Map<String, FeatureStatus>) threadLocal.get().get(FEATURE_STATUS_KEY);

		return featuresMap.get(featureKey);
	}

	private List<FeatureStatus> sortCollectionOnFeature(List<FeatureStatus> listOfStatus) {
		listOfStatus.sort((FeatureStatus p1, FeatureStatus p2) -> p1.getFeatureName().toLowerCase()
				.compareTo(p2.getFeatureName().toLowerCase()));
		return listOfStatus;
	}

	private List<FeatureStatus> sortCollectionOnStatus(List<FeatureStatus> listOfStatus) {
		listOfStatus.sort((FeatureStatus p1, FeatureStatus p2) -> Boolean.compare(p2.isFailed(), p1.isFailed()));
		return listOfStatus;
	}

	private synchronized void writeToFile(String execStatus, int errorCount, FeatureStatus status,boolean isLastFeature) {
		String text = "";
		String ccEmails = "";
		String teamNames = "";
		String ccEmailsKey = "cc_emails";
		String teamNamesKey="team_names";
		try {
			String errorFileLoc = System.getProperty("user.dir") + "/" + DATA_FILE;
			File dataFile = new File(errorFileLoc);
			if (!Config.isDataFileCreated) {
				logger.info("data.json file to be created");
				if (dataFile.exists()) {
					logger.info("Deleting the existing data.json file");
					Files.delete(dataFile.toPath());
				}
			}
			ObjectMapper mapper = new ObjectMapper();
			if (!dataFile.exists()) {
				dataFile.createNewFile();
				logger.info("Creating data.json file as the feature is failed at location-Report gen {}", errorFileLoc);
				Config.isDataFileCreated = true;
			} else {
				text = JsonPath.read(dataFile, "$.error_log");
				ccEmails = JsonPath.read(dataFile, "$." + ccEmailsKey);
				teamNames = JsonPath.read(dataFile, "$." + teamNamesKey);
			}
			teamNames=getNewTeamList(teamNames, status.getComponentName());
			if(teamNames!=null&&teamNames.contains("(")) {
				teamNames=teamNames.replaceAll("\\(", "").replaceAll("\\)", "");
			}
			if(teamNames!=null&&isLastFeature) {
				teamNames="("+teamNames+")";
			}
			JSONObject obj = new JSONObject();
			obj.appendField("error_log", text);
			obj.appendField("error_count", errorCount);
			obj.appendField(ccEmailsKey, getNewEmailList(ccEmails, status.getTeamEmail()));
			obj.appendField(teamNamesKey, teamNames);
			String path = new File("target/site/serenity/datatables/1.10.4/media/images/Sorting icons.psd")
					.getAbsolutePath();
			path = path.replaceAll("/", Matcher.quoteReplacement("\\"));
			obj.appendField("delete_file", path);
			obj.appendField("execution_status", execStatus);
			ObjectWriter writer = mapper.writer(new DefaultPrettyPrinter());
			writer.writeValue(dataFile, obj);
		} catch (IOException e) {
			logger.error("MailContentError:{}", e);
		}
	}
	private String getNewEmailList(String existingList,String newEmail) {
		if(existingList != null && newEmail != null && existingList.contains(newEmail)) {
			logger.info("{} already present,No change in Email list:{}",newEmail,existingList);
			return existingList;
		}
		else if (isSendToDevRequired() && existingList != null && !existingList.equals("") && newEmail != null
				&& !newEmail.equals("")) {
			logger.info("Email list:{}",existingList + "," + newEmail);
			return  existingList + "," + newEmail;
			
		} else if (isSendToDevRequired() && newEmail != null && !newEmail.equals("")) {
			logger.info("Email list:{}",newEmail);
			return newEmail;
		} else {
			logger.info("No change in Email list:{}",existingList);
			return existingList;
		}
	}
	private String getNewTeamList(String existingList,String teamName) {
		if(teamName==null||teamName.equals("")||existingList==null||existingList.contains(teamName)) {
			logger.info("No change in Team list:{}",existingList);
			return existingList;
		}else if (existingList.equals("")) {
			logger.info("Team list:{}",teamName);
			return teamName;
		} 
		else {
			logger.info("Team list:{}",existingList + "," + teamName);
			return  existingList + "," + teamName;
		} 
	}
	private Scenario getScenarioStatusForTestOutcome (TestOutcome testOutCome,boolean isAnyScenarioFailed) {
		
		Scenario scenarioStatus=new Scenario();
		scenarioStatus.setScenarioName(testOutCome.getName());
		scenarioStatus.setDuration( testOutCome.getDurationInSeconds());
		scenarioStatus.setFormattedDuration(getFormattedDurationForFeature(scenarioStatus.getDuration()));
		String testCaseJiraId=getTestCaseJiraID(testOutCome);
		if(testCaseJiraId!=null) {
			scenarioStatus.setTestCaseJiraID(testCaseJiraId);
		}
		if(testOutCome.isSuccess()&&!isAnyScenarioFailed)//If there is a step(for eg jira creation api ) in Last scenario ,it marks as SUCCESS instead of IGNORED
			scenarioStatus.setStatus(Scenario.STATUS.PASS);
		else if(testOutCome.isFailure()||testOutCome.isError()) {
			scenarioStatus.setStatus(Scenario.STATUS.FAIL);
		}
		else if(testOutCome.isSkipped()||testOutCome.isPending()) {
			scenarioStatus.setStatus(Scenario.STATUS.IGNORED);
		}else {
			logger.info("Unrecognized status..Marking as IGNORED");
			scenarioStatus.setStatus(Scenario.STATUS.IGNORED);
		}
		
		return scenarioStatus;
	}
	public String getTestCaseJiraID(TestOutcome testOutCome) {
		String jiraId=null;
		if(isTestExecInJiraRequired()) {
			try {
			String scenarioName=testOutCome.getName();
			LinkedHashMap<String, String> jsonBody = jsonPath.get(JIRA_TEST_ID_FILE,GET_MESSAGE_BODY_PATH);
			 jiraId=jsonBody.get(scenarioName);
			
			if(jiraId==null&&isDynamicTestCaseCreationRequired()) {
				List<TestStep> listOfSteps=testOutCome.getTestSteps();
				String labelForTestcase=jiraMiddleware.getLabelForTestcase(Config.DC.getValue());
				StringBuilder steps=new StringBuilder();
				for(TestStep testStep:listOfSteps) {
					if(!jiraMiddleware.isJiraStep(testStep.getDescription())) {
						steps.append("\n").append(testStep.getDescription());
					}
				}
				Issue testcase=jiraMiddleware.getTestCasesByScenarioName(labelForTestcase, scenarioName);
				if(testcase==null) {
					logger.info("No testcase found in jira matching scenario name:{}, Needs to be created",scenarioName);
					
					jiraId=jiraMiddleware.createTest(scenarioName, labelForTestcase, steps.toString());
					logger.info("Jira id created for Test:{}",jiraId);
				}else {
					jiraId=testcase.getId();
				}
			}
			if(jiraId!=null&&!jiraId.equals("")) {
				writeTestCasesToJson(scenarioName, jiraId);
			}
			}catch(Exception e) { logger.error(e);}
		}
		return jiraId;
		
	}
	private void setAdditionalFeatureDetails(FeatureStatus status, boolean isJiraRequired,boolean isCloseJiraRequired,boolean isTestExecInJiraRequired,List<String> ticketsRaisedInThisExec,String remoteLogFilePath) {
		String program = System.getProperty("PROGRAM");
		String buildNo = System.getProperty("BUILD_NO");
		String env = System.getProperty("ENV");
		String buildUrl = System.getProperty("BUILD_URL");
		if(remoteLogFilePath!=null) {
			status.setRemoteLogFile(getRemoteLogFilePath(program, buildNo, env, remoteLogFilePath));
		}
		if (status.isFailed()) {
			setTeamDetailsAndCreateJiraIssueForFailure(status, program, buildNo, env, buildUrl, isJiraRequired);
		}else {
			if (isCloseJiraRequired) {
				try {
					closeIssuesForFeature(program, status, ticketsRaisedInThisExec,buildUrl);
				} catch (Exception e) {
					logger.error(e);//No impact if this fails
				}
			}
		}
		List<TestOutcome> listOfOutCome = StepEventBus.getEventBus().getBaseStepListener().getTestOutcomes();
		Date startTime = null;
		boolean isFurtherScenariosToBeMarkedAsIgnored=false;
		List<Scenario> listOfScenarioStatus=new ArrayList<>();
		for (int scenarioIndex = 0; scenarioIndex < listOfOutCome.size(); scenarioIndex++) {
			TestOutcome testOutCome=listOfOutCome.get(scenarioIndex);
			Scenario scenarioStatus=getScenarioStatusForTestOutcome(testOutCome,isFurtherScenariosToBeMarkedAsIgnored);
			if(scenarioStatus.getStatus()==Scenario.STATUS.FAIL) {
				scenarioStatus.setJiraId(status.getJiraId());
				isFurtherScenariosToBeMarkedAsIgnored=true;
			}
			if(!status.getIsFailed()&&(scenarioStatus.getStatus()==Scenario.STATUS.FAIL||scenarioStatus.getStatus()==Scenario.STATUS.IGNORED)) {
				status.setIsFailed(true);
				status.setFailedScenario(scenarioStatus.getScenarioName());
			}
			status.setDuration(status.getDuration() +scenarioStatus.getDuration());
			if (scenarioIndex == 0) {
				startTime = Date.from(listOfOutCome.get(scenarioIndex).getStartTime().toInstant());
			}
			logger.info("Duration for Scenario {}==>:{}", testOutCome.getName(),
					testOutCome.getDurationInSeconds());
			listOfScenarioStatus.add(scenarioStatus);
		}
		status.setListOfScenarios(listOfScenarioStatus);
		JavaUtils javaUtils = new JavaUtils();
		String endTime = javaUtils.getCurrentDateAndTime();
		status.setStartTime(sdf.format(startTime));
		status.setEndTime(endTime);
		status.setFormattedDuration(getFormattedDurationForFeature(status.getDuration()));
		logger.info("Feature : {} Start Time : {}" + status.getFeatureName(), status.getStartTime());
		logger.info("Feature : {} End Time : {}", status.getFeatureName(), status.getEndTime());
		logger.info("Total Duration for Feature {}==>", status.getDuration());
		if(Config.isPipeline) {
			executeJiraTestCases(listOfStatus,isTestExecInJiraRequired,program,buildNo,env);
		}
	}
	private void setTeamDetailsAndCreateJiraIssueForFailure(com.walmart.execution.dto.FeatureStatus status,String program,String buildNo,String env,String buildUrl, boolean isJiraRequired) {
		String errorCode = getErrorCode(status);
		String teamId=getTeamId(errorCode);
		ErrorCodes errorCodeEnum=ErrorCodes.getErrorCodeFromKey(errorCode);
		String failedScenario = status.getFailedScenario();
		TestOutcome testOutcome=getFailedTestOutcome(failedScenario);
		String reportUrl = getFailedScenarioLink(testOutcome, program, buildNo, env);
		boolean isScreenshotRequired=(errorCodeEnum==null||errorCodeEnum.isScreenshotRequired()==null)?Arrays.asList(listOfComponentsRequiresScreenshot).contains(teamId)
				:errorCodeEnum.isScreenshotRequired().booleanValue();
				;
		Set<String> screenshotsAndLogFiles = isScreenshotRequired?getScreenshotsForFailure(testOutcome):new HashSet<>();
		status.setReportUrl(reportUrl);
		if(status.getListOfFilesToBeUploaded()!=null) {
			screenshotsAndLogFiles.addAll(status.getListOfFilesToBeUploaded());
		}
		status.setListOfFilesToBeUploaded(screenshotsAndLogFiles);
		
		setTeamComponentAndAssignee(status, errorCode);
		if (isJiraRequired) {
			try {
				String ticket=jiraMiddleware.create(status, program, buildUrl, env, reportUrl, errorCode,null);
				status.setJiraId(ticket);
			} catch (Exception e) {
				logger.error(e);
			}
		}
	}
	private void closeIssuesForFeature(String program,FeatureStatus status,List<String> ticketsRaisedInThisExec,String buildUrl) {
		logger.info("All the issues raised by this feature if exists can be closed");
			List<Issue> listOfIssues=jiraMiddleware.getListOfJiraIssuesForFeature(program, status.getFeatureName());
			for(Issue issue:listOfIssues) {
				if(ticketsRaisedInThisExec.contains(issue.getId())) {
					logger.info("Jira Ticket {} can not be closed as it is being raise as part of this execution",issue.getId());
				}else {
					if(jiraMiddleware.closeIssue(issue.getId(),buildUrl)) {
						logger.info("Jira Ticket {} is marked as DONE",issue.getId());
					}
				}
			}
	}
	private boolean isJiraRequired() {
		return applicationProperties.getProperty(JIRA_REQUIRED) != null
				&& Boolean.parseBoolean(applicationProperties.getProperty(JIRA_REQUIRED));
	}
	private boolean isCloseJiraRequired() {
		return applicationProperties.getProperty(IS_CLOSE_JIRA_REQUIRED) != null
				&& Boolean.parseBoolean(applicationProperties.getProperty(IS_CLOSE_JIRA_REQUIRED));
	}
	private boolean isTestExecInJiraRequired() {
		return applicationProperties.getProperty(IS_TEST_EXEC_REQUIRED) != null
				&& Boolean.parseBoolean(applicationProperties.getProperty(IS_TEST_EXEC_REQUIRED));
	}
	private boolean isDynamicTestCaseCreationRequired() {
		return applicationProperties.getProperty(IS_DYNAMIC_TESTCASE_REQUIRED) != null
				&& Boolean.parseBoolean(applicationProperties.getProperty(IS_DYNAMIC_TESTCASE_REQUIRED));
	}

	private boolean isSendToDevRequired() {
		return applicationProperties.getProperty(EMAIL_TO_DEV_REQUIRED) != null
				&& Boolean.parseBoolean(applicationProperties.getProperty(EMAIL_TO_DEV_REQUIRED));
	}

	private String getTeamId( String errorCode) {
		if (errorCode != null && !errorCode.equals("")) {
			return errorCode.substring(0, errorCode.indexOf(TEAM_ID_SEPARATOR));
		}
		return "";
	}
	private void setTeamComponentAndAssignee(FeatureStatus status, String errorCode) {
		try {
			if (errorCode != null && !errorCode.equals("")) {
				String teamId = errorCode.substring(0, errorCode.indexOf(TEAM_ID_SEPARATOR));
				logger.info("Team Id:{}", teamId);
				LinkedHashMap<String, String> teamDetails = JsonPath
						.read(new File(System.getProperty("user.dir") + FileNames.TEAM_DETAILS_FILE), "$");
				if (teamDetails.containsKey(teamId)) {
					logger.info("Team Id is available in Team details");
					status.setTeamEmail(JsonPath.read(teamDetails, javaUtil.format(TEAM_EMAIL, teamId)));
					status.setJiraAssignee(JsonPath.read(teamDetails, javaUtil.format(JIRA_ASSIGNEE, teamId)));
					status.setComponentName(JsonPath.read(teamDetails, javaUtil.format(COMPONENT, teamId)));
					logger.info("Team Email:{}",status.getTeamEmail());
					logger.info("Assignee:{}",status.getJiraAssignee());
					logger.info("Component:{}",status.getComponentName());
				}else {
					status.setComponentName(teamId);
				}
			}else {
				status.setComponentName("E2E");
			}
		} catch (IOException e) {
			logger.error(e);
		}
	}

	private String getTotalDuration(List<FeatureStatus> listOfStatus) {
		Date startTime = null;
		Date endTime = null;
		for (FeatureStatus featureStatus : listOfStatus) {
			Date thisFeatureStartTime = null;
			Date thisFeatureEndTime = null;
			try {
				thisFeatureStartTime = sdf.parse(featureStatus.getStartTime());
				thisFeatureEndTime = sdf.parse(featureStatus.getEndTime());
			} catch (ParseException e) {
				logger.error("Exception while parsing the date:{}", featureStatus.getStartTime());
			}
			if (startTime == null || (thisFeatureStartTime != null && thisFeatureStartTime.before(startTime)))
				startTime = thisFeatureStartTime;
			if (endTime == null || (thisFeatureEndTime != null && thisFeatureEndTime.after(endTime)))
				endTime = thisFeatureEndTime;
		}
		logger.info("Automation Start Time: {}", startTime);
		logger.info("Automation End Time: {}", endTime);
		if (startTime == null || endTime == null) {
			return "";
		}
		long diff = endTime.getTime() - startTime.getTime();

		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000);
		String duration = "";
		if (diffHours > 0) {
			duration = diffHours + "h " + diffMinutes + "m " + diffSeconds + "s";
		} else {
			duration = diffMinutes + "m " + diffSeconds + "s";
		}

		return duration;
	}

	private String getFormattedDurationForFeature(double timeInSeconds) {
		String duration = "";
		int durationInSeconds = (int) timeInSeconds;
		long diffSeconds = durationInSeconds % 60;
		long diffMinutes = durationInSeconds / 60 % 60;
		long diffHours = durationInSeconds / (60 * 60);
		if (diffHours > 0) {
			duration = diffHours + "h " + diffMinutes + "m " + diffSeconds + "s";
		} else if (diffMinutes > 0) {
			duration = diffMinutes + "m " + diffSeconds + "s";
		} else if (diffSeconds > 0) {
			duration = diffSeconds + "s";
		} else {
			duration = df.format(timeInSeconds)+ "s";
		}
		return duration;

	}

	private TestOutcome getFailedTestOutcome(String scenario) {

		List<TestOutcome> listOfOutCome = StepEventBus.getEventBus().getBaseStepListener().getTestOutcomes();
		for (TestOutcome outcome : listOfOutCome) {
			if (outcome.getName().equalsIgnoreCase(scenario)) {
				return outcome;
			}
		}
		return null;
	}
	private String getFailedScenarioLink(TestOutcome testOutCome, String program, String buildNo, String env) {

		String baseUrl = REPO_URL + program + "-" + env + "-" + buildNo + "/serenity/";
		if(testOutCome!=null) {
			return baseUrl + testOutCome.getHtmlReport();
		}else {
			return "";
		}
	}
	private Set<String> getScreenshotsForFailure(TestOutcome testOutCome){
		Set<String> listOfScreenshots=new HashSet<>();
		if(testOutCome==null)
			return listOfScreenshots;
		List<TestStep> testSteps=testOutCome.getTestSteps();
		List<Screenshot> screenshots =testOutCome.getScreenshots();
		String errorMessage="";
		for(TestStep testStep:testSteps) {
			if((testStep.isFailure()||testStep.isError())) {
				errorMessage=testStep.getShortErrorMessage();
				break;
			}
		}
		for(Screenshot s:screenshots) {
			if(errorMessage.equals(s.getShortErrorMessage())&&listOfScreenshots.size()<3) {
				logger.info("{}",s.getErrorMessage(),SCREENSHOT_LOCATION+s.getFilename());
				listOfScreenshots.add(SCREENSHOT_LOCATION+s.getFilename());
			}
		}
		return listOfScreenshots;
	}
	private String getRemoteLogFilePath(String program, String buildNo, String env,String path) {

		return REPO_URL + program + "-" + env + "-" + buildNo + path;
		
	}

	private String getErrorCode(FeatureStatus status) {
		String errorCode = "";
		String reasonForFailure = status.getReasonForFailure();
		if (reasonForFailure != null && reasonForFailure.contains(ERROR_CODE_SEPARATOR)) {
			errorCode = reasonForFailure.substring(0, reasonForFailure.indexOf(ERROR_CODE_SEPARATOR));
			logger.info("Errorcode:{}", errorCode);
		}
		if (errorCode == null || !ErrorCodes.isValidErrorCode(errorCode)) {
			return "";
		}
		return errorCode;
	}
	private File createThreadSpecificLogFile() throws IOException {
		File destFile=null;
		String fileLoc=System.getProperty("user.dir")+"/logs/rolling.log";
		String destDir=System.getProperty("user.dir")+TARGET_LOG_DIR;
		String destFileLoc=destDir+File.separator+Thread.currentThread().getName()+".log";
		File logFile=new File(fileLoc);
		File logDir=new File(destDir);
		destFile=new File(destFileLoc);
		if(!logDir.exists()) {
			Files.createDirectories(logDir.toPath());
		}
		if(destFile.exists()) {
			Files.delete(destFile.toPath());
		}
		Files.copy(logFile.toPath(), destFile.toPath());
		return destFile;
	}
	private void processThreadLog(File logFile) throws IOException {
		    List<String> out = Files.lines(logFile.toPath())
		                        .filter(line -> line.contains(Thread.currentThread().getName()))
		                        .collect(Collectors.toList());
		    Files.write(logFile.toPath(), out, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);

	}
	private String segragateLogsByThread(FeatureStatus featureStatus) {
		String threadSpecificLogFileLoc=null;
		try {
			long startTime=System.currentTimeMillis();
		File threadSpecificLogFile=createThreadSpecificLogFile();
		processThreadLog(threadSpecificLogFile);
		long endTime=System.currentTimeMillis();
		long diffInMs=endTime-startTime;
		threadSpecificLogFileLoc=REMOTE_LOG_DIR+threadSpecificLogFile.getName();
		Set<String> filesToBeUploaded=featureStatus.getListOfFilesToBeUploaded()==null?new HashSet<>():featureStatus.getListOfFilesToBeUploaded();
		filesToBeUploaded.add(threadSpecificLogFile.getAbsolutePath());
		featureStatus.setListOfFilesToBeUploaded(filesToBeUploaded);
		logger.info("Thread {} Logs Segragator took {} seconds",Thread.currentThread().getName(),diffInMs/1000.0);
		}catch(Exception e) {//This is an internal failure,No action required
			logger.error("segragateLogsByThread has some issue");
			logger.error(e);
		}
		return threadSpecificLogFileLoc;
	}
	private void executeJiraTestCases(List<FeatureStatus>listOfStatus ,boolean isTestExecInJiraRequired,String program,String buildNo,String env) {
		if(isTestExecInJiraRequired&&listOfStatus.size()==Config.totalNumberOfFeatures&&!isFailureFoundWithoutJira(listOfStatus)) {
			try {
			logger.info("This is the last feature that is executing,Jira testcases needs to be executed");
			List<Scenario> listOfScenarios=getListOfAllScenarios(listOfStatus);
			jiraMiddleware.executeScenarios(listOfScenarios,program,buildNo,env);
			}catch(Exception e) {
				logger.error(e);
			}
		}else if(!isTestExecInJiraRequired) {
			logger.info("isTestExecInJiraRequired flag is false,hence not executing jira tests");
		}else if(listOfStatus.size()!=Config.totalNumberOfFeatures) {
			logger.info("This is not the last feature,Waiting for last feature to execute jira tests");
		}else {
			logger.info("There are AutomationFailures found,hence not executing jira tests");
		}
	}
	private boolean isFailureFoundWithoutJira(List<FeatureStatus>listOfStatus) {
		for(FeatureStatus featureStatus:listOfStatus) {
			if(featureStatus.isFailed()&&(featureStatus.getJiraId()==null||featureStatus.getJiraId().equals(""))) {
				return true;
			}
		}
		return false;
	}
	private List<Scenario> getListOfAllScenarios(List<FeatureStatus>listOfStatus) {
		 List<Scenario> listOfScenarios=new ArrayList<>();
		for(FeatureStatus featureStatus:listOfStatus) {
			for(Scenario scenario:featureStatus.getListOfScenarios()) {
				listOfScenarios.add(scenario);
			}
		}
		return listOfScenarios;
	}
	private void writeTestCasesToJson(String scenarioName,String jiraId) throws IOException {
		String fileLoc = System.getProperty("user.dir") + TESTCASE_MAPPING_FILE;
		File dataFile = new File(fileLoc);
		LinkedHashMap<String,String> scenarios=new LinkedHashMap<>();
		if(!dataFile.exists()) {
			dataFile.createNewFile();
		}else {
			scenarios=JsonPath.read(dataFile, "$");
		}
		if(!scenarios.containsKey(scenarioName)) {
			scenarios.put(scenarioName, jiraId);
			ObjectWriter writer = mapper.writer(new DefaultPrettyPrinter());
			writer.writeValue(dataFile, scenarios);
		}
	}


}
