package com.walmart.framework.supplychain.domain.inventory;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"trackingId",
"itemNumber",
"adjustBy",
"reasonCode",
"messageHeader",
"financialReportingGroup",
"baseDivisionCode"
})
public class VtrMessage {

@JsonProperty("trackingId")
private String trackingId;
@JsonProperty("itemNumber")
private Integer itemNumber;
@JsonProperty("adjustBy")
private Integer adjustBy;
@JsonProperty("reasonCode")
private Integer reasonCode;
@JsonProperty("messageHeader")
private MessageHeader messageHeader;
@JsonProperty("financialReportingGroup")
private String financialReportingGroup;
@JsonProperty("baseDivisionCode")
private String baseDivisionCode;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("trackingId")
public String getTrackingId() {
return trackingId;
}

@JsonProperty("trackingId")
public void setTrackingId(String trackingId) {
this.trackingId = trackingId;
}

@JsonProperty("itemNumber")
public Integer getItemNumber() {
return itemNumber;
}

@JsonProperty("itemNumber")
public void setItemNumber(Integer itemNumber) {
this.itemNumber = itemNumber;
}

@JsonProperty("adjustBy")
public Integer getAdjustBy() {
return adjustBy;
}

@JsonProperty("adjustBy")
public void setAdjustBy(Integer adjustBy) {
this.adjustBy = adjustBy;
}

@JsonProperty("reasonCode")
public Integer getReasonCode() {
return reasonCode;
}

@JsonProperty("reasonCode")
public void setReasonCode(Integer reasonCode) {
this.reasonCode = reasonCode;
}

@JsonProperty("messageHeader")
public MessageHeader getMessageHeader() {
return messageHeader;
}

@JsonProperty("messageHeader")
public void setMessageHeader(MessageHeader messageHeader) {
this.messageHeader = messageHeader;
}

@JsonProperty("financialReportingGroup")
public String getFinancialReportingGroup() {
return financialReportingGroup;
}

@JsonProperty("financialReportingGroup")
public void setFinancialReportingGroup(String financialReportingGroup) {
this.financialReportingGroup = financialReportingGroup;
}

@JsonProperty("baseDivisionCode")
public String getBaseDivisionCode() {
return baseDivisionCode;
}

@JsonProperty("baseDivisionCode")
public void setBaseDivisionCode(String baseDivisionCode) {
this.baseDivisionCode = baseDivisionCode;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}