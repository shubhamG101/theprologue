package com.walmart.framework.utilities.javautils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import spring.SpringTestConfiguration;


@ContextConfiguration(classes = SpringTestConfiguration.class)
public class JsonPathHelper {
	@Autowired
	JavaUtils javaUtils;
	
	private static final Logger LOGGER = LogManager.getLogger(JsonPathHelper.class);

	/**
	 * @param jsonFile
	 * @param jsonPath
	 * @param paramsForJsonPath
	 * @return T
	 */
	public <T>T get(File jsonFile, String jsonPath, String... paramsForJsonPath) {
		if (paramsForJsonPath != null && paramsForJsonPath.length > 0) {
			
			jsonPath = javaUtils.format(jsonPath, paramsForJsonPath);
		}
		try {
			return JsonPath.read(jsonFile, jsonPath);
		} catch (IOException e) {
			throw new AutomationFailure("Something went wrong while parsing json data for "+jsonPath, e);
		}
	}

	
	/**
	 * @param json
	 * @param jsonPath
	 * @param paramsForJsonPath
	 * @return T
	 * 
	 */
	public <T>T get(String json, String jsonPath, String... paramsForJsonPath) {
		if (paramsForJsonPath != null && paramsForJsonPath.length > 0) {
			jsonPath = javaUtils.format(jsonPath, paramsForJsonPath);
		}
			return JsonPath.read(json, jsonPath);
	}

	
	/**
	 * @param json
	 * @param jsonPath
	 * @param paramsForJsonPath
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> T getFirst(String json, String jsonPath, String... paramsForJsonPath)  {
		List<T> listOfData = (List<T>) get(json, jsonPath,paramsForJsonPath);
		if (listOfData.size() > 0) {
			return listOfData.get(0);
		} else {
			return null;//First element of an empty list will be a null value
		}
	}

	/**
	 * @param jsonFile
	 * @param jsonPath
	 * @param paramsForJsonPath
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> T getFirst(File jsonFile, String jsonPath, String... paramsForJsonPath) {
		List<T> listOfData= (List<T>) get(jsonFile, jsonPath,paramsForJsonPath);
		if (listOfData.size() > 0) {
			return listOfData.get(0);
		} else {
			return null;
		}
	}
	
}
