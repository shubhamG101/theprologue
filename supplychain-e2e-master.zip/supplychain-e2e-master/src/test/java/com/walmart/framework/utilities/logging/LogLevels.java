package com.walmart.framework.utilities.logging;

public enum LogLevels {

	DEBUG("DEBUG"),
	INFO("INFO"),
	ERROR("ERROR"),
	TRACE("TRACE"),
	ALL("ALL"),
	WARN("WARN");

	String logLevel;
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public String getLogLevel() {
		return logLevel;
	}
	
	LogLevels(String logLevel) {
		this.logLevel = logLevel;
	}
}