package com.walmart.framework.utilities.parsing;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.ContainerDetails;
import com.walmart.framework.utilities.json.JsonUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import net.minidev.json.parser.ParseException;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class XmlParser {

	@Autowired
	JsonUtils jsonUtil;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;

	List<ContainerDetails> contDetails = new ArrayList<>();
	String testFlowData;

	Logger logger = LogManager.getLogger(this.getClass());

	public void parseInventoryXml(String fileName) {

		try {
			testFlowData = threadLocal.get().get("testFlowData").toString();

			File fXmlFile = new File(fileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();

			logger.info("Root element :" + doc.getDocumentElement().getNodeName());
			logger.info("Fetching all the loadUnits");
			NodeList nList = doc.getElementsByTagName("loadUnit");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				ContainerDetails contObj = new ContainerDetails();

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					contObj.setIsUsed("false");
					contObj.setItemNumber(eElement.getElementsByTagName("productId").item(0).getTextContent());
					contObj.setLoadUnitId(eElement.getElementsByTagName("loadUnitId").item(0).getTextContent());

					contDetails.add(contObj);
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Something went wrong while parsing the inventory xml", e);
		}
	}

	public void updateInventoryDetails() throws JsonProcessingException, ParseException {
		String testFlowData_updated = jsonUtil.setJsonAtJsonPath(testFlowData, contDetails,
				"$..testFlowData.containerDetails");
		threadLocal.get().put("testFlowData", testFlowData_updated);
		logger.info("TestFlowData after updating container details or loadUnitID:"
				+ String.valueOf(threadLocal.get().get("testFlowData")));
	}
}