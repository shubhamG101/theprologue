package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.walmart.framework.supplychain.domain.thor.ToteDetail;
import com.walmart.framework.supplychain.domain.thor.ToteIterator;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "vnpkcbuomcd", "vnpkcbqty", "vnpkwtqty", "vnpkwtqtyuomcd", "vnpkqty", "whpkqty", "opolnbr",
		"smppoind", "mancrtind", "promobuyind", "acctgdptnbr", "itmnbr", "plttiqty", "plthiqty", "omspolinedest", "chnlmthdcd", "vnpkcstamt", "polnstcd", "itm1dsc", "vnpkcstuomcd", "chnmthtxt", "vndrstckid", "vndrnbr", "vndrdptnbr", "vndrseqnbr"})
public class POLine {
		@JsonProperty("vnpkcbuomcd")
		private String vnpkcbuomcd;
		@JsonProperty("vnpkcbqty")
		private String vnpkcbqty;
		@JsonProperty("vnpkwtqty")
		private String vnpkwtqty;
		@JsonProperty("vnpkwtqtyuomcd")
		private String vnpkwtqtyuomcd;
		@JsonProperty("vnpkqty")
		private String vnpkqty;
		@JsonProperty("whpkqty")
		private String whpkqty;
		@JsonProperty("opolnbr")
		private String opolnbr;
		@JsonProperty("smppoind")
		private String smppoind;
		@JsonProperty("mancrtind")
		private String mancrtind;
		@JsonProperty("promobuyind")
		private String promobuyind;
		@JsonProperty("acctgdptnbr")
		private String acctgdptnbr;
		@JsonProperty("itmnbr")
		private String itmnbr;
		@JsonProperty("plttiqty")
		private String plttiqty;
		@JsonProperty("plthiqty")
		private String plthiqty;
		@JsonProperty("chnlmthdcd")
		private String chnlmthdcd;
		@JsonProperty("vnpkcstamt")
		private String vnpkcstamt;
		@JsonProperty("polnstcd")
		private String polnstcd;
		@JsonProperty("itm1dsc")
		private ItemDesc itm1dsc;
		@JsonProperty("vnpkcstuomcd")
		private String vnpkcstuomcd;
		@JsonProperty("chnmthtxt")
		private ChnText chnmthtxt;
		@JsonProperty("vndrstckid")
		private Vndorstc vndrstckid;
		@JsonProperty("omspolinedest")
		private List<POLineDest> omspolinedest;
		@JsonProperty("vndrnbr")
		private String vndrnbr;
		@JsonProperty("vndrdptnbr")
		private String vndrdptnbr;
		@JsonProperty("vndrseqnbr")
		private String vndrseqnbr;

		public String getVnpkcbuomcd() {
			return vnpkcbuomcd;
		}
		public void setVnpkcbuomcd(String vnpkcbuomcd) {
			this.vnpkcbuomcd = vnpkcbuomcd;
		}
		public String getVnpkcbqty() {
			return vnpkcbqty;
		}
		public void setVnpkcbqty(String vnpkcbqty) {
			this.vnpkcbqty = vnpkcbqty;
		}
		public String getVnpkwtqty() {
			return vnpkwtqty;
		}
		public void setVnpkwtqty(String vnpkwtqty) {
			this.vnpkwtqty = vnpkwtqty;
		}
		public String getVnpkwtqtyuomcd() {
			return vnpkwtqtyuomcd;
		}
		public void setVnpkwtqtyuomcd(String vnpkwtqtyuomcd) {
			this.vnpkwtqtyuomcd = vnpkwtqtyuomcd;
		}
		public String getVnpkqty() {
			return vnpkqty;
		}
		public void setVnpkqty(String vnpkqty) {
			this.vnpkqty = vnpkqty;
		}
		public String getWhpkqty() {
			return whpkqty;
		}
		public void setWhpkqty(String whpkqty) {
			this.whpkqty = whpkqty;
		}
		public String getOpolnbr() {
			return opolnbr;
		}
		public void setOpolnbr(String opolnbr) {
			this.opolnbr = opolnbr;
		}
		public String getSmppoind() {
			return smppoind;
		}
		public void setSmppoind(String smppoind) {
			this.smppoind = smppoind;
		}
		public String getMancrtind() {
			return mancrtind;
		}
		public void setMancrtind(String mancrtind) {
			this.mancrtind = mancrtind;
		}
		public String getPromobuyind() {
			return promobuyind;
		}
		public void setPromobuyind(String promobuyind) {
			this.promobuyind = promobuyind;
		}
		public String getAcctgdptnbr() {
			return acctgdptnbr;
		}
		public void setAcctgdptnbr(String acctgdptnbr) {
			this.acctgdptnbr = acctgdptnbr;
		}
		public String getItmnbr() {
			return itmnbr;
		}
		public void setItmnbr(String itmnbr) {
			this.itmnbr = itmnbr;
		}
		public String getPlttiqty() {
			return plttiqty;
		}
		public void setPlttiqty(String plttiqty) {
			this.plttiqty = plttiqty;
		}
		public String getPlthiqty() {
			return plthiqty;
		}
		public void setPlthiqty(String plthiqty) {
			this.plthiqty = plthiqty;
		}
		public String getChnlmthdcd() {
			return chnlmthdcd;
		}
		public void setChnlmthdcd(String chnlmthdcd) {
			this.chnlmthdcd = chnlmthdcd;
		}
		public String getVnpkcstamt() {
			return vnpkcstamt;
		}
		public void setVnpkcstamt(String vnpkcstamt) {
			this.vnpkcstamt = vnpkcstamt;
		}
		public List<POLineDest> getOmspolinedest() {
			return omspolinedest;
		}
		public void setOmspolinedest(List<POLineDest> omspolinedest) {
			this.omspolinedest = omspolinedest;
		}
		public String getPolnstcd() {
			return polnstcd;
		}
		public void setPolnstcd(String polnstcd) {
			this.polnstcd = polnstcd;
		}
		@JsonProperty("itm1dsc")
		public ItemDesc getItm1dsc() {
			return itm1dsc;
		}
		@JsonProperty("itm1dsc")
		public void setItm1dsc(ItemDesc itm1dsc) {
			this.itm1dsc = itm1dsc;
		}
		@JsonProperty("vnpkcstuomcd")
		public String getVnpkcstuomcd() {
			return vnpkcstuomcd;
		}
		@JsonProperty("vnpkcstuomcd")
		public void setVnpkcstuomcd(String vnpkcstuomcd) {
			this.vnpkcstuomcd = vnpkcstuomcd;
		}
		@JsonProperty("chnmthtxt")
		public ChnText getChnmthtxt() {
			return chnmthtxt;
		}
		@JsonProperty("chnmthtxt")
		public void setChnmthtxt(ChnText chnmthtxt) {
			this.chnmthtxt = chnmthtxt;
		}
		@JsonProperty("vndrstckid")
		public Vndorstc getVndrstckid() {
			return vndrstckid;
		}
		@JsonProperty("vndrstckid")
		public void setVndrstckid(Vndorstc vndrstckid) {
			this.vndrstckid = vndrstckid;
		}
		@JsonProperty("vndrnbr")
		public String getVndrnbr() {
			return vndrnbr;
		}
		@JsonProperty("vndrnbr")
		public void setVndrnbr(String vndrnbr) {
			this.vndrnbr = vndrnbr;
		}
		@JsonProperty("vndrdptnbr")
		public String getVndrdptnbr() {
			return vndrdptnbr;
		}
		@JsonProperty("vndrdptnbr")
		public void setVndrdptnbr(String vndrdptnbr) {
			this.vndrdptnbr = vndrdptnbr;
		}
		@JsonProperty("vndrseqnbr")
		public String getVndrseqnbr() {
			return vndrseqnbr;
		}
		@JsonProperty("vndrseqnbr")
		public void setVndrseqnbr(String vndrseqnbr) {
			this.vndrseqnbr = vndrseqnbr;
		}

	}
