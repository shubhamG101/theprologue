package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "nextPage","orders" })
public class ResponseObj {
		@JsonProperty("nextPage") 
		private JSONObject nextPage;
		@JsonProperty("orders") 
		private List<WitronOrders> orders;
		
		public JSONObject getNextPage() {
			return nextPage;
		}
		public void setNextPage(JSONObject nextPage) {
			this.nextPage = nextPage;
		}
		public List<WitronOrders> getOrders() {
			return orders;
		}
		public void setOrders(List<WitronOrders> orders) {
			this.orders = orders;
		}
		
		
		
}