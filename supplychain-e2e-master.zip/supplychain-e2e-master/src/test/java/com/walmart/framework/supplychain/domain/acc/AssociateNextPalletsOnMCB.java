package com.walmart.framework.supplychain.domain.acc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "childLabel",
    "scannedInput",
    "storeGroupName",
    "storeGroupId",
    "storeNumber"
})
public class AssociateNextPalletsOnMCB {
	
	@JsonProperty("childLabel")
    private String childLabel;
    @JsonProperty("scannedInput")
    private String scannedInput;
    @JsonProperty("storeGroupName")
    private String storeGroupName;
    @JsonProperty("storeGroupId")
    private String storeGroupId;
    @JsonProperty("storeNumber")
    private int storeNumber;
    
	public String getChildLabel() {
		return childLabel;
	}
	public void setChildLabel(String childLabel) {
		this.childLabel = childLabel;
	}
	public String getScannedInput() {
		return scannedInput;
	}
	public void setScannedInput(String scannedInput) {
		this.scannedInput = scannedInput;
	}
	public String getStoreGroupName() {
		return storeGroupName;
	}
	public void setStoreGroupName(String storeGroupName) {
		this.storeGroupName = storeGroupName;
	}
	public String getStoreGroupId() {
		return storeGroupId;
	}
	public void setStoreGroupId(String storeGroupId) {
		this.storeGroupId = storeGroupId;
	}
	public int getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(int storeNumber) {
		this.storeNumber = storeNumber;
	}

	
    
}