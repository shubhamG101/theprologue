package com.walmart.framework.supplychain.domain.acc;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.DeliveryDetail;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "locationId", "groupNbr", "lpn", "eventTs" })

public class ACLtoReceivingVerificationMsg {

	@JsonProperty("locationId")
	private String locationId;
	@JsonProperty("groupNbr")
	private String groupNbr;
	@JsonProperty("lpn")
	private String lpn;
	@JsonProperty("eventTs")
	private String eventTs;

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getGroupNbr() {
		return groupNbr;
	}

	public void setGroupNbr(String groupNbr) {
		this.groupNbr = groupNbr;
	}

	public String getLpn() {
		return lpn;
	}

	public void setLpn(String lpn) {
		this.lpn = lpn;
	}

	public String getEventTs() {
		return eventTs;
	}

	public void setEventTs(String eventTs) {
		this.eventTs = eventTs;
	}

	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("locationId", locationId)
				.append("groupNbr", groupNbr).append("lpn", lpn)
				.append("eventTs", eventTs)
				.append("additionalProperties", additionalProperties).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(locationId).append(groupNbr).append(lpn)
				.append(eventTs).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof DeliveryDetail) == false) {
			return false;
		}
		ACLtoReceivingVerificationMsg rhs = ((ACLtoReceivingVerificationMsg) other);
		return new EqualsBuilder().append(locationId, rhs.locationId)
				.append(groupNbr, rhs.groupNbr).append(lpn, rhs.lpn)
				.append(additionalProperties, rhs.additionalProperties)
				.append(eventTs, rhs.eventTs).isEquals();
	}
}
