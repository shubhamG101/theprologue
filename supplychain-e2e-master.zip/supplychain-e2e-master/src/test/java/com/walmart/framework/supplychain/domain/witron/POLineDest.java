package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "whpksellcostamt", "vnpkordqty"})
public class POLineDest {
	
		@JsonProperty("whpksellcostamt")
		private String whpksellcostamt;
		@JsonProperty("vnpkordqty")
		private String vnpkordqty;
		public String getWhpksellcostamt() {
			return whpksellcostamt;
		}
		public void setWhpksellcostamt(String whpksellcostamt) {
			this.whpksellcostamt = whpksellcostamt;
		}
		public String getVnpkordqty() {
			return vnpkordqty;
		}
		public void setVnpkordqty(String vnpkordqty) {
			this.vnpkordqty = vnpkordqty;
		}
}