package com.walmart.framework.supplychain.constants;

public class Constants {
	public static final int SUCESS_STATUS_CODE = 200;
	public static final int FALIURE_STATUS_CODE = 404;
	public static final int NO_CONTENT_STATUS_CODE = 204;
	public static final int BAD_STATUS_CODE = 400;
	public static final int CREATE_SUCESS_STATUS_CODE = 201;
	public static final int UPDATE_SUCESS_STATUS_CODE = 202;
	public static final String TRAIL_MOVE_SUCCESS = "Trailer Move created successfully.";
	public static final boolean BOOLEAN_TRUE = true;
	public static final int RETRY_EXECUTION_DELAY = 12;
	public static final int RETRY_EXECUTION_DELAY_18S = 18;
	public static final int RETRY_EXECUTION_DELAY_30S = 30;
	public static final int RETRY_EXECUTION_COUNT = 10;
	public static final int RETRY_EXECUTION_COUNT_5 = 5;
	public static final int RETRY_EXECUTION_COUNT_15 = 15;
	public static final int RETRY_EXECUTION_COUNT_40 = 40;
	public static final int RETRY_EXECUTION_DELAY_20S = 20;
	public static final String MOVE_IS_FORCED = "Move is Forced.";
	public static final String CHANNEL_DA = "CROSSU";
	public static final String CHANNEL_SSTK = "SSTK";
	public static final String TRACKPARTIAL = "[4]";
	public static final String TRACKCOMPLETE = "[5]";
	public static final String PROPERTY_FILES_LOC_PATH_KEY = "PROPERTY_FILES_LOCATION";
	public static final String SIMPLE_DATE_FORMAT="yyyy-MM-dd HH:mm:ss";
	public static final String NO_BULKPICK_RESPONSE = "[]";
	public static final String DECRYPT_SEC_TEXT="jasypt.encryptor.password";
	public static final String SEC_KEY_TEXT="secret_key";
	public static final int DPB_TRIP_REOPTMIZING=7;
	public static final int DPB_TRIP_CANCELLED=7;


}
