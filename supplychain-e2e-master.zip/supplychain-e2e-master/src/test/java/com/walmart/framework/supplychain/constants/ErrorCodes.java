package com.walmart.framework.supplychain.constants;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.framework.utilities.javautils.Assert;

public enum ErrorCodes {
	/*
	 * No need to specify the Program(MCC,ACC,..). Program should be handled in
	 * TestCaseFailure
	 * 
	 * 
	 */
	OMS_PO_DETAILS_NOT_FOUND("OMS-01", "Invalid response code from OMS/Mock Server"),
	OMS_PO_NOT_CREATED("OMS-02", "Mock PO is not created"),
	OMS_PO_NOT_SAVED("OMS-03", "Mock PO is not saved"),
	OMS_PO_ARRAY_SIZE_MORE_THAN_ITEM_ARRAY("OMS-03", "Size of PO Array is more than item array"),
	OMS_ITEM_ARRAY_DETAILS_NOT_CORRECT("OMS-04", "Qtys and chnlMthd Array size does not match with item array"),

	OW_ORDERS_NOT_AVAILABLE("OW-01", "There are no orders in OW"),
	OW_DELETION_UNSUCCESSFUL("OW-02", "Orderwell Reject orders failed "),
	OW_SOME_OR_ALL_OTN_NOT_AVAILABLE("OW-03", "Some or All The expected otns are not availaible in OW"),
	OW_OTN_NOT_FOUND("OW-04", "Order well otn search failed"),
	OW_EXTRA_ORDERS_FOUND("OW-05", "Extra orders found in Orderwell"),
	OW_UNABLE_TO_UPDATE_ORDER_STATUS("OW-06", "Unable to update order status"),
	OW_ORDER_STATUS_NOT_UPDATED("OW-06", "Order status is not updated in OW"),


	IDM_DOOR_NUMBER_NOT_UPDATED("GDM-01", "Door number is not updated in IDM"),
	IDM_DELIVERY_STATUS_NOT_UPDATED("GDM-02", "Delivery status is not updated in IDM"),
	IDM_DELIVERY_NOT_FOUND("GDM-03", "Delivery Not found"),
	IDM_DELIVERY_RECEIPT_NOT_FOUND("GDM-04", "Delivery Receipt Not found"),
	IDM_RECEIPT_QTY_NOT_MATCHING("GDM-05",
			"The quantity received and that is present in IDM receipts  are not matching"),
	IDM_OVG_FLAG_NOT_FOUND("GDM-06", "Overage flag not available in delivery document"),
	IDM_DELIVERY_DOCUMENTS_EMPTY("GDM-07", "Delivery documents is empty"),
	IDM_DELIVERY_PO_COUNT_MISMATCH("GDM-08", "Number of POs present in delivery is not as expected"),
	IDM_OVG_QTY_NOT_MATCHING("GDM-09", "The Overage quantity IDM delivery documents is not matching"),
	IDM_DELIVERY_SHORTAGE_MISMATCH("GDM-10", "Delivery Receipt shortage validation failed"),
	IDM_DELIVERY_ISCONVEYABLE_FIELD_MISMATCH("GDM-11", "isConveyable field is not matching in Delivery doument lines"),
	IDM_DELIVERY_DAMAGE_MISMATCH("GDM-33", "Delivery Receipt damage validation failed"),
	IDM_RECEIVED_QTY_NOT_MATCHING("GDM-36", "The quantity received and that is present in OSDR API are not matching"),
	IDM_VENDOR_UPC_NOT_UPDATED("GDM-11", "UPC update failed in GDM"),
	IDM_RDC_DELIVERY_NOT_FOUND("GDM-12", "Delivery Not found"),
	IDM_RDC_DELIVERY_STATUS_NOT_UPDATED("GDM-13", "Delivery status is not updated in IDM"),
	IDM_RDC_DELIVERY_CONTAINERS_NOT_MATCHED("GDM-14",
			"The containers present in RDC delivery and that loaded in Outbound are not matching"),
	IDM_POST_SHIPMENT_FAILED("GDM-15", "IDM- Unable to post shipment details"),
	IDM_DELIVERY_DETAILS_ITEM_ATTRIBUTES_MISMATCH("GDM-16", "Item attributes in MDM and GDM are not matching"),
	IDM_PO_COUNT_MISMATCH("GDM-17", "PO count between tesdata and GDM UI is not matching"),
	IDM_PO_LINE_COUNT_MISMATCH("GDM-18", "PO line count between tesdata and GDM UI is not matching"),
	IDM_FBQ_NOT_UPDATED("GDM-19", "Updated FBQ qty are not reflecting on the GDM UI"),

	IDM_FBQ_QTY_MISMATCH("GDM-20", "FBQ qty in not matching"),
	IDM_POTYPE_MISMATCH("GDM-21","Mismatch in POtype"),
	IDM_GATE_IN_FAILED("GDM-22","Error while performing Gate In via GDM"),
	IDM_DOOR_ASSIGN_UPDATE_ERROR("GDM-23","Error while assigning a door to the delivery from GDM"),
	IDM_CRO_UPDATE_ERROR("GDM-24","Error while updating the variable weight and FBQ in GDM"),
	IDM_VARIABLE_QTY_MISMATCH("GDM-25", "variable weight averaging in not matching"),
	IDM_NO_VARIABLE_ITEM_FOUND("GDM-26", "variable weight item is missing"),
	IDM_REJECT_STATUS_MISMATCH("GDM-27", "Po line status is not rejected"),
	IDM_REJECT_POLINE_ERROR("GDM-28","Errorrejecting POLine in GDM"),
	GDM_ITEM_ATTRIBURTE("GDM-29", "GDM Item attribute mismatch"),
	GDM_FBQ_QTY_NOT_MATCHING("GDM-30",
			"FBQ quantitypresent in IDM receipts are not matching"),
	GDM_SHORT_QTY_NOT_MATCHING("GDM-30",
			"Short quantitypresent in IDM receipts are not matching"),
	GDM_REJECT_QTY_NOT_MATCHING("GDM-30",
			"Reject quantitypresent in IDM receipts are not matching"),
	GDM_DAMAGE_QTY_NOT_MATCHING("GDM-30",
			"Damage quantitypresent in IDM receipts are not matching"),
	IDM_PALLETCOUNT_MISMATCH("GDM-31","Mismatch in Pallet count"),
	IDM_LIMITED_QTY_LAST_VALIDATION_DATE_CHANGE_FAILED("GDM-32","Unable to change Limited qty Last Validation Date"),
	IDM_DELIVERY_OVERAGE_MISMATCH("GDM-34", "Delivery Receipt overage validation failed"),
	IDM_Lithium_ION_LAST_VALIDATION_DATE_CHANGE_FAILED("GDM-35","Unable to change Lithium ion Last Validation Date"),
	
	
	IDM_WTMS_LOAD_DETAILS_NOT_FOUNT("IDOC-01", "WTMS Load details not found for DSDC load"),
	MOVE_STATUS_NOT_UPDATED("MOVE-01", "MOVE status is not updated"),

	OP_OW_ORDER_DOWNLOAD_FAILED("OP-01", "OP is not able to download Orders from Order Well"),
	OP_COUNT_MISMATCH_IN_OM("OP-02", "The expected number of OTN'S is not present in the Order Services response"),
	OP_OA_ORDER_QUANITY_MISMATCH("OP-03", "OA- Order quanity mismatch in Order Allocation response"),
	OP_INVALID_RESPONSE_FOR_PICK("OP-04", "Getting Invalid response for allocation order service pick"),
	OP_DELIVERY_NOT_FINALIZED("OP-05", "Delivery is not finalized in OP", Priority.P3),
	OP_DEST_FINAL_DEST_SAME("OP-06", "RDC and Store Destination numbers are same in OP"),
	OP_OM_PO_DELIVEYR_ENTRY_CHECK("OP-07","PO-Delivery entry not found"),
	OP_OM_PICK_PO_NBR_NOT_FOUND("OP-08","OM- pickPoNbr key not found in response"),
	OP_OM_PICK_PO_NBR_MISMATCH("OP-09","OM- pickPoNbr in the response is not matching"),
	OP_OA_ALLOCATION_SERVICE_ERROR("OP-10","OA- Invalid response code from allocation service"),
	OP_ORDER_REFRESH_ERROR("OP-11","OA- Invalid response code from order refresh service"),
	OP_OW_ORDER_OTN_MISMATCH("OP-12", "Order not downloaded after re-fresh"),
	OP_OM_ORDER_STATUS_CODE_MISMATCH("OP-13","OM - Mismatch in order status code"),
	OP_OA_ALLOC_ORDER_STATUS_CODE_MISMATCH("OP-14","OA - Mismatch in order alloc status code"),

	OP_RDC_FULFILLED_CONTAINER_COUNT_MISMATCH("OP-01",
			"There is a difference between the number of loaded containers and the actual FQ in the DB"),
	
	
	OT_OPEN_QUANTITY_MISMATCH("OT-01","Mismatch in Open quantity in OT"),
	OT_FULFILLED_QUANTITY_MISMATCH("OT-02","Mismatch in Fulfilled quantity in OT"),
	OT_LOADED_QUANTITY_MISMATCH("OT-03","Mismatch in Loaded quantity in OT"),
	OT_SHIPPED_QUANTITY_MISMATCH("OT-04","Mismatch in Shipped quantity in OT"),
	OT_DAMAGED_QUANTITY_MISMATCH("OT-05","Mismatch in Damaged quantity in OT"),
	OT_ORDER_NOT_FINALISED("OT-06","Order is not finalised"),
	OT_DB_ORDERID_RECORD_COUNT_MISMATCH("OT-07","Mismatch in number of order records from OT DB"),
	OT_ORDER_STATUS_MISMATCH("OT-08","Mismatch in order status"),
	OT_ORDER_FNL_INDICATOR_MISMATCH("OT-09","Mismatch in finalized indicator"),
	OT_ORDER_FINALISATION_IND_MISMATCH("OT-10","Mismatch in order finalisation indicatior"),

	RECEIVING_NO_ALLOCATION("REC-01", "Receiving: No Allocation found for the sanned UPC"),
	RECEIVING_ITEM_NOT_FOUND("REC-02", "Receiving: No item found for the scanned UPC"),
	RECEIVING_SOMETHING_WENT_WRONG_SCAN_UPC("REC-03", "Receiving: Something went wrong while scaning UPC "),
	RECEIVING_FINALIZE_DELIVERY_FAILED("REC-04", "Receiving: Delivery Finalization is failed"),
	RECEIVING_NO_DELIVERY_FOUND("REC-05", "Receiving: No Delivery Found for the given door"),
	RECEIVING_MULTIPLE_DELIVERIES_FOUND("REC-06", "Receiving: Multiple Deliveries Found for the given door"),
	RECEIVING_TRAILER_NUM_VALIDATION_FAILED("REC-07", "Receiving: Mismatch in inbound trailer number"),
	RECEIVING_DELIVERY_NUM_VALIDATION_FAILED("REC-08", "Receiving: Mismatch in inbound delivery number"),
	RECEIVING_SOMETHING_WENT_WRONG_SCAN_DOOR("REC-09", "Receiving: Something went wrong while scanning the door"),
	RECEIVING_VTR_STATUS_MISMATCH("REC-10", "Receiving: Mismatch in VTRed Container status"),
	RECEIVING_VTR_NEGATIVE_ENTRY_VALIDATION("REC-11", "Receiving: Failed to validate -ve entry for VTRed container"),
	RECEIVING_VTR_NO_ALLOCATION("REC-12",
			"Receiving: No Allocation found for the sanned UPC while re-receiving for VTR"),
	RECEIVING_VTR_ITEM_NOT_FOUND("REC-13", "Receiving: No item found for the scanned UPC while re-receiving for VTR"),
	RECEIVING_VTR_SOMETHING_WENT_WRONG_SCAN_UPC("REC-14",
			"Receiving: Something went wrong while scaning UPC while re-receiving for VTR"),
	RECEIVING_UI_NOT_ACCESSIBLE("REC-15", "Receiving web UI is not accesible"),
	RECEIVING_ACC_DA_FLOW_PAGE_NOT_SHOWN("REC-16", "Receiving: Place on conveyor text not shown on scanning the item"),
	RECEIVING_EXCEPTION_LABELS("REC-17", "Receiving: Exception labels generation failed"),
	RECEIVING_VTR_VALIDATION("REC-18", "VTR the container successfully done"),
	RECEIVING_TEMP_TI_HI_VALIDATION("REC-19", "Ti HI Updated successfull"),
	RECEIVING_ACL_LABEL_DATA_NOTFOUND("REC-20", "Receiving ACL Label data not found"),
	RECEIVING_UNABLE_TO_GET_RECEIVING_INSTRUCTION("REC-21", "Unable to get receiving instruction for the Delievry"),
	RECEIVING_ATTENTION_POPUP_ERROR_MSG_NOT_FOUND("REC-22", "Attention popup error msg not found"),
	RECEIVING_SCANNNED_ITEM_UPC_NOT_MATCHING("REC-23", "Receiving Item Upc on Hazrat popup is not matching with scanned item upc"),
	RECEIVING_FREIGHT_POPUP_NOT_FOUND("REC-24","Freight is not conveyable popup not found"),
	RECEIVING_SCANNED_CROSSU_ITEM_MESSAGE_NOT_FOUND("REC-25","CROSSU Item scanned message not found"),
	RECEIVING_LITHIUM_ION_ATTENTION_POPUP_MSG_NOT_FOUND("REC-26","Lithium Ion Attention popup msg not found"),
	RECEIVING_LIMITED_QTY_ATTENTION_POPUP_MSG_NOT_FOUND("REC-27","Limited Qty Attention popup msg not found"),
	RECEIVING_ADD_TO_FLOOR_LINE_PALLET_MSG_NOT_FOUND("REC-28","'Add to floor line pallet' Message is not displayed"),
	RECEIVING_CHNLMTHD_TEXT_NOT_DISPLAYED_CORRECTLY("REC-28","Channel method on top section is not displayed correctly"),

	LOCATION_UNABLE_TO_FETCH_MAPPED_FLOOR_LINE("Loc-01", "Unable to get mapped floor line for the Door"),

	INVENTORY_INVALID_CONTAINER_RESPONSE("INVENTORY-01", "Inventory Container not present or invalid response"),
	PO_LINE_ADD_RESPONSE("IDM_PO_LINE_ADD-01", "po line add failed"),
	PO_LINE_ADD_FAILED("IDM_PO_LINE_ADD-02", "po line did not get attach to Delivery"),
	PO_LINE_UPDATE_FAILED("IDM_PO_LINE_ADD-03", "po line update failed"),

	INVENTORY_CONTAINER_VALIDATION("INVENTORY-02", "Inventory container validation is failed"),
	INVENTORY_CONTAINER_VALIDATION_FOR_LOADED_STATUS("INVENTORY-03",
			"Inventory container validation is failed after loading"),
	INVENTORY_CONTAINER_VALIDATION_AFTER_VTR("INVENTORY-04", "Inventory container detail is present after VTR"),
	INVENTORY_INVALID_CONTAINER_STATUS("INVENTORY-05", "Inventory Container status not correct"),
	INVENTORY_QTY_AFTER_VTR("INVENTORY-06", "VTR qty mismatch"),
	INVENTORY_CONTAINER_DELETED_AFTER_VTR("INVENTORY-07", "VTR CONTAINER DELETION FAILED FROM INVENTORY"),
	INVENTORY_CONTAINER_DELETED_AFTER_DAMAGE("INVENTORY-08", "DAMAGE CONTAINER DELETION FAILED FROM INVENTORY"),
	INVENTORY_QTY_AFTER_DAMAGE("INVENTORY-09", "DAMAGE qty mismatch"),
	INVENTORY_SCAN_CONTAINER_FAILED("INVENTORY-10", "Error while scanning Container"),
	INVENTORY_UNABLE_SUBMIT_VTR("INVENTORY-11", "UNABLE TO SUBMIT VTR"),
	INVENTORY_UNABLE_SUBMIT_DAMAGE("INVENTORY-12", "UNABLE TO SUBMIT DAMAGE"),
	INVENTORY_STATUS_AFTER_GATEOUT("INVENTORY-13", "Container Status is not IN_TRANSIT after gateout"),
	INVENTORY_PROBLEM_CNTR_CONTAINER_RESPONSE("INVENTORY-14",
			"Problem container is still present after Problem receiving"),
	INVENTORY_DAMAGE_POST_LOADED("INVENTORY-15", "LOADED CONTAINER DAMAGED "),
	INVENTORY_SUBMIT_VTR_FINALIZED_CONTAINER("INVENTORY-16", "ABLE TO SUBMIT VTR FOR FINALIZED CONTAINER"),
	INVENTORY_MCB_CONTAINER_VALIDATION("INVENTORY-17", "Failed to validate inventory for MCB container"),
	INVENTORY_CONTAINER_DELETED_RTC("INVENTORY-18", "CONTAINER DELETION FAILED FROM INVENTORY FOR RTC"),
	INVENTORY_INVALID_HOLD_STATUS("INVENTORY-19", "Inventory Container status is not ONHOLD"),
	INVENTORY_MCB_CHILD_CONTAINER_NOT_FOUND("INVENTORY-20", "MCB Child container not found"),
	INVENTORY_MCB_CONTAINER_NOT_FOUND("INVENTORY-21", "MCB container not found"),
	INVENTORY_MCB_MAPPING_IN_CHILD_CONTAINER_VALIDATION("INVENTORY-22", "Wrong MCB mapping in the child container"),
	INVENTORY_CHILD_CONTAINER_NOT_MAPPED_IN_PARENT_MCB("INVENTORY-23", "Child container not mapped in the parent MCB"),
	INVENTORY_MCB_INVALID_CONTAINER_STATUS("INVENTORY-24", "Invalid MCB container status"),
	INVENTORY_MCB_CONTAINER_DELETED("INVENTORY-25", "MCB container not deleted"),
	INVENTORY_CONTAINER_DELETED_VTR("INVENTORY-26", "CONTAINER DELETION FAILED FROM INVENTORY FOR VTR"),
	INVENTORY_INVALID_POCON_RESPONSE("INVENTORY-27", "Mismatch in inventory response data for POCON container"),
	INVENTORY_ZERO_WT_CONTAINER("INVENTORY-28", "Inventory-netWeight can not be zero"),
	INVENTORY_INVALID_DSDC_RESPONSE("INVENTORY-29", "Mismatch in inventory response data for DSDC container"),

	

	MCB_SCAN_FAILED("MCB-01", "First scan for MCB pallet failed"),
	MCB_CREATION_FAILED("MCB-02", "Unable to create MCB pallet"),
	MCB_ASSOCIATE_CHILD_TO_PARENT_MCB_FAILED("MCB-03", "Unable to add child to parent MCB"),
	COMPLETE_MCB_PALLET_FAILED("MCB-04", "Unable to complete MCB pallet"),
	MCB_DISSOCIATION_OF_CHILD_FAILED("MCB-05", "Unable to dissociate child from MCB pallet"),

	


	OF_EMPTY_RESPONSE("OF-01", "Order Fulfillment response is empty, Validation failed"),
	OF_FULFILLMENT_STATUS_NOT_UPDATED("OF-02", "Container fulfillment status is not getting updated"),
	OF_FULFILLMENT_STATUS_NOT_UPDATED_AFTER_VTR("OF-03",
			"Container fulfillment status is not getting updated after VTR"),
	OF_FULFILLMENT_QTY_NOT_MATCH("OF-04", "Container fulfillment Qty does not match with Received Qty"),
	OF_FULFILLMENT_BLOCKED_QTY_NOT_MATCH_ATLAS("OF-05", "Fulfilled and Blocked Qty are not same"),
	OF_FULFILLMENT_RCVED_QTY_NOT_MATCH_ATLAS("OF-06", "Fulfilled and Received Qty are not same"),
	OF_DELIVERY_NOT_FINALIZED("OF-07", "Delivery is not finalized in OF"),
	OF_INDUCT_LABEL_NOT_GENERATED("OF-08", "Induct label is not generated"),
	OF_INDUCT_LABEL_STATUS_NOT_GETTING_UPDATED("OF-09", "Induct label status is not getting updated"),
	OF_SHORTAGE_QTY_INCORRECT("OF-10", "Shortage quantity is not updated correctly in OF"),
	OF_PBYL_UNABLE_TO_SCAN_INDUCT_LPN("OF-11", "Something went wrong while scanning induct lpn"),
	OF_PBYL_UNABLE_TO_START_TRIP("OF-12", "Unable to Start the PBYL Trip"),
	OF_PBYL_UNABLE_TO_SCAN_SLOTS("OF-13", "Unable to Scan the slots in  PBYL Trip"),
	OF_PBYL_UNABLE_TO_COMPLETE_TRIP("OF-14", "Unable to Complete the PBYL Trip"),
	OF_PBYL_UNABLE_TO_SELECT_PRINTER_IN_PBYL("OF-15", "Unable to Select the Printer For PBYL Trip"),
	OF_PBYL_UNABLE_TO_CLOSE_CONTAINER("OF-16", "Unable to Close the Container Outside PBYL Trip"),
	OF_PBYL_SLOT_NOT_CLEARED("OF-17", "Unable to start trip due to failure in clearing the slot"),
	OF_PBYL_INDUCT_PALLET_MISMATCH("OF-18", "Induct pallet count mismatch"),
	OF_PBYL_UNABLE_TO_REPORT_OVERAGE("OF-19", "Unable to Report Overage for PBYL Trip"),
	OF_PBYL_VALIDATE_OVERAGE("OF-20", "Unable to Validate Overage in PBYL Trip"),
	OF_PBYL_OVERAGE_MISMATCH("OF-20", "PBYL Trip Overage value mismatch"),
	OF_PBYL_UNABLE_TO_PAUSE_TRIP("OF-21", "Something went wrong while executing Pause/Resume"),
	OF_PBYL_UNABLE_TO_REPORT_SHORTAGE("OF-22", "Unable to Report Shortage for PBYL Trip"),
	OF_PBYL_SHORTAGE_UNIT_STATUS_NOT_UPDATED("OF-23",
			"Fulfillment unit status is not getting updated after reporting shortage"),
	OF_PBYL_UNABLE_TO_PICK_SHORTAGE_CASE("OF-24", "Something went wrong while picking shortage case"),
	OF_PBYL_UNABLE_TO_TRUE_OUT_SHORTAGE_CASE("OF-25",
			"Something went wrong while performing true out for shortage case"),
	OF_PBYL_TRUE_OUT_UNIT_STATUS_NOT_UPDATED("OF-26",
			"Fulfillment unit status is not getting updated after performing true out"),
	OF_PBYL_CHILD_CONTAINER_STATUS_NOT_UPDATED_FOR_CLOSE_CONTAINER("OF-27",
			"Child container status is not updated after closing the container during trip"),
	OF_PBYL_UNIT_STATUS_NOT_UPDATED_TO_LABEL_PRINT("OF-28",
			"Fulfillment unit status is not getting updated to LABEL_PRINTED for child case"),

	PRINTING_SELECT_PRINTER_FAILED_IN_PBYL("PRINTING-15", "Unable to Select the Printer For PBYL Trip"),

	DC_FIN_PURCHASE_VALIDATION("DCFIN-01", "DC Fin purchase data match failed"),
	DC_FIN_SALES_VALIDATION("DCFIN-02", "DC Fin sales data match failed"),
	DC_FIN_NO_DATA_FOUND("DCFIN-03", "No data found for the given query"),
	DC_FIN_PURCHASE_DAMAGE_VALIDATION_FAILED("DCFIN-04", "DC Fin Purchase validation is failed for damaged container"),
	DC_FIN_GDIS_VALIDATION_FAILED("DCFIN-05", "DC Fin GDIS posting validation failed"),
	DC_FIN_OSDR_INCORRECT("DCFIN-06", "DC Fin OSDR posting validation failed"),

	LOADING_TMSID_NOT_POPULATED("LOADING-01", "Loading-TMSLoad id is not getting populated"),
	LOADING_LOAD_STATUS_MISMATCH("LOADING-02", "Loading-Load status is not updated"),
	LOADING_LOAD_STATUS_MISMATCH_AFTER_CLOSE_LOAD("LOADING-03", "Loading-Load status is not changed after close Load"),
	LOADING_CONTAINER_COUNT_MISMATCH("LOADING-04",
			"Loading- Count mismatch in Container visibility for the given load "),
	LOADING_STATUS_MISMATCH("LOADING-05", "Loading- Load Status is not changed as expected "),
	LOADING_INVALID_RESPONSE_CODE("LOADING-06", "Loading- Status response is not returned as 200 "),
	LOADING_DOOR_SCAN_FAILED("LOADING-07", "Loading- Door scan is failed"),
	LOADING_INVALID_CONTAINER_COUNT("LOADING-08", "Loading- Count of contaienrs loaded is not matching "),
	LOADING_NO_CHILD_CONTAINERS("LOADING-09", "No DA-CON cases recieved for the DA PO"),
	LOADING_CNTR_SCAN_FAILED("LOADING-10", "Loading- cntr scan is failed"),
	LOADING_UNABLE_TO_LOGIN("LOADING-11", "Unable to login to Loading UI"),
	UNLOAD_CNTRS("LOADING-12", "Unable to unload the containers"),
	LOADING_MOBILE_UI_NOT_AVAILABLE("LOADING-13", "Unable to load containers, Looks like Loading mobile UI is down"),
	LOADING_UNABLE_TO_FETCH_LOAD_DETAILS("LOADING-14", "Unable to fetch load details"),
	LOADING_MISMATCH_IN_DOOR("LOADING-15", "Mismatch in Door for the load"),
	LOADING_MISMATCH_IN_LOADID("LOADING-16", "Mismatch in load number on the UI"),
	LOADING_TMSID_NOT_FOUND("LOADING-17", "TMS ID not generated for the load"),
	LOADING_MISMATCH_IN_TRAILER_NUMBER("LOADING-18", "Mismatch in Trailer number fo the load"),
	LOADING_MISMATCH_IN_LOAD_STATUS("LOADING-19", "Mismatch in load status"),
	LOADING_UNABLE_TO_POST_DOOR_TRAILER_MAPP("LOADING-20", "Unable to post DOor Trailer mapping through loading API"),

	SORTER_LPN_COUNT_MISMATCH("SORTER-01",
			"SORTER - LPN to RDC mapping ::  lpn count mismatch between Receive Instruction LPNList(expected) and Sorter LpnSearchResponse(actual) : "),
	SORTER_LPN_MISMATCH("SORTER-02",
			"SORTER - LPN to RDC mapping  ::  Receive Instruction LPN doesnt match with LPN of Sorter LpnSearchResponse"),
	SORTER_GET_LPN_RESPONSE("SORTER-04",
			"SORTER - GET SORTER LPN RESPONSE  ::  Failed to get Sorter respose for the containers"),
	SORTER_LPN_COUNT_MISMATCH_NORMAL_FLOW("SORTER-05", "Mismatch in LPN count for NORMAL lpn flow"),
	SORTER_LPN_COUNT_MISMATCH_NORMALLABELS_PROBLEM_NA_FLOW("SORTER-06",
			"Mismatch in Normal LPN count for PROBLEM_NA lpn flow"),
	SORTER_LPN_COUNT_MISMATCH_EXCEPTIONLABELS_PROBLEM_NA_FLOW("SORTER-07",
			"Mismatch in Exception LPN count for PROBLEM_NA lpn flow"),
	SORTER_LPN_COUNT_MISMATCH_NORMALLABELS_PROBLEM_OVG_FLOW("SORTER-08",
			"Mismatch in Normal LPN count for PROBLEM_OVG flow"),
	SORTER_LPN_COUNT_MISMATCH_EXCEPTIONLABELS_PROBLEM_OVG_FLOW("SORTER-09",
			"Mismatch in Exception LPN count for PROBLEM_OVG flow"),
	SORTER_LPN_COUNT_MISMATCH_FLIP_FLOW("SORTER-10", "Mismatch in LPN count for CHANNEL FLIP flow"),
	SORTER_GET_SORTER_BACKWARD_FLOW_RESPONSE("SORTER-11",
			"Failed to post Sorter Backward flow"),

	// SORTER_STORENBR_NOT_FOUND("SORTER-06","Overage flag not available in delivery
	// document"),

	OUTBOUND_UNABLE_TO_LOGIN("OUTBOUND-01", "Unable to login to outbound"),
	OUTBOUND_UNABLE_TO_SEARCH_FOR_LOAD("OUTBOUND-02", "Unable to find the required load in outbound"),
	OUTBOUND_LOAD_DETAILS_VALIDATION_FAILED("OUTBOUND-03", "Outbound Load details validation Failed"),
	OUTBOUND_SEAL_DETAILS_VALIDATION_FAILED("OUTBOUND-04", "Outbound Seal validation is failed"),
	OUTBOUND_DOWNLOAD_BOL_FAILED("OUTBOUND-05", "Outbound BOL download is failed"),
	OUTBOUND_BOL_BASIC_DATA_VALIDATION_FAILED("OUTBOUND-06", "Outbound BOL data validation failed"),

	SORTER_DISPOSITION_EXP_LANE_COUNT_MISMATCH("SORTER-003",
			"lane count mismatch between sorter exception Disposition message and DB : "),
	LABEL_COUNT_MISMATCH_NORMAL("ACL-001",
			"labels count mismatch between Receive Instruction and Receiving DB for normal labels: "),
	LABEL_COUNT_MISMATCH_EXCEPTION("ACL-002",
			"labels count mismatch between Receive Instruction and Receiving DB for exception labels: "),
	LABEL_COUNT_MISMATCH_OVERAGE("ACL-003",
			"labels count mismatch between Receive Instruction and  Receiving DB for overage labels: "),
	LABEL_COUNT_MISMATCH_ACL("ACL-004",
			"labels count mismatch between Receive Instruction and  ACL DB for overage labels: "),
	ACL_DOOR_MISMATCH("ACL-005", "ACL TO DOOR MAPPING IS INCORRECT: "),
	SORTER_DISPOSITION_LANE_COUNT_MISMATCH("ACL-001", "Mismatch in the lane count in the sorter DB: "),
	SORTER_DB_NOT_PURGED("SORTER-001", "Labels not purged from sorter DB: "),
	VALIDATE_DOOR_LANE_DIVERSION("SORTER-006", "Door lane mismatch after diversion event : "),
	VALIDATE_DOOR_LANE_STOP_DIVERSION("SORTER-007", "Door lane mismatch after stop diversion event : "),
	UNABLE_TO_FILEDAMAGE("DAMAGE-01", "Unable to file damage"),
	DAMAGE_CONTAINERS_COUNT_INCORRECT("DAMAGE-02", "Count of Damage containers is not correct"),
	ACL_COMPLETE_DELIVERY_ITEM_LABEL("ACL Complete-01", "Delivery is not deleted from the ITEM_LABEL table"),
	ACL_COMPLETE_DELIVERY_LABEL_GRP("ACL Complete-02", "Delivery is not deleted from the LABEL_GROUP_MAPPING table"),
	ACL_COMPLETE_DELIVERY_LABEL_DATA("ACL Complete-03",
			"Labels are not deleted in LABEL_DATA table for a given delivery"),
	ACL_REJECT_CODE("ACL Complete-04",
			"Labels are not rejected in ACL on channel flip"),
	EXCEPTION_URL_LABEL("ACL Exception-01", "Exception labels are not generated"),
	LABEL_COUNT_MISMATCH_NONCON("ACL-006", "Mismatch in the status of non conveyable labels"),
	LOADING_INVALID_CONTAINER_STATUS("LOADING-21", "Loading Container status not correct"),
	POUPDATE_INVALID_STATUS("POUPDATE-01", "Po Update Failed"),
	POUPDATE_QTY_MISMATCH("POUPDATE-02", "Po Update quantity mismatch: qty not updated in delivery"),
	OW_STATUS_INVALID("OW-04", "Invalid OW search status"),

	DOCKTAG_PALLET_NOT_CREATED("ACC DOCKTAG-01", "Dock tag pallet not created"),
	DOCKTAG_STATUS_MISMATCH_IN_RECEIVING("ACC DOCKTAG-02", "Mismatch in Docktag status in Receiving"),
	DOCKTAG_STATUS_MISMATCH_IN_INVENTORY("ACC DOCKTAG-03", "Mismatch in Docktag status in Inventory"),
	DOCKTAG_PALLET_NOT_RECEIVED("ACC DOCKTAG-04", "Unable to receive dock tag pallet"),
	DOCKTAG_NOT_DELETING_FROM_INVENTORY("ACC DOCKTAG-05", "Docktag is not deleting from Inventory"),
	DOCKTAG_NOT_DELETED_IN_INVENTORY("ACC DOCKTAG-03", "Docktag is not deleted in Inventory"),
	PBYL_DOCKTAG_NOT_CREATED("ACC DOCKTAG-07", "PBYL Dock tag not created"),

	PROBLEM_STATUS_CODE_MISMATCH("PROBLEM-01", "Problem status is not correct"),
	PROBLEM_RESOLUTION_NOT_UPDATED("PROBLEM-02", "Problem resolution is not updated"),
	PROBLEM_RESOLUTION_MISMATCH("PROBLEM-03", "Problem Resolution is not correct"),

	MDM_ITEM_DETAILS_NOT_FOUND("MDM-01", "Item details not found in Enterprise MDM"),

	WTMS_INCORRECT_REESPONSE("WTMS-01", "The response code returned is incorrect in WTMS"),
	WTMS_STO_NOT_PRESENT("WTMS-02", "STO is not present in WTMS system"),
	TMS_LOADID_MATCH_FAILED("WTMS-03", "TMS Load ID did not match in WTMS system"),
	WTMS_NO_OF_CASES_MATCH_FAILED("WTMS-04", "No of Cases did not match in WTMS system"),
	WTMS_NO_OF_PALLETS_MATCH_FAILED("WTMS-05", "No of Pallets did not match in WTMS system"),
	WTMS_WEIGHT_MATCH_FAILED("WTMS-06", "Weight did not match in WTMS system"),
	WTMS_CUBE_MATCH_FAILED("WTMS-07", "CUBE did not match in WTMS system"),

	RDC_XDOCK_MISMATCH_IN_XDOCK_DELIVERY_STATUS("RDCXDOCK-01", "Mismatch in XDOCK delivery status"),
	RDC_XDOCK_MISMATCH_IN_XDOCK_RECORD_COUNT("RDCXDOCK-02", "Mismatch in XDOCK record count"),
	RDC_S2S_OFFLINE_FULLFILMENT_COUNT("RDCS2S-01", "Mismatch in Offline Fullfiment record count"),
	RDC_S2S_OFFLINE_DELILVERY_DB_DELIVERY_STATUS_MISMATCH("RDCS2S-02",
			"Mismatch in delivery status in Offline delivery DB"),
	RDC_S2S_CONTAINER_COUNT_MISMATCH("RDCS2S-03",
			"Container count mismatch between ecomContainers and Containers in ASN"),
	RDC_S2S_DELIVERY_CONTAINERS_NOT_MATCHED("RDCS2S-03",
			"The containers present in RDC S2S delivery and ecomfile are not matching"),
	S2S_RDC_ECOM_FILE_TRANSFER_FAILED("RDCS2S-05", "Fail to tranfer Ecom file to Linux location"),

	IDOC_UNABLE_TO_FETCH_ASN_FROM_IDOC("IDOC-01", "Unable to fetch ASN from IDOC"),
	IDOC_CONTAINER_COUNT_MISMATCH("IDOC-02", "Container count mismatch between LoadedContainer and Containers in ASN"),
	IDOC_LOADED_NOT_FOUND_IN_IDOC("IDOC-03", "Loaded container not found in ASN of IDOC"),
	IDOC_INVOICE_NUMBER_VALIDATION_FAILED("IDOC-04", "ASN Invoice number is not unique"),
	IDOC_ABLE_TO_FETCH_ASN_FROM_IDOC_FOR_PURE_POCON_OR_DSDC("IDOC-05", "Able to fetch ASN for pure POCON/DSDC from IDOC"),
	PROBLEM_INVALID_STATUS("PROBLEM-01", "Problem Search status is  not correct"),
	PROBLEM_RESOLVE_STATUS("PROBLEM-02", "Problem Resolve status is not correct"),
	LABEL_ERROR_MSG("LABEL-01", "There are no conveyable items in the delivery"),
	LABEL_ERROR_MAP("LABEL-02", "Label map is null"),
	LABEL_RESPONSE_NOT_CORRECT("LABEL-03", "Label response is not correct"),
	LABEL_CLIENT_ID_MISMATCH("LABEL-04", "Label client id is not correct"),
	CANCELLED_LABEL_STATUS_MISMATCH("LABEL-05", "Mismatch in Cancelled pallet status"),
	PROBLEM_RECEIVE_CNTRS("PROBLEMRECEIVING-01", "Mis match in the count of received problem cases "),
	RECEIVING_PROBLEM_LOCATION_MISMATCH("PROBLEM-03", "Location count mismatch in Receiving container"),
	INVENTORY_LOCATION_MISMATCH("INVENTORY-14", "Location is Incorrect in Inventory response"),
	DOORS_STATUS_MISMATCH("Doors-01", "Mis match in the get doors status"),

	THOR_CASE_UPC_MISMATCH("THOR-01", "Mismatch in caseUPC"),
	THOR_VENDOR_NAME_MISMATCH("THOR-02", "Mismatch in Vendor name"),
	THOR_PO_SEARCH("Thor-PO-search", "Not able to find the Thor PO"),
	THOR_PO_DETAILS("Thor-PO-Details", "Not able to find the Thor PO Details"),
	THOR_ITEMS_MIS_MATCH("Thor-items-mismatch", "There is the item count mismatch between oms PO and Thor Po"),
	THOR_QUANTITY_MIS_MATCH("Thor-items-quantity-mismatch",
			"There is the item quantity mismatch between oms PO and Thor Po"),
	THOR_STATUS_MIS_MATCH("Thor-status-mismatch", "There is mismatch in Thor status"),
	THOR_PRICE_MIS_MATCH("Thor-items-price-mismatch", "There is the item price mismatch between oms PO and Thor Po"),
	THOR_UNITS_MIS_MATCH("Thor-items-price-mismatch",
			"There is the item units per case mismatch between oms PO and Thor Po"),
	THOR_SKU_NULL("Thor-sku-null", "Thor Sku is null"), THOR_CREATE_TOTE("create tote", "Failed to create Thor Tote"),
	THOR_RECEIVING("Receive Thor SKU", "Failed to receive Thor SKU"),
	THOR_WAC_RECEIVING("validating WAC Receiving:", "Failed to validate WAC for Receiving"),
	THOR_BOH_RECEIVING("validating BOH Receiving:", "Failed to validate BOH for Receiving"),
	THOR_WAC_ADJUSTMENT("validating WAC adjustment:", "Failed to validate WAC for adjustment"),
	THOR_SALES("Thor Sales", "Failed to publish Sales"),
	THOR_WAC_SALES("validating WAC sales:", "Failed to validate WAC for Sales"),
	THOR_STATUS_CHANGE("Thor status change", "Failed to change thor status"),
	THOR_OSDR_RECEIVED_QTY_MISMATCH("THOR-03", "Mismatch in OSDR Received quantity"),
	THOR_OSDR_DAMAGE_QTY_MISMATCH("THOR-04", "Mismatch in OSDR Damage quantity"),
	THOR_OSDR_FBQ_QTY_MISMATCH("THOR-05", "Mismatch in OSDR FBQ quantity"),
	THOR_CANCEL_STATUS("Thor status cancel", "Unable to Cancel the Thor PO Line"),
	LOADING_CNTR_SEARCH("validating Loading status:", "Failed to validate Loading Status"),
	BAJA_LOADUNITS_NOT_CREATED("BAJA-01", "LOAD UNITS NOT CREATED IN INVENTORY"),
	LOADUNITS_NOT_CREATED("BAJA-01", "LOAD UNITS NOT CREATED IN INVENTORY"),
	BAJA_ORDER_ENRICH("Validating order enrichment:", "Failed to enrich the orders"),
	BAJA_ORDER_RELEASE("Validating Orders are released:", "Failed to release the orders"),
	BAJA_ORDER_MODIFY_ENRICHMENT("Validating enriched orders are modified:", "Failed to modify the enriched orders"),
	BAJA_EXTRA_ORDER_ENRICH("Extra order enriched:", "Additional orders got enriched please check data setup"),
	BAJA_WRONG_ORDER_ENRICH("Correct order not enriched:", "Order created as part of setup is not enriched"),
	BAJA_NEW_EXCEPTION_RAISED("Exception is not raised:", "Failed to raise a new exception"),
	BAJA_BULK_PICK_FAIL("Bulk pick failed to create in OF:", "Bulk pick creation failed in OF"),
	BAJA_TRUCK_DOWN_FAIL("OF fail to send truck down to loading:", "Truck file not send to loading by OF"),
	BAJA_LOADID_FAIL("Load Id generation fail:", "Load id failed to generate after routing upload"),
	OF_MESSAGEIDID_FAIL("Message Id generation fail in OF:", "Message Id generation fail in OF"),

	FIXIT_DC_NEW_SWIMLANE_TICKET_NOT_DISPLAYED("FIXIT-01", "Problem ticket not displayed"),
	FIXIT_DC_PROBLEM_TICKET_STATUS_MISMATCH("FIXIT-02", "Problem ticket status not matching"),
	FIXIT_DC_PROBLEM_TICKET_GROUP_MISMATCH("FIXIT-03", "Problem ticket group not matching"),
	FIXIT_DC_PROBLEM_TICKET_HISTORY_DATA_NOT_DISPLAYED("FIXIT-04", "History data not displayed"),
	FIXIT_DELIVERY_NUMBER_MISMATCH("FIXIT-05", "Delivery number not matching"),
	FIXIT_PROBLEM_TICKET_NUMBER_MISMATCH("FIXIT-06", "Ticket number not matching"),

	FIXIT_PROBLEM_TICKET_CONTAINER_ID_NOT_FOUND("FIXIT-07", "Problem container ID not found"),
	FIXIT_TICKET_ASSIGNED_GROUP_FIELD_MISMATCH("FIXIT-08", "Assigned Groupd field value mismatch"),
	FIXIT_TICKET_CREATEDBY_FIELD_MISMATCH("FIXIT-09", "CreatedBy field value mismatch"),
	FIXIT_TICKET_STATUS_MISMATCH("FIXIT-10", "Problem ticket status is not 'CANCELED' "),
	FIXIT_PROBLEM_RESOLUTION_NAME_MISMATCH("FIXIT-11", "Problem resolution name mismatch"),
	FIXIT_PROBLEM_NAME_MISMATCH("FIXIT-11", "Problem name mismatch"),
	FIXIT_PROBLEM_CASES_MISMATCH("FIXIT-12", "Problem cases count mismatch"),
	FIXIT_PROBLEM_PO_NUMBER_MISMATCH("FIXIT-13", "Problem PO number mismatch"),
	FIXIT_PROBLEM_CONTAINER_ID_MISMATCH("FIXIT-14", "Problem container ID number mismatch"),
	FIXIT_PROBLEM_METRICS_DASHBOARD_PRESENCE_MISMATCH("FIXIT-15", "Metrics Dashboard presence mismatch"),
	FIXIT_REPORT_EXPORT_FAILED("FIXIT-16","Unable to export data"),
	FIXIT_MOBILE_APP_SWITCH_FAILED("FIXIT-17","Unable to switch from Fixit App to NG Receiving App"),
    FIXIT_TICKET_EDIT_FAILED("FIXIT-18","Problem ticket edit is unsuccessful"),
	FIXIT_DAMAGE_TICKET_FOUND("FIXIT-19", "Damage Ticket is visible in UI"),
	FIXIT_CREATE_ALLOCATION_FAILED("FIXIT-20", "Create allocation failed"),
	FIXIT_SEARCH_RESULT_COUNT("FIXIT-21", "Search result count mismatch"),

	//Witron OP Errorcodes
	WITRON_ORDERS_MISMATCH("WITRON-OP-01", "Mismatch in the created orders"),
	WITRON_WAVE_PLANNING_LOGIN_FAILED("WITRON-OP-02","Unable to login to Wave planning UI"),
	WITRON_BATCH_CREATE_FAILED("WITRON-OP-03","Unable to create Batch in Wave planning UI"),
	WITRON_BATCH_NOT_LISTED("WITRON-OP-04","Created Batch not listed in Batch Screen"),
	WITRON_SCHEDULE_CREATE_FAILED("WITRON-OP-05","Unable to create Schedule in Wave planning UI"),
	WITRON_RELEASE_FAILED("WITRON-OP-06","cycle wave release failed"),
	WITRON_ORDERS_MISMATCH_IN_OM("WITRON-OP-07", "Mismatch in the downloaded orders in whse_order table"),
	WITRON_ORDERS_MISMATCH_IN_WAVE("WITRON-OP-08", "Mismatch in the downloaded orders in enrich_order table"),
	WITRON_ORDERS_MISMATCH_IN_OA("WITRON-OP-09", "Mismatch in the downloaded orders in allo_order_obd table"),
	WITRON_ORDERS_MISMATCH_FULFILLED_QTY("WITRON-OP-10", "Mismatch in the downloaded order quantity and fulfilled qty"),
	WITRON_ORDERS_MISMATCH_CNTRS_PICK_QTY("WITRON-OP-11", "Mismatch in the downloaded order quantity and pick qty"),
	WITRON_ORDERS_MISMATCH_ORDERS_WAVE_PLAN("WITRON-OP-12", "Mismatch in the downloaded orders in cycle wave UI"),
	WITRON_ORDERS_MISMATCH_SCHEDULE("WITRON-OP-13", "One of the commodity is not scheduled"),
	WITRON_ORDERS_MISMATCH_PICK_COUNT("WITRON-OP-14", "Mismatch in expected pick count and actual pick count generated by allocation algorithm"),
	WITRON_ORDERS_MISMATCH_PICK_QTY("WITRON-OP-15", "Mismatch in expected pick qty and actual pick qty generated by allocation algorithm"),
	WITRON_ORDERS_MISMATCH_PICK_ITEM("WITRON-OP-16", "Mismatch in expected pick item and actual pick item generated by allocation algorithm"),
	WITRON_ORDERS_MISMATCH_PICK_ROTATE_DATE("WITRON-OP-17", "Mismatch in expected pick rotate date and actual pick rotate date generated by allocation algorithm"),
	WITRON_ORDERS_MISMATCH_OUT_QTY("WITRON-OP-18", "Mismatch in expected out qty and actual out qty generated by allocation algorithm"),
	WITRON_MISMATCH_OP_PROCESS_STATUS("WITRON-OP-19","Failed to validate process status in OP"),
	WITRON_CNTRS_MISMATCH("WITRON-OP-20","Mismatch in Container between same pallet"),
	WITRON_CNTRS_COUNT_MISMATCH("WITRON-OP-21","Mismatch in Container count for a pallet"),
	WITRON_CNTRS_COUNT_RELEASE_MISMATCH("WITRON-OP-22","Mismatch in Container count for a release"),
	WITRON_CNTRS_COUNT_MISMATCH_FULL("WITRON-OP-23","Mismatch in Container count for Full Pallets"),
	WITRON_CNTRS_COUNT_MISMATCH_MIX("WITRON-OP-24","Mismatch in Container count for mixed Pallets"),
	WITRON_OP_REVERSE_FAILED("WITRON-OP-25","Failed to reverse in OP"),
	WITRON_ORDER_NOT_CANCELLED("WITRON-OP-26", "Witron Orders not Deleted"),
	WITRON_ORDER_COUNT_MISMATCH_FOR_MODIFY_AND_RELEASE_PAGES("WITRON-OP-27", "Witron Orders Count mismatch after modifying cycleWave Details"),
	WITRON_ORDER_BATCH_INACTIVATE_FAILED("WITRON-OP-28", "Witron Batch Inactivation failed"),
	WITRON_ORDER_BATCH_ACTIVATE_FAILED("WITRON-OP-29", "Witron Batch activation failed"),
	WITRON_ORDER_COUNT_MISMATCH("WITRON-OP-30", "Witron Order Count Mismatch"),
	
	//Inventory errorcodes
	WITRON_INVENTORY_BOH_RESPONSE("WITRON-INVENTORY-01", "Inventory BOH not present or invalid response"),
	WITRON_INVENTORY_TOTAL_BOH_QTY("WITRON-INVENTORY-02", "Total BOH qty Mismatch for Item"),
	WITRON_INVENTORY_TOTAL_BOH_QTY_BY_DATE("WITRON-INVENTORY-03", "Total BOH qty Mismatch for Item And rotate date"),
	WITRON_GET_BOH_FAILED("WITRON-INVENTORY-04", "Unable to Fetch BOH from inventory api"),
	WITRON_POPULATE_BOH_FAILED("WITRON-INVENTORY-05","Failed to populate BOH"),
	WITRON_BOH_MISMATCH("WITRON-INVENTORY-06","Mismatch in Balance on Hand after Allocation Algorithm"),
	WITRON_GET_CNTR_FAILED("WITRON-INVENTORY-07","Unable to fetch the Inventory container"),
	WITRON_MISMATCH_INV_CNTR_ITEMS_COUNT("WITRON-INVENTORY-08","Mismatch in the items count in the inventory response"),
	WITRON_MISMATCH_INV_CNTR_QTY("WITRON-INVENTORY-09","Mismatch in the item qty in the inventory response"),
	WITRON_INVENTORY_ALLOC_FAILED("WITRON-INVENTORY-10","Failed to validate inventory allocation after OHC OLC"),
	WITRON_SSC_BOH_MISMATCH("WITRON-INVENTORY-11","Mismatch in Balance on Hand after SSC"),
	WITRON_SQC_BOH_MISMATCH("WITRON-INVENTORY-12","Mismatch in Balance on Hand after SQC"),
	RECEIVING_APP_INVENTORY_VTR_DELETE_MISMATCH("WITRON-INVENTORY-13","Failed to delete the Inventory container after VTR"),
	WITRON_INVENTORY_CNTR_QTY_RC_MISMATCH("WITRON-INVENTORY-14","Mismatch in Inventory container quantity after receiving correction"),
	WITRON_INVENTORY_DISTRO_TURN_ADJ_FAILED("WITRON-INVENTORY-15","Failed to publish distro to turn adjustment"),
	WITRON_INVENTORY_DISTRO_TURN_BOH_FAILED("WITRON-INVENTORY-16","Mismatch in BOH after distro to turn adjustments"),
	INVENTORY_SPLIT_QTY_MATCH_FAILED("WITRON-INVENTORY-17", "Split Qty Match failed"),
	INVENTORY_SPLIT_INVENTORY_FAILED("WITON-INVENTORY-18", "Inventory failed while Split pallet"),
	WITRON_INVENTORY_ADJUSTMENT_QTY_REASON_MISMATCH("WITON-INVENTORY-19", "Mismatch of Ajustment quantity and reason"),
	WITRON_INVENTORY_STATUS_MISMATCH("WITRON-INVENTORY-20","Mismatch in status in Inventory "),
	WITRON_INVENTORY_REVERSE_FAILED("WITRON-INVENTORY-21","Failed to reverse in Inventory"),
	WITRON_INVENTORY_UI_CONTAINER_DELIVERY_NUM_MISMATCH("WITON-INVENTORY-22", "deliver number mismatch in container details"),
	WITRON_INVENTORY_UI_CONTAINER_PO_NUM_MISMATCH("WITON-INVENTORY-23", "PO number mismatch in container details"),
	WITRON_INVENTORY_UI_CONTAINER_ITEM_QUANTITY_MISMATCH("WITON-INVENTORY-24", "Item quantity mismatch in container details"),
	WITRON_INVENTORY_UI_CONTAINER_ITEM_NUM_MISMATCH("WITON-INVENTORY-25", "item number mismatch in container details"),
	WITRON_INVENTORY_UI_CONTAINER_ON_HOLD_MISMATCH("WITON-INVENTORY-26", "Container status is not updated as on hold"),
	WITRON_INVENTORY_QTC_FAILED("WITON-INVENTORY-27", "QTC Failed"),
	WITRON_INVENTORY_QTC_QTY_MATCH("WITON-INVENTORY-28", "QTC qty mismatch"),
	WITRON_INVENTORY_UI_POST_QTC_CONTAINER_STATUS_MISMATCH("WITON-INVENTORY-29", "Container status is not updated after QTC"),
	WITRON_QTC_BOH_MISMATCH("WITRON-INVENTORY-30","Mismatch in Balance on Hand after QTC"),
	WITRON_INVENTORY_ADJUSTMENT_REASON_MISMATCH("WITRON-INVENTORY-30","Mismatch in inventory adjustment reason"),
	WITRON_INVENTORY_ADJUSTMENT_QTY_MISMATCH("WITRON-INVENTORY-31","Mismatch in inventory adjustment qty"),








	
	//FM errorcodes
	WITRON_BOH_MISMATCH_PICK_COUNT_FM("WITRON-FM-01","Mismatch in picks generated by Allocation Algorithm and that persisted in FM"),
	WITRON_BOH_MISMATCH_PICK_QTY_FM("WITRON-FM-02","Mismatch in picks qty generated by Allocation Algorithm and that persisted in FM"),
	WITRON_MISMATCH_ROUTE_PICK_PLAN("WITRON-FM-03","Mismatch in route number in pick plan FM"),
	WITRON_MISMATCH_FULFILLMENT_PICK_PLAN("WITRON-FM-04","Mismatch in fulfillment in pick plan FM"),
	WITRON_MISMATCH_FULFILLMENT_LINE_PICK_PLAN("WITRON-FM-05","Mismatch in fulfillment line in pick plan FM"),
	WITRON_MISMATCH_ITEM_PICK_PLAN("WITRON-FM-06","Mismatch in item number in pick plan FM"),
	WITRON_MISMATCH_LOGICAL_REFERENCE_PICK_PLAN("WITRON-FM-07","Mismatch in logical refernce number in pick plan FM"),
	WITRON_MISMATCH_PLANNED_CNTR_PICK_PLAN("WITRON-FM-08","Mismatch in planned container in pick plan FM"),
	WITRON_MISMATCH_PLANNED_QTY_PICK_PLAN("WITRON-FM-09","Mismatch in planned qty in pick plan FM"),
	WITRON_MISMATCH_STATUS_PICK_PLAN("WITRON-FM-10","Mismatch in status in pick plan FM"),
	WITRON_MISMATCH_ACTUAL_CNTR_PICK_PLAN("WITRON-FM-11","Mismatch in actual container in pick plan FM"),
	WITRON_MISMATCH_FULFILLED_ITEM_PICK_PLAN("WITRON-FM-12","Mismatch in fulfilled item in pick plan FM"),
	WITRON_MISMATCH_FULFILLED_QTY_PICK_PLAN("WITRON-FM-13","Mismatch in fulfilled qty in pick plan FM"),
	WITRON_MISMATCH_OHCOLC_FULFILLED_QTY_FULFILLMENT_UNIT("WITRON-FM-14","Mismatch in fulfilled qty in Fulfillment units table"),
	WITRON_MISMATCH_OHCOLC_OUT_QTY_FULFILLMENT_UNIT("WITRON-FM-15","Mismatch in out qty in Fulfillment units table"),
	
	//Loading errorcodes
	WITRON_LOADING_COUNT_MISMATCH("WITRON-LOADING-01","Mismatch in the created load Id count in Loading"),
	WITRON_LOADID_MISMATCH("WITRON-LOADING-02","load Id is null"),
	WITRON_TRANSPORTATION_LOADID_NOT_GENERATED("WITRON-LOADING-03","transportation load Id is not generated in Loading"),
	WITRON_LOADING_FAILED("WITRON-LOADING-04","Failed to validate loading"),
	WITRON_LOADING_ROUTE_MISMATCH("WITRON-LOADING-05","Route number is not displayed i Loading"),
	WITRON_TRANSPORTATION_LOADID_MISMATCH("WITRON-LOADING-06","transportation load Id is not matching with one generated Score and Loading"),
	WITRON_LOADING_STATUS_MISMATCH("WITRON-LOADING-07","Mismatch in the load status"),
	WITRON_LOADING_CONTAINERS_MISMATCH("WITRON-LOADING-08","Failed to validate containers in Loading after pre DTH DTL"),
	WITRON_OUTBOUND_DOOR_NOT_GENERATED("WITRON-LOADING-09","Outbound door is not generated in Loading"),
	WITRON_CONTAINERS_MISMATCH("WITRON-LOADING-10","Mismatch in containers in Loading"),
	WITRON_PARENT_CONTAINER_MATCH("WITRON-LOADING-11","Mismatch in parent container in Loading"),
	
	//OT errorcodes
	WITRON_OT_ORDER_COUNT_MISMATCH("WITRON-OT-01","Mis match in the orders count in OT"),
	WITRON_OT_ALLOC_QTY_MISMATCH("WITRON-OT-02","Mis match in the allocated qty in OT"),
	WITRON_OT_ITEM_MISMATCH("WITRON-OT-03","Mis match in the item nbr in OT"),
	WITRON_OT_ORDER_ID_MISMATCH("WITRON-OT-04","Mis match in the order Ids in OT"),
	WITRON_OT_STATUS_MISMATCH("WITRON-OT-05","Mis match in the order status in OT"),
	WITRON_OT_ORDER_QTY_MISMATCH("WITRON-OT-06","Mis match in the order quantity in OT"),
	WITRON_OT_OUT_QTY_MISMATCH("WITRON-OT-07","Mis match in the out quantity in OT"),
	WITRON_OT_PICK_QTY_MISMATCH("WITRON-OT-08","Mis match in the pick quantity in OT"),
	WITRON_OT_TOTAL_ORDER_QTY_MISMATCH("WITRON-OT-09","Mis match in the total order quantity in OT"),
	WITRON_OT_TOTAL_ALLOCATED_QTY_MISMATCH("WITRON-OT-10","Mis match in the total allocated quantity in OT"),
	WITRON_OT_TOTAL_ORDERS_MISMATCH("WITRON-OT-11","Mis match in the total Orders in OT"),
	WITRON_OT_TOTAL_RELEASED_QTY_MISMATCH("WITRON-OT-12","Mis match in the total released quantity in OT"),
	WITRON_OT_TOTAL_PICKED_QTY_MISMATCH("WITRON-OT-13","Mis match in the total picked quantity in OT"),
	WITRON_OT_TOTAL_OUT_QTY_MISMATCH("WITRON-OT-14","Mis match in the total out quantity in OT"),
	WITRON_OT_QTC_POST_FULFILMENTS_OUTS_MISMATCH("WITRON-OT-01","Mis match in post fulfilments outs after QTC"),

	
	//Score errorcodes
	WITRON_RELEASE_ROUTES_FAILED("WITRON-SCORE-01","Failed to release routes from the Score"),
	WITRON_GET_ROUTES_FAILED("WITRON-SCORE-02","Failed to get routes from the Score"),
	WITRON_SCORE_CARRIER_MISMATCH("WITRON-SCORE-03","There are no carriers to assign it to a route"),
	WITRON_SCORE_ASSIGN_CARRIER_FAILED("WITRON-SCORE-04","Failed to assign carrier to the Route"),
	WITRON_SCORE_STATUS_MISMATCH("WITRON-SCORE-05","Mis match in Score status after Release"),

	//oms errorcodes
	WITRON_GET_OMS("WITRON-OMS-01", "Not able to fetch Witron OMS PO"),
	
	//OW errorcodes
	WITRON_CREATE_ORDERS("WITRON-OW-01", "Failed to post orders to Witron Mock"),
	WITRON_OW_GET_ORDERS_FAILED("WITRON-OW-02","Failed to search orders in OW"),
	
	//item mdm errorcodes
	WITRON_ITEM_FETCH_FAILED("WITRON-ITEMMDM-01","Unable to Fetch item details from item mdm"),
	WITRON_ITEM_IDENTIFIER_UPADTE_FAILED("WITRON-ITEMMDM-02","Unable to update Item MDM identifier details"),
	WITRON_ITEM_MISCELLNEOUS_UPADTE_FAILED("WITRON-ITEMMDM-03","Unable to update Item MDM Miscellneous details"),
	WITRON_ITEM_MDM_CROSS_REFERENCE_ITEMS_MISMATCH("WITRON-ITEMMDM-04","Cross reference items mismatch"),
	WITRON_ITEM_MDM_CROSS_REFERENCE_ITEMS_UPC_IS_NULL("WITRON-ITEMMDM-05","Cross reference items UPC is null"),
	WITRON_ITEM_MDM__FETCH_FAILED("WITRON-ITEMMDM-06","Unable to Fetch details"),
	WITRON_ITEM_MDM__WEIGHT_MISMATCH("WITRON-ITEMMDM-07","Updated weight is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_HEIGHT_MISMATCH("WITRON-ITEMMDM-08","Updated height is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_LENGTH_MISMATCH("WITRON-ITEMMDM-09","Updated length is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_WIDTH_MISMATCH("WITRON-ITEMMDM-10","Updated width is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_PALLET_TI_MISMATCH("WITRON-ITEMMDM-11","Updated palletTi is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_PALLET_HI_MISMATCH("WITRON-ITEMMDM-12","Updated palletHi is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_WAREHOUSE_AREA_MISMATCH("WITRON-ITEMMDM-13","Updated warehouseArea is not reflecting in Item MDM"),
	WITRON_ITEM_MDM_WAREHOUSE_CODE_MISMATCH("WITRON-ITEMMDM-14","Updated wareHouseCode is not reflecting in Item MDM"),
	WITRON_ITEM_WAREHOUSEAREA_UPADTE_FAILED("WITRON-ITEMMDM-15","Unable to update Item MDM WarehouseArea details"),
	WITRON_ITEM_SELECTIONSECTION_UPADTE_FAILED("WITRON-ITEMMDM-16","Unable to update Item MDM Selection Section details"),

	//mock errorcodes
	WITRON_DELETE_MOCK("WITRON-MOCK-01", "Failed to delete the Mock"),
	
	//GDM errorcodes
	WITRON_GDM_LOGIN_FAILED("WITRON-GDM-01","Failed to login to GDM UI"),
	WITRON_GDM_OVG_VALIDATION_FAILED("WITRON-GDM-02","Overage is not populated in the delivery"),
	WITRON_GDM_AVG_WEIGHT_VALIDATION_FAILED("WITRON-GDM-03","Mismatch in the average weight"),
	WITRON_GDM_CRO_STATE_MISMATCH("WITRON-GDM-04","Mismatch in the cro line state"),
	WITRON_GDM_OSDR_ITEM_MISMATCH("WITRON-GDM-05","Mismatch in the item number"),
	WITRON_GDM_OSDR_PO_QTY_MISMATCH("WITRON-GDM-06","Mismatch in the po quantity"),
	WITRON_GDM_OSDR_FBQ_QTY_MISMATCH("WITRON-GDM-07","Mismatch in the fbq quantity"),
	WITRON_GDM_OSDR_VNPK_MISMATCH("WITRON-GDM-08","Mismatch in the vnpk ratio"),
	WITRON_GDM_OSDR_WHPK_MISMATCH("WITRON-GDM-09","Mismatch in the whpk ratio"),
	WITRON_GDM_OSDR_RECEIVED_QTY_MISMATCH("WITRON-GDM-10","Mismatch in the received quantity"),
	WITRON_GDM_OSDR_DAMAGE_QTY_MISMATCH("WITRON-GDM-11","Mismatch in the damage quantity"),
	WITRON_GDM_OSDR_REJECTED_QTY_MISMATCH("WITRON-GDM-12","Mismatch in the rejected quantity"),
	WITRON_GDM_OSDR_OVG_QTY_MISMATCH("WITRON-GDM-13","Mismatch in the overage quantity"),
	WITRON_GDM_OSDR_SHORT_QTY_MISMATCH("WITRON-GDM-14","Mismatch in the shortage quantity"),
	WITRON_PO_NOT_ATTACHED("WITRON-GDM-14", "Po Not attached to PO"),
	WITRON_GDM_OSDR_PROBLEM_MISMATCH("WITRON-GDM-15","Mismatch in the problem quantity"),
	WITRON_GDM_PROBLEM_TICKET_COUNT_MISMATCH("WITRON-GDM-16","Mismatch in the problem ticket count"),
	WITRON_GDM_DELIVERY_PROBLEM_COUNT_MISMATCH("WITRON-GDM-17","Mismatch in the problem count at Delivery"),
	WITRON_GDM_ZONE1_TEMPERATURE_MISMATCH("WITRON-GDM-18","Mismatch in the Temperature of Zone 1"),
	WITRON_GDM_ZONE2_TEMPERATURE_MISMATCH("WITRON-GDM-19","Mismatch in the Temperature of Zone 2"),
	WITRON_GDM_ZONE3_TEMPERATURE_MISMATCH("WITRON-GDM-20","Mismatch in the Temperature of Zone 3"),
	WITRON_GDM_FETCH_FAILED("WITRON-GDM-21","Unable to Fetch GDM details"),
	WITRON_GDM_WAREHOUSE_AREA_MISMATCH("WITRON-GDM-22","Updated warehouseArea is not reflecting in GDM"),
	WITRON_GDM_WAREHOUSE_CODE_MISMATCH("WITRON-GDM-23","Updated wareHouseCode is not reflecting in GDM"),
	WITRON_GDM_WEIGHT_MISMATCH("WITRON-GDM-22","Updated weight is not reflecting in GDM"),
	WITRON_GDM_CUBE_MISMATCH("WITRON-GDM-23","Updated cube is not reflecting in GDM"),
	WITRON_GDM_OSDR_WHPKSELLPRICE_MISMATCH("WITRON-GDM-24","Mismatch in the whpk Sell Price"),
	WITRON_GDM_POMGMT_ITEMCOUNT_MISMATCH("WITRON-GDM-25","Mismatch in the item count"),
	WITRON_GDM_POMGMT_TOTAL_COST_MISMATCH("WITRON-GDM-26","Mismatch in the total cost"),
	WITRON_GDM_POMGMT_PO_NUM_MISMATCH("WITRON-GDM-27","PO Number mismatch"),
	WITRON_GDM_POMGMT_PO_LINE_COUNT_MISMATCH("WITRON-GDM-28","PO Line count mismatch"),
	WITRON_GDM_POMGMT_PO_VNPK_QTY_MISMATCH("WITRON-GDM-29","vnpk qty mismatch"),
	WITRON_GDM_POMGMT_PO_WHPK_QTY_MISMATCH("WITRON-GDM-29","whpk qty mismatch"),





	
	//Witron DCFIN
	WITRON_DCFIN_PURCHASE_FAILED("WITRON-DCFIN-01","Not able to fetch the purchase"),
	WITRON_DCFIN_GDIS_DAMAGE_QTY_MISMATCH("WITRON-DCFIN-02","Mismatch in damage quantity in GDIS"),
	WITRON_DCFIN_GDIS_OVG_SHORT_QTY_MISMATCH("WITRON-DCFIN-03","Mismatch in overage/shortage quantity in GDIS"),
	WITRON_DCFIN_GDIS_REJECT_QTY_MISMATCH("WITRON-DCFIN-04","Mismatch in reject quantity in GDIS"),
	WITRON_DCFIN_GDIS_RECEIVE_QTY_MISMATCH("WITRON-DCFIN-05","Mismatch in received quantity in GDIS"),
	WITRON_DCFIN_GDIS_VNPK_MISMATCH("WITRON-DCFIN-05","Mismatch in vnpk in GDIS"),
	WITRON_DCFIN_TOTAL_COST_MISMATCH("WITRON-DCFIN-06","Mismatch in total cost in purchase"),
	WITRON_DCFIN_CONTAINER_MISMATCH("WITRON-DCFIN-07","Mismatch in container ID in purchase"),
	WITRON_DCFIN_VNPK_MISMATCH("WITRON-DCFIN-08","Mismatch in vnpk ratio in purchase"),
	WITRON_DCFIN_WHPK_MISMATCH("WITRON-DCFIN-09","Mismatch in whpk ratio in purchase"),
	WITRON_DCFIN_RECEIVE_QTY_MISMATCH("WITRON-DCFIN-10","Mismatch in received quantity in purchase"),
	WITRON_DCFIN_WHPK_SELL_COST_MISMATCH("WITRON-DCFIN-10","Mismatch in whpk sell cost in purchase"),
	WITRON_DCFIN_OMS_POSTING_MISMATCH("WITRON-DCFIN-11","OSDR is not posted to OMS"),
	WITRON_DCFIN_BOH_MISMATCH("WITRON-DCFIN-12","Mismatch in BOH"),
	WITRON_DCFIN_WEIGHT_MISMATCH("WITRON-DCFIN-13","Mismatch in Total weight"),
	WITRON_DCFIN_WAC_MISMATCH("WITRON-DCFIN-14","Mismatch in Wac"),
	WITRON_DCFIN_WAW_MISMATCH("WITRON-DCFIN-15","Mismatch in Waw"),
	WITRON_DCFIN_ADJUSTED_CNTR_MISMATCH("WITRON-DCFIN-16","Mismatch in Adjusted Container"),
	WITRON_DCFIN_ADJUSTED_QTY_MISMATCH("WITRON-DCFIN-17","Mismatch in Adjusted quantity"),
	WITRON_DCFIN_ADJUSTED_CODE_MISMATCH("WITRON-DCFIN-18","Mismatch in Adjusted code"),
	WITRON_DCFIN_ADJUSTED_COST_MISMATCH("WITRON-DCFIN-19","Mismatch in Adjusted cost"),
	WITRON_DCFIN_ADJUSTED_WEIGHT_MISMATCH("WITRON-DCFIN-18","Mismatch in Adjusted weight"),
	WITRON_DCFIN_UI_WAC_MISMATCH("WITRON-DCFIN-19","Mismatch in UI Wac values"),
	WITRON_DCFIN_UI_WAW_MISMATCH("WITRON-DCFIN-20","Mismatch in UI Waw values"),
	WITRON_DCFIN_UI_BOH_MISMATCH("WITRON-DCFIN-21","Mismatch in UI BO Values"),
	WITRON_DCFIN_UI_INVENTORY_UNITS_MISMATCH("WITRON-DCFIN-22","Inventory units mismatch"),
	WITRON_DCFIN_UI_WAW_UNITS_MISMATCH("WITRON-DCFIN-23","WAC units mismatch"),
	WITRON_DCFIN_UI_WAC_UNITS_MISMATCH("WITRON-DCFIN-24","WAW units mismatch"),
	WITRON_DCFIN_UI_DETAILS_MISMATCH("WITRON-DCFIN-25","Mismatch in the header and table details"),
	WITRON_DCFIN_SALES_BOH_MISMATCH("WITRON-DCFIN-26","Mismatch in the BOH after saless"),
	WITRON_DCFIN_WAW_RECEIVING_VARIANCE_MISMATCH("WITRON-DCFIN-27","Mismatch in the Receiving Variance value after WAW Correction"),
	WITRON_DCFIN_WAC_RECEIVING_VARIANCE_MISMATCH("WITRON-DCFIN-28","Mismatch in the Receiving Variance value after WAC Correction"),
	WITRON_DCFIN_WAW_TOTAL_INVENTORY_MISMATCH("WITRON-DCFIN-29","Mismatch in the Total Inventory after WAW Correction"),
	WITRON_DCFIN_WAC_TOTAL_INVENTORY_MISMATCH("WITRON-DCFIN-30","Mismatch in the Total Inventory after WAC Correction"),
	//Witron receiving
		WITRON_RECEIVING_PO_CONFIRM_FAILED("WITRON-RECEIVING-01","PO CONFIRM FAILED"),
		WITRON_VTR_QTY_MATCHES("WITRON-RECEIVING-02","VTR QTY REDUCED"),
		WITRON_PALLET_CANCELLED("WITRON-RECEIVING-03","PALLET NOT CANCELLED SUCCESSFULLY"),
		WITRON_REJECT_QTY_MATCH("WITRON-RECEIVING-04","REJECT QTY MATCHED FAILED."),
		WITRON_VTR_NEGATIVE("WITRON-RECEIVING-05","ABLE TO VTR POST PO CONFIRM"),
		WITRON_POCONFIRM_NEGATIVE("WITRON-RECEIVING-06","ABLE TO DO CORRECTION BEFORE PO CONFIRM"),
		WITRON_POCONFIRM_NEGATIVE_VALIDATION("WITRON-RECEIVING-07","Pallet Correction allowed before PO confirm"),
		WITRON_PALLET_CORRECTION_MORE_THAN_TI_HI("WITRON-RECEIVING-08","ENTERED QTY IS MORE THAN TI-HI"),
		WITRON_OVG_QTY("WITRON-RECEIVING-11","OVG QTY MATCHED FAILED."),
		WITRON_RECIEVING_FRIEGHT_NOT_ON_PO_QTY_MISMATCH("WITRON-RECIEVING-09", "Frieght not on po qty mismatch"),
		WITRON_RECIEVING_PF_QTY_MISMATCH("WITRON-RECIEVING-10", "PF qty mismatch"),





		
	//Witron Orderwell
		WITRON_GET_ORDERS_FAILED("WITRON-ORDERWELL-01","Failed to get OW orders"),
		WITRON_UPDATE_ORDER_STATUS_FAILED("WITRON-ORDERWELL-02","Failed to get OW orders"),
		WITRON_CREATE_ORDER_FAILED("WITRON-ORDERWELL-03","Failed to get OW orders"),

	//Catalyst Orderwell
		CATALYST_GET_ORDERS_FAILED("CATALYST-ORDERWELL-01","Failed to get OW orders"),
		CATALYST_UPDATE_ORDER_STATUS_FAILED("CATALYST-ORDERWELL-02","Failed to get OW orders"),
		CATALYST_CREATE_ORDER_FAILED("CATALYST-ORDERWELL-03","Failed to get OW orders"),

   //Problem creation 
		WITRON_RECIEVING_PROBLEM_CREATION_FAILED("WITRON-RECIEVING-PROBLEM-01","Witron Recieving problem creation failed"),
		WITRON_RECIEVING_PROBLEM_LABEL_MISMATCH("WITRON-RECIEVING-PROBLEM-02","Witron Recieving problem label mismatch"),
		WITRON_RECIEVING_PROBLEM_STATUS_MISMATCH("WITRON-RECIEVING-PROBLEM-03","Witron Recieving problem status mismatch"),
		WITRON_RECIEVING_PROBLEM_RESOLUTION_MISMATCH("WITRON-RECIEVING-PROBLEM-04","Witron Recieving problem Resolution mismatch"),
		WITRON_RECIEVING_PROBLEM_RESOLUTION_FAILED("WITRON-RECIEVING-PROBLME-RESOLUTION-05", "Unable to resolve receiving problem"),
		
		//Witrin MM
		
		MM_CONTAINER_CANCELLED_STATUS("MM-01", "CONTAINER status is not cancelled"),

		MM_CONTAINER_OPEN_STATUS("MM-02", "CONTAINER status is not in Open status"),

		MM_CONTAINER_COMPLETED_STATUS("MM-02", "CONTAINER status is not in COMPLETED status"),
		
//		Facility mdm
		WITRON_FACILITY_MDM_FETCH_FAILED("WITRON-FACILITY-MDM-01","failed to fetch facility mdm response for a store"),
		
	//Audit Tool
		WITRON_AUDIT_EVENT_DETAILS_FETCH_FAILED("WITRON-EVENT-AUDIT-01","Unable to Fetch Event details"),
		WITRON_AUDIT_EVENT_WEIGHT_IS_NULL("WITRON-EVENT-AUDIT-02","Weight is null"),
		WITRON_AUDIT_EVENT_TI_IS_NULL("WITRON-EVENT-AUDIT-03","Ti is null"),
        WITRON_AUDIT_EVENT_HI_IS_NULL("WITRON-EVENT-AUDIT-04","Hi is null"),
        WITRON_AUDIT_VENDOR_NUMBER_LENGTH_MISMATCH("WITRON-EVENT-AUDIT-05","Vendor number legth is not equal to 9"),
        WITRON_AUDIT_EVENT_ITEM_MDM_API_AND_UI_DETAILS_MISMATCH("WITRON-EVENT-AUDIT-06","Updated details in PMA message and MDM UI doesnt match"),
        WITRON_AUDIT_EVENT_INVENTORY_STATUS_MISAMTCH("WITRON-EVENT-AUDIT-07","Inventory status mismatch"),
        WITRON_AUDIT_EVENT_QTY_MISMATCH("WITRON-EVENT-AUDIT-08","Quantity mismatch"),
        WITRON_AUDIT_EVENT_VNPKQTY_IS_NULL("WITRON-EVENT-AUDIT-09","vnpk qty  is null"),
        WITRON_AUDIT_EVENT_QTY_UOM_MISMATCH("WITRON-EVENT-AUDIT-10","Quantity UOM mismatch"),
        WITRON_AUDIT_EVENT_WEIGHT_UOM_MISMATCH("WITRON-EVENT-AUDIT-11","Weight UOM mismatch"),
        WITRON_AUDIT_EVENT_COUNTRY_CODE_MISMATCH("WITRON-EVENT-AUDIT-12","Country code mismatch"),
        WITRON_AUDIT_EVENT_DELIVERY_NUM_MISMATCH("WITRON-EVENT-AUDIT-13","Delivery number mismatch"),
        WITRON_AUDIT_EVENT_ROATATION_DATE_MISMATCH("WITRON-EVENT-AUDIT-14","Rotation date mismatch"),
        WITRON_AUDIT_EVENT_RTU_MISSING_UPDATE_EVENT("WITRON-EVENT-AUDIT-15","Update event is not present in audit response"),
        WITRON_AUDIT_EVENT_RTU_MISSING_DELETE_EVENT("WITRON-EVENT-AUDIT-16","Delete event is not present in audit response"),
        WITRON_AUDIT_EVENT_RTU_MISSING_ADD_EVENT("WITRON-EVENT-AUDIT-16","Add event is not present in audit response"),
        WITRON_AUDIT_EVENT_RTU_WEIGHT_MISMATCH("WITRON-EVENT-AUDIT-17","Item MDM updated weight is not reflecting"),
        WITRON_AUDIT_EVENT_RTU_PALLET_TI_MISMATCH("WITRON-EVENT-AUDIT-18","Item MDM updated palletTi is not reflecting"),
        WITRON_AUDIT_EVENT_RTU_PALLET_HI_MISMATCH("WITRON-EVENT-AUDIT-19","Item MDM updated palletHi is not reflecting"),
        WITRON_AUDIT_EVENT_RTU_WEIGHT_NULL("WITRON-EVENT-AUDIT-20","RTU Weight is Null"),
        WITRON_AUDIT_EVENT_EMPTY_RESPONSE("WITRON-EVENT-AUDIT-21","list of entities is empty"),
        WITRON_AUDIT_EVENT_RTU_VTR_WITRON_DELETE_EVENT("WITRON-EVENT-AUDIT-22","Delete event is  present in audit response for VTR from Witron"),
        WITRON_AUDIT_EVENT_RTU_VTR_WITRON_UPDATE_EVENT("WITRON-EVENT-AUDIT-23","Update event is  present in audit response for VTR from Witron"),
        WITRON_AUDIT_EVENT_RTU_VTR_RECEIVING_UPDATE_EVENT("WITRON-EVENT-AUDIT-24","Update event is present in audit response for VTR from Receving"),
        WITRON_AUDIT_EVENT_RTU_CORRECTION_WITRON_DELETE_EVENT("WITRON-EVENT-AUDIT-25","Delete event is  present in audit response for pallet correction from Witron"),
        WITRON_AUDIT_EVENT_RTU_CORRECTION_WITRON_UPDATE_EVENT("WITRON-EVENT-AUDIT-26","Update event is  present in audit response for pallet correction from Witron"),
        WITRON_AUDIT_EVENT_RTU_CORRECTION_RECEIVING_DELETE_EVENT("WITRON-EVENT-AUDIT-27","Update event is present in audit response for pallet correction from Receving"),


//shore error codes
    	WITRON_INVOICE_COUNT_MISMATCH("WITRON-SHORE-01","Mismatch in invoice generated"),
      	WITRON_GET_SHORE_INVOICE_FAILED("WITRON-SHORE-02","Unable to fetch the invoices from shore"),
    	WITRON_INVOICE_ITEM_QTY_MISMATCH("WITRON-SHORE-03","Mismatch in the item quantity in Invoice"),
    	WITRON_INVOICE_DIVISION_MISMATCH("WITRON-SHORE-04","Mismatch in the division number in Invoice"),
    	WITRON_INVOICE_DESTINATION_MISMATCH("WITRON-SHORE-05","Mismatch in the destination number in Invoice"),
    	WITRON_INVOICE_LOAD_ID_MISMATCH("WITRON-SHORE-06","Mismatch in the load Id in Invoice"),
    	WITRON_INVOICE_TRAILER_MISMATCH("WITRON-SHORE-07","Mismatch in the Trailer number in Invoice"),
    	WITRON_INVOICE_STATUS_MISMATCH("WITRON-SHORE-08","Mismatch in the status in Invoice"),
    	WITRON_INVOICE_WEIGHT_FORMAT_MISMATCH("WITRON-SHORE-09","Mismatch in the weight format in Invoice"),
    	WITRON_INVOICE_ITEM_COST_MISMATCH("WITRON-SHORE-10","Mismatch in the item cost in Invoice"),
    	WITRON_INVOICE_SHORE_UI_TRAILER_MISMATCH("WITRON-SHORE-11","Mismatch in the Trailer number in Invoice"),
    	WITRON_INVOICE_SHORE_UI_LOAD_ID_MISMATCH("WITRON-SHORE-12","Mismatch in the load Id in Invoice"),
    	WITRON_INVOICE_SHORE_UI_DIVISON_MISMATCH("WITRON-SHORE-13","Mismatch in the load Id in Invoice"),
    	WITRON_INVOICE_SHORE_UI_DESITINATION_MISMATCH("WITRON-SHORE-14","Mismatch in the load Id in Invoice"),
     	WITRON_INVOICE_SHORE_UI_ITEMNUMBER_MISMATCH("WITRON-SHORE-15","Mismatch in item number in Invoice"),
     	WITRON_INVOICE_SHORE_UI_DEPTNUMBER_MISMATCH("WITRON-SHORE-16","Mismatch in the department number in Invoice"),
     	WITRON_INVOICE_SHORE_UI_WHPQTY_MISMATCH("WITRON-SHORE-17","Mismatch in the WHPK Qty in Invoice"),
     	WITRON_INVOICE_SHORE_UI_TOTALCOST_MISMATCH("WITRON-SHORE-18","Mismatch in the total cost in Invoice"),
     	WITRON_INVOICE_SHORE_UI_INVOICECOST_MISMATCH("WITRON-SHORE-19","Mismatch in the total cost in Invoice"),
    	WITRON_INVOICE_SHORE_UI_OUTDOOR_DOOR_MISMATCH("WITRON-SHORE-20","Mismatch in the door "),
    	WITRON_INVOICE_SHORE_UI_OUTDOOR_TRAILER_NUMBER_MISMATCH("WITRON-SHORE-21","Mismatch in the trailer number"),
    	WITRON_INVOICE_SHORE_UI_OUTDOOR_DESTINATIONS_MISMATCH("WITRON-SHORE-22","Mismatch in the Destinations"),

    	//RDC GDM error codes

    	RDC_FAILED_TO_POPULATE_TESTFLOWDATA("RDC-GDM-01","Failed to populate testflow data"),
    	RDC_FAILED_TO_GET_DELIVERY("RDC-GDM-02","Failed to get delivery document from GDM"),
    	RDC_FAILED_TO_VALIDATE_DELIVERY_STATUS("RDC-GDM-03","Mismatch in the GDM delivery status"),
    	RDC_FAILED_TO_VALIDATE_GDM_UI("RDC-GDM-04","Failed to Validate GDM UI"),
    	RDC_GDM_UI_DELIVERY_STATUS_MISMATCH("RDC-GDM-05","Mismatch in the delivery status"),
    	RDC_GDM_UI_DOOR_NBR_MISMATCH("RDC-GDM-06","Mismatch in the Door Number"),
    	RDC_GDM_UI_PO_COUNT_MISMATCH("RDC-GDM-07","Mismatch in the PO Count"),
    	RDC_GDM_UI_PO_LINE_COUNT_MISMATCH("RDC-GDM-08","Mismatch in the PO Line Count"),
    	RDC_GDM_UI_TOTAL_QUANTITY_MISMATCH("RDC-GDM-09","Mismatch in the Total quantity"),
    	RDC_FAILED_TO_CREATE_ASN("RDC-GDM-10","Failed to create ASN"),
    	RDC_FAILED_TO_VALIDATE_DOCKTAGS("RDC-GDM-11","Failed to validate docktags in GDM UI"),
    	RDC_GDM_MISMATCH_IN_CASE_UPC_AFTER_ITEM_CATALOG("RDC-GDM-12","case upc is not updated in GDM after item cataloging"),
    	RDC_GDM_FAILED_TO_VALIDATE_CASEUPC_AFTER_ITEM_CATALOG("RDC-GDM-13","Failed to validate case upc in GDM after item cataloging"),
    	RDC_GDM_DELIVERY_STATUS_MISMATCH("RDC-GDM-14","Mismatch in the delivery status"),
    	RDC_GDM_DELIVERY_LEGACY_STATUS_MISMATCH("RDC-GDM-15","Mismatch in the delivery legacy status"),


    	//RDC Receiving error codes

    	RDC_FAILED_TO_SCAN_DOOR("RDC-RECEIVING-01","Failed to scan the door"),
    	RDC_FAILED_VALIDATE_ITEM("RDC-RECEIVING-02","Failed to validate item in Receiving App"),
    	RDC_FAILED_TO_RECEIVE_ITEM("RDC-RECEIVING-03","Failed to receive and item from Receiving App"),
    	RDC_FAILED_TO_GET_RECEIVED_CONTAINER("RDC-RECEIVING-04","Failed to get Received Container"),
    	RDC_FAILED_VALIDATE_CONTAINERS_IN_RECEIVING("RDC-RECEIVING-05","Failed to validate containers in receivingr"),
    	RDC_FAILED_TO_COMPLETE_DELIVERY_IN_RECEIVING("RDC-RECEIVING-06","Failed to complete delivery in receivingr"),
    	RDC_FAILED_TO_VALIDATE_CONTAINERS_QTY_IN_RECEIVING("RDC-RECEIVING-07","Failed to validate containers quantity in receivingr"),
    	RDC_FAILED_TO_VALIDATE_RECEIPTS_IN_RECEIVING("RDC-RECEIVING-08","Failed to validate receipts in receivingr"),
    	RDC_FAILED_TO_COMPLETE_DOCKTAG("RDC-RECEIVING-09","Failed to complete the docktag in receivingr"),
    	RDC_FAILED_TO_RECEIVE_DOCKTAG("RDC-RECEIVING-10","Failed to receive the docktag in receiving"),
    	RDC_FAILED_TO_VALIDATE_DOCKTAG_COMPLETE_MSG("RDC-RECEIVING-11","Failed to validate the docktag complete message"),
    	RDC_FAILED_VALIDATE_LABEL_IN_RC("RDC-RECEIVING-12","Failed to validate label in receiving correction screen"),
    	RDC_FAILED_VALIDATE_ITEM_IN_RC("RDC-RECEIVING-12","Failed to validate item in receiving correction screen"),
    	RDC_FAILED_TO_PERFORM_RECEIVING_CORRECTION("RDC-RECEIVING-13","Failed to perform receiving correction"),
    	RDC_CONTAINER_QUANTITY_MISMATCH_AFTER_RC("RDC-RECEIVING-14","Mismatch in container quantity after receiving correction"),
    	RDC_MISMATCH_IN_RECEIPTS_AFTER_RC("RDC-RECEIVING-15","Mismatch in receipts after receiving correction"),
    	RDC_FAILED_VALIDATE_QUANTITY_IN_RC("RDC-RECEIVING-16","Failed to validate quantity in receiving correction screen"),
    	RDC_FAILED_TO_VALIDATE_RECEIPTS_IN_RECEIVING_AFTER_RC("RDC-RECEIVING-17","Failed to validate receipts in receiving afer receiving correction screen"),
    	RDC_FAILED_TO_VALIDATE_UPDATE_GTIN_ERROR_MSG("RDC-RECEIVING-18","Failed to validate update GTIN error message"),
    	RDC_FAILED_TO_VALIDATE_INVALID_ITEM_ERROR_MSG("RDC-RECEIVING-19","Failed to validate invalid item error message"),
    	RDC_MISMATCH_IN_UPDATED_GTIN("RDC-RECEIVING-20","Mis match in updated GTIN"),
    	RDC_MISMATCH_IN_UPDATED_ITEM("RDC-RECEIVING-21","Mis match in updated item"),
    	RDC_DOCKTAG_NOT_GENERATED("RDC-RECEIVING-22","Dock Tag is not generated"),
    	
    	// RDC Loading error codes
    	
    	RDC_FAILED_TO_PUBLISH_DIVERTS("RDC-LOADING-01","Failed to publish divert message"),
    	
    	//RDC item mdm error codes

    	RDC_FAILED_TO_GET_ITEM_MDM_RESPONSE("RDC-ITEM-01","Failed to get item mdm response"),

        //RDC oms error codes

    	RDC_FAILED_TO_CREATE_PO("RDC-OMS-01","Failed to create PO"),

    	//RDC clean up error codes

    	RDC_FAILED_TO_CLEAN_GDM("RDC-CLEANUP-01","Failed to clean up GDM"),
    	RDC_FAILED_TO_CLEAN_RECEIVING("RDC-CLEANUP-02","Failed to clean up Receiving"),
    	RDC_FAILED_TO_CLEAN_RDS("RDC-CLEANUP-03","Failed to clean up RDS"),
    	RDC_FAILED_TO_CLEAN_RDC("RDC-CLEANUP-04","Failed to clean up RDC"),

    	//RDC Location error codes
    	RDC_FAILED_TO_VALIDATE_LOCATION("RDC-LOCATION-01","Failed to validate door number in Location"),
    	RDC_FAILED_TO_SEARCH_DOOR("RDC-LOCATION-02","Failed to search door"),
    	RDC_FAILED_TO_ADD_DOOR("RDC-LOCATION-03","Failed to Add door"),

    	//RDC RDS  error codes
    	RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS("RDC-RDS-01","Failed to validate containers in RDS"),
    	RDC_FAILED_TO_VALIDATE_CONTAINERS_IN_RDS_AFTER_RC("RDC-RDS-02","Failed to validate containers in RDS after Receiving correction"),



	
	//Pharmacy_OMS
    	PHARMACY_UNABLE_TO_FETCH_OMS_PO("PHARMACY-OMS-01","Unable to fetch Pharmacy OMS PO"),
    	PHARMACY_UNABLE_CREATE_SHIPMENT("PHARMACY-GDM-02","Unable to create Shipment"),
    	PHARMACY_UNABLE_FIND_SHIPMENT_IN_DELIVERY("PHARMACY-GDM-03","Unable to get Shipment"),
		PHARMACY_COUNT_MISMATCH_OF_SHIPMENT_IN_DELIVERY("PHARMACY-GDM-04","Shipment Count mismatch in delivery"),
		PHARMACY_UNABLE_GET_SHIPMENT_DETAILS("PHARMACY-GDM-05","Unable to get Shipment Details"),
		PHARMACY_RECEIVING_UNBLE_TO_FETCH_INSTRUCTIONS("PHARMACY-REC-01","Unable to fetch Receiving instructions"),
		PHARMACY_RDS_PTAG_DETAILS_NOT_FOUND("PHARMACY-RDS-01","Ptag details not found in RDS"),
		PHARMACY_RDS_PTAG_MISMATCH_IN_RECEIVED_QTY("PHARMACY-RDS-02","Ptag - Mismatch in Received quantity in RDS"),
		PHARMACY_RDS_MISMATCH_IN_RECEIVED_QTY("PHARMACY-RDS-03","Mismatch in Received quantity in RDS"),
		PHARMACY_RDS_MISMATCH_IN_OSDR_OVERAGE_QTY("PHARMACY-RDS-04","OSDR - Mismatch in Overage quantity in RDS"),
		PHARMACY_RDS_MISMATCH_IN_OSDR_SHORTAGE_QTY("PHARMACY-RDS-05","OSDR - Mismatch in Shortage quantity in RDS"),
		PHARMACY_RDS_MISMATCH_IN_OSDR_DAMAGE_QTY("PHARMACY-RDS-06","OSDR - Mismatch in Damage quantity in RDS"),
		PHARMACY_RDS_MISMATCH_IN_OSDR_RECEIVED_QTY("PHARMACY-RDS-07","OSDR - Mismatch in Received quantity in RDS"),
		PHARMACY_RDS_RCV_UNIT_DETAILS_NOT_FOUND_IN_PEDIGREE("PHARMACY-RDS-08","Rec unit details not found in Pedigree table"),
		PHARMACY_RDS_MISMATCH_IN_RECEIVED_QTY_IN_PEDIGREE("PHARMACY-RDS-09","Mismatch in Received quantity in Pedigree table"),
		PHARMACY_RDS_MISMATCH_IN_PTAG_STATUS("PHARMACY-RDS-10","Mismatch in Pallet status code in RDS"),
		PHARMACY_VALIDATE_UNITS_PER_CASE("PHARMACY-RCV-01","Validate units per case"),
		PHARMACY_RECEIVING_FINALIZE_DELIVERY_FAILED("PHARMACY_RCV-02", "Receiving: Delivery Finalization is failed"),
		PHARMACY_CLOSE_DELIVERY_FAILED("PHARMACY_RCV-03", "Receiving: Close Delivery Failed "),
		PHARMACY_VALIDATE_TOTAL_CASES("PHARMACY-RCV-04","Validate Total cases"),
		PHARMACY_VALIDATE_PALLET_RECEIVED("PHARMACY-RCV-05","Validate Pallet is received"),
		PHARMACY_REC_MISMATCH_IN_CONTAINER_STATUS("PHARMACY-RCV-06","Mismatch in containerStatus for Cancelled Label in Receiving"),
		PHARMACY_CASE_OVERAGE_VALIDATION_FAILED("PHARMACY-RCV-07","Case Overage Validation Failed"),
		PHARMACY_TOTAL_CASES_VALIDATION_FAILED("PHARMACY-RCV-08","Total Cases on Confirm Trailer Screen Validation Failed"),
		PHARMACY_RECEIVED_CASES_VALIDATION_FAILED("PHARMACY-RCV-09","Total Received Cases on Confirm Trailer Screen Validation Failed"),
		PHARMACY_TRAILER_VALIDATION_FAILED("PHARMACY-RCV-10","Trailer Number Validation Failed"),
		PHARMACY_UPDATE_GTIN_MESSAGE_VALIDATION_FAILED("PHARMACY-RCV-11","Update GTIN Message Validation Failed"),
		PHARMACY_GTIN_ITEM_DETAILS_VALIDATION_FAILED("PHARMACY-RCV-12","GTIN in Item Details Validation Failed"),
		PHARMACY_VALIDATE_MANUAL_SLOTTING("PHARMACY-RCV-13","Change the slot to Manual slot has been failed"),
		PHARMACY_RECIVING_RECEIPT_QTY_VALIDATION_FAILED("PHARMACY-RCV-13","Qty Mismatch in Receiving RECEIPT Table"),
		PHARMACY_RECIVING_INSTRUCTION_QTY_VALIDATION_FAILED("PHARMACY-RCV-14","Qty Mismatch in Receiving Instruction Table"),
		PHARMACY_RECIVING_CONTAINER_NO_DATA_VALIDATION_FAILED("PHARMACY-RCV-15","Data found in Receiving Container Table"),
		PHARMACY_RECIVING_CONTAINERITEM_NO_DATA_VALIDATION_FAILED("PHARMACY-RCV-16","Data found in Receiving Container Item Table"),
		PHARMACY_REOPEN_DELIVERY_VALIDATION_FAILED("PHARMACY-RCV-17","Re-open delivery has been failed"),
		PHARMACY_SMART_SLOTTING_VALIDATION_FAILED("PHARMACY-SLOTTING-01","Smart Slotting Slot Details Validation failed"),

    	RDC_UNABLE_CREATE_SHIPMENT("RDC-GDM-01","Unable to create Shipment"),

		//Catalyst_MDM
		CATALYST_ITEM_FETCH_FAILED("CATALYST-ITEMMDM-01","Unable to Fetch item details from item mdm"),
	
		//Catalyst oms errorcodes
		Catalyst_GET_OMS("Catalyst-OMS-01", "Not able to fetch Catalyst OMS PO"),
	
		///Catalyst BY_UI
		CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_STATUS("CATALYST-BY_UI-01","Inbound shipment status mismatch!!"),
		CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_EQUIPMENT_STATUS("CATALYST-BY_UI-02","Equipment status mismatch!!"),
		CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_ITEM_NUMBER("CATALYST-BY_UI-03","Mismatch occurs in item numbers!!"),
		CATALYST_MISMATCH_IN_INBOUND_SHIPMENT_PO_NUMBER("CATALYST-BY_UI-04","Mismatch occurs in PO numbers!!"),
		CATALYST_WRONG_DELIVERY_SHIPMENT_RECORD("CATALYST-BY_UI-05","Correct record for shipment number is not showing!!"),
		CATALYST_TRAILER_NOT_AT_PROPER_LOCATION("CATALYST-BY_UI-06","Expected trailer number is not showing at proper location!!"),
		CATALYST_TRAILER_AT_WRONG_LOCATION("CATALYST-BY_UI-07","Expected trailer is at wrong location!!!!"),
		CATALYST_WRONG_ORDER_RECORD("CATALYST-BY_UI-08","Correct record for searched order is not showing!!"),
		CATALYST_WRONG_WAVE_RECORD("CATALYST-BY_UI-09","Correct wave record is not showing!!"),
		CATALYST_MISMATCH_IN_WAVE_STATUS("CATALYST-BY_UI-10","Wave status mismatch!!"),
		CATALYST_WRONG_WAVE_ALLOCATION_PERCENTAGE("CATALYST-BY_UI-11","Wave allocation percenatge is not showing 100 after successfully allocated!!"),
		CATALYST_MISMATCH_IN_TASK_COUNT_FOR_PICKS_GRID("CATALYST-BY_UI-12","Mismatch occurs for picks grid task count after wave allocation !!"),
		CATALYST_WRONG_WORK_ASSIGNMENT_RECORD("CATALYST-BY_UI-13","Correct work assignement record for released wave is not showing under work queue tab!!"),
		CATALYST_MMISMATCH_IN_WORK_ASSIGNMENT_STATUS("CATALYST-BY_UI-14","Mismatch in work assignment status under work queue tab!!"),
		CATALYST_LABEL_MISMATCH("CATALYST-APP_UI-15","Label Mismatch"),
		CATALYST_PROBLEM_ITEM_NUM_MISMATCH("CATALYST-APP_UI-16","Returned wrong Item No. while receving in problem status!"),
		CATALYST_HOLD_TAG_MISMATCH("CATALYST-BY_UI-17","Hold tag is not available!!"),
		


		CATALYST_SCT_UNLOAD_USERID_MISMATCH("CATALYST-SCT-01","Mismatch in SCT Unload User ID"),
		CATALYST_SCT_DOOR_OPEN_USERID_MISMATCH("CATALYST-SCT-02","Mismatch in SCT Open Door User ID"),
		CATALYST_SCT_MASTER_CONTAINER_ID_MISMATCH("CATALYST-SCT-03","Mismatch in SCT Master Container Id"),
		CATALYST_SCT_RECEIVED_ITEM_NUMBER_MISMATCH("CATALYST-SCT-04","Mismatch in SCT Received Item Number"),
		CATALYST_SCT_RECEIVED_ITEM_QTY_USERID_MISMATCH("CATALYST-SCT-05","Mismatch in SCT Received Item Qty in eaches"),
		CATALYST_SCT_PO_NUMBER_MISMATCH("CATALYST-SCT-06","Mismatch in SCT PO Number"),
		CATALYST_SCT_DOOR_NUM_MISMATCH("CATALYST-SCT-07","Mismatch in SCT Door Number"),
		CATALYST_SCT_DELIVERY_STATUS_MISMATCH("CATALYST-SCT-08","Mismatch in SCT Delivery Status"),
		CATALYST_SCT_DOOR_CLOSE_USER_ID_MISMATCH("CATALYST-SCT-09","Mismatch in SCT Door Close User Id"),
		CATALYST_SCT_DELIVERY_COMPLETE_USER_ID_MISMATCH("CATALYST-SCT-10","Mismatch in SCT Delivery Complete User Id"),
		CATALYST_SCT_DOOR_CLOSE_REASON_MISMATCH("CATALYST-SCT-11","Mismatch in SCT Delivery Door Close Reason"),
		CATALYST_SCT_TOTAL_DAMAGE_QTY_MISMATCH("CATALYST-SCT-12","Mismatch in SCT Total Damage Qty"),
		CATALYST_SCT_PICKED_UNIT_QTY_MISMATCH("CATALYST-SCT-13","Mismatch in SCT Picked Unit Qty"),
		CATALYST_SCT_ORDER_ITEM_NUMBER_MISMATCH("CATALYST-SCT-14","Mismatch in SCT Order Item Number"),
		CATALYST_SCT_ALLOC_ORDER_ID_MISMATCH("CATALYST-SCT-15","Mismatch in SCT Alloc Order Id"),
		CATALYST_SCT_CONTAINER_ID_MISMATCH("CATALYST-SCT-16","Mismatch in SCT Container Id"),
		CATALYST_SCT_PICK_STATUS_MISMATCH("CATALYST-SCT-17","Mismatch in SCT Pick Status"),
		CATALYST_SCT_STORE_ORDER_NUMBER_MISMATCH("CATALYST-SCT-18","Mismatch in SCT Store Order Number"),
		CATALYST_SCT_ALLOCATION_ORDER_STATUS_MISMATCH("CATALYST-SCT-19","Mismatch in SCT Allocation Order Status"),
		CATALYST_SCT_ALLOC_TO_PICK_QTY_MISMATCH("CATALYST-SCT-20","Mismatch in SCT Alloc To Pick Qty"),	
		CATALYST_SCT_DESTINATION_STORE_NUMBER_MISMATCH("CATALYST-SCT-21","Mismatch in SCT Destination Store Number"),
		CATALYST_SCT_STORE_ORDER_STATUS_MISMATCH("CATALYST-SCT-22","Mismatch in SCT Store Order Status"),
		CATALYST_SCT_ORDER_QTY_MISMATCH("CATALYST-SCT-23","Mismatch in SCT Order Quantity"),
		CATALYST_SCT_ALLOCATION_ORDER_ID_MISMATCH("CATALYST-SCT-24","Mismatch in SCT Allocation Order ID"),
		CATALYST_SCT_STORE_ORDER_LINE_ORDER_STATUS_MISMATCH("CATALYST-SCT-25","Mismatch in SCT Store Order Line Order Status"),
		CATALYST_SCT_ALLOCATION_ORDER_LINE_STATUS_MISMATCH("CATALYST-SCT-26","Mismatch in SCT Allocation Order LINE Status"),
		CATALYST_SCT_TOTAL_ALLOC_QTY_MISMATCH("CATALYST-SCT-27","Mismatch in SCT Total Allocation Quantity"),
		CATALYST_SCT_INVENTORY_STATUS_MISMATCH("CATALYST-SCT-28","Mismatch in SCT Inventory Status"),
		
		
		//Catalyst BY_Webservices
		CATALYST_BY_SERVICE_NOT_AUTHORIZED("CATALYST-BY_SERVICE-01","User not authorized"),
		CATALYST_BY_SERVICE_DELIVERY_NOT_FOUND("CATALYST-BY_SERVICE-02","Unable to fetch delivery details through BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_DELIVERY_STATUS("CATALYST-BY_SERVICE-03","Mismatch in delivery status under BY service"),
		CATALYST_BY_SERVICE_EQUIPMENT_NOT_FOUND("CATALYST-BY_SERVICE-04","Unable to fetch transport equipment details through BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_IBD_SHIPMENT_PO_NUMBER("CATALYST-BY_SERVICE-05","Mismatch in inbound shipment PO number under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_IBD_SHIPMENT_ITEM_NUMBER("CATALYST-BY_SERVICE-06","Mismatch in inbound shipment item number under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_NUMBER("CATALYST-BY_SERVICE-07","Mismatch in transport equipment number under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_LOCATION("CATALYST-BY_SERVICE-08","Mismatch in transport equipment location under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_SAFETY_CHECK_STATUS("CATALYST-BY_SERVICE-09","Mismatch in transport equipment safety check status under BY service"),
		CATALYST_BY_CONTAINER_DETAILS_NOT_FOUND("CATALYST-BY_SERVICE-10","Unable to fetch container details through BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPNs("CATALYST-BY_SERVICE-11","Mismatch in received LPNs under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPN_LOCATION("CATALYST-BY_SERVICE-12","Mismatch in received LPNs location under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPN_STATUS("CATALYST-BY_SERVICE-13","Mismatch in received LPN status under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_RECEIVED_LPN_QUANTITY("CATALYST-BY_SERVICE-14","Mismatch in received LPN quantity under BY service"),
		CATALYST_BY_SERVICE_PROBLEM_PO_NOT_FOUND("CATALYST-BY_SERVICE-15","Problem PO not generated under BY service"),
		CATALYST_BY_SERVICE_PROBLEM_ITEM_NOT_FOUND("CATALYST-BY_SERVICE-16","Problem Item not generated under BY service"),
		CATALYST_BY_SERVICE_MISMATCH_IN_EQUIPMENT_STATUS("CATALYST-BY_SERVICE-17","Mismatch in transport equipment status under BY service"),


		//GFCS
		GFCS_CREATE_DAMAGE_STATUS_CODE_MISMATCH("DAMAGE-03","GFCS - Unable to create damage"),
		
		
		
		
		//Catalyst Mobile
		CATALYST_MOBILE_RECEIVING_MISMATCH_IN_RECEIVED_CASES("CATALYST-MOBILE_RECEIVING-01","Mismatch in item received cases in receiving screen"),
		CATALYST_MOBILE_RECEIVING_ROC_SCREEN_NOT_VISIBLE("CATALYST-MOBILE_RECEIVING-02","User is not being navigated to confirm ROC screen"),
		CATALYST_MOBILE_RECEIVING_MISMATCH_IN_SHIPMENT_NUMBER_UNDER_CONFIRM_ROC_SCREEN("CATALYST-MOBILE_RECEIVING-03","Mismatch in shipment number under confirm ROC screen"),
		CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ROC_PALLETS_COUNT("CATALYST-MOBILE_RECEIVING-04","Mismatch in received ROC pallets under confirm ROC screen"),
		CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ROC_LPN("CATALYST-MOBILE_RECEIVING-05","Mismatch in received ROC LPN under confirm ROC screen"),
		CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ITEM_NUMBER_FOR_ROC_LPN("CATALYST-MOBILE_RECEIVING-06","Mismatch in item number for received ROC LPN under confirm ROC screen"),
		CATALYST_MOBILE_RECEIVING_MISMATCH_IN_ROC_LPN_STORAGE_LOCATION("CATALYST-MOBILE_RECEIVING-07","Mismatch in received ROC LPN storage location after completing shipment"),
		
		
		CATALYST_MOBILE_BY_APP_LOGOUT_POPUP_NOT_VISIBLE("CATALYST-MOBILE_BY_APP-01","Logout popup not visible"),
		CATALYST_MOBILE_BY_APP_DIRECTED_WORK_OPTION_NOT_VISIBLE("CATALYST-MOBILE_BY_APP-02","Directed work option not visible"),
		
		
		//Catalyst EI
		CATALYST_EI_INVENTORY_DETAILS_NOT_FOUND("CATALYST-EI-01","Unable to fetch EI inventory details for searched item"),
		CATALYST_EI_MISMATCH_IN_TURN_QUANTITY("CATALYST-EI-02","Turn quantity for the item is not getting updated in EI after receiving the LPNs"),
		CATALYST_EI_MISMATCH_IN_INVENTORY_STATUS("CATALYST-EI-03","Mismatch in inventory status in EI after receiving the LPNs"),
		CATALYST_EI_MISMATCH_IN_INVENTORY_LAST_UPDATED_DATE("CATALYST-EI-04","Mismatch in last updated date in EI inventory after receiving the LPNs"),
		
		
		


		CATALYST_OB_TEST_FLOW_DATA_CREATION_FAILED("CATALYST-OB-TESTFLOWDATA-01","Unable to create new or fetch existing test flow data for outbound flow"),



	// DPB ERROR CODES
	DPB_UNABLE_GET_RELEASE("DPB_RELEASE_01","Triggering Release to Atlas Failed"),
	DPB_UNABLE_FIND_TRIP_AP("AP_02","Trip not found in AP DB"),
	DPB_UNABLE_FIND_TRIP_FES("FES_03","Trip not found in FES DB"),
	DPB_INCORRECT_TRIP_STATUS_FES("FES_04","Trip status is incorrect in FES DB"),
	DPB_TRIP_UNITS_LESS_THAN_EXPECTED_FES("FES_05","Trip Units Count is not correct in FES DB"),
	DPB_PALLET_STILL_RE_OPTIMIZING_FES("FES_06","Pallet is still re-optimizing after last short event"),
	DPB_TRIP_UNIT_NOT_CANCELLED_FES("FES_07","All trip units are not yet cancelled");


	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return getErrorCode() + ":-" + errorMessage;
	}

	public Priority getPriority() {
		return this.priority;
	}
	
	public Map<String,String> getDescription() {
		return this.description;
	}
	public Boolean isScreenshotRequired() {
		return this.isScreenshotRequired;
	}

	private String errorCode;
	private String errorMessage;
	private Priority priority;
	private Map<String,String> description;
	private Boolean isScreenshotRequired;
	ErrorCodes(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.priority = Priority.P2;
		this.description=new ConcurrentHashMap<>();
	}

	ErrorCodes(String errorCode, String errorMessage, Priority priority) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.priority = priority;
		this.description=new ConcurrentHashMap<>();
	}
	
	ErrorCodes(String errorCode,String errorMessage,Priority priority,boolean isScreenshotRequired){
		this.errorCode=errorCode;
		this.errorMessage=errorMessage;
		this.priority=priority;
		this.isScreenshotRequired=isScreenshotRequired;
		this.description=new ConcurrentHashMap<>();
	}
	
	ErrorCodes(String errorCode,String errorMessage,boolean isScreenshotRequired){
		this.errorCode=errorCode;
		this.errorMessage=errorMessage;
		this.isScreenshotRequired=isScreenshotRequired;
		this.description=new ConcurrentHashMap<>();
	}

	public static ErrorCodes getErrorCodeFromKey(String errorCode) {
		for (ErrorCodes err : ErrorCodes.values()) {
			if (err.getErrorCode().equalsIgnoreCase(errorCode))
				return err;
		}
		return null;
	}
	

	public static boolean isValidErrorCode(String errorCode) {
		for (ErrorCodes err : ErrorCodes.values()) {
			if (err.getErrorCode().equalsIgnoreCase(errorCode))
				return true;
		}
		return false;
	}
	public static ErrorCodes addDescription(ErrorCodes errorCode,String featureName,String desc) {
		errorCode.description.put(featureName, desc);
		return errorCode;
	}
	public static ErrorCodes isScreenshotRequiredForThisErrorCode(ErrorCodes errorCode,boolean isRequired) {
		errorCode.isScreenshotRequired=isRequired;
		return errorCode;
	}
	public static ErrorCodes appendErrorCodeMessage(ErrorCodes errorCode,String messageAppender) {
		errorCode.errorMessage=errorCode.getErrorMessage()+messageAppender;
		return errorCode;
	}
	public static ErrorCodes updateErrorCodeMessage(ErrorCodes errorCode,String newMessage) {
		errorCode.errorMessage=newMessage;
		return errorCode;
	}

	public enum Priority {
		P1, P2, P3, P4;

		public String getValue() {
			return this.name();
		}
	}
}
