package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "urlPattern","method" })
public class Request {
		@JsonProperty("urlPattern")
		private String urlPattern;
		@JsonProperty("method")
		private String method;
		public String getUrlPattern() {
			return urlPattern;
		}
		public void setUrlPattern(String urlPattern) {
			this.urlPattern = urlPattern;
		}
		public String getMethod() {
			return method;
		}
		public void setMethod(String method) {
			this.method = method;
		}
}
