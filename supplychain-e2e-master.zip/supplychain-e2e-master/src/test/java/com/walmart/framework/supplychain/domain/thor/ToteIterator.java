package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "areaStart", "areaCode", "areaName", "areaThrough", "positionIncrement"})
public class ToteIterator {
	@JsonProperty("areaStart")
	private int areaStart;
	@JsonProperty("areaCode")
	private String areaCode;
	@JsonProperty("areaName")
	private String areaName;
	@JsonProperty("areaThrough")
	private int areaThrough;
	@JsonProperty("positionIncrement")
	private int positionIncrement;
	
	@JsonProperty("areaStart")
	public int getAreaStart() {
		return areaStart;
	}
	@JsonProperty("areaStart")
	public void setAreaStart(int areaStart) {
		this.areaStart = areaStart;
	}
	@JsonProperty("areaCode")
	public String getAreaCode() {
		return areaCode;
	}
	@JsonProperty("areaCode")
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	@JsonProperty("areaName")
	public String getAreaName() {
		return areaName;
	}
	@JsonProperty("areaName")
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	@JsonProperty("areaThrough")
	public int getAreaThrough() {
		return areaThrough;
	}
	@JsonProperty("areaThrough")
	public void setAreaThrough(int areaThrough) {
		this.areaThrough = areaThrough;
	}
	@JsonProperty("positionIncrement")
	public int getPositionIncrement() {
		return positionIncrement;
	}
	@JsonProperty("positionIncrement")
	public void setPositionIncrement(int positionIncrement) {
		this.positionIncrement = positionIncrement;
	}
	

}
