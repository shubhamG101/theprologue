package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "routes" })
public class RouteCarrier {
	@JsonProperty("routes")
	private List<AssignCarrier> routes;

	public List<AssignCarrier> getRoutes() {
		return routes;
	}

	public void setRoutes(List<AssignCarrier> routes) {
		this.routes = routes;
	}
}
