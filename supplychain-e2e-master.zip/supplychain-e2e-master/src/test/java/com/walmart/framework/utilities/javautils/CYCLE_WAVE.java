package com.walmart.framework.utilities.javautils;

public enum CYCLE_WAVE {

    MON("111/112"),TUE("222/222"),WED("333/332"),THU("444/442"),FRI("555/552"),SAT("666/662"),SUN("777/772");

    String dayOfWeek;

    CYCLE_WAVE(String dayOfWeek){
        this.dayOfWeek = dayOfWeek;
    }
    public String getValue() {
		return dayOfWeek;
	}
}
