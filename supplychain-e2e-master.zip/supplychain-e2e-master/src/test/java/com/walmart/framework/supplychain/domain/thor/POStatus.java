package com.walmart.framework.supplychain.domain.thor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "poNumber", "poStatusUpdateRequest"})
public class POStatus {
	
	@JsonProperty("poNumber")
	private int poNumber;
	@JsonProperty("poStatusUpdateRequest")
	private StatusRequest poStatusUpdateRequest;
	
	@JsonProperty("poNumber")
	public int getPoNumber() {
		return poNumber;
	}
	@JsonProperty("poNumber")
	public void setPoNumber(int poNumber) {
		this.poNumber = poNumber;
	}
	@JsonProperty("poStatusUpdateRequest")
	public StatusRequest getPoStatusUpdateRequest() {
		return poStatusUpdateRequest;
	}
	@JsonProperty("poStatusUpdateRequest")
	public void setPoStatusUpdateRequest(StatusRequest poStatusUpdateRequest) {
		this.poStatusUpdateRequest = poStatusUpdateRequest;
	}
}
