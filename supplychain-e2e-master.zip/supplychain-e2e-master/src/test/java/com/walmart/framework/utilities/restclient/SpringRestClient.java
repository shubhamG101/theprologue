package com.walmart.framework.utilities.restclient;

import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.client.RestTemplate;
import spring.SpringTestConfiguration;

import java.util.UUID;

@ContextConfiguration(classes = SpringTestConfiguration.class)
//@RunWith(SpringRunner.class)
public class SpringRestClient {

     Logger logger = LoggerFactory.getLogger(SpringRestClient.class);

    @Autowired
    RestTemplate restTemplate;

    private ResponseEntity doHttpCallToResource(HttpMethod httpMethod, String endPoint, HttpHeaders headers, String payload, Class clazz){

        String uuid = UUID.randomUUID().toString();

        if(headers!=null){
            headers.setContentType(MediaType.APPLICATION_JSON);
        }

        HttpEntity<String> entity = new HttpEntity<>(payload, headers);

        ResponseEntity<?> responseEntity = restTemplate.exchange(endPoint, httpMethod, entity, clazz, uuid);

        logger.info(httpMethod.toString() + " call to " + endPoint);

        return responseEntity;
    }

    public ResponseEntity getResource(String ep, Class clazz){
        return doHttpCallToResource(HttpMethod.GET, ep, null, null, clazz);
    }

    public ResponseEntity getResource(String ep, HttpHeaders headers, Class clazz){
        return doHttpCallToResource(HttpMethod.GET, ep, headers, null, clazz);
    }

    public ResponseEntity postResource(String ep, String payload, Class clazz){
        return doHttpCallToResource(HttpMethod.POST, ep, null, payload, clazz);
    }

    public ResponseEntity postResource(String ep, HttpHeaders headers, String payload, Class clazz){
        return doHttpCallToResource(HttpMethod.POST, ep, headers, payload, clazz);
    }

    public ResponseEntity putResource(String ep, String payload, Class clazz){
        return doHttpCallToResource(HttpMethod.PUT, ep, null, payload, clazz);
    }

    public ResponseEntity putResource(String ep, HttpHeaders headers, String payload, Class clazz){
        return doHttpCallToResource(HttpMethod.PUT, ep, headers, payload, clazz);
    }

    public ResponseEntity deleteResource(String ep, HttpHeaders headers, String payload, Class clazz){
        return doHttpCallToResource(HttpMethod.PUT, ep, headers, payload, clazz);
    }

    public ResponseEntity deleteResource(String ep, String payload, Class clazz){
        return doHttpCallToResource(HttpMethod.PUT, ep, null, payload, clazz);
    }

    //@Test
    public void executeHttpCalls(){

        ResponseEntity responseEntity;

        HttpHeaders headers = new HttpHeaders();
        headers.add("Accept", "application/json");


//        System.out.println("*********** Get Call *****************");
//responseEntity = getResource("http://www.google.com", String.class);
//        System.out.println(responseEntity.getBody().toString());
//
//
//        System.out.println("*********** Get Call with Headers *****************");
//
//
//        responseEntity = getResource("http://www.google.com",headers, String.class);
//        System.out.println(responseEntity.getBody().toString());



        System.out.println("*********** Post Call *****************");
        responseEntity = postResource("https://jsonplaceholder.typicode.com/posts", "{\n      title: \'foo\',\n      body: \'bar\',\n      userId: 1\n    }", String.class);
        System.out.println(responseEntity.getBody().toString());


        System.out.println("*********** Post Call with Headers *****************");


        responseEntity = postResource("http://devcicweb1.wal-mart.com:58022/GENERIC/OMSPubSubGenericRead2/3857760045?LegacyPO=Y",headers,"{\n      title: \'foo\',\n      body: \'bar\',\n      userId: 10001\n    }", String.class);
        System.out.println(responseEntity.getBody().toString());



    }

}
