package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "problemResolutionType", "poNbr", "poLineNbr", "resolutionQty" })
public class ProblemResolutionDetail {

	@JsonProperty("problemResolutionType")
	private String problemResolutionType;
	@JsonProperty("poNbr")
	private String poNbr;
	@JsonProperty("poLineNbr")
	private int poLineNbr;
	@JsonProperty("resolutionQty")
	private int resolutionQty;
	
	
	@JsonProperty("problemResolutionType")
	public String getProblemResolutionType() {
		return problemResolutionType;
	}
	@JsonProperty("problemResolutionType")
	public void setProblemResolutionType(String problemResolutionType) {
		this.problemResolutionType = problemResolutionType;
	}
	@JsonProperty("poNbr")
	public String getPoNbr() {
		return poNbr;
	}
	@JsonProperty("poNbr")
	public void setPoNbr(String poNbr) {
		this.poNbr = poNbr;
	}
	@JsonProperty("poLineNbr")
	public int getPoLineNbr() {
		return poLineNbr;
	}
	@JsonProperty("poLineNbr")
	public void setPoLineNbr(int poLineNbr) {
		this.poLineNbr = poLineNbr;
	}
	@JsonProperty("resolutionQty")
	public int getResolutionQty() {
		return resolutionQty;
	}
	@JsonProperty("resolutionQty")
	public void setResolutionQty(int resolutionQty) {
		this.resolutionQty = resolutionQty;
	}
	
}