package com.walmart.framework.supplychain.domain.thor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "salesDate", "salesDocNum", "salesDocType", "lines",})
public class Sales {
	
	@JsonProperty("salesDate")
	private String salesDate;
	@JsonProperty("salesDocNum")
	private String salesDocNum;
	@JsonProperty("salesDocType")
	private String salesDocType;
	@JsonProperty("lines")
	private List<SalesLine> lines;
	
	@JsonProperty("salesDate")
	public String getSalesDate() {
		return salesDate;
	}
	@JsonProperty("salesDate")
	public void setSalesDate(String salesDate) {
		this.salesDate = salesDate;
	}
	@JsonProperty("salesDocNum")
	public String getSalesDocNum() {
		return salesDocNum;
	}
	@JsonProperty("salesDocNum")
	public void setSalesDocNum(String salesDocNum) {
		this.salesDocNum = salesDocNum;
	}
	@JsonProperty("salesDocType")
	public String getSalesDocType() {
		return salesDocType;
	}
	@JsonProperty("salesDocType")
	public void setSalesDocType(String salesDocType) {
		this.salesDocType = salesDocType;
	}
	@JsonProperty("lines")
	public List<SalesLine> getLines() {
		return lines;
	}
	@JsonProperty("lines")
	public void setLines(List<SalesLine> lines) {
		this.lines = lines;
	}
}

