
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "poLineNumber", "itemNumber", "destNumber", "poDestStatus", "destCountryCode", "poLineStatus",
		"poEvent", "poVnpkQty", "poWhpkQty", "vnpk", "whpk", "whpkSellPrice", "ovgQty", "omsChannelMethod",
		"channelMethod", "ti", "hi", "departmentNumber", "isConveyable", "itemUpc", "caseUpc", "receivingInstructions",
		"overageFlag", "poUpdateQty", "thorSKU", "thorUnitsPer", "boh", "wac", "promoInd", "witronItemDetails","catalystItemDetails",
		"freightBillQty", "isVariableWeight", "weight", "warehouseRotationType", "warehouseArea", "warehouseGroupCode",
		"witronItemDetails","damageQty","shortQty","rejectQty", "waw", "totalWeight", "averageWeightPerCase", "croInd", "recvQty", 
		"osdrInd", "problemQty","problemLabel","problemJobID","problemType", "recvType", "primeLocation"})
public class PoLineDetail {

	@JsonProperty("overageFlag")
	private String overageFlag;
	
	
	@JsonProperty("damageQty")
	private String damageQty;
	
	@JsonProperty("shortQty")
	private String shortQty;
	
	@JsonProperty("rejectQty")
	private String rejectQty;
	
	@JsonProperty("poLineNumber")
	private String poLineNumber;
	@JsonProperty("itemNumber")
	private String itemNumber;
	@JsonProperty("destNumber")
	private String destNumber;
	@JsonProperty("poDestStatus")
	private String poDestStatus;
	@JsonProperty("destCountryCode")
	private String destCountryCode;
	@JsonProperty("poLineStatus")
	private String poLineStatus;
	@JsonProperty("poEvent")
	private String poEvent;
	@JsonProperty("poVnpkQty")
	private String poVnpkQty;
	@JsonProperty("poWhpkQty")
	private String poWhpkQty;
	@JsonProperty("vnpk")
	private String vnpk;
	@JsonProperty("whpk")
	private String whpk;
	@JsonProperty("whpkSellPrice")
	private String whpkSellPrice;
	@JsonProperty("ovgQty")
	private String ovgQty;
	@JsonProperty("omsChannelMethod")
	private String omsChannelMethod;
	@JsonProperty("channelMethod")
	private String channelMethod;
	@JsonProperty("ti")
	private String ti;
	@JsonProperty("hi")
	private String hi;
	@JsonProperty("departmentNumber")
	private String departmentNumber;
	@JsonProperty("isConveyable")
	private String isConveyable;
	@JsonProperty("itemUpc")
	private String itemUpc;
	@JsonProperty("thorSKU")
	private String thorSKU;
	@JsonProperty("poUpdateQty")
	private String poUpdateQty;
	@JsonProperty("thorUnitsPer")
	private int thorUnitsPer;
	@JsonProperty("boh")
	private int boh;
	@JsonProperty("wac")
	private double wac;
	@JsonProperty("promoInd")
	private String promoInd;
	@JsonProperty("isVariableWeight")
	private boolean isVariableWeight;
	@JsonProperty("weight")
	private double weight;
	@JsonProperty("cube")
	private double cube;
	@JsonProperty("warehouseArea")
	private String warehouseArea;
	@JsonProperty("warehouseGroupCode")
	private String warehouseGroupCode;
	@JsonProperty("profiledWarehouseArea")
	private String profiledWarehouseArea;
	@JsonProperty("warehouseMinLifeRemainingToReceive")
	private String warehouseMinLifeRemainingToReceive;
	@JsonProperty("warehouseAreaCode")
	private String warehouseAreaCode;
	@JsonProperty("recvType")
	private String recvType;
	
	@JsonProperty("primeLocation")
	private String primeLocation;
	
	@JsonProperty("warehouseRotationTypeCode")
	private String warehouseRotationTypeCode;
	@JsonProperty("witronItemDetails")
	private WitronItemDetails witronItemDetails;
	@JsonProperty("catalystItemDetails")
	private CatalystItemDetails catalystItemDetails;
	
	public  CatalystItemDetails getCatalystItemDetails() {
		return catalystItemDetails;
	}

	public void setCatalystItemDetails(CatalystItemDetails catalystItemDetails) {
		this.catalystItemDetails = catalystItemDetails;
	}

	@JsonProperty("receivingInstructions")
	private List<ReceivingInstruction> receivingInstructions = new ArrayList<ReceivingInstruction>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	@JsonProperty("caseUpc")
	private String caseUpc;
	@JsonProperty("freightBillQty")
	private String freightBillQty;
	@JsonProperty("waw")
	private double waw;
	@JsonProperty("totalWeight")
	private double totalWeight;
	@JsonProperty("averageWeightPerCase")
	private double averageWeightPerCase;
	@JsonProperty("croInd")
	private String croInd;
	@JsonProperty("recvQty")
	private int recvQty;
	@JsonProperty("osdrInd")
	private String osdrInd;
	@JsonProperty("problemQty")
	private String problemQty;
	
	@JsonProperty("problemLabel")
	private String problemLabel;
	
	@JsonProperty("problemJobID")
	private String problemJobID;
	
	@JsonProperty("problemType")
	private String problemType;

	public String getwarehouseAreaCode() {
		return warehouseAreaCode;
	}

	public void setwarehouseAreaCode(String warehouseAreaCode) {
		this.warehouseAreaCode = warehouseAreaCode;
	}
	
	
	public String getWarehouseArea() {
		return warehouseArea;
	}

	public void setWarehouseArea(String warehouseArea) {
		this.warehouseArea = warehouseArea;
	}
	
	
	public String getDamageQty() {
		return damageQty;
	}

	public void setDamageQty(String damageQty) {
		this.damageQty = damageQty;
	}
	
	@JsonProperty("shortQty")
	public String getShortQty() {
		return shortQty;
	}
	@JsonProperty("shortQty")
	public void setShortQty(String shortQty) {
		this.shortQty = shortQty;
	}
	
	
	public String getRejectQty() {
		return rejectQty;
	}

	public void setRejectQty(String rejectQty) {
		this.rejectQty = rejectQty;
	}

	public String getWarehouseGroupCode() {
		return warehouseGroupCode;
	}

	public void setWarehouseGroupCode(String warehouseGroupCode) {
		this.warehouseGroupCode = warehouseGroupCode;
	}
	
	public String getWarehouseMinLife() {
		return warehouseMinLifeRemainingToReceive;
	}

	public void setWarehouseMinLife(String warehouseMinLifeRemainingToReceive) {
		this.warehouseMinLifeRemainingToReceive = warehouseMinLifeRemainingToReceive;
	}
	

	public String getWarehouseRotationTypeCode() {
		return warehouseRotationTypeCode;
	}

	public void setWarehouseRotationType(String warehouseRotationTypeCode) {
		this.warehouseRotationTypeCode = warehouseRotationTypeCode;
	}
	
	public String getProfiledWareHouse() {
		return profiledWarehouseArea;
	}

	public void setProfiledWareHouse(String profiledWarehouseArea) {
		this.profiledWarehouseArea = profiledWarehouseArea;
	}
	

	public boolean getIsVariableWeight() {
		return isVariableWeight;
	}

	public void setIsVariableWeight(boolean isVariableWeight) {
		this.isVariableWeight = isVariableWeight;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public double getCube() {
		return cube;
	}

	public void setCube(double cube) {
		this.cube = cube;
	}
	
	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	@JsonProperty("overageFlag")
	public String getOverageFlag() {
		return overageFlag;
	}

	@JsonProperty("overageFlag")
	public void setOverageFlag(String overageFlag) {
		this.overageFlag = overageFlag;
	}

	@JsonProperty("freightBillQty")
	public String getfreightBillQty() {
		return freightBillQty;
	}

	@JsonProperty("freightBillQty")
	public void setfreightBillQty(String freightBillQty) {
		this.freightBillQty = freightBillQty;
	}

	@JsonProperty("poLineNumber")
	public String getPoLineNumber() {
		return poLineNumber;
	}

	@JsonProperty("poLineNumber")
	public void setPoLineNumber(String poLineNumber) {
		this.poLineNumber = poLineNumber;
	}

	public PoLineDetail withPoLineNumber(String poLineNumber) {
		this.poLineNumber = poLineNumber;
		return this;
	}

	@JsonProperty("itemNumber")
	public String getItemNumber() {
		return itemNumber;
	}

	@JsonProperty("itemNumber")
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public PoLineDetail withItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
		return this;
	}

	@JsonProperty("ovgQty")
	public String getOvgQty() {
		return ovgQty;
	}

	@JsonProperty("ovgQty")
	public void setOvgQty(String ovgQty) {
		this.ovgQty = ovgQty;
	}

	public PoLineDetail withOvgQty(String ovgQty) {
		this.ovgQty = ovgQty;
		return this;
	}

	@JsonProperty("destNumber")
	public String getDestNumber() {
		return destNumber;
	}

	@JsonProperty("destNumber")
	public void setDestNumber(String destNumber) {
		this.destNumber = destNumber;
	}

	public PoLineDetail withDestNumber(String destNumber) {
		this.destNumber = destNumber;
		return this;
	}
	@JsonProperty("departmentNumber")
	public String getDepartmentNumber() {
		return departmentNumber;
	}
	@JsonProperty("departmentNumber")
	public void setDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public PoLineDetail withDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
		return this;
	}

	@JsonProperty("poDestStatus")
	public String getPoDestStatus() {
		return poDestStatus;
	}

	@JsonProperty("poDestStatus")
	public void setPoDestStatus(String poDestStatus) {
		this.poDestStatus = poDestStatus;
	}

	public PoLineDetail withPoDestStatus(String poDestStatus) {
		this.poDestStatus = poDestStatus;
		return this;
	}

	public String getDestCountryCode() {
		return destCountryCode;
	}

	public void setDestCountryCode(String destCountryCode) {
		this.destCountryCode = destCountryCode;
	}

	public PoLineDetail withDestCountryCode(String destCountryCode) {
		this.destCountryCode = destCountryCode;
		return this;
	}

	@JsonProperty("poLineStatus")
	public String getPoLineStatus() {
		return poLineStatus;
	}

	@JsonProperty("poLineStatus")
	public void setPoLineStatus(String poLineStatus) {
		this.poLineStatus = poLineStatus;
	}

	public PoLineDetail withPoLineStatus(String poLineStatus) {
		this.poLineStatus = poLineStatus;
		return this;
	}

	@JsonProperty("poEvent")
	public String getPoEvent() {
		return poEvent;
	}

	@JsonProperty("poEvent")
	public void setPoEvent(String poEvent) {
		this.poEvent = poEvent;
	}

	public PoLineDetail withPoEvent(String poEvent) {
		this.poEvent = poEvent;
		return this;
	}

	@JsonProperty("poVnpkQty")
	public String getPoVnpkQty() {
		return poVnpkQty;
	}

	@JsonProperty("poVnpkQty")
	public void setPoVnpkQty(String poVnpkQty) {
		this.poVnpkQty = poVnpkQty;
	}

	public PoLineDetail withPoVnpkQty(String poVnpkQty) {
		this.poVnpkQty = poVnpkQty;
		return this;
	}

	@JsonProperty("poWhpkQty")
	public String getPoWhpkQty() {
		return poWhpkQty;
	}

	@JsonProperty("poWhpkQty")
	public void setPoWhpkQty(String poWhpkQty) {
		this.poWhpkQty = poWhpkQty;
	}

	public PoLineDetail withPoWhpkQty(String poWhpkQty) {
		this.poWhpkQty = poWhpkQty;
		return this;
	}

	@JsonProperty("vnpk")
	public String getVnpk() {
		return vnpk;
	}

	@JsonProperty("vnpk")
	public void setVnpk(String vnpk) {
		this.vnpk = vnpk;
	}

	public PoLineDetail withVnpk(String vnpk) {
		this.vnpk = vnpk;
		return this;
	}

	@JsonProperty("whpk")
	public String getWhpk() {
		return whpk;
	}

	@JsonProperty("whpk")
	public void setWhpk(String whpk) {
		this.whpk = whpk;
	}

	public PoLineDetail withWhpk(String whpk) {
		this.whpk = whpk;
		return this;
	}

	@JsonProperty("whpkSellPrice")
	public String getWhpkSellPrice() {
		return whpkSellPrice;
	}

	@JsonProperty("whpkSellPrice")
	public void setWhpkSellPrice(String whpkSellPrice) {
		this.whpkSellPrice = whpkSellPrice;
	}

	public PoLineDetail withWhpkSellPrice(String whpkSellPrice) {
		this.whpkSellPrice = whpkSellPrice;
		return this;
	}

	@JsonProperty("omsChannelMethod")
	public String getOmsChannelMethod() {
		return omsChannelMethod;
	}

	@JsonProperty("omsChannelMethod")
	public void setOmsChannelMethod(String omsChannelMethod) {
		this.omsChannelMethod = omsChannelMethod;
	}

	public PoLineDetail withOmsChannelMethod(String omsChannelMethod) {
		this.omsChannelMethod = omsChannelMethod;
		return this;
	}

	@JsonProperty("channelMethod")
	public String getChannelMethod() {
		return channelMethod;
	}

	@JsonProperty("channelMethod")
	public void setChannelMethod(String channelMethod) {
		this.channelMethod = channelMethod;
	}

	public PoLineDetail withChannelMethod(String channelMethod) {
		this.channelMethod = channelMethod;
		return this;
	}

	@JsonProperty("ti")
	public String getTi() {
		return ti;
	}

	@JsonProperty("ti")
	public void setTi(String ti) {
		this.ti = ti;
	}

	public PoLineDetail withTi(String ti) {
		this.ti = ti;
		return this;
	}

	@JsonProperty("hi")
	public String getHi() {
		return hi;
	}

	@JsonProperty("hi")
	public void setHi(String hi) {
		this.hi = hi;
	}

	public PoLineDetail withHi(String hi) {
		this.hi = hi;
		return this;
	}

	@JsonProperty("isConveyable")
	public String getIsConveyable() {
		return isConveyable;
	}

	@JsonProperty("isConveyable")
	public void setIsConveyable(String isConveyable) {
		this.isConveyable = isConveyable;
	}

	public PoLineDetail withIsConveyable(String isConveyable) {
		this.isConveyable = isConveyable;
		return this;
	}

	@JsonProperty("itemUpc")
	public String getItemUpc() {
		return itemUpc;
	}

	@JsonProperty("itemUpc")
	public void setItemUpc(String itemUpc) {
		this.itemUpc = itemUpc;
	}

	@JsonProperty("poUpdateQty")
	public String getPoUpdateQty() {
		return poUpdateQty;
	}

	@JsonProperty("poUpdateQty")
	public void setPoUpdateQty(String poUpdateQty) {
		this.poUpdateQty = poUpdateQty;
	}

	public PoLineDetail withItemUpc(String itemUpc) {
		this.itemUpc = itemUpc;
		return this;
	}

	@JsonProperty("receivingInstructions")
	public List<ReceivingInstruction> getReceivingInstructions() {
		return receivingInstructions;
	}

	@JsonProperty("receivingInstructions")
	public void setReceivingInstructions(List<ReceivingInstruction> receivingInstructions) {
		this.receivingInstructions = receivingInstructions;
	}

	public PoLineDetail withReceivingInstructions(List<ReceivingInstruction> receivingInstructions) {
		this.receivingInstructions = receivingInstructions;
		return this;
	}

	@JsonProperty("thorSKU")
	public String getThorSKU() {
		return thorSKU;
	}

	@JsonProperty("thorSKU")
	public void setThorSKU(String thorSKU) {
		this.thorSKU = thorSKU;
	}

	@JsonProperty("thorUnitsPer")
	public int getThorUnitsPer() {
		return thorUnitsPer;
	}

	@JsonProperty("thorUnitsPer")
	public void setThorUnitsPer(int thorUnitsPer) {
		this.thorUnitsPer = thorUnitsPer;
	}

	@JsonProperty("boh")
	public int getBoh() {
		return boh;
	}

	@JsonProperty("boh")
	public void setBoh(int boh) {
		this.boh = boh;
	}

	@JsonProperty("wac")
	public double getWac() {
		return wac;
	}

	@JsonProperty("wac")
	public void setWac(double wac) {
		this.wac = wac;
	}

	@JsonProperty("promoInd")
	public String getPromoInd() {
		return promoInd;
	}

	@JsonProperty("promoInd")
	public void setPromoInd(String promoInd) {
		this.promoInd = promoInd;
	}

	@JsonProperty("witronItemDetails")
	public WitronItemDetails getWitronItemDetails() {
		return witronItemDetails;
	}

	@JsonProperty("witronItemDetails")
	public void setWitronItemDetails(WitronItemDetails witronItemDetails) {
		this.witronItemDetails = witronItemDetails;
	}
	@JsonProperty("waw")
	public double getWaw() {
		return waw;
	}
	@JsonProperty("waw")
	public void setWaw(double waw) {
		this.waw = waw;
	}
	@JsonProperty("totalWeight")
	public double getTotalWeight() {
		return totalWeight;
	}
	@JsonProperty("totalWeight")
	public void setTotalWeight(double totalWeight) {
		this.totalWeight = totalWeight;
	}
	@JsonProperty("averageWeightPerCase")
	public double getAverageWeightPerCase() {
		return averageWeightPerCase;
	}
	@JsonProperty("averageWeightPerCase")
	public void setAverageWeightPerCase(double averageWeightPerCase) {
		this.averageWeightPerCase = averageWeightPerCase;
	}
	@JsonProperty("croInd")
	public String getCroInd() {
		return croInd;
	}
	@JsonProperty("croInd")
	public void setCroInd(String croInd) {
		this.croInd = croInd;
	}
	@JsonProperty("recvQty")
	public int getRecvQty() {
		return recvQty;
	}
	@JsonProperty("recvQty")
	public void setRecvQty(int recvQty) {
		this.recvQty = recvQty;
	}
	@JsonProperty("osdrInd")
	public String getOsdrInd() {
		return osdrInd;
	}
	@JsonProperty("osdrInd")
	public void setOsdrInd(String osdrInd) {
		this.osdrInd = osdrInd;
	}
	@JsonProperty("problemQty")
	public String getProblemQty() {
		return problemQty;
	}
	@JsonProperty("problemQty")
	public void setProblemQty(String problemQty) {
		this.problemQty = problemQty;
	}

	@JsonProperty("problemLabel")
	public String getproblemLabel() {
		return problemLabel;
	}
	@JsonProperty("problemLabel")
	public void setproblemLabel(String problemLabel) {
		this.problemLabel = problemLabel;
	}
	
	@JsonProperty("problemJobID")
	public String getproblemJobID() {
		return problemJobID;
	}
	@JsonProperty("problemJobID")
	public void setproblemJobID(String problemJobID) {
		this.problemJobID = problemJobID;
	}
	
	@JsonProperty("problemType")
	public String getproblemType() {
		return problemType;
	}
	@JsonProperty("problemType")
	public void setproblemType(String problemType) {
		this.problemType = problemType;
	}
	@JsonProperty("recvType")
	public String getRecvType() {
		return recvType;
	}
	@JsonProperty("recvType")
	public void setRecvType(String recvType) {
		this.recvType = recvType;
	}
	
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	public PoLineDetail withAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
		return this;
	}
	
	public String getPrimeLocation() {
		return primeLocation;
	}

	public void setPrimeLocation(String primeLocation) {
		this.primeLocation = primeLocation;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("poLineNumber", poLineNumber).append("itemNumber", itemNumber).append("primeLocation", primeLocation)
				.append("destNumber", destNumber).append("poDestStatus", poDestStatus)
				.append("poLineStatus", poLineStatus).append("poEvent", poEvent).append("poVnpkQty", poVnpkQty)
				.append("poWhpkQty", poWhpkQty).append("vnpk", vnpk).append("whpk", whpk)
				.append("whpkSellPrice", whpkSellPrice).append("omsChannelMethod", omsChannelMethod)
				.append("channelMethod", channelMethod).append("ti", ti).append("hi", hi)
				.append("isConveyable", isConveyable).append("itemUpc", itemUpc)
				.append("receivingInstructions", receivingInstructions)
				.append("additionalProperties", additionalProperties).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(itemNumber).append(primeLocation).append(hi).append(receivingInstructions).append(isConveyable)
				.append(poDestStatus).append(vnpk).append(whpkSellPrice).append(poLineNumber).append(destNumber)
				.append(omsChannelMethod).append(poWhpkQty).append(poLineStatus).append(channelMethod).append(ti)
				.append(itemUpc).append(poVnpkQty).append(whpk).append(additionalProperties).append(poEvent)
				.toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof PoLineDetail) == false) {
			return false;
		}
		PoLineDetail rhs = ((PoLineDetail) other);
		return new EqualsBuilder().append(itemNumber, rhs.itemNumber).append(primeLocation, rhs.primeLocation).append(hi, rhs.hi)
				.append(receivingInstructions, rhs.receivingInstructions).append(isConveyable, rhs.isConveyable)
				.append(poDestStatus, rhs.poDestStatus).append(vnpk, rhs.vnpk).append(whpkSellPrice, rhs.whpkSellPrice)
				.append(poLineNumber, rhs.poLineNumber).append(destNumber, rhs.destNumber)
				.append(omsChannelMethod, rhs.omsChannelMethod).append(poWhpkQty, rhs.poWhpkQty)
				.append(poLineStatus, rhs.poLineStatus).append(channelMethod, rhs.channelMethod).append(ti, rhs.ti)
				.append(itemUpc, rhs.itemUpc).append(poVnpkQty, rhs.poVnpkQty).append(whpk, rhs.whpk)
				.append(additionalProperties, rhs.additionalProperties).append(poEvent, rhs.poEvent).isEquals();
	}
}
