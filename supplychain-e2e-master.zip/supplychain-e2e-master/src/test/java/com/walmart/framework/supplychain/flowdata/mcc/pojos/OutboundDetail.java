
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import com.walmart.framework.supplychain.domain.witron.InventoryBOH;
import com.walmart.framework.supplychain.domain.witron.Route;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "trailerNumber", "destNumber", "loadId", "tmsLoadId", "outboundDoorNumber", "sealNumber",
		"asnNumber", "containerIds", "unloadedContainers", "rdcDeliveryDetail", "laneNumber", "bolNumber", "asnDocID",
		"mcbContainerID", "witronBatchName", "cycleWave", "releaseNbr", "containersCount", "routes", "scoreJobId", "balanceOnHand", "waveNumber_BY", "loadID_BY",
		"sourceLocationForPicking", "destinationLocationForPicking", "operationNumForPicking" , "fulfillmentId","outboundYardZone" })

public class OutboundDetail {

	@JsonProperty("trailerNumber")
	private String trailerNumber;
	@JsonProperty("destNumber")
	private String destNumber;
	@JsonProperty("loadId")
	private String loadId;
	@JsonProperty("tmsLoadId")
	private String tmsLoadId;
	@JsonProperty("outboundDoorNumber")
	private String outboundDoorNumber;
	@JsonProperty("sealNumber")
	private String sealNumber;
	@JsonProperty("asnNumber")
	private String asnNumber;
	@JsonProperty("laneNumber")
	private String laneNumber;
	@JsonProperty("witronBatchName")
	private String witronBatchName;
	@JsonProperty("cycleWave")
	private String cycleWave;
	@JsonProperty("releaseNbr")
	private String releaseNbr;
	@JsonProperty("containersCount")
	private String containersCount;
	@JsonProperty("fulfillmentId")
	private String fulfillmentId;
	@JsonProperty("routes")
	private List<Route> routes;
	@JsonProperty("scoreJobId")
	private String scoreJobId;
	@JsonProperty("balanceOnHand")
	private List<InventoryBOH> balanceOnHand;
	@JsonProperty("containerIds")
	private List<String> containerIds = new ArrayList<String>();
	@JsonProperty("unloadedContainers")
	private List<String> unloadedContainers = new ArrayList<String>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	@JsonProperty("rdcDeliveryDetail")
	private RDCDeliveryDetail rdcDelievryDetails;
	@JsonProperty("bolNumber")
	private String bolNumber;
	@JsonProperty("asnDocID")
	private String asnDocID;
	@JsonProperty("stoNumbers")
	private List<String> stoNumbers = new ArrayList<String>();
	@JsonProperty("mcbContainerID")
	private String mcbContainerID;
	
	@JsonProperty("waveNumber_BY")
	private String waveNumber_BY;
	@JsonProperty("loadID_BY")
	private String loadID_BY;
	@JsonProperty("sourceLocationForPicking")
	private String sourceLocationForPicking;
	@JsonProperty("destinationLocationForPicking")
	private String destinationLocationForPicking;
	@JsonProperty("operationNumForPicking")
	private String operationNumForPicking;
	
	//Outbound
	@JsonProperty("outboundYardZone")
	private String outboundYardZone;

	public String getMcbContainerID() {
		return mcbContainerID;
	}

	public void setMcbContainerID(String mcbContainerID) {
		this.mcbContainerID = mcbContainerID;
	}

	public RDCDeliveryDetail getRdcDelievryDetails() {
		return rdcDelievryDetails;
	}

	public void setRdcDelievryDetails(RDCDeliveryDetail rdcDelievryDetails) {
		this.rdcDelievryDetails = rdcDelievryDetails;
	}

	@JsonProperty("trailerNumber")
	public String getTrailerNumber() {
		return trailerNumber;
	}

	@JsonProperty("trailerNumber")
	public void setTrailerNumber(String trailerNumber) {
		this.trailerNumber = trailerNumber;
	}

	public OutboundDetail withTrailerNumber(String trailerNumber) {
		this.trailerNumber = trailerNumber;
		return this;
	}

	@JsonProperty("laneNumber")
	public String getLaneNumber() {
		return laneNumber;
	}

	@JsonProperty("laneNumber")
	public void setLaneNumber(String laneNumber) {
		this.laneNumber = laneNumber;
	}

	@JsonProperty("destNumber")
	public String getDestNumber() {
		return destNumber;
	}

	@JsonProperty("destNumber")
	public void setDestNumber(String destNumber) {
		this.destNumber = destNumber;
	}

	public OutboundDetail withDestNumber(String destNumber) {
		this.destNumber = destNumber;
		return this;
	}

	@JsonProperty("loadId")
	public String getLoadId() {
		return loadId;
	}

	@JsonProperty("loadId")
	public void setLoadId(String loadId) {
		this.loadId = loadId;
	}

	public OutboundDetail withLoadId(String loadId) {
		this.loadId = loadId;
		return this;
	}

	@JsonProperty("tmsLoadId")
	public String getTmsLoadId() {
		return tmsLoadId;
	}

	@JsonProperty("tmsLoadId")
	public void setTmsLoadId(String tmsLoadId) {
		this.tmsLoadId = tmsLoadId;
	}

	public OutboundDetail withTmsLoadId(String tmsLoadId) {
		this.tmsLoadId = tmsLoadId;
		return this;
	}

	@JsonProperty("outboundDoorNumber")
	public String getOutboundDoorNumber() {
		return outboundDoorNumber;
	}

	@JsonProperty("outboundDoorNumber")
	public void setOutboundDoorNumber(String outboundDoorNumber) {
		this.outboundDoorNumber = outboundDoorNumber;
	}

	public OutboundDetail withOutboundDoorNumber(String outboundDoorNumber) {
		this.outboundDoorNumber = outboundDoorNumber;
		return this;
	}

	@JsonProperty("sealNumber")
	public String getSealNumber() {
		return sealNumber;
	}

	@JsonProperty("sealNumber")
	public void setSealNumber(String sealNumber) {
		this.sealNumber = sealNumber;
	}

	public OutboundDetail withSealNumber(String sealNumber) {
		this.sealNumber = sealNumber;
		return this;
	}

	@JsonProperty("asnNumber")
	public String getAsnNumber() {
		return asnNumber;
	}

	@JsonProperty("asnNumber")
	public void setAsnNumber(String asnNumber) {
		this.asnNumber = asnNumber;
	}

	public OutboundDetail withAsnNumber(String asnNumber) {
		this.asnNumber = asnNumber;
		return this;
	}

	@JsonProperty("containerIds")
	public List<String> getContainerIds() {
		return containerIds;
	}

	@JsonProperty("containerIds")
	public void setContainerIds(List<String> containerIds) {
		this.containerIds = containerIds;
	}

	@JsonProperty("stoNumbers")
	public List<String> getstoNumbers() {
		return stoNumbers;
	}

	@JsonProperty("stoNumbers")
	public void setstoNumbers(List<String> stoNumbers) {
		this.stoNumbers = stoNumbers;
	}

	public OutboundDetail withContainerIds(List<String> containerIds) {
		this.containerIds = containerIds;
		return this;
	}

	@JsonProperty("unloadedContainers")
	public List<String> getUnloadedContainers() {
		return unloadedContainers;
	}

	@JsonProperty("unloadedContainers")
	public void setUnloadedContainers(List<String> unloadedContainers) {
		this.unloadedContainers = unloadedContainers;
	}

	public OutboundDetail withUnloadedContainers(List<String> unloadedContainers) {
		this.unloadedContainers = unloadedContainers;
		return this;
	}

	@JsonProperty("bolNumber")
	public String getBolNumber() {
		return bolNumber;
	}

	@JsonProperty("bolNumber")
	public void setBolNumber(String bolNumber) {
		this.bolNumber = bolNumber;
	}

	@JsonProperty("asnDocID")
	public String getAsnDocID() {
		return asnDocID;
	}

	@JsonProperty("asnDocID")
	public void setAsnDocID(String asnDocID) {
		this.asnDocID = asnDocID;
	}

	public String getWitronBatchName() {
		return witronBatchName;
	}

	public void setWitronBatchName(String witronBatchName) {
		this.witronBatchName = witronBatchName;
	}

	public String getCycleWave() {
		return cycleWave;
	}

	public void setCycleWave(String cycleWave) {
		this.cycleWave = cycleWave;
	}

	public String getReleaseNbr() {
		return releaseNbr;
	}

	public void setReleaseNbr(String releaseNbr) {
		this.releaseNbr = releaseNbr;
	}

	public String getContainersCount() {
		return containersCount;
	}

	public void setContainersCount(String containersCount) {
		this.containersCount = containersCount;
	}
	
	public String getFulfillmentId() {
		return fulfillmentId;
	}

	public void setFulfillmentId(String FulfillmentId) {
		this.fulfillmentId = fulfillmentId;
	}

	public List<Route> getRoutes() {
		return routes;
	}

	public void setRoutes(List<Route> routes) {
		this.routes = routes;
	}
	
	public String getScoreJobId() {
		return scoreJobId;
	}

	public void setScoreJobId(String scoreJobId) {
		this.scoreJobId = scoreJobId;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	public OutboundDetail withAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
		return this;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("trailerNumber", trailerNumber).append("destNumber", destNumber)
				.append("loadId", loadId).append("tmsLoadId", tmsLoadId)
				.append("outboundDoorNumber", outboundDoorNumber).append("sealNumber", sealNumber)
				.append("asnNumber", asnNumber).append("containerIds", containerIds)
				.append("unloadedContainers", unloadedContainers).append("additionalProperties", additionalProperties)
				.toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(outboundDoorNumber).append(containerIds).append(tmsLoadId).append(loadId)
				.append(unloadedContainers).append(asnNumber).append(trailerNumber).append(sealNumber)
				.append(additionalProperties).append(destNumber).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof OutboundDetail) == false) {
			return false;
		}
		OutboundDetail rhs = ((OutboundDetail) other);
		return new EqualsBuilder().append(outboundDoorNumber, rhs.outboundDoorNumber)
				.append(containerIds, rhs.containerIds).append(tmsLoadId, rhs.tmsLoadId).append(loadId, rhs.loadId)
				.append(unloadedContainers, rhs.unloadedContainers).append(asnNumber, rhs.asnNumber)
				.append(trailerNumber, rhs.trailerNumber).append(sealNumber, rhs.sealNumber)
				.append(additionalProperties, rhs.additionalProperties).append(destNumber, rhs.destNumber).isEquals();
	}

	public List<InventoryBOH> getBalanceOnHand() {
		return balanceOnHand;
	}

	public void setBalanceOnHand(List<InventoryBOH> balanceOnHand) {
		this.balanceOnHand = balanceOnHand;
	}
	
	public String getWaveNumber_BY() {
		return waveNumber_BY;
	}

	public void setWaveNumber_BY(String waveNumber_BY) {
		this.waveNumber_BY = waveNumber_BY;
	}
	
	public String getLoadID_BY() {
		return loadID_BY;
	}

	public void setLoadID_BY(String loadID_BY) {
		this.loadID_BY = loadID_BY;
	}

	public String getSourceLocationForPicking() {
		return sourceLocationForPicking;
	}

	public void setSourceLocationForPicking(String sourceLocationForPicking) {
		this.sourceLocationForPicking = sourceLocationForPicking;
	}

	public String getDestinationLocationForPicking() {
		return destinationLocationForPicking;
	}

	public void setDestinationLocationForPicking(String destinationLocationForPicking) {
		this.destinationLocationForPicking = destinationLocationForPicking;
	}
	
	public String getoperationNumForPicking() {
		return operationNumForPicking;
	}

	public void setoperationNumForPicking(String operationNumForPicking) {
		this.operationNumForPicking = operationNumForPicking;
	}
	
	//Outbound
	public String getOutboundYardZone() {
		return outboundYardZone;
	}

	public void setOutboundYardZone(String outboundYardZone) {
		this.outboundYardZone = outboundYardZone;
	}
}
