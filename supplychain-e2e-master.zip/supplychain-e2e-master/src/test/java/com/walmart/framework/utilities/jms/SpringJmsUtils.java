package com.walmart.framework.utilities.jms;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.framework.supplychain.config.Config;

import spring.SpringTestConfiguration;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

//@ContextConfiguration(classes = {SpringTestConfiguration.class, MessagingConfig.class})
@ContextConfiguration(classes = {SpringTestConfiguration.class})
//@RunWith(SpringRunner.class)
public class SpringJmsUtils {

    @Autowired
    @Qualifier("mccAmqConnectionFactory")
    ConnectionFactory mccAmqConnectionFactory;

    @Autowired
    @Qualifier("mccImqConnectionFactory")
    ConnectionFactory mccImqConnectionFactory;

    @Autowired
    @Qualifier("rdcAmqConnectionFactory")
    ConnectionFactory rdcAmqConnectionFactory;

    @Autowired
    @Qualifier("rdcImqConnectionFactory")
    ConnectionFactory rdcImqConnectionFactory;

    @Autowired
    @Qualifier("jmsTemplate")
    JmsTemplate jmsTemplate;


    Logger logger = LogManager.getLogger(this.getClass());

    //    @Test
    public void sendMessages() throws JMSException {


       /* sendMessage(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.AMQ, DC_TYPE.MCC, "aaaaaa.test.123", "This is a greeting message @ : " + new Date());


        sendMessage(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ, DC_TYPE.MCC, "QL.WMT.WMS.OBM.ASN.CLOUD.BO", "This is a greeting message @ : " + new Date());

        sendMessage(JMS_SUBSCRIPTION_TYPE.TOPIC, JMS_PROVIDER_TYPE.IMQ, DC_TYPE.MCC, "WMSOP/ORDER/ALLOCATION", "This is a greeting message @ : " + new Date());

        System.out.println();*/
    }

    //    @Test
    public void receiveMessages() throws JMSException {

        Message message = receiveMessages(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.AMQ, DC_TYPE.MCC, "aaaaaa.test.123");

        Message message2 = receiveMessages(JMS_SUBSCRIPTION_TYPE.QUEUE, JMS_PROVIDER_TYPE.IMQ, DC_TYPE.MCC, "QL.WMT.WMS.OBM.ASN.CLOUD.BO");

        System.out.println();
    }


    public void sendMessage(JMS_SUBSCRIPTION_TYPE jst, JMS_PROVIDER_TYPE jpt, DC_TYPE dct, String destQueueOrTopicName, String message) {

        JmsTemplate jmsTemplate = configureJmsTemplate(jst, jpt, dct);
        logger.info(message);
        jmsTemplate.send(destQueueOrTopicName, (Session session)-> session.createTextMessage(message));
       
    }
    
    public void sendMessageAMQRDC(JMS_SUBSCRIPTION_TYPE jst, JMS_PROVIDER_TYPE jpt, DC_TYPE dct, String destQueueOrTopicName, String message) {

        JmsTemplate jmsTemplate = configureJmsTemplate(jst, jpt, dct);
        jmsTemplate.send(destQueueOrTopicName, (Session session)-> session.createTextMessage(message));
       
    }

    public Message receiveMessages(JMS_SUBSCRIPTION_TYPE jst, JMS_PROVIDER_TYPE jpt, DC_TYPE dct, String destQueueOrTopicName) {

        JmsTemplate jmsTemplate = configureJmsTemplate(jst, jpt, dct);
        Message message = jmsTemplate.receive(destQueueOrTopicName);

        return message;
    }

    private JmsTemplate configureJmsTemplate(JMS_SUBSCRIPTION_TYPE jst, JMS_PROVIDER_TYPE jpt, DC_TYPE dct){

        if(jpt == JMS_PROVIDER_TYPE.IMQ){
            if(dct == DC_TYPE.MCC || dct == DC_TYPE.ACC || dct == DC_TYPE.BAJA){
                jmsTemplate.setConnectionFactory(mccImqConnectionFactory);
            }else if(dct==DC_TYPE.MCC_RDC || dct==DC_TYPE.ATLAS_RDC || dct==DC_TYPE.ACC_RDC || dct==DC_TYPE.RDC){
                jmsTemplate.setConnectionFactory(rdcImqConnectionFactory);
            }
        }else if(jpt == JMS_PROVIDER_TYPE.AMQ){
            if(dct == DC_TYPE.MCC || dct == DC_TYPE.ACC){
                jmsTemplate.setConnectionFactory(mccAmqConnectionFactory);
            }else if(dct==DC_TYPE.MCC_RDC || dct==DC_TYPE.ATLAS_RDC || dct==DC_TYPE.ACC_RDC || dct==DC_TYPE.RDC){
                jmsTemplate.setConnectionFactory(rdcAmqConnectionFactory);
            }
        }

        if(jst == JMS_SUBSCRIPTION_TYPE.TOPIC){
            jmsTemplate.setPubSubDomain(true);
        }else{
            jmsTemplate.setPubSubDomain(false);
        }

        return jmsTemplate;
    }

    public void sendMessageWithHeaders(JMS_SUBSCRIPTION_TYPE jst, JMS_PROVIDER_TYPE jpt, DC_TYPE dct, String destQueueOrTopicName, String message, Map<String, Object> headersMap) throws JMSException {

        JmsTemplate jmsTemplate = configureJmsTemplate(jst, jpt, dct);
        Session session = jmsTemplate.getConnectionFactory().createConnection().createSession();
        TextMessage textMessage = session.createTextMessage(message);
        jmsTemplate.convertAndSend(destQueueOrTopicName, textMessage, m -> {
            addAllHeaders(m, headersMap);
            return m;
        });
        session.close();
    }

    private void addAllHeaders(Message m, Map<String, Object> headersMap) throws JMSException {
        Set<Map.Entry<String, Object>> entrySet = headersMap.entrySet();
        Iterator<Map.Entry<String, Object>> entryIterator = entrySet.iterator();

        while(entryIterator.hasNext()){
            Map.Entry<String, Object> entry = entryIterator.next();
            m.setObjectProperty(entry.getKey(), entry.getValue());
        }
    }


}

