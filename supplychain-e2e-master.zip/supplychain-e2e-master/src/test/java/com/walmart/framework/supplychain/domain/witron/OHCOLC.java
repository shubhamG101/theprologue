package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "OHC" })
public class OHCOLC {
	@JsonProperty("OHC")
	private OHC OHC;
	@JsonProperty("OHC")
	public OHC getOHC() {
		return OHC;
	}
	@JsonProperty("OHC")
	public void setOHC(OHC oHC) {
		OHC = oHC;
	}
}
