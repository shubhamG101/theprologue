package com.walmart.framework.utilities.reporting;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AutomationFailure extends RuntimeException{
	public static final Logger LOGGER = LogManager.getLogger(AutomationFailure.class);
	private static final String CLASS_NAME_IN_MSG="AutomationFailure:";
	private static final String JUNIT_PACKAGE_NAME_IN_MSG="org.junit.ComparisonFailure: ";
	private static final String ASSERTION_PACKAGE_NAME_IN_MSG="java.lang.AssertionError: ";
	private static final String SERENITY_PACKAGE_NAME_IN_MSG="net.serenitybdd.core.exceptions.SerenityManagedException: ";


	
	public AutomationFailure(String message, Throwable cause) {  
        super(getExceptionMessage(cause, message), cause);
        LOGGER.error("#Failure-AutomationFailure:"+cause);
    }
	
	
	public AutomationFailure(String message) {  
        super(processErrorMessage(message));
    }
	public static String getExceptionMessage(Throwable cause,String message) {
		return processErrorMessage(cause.getMessage(),message);
	}
	public static String processErrorMessage(String errorMessage) {
		return processErrorMessage(null,errorMessage);
	}
	public static String processErrorMessage(String messageFromThrowable,String errorMessage) {
		if(messageFromThrowable!=null&&messageFromThrowable.contains(CLASS_NAME_IN_MSG)) {
			errorMessage= messageFromThrowable.substring(messageFromThrowable.lastIndexOf(CLASS_NAME_IN_MSG)+CLASS_NAME_IN_MSG.length(), messageFromThrowable.length());
		}
		if(errorMessage!=null&&errorMessage.contains(JUNIT_PACKAGE_NAME_IN_MSG)) {
			errorMessage=errorMessage.replaceAll(JUNIT_PACKAGE_NAME_IN_MSG, "");
		}
		if(errorMessage.contains(ASSERTION_PACKAGE_NAME_IN_MSG)) {
			errorMessage=errorMessage.replaceAll(ASSERTION_PACKAGE_NAME_IN_MSG, "");
		}
		if(errorMessage.contains(SERENITY_PACKAGE_NAME_IN_MSG)) {
			errorMessage=errorMessage.replaceAll(SERENITY_PACKAGE_NAME_IN_MSG, "");
		}
		return errorMessage;
	}
	
}
