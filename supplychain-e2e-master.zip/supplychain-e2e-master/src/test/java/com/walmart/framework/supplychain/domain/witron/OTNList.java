package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "updateList" })
public class OTNList {
	@JsonProperty("orderTrackingNumber")
	private String orderTrackingNumber;
	@JsonProperty("status")
	private String status;

	@JsonProperty("orderTrackingNumber")
	public String getOrderTrackingNumber() {
		return orderTrackingNumber;
	}

	@JsonProperty("orderTrackingNumber")
	public void setOrderTrackingNumber(String orderTrackingNumber) {
		this.orderTrackingNumber = orderTrackingNumber;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}
}
