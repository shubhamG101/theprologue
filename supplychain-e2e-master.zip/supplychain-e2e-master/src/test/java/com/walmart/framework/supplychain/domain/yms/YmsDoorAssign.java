package com.walmart.framework.supplychain.domain.yms;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"deliveryNumber",
"sealNumber",
"trailerStatusCode",
"carrier",
"trailerId",
"arrivalTimeStamp",
"dcNumber",
"subcenter",
"doorNumber",
"trailerType",
"trailerTypeCode",
"tralrCntrlRecId",
"moveType"
})
public class YmsDoorAssign {

@JsonProperty("deliveryNumber")
private String deliveryNumber;
@JsonProperty("sealNumber")
private String sealNumber;
@JsonProperty("trailerStatusCode")
private String trailerStatusCode;
@JsonProperty("carrier")
private String carrier;
@JsonProperty("trailerId")
private String trailerId;
@JsonProperty("arrivalTimeStamp")
private String arrivalTimeStamp;
@JsonProperty("dcNumber")
private String dcNumber;
@JsonProperty("subcenter")
private String subcenter;
@JsonProperty("doorNumber")
private String doorNumber;
@JsonProperty("trailerType")
private String trailerType;
@JsonProperty("trailerTypeCode")
private String trailerTypeCode;
@JsonProperty("tralrCntrlRecId")
private String tralrCntrlRecId;
@JsonProperty("moveType")
private String moveType;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("deliveryNumber")
public String getDeliveryNumber() {
return deliveryNumber;
}

@JsonProperty("deliveryNumber")
public void setDeliveryNumber(String deliveryNumber) {
this.deliveryNumber = deliveryNumber;
}

@JsonProperty("sealNumber")
public String getSealNumber() {
return sealNumber;
}

@JsonProperty("sealNumber")
public void setSealNumber(String sealNumber) {
this.sealNumber = sealNumber;
}

@JsonProperty("trailerStatusCode")
public String getTrailerStatusCode() {
return trailerStatusCode;
}

@JsonProperty("trailerStatusCode")
public void setTrailerStatusCode(String trailerStatusCode) {
this.trailerStatusCode = trailerStatusCode;
}

@JsonProperty("carrier")
public String getCarrier() {
return carrier;
}

@JsonProperty("carrier")
public void setCarrier(String carrier) {
this.carrier = carrier;
}

@JsonProperty("trailerId")
public String getTrailerId() {
return trailerId;
}

@JsonProperty("trailerId")
public void setTrailerId(String trailerId) {
this.trailerId = trailerId;
}

@JsonProperty("arrivalTimeStamp")
public String getArrivalTimeStamp() {
return arrivalTimeStamp;
}

@JsonProperty("arrivalTimeStamp")
public void setArrivalTimeStamp(String arrivalTimeStamp) {
this.arrivalTimeStamp = arrivalTimeStamp;
}

@JsonProperty("dcNumber")
public String getDcNumber() {
return dcNumber;
}

@JsonProperty("dcNumber")
public void setDcNumber(String dcNumber) {
this.dcNumber = dcNumber;
}

@JsonProperty("subcenter")
public String getSubcenter() {
return subcenter;
}

@JsonProperty("subcenter")
public void setSubcenter(String subcenter) {
this.subcenter = subcenter;
}

@JsonProperty("doorNumber")
public String getDoorNumber() {
return doorNumber;
}

@JsonProperty("doorNumber")
public void setDoorNumber(String doorNumber) {
this.doorNumber = doorNumber;
}

@JsonProperty("trailerType")
public String getTrailerType() {
return trailerType;
}

@JsonProperty("trailerType")
public void setTrailerType(String trailerType) {
this.trailerType = trailerType;
}

@JsonProperty("trailerTypeCode")
public String getTrailerTypeCode() {
return trailerTypeCode;
}

@JsonProperty("trailerTypeCode")
public void setTrailerTypeCode(String trailerTypeCode) {
this.trailerTypeCode = trailerTypeCode;
}

@JsonProperty("tralrCntrlRecId")
public String getTralrCntrlRecId() {
return tralrCntrlRecId;
}

@JsonProperty("tralrCntrlRecId")
public void setTralrCntrlRecId(String tralrCntrlRecId) {
this.tralrCntrlRecId = tralrCntrlRecId;
}

@JsonProperty("moveType")
public String getmoveType() {
return moveType;
}

@JsonProperty("moveType")
public void setmoveType(String moveType) {
this.moveType = moveType;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
