package com.walmart.framework.supplychain.domain.thor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "txnId", "sales"})
public class ThorSales {
	
	@JsonProperty("txnId")
	private String txnId;
	@JsonProperty("sales")
	private List<SalesLine> sales;
	@JsonProperty("txnId")
	public String getTxnId() {
		return txnId;
	}
	@JsonProperty("txnId")
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	@JsonProperty("sales")
	public List<SalesLine> getSales() {
		return sales;
	}
	@JsonProperty("sales")
	public void setSales(List<SalesLine> sales) {
		this.sales = sales;
	}
}
