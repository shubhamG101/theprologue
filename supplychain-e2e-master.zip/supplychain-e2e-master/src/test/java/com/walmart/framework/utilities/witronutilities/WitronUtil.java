package com.walmart.framework.utilities.witronutilities;

import static net.serenitybdd.rest.SerenityRest.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.witron.BOH;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoDetail;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.PoLineDetail;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.db.PRODUCT_NAME;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.framework.utilities.reporting.AutomationFailure;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

public class WitronUtil {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	InventoryHelper inventoryHelper;

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	private static final String WITRON_INVENTORY_BOH_ENDPOINT = "witron_inv_boh_validation_ep";

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	Logger logger = LogManager.getLogger(this.getClass());
	Response response;
	private static final String WMT_USER_ID = "sysadmin";
	private static final String CONETENT_TYPE = "application/json";
	private static final String CORRELATIONID = "676726";
	private static final String GROUP_BY_ATTRIBUTE = "rotateDate";
	private static final String GROUP_BY_ATTRIBUTE_ORDER_BY = "asc";
	private static final String BASEDIVISION_CODE = "WM";
	private static final String FINANCIAL_REPORTING_GROUP = "US";
	private static final String INVENTORY_STATUS = "AVAILABLE";
	private static final String BOH_QTY_UOM = "EA";
	private static final String TURN = "TURN";
	private static final String DISTRO = "DISTRO";
	ObjectMapper om = new ObjectMapper();
	private static final String GET_PONUMBERS = "$.testFlowData.poDetails[*]";
	private static final String TEST_FLOW_DATA = "testFlowData";

	private static final String BOH = "boh";
	private static final String TOTAL_WEIGHT = "totalWeight";
	private static final String WAC = "wac";
	private static final String WAW = "waw";

	public String getItemMDMDetails(String itemNum) {

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().body("[" + itemNum + "]")
					.headers(getHeaderForItemMDM()).post(environment.getProperty("witron_item_mdm"));
			Assert.assertEquals(ErrorCodes.WITRON_ITEM_FETCH_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	public String getItemMDMDetailsUPCXref(String primeItemNum, String xrefItem) {
		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().body("[" + primeItemNum + "]")
					.headers(getHeaderForItemMDM()).post(environment.getProperty("witron_item_mdm"));
			Assert.assertEquals(ErrorCodes.WITRON_ITEM_FETCH_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		DocumentContext parsedJson = JsonPath.parse(response.asString());
		List<String> xrefUPC = parsedJson.read("$.foundSupplyItems[?(@.number == '" + primeItemNum
				+ "')].inventoryItemXref[*].itemList[?(@.supplyItemNumber == '" + xrefItem + "')].gtin");

		return xrefUPC.get(0);
	}

	public String getItemBOH(List<String> itemNumList) {

		List orderTypeList = new ArrayList();
		orderTypeList.add(TURN);
		orderTypeList.add(DISTRO);

		BOH boh = new BOH();
		boh.setGroupByAttr(GROUP_BY_ATTRIBUTE);
		boh.setGroupByAttrOrderBy(GROUP_BY_ATTRIBUTE_ORDER_BY);
		boh.setItemList(itemNumList);
		boh.setPoTypeList(orderTypeList);
		boh.setBaseDivisionCode(BASEDIVISION_CODE);
		boh.setFinancialReportingGroup(FINANCIAL_REPORTING_GROUP);
		boh.setInventoryStatus(INVENTORY_STATUS);
		boh.setBohQtyUom(BOH_QTY_UOM);

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().body(om.writeValueAsString(boh))
					.headers(getHeaderForInventoryBOH()).post(environment.getProperty("witron_inventory_boh"));
			Assert.assertEquals(ErrorCodes.WITRON_GET_BOH_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	public String getInventoryCntr(String cntr) {

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getHeaderForInventoryCntr())
					.get(environment.getProperty("witron_inventory_cntr") + cntr);
			Assert.assertEquals(ErrorCodes.WITRON_GET_CNTR_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	public String getFacilityMdm(String dest) {

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getHeaderForFacilitymdm())
					.get(environment.getProperty("facility_mdm_url") + dest);
			Assert.assertEquals(ErrorCodes.WITRON_FACILITY_MDM_FETCH_FAILED, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	public Headers getHeaderForItemMDM() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("witron_facility_country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("witron_facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		Header tokeID = new Header("api-key", environment.getProperty("witron_mdm_api_key"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);
		headerList.add(tokeID);
		return new Headers(headerList);

	}

	public Headers getHeaderForInventoryBOH() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("witron_facility_country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("witron_facility_num"));
		Header userId = new Header("WMT-CorrelationId", CORRELATIONID);
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);
		return new Headers(headerList);

	}

	public Headers getHeaderForInventoryCntr() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("witron_facility_country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("witron_facility_num"));
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(appType);
		return new Headers(headerList);
	}

	public Headers getHeaderForFacilitymdm() {
		Header apikey = new Header("api-key", environment.getProperty("witron_facility_mdm_api_key"));
		Header facilityNum = new Header("facilitynum", environment.getProperty("witron_facility_num"));
		Header countryCode = new Header("facilitycountrycode", environment.getProperty("witron_facility_country_code"));
		Header userId = new Header("wmt-userid", "shore");
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(apikey);
		headerList.add(userId);
		return new Headers(headerList);
	}

	public void setBohWacWawTotalWeight() {
		try {
			String testFlowData = (String) threadLocal.get().get(TEST_FLOW_DATA);
			DocumentContext context = null;
			JSONArray listOfPO = JsonPath.read(testFlowData, GET_PONUMBERS);
			String poString = listOfPO.toJSONString();
			List<PoDetail> poList = om.readValue(poString, new TypeReference<List<PoDetail>>() {
			});
			List<PoDetail> newPOList = new ArrayList<PoDetail>();
			for (PoDetail poDetail : poList) {
				List<PoLineDetail> poLineList = poDetail.getPoLineDetails();
				List<PoLineDetail> newpoLineList = new ArrayList<PoLineDetail>();
				for (PoLineDetail lineDetail : poLineList) {

					String promoInd = null;
					String item = lineDetail.getItemNumber();
					boolean isVariable = lineDetail.getIsVariableWeight();

					if (lineDetail.getPromoInd().equals("N")) {
						promoInd = "TURN";
					} else {
						promoInd = "DISTRO";
					}

					Map<String, String> averageMap = getBohWacWawTotalWeight(item, promoInd, isVariable);
					lineDetail.setBoh(Integer.parseInt(averageMap.get(BOH)));
					lineDetail.setWac(Double.parseDouble(averageMap.get(WAC)));
					if (lineDetail.getIsVariableWeight()) {
						lineDetail.setTotalWeight(Double.parseDouble(averageMap.get(TOTAL_WEIGHT)));
						lineDetail.setWaw(Double.parseDouble(averageMap.get(WAW)));
					}

					newpoLineList.add(lineDetail);
				}
				poDetail.setPoLineDetails(newpoLineList);
				newPOList.add(poDetail);
			}
			JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
			context = JsonPath.parse(parser.parse(testFlowData));
			context.set("$.testFlowData.poDetails",
					JsonPath.parse(om.writeValueAsString(newPOList)).read("$", JSONArray.class));
			String str = context.jsonString();
			threadLocal.get().put(TEST_FLOW_DATA, str);

		} catch (Exception e) {
			throw new AutomationFailure("Failed to set BOH, WAW, WAW, Total weight", e);
		}
	}

	public Map<String, String> getBohWacWawTotalWeight(String item, String promoInd, boolean isVariable) {
		Map<String, String> bohWacMap = new HashMap<String, String>();
		try {
			List<Map<String, Object>> itemBohList = dbUtils.selectFrom(PRODUCT_NAME.DCFIN,
					environment.getProperty("dcfin_select_wac_item_details"), item, promoInd,
					environment.getProperty("dcNumber"));

			List<Map<String, Object>> itemWacList = dbUtils.selectFrom(PRODUCT_NAME.DCFIN,
					environment.getProperty("dcfin_select_wac_data"), item, promoInd,
					environment.getProperty("dcNumber"));

			if (itemBohList.isEmpty()) {
				bohWacMap.put(BOH, "0");
				bohWacMap.put(TOTAL_WEIGHT, "0");
			} else {
				bohWacMap.put(BOH, String.valueOf(itemBohList.get(0).get("total_item_qty")));
				if (isVariable) {
					bohWacMap.put(TOTAL_WEIGHT, String.valueOf(itemBohList.get(0).get("total_item_weight")));
				}
			}

			if (itemWacList.isEmpty()) {
				bohWacMap.put(WAC, "0");
				bohWacMap.put(WAW, "0");
			} else {
				bohWacMap.put(WAC, String.valueOf(itemWacList.get(0).get("wac_cost")));
				if (isVariable) {
					bohWacMap.put(WAW, String.valueOf(itemWacList.get(0).get("avg_weight")));
				}
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to get BOH, WAW, WAW, Total weight", e);
		}
		return bohWacMap;
	}

	public Response getInventoryBoh(String item) {
		try {
			List<Integer> itemNumberList = new ArrayList<Integer>();
			itemNumberList.add(Integer.parseInt(item));
			Failsafe.with(retryPolicy).run(() -> {
				logger.info("inside failsafe" + inventoryHelper.bohBody(itemNumberList).toJSONString());

				response = given().relaxedHTTPSValidation().headers(inventoryHelper.getInventoryHeaders())
						.body(inventoryHelper.bohBody(itemNumberList).toJSONString())
						.post(environment.getProperty(WITRON_INVENTORY_BOH_ENDPOINT));

				Assert.assertEquals(ErrorCodes.WITRON_INVENTORY_BOH_RESPONSE, Constants.SUCESS_STATUS_CODE,
						response.getStatusCode());
				logger.info("Validated the response status returned for the LPN response " + response.asString());
			});
		} catch (Exception e) {

		}
		return response;
	}

	public String format(String text, String... val2) {
		for (int occurence = 0; occurence < val2.length; occurence++) {
			int i = occurence + 1;
			text = text.replace("#" + i + "#", val2[occurence]);
		}
		logger.info(text);
		return text;
	}

	public Map<String, String> getFreightZoneCharge(String dept, String dest) {
		Map<String, String> freightMap = new HashMap<String, String>();
		try {
				List<Map<String, Object>> freightList = dbUtils.selectFrom(PRODUCT_NAME.DCFINTRANS,
						environment.getProperty("dcfin_transport_select_freight_charge"), dept);
				freightMap.put(dest, freightList.get(0).get("default_freight_zone_rate").toString());
		} catch (Exception e) {
			throw new AutomationFailure("Failed to get freight zone charge", e);
		}
		return freightMap;
	}
	
	public Map<String, String> getFreightDepartment(List<String> destList) {
		Map<String, String> freightDeptMap = new HashMap<String, String>();
		try {
			for (String dest : destList) {
				List<Map<String, Object>> freightDeptList = dbUtils.selectFrom(PRODUCT_NAME.DCFINTRANS,
						environment.getProperty("dcfin_select_freight_dept"),
						environment.getProperty("facility_num"), dest);
				freightDeptMap.put(dest, freightDeptList.get(0).get("store_freight_zone_id").toString());
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to get freight zone charge", e);
		}
		return freightDeptMap;
	}
	
	public Map<String, String> getHandlingCharge(List<String> deptList) {
		Map<String, String> handlingMap = new HashMap<String, String>();
		try {
			for (String dept : deptList) {
				List<Map<String, Object>> handlingList = dbUtils.selectFrom(PRODUCT_NAME.DCFINTRANS,
						environment.getProperty("dcfin_transport_select_handling_charge"),
						environment.getProperty("facility_num"), dept);
				handlingMap.put(dept, handlingList.get(0).get("handling_rate_percentage").toString());
			}
		} catch (Exception e) {
			throw new AutomationFailure("Failed to get freight zone charge", e);
		}
		return handlingMap;
	}
}
