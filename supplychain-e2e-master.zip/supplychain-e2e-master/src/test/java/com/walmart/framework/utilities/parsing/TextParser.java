package com.walmart.framework.utilities.parsing;

import org.apache.commons.io.FileUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;

public class TextParser {

	/*
	 * This method reads a txt file from the resources folder and returns a String
	 */
	public String readTextFile(String fileName) throws URISyntaxException, IOException {
		File file = new File(this.getClass().getResource(fileName).toURI());
		String fileData = FileUtils.readFileToString(file, "UTF-8");
		return fileData;

	}

	public void writeIntoTextFile(String fileName,String data) throws URISyntaxException, IOException {
		File file = new File(System.getProperty("user.dir")+fileName);
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		writer.write(data);
		writer.close();
	}

}
