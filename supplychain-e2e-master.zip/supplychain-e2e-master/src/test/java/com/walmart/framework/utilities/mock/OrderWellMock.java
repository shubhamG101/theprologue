package com.walmart.framework.utilities.mock;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.json.JSONException;
import org.json.JSONObject;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.Assert;

import cucumber.api.java.en.When;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class OrderWellMock {

	// public static WebServiceRestAssured restClient = new WebServiceRestAssured();
	Response response;
	Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	Environment environment;

	enum OrderReference {

		SSTK("20", "SSTK", "New"), DA("33", "XDOCK", "New"), MANUAL("3", "XDOCK", "New_DA_M");

		String poType, status, orderRecordType;

		OrderReference(String poType, String orderRecordType, String status) {
			this.poType = poType;
			this.orderRecordType = orderRecordType;
			this.status = status;
		}
	}

	public void createMockOrders(int itmnbr, int[] destArray, long poNbr, int[] priorityNbrArr, int[] qtyArray,
			int vnpk, int whpk, String poTyp) throws JSONException {

		String poType = null;
		String orderRecordType = null;
		String status = null;
		int itemNbr = itmnbr;
		int[] destinationNumber = destArray;
		long poNumber = poNbr;
		int[] priorityNbr = priorityNbrArr;
		int[] qty = qtyArray;
		if (poTyp.equals("CROSSU")) {
			poType = OrderReference.DA.poType;
			orderRecordType = OrderReference.DA.orderRecordType;
			status = OrderReference.DA.status;
		} else if (poTyp.equals("SSTK")) {
			poType = OrderReference.SSTK.poType;
			orderRecordType = OrderReference.SSTK.orderRecordType;
			status = OrderReference.SSTK.status;
		} else if (poTyp.equals("CROSSMU")) {
			poType = OrderReference.MANUAL.poType;
			orderRecordType = OrderReference.MANUAL.orderRecordType;
			status = OrderReference.MANUAL.status;
		}

		// comMeths.startMockServer();

		JSONObject request = new JSONObject();
		JSONObject mockResponse = new JSONObject();
		JSONObject finalObj = new JSONObject();
		List orderList = new ArrayList();

		JSONObject jsonOrderObj = new JSONObject();
		Date currDate = new Date();
		DateFormat destDf = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		String dateStr = destDf.format(currDate);

		for (int i = 0; i < destinationNumber.length; i++) {
			JSONObject orderObj = new JSONObject();
			orderObj.put("sourceNumber", 6938);
			orderObj.put("orderDate", dateStr + " UTC");
			orderObj.put("wmtItemNumber", itemNbr);
			orderObj.put("destinationNumber", destinationNumber[i]);
			orderObj.put("orderTrackingNumber", UUID.randomUUID().toString());
			orderObj.put("baseDivNumber", 1);
			orderObj.put("departmentNumber", 11);
			orderObj.put("destCountryCode", "US");
			orderObj.put("needType", "%");
			orderObj.put("orderRecordType", orderRecordType);
			orderObj.put("packType", "C");
			orderObj.put("poLineNumber", 1);
			orderObj.put("poNumber", poNumber);
			orderObj.put("poType", poType);
			orderObj.put("priorityReason", "");
			orderObj.put("priorityNbr", priorityNbr[i]);
			orderObj.put("processName", "GLS-test");
			orderObj.put("quantity", qty[i]);
			orderObj.put("reason", "");
			orderObj.put("sourceCountryCode", "US");
			orderObj.put("status", status);
			orderObj.put("upcNumber", "80764489174");
			orderObj.put("vnpkQuantity", vnpk);
			orderObj.put("whpkQuantity", whpk);
			orderObj.put("messageType", "%");

			orderList.add(orderObj);

		}

		jsonOrderObj.put("nextPage", "");
		jsonOrderObj.put("orders", orderList);

		request.put("urlPattern", "/us/1/orders.*by=quantity&sourcenbr=06938&itemnbr=" + itemNbr + ".*");
		request.put("method", "GET");

		mockResponse.put("headers", new JSONObject().put("Content-Type", "application/json"));

		JSONObject obj = null;
		mockResponse.put("status", "200");
		mockResponse.put("body", jsonOrderObj.toString());

		finalObj.put("request", request);
		finalObj.put("response", mockResponse);
		String UUid = UUID.randomUUID().toString();
		finalObj.put("id", UUid);
		finalObj.put("uuid", UUid);

		response = SerenityRest.given().contentType("application/json").body(finalObj.toString()).when()
				.post(environment.getProperty("mockurl_mapping")).andReturn();
//		Assert.assertEquals(ErrorCodes.ORDERWELL_MOCK_ERROR, 201, response.getStatusCode());
		logger.info("mock response" + response.getBody().asString());

		// String mockId = mockObject.getString("id");

	}

}
