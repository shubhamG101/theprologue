package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "itm1dsctxt" })
public class ItemDesc {
	@JsonProperty("itm1dsctxt")
	private String itm1dsctxt;

	@JsonProperty("itm1dsctxt")
	public String getItm1dsctxt() {
		return itm1dsctxt;
	}
	@JsonProperty("itm1dsctxt")
	public void setItm1dsctxt(String itm1dsctxt) {
		this.itm1dsctxt = itm1dsctxt;
	}
}
