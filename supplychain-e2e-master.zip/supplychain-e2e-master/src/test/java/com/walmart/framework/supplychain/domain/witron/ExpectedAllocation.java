package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "expectedPicks" })
public class ExpectedAllocation {
	@JsonProperty("expectedPicks")
	private List<ExpectedPicks> expectedPicks;

	public List<ExpectedPicks> getExpectedPicks() {
		return expectedPicks;
	}

	public void setExpectedPicks(List<ExpectedPicks> expectedPicks) {
		this.expectedPicks = expectedPicks;
	}
}
