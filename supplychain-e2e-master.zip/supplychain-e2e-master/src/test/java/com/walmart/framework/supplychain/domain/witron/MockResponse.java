package com.walmart.framework.supplychain.domain.witron;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "headers","status","body" })
public class MockResponse {
		@JsonProperty("headers")
		private String headers;
		@JsonProperty("status")
		private String status;
		@JsonProperty("body")
		private String body;
		public String getHeaders() {
			return headers;
		}
		public void setHeaders(String headers) {
			this.headers = headers;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
}
