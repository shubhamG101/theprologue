package com.walmart.framework.supplychain.domain.op;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.walmart.framework.supplychain.flowdata.mcc.pojos.RDCDeliveryDetail;
import com.walmart.libs.iam.xacml.core.types.Date;


	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonPropertyOrder(
	
	{
	"enrichOrderSearchCriteria",
	"waveNbr",
	"cycleNbr",
	"status",
	"effectiveReleaseDate"
	})
	
	
	public class EnrichUpdateOrderWithSearchCriteria {
		
		@JsonProperty("enrichOrderSearchCriteria")
		 private EnrichOrderSearchCriteria enrichOrderSearchCriteria;
		 
		public EnrichOrderSearchCriteria getenrichOrderSearchCriteria() {
				return enrichOrderSearchCriteria;
			}

		public void setenrichOrderSearchCriteria(EnrichOrderSearchCriteria enrichOrderSearchCriteria) {
				this.enrichOrderSearchCriteria = enrichOrderSearchCriteria;
			}
		 
		@JsonProperty("waveNbr")
		private String waveNbr = null;


		@JsonProperty("waveNbr")
		public String  getwaveNbr() {
		return this.waveNbr;
		}

		@JsonProperty("waveNbr")
		public void setwaveNbr(String  waveNbr) {
		this.waveNbr=waveNbr;
		}
		
		@JsonProperty("cycleNbr")
		private String cycleNbr = null;


		@JsonProperty("cycleNbr")
		public String  getcycleNbr() {
		return this.cycleNbr;
		}

		@JsonProperty("cycleNbr")
		public void setcycleNbr(String  cycleNbr) {
		this.cycleNbr=cycleNbr;
		}
		
		@JsonProperty("status")
		private String Status = null;


		@JsonProperty("status")
		public String  getStatus() {
		return this.Status;
		}

		@JsonProperty("status")
		public void setStatus(String  Status) {
		this.Status=Status;
		}
		
		@JsonProperty("effectiveReleaseDate")
		private String effectiveReleaseDate = null;


		@JsonProperty("effectiveReleaseDate")
		public String  geteffectiveReleaseDate() {
		return this.effectiveReleaseDate;
		}

		@JsonProperty("effectiveReleaseDate")
		public void seteffectiveReleaseDate(String  effectiveReleaseDate) {
		this.effectiveReleaseDate=effectiveReleaseDate;
		}


}
