package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "fulfillmentId", "dest", "units" })
public class Fulfillment {
	@JsonProperty("fulfillmentId")
	private String fulfillmentId;
	@JsonProperty("dest")
	private String dest;
	@JsonProperty("units")
	private List<FulfillmentUnit> units;
	public String getFulfillmentId() {
		return fulfillmentId;
	}
	public void setFulfillmentId(String fulfillmentId) {
		this.fulfillmentId = fulfillmentId;
	}
	public String getDest() {
		return dest;
	}
	public void setDest(String dest) {
		this.dest = dest;
	}
	public List<FulfillmentUnit> getUnits() {
		return units;
	}
	public void setUnits(List<FulfillmentUnit> units) {
		this.units = units;
	}
}
