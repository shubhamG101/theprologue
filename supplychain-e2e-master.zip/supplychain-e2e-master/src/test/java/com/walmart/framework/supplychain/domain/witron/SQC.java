package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ChangeReference", "Owner", "ProdIdent", "UM", "BatchNo", "ExpiryDate", "OriginDate", "QState", "ChangeSign",
		"QtyUm", "Weight", "ReasonCode", "ReasonText", "StoreID", "SupplierID", "PoIdent", "PoLineIdent",
		"ReturnRefNo", "ActivityDateTime", "UserId", "PalletId" })
public class SQC {
	@JsonProperty("ChangeReference")
	private int ChangeReference;
	@JsonProperty("Owner")
	private OwnerBean Owner;
	@JsonProperty("ProdIdent")
	private String ProdIdent;
	@JsonProperty("UM")
	private String UM;
	@JsonProperty("BatchNo")
	private String BatchNo;
	@JsonProperty("ExpiryDate")
	private String ExpiryDate;
	@JsonProperty("OriginDate")
	private String OriginDate;
	@JsonProperty("QState")
	private String QState;
	@JsonProperty("ChangeSign")
	private String ChangeSign;
	@JsonProperty("QtyUm")
	private String QtyUm;
	@JsonProperty("Weight")
	private SQCWeight Weight;
	@JsonProperty("ReasonCode")
	private String ReasonCode;
	@JsonProperty("ReasonText")
	private String ReasonText;
	@JsonProperty("StoreID")
	private String StoreID;
	@JsonProperty("SupplierID")
	private String SupplierID;
	@JsonProperty("PoIdent")
	private String PoIdent;
	@JsonProperty("PoLineIdent")
	private String PoLineIdent;
	@JsonProperty("ReturnRefNo")
	private String ReturnRefNo;
	@JsonProperty("ActivityDateTime")
	private String ActivityDateTime;
	@JsonProperty("UserId")
	private String UserId;
	@JsonProperty("PalletId")
	private String PalletId;
	
	@JsonProperty("ChangeReference")
	public int getChangeReference() {
		return ChangeReference;
	}
	@JsonProperty("ChangeReference")
	public void setChangeReference(int changeReference) {
		ChangeReference = changeReference;
	}
	@JsonProperty("Owner")
	public OwnerBean getOwner() {
		return Owner;
	}
	@JsonProperty("Owner")
	public void setOwner(OwnerBean owner) {
		Owner = owner;
	}
	@JsonProperty("ProdIdent")
	public String getProdIdent() {
		return ProdIdent;
	}
	@JsonProperty("ProdIdent")
	public void setProdIdent(String prodIdent) {
		ProdIdent = prodIdent;
	}
	@JsonProperty("UM")
	public String getUM() {
		return UM;
	}
	@JsonProperty("UM")
	public void setUM(String uM) {
		UM = uM;
	}
	@JsonProperty("BatchNo")
	public String getBatchNo() {
		return BatchNo;
	}
	@JsonProperty("BatchNo")
	public void setBatchNo(String batchNo) {
		BatchNo = batchNo;
	}
	@JsonProperty("ExpiryDate")
	public String getExpiryDate() {
		return ExpiryDate;
	}
	@JsonProperty("ExpiryDate")
	public void setExpiryDate(String expiryDate) {
		ExpiryDate = expiryDate;
	}
	@JsonProperty("OriginDate")
	public String getOriginDate() {
		return OriginDate;
	}
	@JsonProperty("OriginDate")
	public void setOriginDate(String originDate) {
		OriginDate = originDate;
	}
	@JsonProperty("QState")
	public String getQState() {
		return QState;
	}
	@JsonProperty("QState")
	public void setQState(String qState) {
		QState = qState;
	}
	@JsonProperty("ChangeSign")
	public String getChangeSign() {
		return ChangeSign;
	}
	@JsonProperty("ChangeSign")
	public void setChangeSign(String changeSign) {
		ChangeSign = changeSign;
	}
	@JsonProperty("QtyUm")
	public String getQtyUm() {
		return QtyUm;
	}
	@JsonProperty("QtyUm")
	public void setQtyUm(String qtyUm) {
		QtyUm = qtyUm;
	}
	@JsonProperty("Weight")
	public SQCWeight getWeight() {
		return Weight;
	}
	@JsonProperty("Weight")
	public void setWeight(SQCWeight weight) {
		Weight = weight;
	}
	@JsonProperty("ReasonCode")
	public String getReasonCode() {
		return ReasonCode;
	}
	@JsonProperty("ReasonCode")
	public void setReasonCode(String reasonCode) {
		ReasonCode = reasonCode;
	}
	@JsonProperty("ReasonText")
	public String getReasonText() {
		return ReasonText;
	}
	@JsonProperty("ReasonText")
	public void setReasonText(String reasonText) {
		ReasonText = reasonText;
	}
	@JsonProperty("StoreID")
	public String getStoreID() {
		return StoreID;
	}
	@JsonProperty("StoreID")
	public void setStoreID(String storeID) {
		StoreID = storeID;
	}
	@JsonProperty("SupplierID")
	public String getSupplierID() {
		return SupplierID;
	}
	@JsonProperty("SupplierID")
	public void setSupplierID(String supplierID) {
		SupplierID = supplierID;
	}
	@JsonProperty("PoIdent")
	public String getPoIdent() {
		return PoIdent;
	}
	@JsonProperty("PoIdent")
	public void setPoIdent(String poIdent) {
		PoIdent = poIdent;
	}
	@JsonProperty("PoLineIdent")
	public String getPoLineIdent() {
		return PoLineIdent;
	}
	@JsonProperty("PoLineIdent")
	public void setPoLineIdent(String poLineIdent) {
		PoLineIdent = poLineIdent;
	}
	@JsonProperty("ReturnRefNo")
	public String getReturnRefNo() {
		return ReturnRefNo;
	}
	@JsonProperty("ReturnRefNo")
	public void setReturnRefNo(String returnRefNo) {
		ReturnRefNo = returnRefNo;
	}
	@JsonProperty("ActivityDateTime")
	public String getActivityDateTime() {
		return ActivityDateTime;
	}
	@JsonProperty("ActivityDateTime")
	public void setActivityDateTime(String activityDateTime) {
		ActivityDateTime = activityDateTime;
	}
	@JsonProperty("UserId")
	public String getUserId() {
		return UserId;
	}
	@JsonProperty("UserId")
	public void setUserId(String userId) {
		UserId = userId;
	}
	@JsonProperty("PalletId")
	public String getPalletId() {
		return PalletId;
	}
	@JsonProperty("PalletId")
	public void setPalletId(String palletId) {
		PalletId = palletId;
	}
}
