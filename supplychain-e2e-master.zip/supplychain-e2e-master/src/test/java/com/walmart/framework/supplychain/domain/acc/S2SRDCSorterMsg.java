package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "intendedLane", "actualLane", "sorterId", "messageType",
		"scannedLabel", "eventTime","labelStatus","messageSeqNbr","dispositionQueueCnt","inductNumber","dispositionCode" })
public class S2SRDCSorterMsg {

	@JsonProperty("intendedLane")
	private String intendedLane;
	@JsonProperty("actualLane")
	private String actualLane;
	@JsonProperty("sorterId")
	private String sorterId;
	@JsonProperty("messageType")
	private String messageType;
	@JsonProperty("scannedLabel")
	private String scannedLabel;
	@JsonProperty("eventTime")
	private String eventTime;
	@JsonProperty("labelStatus")
	private String labelStatus;
	@JsonProperty("messageSeqNbr")
	private String messageSeqNbr;
	@JsonProperty("dispositionQueueCnt")
	private String dispositionQueueCnt;
	@JsonProperty("inductNumber")
	private String inductNumber;
	@JsonProperty("dispositionCode")
	private String dispositionCode;

	@JsonProperty("intendedLane")
	public String getIntendedLane() {
		return intendedLane;
	}

	@JsonProperty("intendedLane")
	public void setIntendedLane(String intendedLane) {
		this.intendedLane = intendedLane;
	}

	@JsonProperty("actualLane")
	public String getActualLane() {
		return actualLane;
	}

	@JsonProperty("actualLane")
	public void setActualLane(String actualLane) {
		this.actualLane = actualLane;
	}

	@JsonProperty("sorterId")
	public String getSorterId() {
		return sorterId;
	}

	@JsonProperty("sorterId")
	public void setSorterId(String sorterId) {
		this.sorterId = sorterId;
	}

	@JsonProperty("messageType")
	public String getMessageType() {
		return messageType;
	}

	@JsonProperty("messageType")
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	@JsonProperty("scannedLabel")
	public String getScannedLabel() {
		return scannedLabel;
	}

	@JsonProperty("scannedLabel")
	public void setScannedLabel(String scannedLabel) {
		this.scannedLabel = scannedLabel;
	}

	@JsonProperty("eventTime")
	public String getEventTime() {
		return eventTime;
	}

	@JsonProperty("eventTime")
	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}

	@JsonProperty("labelStatus")
	public String getLabelStatus() {
		return labelStatus;
	}

	@JsonProperty("labelStatus")
	public void setLabelStatus(String labelStatus) {
		this.labelStatus = labelStatus;
	}
	
	@JsonProperty("messageSeqNbr")
	public String getMessageSeqNbr() {
		return messageSeqNbr;
	}

	@JsonProperty("messageSeqNbr")
	public void setMessageSeqNbr(String messageSeqNbr) {
		this.messageSeqNbr = messageSeqNbr;
	}
	
	@JsonProperty("dispositionQueueCnt")
	public String getDispositionQueueCnt() {
		return dispositionQueueCnt;
	}

	@JsonProperty("dispositionQueueCnt")
	public void setDispositionQueueCnt(String dispositionQueueCnt) {
		this.dispositionQueueCnt = dispositionQueueCnt;
	}
	
	@JsonProperty("inductNumber")
	public String getInductNumber() {
		return inductNumber;
	}

	@JsonProperty("inductNumber")
	public void setInductNumber(String inductNumber) {
		this.inductNumber = inductNumber;
	}
	
	@JsonProperty("dispositionCode")
	public String getDispositionCode() {
		return dispositionCode;
	}

	@JsonProperty("dispositionCode")
	public void setDispositionCode(String dispositionCode) {
		this.dispositionCode = dispositionCode;
	}
}