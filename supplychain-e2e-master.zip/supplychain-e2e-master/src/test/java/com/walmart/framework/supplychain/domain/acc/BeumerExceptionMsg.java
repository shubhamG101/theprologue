package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "scannedLabel", "inductNumber", "doorNbr", "labelStatus",
		"errorCode" })
public class BeumerExceptionMsg {

	@JsonProperty("lpn")
	private String lpn;
	@JsonProperty("labelType")
	private String labelType;
	@JsonProperty("exceptionReason")
	private String exceptionReason;

	@JsonProperty("lpn")
	public String getLpn() {
		return lpn;
	}

	@JsonProperty("lpn")
	public void setLpn(String lpn) {
		this.lpn = lpn;
	}

	@JsonProperty("labelType")
	public String getLabelType() {
		return labelType;
	}

	@JsonProperty("labelType")
	public void setLabelType(String labelType) {
		this.labelType = labelType;
	}

	@JsonProperty("exceptionReason")
	public String getExceptionReason() {
		return exceptionReason;
	}

	@JsonProperty("exceptionReason")
	public void setExceptionReason(String exceptionReason) {
		this.exceptionReason = exceptionReason;
	}

}