package com.walmart.framework.supplychain.domain.rdc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "name", "status", "type", "orgUnitId", "xCoord", "yCoord", "zCoord", "attributes", "properties" })
public class AddDoor {
	@JsonProperty("name")
	private String name;
	@JsonProperty("status")
	private int status;
	@JsonProperty("type")
	private int type;
	@JsonProperty("orgUnitId")
	private int orgUnitId;
	@JsonProperty("xCoord")
	private int xCoord;
	@JsonProperty("yCoord")
	private int yCoord;
	@JsonProperty("zCoord")
	private int zCoord;
	@JsonProperty("attributes")
	private String attributes;
	@JsonProperty("properties")
	private List<DoorProperty> properties;
	@JsonProperty("name")
	public String getName() {
		return name;
	}
	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}
	@JsonProperty("status")
	public int getStatus() {
		return status;
	}
	@JsonProperty("status")
	public void setStatus(int status) {
		this.status = status;
	}
	@JsonProperty("type")
	public int getType() {
		return type;
	}
	@JsonProperty("type")
	public void setType(int type) {
		this.type = type;
	}
	@JsonProperty("orgUnitId")
	public int getOrgUnitId() {
		return orgUnitId;
	}
	@JsonProperty("orgUnitId")
	public void setOrgUnitId(int orgUnitId) {
		this.orgUnitId = orgUnitId;
	}
	@JsonProperty("xCoord")
	public int getxCoord() {
		return xCoord;
	}
	@JsonProperty("xCoord")
	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;
	}
	@JsonProperty("yCoord")
	public int getyCoord() {
		return yCoord;
	}
	@JsonProperty("yCoord")
	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;
	}
	@JsonProperty("zCoord")
	public int getzCoord() {
		return zCoord;
	}
	@JsonProperty("zCoord")
	public void setzCoord(int zCoord) {
		this.zCoord = zCoord;
	}
	@JsonProperty("attributes")
	public String getAttributes() {
		return attributes;
	}
	@JsonProperty("attributes")
	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}
	@JsonProperty("properties")
	public List<DoorProperty> getProperties() {
		return properties;
	}
	@JsonProperty("properties")
	public void setProperties(List<DoorProperty> properties) {
		this.properties = properties;
	}
}

