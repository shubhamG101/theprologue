package com.walmart.framework.utilities.jms;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;

import com.walmart.framework.supplychain.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.io.FileReader;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

public class KafkaUtils {

	@Autowired
	Environment environment;

	String topicName = "ow_us_18_orders";

	Logger logger = LogManager.getLogger(KafkaUtils.class);

	public Properties getProducerProperties() {
		// create instance for properties to access producer configs
		Properties props = new Properties();

		//props.put("bootstrap.servers", "kafkav10.stg.ow-kafka0.replflow.prod.walmart.com:9092");
		props.put("bootstrap.servers", "kafka-520016960-5-532141789.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"+
				"kafka-520016960-1-532141777.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"+
				"kafka-520016960-6-532141792.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"+
				"kafka-520016960-3-532141783.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"+
				"kafka-520016960-2-532141780.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092,"+
				"kafka-520016960-4-532141786.stg-westus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-westus-2.prod.us.walmart.net:9092");
		//props.put("bootstrap.servers", "kafka-498637915-6-532134081.stg-southcentralus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092, kafka-498637915-2-532134069.stg-southcentralus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092, kafka-498637915-5-532134078.stg-southcentralus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092, kafka-498637915-4-532134075.stg-southcentralus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092, kafka-498637915-3-532134072.stg-southcentralus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092, kafka-498637915-1-532134066.stg-southcentralus-az.kafka-shared-az-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092");
		// Set acknowledgements for producer requests.
		props.put("acks", "all");
		// If the request fails, the producer can automatically retry,
		props.put("retries", 0);
		// Specify buffer size in config
		props.put("batch.size", 16384);
		// Reduce the no of requests less than 0
		props.put("linger.ms", 1);
		// The buffer.memory controls the total amount of memory available to
		// the producer for buffering.
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		return props;

	}

	public void publish(JSONArray ja) throws JSONException {
		if(Config.DC!=DC_TYPE.SAMS) {
			topicName = "ow_us_1_orders";
		}
		logger.info(ja);
		Producer<String, String> producer = new KafkaProducer<String, String>(getProducerProperties());

			for (int i = 0; i < ja.size(); i++) {
				JSONObject orderObj = (JSONObject) ja.get(i);
				if(orderObj.get("poType")==null||orderObj.get("poType").toString().equals("3")||orderObj.get("poType").toString().equals("43")){
					producer.send(new ProducerRecord<String, String>(topicName, String.valueOf(i), ja.get(i).toString()));
					logger.info("Published orders : " + ja.get(i).toString());
				} else {
					String poNum = orderObj.get("poNumber").toString();
					orderObj.put("poNumber", "");
					producer.send(new ProducerRecord<String, String>(topicName, String.valueOf(i), ja.get(i).toString()));
					logger.info("Published orders : " + ja.get(i).toString());
					orderObj.put("poNumber", poNum);
				}			
			}

		logger.info("Published orders : " + ja.toJSONString());
		producer.close();
	}
	
	public void sendTriggerBajaToDownloadOrders() {

		Producer<String, String> producer = new KafkaProducer<String, String>(getProducerProperties());

		for (int i = 0; i < 1; i++) {
			producer.send(new ProducerRecord<String, String>(topicName, "7390"));
			logger.info("Trigger send to download Baja orders");
		}
		
		producer.close();
	}

	public void sendCreateOrUpdateGLSTripMessage(String message, String topicName, String eventName, Integer tripId) {
		Map<String, Object> props = new HashMap<>();

		// Kafka Properties + Headers for Trip Create and Update
//		String kafkaBrokerOldShared = "kafka-1048092748-2-1055601939.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-4-1055601945.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-14-1055601987.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-5-1055601948.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-9-1055601960.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-3-1055601942.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-10-1055601963.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-1-1055601936.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-8-1055601957.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-15-1055601993.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-7-1055601954.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-6-1055601951.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-13-1055601980.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-11-1055601967.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-12-1055601974.stg-southcentralus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092";
//		String kafkaBrokerNewShared = "kafka-980199677-15-1055602175.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-9-1055602132.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-11-1055602146.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-5-1055602105.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-6-1055602112.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-12-1055602153.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-3-1055602090.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-14-1055602167.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-13-1055602160.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-10-1055602138.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-4-1055602097.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-8-1055602125.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-2-1055602081.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-7-1055602119.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092,kafka-980199677-1-1055602074.stg-westus-az.kafka-shared-non-prod-1-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9092";
//		String kafkaBroker = "kafka-498637915-1-1282813190.scus.kafka-atlas-uwms-stg.ms-df-messaging.prod.us.walmart.net:9092,kafka-498637915-2-1282813193.scus.kafka-atlas-uwms-stg.ms-df-messaging.prod.us.walmart.net:9092,kafka-498637915-3-1282813196.scus.kafka-atlas-uwms-stg.ms-df-messaging.prod.us.walmart.net:9092";
		String kafkaBroker = environment.getProperty("KAFKA_BROKERS");
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBroker);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, environment.getProperty("KEY_SERIALIZER_CLASS_CONFIG"));
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, environment.getProperty("VALUE_SERIALIZER_CLASS_CONFIG"));
		props.put(ProducerConfig.CLIENT_ID_CONFIG, environment.getProperty("CLIENT_ID_CONFIG"));
		props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, environment.getProperty("ENABLE_IDEMPOTENCE_CONFIG"));
		props.put(ProducerConfig.ACKS_CONFIG, environment.getProperty("ACKS_CONFIG"));
		props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, environment.getProperty("BUFFER_MEMORY_CONFIG"));
		props.put(ProducerConfig.BATCH_SIZE_CONFIG, environment.getProperty("BATCH_SIZE_CONFIG"));
		props.put(ProducerConfig.LINGER_MS_CONFIG, environment.getProperty("LINGER_MS_CONFIG"));
		props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, environment.getProperty("MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION"));
		props.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, environment.getProperty("MAX_BLOCK_MS_CONFIG"));
		props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, environment.getProperty("REQUEST_TIMEOUT_MS_CONFIG"));
		props.put("delivery.timeout.ms", environment.getProperty("delivery.timeout.ms"));
		props.put(ProducerConfig.RETRIES_CONFIG, environment.getProperty("RETRIES_CONFIG"));
		props.put(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, environment.getProperty("MAX_REQUEST_SIZE_CONFIG"));

		JsonObject jsonObject = null;
		// Convert Message to JSON Object
		try {
			JsonParser jsonParser = new JsonParser();
			Object obj = jsonParser.parse(message);
			jsonObject = (JsonObject) obj;
		}catch (Exception ex){
			ex.printStackTrace();
		}

		// Produce Message to Kafka Topic
		Producer<String, String> producer = null;
		try {
			String currentDate = new Timestamp(System.currentTimeMillis()).toString().split(" ")[0];
			// Change-1 put headers in getBytes()
			String facilityNum = environment.getProperty("facility_num");
			RecordHeader headers = new RecordHeader("facilityNum", facilityNum.getBytes());
			RecordHeader headers2 = new RecordHeader("facilityCountryCode", "US".getBytes());
			RecordHeader header3 = new RecordHeader("WMT_Event",eventName.getBytes());
			String currentTs = LocalDateTime.now()+"Z";
			if(!eventName.equalsIgnoreCase("Created") && !eventName.equalsIgnoreCase("Cancel")) {
				currentTs = null;
			}
//			else if(eventName.equalsIgnoreCase("Cancel")) {
//				currentTs = currentDate + "T13:29:23.000Z";
//			}
			RecordHeader wmt_eventTs = new RecordHeader("WMT_EventTs", String.valueOf(currentTs).getBytes());
			String correlationIdString = UUID.randomUUID().toString();
			RecordHeader correlationId = new RecordHeader("wmtCorrelationId", correlationIdString.getBytes());
			RecordHeader wmt_CorrelationId = new RecordHeader("WMT_CorrelationId", correlationIdString.getBytes());
			producer = new KafkaProducer<String, String>(props);
			// Change-2 change topic name
			String key = "";
			if(eventName.equalsIgnoreCase("Created") || eventName.equalsIgnoreCase("Cancel")) {
				key = currentDate.replaceAll("-","").substring(2) + "-"+tripId;
			}
			ProducerRecord<String, String> score_lp_release_plan_perf = new ProducerRecord<>(topicName, key, jsonObject.toString());
			// Change-3 add headers
			score_lp_release_plan_perf.headers().add(headers);
			score_lp_release_plan_perf.headers().add(headers2);
			score_lp_release_plan_perf.headers().add(header3);
			score_lp_release_plan_perf.headers().add(wmt_eventTs);
			if(!eventName.equalsIgnoreCase("Created") && !eventName.equalsIgnoreCase("Cancel")) {
				score_lp_release_plan_perf.headers().add(correlationId);
			} else if(eventName.equalsIgnoreCase("Cancel")) {
				score_lp_release_plan_perf.headers().add(wmt_CorrelationId);
			}
			producer.send(score_lp_release_plan_perf);
			logger.info("Message sent successfully");
		}catch (Exception ex){
			ex.printStackTrace();
		}finally {
//			logger.info("Closing producer");
//			producer.close();
		}
	}
}
