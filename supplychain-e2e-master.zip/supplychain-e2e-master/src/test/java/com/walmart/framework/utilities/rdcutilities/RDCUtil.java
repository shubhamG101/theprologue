package com.walmart.framework.utilities.rdcutilities;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.framework.supplychain.constants.Constants;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.supplychain.domain.rdc.AddDoor;
import com.walmart.framework.supplychain.domain.rdc.DoorAttribute;
import com.walmart.framework.supplychain.domain.rdc.DoorProperty;
import com.walmart.framework.supplychain.domain.rdc.SearchDoor;
import com.walmart.framework.utilities.db.DbUtils;
import com.walmart.framework.utilities.javautils.Assert;
import com.walmart.framework.utilities.javautils.JavaUtils;
import com.walmart.supplychain.nextgen.inventory.steps.webservices.InventoryHelper;

import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.serenitybdd.rest.SerenityRest;

public class RDCUtil {

	@Autowired
	Environment environment;

	@Autowired
	Environment endpoint;

	@Autowired
	DbUtils dbUtils;

	@Autowired
	InventoryHelper inventoryHelper;

	ObjectMapper om = new ObjectMapper();

	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	private static final String WITRON_INVENTORY_BOH_ENDPOINT = "witron_inv_boh_validation_ep";

	RetryPolicy retryPolicy = JavaUtils.getRetryPolicy(Constants.RETRY_EXECUTION_DELAY,
			Constants.RETRY_EXECUTION_COUNT);
	Logger logger = LogManager.getLogger(this.getClass());
	Response response;
	private static final String CONETENT_TYPE = "application/json";
	private static final String POSTMAN_TOKEN = "45d8712b-dd01-4096-891f-0450ff994b0e";
	private static final String USERID = "test";
	private static final String CACHE_CONTROL = "no-cache";
	private static final String WMT_USER_ID = "sysadmin";

	// This is the utility to get delivery details from GDM
	public String getrdcDelivery(String deliveryNumber) {

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getHeaderForDelivery())
					.get(MessageFormat.format(environment.getProperty("gdm_get_delivery"), deliveryNumber));
			Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_GET_DELIVERY, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	public void validateRDCDeliveryStatus(String deliveryNumber, String status) {

		Failsafe.with(retryPolicy).run(() -> {
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getHeaderForDelivery())
					.get(MessageFormat.format(environment.getProperty("gdm_get_delivery"), deliveryNumber));
			Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_GET_DELIVERY, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
			List<String> statusList = JsonPath.parse(response.asString()).read("$.deliveryStatus");
			Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_VALIDATE_DELIVERY_STATUS, status, statusList.get(0));
		});
	}

	// Headers for Delivery document
	public Headers getHeaderForDelivery() {
		Header postmanToken = new Header("Postman-Token", POSTMAN_TOKEN);
		Header userID = new Header("WMT-UserId", USERID);
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		Header cacheControl = new Header("cache-control", CACHE_CONTROL);
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(postmanToken);
		headerList.add(userID);
		headerList.add(cacheControl);
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(appType);
		return new Headers(headerList);
	}

	// get item mdm response

	public String getItemMDMDetails(String itemNum) {

		Failsafe.with(retryPolicy).run(() -> {
			logger.info(environment.getProperty("rdc_item_mdm"));
			logger.info(itemNum);
			response = SerenityRest.given().relaxedHTTPSValidation().body("[" + itemNum + "]")
					.headers(getHeaderForItemMDM()).post(environment.getProperty("rdc_item_mdm"));
			Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_GET_ITEM_MDM_RESPONSE, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	// item mdm header

	public Headers getHeaderForItemMDM() {
		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header userId = new Header("WMT-UserId", WMT_USER_ID);
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		Header tokeID = new Header("api-key", environment.getProperty("rdc_mdm_api_key"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(userId);
		headerList.add(appType);
		headerList.add(tokeID);
		logger.info(headerList.toString());
		return new Headers(headerList);

	}

	// cleanup GDM Delivery

	public String cleanUpGDMDelivery(String deliveryNumber) {

		Failsafe.with(retryPolicy).run(() -> {
			logger.info("cleaning delivery in GDM");
			response = SerenityRest.given().relaxedHTTPSValidation().headers(getHeaderForDeleteDelivery())
					.delete((MessageFormat.format(environment.getProperty("gdm_delete_delivery_ep"), deliveryNumber)));
			// Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_CLEAN_GDM,
			// Constants.SUCESS_STATUS_CODE,
			// response.getStatusCode());
		});
		return response.asString();
	}

	public Headers getHeaderForDeleteDelivery() {

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		return new Headers(headerList);

	}

	// search doors in Location

	public String searchDoorInLocation(String door) {

		SearchDoor searchDoor = new SearchDoor();
		List<SearchDoor> doorObjList = new ArrayList<SearchDoor>();
		List<String> doorList = new ArrayList<String>();
		List<Integer> typesList = new ArrayList<Integer>();
		doorList.add(door);
		typesList.add(2);

		searchDoor.setNames(doorList);
		searchDoor.setStatus(1);
		searchDoor.setTypes(typesList);
		searchDoor.setOrgUnitId(286);
		doorObjList.add(searchDoor);

		Failsafe.with(retryPolicy).run(() -> {
			logger.info("Search door end point:" + environment.getProperty("rdc_search_door"));
			response = SerenityRest.given().relaxedHTTPSValidation().body(om.writeValueAsString(doorObjList))
					.headers(getHeaderForDoorSearch()).post(environment.getProperty("rdc_search_door"));
			Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_SEARCH_DOOR, Constants.SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.asString());
		return response.asString();
	}

	// Headers for search Door
	public Headers getHeaderForDoorSearch() {

		Header countryCode = new Header("facilityCountryCode", environment.getProperty("country_code"));
		Header facilityNum = new Header("facilityNum", environment.getProperty("facility_num"));
		Header appType = new Header("Content-Type", CONETENT_TYPE);
		List<Header> headerList = new ArrayList<>();
		headerList.add(countryCode);
		headerList.add(facilityNum);
		headerList.add(appType);
		return new Headers(headerList);

	}

	// Add Door in Location

	public String addDoorInLocation(String door) {

		List<DoorProperty> doorPropertyList = new ArrayList<DoorProperty>();
		List<AddDoor> addDoorList = new ArrayList<AddDoor>();

		DoorAttribute doorAttribute1 = new DoorAttribute();
		doorAttribute1.setId(6);

		DoorAttribute doorAttribute2 = new DoorAttribute();
		doorAttribute1.setId(1);

		DoorAttribute doorAttribute3 = new DoorAttribute();
		doorAttribute1.setId(2);

		DoorProperty doorProperty1 = new DoorProperty();
		doorProperty1.setAttribute(doorAttribute1);
		doorProperty1.setValue("");

		DoorProperty doorProperty2 = new DoorProperty();
		doorProperty2.setAttribute(doorAttribute1);
		doorProperty2.setValue("");

		DoorProperty doorProperty3 = new DoorProperty();
		doorProperty3.setAttribute(doorAttribute1);
		doorProperty3.setValue("");

		doorPropertyList.add(doorProperty1);
		doorPropertyList.add(doorProperty2);
		doorPropertyList.add(doorProperty3);

		AddDoor addDoor = new AddDoor();
		addDoor.setName(door);
		addDoor.setStatus(1);
		addDoor.setType(2);
		addDoor.setOrgUnitId(286);
		addDoor.setxCoord(0);
		addDoor.setyCoord(0);
		addDoor.setzCoord(0);
		addDoor.setAttributes(null);
		addDoor.setProperties(doorPropertyList);
		addDoorList.add(addDoor);

		Failsafe.with(retryPolicy).run(() -> {
			logger.info("Search door end point:" + environment.getProperty("rdc_add_door"));
			response = SerenityRest.given().relaxedHTTPSValidation().body(om.writeValueAsString(addDoorList))
					.headers(getHeaderForAddDoor()).post(environment.getProperty("rdc_add_door"));
			Assert.assertEquals(ErrorCodes.RDC_FAILED_TO_ADD_DOOR, Constants.CREATE_SUCESS_STATUS_CODE,
					response.getStatusCode());
		});
		logger.info(response.getStatusCode());
		return String.valueOf(response.getStatusCode());
	}
	
	// Headers for Add Door
		public Headers getHeaderForAddDoor() {

			Header appType = new Header("Content-Type", CONETENT_TYPE);
			List<Header> headerList = new ArrayList<>();
			headerList.add(appType);
			return new Headers(headerList);
		}
}
