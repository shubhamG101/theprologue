package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "maxCube",
        "warehouseRotationTypeCode",
        "maxHeight",
        "maxWeight",
        "outboundStackGroup",
        "shipGroupId",
        "isMergeable",
        "weight",
        "height",
        "width",
        "depth",
        "wareHouseGroupCode",
        "wareHouseAreaCode",
        "acceptableTemperaturelow",
        "acceptableTemperatureHigh",
        "temperatureUOM",
        "samePalletIndicator",
        "xrefId",
        "profiledWarehouseArea",
        "profiledWarehouseArea",
        "receiveDate"
})
public class WitronItemDetails {

	@JsonProperty("maxCube")
    private String maxCube;
	@JsonProperty("warehouseRotationTypeCode")
    private String warehouseRotationTypeCode;
	@JsonProperty("maxHeight")
    private String maxHeight;
	@JsonProperty("maxWeight")
    private String maxWeight;
	@JsonProperty("outboundStackGroup")
    private String outboundStackGroup;
	@JsonProperty("shipGroupId")
    private String shipGroupId;
	@JsonProperty("isMergeable")
    private boolean isMergeable;
	@JsonProperty("weight")
    private String weight;
	@JsonProperty("height")
    private String height;
	@JsonProperty("width")
    private String width;
	@JsonProperty("depth")
    private String depth;
	@JsonProperty("wareHouseGroupCode")
    private String wareHouseGroupCode;
	@JsonProperty("wareHouseAreaCode")
    private String wareHouseAreaCode;
	@JsonProperty("acceptableTemperatureLow")
    private String acceptableTemperatureLow;
	@JsonProperty("acceptableTemperatureHigh")
    private String acceptableTemperatureHigh;
	@JsonProperty("temperatureUOM")
    private String temperatureUOM;
	@JsonProperty("samePalletIndicator")
    private String samePalletIndicator;
	@JsonProperty("xrefId")
    private String xrefId;
	@JsonProperty("profiledWarehouseArea")
    private String profiledWarehouseArea;
	@JsonProperty("receiveDate")
    private String receiveDate;
	public String getMaxCube() {
		return maxCube;
	}
	public void setMaxCube(String maxCube) {
		this.maxCube = maxCube;
	}
	public String getWarehouseRotationTypeCode() {
		return warehouseRotationTypeCode;
	}
	public void setWarehouseRotationTypeCode(String warehouseRotationTypeCode) {
		this.warehouseRotationTypeCode = warehouseRotationTypeCode;
	}
	public String getMaxHeight() {
		return maxHeight;
	}
	public void setMaxHeight(String maxHeight) {
		this.maxHeight = maxHeight;
	}
	public String getMaxWeight() {
		return maxWeight;
	}
	public void setMaxWeight(String maxWeight) {
		this.maxWeight = maxWeight;
	}
	public String getOutboundStackGroup() {
		return outboundStackGroup;
	}
	public void setOutboundStackGroup(String outboundStackGroup) {
		this.outboundStackGroup = outboundStackGroup;
	}
	public String getShipGroupId() {
		return shipGroupId;
	}
	public void setShipGroupId(String shipGroupId) {
		this.shipGroupId = shipGroupId;
	}
	public boolean isMergeable() {
		return isMergeable;
	}
	public void setMergeable(boolean isMergeable) {
		this.isMergeable = isMergeable;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getDepth() {
		return depth;
	}
	public void setDepth(String depth) {
		this.depth = depth;
	}
	public String getWareHouseGroupCode() {
		return wareHouseGroupCode;
	}
	public void setWareHouseGroupCode(String wareHouseGroupCode) {
		this.wareHouseGroupCode = wareHouseGroupCode;
	}
	public String getWareHouseAreaCode() {
		return wareHouseAreaCode;
	}
	public void setWareHouseAreaCode(String wareHouseAreaCode) {
		this.wareHouseAreaCode = wareHouseAreaCode;
	}
	public String getAcceptableTemperatureLow() {
		return acceptableTemperatureLow;
	}
	public void setAcceptableTemperatureLow(String acceptableTemperatureLow) {
		this.acceptableTemperatureLow = acceptableTemperatureLow;
	}
	public String getAcceptableTemperatureHigh() {
		return acceptableTemperatureHigh;
	}
	public void setAcceptableTemperatureHigh(String acceptableTemperatureHigh) {
		this.acceptableTemperatureHigh = acceptableTemperatureHigh;
	}
	public String getTemperatureUOM() {
		return temperatureUOM;
	}
	public void setTemperatureUOM(String temperatureUOM) {
		this.temperatureUOM = temperatureUOM;
	}
	public String getSamePalletIndicator() {
		return samePalletIndicator;
	}
	public void setSamePalletIndicator(String samePalletIndicator) {
		this.samePalletIndicator = samePalletIndicator;
	}
	public String getXrefId() {
		return xrefId;
	}
	public void setXrefId(String xrefId) {
		this.xrefId = xrefId;
	}
	public String getProfiledWarehouseArea() {
		return profiledWarehouseArea;
	}
	public void setProfiledWarehouseArea(String profiledWarehouseArea) {
		this.profiledWarehouseArea = profiledWarehouseArea;
	}
	public String getReceiveDate() {
		return receiveDate;
	}
	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}
}
