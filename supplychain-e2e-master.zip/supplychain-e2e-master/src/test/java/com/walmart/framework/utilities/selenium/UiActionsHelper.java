package com.walmart.framework.utilities.selenium;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.functions.ExpectedCondition;

public class UiActionsHelper extends SerenityHelper{
	
	Logger logger = LogManager.getLogger(this.getClass());
	private JavascriptExecutor js;
	private Actions action;
	
	
	public void sync(WebDriver driver, WebElement element) {
		
		Wait<WebDriver> wait = new WebDriverWait(driver, 30).ignoring(StaleElementReferenceException.class);
		wait.until(ExpectedConditions.visibilityOf(element));
		
	}
	
	public void syncElementNotPresent(WebElement element) {
		
		List<WebElement> elements = new ArrayList<WebElement>();
		elements.add(element);
		Wait<WebDriver> wait = new WebDriverWait(getDriver(), 100).ignoring(StaleElementReferenceException.class);
		wait.until(ExpectedConditions.invisibilityOfAllElements(elements));
		
	}
	
	public void syncClickable(WebElement element) {
		
		Wait<WebDriver> wait = new WebDriverWait(getDriver(), 15).ignoring(StaleElementReferenceException.class);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public void jsClick(WebElement element) {
		js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();", element);
		logger.info("Clicked element using javascrpit executor ===");
	}
	
	public void pageLoadWait(WebDriver driver) {
		
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete"); 
			}
		};
		
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(pageLoadCondition);
		
	}
	
	
	public String getElementText(WebElement element) {
		sync(getDriver(), element);
		return element.getText().trim();
	}
	
	public void scrollToElement(WebElement element) {
		js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}
	
	public void moveToElementAndClick(WebElement element) {
		action = new Actions(getDriver());
		action.moveToElement(element).click().build().perform();
		logger.info("Clicked element using actions class ====");
	}
	
	public void moveToElement(WebElement element) {
		action = new Actions(getDriver());
		action.moveToElement(element).build().perform();
		logger.info("Clicked element using actions class ====");
	}
	
	public void jsClear(WebElement element) {
		js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].value='';", element);
		logger.info("Cleared element using javascrpit executor ===");
	}
	
	public void switchToFrameWithElement(WebElement element) {
		getDriver().switchTo().frame(element);
		logger.info("Switched to working frame {} -----> ", element);
	}

	public void switchToParentFrame() {
		getDriver().switchTo().parentFrame();
		logger.info("Switched to Parent Content {} -----> ");
	}

	public void switchToDefaultContent() {
		getDriver().switchTo().defaultContent();
		logger.info("Switched to DefaultContent {} -----> ");
	}

}
