package com.walmart.framework.utilities.selenium;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.strati.libs.commons.configuration.PropertiesConfiguration;
import net.thucydides.core.webdriver.DriverSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;
import com.walmart.framework.utilities.reporting.AutomationFailure;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class CustomDriver implements DriverSource {
	Logger logger = LogManager.getLogger(this.getClass());
	PropertiesConfiguration envProperties = null;
	private static final String EXTENSION_FOR_DRIVER = ".exe";

	@Override
	public WebDriver newDriver() {
		Map<String, Object> chromePreferences = new HashMap<>();
		String downloadDir = System.getProperty("user.dir") + "/target";
		logger.info("Download Location" + downloadDir);

		String config = null;
		try {
			envProperties = new PropertiesConfiguration("./src/test/resources/env.properties");
			config = (String) envProperties.getProperty("webdriver.drivertype");
			if (config.equalsIgnoreCase("appium") && System.getProperty("appName") != null) {
				AndroidDriver<AndroidElement> androidDriver = getAndroidDriver(System.getProperty("appName"));
				return androidDriver;

			} else {

				if (Config.isPipeline) {
					// try { WebDriverManager.chromedriver().setup(); }catch(Exception e) {
					String driverPath = getChromeDriverPath();
					System.setProperty("webdriver.chrome.driver", driverPath);
				} else {
					System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver");
				}
			}

			Map<String, Object> deviceMetrics = new HashMap<>();

			deviceMetrics.put("width", 360);

			deviceMetrics.put("height", 640);

			deviceMetrics.put("pixelRatio", 3.0);

			Map<String, Object> mobileEmulation = new HashMap<>();

			mobileEmulation.put("deviceMetrics", deviceMetrics);

			mobileEmulation.put("userAgent",
					"Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19");

			chromePreferences.put("profile.default_content_settings.popups", 0);
			chromePreferences.put("download.prompt_for_download", false);
			chromePreferences.put("download.default_directory", downloadDir);
			chromePreferences.put("pdfjs.disabled", true);
			chromePreferences.put("plugins.always_open_pdf_externally", true);

			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--headless");
			chromeOptions.addArguments("--no-sandbox");
			chromeOptions.addArguments("--disable-dev-shm-usage");
			chromeOptions.addArguments("--window-size=1920,1080");
			chromeOptions.addArguments("--start-maximized");
			chromeOptions.setExperimentalOption("prefs", chromePreferences);
			//chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);

			chromeOptions.addArguments("--disable-web-security");
			return new ChromeDriver(chromeOptions);
		} catch (Exception e) {
			throw new AutomationFailure("Driver didn't launch...", e);
		}
	}

	@Override
	public boolean takesScreenshots() {
		return true;
	}

	private AndroidDriver<AndroidElement> getAndroidDriver(String appName) {
		AndroidDriver<AndroidElement> androidDriver = setAppProperties(
				(String) envProperties.getProperty(appName + "_run_config"),
				(String) envProperties.getProperty(appName + "_appPackage"),
				(String) envProperties.getProperty(appName + "_appActivity"),
				(String) envProperties.getProperty(appName + "_os_version"),
				(String) envProperties.getProperty(appName + "_apk_downloadpath"),
				(String) envProperties.getProperty(appName + "_appWaitActivity"),
				(String) envProperties.getProperty(appName + "_grid_url"),
				(String) envProperties.getProperty(appName + "_emulator_url"),
				(String) envProperties.getProperty(appName + "_avd"),
				(String) envProperties.getProperty(appName + "_emulator_id"),
				(String) envProperties.getProperty("testobject_api_key"),
				(String) envProperties.getProperty("tunnel_identifier"),
				(String) envProperties.getProperty("deviceName"),
				(String) envProperties.getProperty("private_devices_only"));
		return androidDriver;
	}

	private AndroidDriver<AndroidElement> setAppProperties(String... args) {
		AndroidDriver<AndroidElement> driver = null;
		URL serverURL = null;
		DesiredCapabilities capabilities = new DesiredCapabilities();
		try {
			if (args[0].equals("LOCAL")) {
				logger.info("Setting Appium LOCAL capabilities...");
				capabilities.setCapability("deviceName", "testDevice");
				capabilities.setCapability(CapabilityType.PLATFORM, "Android");
				capabilities.setCapability("automationName", "uiautomator2");
				capabilities.setCapability("appPackage", args[1]);
				logger.info("appPackage : {}", args[1]);
				capabilities.setCapability("appActivity", args[2]);
				logger.info("appActivity : {}", args[2]);
				capabilities.setCapability("platformVersion", args[3]);
				logger.info("platformVersion : {}", args[3]);
				capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
				capabilities.setCapability("avd", args[8]);
				capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 300);
				serverURL = new URL(args[7]);
				//driver = new AndroidDriver<AndroidElement>(serverURL, capabilities);
			} else if (args[0].equals("GRID")){

				logger.info("Setting Appium GRID capabilities...");
				
				/* Saucelab POC
				 * 
				 * // this will set a proxy for all https traffic for URLs
		        System.setProperty("https.proxyHost", "sysproxy.wal-mart.com");
		        System.setProperty("https.proxyPort", "8080");

		       // this will set a proxy for all http (not https) traffic for URLs
		        System.setProperty("http.proxyHost", "sysproxy.wal-mart.com");
		        System.setProperty("http.proxyPort", "8080");

				capabilities.setCapability("testobject_api_key",args[10]);
				logger.info("testobject api key : {}", args[10]);

				capabilities.setCapability("tunnelIdentifier",args[11]);
				logger.info("tunnel Identifier : {}", args[11]);

				String[] appid = {"1","2","3"};
				capabilities.setCapability("testobject_app_id",appid);
				logger.info("app Id's : {}",appid);

				capabilities.setCapability("deviceName",args[12]);
				logger.info("device Name : {}",args[12]);

				capabilities.setCapability("privateDevicesOnly",args[13]);
				logger.info("private Devices Only : {}", args[13]);*/
				
				/*capabilities.setCapability("app",args[4]);
				logger.info("app : {}", args[4]);*/
				capabilities.setCapability("platformName", "Android");
				logger.info("platformName : {}","Android");
				
				capabilities.setCapability("automationName", "uiautomator2");
				capabilities.setCapability("appPackage", args[1]);
				logger.info("appPackage : {}", args[1]);
				capabilities.setCapability("appActivity", args[2]);
				logger.info("appActivity : {}", args[2]);
				
				capabilities.setCapability("appWaitActivity", args[5]);
				logger.info("appWaitActivity : {}", args[5]);
				capabilities.setCapability("udid", args[9]);
				logger.info("avd : {}", args[9]);
				capabilities.setCapability("deviceName", "testDevice");
				serverURL = new URL(args[6]);

				/* Appium GRID with cluster POC
				 * 
				 * capabilities.setCapability("appium:deviceName", "Android");
				capabilities.setCapability("appium:platformName", "Android");
				capabilities.setCapability("appium:automationName", "UIAutomator2");
				capabilities.setCapability("appium:app", args[4]);
				logger.info("app : {}", args[4]);
				capabilities.setCapability("appium:appActivity", args[2]);
				logger.info("appActivity : {}", args[2]);
				capabilities.setCapability("appium:appPackage", args[1]);
				logger.info("appPackage : {}", args[1]);
				capabilities.setCapability("appium:appWaitActivity", args[5]);
				logger.info("appWaitActivity : {}", args[5]);
				capabilities.setCapability("appium:appWaitDuration", "10000");
				// capabilities.setCapability("headless", "False");
				capabilities.setCapability("appium:noReset", "False");
				capabilities.setCapability("appium:fullReset", "True");
				capabilities.setCapability("appium:adbExecTimeout", 50000);
				serverURL = new URL(args[6]);*/
			}
			logger.info("Server URL : {}", serverURL);
			driver = new AndroidDriver<AndroidElement>(serverURL, capabilities);
			logger.info("Mobile app launched... ");
			Thread.sleep(2000);
		} catch (MalformedURLException | InterruptedException e) {
			e.printStackTrace();
		}
		return driver;
	}

	private String getChromeVersion() {
		try {
			logger.info("Checking Chrome version ");
			String line;
			Process p = Runtime.getRuntime().exec(
					"powershell -command \"(Get-Item 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe').VersionInfo");
			p.waitFor();
			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			while ((line = input.readLine()) != null) {
				if (line.contains("chrome")) {
					logger.info("Line {}", line);
					String version = line.substring(0, line.indexOf('.'));
					logger.info("Version {}", version);
					return "" + Integer.parseInt(version);
				}
			}

			input.close();
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}

	private String getChromeDriverPath() {
		String version = getChromeVersion();
		String driverPath = System.getProperty("user.dir") + "/windriver/chromedriver";
		String newDriverPath = driverPath + version + EXTENSION_FOR_DRIVER;
		if (version != null && new File(newDriverPath).exists()) {
			driverPath = newDriverPath;
		} else {
			driverPath += EXTENSION_FOR_DRIVER;
		}
		logger.info("Chrome driver path:{}", driverPath);
		return driverPath;
	}

}
