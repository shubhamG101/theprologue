package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "thorSku", "totalUnitCount", "element", "icWorkflow", "icReason"})
public class ThorAdjustment {
	
	@JsonProperty("thorSku")
	private String thorSku;
	@JsonProperty("totalUnitCount")
	private int totalUnitCount;
	@JsonProperty("element")
	private String element;
	@JsonProperty("icWorkflow")
	private String icWorkflow;
	@JsonProperty("icReason")
	private String icReason;
	
	@JsonProperty("thorSku")
	public String getThorSku() {
		return thorSku;
	}
	@JsonProperty("thorSku")
	public void setThorSku(String thorSku) {
		this.thorSku = thorSku;
	}
	@JsonProperty("totalUnitCount")
	public int getTotalUnitCount() {
		return totalUnitCount;
	}
	@JsonProperty("totalUnitCount")
	public void setTotalUnitCount(int totalUnitCount) {
		this.totalUnitCount = totalUnitCount;
	}
	@JsonProperty("element")
	public String getElement() {
		return element;
	}
	@JsonProperty("element")
	public void setElement(String element) {
		this.element = element;
	}
	@JsonProperty("icWorkflow")
	public String getIcWorkflow() {
		return icWorkflow;
	}
	@JsonProperty("icWorkflow")
	public void setIcWorkflow(String icWorkflow) {
		this.icWorkflow = icWorkflow;
	}
	@JsonProperty("icReason")
	public String getIcReason() {
		return icReason;
	}
	@JsonProperty("icReason")
	public void setIcReason(String icReason) {
		this.icReason = icReason;
	}
}

