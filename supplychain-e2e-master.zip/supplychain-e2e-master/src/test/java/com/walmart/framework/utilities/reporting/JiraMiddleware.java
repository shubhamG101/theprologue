package com.walmart.framework.utilities.reporting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.walmart.execution.dto.FeatureStatus;
import com.walmart.execution.dto.Scenario;
import com.walmart.framework.supplychain.constants.ErrorCodes;
import com.walmart.framework.utilities.javautils.JsonPathHelper;

import jiraintegration.core.JiraIntegration;
import jiraintegration.domain.issue.Issue;
import spring.SpringTestConfiguration;

enum JIRA_STATUS {
	DONE("DONE"), IN_PROGRESS("IN_PROGRESS_QA");
	private String value;

	JIRA_STATUS(String val) {
		this.value = val;
	}

	String getValue() {
		return this.value;
	}
}

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class JiraMiddleware {
	@Autowired
	JiraIntegration jira;
	@Autowired
	Environment applicationProperties;
	@Autowired
	JsonPathHelper jsonpath;
	Logger logger = LogManager.getLogger(JiraMiddleware.class);
	private static final String CODE_SNIPPET_TAG = "{code}";
	private static final String ERROR_CODE_SEPARATOR = ":-";
	private static final String AUTOMATION_LABEL = "_E2E_AUTOMATION";
	private static final String AUTOMATION_LABEL_FOR_TEST = "_E2E";
	private static final String FEATURE_NAME_PRE_APPENDER = "Feature Name:";
	private static final String SCENARIO_NAME_PRE_APPENDER = "Scenario Name:";
	private static final String AUTOMATION_USER_NAME="SVC_e2e";
	private static final String IS_DEFAULT_ASSIGNEE_KEY="is_default_assignee";
	private static final String TEST_RUN_JSONPATH="$.[?(@.key==\"#0#\")].id";
	private static final String JIRA_URL="jira.walmart.com";
	
	public String create(FeatureStatus status, String program, String buildUrl, String env, String reportUrl,
			String errorCode, String testCaseJiraID) {
		String issueSummary = "";
		String reasonForFailure = status.getReasonForFailure();
		if (reasonForFailure == null || !reasonForFailure.contains(ERROR_CODE_SEPARATOR)) {
			logger.info("reason for failure:{} is null or does not contain ErrorCode separator", reasonForFailure);
			return "";
		}else {
			issueSummary = reasonForFailure.substring(
					reasonForFailure.indexOf(ERROR_CODE_SEPARATOR) + ERROR_CODE_SEPARATOR.length(),
					reasonForFailure.length());
			status.setReasonForFailure(issueSummary);
			logger.info("Errorcode:{}, issue:{}", errorCode, issueSummary);
		}
		if (errorCode == null || !ErrorCodes.isValidErrorCode(errorCode)) {
			logger.info("Errorcode:{}, is not a valid error code", errorCode);
			return "";
		}
		ErrorCodes errorCodeEnum=ErrorCodes.getErrorCodeFromKey(errorCode);
		String priority=errorCodeEnum.getPriority().getValue();
		String releaseLabelKey=status.getJiraLabelPropertyKey();
		String releaseMileStoneLabel=null;
		if(releaseLabelKey==null) {
			releaseMileStoneLabel=applicationProperties.getProperty("release_label");
		}else {
			releaseMileStoneLabel=applicationProperties.getProperty(status.getJiraLabelPropertyKey());
		}
		List<String> labels=null;
		if(releaseMileStoneLabel!=null&&!releaseMileStoneLabel.equals("")) {
			labels = Arrays.asList(errorCode, program.toUpperCase() + AUTOMATION_LABEL,releaseMileStoneLabel);
		}else {
			labels = Arrays.asList(errorCode, program.toUpperCase() + AUTOMATION_LABEL);
		}
		try {Thread.sleep(5000);}catch(Exception e) {logger.error(e);}//created jira ticket to come in search takes some time
		List<Issue> issues = jira.getJiraIssueDetailsForLabels(labels);
		Issue issue=issues.isEmpty()?null:issues.get(0);
		String extraInformation="";
		String threadName=Thread.currentThread().getName();
		if(errorCodeEnum.getDescription().get(threadName)!=null&&!errorCodeEnum.getDescription().get(threadName).equals("")) {
			
			extraInformation="\n\nIssue Description:"+errorCodeEnum.getDescription().get(threadName);
			errorCodeEnum.getDescription().put(threadName, ""); //update to empty to avoid any further impact
		}
		issueSummary = program.toUpperCase() + "-" + issueSummary;
		String issueDescription = FEATURE_NAME_PRE_APPENDER + status.getFeatureName() 
				+"\n\n"+SCENARIO_NAME_PRE_APPENDER+status.getFailedScenario()
				+ "\n\nIssue Summary:" + issueSummary+extraInformation
				+ "\n\nAutomation Build Url : " + buildUrl + "\n\nReport url : " + reportUrl
				+ "\n\n Please find the below TestFlowData\n" + CODE_SNIPPET_TAG + status.getTestFlowData()
				+ CODE_SNIPPET_TAG;
		
		if (issue != null && !issue.getStatus().equalsIgnoreCase(JIRA_STATUS.DONE.getValue())) {
			logger.info("No need to create new issue...Issue :{} already exists", issue.getId());
			/*
			 * Add the code to check the status of the ticket and reopen if it is DEV
			 * COMPLETE/INPROGRESS QA
			 */
			jira.addJiraComment(issue.getId(), issueDescription);
			return issue.getId();

		} else {
			String isDefaultAssigneeVal=applicationProperties.getProperty(IS_DEFAULT_ASSIGNEE_KEY);
			boolean isDefaultAssignee=isDefaultAssigneeVal!=null&&Boolean.parseBoolean(isDefaultAssigneeVal);
			String assignee =null;
			if(isDefaultAssignee) {
				assignee=AUTOMATION_USER_NAME;
			}else {
				assignee=status.getJiraAssignee();
			}
			logger.info("Creating new issue");
			logger.info("Assignee:{}", assignee);
			Issue reportIssue=new Issue();
			reportIssue.setSummary(issueSummary);
			reportIssue.setDescription(issueDescription);
			reportIssue.setLabels(labels);
			reportIssue.setAssignee(assignee);
			reportIssue.setPriority(priority);
			reportIssue.setComponent(status.getComponentName());
			reportIssue.setApplicationServiceKey(applicationProperties.getProperty("jira_application_service_key"));
			reportIssue.setSeverity("2 - Major Problem");
			String affectsVersion=applicationProperties.getProperty("affects_version");
			if(affectsVersion!=null&&!affectsVersion.equals("")) {
				reportIssue.setAffectsVersion(Arrays.asList(affectsVersion.split(",")));
			}
			if(env.equalsIgnoreCase("qa")) {
				reportIssue.setFoundIn("Test/QA");
			}else {
				reportIssue.setFoundIn("Staging");
			}
			String ticketId = jira.createIssue(reportIssue);
			logger.info("Created issue:{}", ticketId);
			uploadLogsAndScreenshots(status,ticketId);
			return ticketId;
		}
	}
	public List<Issue> getListOfJiraIssuesForFeature(String program,String featureName){
		String label=program.toUpperCase() + AUTOMATION_LABEL;
		featureName=FEATURE_NAME_PRE_APPENDER+featureName;
		return jira.getListOfIssuesForParticularDesc(label, featureName);
	}
	public Issue getTestCasesByScenarioName(String label,String scenarionName){
		Issue matchedIssue=null;
		Issue issue=new Issue();
		issue.setSummary(scenarionName);
		issue.setType("Test");
		issue.setLabels(Arrays.asList(label));
		List<Issue> listOfTests =jira.getListofIssuesByIssueDetails(issue);
		int matchedCount=0;
		for(Issue issueFromResult:listOfTests) {
			if(issueFromResult.getSummary().equalsIgnoreCase(issue.getSummary())) {
				matchedIssue=issueFromResult;
				matchedCount++;
			}
		}
		if(matchedCount>1) {
			logger.info("+++ Duplicate testcases found for summary:{}",issue.getSummary());
		}
		return matchedIssue;
	}
	public void addJiraLabel(Issue testcase, String label) {
		int statusCode=jira.addLabel(testcase.getId(), label);
		if(statusCode==204) {
			logger.info("Added jira label for testcase:{} ",testcase.getId());
		}
	}
	public String getLabelForTestcase(String program) {
		return program.toUpperCase() + AUTOMATION_LABEL_FOR_TEST;
	}
	public String createTest(String scenarioName,String label,String steps) {
		Issue issue=new Issue();
		issue.setType("Test");
		issue.setSummary(scenarioName);
		issue.setLabels(Arrays.asList(label));
		issue.setAssignee(AUTOMATION_USER_NAME);
		issue.setFeatureSteps(steps);
		return jira.createIssue(issue);
	}
	public boolean closeIssue(String jiraId,String buildUrl){
		boolean isSuccess= jira.closeIssue(jiraId);
		if(isSuccess) {
			String comment="This issue is validated as part of Automation Build: "+buildUrl;
			jira.addJiraComment(jiraId, comment);
		}
		return isSuccess;
	}
	public void uploadLogsAndScreenshots(FeatureStatus featureStatus,String defectId) {
		Set<String> listOfFiles=featureStatus.getListOfFilesToBeUploaded();
		int noOfFilesUploaded=0;
		if(listOfFiles!=null&&!listOfFiles.isEmpty()) {
			for(String fileLoc:listOfFiles) {
				jira.addAttachment(defectId, fileLoc);
				noOfFilesUploaded++;
				if(noOfFilesUploaded>6) {
					logger.info("Total Number of file upload can not be more than 6");
					break;
				}
			}
		}
	}
	public void executeScenarios(List<Scenario> listOfScenarios,String program,String buildNo,String env) {
		String testExecutionSummary=program.toUpperCase()+"_"+env.toUpperCase()+"_BUILD_"+buildNo;
		String testExecutionJiraId=jira.createTestExecution(testExecutionSummary,AUTOMATION_USER_NAME);
		List<String> listOfTestCaseIds=getListOfTestsToBeAdded(listOfScenarios);
		jira.addTestCasesToTestExecution(testExecutionJiraId,listOfTestCaseIds);
		List<Scenario> failedScenarios=getListOfScenariosByStatus(listOfScenarios, Scenario.STATUS.FAIL);
		List<String> listOfTestsPassed=getListOfTestsByStatus(listOfScenarios, Scenario.STATUS.PASS);
		List<String> listOfTestsFailed=getListOfTestsByStatus(listOfScenarios, Scenario.STATUS.FAIL);
		if(!listOfTestsPassed.isEmpty()) {
			for(String testCaseKey:listOfTestsPassed) {//This for loop is required only because current user does not support batch exec due to No Email
				jira.executeTests(testExecutionJiraId,testCaseKey , true);
			}
		}
		if(!listOfTestsFailed.isEmpty()) {
			for(String testCaseKey:listOfTestsFailed) {
				jira.executeTests(testExecutionJiraId,testCaseKey, false);
			}
		}
		String testCasesForExecResponse=jira.getTestRunIdFromTestExecution(testExecutionJiraId);
		for(Scenario scenario:failedScenarios) {
			String testExecutionRunId=getTestRunId(testCasesForExecResponse, scenario.getTestCaseJiraID());
			if(!testExecutionRunId.equals("")) {
				jira.updateDefectIdForTestRun(testExecutionRunId, scenario.getJiraId());
			}else {
				logger.error("Test Run not found");
			}
		}
		
	}
	private String getTestRunId(String resp,String testcaseKey) {
		if(resp!=null&&!resp.equals(""))
			return ""+jsonpath.getFirst(resp,TEST_RUN_JSONPATH,testcaseKey );
		else
			return "";
	}
	private List<String> getListOfTestsToBeAdded(List<Scenario> listOfScenarios){
		List<String> listOfTestCaseIds=new ArrayList<>();
		for(Scenario scenario:listOfScenarios) {
			if(scenario.getTestCaseJiraID()!=null&&!scenario.getTestCaseJiraID().equals("")) {
				if(!listOfTestCaseIds.contains(scenario.getTestCaseJiraID())) {
					listOfTestCaseIds.add(scenario.getTestCaseJiraID());
				}
			}else {
				logger.info("~~~Scenario {} does not have testcase jira id",scenario.getScenarioName());
			}
		}
		return listOfTestCaseIds;
	}
	private List<String> getListOfTestsByStatus(List<Scenario> listOfScenarios,Scenario.STATUS status){
		List<String> listOfTestCaseIds=new ArrayList<>();
		for(Scenario scenario:listOfScenarios) {
			if(status==scenario.getStatus()&&scenario.getTestCaseJiraID()!=null&&!scenario.getTestCaseJiraID().equals("")&&!listOfTestCaseIds.contains(scenario.getTestCaseJiraID())) {
					listOfTestCaseIds.add(scenario.getTestCaseJiraID());
			}
		}
		return listOfTestCaseIds;
	}
	private List<Scenario> getListOfScenariosByStatus(List<Scenario> listOfScenarios,Scenario.STATUS status){
		List<Scenario> listOfFailedScenarios=new ArrayList<>();
		for(Scenario scenario:listOfScenarios) {
			if(status==scenario.getStatus()&&scenario.getTestCaseJiraID()!=null&&!scenario.getTestCaseJiraID().equals("")&&!isScenarioAlreadyExists(listOfFailedScenarios, scenario)) {
					listOfFailedScenarios.add(scenario);
			}
		}
		return listOfFailedScenarios;
	}
	private boolean isScenarioAlreadyExists(List<Scenario> listOfFailedScenarios,Scenario scenarioToBeChecked) {
		for(Scenario scenario:listOfFailedScenarios) {
			if(scenario.getScenarioName().equals(scenarioToBeChecked.getScenarioName())) {
				return true;
			}
		}
		return false;
	}
	public boolean isJiraStep(String step) {
		return step.contains(JIRA_URL);
	}
}
