package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "poNumber", "altPoNumber", "fc", "vendor", "poStatus", "placedDate", "scheduledDeliveryDate", "actualDeliveryDate", "purchasingCompany", "fcIssues", "scIssues", "skuIssues", "vendorIssues" })
public class SearchThorPO {

	@JsonProperty("poNumber")
	private String poNumber;
	@JsonProperty("altPoNumber")
	private String altPoNumber;
	@JsonProperty("fc")
	private String fc;
	@JsonProperty("vendor")
	private String vendor;
	@JsonProperty("poStatus")
	private String poStatus;
	@JsonProperty("placedDate")
	private String placedDate;
	@JsonProperty("scheduledDeliveryDate")
	private String scheduledDeliveryDate;
	@JsonProperty("actualDeliveryDate")
	private String actualDeliveryDate;
	@JsonProperty("purchasingCompany")
	private String purchasingCompany;
	@JsonProperty("fcIssues")
	private String fcIssues;
	@JsonProperty("scIssues")
	private String scIssues;
	@JsonProperty("skuIssues")
	private String skuIssues;
	@JsonProperty("vendorIssues")
	private String vendorIssues;
	
	@JsonProperty("poNumber")
	public String getPoNumber() {
		return poNumber;
	}
	@JsonProperty("poNumber")
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	@JsonProperty("altPoNumber")
	public String getAltPoNumber() {
		return altPoNumber;
	}
	@JsonProperty("altPoNumber")
	public void setAltPoNumber(String altPoNumber) {
		this.altPoNumber = altPoNumber;
	}
	@JsonProperty("fc")
	public String getFc() {
		return fc;
	}
	@JsonProperty("fc")
	public void setFc(String fc) {
		this.fc = fc;
	}
	@JsonProperty("vendor")
	public String getVendor() {
		return vendor;
	}
	@JsonProperty("vendor")
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	@JsonProperty("poStatus")
	public String getPoStatus() {
		return poStatus;
	}
	@JsonProperty("poStatus")
	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
	@JsonProperty("placedDate")
	public String getPlacedDate() {
		return placedDate;
	}
	@JsonProperty("placedDate")
	public void setPlacedDate(String placedDate) {
		this.placedDate = placedDate;
	}
	@JsonProperty("scheduledDeliveryDate")
	public String getScheduledDeliveryDate() {
		return scheduledDeliveryDate;
	}
	@JsonProperty("scheduledDeliveryDate")
	public void setScheduledDeliveryDate(String scheduledDeliveryDate) {
		this.scheduledDeliveryDate = scheduledDeliveryDate;
	}
	@JsonProperty("actualDeliveryDate")
	public String getActualDeliveryDate() {
		return actualDeliveryDate;
	}
	@JsonProperty("actualDeliveryDate")
	public void setActualDeliveryDate(String actualDeliveryDate) {
		this.actualDeliveryDate = actualDeliveryDate;
	}
	@JsonProperty("purchasingCompany")
	public String getPurchasingCompany() {
		return purchasingCompany;
	}
	@JsonProperty("purchasingCompany")
	public void setPurchasingCompany(String purchasingCompany) {
		this.purchasingCompany = purchasingCompany;
	}
	@JsonProperty("fcIssues")
	public String getFcIssues() {
		return fcIssues;
	}
	@JsonProperty("fcIssues")
	public void setFcIssues(String fcIssues) {
		this.fcIssues = fcIssues;
	}
	@JsonProperty("scIssues")
	public String getScIssues() {
		return scIssues;
	}
	@JsonProperty("scIssues")
	public void setScIssues(String scIssues) {
		this.scIssues = scIssues;
	}
	@JsonProperty("skuIssues")
	public String getSkuIssues() {
		return skuIssues;
	}
	@JsonProperty("skuIssues")
	public void setSkuIssues(String skuIssues) {
		this.skuIssues = skuIssues;
	}
	@JsonProperty("vendorIssues")
	public String getVendorIssues() {
		return vendorIssues;
	}
	@JsonProperty("vendorIssues")
	public void setVendorIssues(String vendorIssues) {
		this.vendorIssues = vendorIssues;
	}
	
}