/*package com.walmart.framework.utilities.jms;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQTopicConnectionFactory;
import com.walmart.framework.supplychain.constants.JMSConstants;

import javax.jms.*;


public class IBMMQController {

    private static QueueConnection connection;
    private static QueueSession session;
    private static QueueSender queueSender;
    private static TopicPublisher topicSender;
    private static String QueueManager;
    static String IBMMQ_QUEUE_CLIENT_ID = JMSConstants.IBMMQ_QUEUE_CLIENT_ID;
    static String IBMMQ_TOPIC_NAME = "";
    private static Connection topicConnection;
    private static Session topicSession;
    private static MessageConsumer consumer;
    private static final int TIMEOUT = 10000; // time to wait for the message in
                                              // a topic in ms.
    private static MessageProducer messageProducer = null;

    
     * Establish a connection with the queue
     
    public void createConnection(String clientId, String queueName,
        String boxName) throws JMSException {

        try {

            MQQueueConnectionFactory connfc = new MQQueueConnectionFactory();
            connfc.setHostName(JMSConstants.IMQ_HOST);
            connfc.setPort(JMSConstants.IBMMQ_PORT);
            connfc.setQueueManager(JMSConstants.IMQ_Q_MANAGER);
            connfc.setChannel(clientId);
            connfc.setTransportType(JMSConstants.TRANSPORT_TYPE);
            connection = connfc.createQueueConnection();
            session =
                connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            Queue q = session.createQueue(queueName);
            queueSender = session.createSender(q);

        } catch (JMSException e) {
            e.printStackTrace();
            throw e;
        }
    }

    
     * Establish a connection with the Topic and puclish
     
    public static void createTopicConnectionandPublish(String clientId, String topicName,
        String boxName, String message) throws JMSException {

        try {

            MQTopicConnectionFactory connfc = new MQTopicConnectionFactory();
            connfc.setHostName(JMSConstants.IMQ_HOST);
            connfc.setPort(JMSConstants.IBMMQ_PORT);
            connfc.setQueueManager(JMSConstants.IMQ_Q_MANAGER);
            connfc.setChannel(clientId);
            connfc.setTransportType(JMSConstants.TRANSPORT_TYPE);
            topicConnection = connfc.createConnection();
            topicConnection.start();
            topicSession = topicConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic t = topicSession.createTopic(topicName);
            consumer = topicSession.createConsumer(t);
            messageProducer = topicSession.createProducer(t);
    		TextMessage text = topicSession.createTextMessage(message);
    		messageProducer.send(text);

        } catch (JMSException e) {
            e.printStackTrace();
            throw e;
        }
    }

    
     * Starting the publisher connection
     
    public void startPublisher(String boxname, String QueueName) {

        try {
            createConnection(IBMMQ_QUEUE_CLIENT_ID, QueueName, boxname);
            System.out.println("IBMMQPublisher Started .......");
        } catch (JMSException e) {
            System.out
                .println("Problem starting publisher..." + e.getMessage());
        }

    }

    
     * Closing the connection
     
    public static void closeConnection() throws JMSException {
        connection.close();
        connection = null;
    }

    
     * Starting the publisher topic connection
     
    public static void startTopicPublisher(String boxname, String topicName, String message) {

        try {
            createTopicConnectionandPublish(IBMMQ_QUEUE_CLIENT_ID, topicName, boxname, message);
            System.out.println("Topic publisher Started .......");
        } catch (JMSException e) {
            System.out.println("Problem starting Consumer..." + e.getMessage());
        }

    }

    
     * Closing the TopicConnection
     
    public static void closeTopicConnection() throws JMSException {
        topicSession.close();
        topicConnection.close();
        topicConnection = null;
    }
    
     * Sending a message to the queue
     

    public void publishMessage(String message, String messageType) {

        try {

            System.out.println("Sending message to the Queue");
            sendMessage(message, messageType);
        } catch (JMSException e) {
            System.out.println("Problem sending message" + e.getMessage());
        }
    }

    
     * Converting the message into byte array and write the same
     
    public void sendMessage(String jsonInString, String messageType) throws JMSException {
        try {
        	
        	if (messageType.equalsIgnoreCase(JMSConstants.BYTES_MESSAGE)){
            byte[] bytes = jsonInString.getBytes();
            BytesMessage byteMessage = session.createBytesMessage();
            byteMessage.writeBytes(bytes);
            queueSender.send(byteMessage);
        	}
        	else
        	{
        		TextMessage textMessage = session.createTextMessage(jsonInString);
                queueSender.send(textMessage);
        	}
        } catch (Exception e) {
            e.printStackTrace();
            
        }

    }

    public static String consumeMessage() throws JMSException {

        Message message = consumer.receive(TIMEOUT);
        String msgRecieved = "";
        if (message != null) {
            // cast the message to the correct type
            TextMessage textMessage = (TextMessage) message;
            msgRecieved = textMessage.getText();
            System.out
                .println("message recieved from Topic is : " + msgRecieved);
        } else {
            System.out.println("No message received");
        }
        return msgRecieved;
    }

}
*/