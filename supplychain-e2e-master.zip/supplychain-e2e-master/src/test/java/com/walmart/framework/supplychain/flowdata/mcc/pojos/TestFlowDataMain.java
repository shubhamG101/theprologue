
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "testFlowData" })
public class TestFlowDataMain {

	@JsonProperty("testFlowData")
	private TestFlowData testFlowData = new TestFlowData();

	@JsonProperty("testFlowData")
	public TestFlowData getTestFlowData() {
		return testFlowData;
	}

	@JsonProperty("TestFlowData")
	public void setTestFlowData(TestFlowData testFlowData) {
		this.testFlowData = testFlowData;
	}

}
