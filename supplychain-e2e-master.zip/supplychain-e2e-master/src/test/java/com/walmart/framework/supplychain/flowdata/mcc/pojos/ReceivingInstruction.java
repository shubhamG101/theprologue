package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "parentContainer", "messageId", "childContainers", "receivedQuantity","receivedStatus", "channelType", "destNumber",
		"isPbyl", "isShipOut", "isVTR", "isDamage", "vtrContainer", "orderIds", "vtrQty", "labelType", "tote",
		"adjustmentCode", "salesQty", "adjustedQty,onHoldStatus",  "overrageLPN", "overrageReceiveQty", "reasonForReceivedStatus","putawayFromLocation", "putawayIntermediateLocation", "putawayToLocation"})

public class ReceivingInstruction {

	@JsonProperty("parentContainer")
	private String parentContainer;

	@JsonProperty("onHoldStatus")
	private boolean onHoldStatus;

	@JsonProperty("messageId")
	private String messageId;
	@JsonProperty("childContainers")
	private List<String> childContainers = new ArrayList<String>();
	@JsonProperty("receivedQuantity")
	private String receivedQuantity;
	@JsonProperty("receivedStatus")
	private String receivedStatus;
	@JsonProperty("channelType")
	private String channelType;
	@JsonProperty("destNumber")
	private String destNumber;
	@JsonProperty("isPbyl")
	private boolean isPbyl;
	@JsonProperty("isPbylTripExecuted")
	private boolean isPbylTripExecuted;
	@JsonProperty("isShipOut")
	private boolean isShipOut;
	@JsonProperty("isDamage")
	private boolean isDamage;
	@JsonProperty("isVTR")
	private boolean isVTR;
	@JsonProperty("vtrContainer")
	private String vtrContainer;
	@JsonProperty("damageContainer")
	private String damageContainer;
	@JsonProperty("isGFCS")
	private boolean isGFCS;
	@JsonProperty("containerName")
	private String containerName;
	@JsonProperty("damageOrderIds")
	private List<String> damageOrderIds;
	@JsonProperty("damageQty")
	private int damageQty;
	@JsonProperty("rotateDate")
	private String rotateDate;
	@JsonProperty("salesQty")
	private int salesQty;
	@JsonProperty("tote")
	private String tote;
	@JsonProperty("adjustmentCode")
	private String adjustmentCode;
	@JsonProperty("adjustedQty")
	private int adjustedQty;
	@JsonProperty("vtrContainerOrderIds")
	private List<String> vtrContainerOrderIds = new ArrayList<String>();
	@JsonProperty("vtrQty")
	private int vtrQty;

	@JsonProperty("palletHoldQty")
	private String palletHoldQty;
	@JsonProperty("labelType")
	private String labelType;
	@JsonProperty("reasonForReceivedStatus")
	private String reasonForReceivedStatus;
	
	@JsonProperty("putawayFromLocation")
	private String putawayFromLocation;
	
	@JsonProperty("putawayIntermediateLocation")
	private String putawayIntermediateLocation;
	
	@JsonProperty("putawayToLocation")
	private String putawayToLocation;
	

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("parentContainer")
	public String getParentContainer() {
		return parentContainer;
	}

	@JsonProperty("parentContainer")
	public void setParentContainer(String parentContainer) {
		this.parentContainer = parentContainer;
	}

//	@JsonProperty("onHoldStatus")
//	public boolean getParentContainerStatus() {
//		return onHoldStatus;
//	}
//
//	@JsonProperty("onHoldStatus")
//	public void setParentContainerStatus(boolean onHoldStatus) {
//		this.onHoldStatus = onHoldStatus;
//	}
	
	@JsonProperty("onHoldStatus")
	public boolean getOnHoldStatus() {
		return onHoldStatus;
	}

	@JsonProperty("onHoldStatus")
	public void setOnHoldStatus(boolean onHoldStatus) {
		this.onHoldStatus = onHoldStatus;
	}
	
	@JsonProperty("overrageLPN")
	private String overrageLPN;
	
	@JsonProperty("overrageReceiveQty")
	private String overrageReceiveQty;

	public ReceivingInstruction() {
		this.isGFCS = false;
		this.isShipOut = true;
		this.channelType = "";
	}

	public ReceivingInstruction withParentContainer(String parentContainer) {
		this.parentContainer = parentContainer;
		return this;
	}

	@JsonProperty("messageId")
	public String getMessageId() {
		return messageId;
	}

	@JsonProperty("messageId")
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	@JsonProperty("rotateDate")
	public String getrotateDate() {
		return rotateDate;
	}

	@JsonProperty("rotateDate")
	public void setrotateDate(String rotateDate) {
		this.rotateDate = rotateDate;
	}

	@JsonProperty("isGFCS")
	public boolean getIsGFCS() {
		return isGFCS;
	}

	@JsonProperty("isGFCS")
	public void setIsGFCS(boolean isGFCS) {
		this.isGFCS = isGFCS;
	}

	public ReceivingInstruction withMessageId(String messageId) {
		this.messageId = messageId;
		return this;
	}

	@JsonProperty("childContainers")
	public List<String> getChildContainers() {
		return childContainers;
	}

	@JsonProperty("childContainers")
	public void setChildContainers(List<String> childContainers) {
		this.childContainers = childContainers;
	}

	public ReceivingInstruction withChildContainers(List<String> childContainers) {
		this.childContainers = childContainers;
		return this;
	}

	@JsonProperty("receivedQuantity")
	public String getReceivedQuantity() {
		return receivedQuantity;
	}

	@JsonProperty("receivedQuantity")
	public void setReceivedQuantity(String receivedQuantity) {
		this.receivedQuantity = receivedQuantity;
	}
	
	@JsonProperty("receivedStatus")
	public String getReceivedStatus() {
		return receivedStatus;
	}

	@JsonProperty("receivedStatus")
	public void setReceivedStatus(String receivedStatus) {
		this.receivedStatus = receivedStatus;
	}
	

	@JsonProperty("palletHoldQty")
	public String getpalletHoldQty() {
		return palletHoldQty;
	}

	@JsonProperty("palletHoldQty")
	public void setpalletHoldQty(String palletHoldQty) {
		this.palletHoldQty = palletHoldQty;
	}

	@JsonProperty("labelType")
	public String getLabelType() {
		return labelType;
	}

	@JsonProperty("labelType")
	public void setLabelType(String labelType) {
		this.labelType = labelType;
	}

	@JsonProperty("channelType")
	public String getChannelType() {
		return channelType;
	}

	@JsonProperty("channelType")
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	@JsonProperty("destNumber")
	public String getDestNumber() {
		return destNumber;
	}

	@JsonProperty("destNumber")
	public void setDestNumber(String destNumber) {
		this.destNumber = destNumber;
	}

	@JsonProperty("isPbyl")
	public boolean getIsPbyl() {
		return isPbyl;
	}

	@JsonProperty("isPbyl")
	public void setIsPbyl(boolean isPbyl) {
		this.isPbyl = isPbyl;
	}

	public boolean getIsPbylTripExecuted() {
		return isPbylTripExecuted;
	}

	public void setIsPbylTripExecuted(boolean isPbylTripExecuted) {
		this.isPbylTripExecuted = isPbylTripExecuted;
	}

	public boolean getIsShipOut() {
		return isShipOut;
	}

	public void setIsShipOut(boolean isShipOut) {
		this.isShipOut = isShipOut;
	}

	@JsonProperty("isDamage")
	public boolean getIsDamage() {
		return isDamage;
	}

	@JsonProperty("isDamage")
	public void setIsDamage(boolean isDamage) {
		this.isDamage = isDamage;
	}

	@JsonProperty("isVTR")
	public boolean getIsVTR() {
		return isVTR;
	}

	@JsonProperty("isVTR")
	public void setIsVTR(boolean isVTR) {
		this.isVTR = isVTR;
	}

	@JsonProperty("vtrContainer")
	public String getVtrContainer() {
		return vtrContainer;
	}

	@JsonProperty("vtrContainer")
	public void setVtrContainer(String vtrContainer) {
		this.vtrContainer = vtrContainer;
	}

	@JsonProperty("damageContainer")
	public String getDamageContainer() {
		return damageContainer;
	}

	@JsonProperty("damageContainer")
	public void setDamageContainer(String vtrDamgeContainer) {
		this.damageContainer = vtrDamgeContainer;
	}

	@JsonProperty("tote")
	public String getTote() {
		return tote;
	}

	@JsonProperty("tote")
	public void setTote(String tote) {
		this.tote = tote;
	}

	@JsonProperty("orderIds")
	public List<String> getOrderIds() {
		return vtrContainerOrderIds;
	}

	@JsonProperty("orderIds")
	public void setOrderIds(List<String> orderIds) {
		this.vtrContainerOrderIds = orderIds;
	}

	@JsonProperty("vtrQty")
	public int getvtrQty() {
		return vtrQty;
	}

	@JsonProperty("vtrQty")
	public void setvtrQty(int vtrQty) {
		this.vtrQty = vtrQty;
	}

	@JsonProperty("damageOrderIds")
	public List<String> getDamageOrderIds() {
		return damageOrderIds;
	}

	@JsonProperty("damageOrderIds")
	public void setDamageOrderIds(List<String> orderIds) {
		this.damageOrderIds = orderIds;
	}

	@JsonProperty("damageQty")
	public int getDamageQty() {
		return damageQty;
	}

	@JsonProperty("damageQty")
	public void setDamageQty(int vtrQty) {
		this.damageQty = vtrQty;
	}

	@JsonProperty("adjustmentCode")
	public String getAdjustmentCode() {
		return adjustmentCode;
	}

	@JsonProperty("adjustmentCode")
	public void setAdjustmentCode(String adjustmentCode) {
		this.adjustmentCode = adjustmentCode;
	}

	@JsonProperty("salesQty")
	public int getSalesQty() {
		return salesQty;
	}

	@JsonProperty("salesQty")
	public void setSalesQty(int salesQty) {
		this.salesQty = salesQty;
	}

	@JsonProperty("adjustedQty")
	public int getAdjustedQty() {
		return adjustedQty;
	}

	@JsonProperty("adjustedQty")
	public void setAdjustedQty(int adjustedQty) {
		this.adjustedQty = adjustedQty;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}
	
	public String getOverrageLPN() {
		return overrageLPN;
	}

	public void setOverrageLPN(String overrageLPN) {
		this.overrageLPN = overrageLPN;
	}

	public String getOverrageReceiveQty() {
		return overrageReceiveQty;
	}

	public void setOverrageReceiveQty(String overrageReceiveQty) {
		this.overrageReceiveQty = overrageReceiveQty;
	}
	

	public ReceivingInstruction withReceivedQuantity(String receivedQuantity) {
		this.receivedQuantity = receivedQuantity;
		return this;
	}

	// @JsonAnyGetter
	// public Map<String, Object> getAdditionalProperties() {
	// return this.additionalProperties;
	// }
	//
	// @JsonAnySetter
	// public void setAdditionalProperty(String name, Object value) {
	// this.additionalProperties.put(name, value);
	// }

	public ReceivingInstruction withAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
		return this;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("parentContainer", parentContainer).append("messageId", messageId)
				.append("childContainers", childContainers).append("receivedQuantity", receivedQuantity)
				.append("additionalProperties", additionalProperties).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(parentContainer).append(messageId).append(additionalProperties)
				.append(childContainers).append(receivedQuantity).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof ReceivingInstruction) == false) {
			return false;
		}
		ReceivingInstruction rhs = ((ReceivingInstruction) other);
		return new EqualsBuilder().append(parentContainer, rhs.parentContainer).append(messageId, rhs.messageId)
				.append(additionalProperties, rhs.additionalProperties).append(childContainers, rhs.childContainers)
				.append(receivedQuantity, rhs.receivedQuantity).isEquals();
	}
	
	public String getReasonForReceivedStatus() {
		return reasonForReceivedStatus;
	}

	public void setReasonForReceivedStatus(String reasonForReceivedStatus) {
		this.reasonForReceivedStatus = reasonForReceivedStatus;
	}
	
	public String getPutawayFromLocation() {
		return putawayFromLocation;
	}

	public void setPutawayFromLocation(String putawayFromLocation) {
		this.putawayFromLocation = putawayFromLocation;
	}
	
	public String getPutawayIntermediateLocation() {
		return putawayIntermediateLocation;
	}

	public void setPutawayIntermediateLocation(String putawayIntermediateLocation) {
		this.putawayIntermediateLocation = putawayIntermediateLocation;
	}
	
	public String getPutawayToLocation() {
		return putawayToLocation;
	}

	public void setPutawayToLocation(String putawayToLocation) {
		this.putawayToLocation = putawayToLocation;
	}
	
}
