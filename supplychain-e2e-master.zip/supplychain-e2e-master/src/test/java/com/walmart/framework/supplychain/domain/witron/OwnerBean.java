package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "baseDivisionCode", "financialReportingGroupCode" })
public class OwnerBean {
	@JsonProperty("baseDivisionCode")
	private String baseDivisionCode;
	@JsonProperty("financialReportingGroupCode")
	private String financialReportingGroupCode;

	public String getBaseDivisionCode() {
		return baseDivisionCode;
	}

	public void setBaseDivisionCode(String baseDivisionCode) {
		this.baseDivisionCode = baseDivisionCode;
	}

	public String getFinancialReportingGroupCode() {
		return financialReportingGroupCode;
	}

	public void setFinancialReportingGroupCode(String financialReportingGroupCode) {
		this.financialReportingGroupCode = financialReportingGroupCode;
	}
}
