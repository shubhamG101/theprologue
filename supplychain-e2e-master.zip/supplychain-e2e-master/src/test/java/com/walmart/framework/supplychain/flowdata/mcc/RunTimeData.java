/*package com.walmart.framework.supplychain.flowdata.mcc;


import com.walmart.framework.supplychain.domain.receiving.Instruction;

import java.util.HashSet;
import java.util.List;

public class RunTimeData {

	private static int itemNum;
	private static long poNum;
	private static int poQty;
	private static int destNum;
    private static int vnpk;
    private static int whpk;
	private static String deliveryNum;
	private static String channelMethod;
	private static String inboundTrailer;
	private static int receivedQty;
	private static int loadId;
	private static int tmsLoadId;
	private static HashSet<String> otns;
	private static String inboundDoor;
	private static String outboundDoor;
	private static List<String> containerLPN;
	private static String outBoundTrailer;
	private static String sealNo;
	private static List<Instruction> receivingInstructionList;
	private static String itemUPC;
	private static double dcFinPurchaseValue;
	private static List<String> orderIDs;

	public static String getItemUPC() {
		return itemUPC;
	}

	public static void setItemUPC(String itemUPC) {
		RunTimeData.itemUPC = itemUPC;
	}

	public static List<Instruction> getReceivingInstructionList() {
		return receivingInstructionList;
	}

	public static void setReceivingInstructionList(List<Instruction> receivingInstructionList) {
		RunTimeData.receivingInstructionList = receivingInstructionList;
	}


	public static String getSealNo() {
		return sealNo;
	}

	public static void setSealNo(String sealNo) {
		RunTimeData.sealNo = sealNo;
	}

	public static String getOutBoundTrailer() {
		return outBoundTrailer;
	}

	public static void setOutBoundTrailer(String outBoundTrailer) {
		RunTimeData.outBoundTrailer = outBoundTrailer;
	}

	public static int getItemNum() {
		return itemNum;
	}

	public static void setItemNum(int itemNum) {
		RunTimeData.itemNum = itemNum;
	}

	public static long getPoNum() {

		return poNum;

	}

	public static void setPoNum(long poNum) {
		RunTimeData.poNum = poNum;
	}

	public static int getPoQty() {
		return poQty;
	}

	public static void setPoQty(int poQty) {
		RunTimeData.poQty = poQty;
	}

	public static int getDestNum() {
		return destNum;
	}

	public static void setDestNum(int destNum) {
		RunTimeData.destNum = destNum;
	}

	public static String getDeliveryNum() {
		return deliveryNum;
	}

	public static void setDeliveryNum(String deliveryNum) {
		RunTimeData.deliveryNum = deliveryNum;
	}

	public static String getInboundTrailer() {
		return inboundTrailer;
	}

	public static void setInboundTrailer(String trailer) {
		RunTimeData.inboundTrailer = trailer;
	}

	public static HashSet<String> getOtns() {
		return otns;
	}

	public static void setOtns(HashSet<String> otns) {
		RunTimeData.otns = otns;
	}

    public static String getChannelMethod() {
        return channelMethod;
    }

    public static void setChannelMethod(String channelMethod) {
        RunTimeData.channelMethod = channelMethod;
    }

    public static int getVnpk() {
        return vnpk;
    }

    public static void setVnpk(int vnpk) {
        RunTimeData.vnpk = vnpk;
    }
    public static String getInboundDoor() {
		return inboundDoor;
	}

	public static void setInboundDoor(String door) {
		RunTimeData.inboundDoor = door;
	}


	public static String getOutboundDoor() {
		return outboundDoor;
	}

	public static void setOutboundDoor(String outboundDoor) {
		RunTimeData.outboundDoor = outboundDoor;
	}


	public static List<String> getContainerLPN() {
		return containerLPN;
	}

	public static void setContainerLPN(List<String> containerLPN) {
		RunTimeData.containerLPN = containerLPN;
	}

	public static int getReceivedQty() {

		return receivedQty;
	}


	public static void setReceivedQty(int receivedQty) {
		RunTimeData.receivedQty = receivedQty;
	}

	public static int getLoadId() {
		return loadId;
	}

	public static void setLoadId(int loadId) {
		RunTimeData.loadId = loadId;
	}

	public static int getTmsLoadId() {
		return tmsLoadId;
	}

	public static void setTmsLoadId(int tmsLoadId) {
		RunTimeData.tmsLoadId = tmsLoadId;
	}

	public static double getDcFinPurchaseValue() {
		return dcFinPurchaseValue;
	}

	public static void setDcFinPurchaseValue(double dcFinPurchaseValue) {
		RunTimeData.dcFinPurchaseValue = dcFinPurchaseValue;
	}

	public static int getWhpk() {
		return whpk;
	}

	public static void setWhpk(int whpk) {
		RunTimeData.whpk = whpk;
	}


	public static List<String> getOrderIDs() {
		return orderIDs;
	}

	public static void setOrderIDs(List<String> orderIDs) {
		RunTimeData.orderIDs = orderIDs;
	}


}
*/