package com.walmart.framework.supplychain.domain.yms;

public class Yms {
	private int assignAndForceMoveCount;

	public int getAssignAndForceMoveCount() {
		return assignAndForceMoveCount;
	}

	public void setAssignAndForceMoveCount(int assignAndForceMoveCount) {
		this.assignAndForceMoveCount = assignAndForceMoveCount;
	}
}
