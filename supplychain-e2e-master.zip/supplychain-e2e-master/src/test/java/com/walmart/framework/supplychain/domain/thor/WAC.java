package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "baseDivCode", "financialReportingGroupCode", "itemNumber"})
public class WAC {
	
	@JsonProperty("baseDivCode")
	private String baseDivCode;
	@JsonProperty("financialReportingGroupCode")
	private String financialReportingGroupCode;
	@JsonProperty("itemNumber")
	private String itemNumber;
	
	@JsonProperty("baseDivCode")
	public String getBaseDivCode() {
		return baseDivCode;
	}
	@JsonProperty("baseDivCode")
	public void setBaseDivCode(String baseDivCode) {
		this.baseDivCode = baseDivCode;
	}
	@JsonProperty("financialReportingGroupCode")
	public String getFinancialReportingGroupCode() {
		return financialReportingGroupCode;
	}
	@JsonProperty("financialReportingGroupCode")
	public void setFinancialReportingGroupCode(String financialReportingGroupCode) {
		this.financialReportingGroupCode = financialReportingGroupCode;
	}
	@JsonProperty("itemNumber")
	public String getItemNumber() {
		return itemNumber;
	}
	@JsonProperty("itemNumber")
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	
	
}
