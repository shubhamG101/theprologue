package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "loadUnitId",
    "isUsed",
    "itemNumber"
    })
public class ContainerDetails {

    @JsonProperty("loadUnitId")
    private String loadUnitId;
    @JsonProperty("isUsed")
    private String isUsed;
    @JsonProperty("itemNumber")
    private String itemNumber;
   
    @JsonProperty("loadUnitId")
    public String getLoadUnitId() {
        return loadUnitId;
    }

    @JsonProperty("loadUnitId")
    public void setLoadUnitId(String loadUnitId) {
        this.loadUnitId = loadUnitId;
    }

    @JsonProperty("isUsed")
    public String getIsUsed() {
        return isUsed;
    }

    @JsonProperty("isUsed")
    public void setIsUsed(String isUsed) {
        this.isUsed = isUsed;
    }
 
   @JsonProperty("itemNumber")
    public String getItemNumber() {
        return itemNumber;
    }

    @JsonProperty("itemNumber")
    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }
}
