package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Owner", "SSCC", "TUType", "SSCCParent", "LogicalPalletReferenceNr", "GrossWeight", "Cube",
		"RouteIdent", "DispatchDate", "CustIdent", "DispatchDateTime", "MessageType", "Location", "DispatchZone",
		"DTL" })
public class DTH {
	@JsonProperty("Owner")
	private OwnerBean Owner;
	@JsonProperty("SSCC")
	private String SSCC;
	@JsonProperty("TUType")
	private String TUType;
	@JsonProperty("SSCCParent")
	private String SSCCParent;
	@JsonProperty("LogicalPalletReferenceNr")
	private String LogicalPalletReferenceNr;
	@JsonProperty("GrossWeight")
	private GrossWeightBean GrossWeight;
	@JsonProperty("Cube")
	private CubeBean Cube;
	@JsonProperty("RouteIdent")
	private String RouteIdent;
	@JsonProperty("DispatchDate")
	private String DispatchDate;
	@JsonProperty("CustIdent")
	private String CustIdent;
	@JsonProperty("DispatchDateTime")
	private String DispatchDateTime;
	@JsonProperty("MessageType")
	private int MessageType;
	@JsonProperty("Location")
	private String Location;
	@JsonProperty("DispatchZone")
	private String DispatchZone;
	@JsonProperty("DTL")
	private List<DTL> DTL;

	@JsonProperty("Owner")
	public OwnerBean getOwner() {
		return Owner;
	}

	@JsonProperty("Owner")
	public void setOwner(OwnerBean owner) {
		Owner = owner;
	}
	@JsonProperty("SSCC")
	public String getSSCC() {
		return SSCC;
	}
	@JsonProperty("SSCC")
	public void setSSCC(String sSCC) {
		SSCC = sSCC;
	}
	@JsonProperty("TUType")
	public String getTUType() {
		return TUType;
	}
	@JsonProperty("TUType")
	public void setTUType(String tUType) {
		TUType = tUType;
	}
	@JsonProperty("SSCCParent")
	public String getSSCCParent() {
		return SSCCParent;
	}
	@JsonProperty("SSCCParent")
	public void setSSCCParent(String sSCCParent) {
		SSCCParent = sSCCParent;
	}
	@JsonProperty("LogicalPalletReferenceNr")
	public String getLogicalPalletReferenceNr() {
		return LogicalPalletReferenceNr;
	}
	@JsonProperty("LogicalPalletReferenceNr")
	public void setLogicalPalletReferenceNr(String logicalPalletReferenceNr) {
		LogicalPalletReferenceNr = logicalPalletReferenceNr;
	}
	@JsonProperty("GrossWeight")
	public GrossWeightBean getGrossWeight() {
		return GrossWeight;
	}
	@JsonProperty("GrossWeight")
	public void setGrossWeight(GrossWeightBean grossWeight) {
		GrossWeight = grossWeight;
	}
	@JsonProperty("Cube")
	public CubeBean getCube() {
		return Cube;
	}
	@JsonProperty("Cube")
	public void setCube(CubeBean cube) {
		Cube = cube;
	}
	@JsonProperty("RouteIdent")
	public String getRouteIdent() {
		return RouteIdent;
	}
	@JsonProperty("RouteIdent")
	public void setRouteIdent(String routeIdent) {
		RouteIdent = routeIdent;
	}
	@JsonProperty("DispatchDate")
	public String getDispatchDate() {
		return DispatchDate;
	}
	@JsonProperty("DispatchDate")
	public void setDispatchDate(String dispatchDate) {
		DispatchDate = dispatchDate;
	}
	@JsonProperty("CustIdent")
	public String getCustIdent() {
		return CustIdent;
	}
	@JsonProperty("CustIdent")
	public void setCustIdent(String custIdent) {
		CustIdent = custIdent;
	}
	@JsonProperty("DispatchDateTime")
	public String getDispatchDateTime() {
		return DispatchDateTime;
	}
	@JsonProperty("DispatchDateTime")
	public void setDispatchDateTime(String dispatchDateTime) {
		DispatchDateTime = dispatchDateTime;
	}
	@JsonProperty("MessageType")
	public int getMessageType() {
		return MessageType;
	}
	@JsonProperty("MessageType")
	public void setMessageType(int messageType) {
		MessageType = messageType;
	}
	@JsonProperty("Location")
	public String getLocation() {
		return Location;
	}
	@JsonProperty("Location")
	public void setLocation(String location) {
		Location = location;
	}
	@JsonProperty("DispatchZone")
	public String getDispatchZone() {
		return DispatchZone;
	}
	@JsonProperty("DispatchZone")
	public void setDispatchZone(String dispatchZone) {
		DispatchZone = dispatchZone;
	}
	@JsonProperty("DTL")
	public List<DTL> getDTL() {
		return DTL;
	}
	@JsonProperty("DTL")
	public void setDTL(List<DTL> dTL) {
		DTL = dTL;
	}
}
