
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "poDetails",
    "ordersDetails",
    "deliveryDetails",
    "deliveryDetailsRDC",
    "outboundDetails",
    "problemDetails",
    "containerDetails",
    "releaseDetails"
})
public class TestFlowData {

    @JsonProperty("poDetails")
    private List<PoDetail> poDetails = new ArrayList<PoDetail>();
    @JsonProperty("ordersDetails")
    private List<OrdersDetail> ordersDetails = new ArrayList<OrdersDetail>();
    @JsonProperty("deliveryDetails")
    private List<DeliveryDetail> deliveryDetails = new ArrayList<DeliveryDetail>();
    @JsonProperty("deliveryDetailsRDC")
    private List<DeliveryDetailsRDC> deliveryDetailsRDC = new ArrayList<DeliveryDetailsRDC>();
	@JsonProperty("outboundDetails")
    private List<OutboundDetail> outboundDetails = new ArrayList<OutboundDetail>();
    @JsonProperty("problemDetails")
    private List<ProblemDetail> problemDetails = new ArrayList<ProblemDetail>();
	@JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	@JsonProperty("containerDetails")
	private List<ContainerDetails> containerDetails = new ArrayList<ContainerDetails>();
	@JsonProperty("releaseDetails")
	private List<ReleaseDetails> releaseDetails = new ArrayList<ReleaseDetails>();
	
	@JsonProperty("releaseDetails")
    public List<ReleaseDetails> getReleaseDetails() {
        return releaseDetails;
    }

    @JsonProperty("releaseDetails")
    public void setReleaseDetails(List<ReleaseDetails> releaseDetails) {
        this.releaseDetails = releaseDetails;
    }

    public TestFlowData withReleaseDetails(List<ReleaseDetails> releaseDetails) {
        this.releaseDetails = releaseDetails;
        return this;
    }
    
    @JsonProperty("containerDetails")
    public List<ContainerDetails> getcontainerDetails() {
        return containerDetails;
    }

    @JsonProperty("containerDetails")
    public void setcontainerDetails(List<ContainerDetails> containerDetails) {
        this.containerDetails = containerDetails;
    }

    public TestFlowData withcontainerDetails(List<ContainerDetails> containerDetails) {
        this.containerDetails = containerDetails;
        return this;
    }
    
    @JsonProperty("poDetails")
    public List<PoDetail> getPoDetails() {
        return poDetails;
    }

    @JsonProperty("poDetails")
    public void setPoDetails(List<PoDetail> poDetails) {
        this.poDetails = poDetails;
    }

    public TestFlowData withPoDetails(List<PoDetail> poDetails) {
        this.poDetails = poDetails;
        return this;
    }

    @JsonProperty("ordersDetails")
    public List<OrdersDetail> getOrdersDetails() {
        return ordersDetails;
    }

    @JsonProperty("ordersDetails")
    public void setOrdersDetails(List<OrdersDetail> ordersDetails) {
        this.ordersDetails = ordersDetails;
    }

    public TestFlowData withOrdersDetails(List<OrdersDetail> ordersDetails) {
        this.ordersDetails = ordersDetails;
        return this;
    }

    @JsonProperty("deliveryDetails")
    public List<DeliveryDetail> getDeliveryDetails() {
        return deliveryDetails;
    }

    @JsonProperty("deliveryDetails")
    public void setDeliveryDetails(List<DeliveryDetail> deliveryDetails) {
        this.deliveryDetails = deliveryDetails;
    }

    public TestFlowData withDeliveryDetails(List<DeliveryDetail> deliveryDetails) {
        this.deliveryDetails = deliveryDetails;
        return this;
    }
    
    public List<DeliveryDetailsRDC> getDeliveryDetailsRDC() {
		return deliveryDetailsRDC;
	}

	public void setDeliveryDetailsRDC(List<DeliveryDetailsRDC> deliveryDetailsRDC) {
		this.deliveryDetailsRDC = deliveryDetailsRDC;
	}

    @JsonProperty("outboundDetails")
    public List<OutboundDetail> getOutboundDetails() {
        return outboundDetails;
    }

    @JsonProperty("outboundDetails")
    public void setOutboundDetails(List<OutboundDetail> outboundDetails) {
        this.outboundDetails = outboundDetails;
    }

    public TestFlowData withOutboundDetails(List<OutboundDetail> outboundDetails) {
        this.outboundDetails = outboundDetails;
        return this;
    }
    
    @JsonProperty("problemDetails")
    public List<ProblemDetail> getProblemDetails() {
		return problemDetails;
	}

    @JsonProperty("problemDetails")
	public void setProblemDetails(List<ProblemDetail> problemDetails) {
		this.problemDetails = problemDetails;
	}

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TestFlowData withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("poDetails", poDetails).append("ordersDetails", ordersDetails).append("deliveryDetails", deliveryDetails).append("outboundDetails", outboundDetails).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(ordersDetails).append(deliveryDetails).append(outboundDetails).append(additionalProperties).append(poDetails).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TestFlowData) == false) {
            return false;
        }
        TestFlowData rhs = ((TestFlowData) other);
        return new EqualsBuilder().append(ordersDetails, rhs.ordersDetails).append(deliveryDetails, rhs.deliveryDetails).append(outboundDetails, rhs.outboundDetails).append(additionalProperties, rhs.additionalProperties).append(poDetails, rhs.poDetails).isEquals();
    }

}
