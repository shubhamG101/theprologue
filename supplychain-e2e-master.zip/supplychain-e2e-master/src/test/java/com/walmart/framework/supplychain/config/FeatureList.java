package com.walmart.framework.supplychain.config;

import java.util.Arrays;
import java.util.List;

import com.walmart.framework.supplychain.constants.FileNames;
import com.walmart.framework.utilities.jms.DC_TYPE;

public class FeatureList {/*
	FeatureList() {

	}

	private static final List<String> ATLAS_FEATURES = Arrays.asList(
			FileNames.ATLAS_HAZMAT_ITEM,
			FileNames.ATLAS_MULTI_PO,
			FileNames.ATLAS_DA_NON_CON_MANUAL,
			FileNames.ATLAS_DA_CON_MANUAL,
			//FileNames.ATLAS_PBYL,
			FileNames.ATLAS_RECEIVE_FULL,
			FileNames.ATLAS_VTR_DA,
			FileNames.ATLAS_VTR_SSTK,
			FileNames.ATLAS_RECEIVE_PARTIAL,
			FileNames.ATLAS_DAMAGE_SSTK,
			FileNames.ATLAS_DAMAGE_DA,
			// FileNames.ATLAS_PROBLEM, //Commented until env issue is resolved

			FileNames.ATLAS_PO_LINE_ADD_UPDATE,
			FileNames.ATLAS_POCON,
			// 			FileNames.ATLAS_DSDC,
			FileNames.ATLAS_CANCEL_DELIVERY,
			FileNames.ATLAS_ORDER_RERESH,
			FileNames.ATLAS_MANUAL_PO_ORDER_REOPEN,
			FileNames.FIXIT_PROBLEM_NOTWALMARTFREIGHT, // , //NOTWALMARTFREIGHT - denote- crossmu
			FileNames.FIXIT_PROBLEM_WRONGDC, // WRONGDC- transfer another dc- crossmu
			FileNames.FIXIT_PROBLEM_WRONGPACK, // WRONGPACK - Added a PO Line
			FileNames.FIXIT_PROBLEM_DC, // hazmat-Destroy
			FileNames.FIXIT_PROBLEM_DCHO, // NOP -receive against another po
			FileNames.FIXIT_PROBLEM_ASSIGNED_HO,
			FileNames.FIXIT_PROBLEM_NOP_NOTINITEM,
			FileNames.FIXIT_PROBLEM_WRONGDC_NOTINITEM,
			FileNames.FIXIT_PROBLEM_MOBILE_CANCEL,
			FileNames.FIXIT_PROBLEM_WEB_CANCEL,

			FileNames.FIXIT_DCTC_NOP,
			FileNames.FIXIT_DCTC_WRONGDC,
			FileNames.FIXIT_DCTC_WRONGPACK,
			FileNames.FIXIT_DCTC_HAZMAT,
			FileNames.FIXIT_DCTC_NOTWALMARTFREIGHT,
			FileNames.FIXIT_DCTC_OVERRAGE,
			FileNames.FIXIT_DCTC_NOPNOTINITEM,
			FileNames.FIXIT_DCTC_WRONGDCNOTINITEM,
			FileNames.FIXIT_RDC_PROBLEMS

			);
	private static final List<String> ACC_FEATURES = Arrays.asList(
			FileNames.ACC_CHANNEL_FLIP, 
			FileNames.ACC_MULTIPO,
			FileNames.ACC_MANUAL_RECEIVING, 
			FileNames.ACC_SSTK_OFFLINE_ONLINE_DOOR_FILE,
			FileNames.ACC_MANUALPO_BASE_FILE, 
			FileNames.ACC_DOCK_TAG, 
			//FileNames.ACC_PROBLEM_NA_APP,
			FileNames.ACC_PRERECEIVING_DAMAGE_LOADING, 
			//FileNames.ACC_PROBLEM_OV_APP, 
			FileNames.ACC_DA_NONCON_ONLINE,
			FileNames.ACC_BUMER_EXCEPTION_LPN, 
			FileNames.ACC_CLOSE_LOAD_WITHOUT_STOP_DIVERSION,
			FileNames.ACC_POUPDATE_DELETE_LOAD, 
			FileNames.ACC_BASE_POCON,
			FileNames.ACC_MCB_COMBINED_FLOW,
			FileNames.ACC_MCB_REGULAR_FLOW
			// FileNames.ACC_DELIVERY_FINALIZATION_FILE
			);
	private static final List<String> MCC_FEATURES = Arrays.asList(FileNames.DA_CON_PBYL
			//		FileNames.DA_CON,
			//		FileNames.DA_NON_CON,
			//		FileNames.SSTK,
			//		FileNames.VTR,
			//		FileNames.DAMAGE,
			//		FileNames.DA_CON_MANUAL,
			//		FileNames.DA_NON_CON_MANUAL,
			//		FileNames.RECEIVE_FULL,
			//		FileNames.RECEIVE_PARTIAL
			//		FileNames.DA_CON_PBYL
			);
	private static final List<String> THOR_FEATURES = Arrays.asList(

			FileNames.THOR_BASE_FILE, FileNames.THOR_PO_QTY_UPDATE, FileNames.THOR_PO_QTY_UPDATE_DELIVERED,
			FileNames.THOR_PO_LINE_CANCEL, FileNames.THOR_PO_LINE_CANCEL_DELIVERED, FileNames.THOR_PO_LINE_ADD,
			FileNames.THOR_PO_LINE_ADD_DELIVERED,
			//		FileNames.THOR_WAREHOUSE_DAMAGE,
			FileNames.THOR_SALES, FileNames.THOR_WAC_INCREASE, FileNames.THOR_WAC_DECREASE, FileNames.THOR_WAC_NOCHANGE,
			FileNames.THOR_CYCLE_COUNT_DECREASE, FileNames.THOR_CYCLE_COUNT_INCREASE);

	private static final List<String> GDC_FEATURES = ExcelHandler.

			//getFeatureList("./src/test/resources/FeatureRunner.xlsx", "SELECT * FROM Fixit WHERE Run='Yes'");
			// Arrays.asList(FileNames.GDC_WEB_OVG,FileNames.GDC_WEB_CANCEL,

			getFeatureList("./src/test/resources/FeatureRunner.xlsx", "SELECT * FROM Gdc WHERE Run='Yes'");
	/* Arrays.asList(FileNames.GDC_WEB_OVG,FileNames.GDC_WEB_CANCEL,

			FileNames.GDC_WEB_OVERAGE,FileNames.GDC_WEB_ASSIGNHO,
			FileNames.GDC_WEB_NWF,FileNames.GDC_WEB_NOP,
			FileNames.GDC_WEB_DATEISSUE,

		//	FileNames.GDC_FIXIT_MOBILE_CANCEL,
			FileNames.GDC_FIXIT_MOBILE_NWF,

			FileNames.RDC_FIXIT_WEB_ASSIGNEDTOHO,
			FileNames.RDC_FIXIT_WEB_CANCEL,
			FileNames.RDC_FIXIT_WEB_OVERAGE,

			FileNames.RDC_FIXIT_MOBILE_NWF,
			FileNames.RDC_FIXIT_MOBILE_OVG,
			FileNames.RDC_FIXIT_MOBILE_WRONGDC);

	private static final List<String> BAJA_FEATURES = Arrays.asList(
			// FileNames.BAJA_BULKPICK,
			FileNames.BAJA_BULKPICK_INVALID_QUANTITY
			// FileNames.BAJA_BULKPICK_INVALID_STORE
			);

	private static final List<String> WITRON_FEATURES = Arrays.asList(



			FileNames.WITRON_PALLET_HOLD,
			FileNames.WITRON_INBOUND_OUTBOUND_BASE,
			FileNames.WITRON_SQC,
			FileNames.WITRON_SSC,
			FileNames.WITRON_OSDR,
			FileNames.WITRON_MDM,
			FileNames.WITRON_BATCH_PLANNER,
			FileNames.WITRON_VTR,
			FileNames.WITRON_SPLIT_PALLET,
			FileNames.WITRON_PALLET_CORRECTION,
			FileNames.WITRON_STO_OSDR,
			FileNames.WITRON_DISTRO_TURN_ADJ,
			FileNames.WITRON_WAVE_REVERSAL,
			FileNames.WITRON_RECEIVING_EXCEPTION,
			FileNames.WITRON_INVOICE,
			FileNames.WITRON_MODIFY_CANCEL_WAVE,
			FileNames.WITRON_MODIFY_ITEM_ATTRIBUTE,
			FileNames.WITRON_OUTS
			//			FileNames.WITRON_ORDERS_CREATE




			);
	private static final List<String> SAMS_FEATURES = Arrays.asList(

			FileNames.SAMS_BASE_FEATURE
			// FileNames.SAMS_DAMAGE
			// FileNames.SAMS_FIXIT_PROBLEM

			);

	private static final List<String> PHARMACY_FEATURES = Arrays.asList(
			FileNames.PHARMACY_CASE_RECEIVING,
			FileNames.PHARMACY_PALLET_RECEIVING,
			FileNames.PHARMACY_PARTIAL_CASE_RECEIVING,
			FileNames.PHARMACY_D40_PARTIAL_PALLET_RECEIVING,
			FileNames.PHARMACY_D40_FULL_PALLET_RECEIVING,
			FileNames.PHARMACY_LABEL_CANCEL
			);

	public static List<String> getFeatureList() {
		if (Config.DC == DC_TYPE.ATLAS)
			return ATLAS_FEATURES;
		else if (Config.DC == DC_TYPE.ACC)
			return ACC_FEATURES;
		else if (Config.DC == DC_TYPE.THOR)
			return THOR_FEATURES;
		else if (Config.DC == DC_TYPE.BAJA)
			return BAJA_FEATURES;
		else if (Config.DC == DC_TYPE.WITRON)
			return WITRON_FEATURES;
		else if (Config.DC == DC_TYPE.SAMS)
			return SAMS_FEATURES;
		else if (Config.DC == DC_TYPE.PHARMACY)
			return PHARMACY_FEATURES;

		else
			return MCC_FEATURES;
	}
*/}
