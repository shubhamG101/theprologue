package com.walmart.framework.supplychain.domain.op;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cycleNbr",
"waveNbr",
})
public class CycleWavelist {
	
	 
		@JsonProperty("waveNbr")
		private String waveNbr = null;


		@JsonProperty("waveNbr")
		public String  getwaveNbr() {
		return this.waveNbr;
		}

		@JsonProperty("waveNbr")
		public void setwaveNbr(String  waveNbr) {
		this.waveNbr=waveNbr;
		}
		
		@JsonProperty("cycleNbr")
		private String cycleNbr = null;


		@JsonProperty("cycleNbr")
		public String  getcycleNbr() {
		return this.cycleNbr;
		}

		@JsonProperty("cycleNbr")
		public void setcycleNbr(String  cycleNbr) {
		this.cycleNbr=cycleNbr;
		}
		

}
