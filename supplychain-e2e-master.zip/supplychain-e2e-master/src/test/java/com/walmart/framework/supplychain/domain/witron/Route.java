package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "routeNbr", "destinations", "containers", "door","fulfillments", "loadId", "transportationLoadId", "trailerNbr", "invoice" })
public class Route {
	@JsonProperty("routeNbr")
	private String routeNbr;
	@JsonProperty("destinations")
	private List<String> destinations;
	@JsonProperty("containers")
	private List<String> containers;
	@JsonProperty("door")
	private String door;
	@JsonProperty("loadId")
	private String loadId;
	@JsonProperty("trailerNbr")
	private String trailerNbr;
	@JsonProperty("transportationLoadId")
	private String transportationLoadId;
	@JsonProperty("fulfillments")
	private List<Fulfillment> fulfillments;
	@JsonProperty("invoice")
	private List<Invoice> invoice;
	
	public String getRouteNbr() {
		return routeNbr;
	}
	public void setRouteNbr(String routeNbr) {
		this.routeNbr = routeNbr;
	}
	public List<String> getDestinations() {
		return destinations;
	}
	public void setDestinations(List<String> destinations) {
		this.destinations = destinations;
	}
	public List<String> getContainers() {
		return containers;
	}
	public void setContainers(List<String> containers) {
		this.containers = containers;
	}
	public String getDoor() {
		return door;
	}
	public void setDoor(String door) {
		this.door = door;
	}
	public List<Fulfillment> getFulfillments() {
		return fulfillments;
	}
	public void setFulfillments(List<Fulfillment> fulfillments) {
		this.fulfillments = fulfillments;
	}
	public String getLoadId() {
		return loadId;
	}
	public void setLoadId(String loadId) {
		this.loadId = loadId;
	}
	public String getTransportationLoadId() {
		return transportationLoadId;
	}
	public void setTransportationLoadId(String transportationLoadId) {
		this.transportationLoadId = transportationLoadId;
	}
	@JsonProperty("trailerNbr")
	public String getTrailerNbr() {
		return trailerNbr;
	}
	@JsonProperty("trailerNbr")
	public void setTrailerNbr(String trailerNbr) {
		this.trailerNbr = trailerNbr;
	}
	@JsonProperty("invoice")
	public List<Invoice> getInvoice() {
		return invoice;
	}
	@JsonProperty("invoice")
	public void setInvoice(List<Invoice> invoice) {
		this.invoice = invoice;
	}
}
