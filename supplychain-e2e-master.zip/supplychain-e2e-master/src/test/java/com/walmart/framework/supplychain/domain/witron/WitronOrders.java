package com.walmart.framework.supplychain.domain.witron;

import java.util.UUID;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sourceNumber", "orderDate", "wmtItemNumber", "destinationNumber", "orderTrackingNumber",
		"departmentNumber", "destCountryCode", "messageType", "orderRecordType", "packType", "poLineNumber", "poNumber",
		"poType", "priorityNbr", "quantity", "sourceCountryCode", "vnpkQuantity", "whpkQuantity", "status",
		"quantityUOM", "substitutable", "orderType", "whseAreaCode", "upcNumber", "baseDivNumber", "needType",
		"priorityNbrLong", "priorityReason", "processName", "reason", "releaseDate", "fulfilledQuantity",
		"vendorNumber9", "externalPONumber" })
public class WitronOrders {
	
	@JsonProperty("sourceNumber")
	private int sourceNumber;
	@JsonProperty("orderDate")
	private String orderDate;
	@JsonProperty("wmtItemNumber")
	private int wmtItemNumber;
	@JsonProperty("destinationNumber")
	private int destinationNumber;
	@JsonProperty("orderTrackingNumber")
	private String orderTrackingNumber;
	@JsonProperty("departmentNumber")
	private int departmentNumber;
	@JsonProperty("destCountryCode")
	private String destCountryCode;
	@JsonProperty("messageType")
	private String messageType;
	@JsonProperty("orderRecordType")
	private String orderRecordType;
	@JsonProperty("packType")
	private String packType;
	@JsonProperty("poLineNumber")
	private int poLineNumber;
	@JsonProperty("poNumber")
	private String poNumber;
	@JsonProperty("poType")
	private int poType;
	@JsonProperty("priorityNbr")
	private int priorityNbr;
	@JsonProperty("quantity")
	private int quantity;
	@JsonProperty("sourceCountryCode")
	private String sourceCountryCode;
	@JsonProperty("vnpkQuantity")
	private int vnpkQuantity;
	@JsonProperty("whpkQuantity")
	private int whpkQuantity;
	@JsonProperty("status")
	private String status;
	@JsonProperty("quantityUOM")
	private String quantityUOM;
	@JsonProperty("substitutable")
	private boolean substitutable;
	@JsonProperty("orderType")
	private String orderType;
	@JsonProperty("whseAreaCode")
	private String whseAreaCode;
	@JsonProperty("upcNumber")
	private String upcNumber;
	@JsonProperty("processName")
	private String processName;
	@JsonProperty("reason")
	private String reason;
	@JsonProperty("releaseDate")
	private String releaseDate;
	@JsonProperty("fulfilledQuantity")
	private int fulfilledQuantity;
	@JsonProperty("vendorNumber9")
	private int vendorNumber9;
	@JsonProperty("baseDivNumber")
	private int baseDivNumber;
	@JsonProperty("needType")
	private String needType;
	@JsonProperty("priorityNbrLong")
	private long priorityNbrLong;
	@JsonProperty("priorityReason")
	private String priorityReason;
	@JsonProperty("externalPONumber")
	private String externalPONumber;

	public int getSourceNumber() {
		return sourceNumber;
	}

	public void setSourceNumber(int sourceNumber) {
		this.sourceNumber = sourceNumber;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public int getWmtItemNumber() {
		return wmtItemNumber;
	}

	public void setWmtItemNumber(int wmtItemNumber) {
		this.wmtItemNumber = wmtItemNumber;
	}

	public int getDestinationNumber() {
		return destinationNumber;
	}

	public void setDestinationNumber(int destinationNumber) {
		this.destinationNumber = destinationNumber;
	}

	public String getOrderTrackingNumber() {
		return orderTrackingNumber;
	}

	public void setOrderTrackingNumber(String orderTrackingNumber) {
		this.orderTrackingNumber = orderTrackingNumber;
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDestCountryCode() {
		return destCountryCode;
	}

	public void setDestCountryCode(String destCountryCode) {
		this.destCountryCode = destCountryCode;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getOrderRecordType() {
		return orderRecordType;
	}

	public void setOrderRecordType(String orderRecordType) {
		this.orderRecordType = orderRecordType;
	}

	public String getPackType() {
		return packType;
	}

	public void setPackType(String packType) {
		this.packType = packType;
	}

	public int getPoLineNumber() {
		return poLineNumber;
	}

	public void setPoLineNumber(int poLineNumber) {
		this.poLineNumber = poLineNumber;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public int getPoType() {
		return poType;
	}

	public void setPoType(int poType) {
		this.poType = poType;
	}

	public int getPriorityNbr() {
		return priorityNbr;
	}

	public void setPriorityNbr(int priorityNbr) {
		this.priorityNbr = priorityNbr;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getSourceCountryCode() {
		return sourceCountryCode;
	}

	public void setSourceCountryCode(String sourceCountryCode) {
		this.sourceCountryCode = sourceCountryCode;
	}

	public int getVnpkQuantity() {
		return vnpkQuantity;
	}

	public void setVnpkQuantity(int vnpkQuantity) {
		this.vnpkQuantity = vnpkQuantity;
	}

	public int getWhpkQuantity() {
		return whpkQuantity;
	}

	public void setWhpkQuantity(int whpkQuantity) {
		this.whpkQuantity = whpkQuantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getQuantityUOM() {
		return quantityUOM;
	}

	public void setQuantityUOM(String quantityUOM) {
		this.quantityUOM = quantityUOM;
	}

	public boolean isSubstitutable() {
		return substitutable;
	}

	public void setSubstitutable(boolean substitutable) {
		this.substitutable = substitutable;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getWhseAreaCode() {
		return whseAreaCode;
	}

	public void setWhseAreaCode(String whseAreaCode) {
		this.whseAreaCode = whseAreaCode;
	}

	public String getUpcNumber() {
		return upcNumber;
	}

	public void setUpcNumber(String upcNumber) {
		this.upcNumber = upcNumber;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getFulfilledQuantity() {
		return fulfilledQuantity;
	}

	public void setFulfilledQuantity(int fulfilledQuantity) {
		this.fulfilledQuantity = fulfilledQuantity;
	}

	public int getVendorNumber9() {
		return vendorNumber9;
	}

	public void setVendorNumber9(int vendorNumber9) {
		this.vendorNumber9 = vendorNumber9;
	}

	public int getBaseDivNumber() {
		return baseDivNumber;
	}

	public void setBaseDivNumber(int baseDivNumber) {
		this.baseDivNumber = baseDivNumber;
	}

	public String getNeedType() {
		return needType;
	}

	public void setNeedType(String needType) {
		this.needType = needType;
	}

	public long getPriorityNbrLong() {
		return priorityNbrLong;
	}

	public void setPriorityNbrLong(long priorityNbrLong) {
		this.priorityNbrLong = priorityNbrLong;
	}

	public String getPriorityReason() {
		return priorityReason;
	}

	public void setPriorityReason(String priorityReason) {
		this.priorityReason = priorityReason;
	}

	public String getExternalPONumber() {
		return externalPONumber;
	}

	public void setExternalPONumber(String externalPONumber) {
		this.externalPONumber = externalPONumber;
	}
}
