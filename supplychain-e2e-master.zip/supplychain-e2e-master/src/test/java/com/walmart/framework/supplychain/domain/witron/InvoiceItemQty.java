package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "item", "qty", "poType", "totalSalesCost", "freightzoneCharge", "handlingCharge"})
public class InvoiceItemQty {
	@JsonProperty("item")
	private String item;
	@JsonProperty("qty")
	private String qty;
	@JsonProperty("poType")
	private String poType;
	@JsonProperty("totalSalesCost")
	private String totalSalesCost;
	@JsonProperty("freightzoneCharge")
	private String freightzoneCharge;
	@JsonProperty("handlingCharge")
	private String handlingCharge;
	
	@JsonProperty("item")
	public String getItem() {
		return item;
	}
	@JsonProperty("item")
	public void setItem(String item) {
		this.item = item;
	}
	@JsonProperty("qty")
	public String getQty() {
		return qty;
	}
	@JsonProperty("qty")
	public void setQty(String qty) {
		this.qty = qty;
	}
	@JsonProperty("poType")
	public String getPoType() {
		return poType;
	}
	@JsonProperty("poType")
	public void setPoType(String poType) {
		this.poType = poType;
	}
	@JsonProperty("totalSalesCost")
	public String getTotalSalesCost() {
		return totalSalesCost;
	}
	@JsonProperty("totalSalesCost")
	public void setTotalSalesCost(String totalSalesCost) {
		this.totalSalesCost = totalSalesCost;
	}
	@JsonProperty("freightzoneCharge")
	public String getFreightzoneCharge() {
		return freightzoneCharge;
	}
	@JsonProperty("freightzoneCharge")
	public void setFreightzoneCharge(String freightzoneCharge) {
		this.freightzoneCharge = freightzoneCharge;
	}
	@JsonProperty("handlingCharge")
	public String getHandlingCharge() {
		return handlingCharge;
	}
	@JsonProperty("handlingCharge")
	public void setHandlingCharge(String handlingCharge) {
		this.handlingCharge = handlingCharge;
	}
	
}
