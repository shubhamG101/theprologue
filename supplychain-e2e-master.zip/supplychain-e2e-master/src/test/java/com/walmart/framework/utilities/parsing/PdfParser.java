package com.walmart.framework.utilities.parsing;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.FileInputStream;
import java.io.IOException;

public class PdfParser {
	Logger logger = LogManager.getLogger(this.getClass());
	public  String[] getPdfContents(String filePath) {
		String data[]=null;
		logger.info("File Name:"+filePath);
		PDFTextStripper pdfStripper;
		try (PDDocument document = PDDocument.load(new FileInputStream(filePath))){
			pdfStripper = new PDFTextStripper();
			String text = pdfStripper.getText(document);
			data = text.split("\\r?\\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;
	}
}
