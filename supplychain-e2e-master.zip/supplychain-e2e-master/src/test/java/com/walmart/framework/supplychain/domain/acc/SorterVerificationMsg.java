package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "scannedLabel", "inductNumber", "doorNbr", "labelStatus",
		"errorCode" })
public class SorterVerificationMsg {

	@JsonProperty("scannedLabel")
	private String scannedLabel;
	@JsonProperty("inductNumber")
	private String inductNumber;
	@JsonProperty("doorNbr")
	private String doorNbr;
	@JsonProperty("labelStatus")
	private String labelStatus;
	@JsonProperty("errorCode")
	private String errorCode;
	@JsonProperty("destination")
	private String destination;
	@JsonProperty("countryCode")
	private String countryCode;
	@JsonProperty("labelType")
	private String labelType;

	@JsonProperty("destination")
	public String getDestination() {
		return destination;
	}

	@JsonProperty("destination")
	public void setDestination(String destination) {
		this.destination = destination;
	}

	@JsonProperty("countryCode")
	public String getCountryCode() {
		return countryCode;
	}

	@JsonProperty("countryCode")
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@JsonProperty("labelType")
	public String getLabelType() {
		return labelType;
	}

	@JsonProperty("labelType")
	public void setLabelType(String labelType) {
		this.labelType = labelType;
	}

	@JsonProperty("scannedLabel")
	public String getScannedLabel() {
		return scannedLabel;
	}

	@JsonProperty("scannedLabel")
	public void setScannedLabel(String scannedLabel) {
		this.scannedLabel = scannedLabel;
	}

	@JsonProperty("inductNumber")
	public String getInductNumber() {
		return inductNumber;
	}

	@JsonProperty("inductNumber")
	public void setInductNumber(String inductNumber) {
		this.inductNumber = inductNumber;
	}

	@JsonProperty("doorNbr")
	public String getDoorNbr() {
		return doorNbr;
	}

	@JsonProperty("doorNbr")
	public void setDoorNbr(String doorNbr) {
		this.doorNbr = doorNbr;
	}

	@JsonProperty("labelStatus")
	public String getLabelStatus() {
		return labelStatus;
	}

	@JsonProperty("labelStatus")
	public void setLabelStatus(String labelStatus) {
		this.labelStatus = labelStatus;
	}

	@JsonProperty("errorCode")
	public String getErrorCode() {
		return errorCode;
	}

	@JsonProperty("errorCode")
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
