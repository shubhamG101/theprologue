package com.walmart.framework.supplychain.domain.rdc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "names", "status", "types", "orgUnitId" })
public class SearchDoor {
	@JsonProperty("names")
	private List<String> names;
	@JsonProperty("status")
	private int status;
	@JsonProperty("types")
	private List<Integer> types;
	@JsonProperty("orgUnitId")
	private int orgUnitId;
	
	@JsonProperty("names")
	public List<String> getNames() {
		return names;
	}
	@JsonProperty("names")
	public void setNames(List<String> names) {
		this.names = names;
	}
	@JsonProperty("status")
	public int getStatus() {
		return status;
	}
	@JsonProperty("status")
	public void setStatus(int status) {
		this.status = status;
	}
	@JsonProperty("types")
	public List<Integer> getTypes() {
		return types;
	}
	@JsonProperty("types")
	public void setTypes(List<Integer> types) {
		this.types = types;
	}
	@JsonProperty("orgUnitId")
	public int getOrgUnitId() {
		return orgUnitId;
	}
	@JsonProperty("orgUnitId")
	public void setOrgUnitId(int orgUnitId) {
		this.orgUnitId = orgUnitId;
	}
}
