package com.walmart.framework.supplychain.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.walmart.framework.utilities.jms.DC_TYPE;

public class Config {

	public static String siteNumber;
	public static String countryCode;
	public static String sUrl;
	public String oaEP;
	public String idmEP;
	public String ymsUiUrl;
	public String ymsDriverUiUrl;
	public String outboundUiUrl;

	private static String orderManagerSearch;
	private static String fetchOrderAllocation;
	public String idmDeliveryEP;
	public String idmDeliveryDoorSearchEP;
	public String idmReceiptEP;
	public String loadingUrl;
	public String orderSearchEndPoint;
	public String orderTrackerUIEndPoint;
	public String inventorySearchEP;

	public String idocEP;

	public String mmUiUrl;
	public String printingEP;
	public String itemMdmEP;
	public static DC_TYPE DC;
	public static boolean isPipeline=false;
	public static boolean isDataFileCreated=false;
	public static ENVIRONMENT ENV;
	public static boolean isOrderWellMocked = false;
	public static boolean isParallel=false;
	public static boolean isCloud=false;
	public static Map<String,String> featureFileToNameMap=new HashMap<>();
	public static int totalNumberOfFeatures=0;

	@Deprecated
	public Config() {
		sUrl = System.getProperty("CONTEXT_URL");
		String replacedUrl = sUrl.replaceAll("http://", "");
		siteNumber = replacedUrl.split("/")[1].split("-")[1];
		countryCode = replacedUrl.split("/")[1].split("-")[0];
		initializeEndPoints(sUrl);
	}

	public static String getOrderManagerSearch() {
		return orderManagerSearch;
	}

	public static String getFetchOrderAllocation() {
		return fetchOrderAllocation;
	}

	private void initializeEndPoints(String sUrl) {
		initializeOPEndPoints(sUrl);
		initializeIDMEndPoints(sUrl);
		initializeIDMDeliveryEndPoint(sUrl);
		initializeIDMReceiptEndPoint(sUrl);
		initializeLoadingURL(sUrl);
		initializeOrderTrackerUIEndPoint(sUrl);
		initializeYMSUiUrl();
		initializeYMSDriverUiUrl();
		initializeInventorySearchEndPoint(sUrl);
		initializeOTOrderSearchEndPoint(sUrl);
		initializeOutboundUiUrl(sUrl);
		initializeMMUiUrl(sUrl);
		initializePrinterEndPoint();
		initializeItemMdmUrl();
		initializeIDMDeliverySearchUsingDoorEndPoint(sUrl);

	}

	private void initializeItemMdmUrl() {
		itemMdmEP = sUrl + "/item-mdm/supplyitem/us/wm";
	}

	private void initializeYMSUiUrl() {

		ymsUiUrl = "https://yms.s" + siteNumber + "." + countryCode
				+ ".wal-mart.com:61414/usermgmtWeb/loginHome.action?deviceTypeCode=1";

	}

	private void initializeIDMEndPoints(String sUrl) {

		idmEP = sUrl + "/inbound-document-manager/document/deliveries/";

	}

	private void initializeOPEndPoints(String sUrl) {
		orderManagerSearch = sUrl + "/order-services/orders/search";
		fetchOrderAllocation = sUrl + "/allocation-order-service/allocations";
	}

	private void initializeLoadingURL(String sUrl) {
		loadingUrl = sUrl + "/loadingmaterial/#!/splash";

	}

	private void initializeIDMDeliveryEndPoint(String sUrl) {

		idmDeliveryEP = sUrl + "/inbound-document-manager/document/deliveries/";

	}

	private void initializeIDMDeliverySearchUsingDoorEndPoint(String sUrl) {

		idmDeliveryDoorSearchEP = sUrl
				+ "/inbound-document-manager/document/deliveries/search";

	}

	private void initializeIDMReceiptEndPoint(String sUrl) {

		idmReceiptEP = sUrl + "/inbound-document-manager/document/deliveryReceipts/";

	}

	private void initializeYMSDriverUiUrl() {

		ymsDriverUiUrl = "https://yms.s" + siteNumber + "." + countryCode
				+ ".wal-mart.com:61414/usermgmtWeb/loginHome.action?deviceTypeCode=3";
	}

	private void initializeInventorySearchEndPoint(String sUrl) {

		inventorySearchEP = sUrl + "/inventory/inventories/containers/";

	}

	private void initializeOTOrderSearchEndPoint(String sUrl) {

		orderSearchEndPoint = sUrl + "/order-inquiry/orders/search/";

	}

	private void initializeOrderTrackerUIEndPoint(String sUrl) {
		orderTrackerUIEndPoint = sUrl + "/order-processing-client/#!/home";
	}

	private void initializeOutboundUiUrl(String sUrl) {

		outboundUiUrl = sUrl + "/outboundmaterial/#!/splash";

	}

	public String initializeSoftAllocationUrlDA() {

		return sUrl + "/da-sstk-fulfillment-method/soft-allocations?message_id=";

	}

	public String initializeFulfillmentStatusUrlDA() {

		return sUrl + "/da-fulfillment-manager/fulfillments/search/";
	}

	public String deleteFulFillInstructionDA() {

		return sUrl + "/da-sstk-fulfillment-method/fulfillment-instructions/";
	}

	public String deleteFulFillmentsDA() {

		return sUrl + "/da-fulfillment-manager/fulfillments/";
	}

	public String deleteFulFillmentsSSTK() {

		return sUrl + "/sstk-fulfillment-manager/fulfillments/";
	}

	private void initializePrinterEndPoint() {
		printingEP = "http://nimservices.s" + siteNumber
				+ ".us.wal-mart.com:7099/printing/" + countryCode + "/" + siteNumber;
	}

	private void initializeMMUiUrl(String sUrl) {

		mmUiUrl = sUrl + "/mm-managementui/login";
	}

	public List<String> deleteOrderTrackingData() {
		List<String> OrderTrackingUrls = new ArrayList<>();
		OrderTrackingUrls.add(sUrl + "/order-inquiry/delete/orders");
		OrderTrackingUrls.add(sUrl + "/order-inquiry/delete/picksByOrderIds");
		OrderTrackingUrls.add(sUrl + "/order-services/delete/orders");
		return OrderTrackingUrls;
	}

	public String deleteDelivery() {
		return sUrl + "/inbound-document-manager/v1/document/idmdocs/";
	}

}
