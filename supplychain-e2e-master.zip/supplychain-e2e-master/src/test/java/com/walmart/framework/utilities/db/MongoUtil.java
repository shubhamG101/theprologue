package com.walmart.framework.utilities.db;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import com.ibm.icu.impl.Assert;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.MongoWriteException;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.result.UpdateResult;
import com.walmart.framework.supplychain.config.Config;
import com.walmart.framework.utilities.jms.DC_TYPE;

import spring.SpringTestConfiguration;

@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class MongoUtil {

	private static int connectTimeout = 1000;
	Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	Environment environment;

	public  MongoClient createConnection() {
		String  username=null;
		String password=null;
		String databaseName=null;
		String host_a=null;
		String host_b=null;
		String host_c=null;
		int  port=0;
		
		if (Config.DC==DC_TYPE.MCC) {
			username = environment.getProperty("mongo_username_mcc");
			  password = environment.getProperty("mongo_password_mcc");
			  databaseName = environment.getProperty("mongo_database_mcc");
			  host_a = environment.getProperty("mongo_host_a_mcc");
			  host_b = environment.getProperty("mongo_host_b_mcc");
			  host_c = environment.getProperty("mongo_host_c_mcc");
			  port = Integer.parseInt(environment.getProperty("mongo_port_mcc"));
		}
		if (Config.DC==DC_TYPE.ACC) {
			username = environment.getProperty("mongo_username_mcc");
			  password = environment.getProperty("mongo_password_mcc");
			  databaseName = environment.getProperty("mongo_database_mcc");
			  host_a = environment.getProperty("mongo_host_a_mcc");
			  host_b = environment.getProperty("mongo_host_b_mcc");
			  host_c = environment.getProperty("mongo_host_c_mcc");
			  port = Integer.parseInt(environment.getProperty("mongo_port_mcc"));
		}
		else if (Config.DC==DC_TYPE.MCC_RDC || Config.DC==DC_TYPE.ATLAS_RDC || Config.DC==DC_TYPE.ACC_RDC || Config.DC==DC_TYPE.RDC) {
			  username = environment.getProperty("mongo_username_rdc");
			  password = environment.getProperty("mongo_password_rdc");
			  databaseName = environment.getProperty("mongo_database_rdc");
			  host_a = environment.getProperty("mongo_host_a_rdc");
			  host_b = environment.getProperty("mongo_host_b_rdc");
			  host_c = environment.getProperty("mongo_host_c_rdc");
			  port = Integer.parseInt(environment.getProperty("mongo_port_rdc"));
		}
		MongoCredential credential = MongoCredential.createCredential(username, databaseName, password.toCharArray());
		List<ServerAddress> addressDetails = Arrays.asList(
				new ServerAddress(host_a, port),
				new ServerAddress(host_b, port),
				new ServerAddress(host_c, port));

		MongoClientOptions options = new MongoClientOptions.Builder().connectTimeout(connectTimeout).build();

		return new MongoClient(addressDetails, credential, options);
	}


	public  List<String> getDatafromDB(String db, String collection,BasicDBObject searchQuery, String field) throws SQLException {



		MongoClient mongoClient = createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		MongoCollection<Document> table = database.getCollection(collection);
		List<String> results = new ArrayList<>();
		logger.info(db+" > "+collection+" Executing GET query : "+searchQuery);
		table.find(searchQuery).iterator().forEachRemaining(doc -> results.add(doc.get(field).toString()));
		
		closeConnection(mongoClient);

		return results;
	}


	public  void setDatatoDB(String db,String collection, Bson whereQuery, Bson updateQuery) {
		MongoClient mongoClient = createConnection();

		MongoDatabase database = mongoClient.getDatabase(db);

		MongoCollection<Document> table = database.getCollection(collection);
		logger.info(db+" > "+collection+" Executing SET whereQuery : "+updateQuery);
		logger.info(db+" > "+collection+" Executing SET updateQuery : "+updateQuery);
		logger.info("Updating data ....." + db);

		Bson set = new Document().append("$set", updateQuery);
		try {
			UpdateResult result = table.updateOne(whereQuery, set, new UpdateOptions().upsert(true));
			if (result.getMatchedCount() > 0) {
				logger.info("successfully updated data in DB : " + db);
			} else {
				Assert.fail("failed to update DB: " + db);
				logger.info("failed to update DB: " + db);
			}
		} catch (MongoWriteException e) {
			logger.error(e.toString());
			e.printStackTrace();
			Assert.fail("failed to update  Inbound DB: " + db);
		}

		closeConnection(mongoClient);

	}
	
	public long getRecordCount(String db, String collection,BasicDBObject searchQuery) throws SQLException {
		long recordCount=0;
		MongoClient mongoClient = createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		MongoCollection<Document> table = database.getCollection(collection);
		recordCount = table.count(searchQuery);

			closeConnection(mongoClient);

		return recordCount;
		}
	public void removeRecords(String db, String collection,DBObject searchQuery){
		
		logger.info(db+" > "+collection+" Executing DELETE query : "+(Bson) searchQuery);
		long recordCount=0;
		MongoClient mongoClient = createConnection();
		MongoDatabase database = mongoClient.getDatabase(db);
		MongoCollection<Document> table = database.getCollection(collection);
		table.deleteMany((Bson) searchQuery);
		}

	public void closeConnection(MongoClient mongoClient) {
		logger.info("Closing the statement and connection");

		mongoClient.close();

	}

}