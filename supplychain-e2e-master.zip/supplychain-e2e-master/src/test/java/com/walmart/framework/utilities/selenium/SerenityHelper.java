package com.walmart.framework.utilities.selenium;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.pages.PageObject;

public class SerenityHelper extends ContextDriver {
	private static final Logger LOGGER = LogManager.getLogger(ContextDriver.class);	
	public void click(WebElement webElementToBeClicked) {
		element(webElementToBeClicked).waitUntilVisible();
		element(webElementToBeClicked).waitUntilClickable();
		element(webElementToBeClicked).click();
	}
	public void sleep(int timeInSeconds) {
		try {
			Thread.sleep(timeInSeconds*1000L);
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
	public void sleep() {
		sleep(2);
	}
	public Object executeScript(String script) {
		WebDriver driver=getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return js.executeScript(script);
	}
	public Object setWebElementValue(WebElement element,String value) {
		WebDriver driver=getDriverInstance();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		LOGGER.info("Setting value {} in textfield",value);
		return js.executeScript("arguments[0].setAttribute('value', '" + value +"')", element);
	}
}
