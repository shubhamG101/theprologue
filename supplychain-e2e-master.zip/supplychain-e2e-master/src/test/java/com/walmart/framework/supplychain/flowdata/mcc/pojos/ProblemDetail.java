package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "problemTicketNumber",
    "problemContainersList",
    "problemStatus",
    "problemContainer",
    "problemQty",
})
public class ProblemDetail {
	
	@JsonProperty("problemTicketNumber")
    private String problemTicketNumber;
	
	@JsonProperty("problemContainersList")
    private List<ProblemContainer> problemContainersList;
	
    @JsonProperty("problemContainer")
    private String problemContainer;
    
    @JsonProperty("problemStatus")
    private String problemStatus;
    
    @JsonProperty("problemQty")
    private String problemQty;

    @JsonProperty("problemTicketNumber")
    public String getProblemTicketNumber() {
		return problemTicketNumber;
	}
    
    @JsonProperty("problemTicketNumber")
	public void setProblemTicketNumber(String problemTicketNumber) {
		this.problemTicketNumber = problemTicketNumber;
	}
    
    
    @JsonProperty("problemContainersList")
	public List<ProblemContainer> getProblemContainersList() {
		return problemContainersList;
	}
    
    @JsonProperty("problemContainersList")
	public void setProblemContainersList(List<ProblemContainer> problemContainersList) {
		this.problemContainersList = problemContainersList;
	}
    
    @JsonProperty("problemContainer")
	public String getproblemContainer() {
		return problemContainer;
	}
    
    @JsonProperty("problemContainer")
	public void setproblemContainer(String problemContainer) {
		this.problemContainer = problemContainer;
	}
	
    @JsonProperty("problemStatus")
    public String getproblemStatus() {
		return problemStatus;
	}
    
    @JsonProperty("problemStatus")
	public void setproblemStatus(String problemStatus) {
		this.problemStatus = problemStatus;
	}
    
    @JsonProperty("problemQty")
    public String getproblemQty() {
		return problemQty;
	}
    
    @JsonProperty("problemQty")
	public void setproblemQty(String problemQty) {
		this.problemQty = problemQty;
	}
}