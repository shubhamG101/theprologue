
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "poNumber",
    "poName",
    "sourceNumber",
    "baseDiv",
    "srcCountryCode",
    "poStatus",
    "isPlannedPo",
    "channelMethod",
    "poLineDetails",
    "omsPONumber",
    "vendorNumber",
    "isChannelFlipRequired",
    "thorPO",
    "uuid",
    "zonetemperatures"
})
public class PoDetail {

    @JsonProperty("poNumber")
    private String poNumber;
    @JsonProperty("poName")
    private String poName;
	@JsonProperty("sourceNumber")
    private String sourceNumber;
    @JsonProperty("baseDiv")
    private String baseDiv;
    @JsonProperty("srcCountryCode")
    private String srcCountryCode;
    @JsonProperty("poStatus")
    private String poStatus;
    @JsonProperty("isPlannedPo")
    private String isPlannedPo;
    @JsonProperty("channelMethod")
    private String channelMethod;
	@JsonProperty("omsPONumber")
    private String omsPONumber;
    @JsonProperty("poLineDetails")
    private List<PoLineDetail> poLineDetails = new ArrayList<PoLineDetail>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    @JsonProperty("vendorNumber")
    private String vendorNumber;
    @JsonProperty("thorPO")
    private String thorPO;
    @JsonProperty("uuid")
    private List<String> uuid = new ArrayList<>();
    @JsonProperty("isChannelFlipRequired")
    private String isChannelFlipRequired;
    @JsonProperty("zonetemperatures")
    private String zonetemperatures;
    
    public String getPoName() {
		return poName;
	}
	public void setPoName(String poName) {
		this.poName = poName;
	}
    public String getIsChannelFlipRequired() {
  		return isChannelFlipRequired;
  	}
  	public void setIsChannelFlipRequired(String isChannelFlipRequired) {
  		this.isChannelFlipRequired = isChannelFlipRequired;
  	}
    @JsonProperty("thorPO")
    public String getThorPO() {
		return thorPO;
	}
    @JsonProperty("thorPO")
	public void setThorPO(String thorPO) {
		this.thorPO = thorPO;
    }

    public List<String> getUuid() {
		return uuid;
	}

	public void setUuid(List<String> uuid) {
		this.uuid = uuid;
	}

	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	@JsonProperty("poNumber")
    public String getPoNumber() {
        return poNumber;
    }

    @JsonProperty("poNumber")
    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }
    
    @JsonProperty("omsPONumber")
    public String getOmsPONumber() {
		return omsPONumber;
	}

    @JsonProperty("omsPONumber")
	public void setOmsPONumber(String omsPONumber) {
		this.omsPONumber = omsPONumber;
	}


    public PoDetail withPoNumber(String poNumber) {
        this.poNumber = poNumber;
        return this;
    }

    @JsonProperty("channelMethod")
    public String getChannelMethod() {
        return channelMethod;
    }

    @JsonProperty("channelMethod")
    public void setChannelMethod(String channelMethod) {
        this.channelMethod = channelMethod;
    }

    public PoDetail withChannelMethod(String channelMethod) {
        this.channelMethod = channelMethod;
        return this;
    }

    public String getBaseDiv() {
        return baseDiv;
    }

    public void setBaseDiv(String baseDiv) {
        this.baseDiv = baseDiv;
    }

    public PoDetail withBaseDiv(String baseDiv) {
        this.baseDiv = baseDiv;
        return this;
    }

    public String getSrcCountryCode() {
        return srcCountryCode;
    }

    public void setSrcCountryCode(String srcCountryCode) {
        this.srcCountryCode = srcCountryCode;
    }

    public PoDetail withSrcCountryCode(String srcCountryCode) {
        this.srcCountryCode = srcCountryCode;
        return this;
    }


    @JsonProperty("isPlannedPo")
    public String getIsPlannedPo() {
        return isPlannedPo;
    }

    @JsonProperty("isPlannedPo")
    public void setIsPlannedPo(String isPlannedPo) {
        this.isPlannedPo = isPlannedPo;
    }

    public PoDetail withIsPlannedPo(String isPlannedPo) {
        this.isPlannedPo = isPlannedPo;
        return this;
    }

    @JsonProperty("sourceNumber")
    public String getSourceNumber() {
        return sourceNumber;
    }

    @JsonProperty("sourceNumber")
    public void setSourceNumber(String sourceNumber) {
        this.sourceNumber = sourceNumber;
    }

    public PoDetail withSourceNumber(String sourceNumber) {
        this.sourceNumber = sourceNumber;
        return this;
    }

    @JsonProperty("poStatus")
    public String getPoStatus() {
        return poStatus;
    }

    @JsonProperty("poStatus")
    public void setPoStatus(String poStatus) {
        this.poStatus = poStatus;
    }

    public PoDetail withPoStatus(String poStatus) {
        this.poStatus = poStatus;
        return this;
    }

    @JsonProperty("poLineDetails")
    public List<PoLineDetail> getPoLineDetails() {
        return poLineDetails;
    }

    @JsonProperty("poLineDetails")
    public void setPoLineDetails(List<PoLineDetail> poLineDetails) {
        this.poLineDetails = poLineDetails;
    }

    public PoDetail withPoLineDetails(List<PoLineDetail> poLineDetails) {
        this.poLineDetails = poLineDetails;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PoDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }
    
    @JsonProperty("zonetemperatures")
    public String getZonetemperatures() {
		return zonetemperatures;
	}
    @JsonProperty("zonetemperatures")
	public void setZonetemperatures(String zonetemperatures) {
		this.zonetemperatures = zonetemperatures;
	}
	@Override
    public String toString() {
        return new ToStringBuilder(this).append("poNumber", poNumber).append("sourceNumber", sourceNumber).append("poStatus", poStatus).append("poLineDetails", poLineDetails).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(poLineDetails).append(poStatus).append(additionalProperties).append(sourceNumber).append(poNumber).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PoDetail) == false) {
            return false;
        }
        PoDetail rhs = ((PoDetail) other);
        return new EqualsBuilder().append(poLineDetails, rhs.poLineDetails).append(poStatus, rhs.poStatus).append(additionalProperties, rhs.additionalProperties).append(sourceNumber, rhs.sourceNumber).append(poNumber, rhs.poNumber).isEquals();
    }
}
