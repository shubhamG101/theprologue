package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "quantity", "thorUnitsPer", "sellByUnits", "vendorSku", "thorSkuId", "description", "unitWeight", "unitVolume", "unitPrice", "unitDiscount", "total", "label", "barcode", "ackQty", "notes", "itemNbr", "poLineStatus" })
public class ThorItemDetails {

	@JsonProperty("quantity")
	private int quantity;
	@JsonProperty("thorUnitsPer")
	private int thorUnitsPer;
	@JsonProperty("sellByUnits")
	private int sellByUnits;
	@JsonProperty("vendorSku")
	private String vendorSku;
	@JsonProperty("thorSkuId")
	private String thorSkuId;
	@JsonProperty("description")
	private String description;
	@JsonProperty("unitWeight")
	private double unitWeight;
	@JsonProperty("unitVolume")
	private double unitVolume;
	@JsonProperty("unitPrice")
	private double unitPrice;
	@JsonProperty("unitDiscount")
	private int unitDiscount;
	@JsonProperty("total")
	private int total;
	@JsonProperty("label")
	private String label;
	@JsonProperty("barcode")
	private String barcode;
	@JsonProperty("ackQty")
	private String ackQty;
	@JsonProperty("notes")
	private String notes;
	@JsonProperty("itemNbr")
	private String itemNbr;
	@JsonProperty("poLineStatus")
	private String poLineStatus;
	
	@JsonProperty("quantity")
	public int getQuantity() {
		return quantity;
	}
	@JsonProperty("quantity")
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@JsonProperty("thorUnitsPer")
	public int getThorUnitsPer() {
		return thorUnitsPer;
	}
	@JsonProperty("thorUnitsPer")
	public void setThorUnitsPer(int thorUnitsPer) {
		this.thorUnitsPer = thorUnitsPer;
	}
	@JsonProperty("sellByUnits")
	public int getSellByUnits() {
		return sellByUnits;
	}
	@JsonProperty("sellByUnits")
	public void setSellByUnits(int sellByUnits) {
		this.sellByUnits = sellByUnits;
	}
	@JsonProperty("vendorSku")
	public String getVendorSku() {
		return vendorSku;
	}
	@JsonProperty("vendorSku")
	public void setVendorSku(String vendorSku) {
		this.vendorSku = vendorSku;
	}
	@JsonProperty("thorSkuId")
	public String getThorSkuId() {
		return thorSkuId;
	}
	@JsonProperty("thorSkuId")
	public void setThorSkuId(String thorSkuId) {
		this.thorSkuId = thorSkuId;
	}
	@JsonProperty("description")
	public String getDescription() {
		return description;
	}
	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}
	@JsonProperty("unitWeight")
	public double getUnitWeight() {
		return unitWeight;
	}
	@JsonProperty("unitWeight")
	public void setUnitWeight(double unitWeight) {
		this.unitWeight = unitWeight;
	}
	@JsonProperty("unitVolume")
	public double getUnitVolume() {
		return unitVolume;
	}
	@JsonProperty("unitVolume")
	public void setUnitVolume(double unitVolume) {
		this.unitVolume = unitVolume;
	}
	@JsonProperty("unitPrice")
	public double getUnitPrice() {
		return unitPrice;
	}
	@JsonProperty("unitPrice")
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	@JsonProperty("unitDiscount")
	public int getUnitDiscount() {
		return unitDiscount;
	}
	@JsonProperty("unitDiscount")
	public void setUnitDiscount(int unitDiscount) {
		this.unitDiscount = unitDiscount;
	}
	@JsonProperty("total")
	public int getTotal() {
		return total;
	}
	@JsonProperty("total")
	public void setTotal(int total) {
		this.total = total;
	}
	@JsonProperty("label")
	public String getLabel() {
		return label;
	}
	@JsonProperty("label")
	public void setLabel(String label) {
		this.label = label;
	}
	@JsonProperty("barcode")
	public String getBarcode() {
		return barcode;
	}
	@JsonProperty("barcode")
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	@JsonProperty("ackQty")
	public String getAckQty() {
		return ackQty;
	}
	@JsonProperty("ackQty")
	public void setAckQty(String ackQty) {
		this.ackQty = ackQty;
	}
	@JsonProperty("notes")
	public String getNotes() {
		return notes;
	}
	@JsonProperty("notes")
	public void setNotes(String notes) {
		this.notes = notes;
	}
	@JsonProperty("itemNbr")
	public String getItemNbr() {
		return itemNbr;
	}
	@JsonProperty("itemNbr")
	public void setItemNbr(String itemNbr) {
		this.itemNbr = itemNbr;
	}
	@JsonProperty("poLineStatus")
	public String getPoLineStatus() {
		return poLineStatus;
	}
	@JsonProperty("poLineStatus")
	public void setPoLineStatus(String poLineStatus) {
		this.poLineStatus = poLineStatus;
	}
	
}

