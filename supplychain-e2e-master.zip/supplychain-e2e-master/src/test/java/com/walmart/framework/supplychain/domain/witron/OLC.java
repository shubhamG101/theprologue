package com.walmart.framework.supplychain.domain.witron;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Owner", "OrderIdent", "OrderLineIdent", "ProdIdent", "UM", "ExpiryDate", "OriginDate", "BatchNo",
		"QtyPickedUm", "QtyMissedUm", "WeightPicked", "QState", "Reason" })
public class OLC {
	@JsonProperty("Owner")
	private OwnerBean Owner;
	@JsonProperty("OrderIdent")
	private String OrderIdent;
	@JsonProperty("OrderLineIdent")
	private String OrderLineIdent;
	@JsonProperty("ProdIdent")
	private String ProdIdent;
	@JsonProperty("UM")
	private String UM;
	@JsonProperty("ExpiryDate")
	private String ExpiryDate;
	@JsonProperty("OriginDate")
	private String OriginDate;
	@JsonProperty("BatchNo")
	private String BatchNo;
	@JsonProperty("QtyPickedUm")
	private int QtyPickedUm;
	@JsonProperty("QtyMissedUm")
	private int QtyMissedUm;
	@JsonProperty("WeightPicked")
	private GrossWeightBean WeightPicked;
	@JsonProperty("QState")
	private int QState;
	@JsonProperty("Reason")
	private String Reason;

	@JsonProperty("Owner")
	public OwnerBean getOwner() {
		return Owner;
	}
	@JsonProperty("Owner")
	public void setOwner(OwnerBean owner) {
		Owner = owner;
	}
	@JsonProperty("OrderIdent")
	public String getOrderIdent() {
		return OrderIdent;
	}
	@JsonProperty("OrderIdent")
	public void setOrderIdent(String orderIdent) {
		OrderIdent = orderIdent;
	}
	@JsonProperty("OrderLineIdent")
	public String getOrderLineIdent() {
		return OrderLineIdent;
	}
	@JsonProperty("OrderLineIdent")
	public void setOrderLineIdent(String orderLineIdent) {
		OrderLineIdent = orderLineIdent;
	}
	@JsonProperty("ProdIdent")
	public String getProdIdent() {
		return ProdIdent;
	}
	@JsonProperty("ProdIdent")
	public void setProdIdent(String prodIdent) {
		ProdIdent = prodIdent;
	}
	@JsonProperty("UM")
	public String getUM() {
		return UM;
	}
	@JsonProperty("UM")
	public void setUM(String uM) {
		UM = uM;
	}
	@JsonProperty("ExpiryDate")
	public String getExpiryDate() {
		return ExpiryDate;
	}
	@JsonProperty("ExpiryDate")
	public void setExpiryDate(String expiryDate) {
		ExpiryDate = expiryDate;
	}
	@JsonProperty("OriginDate")
	public String getOriginDate() {
		return OriginDate;
	}
	@JsonProperty("OriginDate")
	public void setOriginDate(String originDate) {
		OriginDate = originDate;
	}
	@JsonProperty("BatchNo")
	public String getBatchNo() {
		return BatchNo;
	}
	@JsonProperty("BatchNo")
	public void setBatchNo(String batchNo) {
		BatchNo = batchNo;
	}
	@JsonProperty("QtyPickedUm")
	public int getQtyPickedUm() {
		return QtyPickedUm;
	}
	@JsonProperty("QtyPickedUm")
	public void setQtyPickedUm(int qtyPickedUm) {
		QtyPickedUm = qtyPickedUm;
	}
	@JsonProperty("QtyMissedUm")
	public int getQtyMissedUm() {
		return QtyMissedUm;
	}
	@JsonProperty("QtyMissedUm")
	public void setQtyMissedUm(int qtyMissedUm) {
		QtyMissedUm = qtyMissedUm;
	}
	@JsonProperty("WeightPicked")
	public GrossWeightBean getWeightPicked() {
		return WeightPicked;
	}
	@JsonProperty("WeightPicked")
	public void setWeightPicked(GrossWeightBean weightPicked) {
		WeightPicked = weightPicked;
	}
	@JsonProperty("QState")
	public int getQState() {
		return QState;
	}
	@JsonProperty("QState")
	public void setQState(int qState) {
		QState = qState;
	}
	@JsonProperty("Reason")
	public String getReason() {
		return Reason;
	}
	@JsonProperty("Reason")
	public void setReason(String reason) {
		Reason = reason;
	}
}
