
package com.walmart.framework.supplychain.flowdata.mcc.pojos;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "deliveryNumber",
    "deliveryName",
    "inboundDoorNumber",
    "inboundTrailerNumber",
    "poNumbers",
    "inboundLoadNumber",
    "shipments",
    "containersOnShipment"
})
public class DeliveryDetailsRDC {

	@JsonProperty("deliveryNumber")
    private String deliveryNumber;
    @JsonProperty("deliveryName")
    private String deliveryName;
    @JsonProperty("deliveryStatus")
    private String deliveryStatus;
    @JsonProperty("inboundDoorNumber")
    private String inboundDoorNumber;
    @JsonProperty("inboundTrailerNumber")
    private String inboundTrailerNumber;
	@JsonProperty("poNumbers")
    private List<String> poNumbers = new ArrayList<String>();
	@JsonProperty("shipments")
    private List<String> shipments = new ArrayList<String>();
	@JsonProperty("containersOnShipment")
    private List<String> containersOnShipment = new ArrayList<String>();
	
    public List<String> getContainersOnShipment() {
		return containersOnShipment;
	}
	public void setContainersOnShipment(List<String> containersOnShipment) {
		this.containersOnShipment = containersOnShipment;
	}
    public List<String> getshipments() {
		return shipments;
	}
	public void setshipments(List<String> shipments) {
		this.shipments = shipments;
	}
    public String getInboundLoadNumber() {
		return inboundLoadNumber;
	}

	public void setInboundLoadNumber(String inboundLoadNumber) {
		this.inboundLoadNumber = inboundLoadNumber;
	}
	@JsonProperty("inboundLoadNumber")
    private String inboundLoadNumber;

	public String getDeliveryName() {
		return deliveryName;
	}
	
	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}
	
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	@JsonProperty("itemLabelId")
    private List<String> itemLabelId = new ArrayList<String>();

	@JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("deliveryNumber")
    public String getDeliveryNumber() {
        return deliveryNumber;
    }

    @JsonProperty("deliveryNumber")
    public void setDeliveryNumber(String deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
    }

    public DeliveryDetailsRDC withDeliveryNumber(String deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
        return this;
    }

    @JsonProperty("inboundDoorNumber")
    public String getInboundDoorNumber() {
        return inboundDoorNumber;
    }

    @JsonProperty("inboundDoorNumber")
    public void setInboundDoorNumber(String inboundDoorNumber) {
        this.inboundDoorNumber = inboundDoorNumber;
    }

    public DeliveryDetailsRDC withInboundDoorNumber(String inboundDoorNumber) {
        this.inboundDoorNumber = inboundDoorNumber;
        return this;
    }

    @JsonProperty("inboundTrailerNumber")
    public String getInboundTrailerNumber() {
        return inboundTrailerNumber;
    }

    @JsonProperty("inboundTrailerNumber")
    public void setInboundTrailerNumber(String inboundTrailerNumber) {
        this.inboundTrailerNumber = inboundTrailerNumber;
    }

    public DeliveryDetailsRDC withInboundTrailerNumber(String inboundTrailerNumber) {
        this.inboundTrailerNumber = inboundTrailerNumber;
        return this;
    }

    @JsonProperty("poNumbers")
    public List<String> getPoNumbers() {
        return poNumbers;
    }

    @JsonProperty("poNumbers")
    public void setPoNumbers(List<String> poNumbers) {
        this.poNumbers = poNumbers;
    }
    
    @JsonProperty("itemLabelId")
    public List<String> getItemLabelId() {
		return itemLabelId;
	}

    @JsonProperty("itemLabelId")
	public void setItemLabelId(List<String> itemLabelId) {
		this.itemLabelId = itemLabelId;
	}

    public DeliveryDetailsRDC withPoNumbers(List<String> poNumbers) {
        this.poNumbers = poNumbers;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DeliveryDetailsRDC withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("deliveryNumber", deliveryNumber).append("inboundDoorNumber", inboundDoorNumber).append("inboundTrailerNumber", inboundTrailerNumber).append("poNumbers", poNumbers).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(inboundDoorNumber).append(inboundTrailerNumber).append(poNumbers).append(additionalProperties).append(deliveryNumber).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DeliveryDetailsRDC) == false) {
            return false;
        }
        DeliveryDetailsRDC rhs = ((DeliveryDetailsRDC) other);
        return new EqualsBuilder().append(inboundDoorNumber, rhs.inboundDoorNumber).append(inboundTrailerNumber, rhs.inboundTrailerNumber).append(poNumbers, rhs.poNumbers).append(additionalProperties, rhs.additionalProperties).append(deliveryNumber, rhs.deliveryNumber).isEquals();
    }

}
