package com.walmart.framework.supplychain.spring;


//
//@Configuration
//@ComponentScan({"com.walmart.supplychain"})
//@EnableRetry
//@SpringBootApplication
//@Import(MessagingConfig.class)
//@PropertySource(value = {"classpath:properties/db.properties", "classpath:properties/app.properties","classpath:properties/cert_endpoints.properties","classpath:properties/filepaths.properties","classpath:properties/message.properties"})
public class SpringConfiguration {
//
//    private static final String url = "jdbc.url";
//    private static final String user = "jdbc.username";
//    private static final String driver = "jdbc.driverClassName";
//    private static final String password = "jdbc.password";
//
//    @Configuration
//    @Profile("e2e")
//    @PropertySource(value = {"classpath:properties/db.properties", "classpath:properties/app.properties","classpath:properties/cert_endpoints.properties","classpath:properties/filepaths.properties","classpath:properties/message.properties"})
//    public static class E2eAppConfig {
//
//        @Autowired
//        Environment environment;
//
////        @Bean
////        public static PropertyPlaceholderConfigurer properties() {
////
////            PropertyPlaceholderConfigurer ppc
////                    = new PropertyPlaceholderConfigurer();
////
////            Resource[] resources = new ClassPathResource[]
////                    { new ClassPathResource( "properties/db.properties" ), new ClassPathResource( "properties/app.properties" ),
////                            new ClassPathResource("properties/logging.properties")};
////            ppc.setLocations( resources );
////            ppc.setIgnoreUnresolvablePlaceholders( true );
////
////
////            return ppc;
////        }
//
//
//        @Bean
//        public KafkaUtils kafkaUtils() {
//            return new KafkaUtils();
//        }
//
//        @Bean
//        public SpringJmsUtils springJmsUtils() {
//            return new SpringJmsUtils();
//        }
//
//        @Bean
//        public Yms yms() {
//            return new Yms();
//        }
//
//        @Bean
//        public Config config() {
//            return new Config();
//        }
//
//
//        @Bean
//        public RestTemplate restTemplate() {
//            return new RestTemplate();
//        }
//
//        @Bean
//        public SpringRestClient springRestClient() {
//            return new SpringRestClient();
//        }
//
//        @Bean
//        public JsonUtils jsonUtils() {
//            return new JsonUtils();
//        }
//
//        @Bean
//        public LoggingUtils loggingUtils() {
//            return new LoggingUtils();
//        }
//
//        @Bean
//        public PropertyResolver propertyResolver() {
//            return new PropertyResolver();
//        }
//
//        @Bean
//        public DataSource dataSource() {
//            DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
//
//            driverManagerDataSource.setUrl(environment.getProperty(url));
//            driverManagerDataSource.setUsername(environment.getProperty(user));
//            driverManagerDataSource.setPassword(environment.getProperty(password));
//            driverManagerDataSource.setDriverClassName(environment.getProperty(driver));
//
//            return driverManagerDataSource;
//        }
//
//
//        @Bean
//        public JdbcTemplate jdbcTemplate(DataSource dataSource) {
//            return new JdbcTemplate(dataSource);
//        }
//
//        @Bean
//        public DbUtils dbUtils() {
//            return new DbUtils();
//        }
//    }
//
//    @Configuration
//    @Profile("test")
//    @PropertySource("classpath:app-test.properties")
//    public static class TestAppConfig {
//    }
//
//
//    @Bean("threadLocal")
//    public ThreadLocal<HashMap<String, Object>> threadLocal() {
//        HashMap<String, Object> hm = new HashMap<>();
//
//        ThreadLocal<HashMap<String, Object>> tl = new ThreadLocal();
//        tl.set(hm);
//
//        return tl;
//    }
//
//
////    @Bean
////    @DependsOn("threadLocal")
////    @Scope("prototype")
////    public ThreadLocalFactory threadLocalFactory() {
////        return new ThreadLocalFactory();
////    }
//
//    @Bean
//    public Yms yms() {
//        return new Yms();
//    }
//
//    @Bean
//    public Config config() {
//        return new Config();
//    }
//
//    @Bean
//    public ObjectMapper objectMapper() {
//        return new ObjectMapper();
//    }
//
//
//    @Bean
//    public PropertyResolver ymsPropertyResolver() {
//        return new PropertyResolver();
//    }
//
//    @Bean
//    public PropertyResolver envPropertyResolver() {
//        return new PropertyResolver();
//    }
//
//    @Bean
//    public JsonUtils jsonUtils() {
//        return new JsonUtils();
//    }
//
//    @Bean
//    public JavaUtils javaUtils(){
//        return new JavaUtils();
//    }
//
//
//    @Bean
//    public TextParser testParser(){
//        return new TextParser();
//    }
}
