package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "isSmallParcel", "poStatus", "fcIssues", "scIssues", "skuIssues", "vendorIssues"})
public class StatusRequest {
	
	@JsonProperty("isSmallParcel")
	private boolean isSmallParcel;
	@JsonProperty("poStatus")
	private String poStatus;
	@JsonProperty("fcIssues")
	private String fcIssues;
	@JsonProperty("scIssues")
	private String scIssues;
	@JsonProperty("skuIssues")
	private String skuIssues;
	@JsonProperty("vendorIssues")
	private String vendorIssues;
	
	@JsonProperty("isSmallParcel")
	public boolean isSmallParcel() {
		return isSmallParcel;
	}
	@JsonProperty("isSmallParcel")
	public void setSmallParcel(boolean isSmallParcel) {
		this.isSmallParcel = isSmallParcel;
	}
	@JsonProperty("poStatus")
	public String getPoStatus() {
		return poStatus;
	}
	@JsonProperty("poStatus")
	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
	@JsonProperty("fcIssues")
	public String getFcIssues() {
		return fcIssues;
	}
	@JsonProperty("fcIssues")
	public void setFcIssues(String fcIssues) {
		this.fcIssues = fcIssues;
	}
	@JsonProperty("scIssues")
	public String getScIssues() {
		return scIssues;
	}
	@JsonProperty("scIssues")
	public void setScIssues(String scIssues) {
		this.scIssues = scIssues;
	}
	@JsonProperty("skuIssues")
	public String getSkuIssues() {
		return skuIssues;
	}
	@JsonProperty("skuIssues")
	public void setSkuIssues(String skuIssues) {
		this.skuIssues = skuIssues;
	}
	@JsonProperty("vendorIssues")
	public String getVendorIssues() {
		return vendorIssues;
	}
	@JsonProperty("vendorIssues")
	public void setVendorIssues(String vendorIssues) {
		this.vendorIssues = vendorIssues;
	}
	
	
}
