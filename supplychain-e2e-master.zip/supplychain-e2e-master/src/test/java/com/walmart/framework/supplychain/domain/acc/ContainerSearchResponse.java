package com.walmart.framework.supplychain.domain.acc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "containerTagId", "containerStatusDesc" })
public class ContainerSearchResponse {

	@JsonProperty("containerTagId")
	private String containerTagId;
	@JsonProperty("containerStatusDesc")
	private String containerStatusDesc;
	
	@JsonProperty("containerTagId")
	public String getContainerTagId() {
		return containerTagId;
	}

	@JsonProperty("containerTagId")
	public void setContainerTagId(String containerTagId) {
		this.containerTagId = containerTagId;
	}

	@JsonProperty("containerStatusDesc")
	public String getContainerStatusDesc() {
		return containerStatusDesc;
	}

	@JsonProperty("containerStatusDesc")
	public void setContainerStatusDesc(String containerStatusDesc) {
		this.containerStatusDesc = containerStatusDesc;
	}
}