package com.walmart.framework.utilities.selenium;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import net.serenitybdd.core.pages.PageObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import com.walmart.framework.supplychain.constants.DRIVER_TYPE;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import spring.SpringTestConfiguration;
@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class ContextDriver extends PageObject {
	@Autowired
	ThreadLocal<HashMap<String, Object>> threadLocal;
	
	private static final Logger LOGGER = LogManager.getLogger(ContextDriver.class);
	public WebDriver getDriverInstance() {
		return getWebDriverInstance();
	}
	
	public WebDriver getWebDriverInstance() {
		
		if(isNewDriverToBeCreated(DRIVER_TYPE.WEB_DRIVER)) {
			return createWebDriver();
		}else {
			return (WebDriver) threadLocal.get().get(DRIVER_TYPE.WEB_DRIVER.getValue());
		}
		
	}
	public AndroidDriver<AndroidElement> getAppiumDriverInstance(String environment,String appPackage,String appActivity,String version,String apkDownloadPath,String appWaitActivity,String gridURL,String emulatorURL,String avd) {
		AndroidDriver<AndroidElement> driver=null;
		if(isNewDriverToBeCreated(DRIVER_TYPE.APPIUM_DRIVER)) {
			//driver=appiumDriver.getAppiumDriver();
			driver=new AppiumDriver().getMobileDriver( environment, appPackage, appActivity,version,apkDownloadPath,appWaitActivity,gridURL,emulatorURL,avd);
			boolean ismyAppInstalled=driver.isAppInstalled("com.walmart.myapps.app");
			/*if(avd.trim().equalsIgnoreCase("Galaxy_Nexus_API_26") && driver!=null) {
				//logger.info("Is My apps and wmauth app? : {}",ismyAppInstalled);
				if(!ismyAppInstalled) {
					//logger.info("Installing My apps and wmauth app : {}",ismyAppInstalled);
					driver.installApp("http://repo.wal-mart.com/content/repositories/walmart/com/walmart/logistics/platform/mobile/android/myapps-apk/1.1.2/myapps-apk-1.1.2.apk");
					driver.installApp("http://repo.wal-mart.com/content/repositories/walmart/com/walmart/platform/mobile/android/wmAuth/2.0.42/wmAuth-2.0.42.apk");
				}
			}*/

			if(threadLocal!=null&&threadLocal.get()!=null) {
				threadLocal.get().put(DRIVER_TYPE.APPIUM_DRIVER.getValue(), driver);
			}else {
				LOGGER.info("Unable to get thread local data to set the driver");
			}
			return driver;
		}else {
			LOGGER.info("Using Existing Driver");
			return (AndroidDriver<AndroidElement>) threadLocal.get().get(DRIVER_TYPE.APPIUM_DRIVER.getValue());
		}
		
	}
	
	public boolean isNewDriverToBeCreated(DRIVER_TYPE driverType ) {
		String driverKey=driverType.getValue();
		return threadLocal==null||threadLocal.get()==null||threadLocal.get().get(driverKey)==null||isDriverClosed(driverType) ;
	}
	public WebDriver createWebDriver() {
		
		WebDriver driver=getDriver();
		LOGGER.info("Created New Driver:{}",driver);
		if(threadLocal!=null&&threadLocal.get()!=null) {
			threadLocal.get().put(DRIVER_TYPE.WEB_DRIVER.getValue(), driver);
		}else {
			LOGGER.info("Unable to get thread local data to set the driver");
		}
		return driver;
	}
	public boolean isDriverClosed(DRIVER_TYPE driverType) {
		return threadLocal.get().get(driverType.getValue()).toString().contains("(null)");
	}
	
//	public AndroidDriver getMobileWebBrowserInstance() throws MalformedURLException {
//		LOGGER.info(System.getProperty("user.dir") + "/chromedriver");
//		DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability("chromedriverExecutable",System.getProperty("user.dir") + "/chromedriver");
//		capabilities.setCapability("platformName", "Android");
//		
//		capabilities.setCapability("deviceName", "emulator-5554");
//		capabilities.setCapability("udid", "emulator-5554");
////		capabilities.setCapability("deviceName", "Emulator_Catalyst");
//		capabilities.setCapability("browserName", "Chrome");
//		capabilities.setCapability("platformVersion", "8.1.0");
//		AndroidDriver mobileWebdriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
//		return mobileWebdriver;
//	}
}
