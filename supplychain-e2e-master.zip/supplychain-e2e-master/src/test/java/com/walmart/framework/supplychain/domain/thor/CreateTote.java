package com.walmart.framework.supplychain.domain.thor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "iterator", "detail"})
public class CreateTote {
	
	@JsonProperty("iterator")
	private ToteIterator iterator;
	@JsonProperty("detail")
	private ToteDetail detail;
	
	@JsonProperty("iterator")
	public ToteIterator getIterator() {
		return iterator;
	}
	@JsonProperty("iterator")
	public void setIterator(ToteIterator iterator) {
		this.iterator = iterator;
	}
	@JsonProperty("detail")
	public ToteDetail getDetail() {
		return detail;
	}
	@JsonProperty("detail")
	public void setDetail(ToteDetail detail) {
		this.detail = detail;
	}
	

}
