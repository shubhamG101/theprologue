package com.walmart.framework.supplychain.domain.witron;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "DTH"})
public class DTHDTL {
	@JsonProperty("DTH")
	private List<DTH> DTH;
	@JsonProperty("DTH")
	public List<DTH> getDTH() {
		return DTH;
	}
	@JsonProperty("DTH")
	public void setDTH(List<DTH> dTH) {
		DTH = dTH;
	}
}
