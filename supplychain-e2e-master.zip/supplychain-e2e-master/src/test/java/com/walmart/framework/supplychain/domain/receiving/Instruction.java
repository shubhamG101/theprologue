package com.walmart.framework.supplychain.domain.receiving;

import java.util.List;

public class Instruction 
{
	private String parentContainer;
	private String messageId;
	private List<String> childConatiners;
	private int receivedQty;
	public String getParentContainer() {
		return parentContainer;
	}
	public void setParentContainer(String parentContainer) {
		this.parentContainer = parentContainer;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public List<String> getChildConatiners() {
		return childConatiners;
	}
	public void setChildConatiners(List<String> childConatiners) {
		this.childConatiners = childConatiners;
	}
	public int getReceivedQty() {
		return receivedQty;
	}
	public void setReceivedQty(int receivedQty) {
		this.receivedQty = receivedQty;
	}
	
	
}
