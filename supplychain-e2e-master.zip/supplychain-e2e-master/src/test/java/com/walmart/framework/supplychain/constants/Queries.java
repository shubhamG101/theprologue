package com.walmart.framework.supplychain.constants;

import java.util.HashMap;
import java.util.Map;

public class Queries {
	Map<String, String> QueryParam = new HashMap<String, String>();

	public static final String YMS_APPOINTMENT_QUERY = "INSERT INTO dc_gate_mgr:informix.appointment (appointment_nbr, unld_pymt_type_cd, carrier_id, trailer_id, scheduled_date,scheduled_time, arrival_date, arrival_time, transport_mthd_cd, cancel_ts,gate_arrive_userid, gate_arvl_car_id, gate_arvl_trlr_id, rcvg_dock_type_cd, subcenter_id,assign_door_id, driver_unload_ind, bill_of_lading_nbr, unload_type_code, tralr_cntrl_rec_id,unload_allow_amt, unld_allw_paid_amt, allow_amt_rcpt_nbr, backhaul_ind, scheduling_dc_nbr,scheduling_dc_cntry_cd, appt_status_cd, load_id, delivery_type_code, window_arvl_ts,asn_type_code, packet_status_code, prime_slot_id, inbound_seal_nbr, paper_avail_wndw_ts,conveyor_ind, cnvy_enabled_ind, complex_trailer_ind, outed_commodity_ind, outed_commodity_amt,currency_code, door_alloc_ts, fee_type_cd, must_ship_ts, must_finalize_ts,appointment_cmt_txt, appointment_dc_nbr, tractor_nbr, create_userid, create_ts, last_change_userid, last_change_ts, lock_cnt)"
			+ " values (#del#, null, 'WMT', '#trailer#', '#date#','00:00', null, null, 1, null,null, null, null, 'DA', 2,null, 'N', '', null, null,null, null, null,'N', #dc#,'US', 3, 2018082111, 2, null,null, null, null, 'IS4372', null,'', 2 , '00252930833847156', 'N', null,null, null,null, '#dateTime#', null,null,#dc#,'2343523',"
			+ "'YMSAdmin', current, 'YMSAdmin', current, 0);";

	public static final String YMS_APPOINTMENT_PO_QUERY = "INSERT INTO dc_gate_mgr:informix.appointment_po "
			+ "(appointment_nbr, po_nbr, purch_company_id, scheduled_unit_qty, scheduled_wgt_qty,"
			+ "unit_uom_code, wgt_uom_code, vendor_nbr, vendor_name, po_event_code,"
			+ "po_bol_nbr, freight_term_cd, must_arrive_by_dt, po_type_code, po_line_cnt,"
			+ "po_dc_nbr, po_dept_nbr, po_state_of_origin_cd, po_ship_ts, po_pickup_ts,"
			+ "po_cancel_date, po_cube_qty, po_hazmat_ind, shipment_type_code, load_type_code,"
			+ "create_userid, create_ts, last_change_userid, last_change_ts, lock_cnt)\n"
			+ "values" + "(#del#, #po#, 1001, 32, 1000,\n"
			+ "null, null, 555901640, \"1-2-3 GLUTEN FREE INC\", null,"
			+ "null, 1, '#date#', 1, 1,\n" + "null, 1, null, null, null,\n"
			+ "'', 0, '', '', 1," + "'YMSAdmin', current, 'YMSAdmin', current, 0)";

	public static final String DC_FIN_PURCHASE_DATA_PARENT_CONTAINER_QUERY = "select sum(total_received_cost) from purchase_by_dc_nbr_and_posting_date where source_nbr=#source_number# and parent_ctr_trackingid='#parent_container#' ALLOW FILTERING";
	public static final String DC_FIN_DAMAGE_DATA_PARENT_CONTAINER_QUERY = "select sum(total_adjusted_cost) from inv_adjust_by_dc_nbr_and_posting_date where source_nbr=#source_number# and parent_cntnr_tracking_id='#parent_container#' ALLOW FILTERING";
	public static final String DC_FIN_PURCHASE_DATA_PARENT_CONTAINER_QUERY_ATLAS = "select sum(total_received_cost) from purchase_by_dc_nbr_and_posting_date where source_nbr=#source_number# AND parent_ctr_trackingid='#child_container#' ALLOW FILTERING";
	public static final String DC_FIN_PURCHASE_DATA_CHILD_CONTAINER_QUERY = "select sum(total_received_cost) from purchase_by_dc_nbr_and_posting_date where child_cntr_tracking_id='#child_container#' ALLOW FILTERING";
	public static final String DC_FIN_SALE_DATA = "	select  SUM(total_sales_cost) from sales_by_dc_nbr_and_posting_date where source_cc='US' and ending_inv_sales_date >= '#startDate#' and ending_inv_sales_date<='#endDate#' and trans_load_id='#tmsId#' ALLOW FILTERING";
	public static final String DC_FIN_GDIS_QUERY = "select qty_in_eaches from wmt_dc_financials.dbo.po_line_qty where po_num = '#poNumber#' AND delivery_nbr = '#deliveryNumber#' and item_nbr = '#itemNumber#';";
	public static final String DC_FIN_OSDR_QUERY = "select * from receiver_number_detail where delivery_number = '#deliveryNumber#' and po_number = '#poNumber#'";
	public static final String DC_FIN_PURCHASE_DATA_PO_ITEM_THOR = "select sum(total_received_cost) from purchase_by_dc_nbr_and_posting_date where po_doc_id='#po_number#' and wmt_item_nbr='#item_number#' and source_nbr=#src_number# ALLOW FILTERING";
	public static final String DC_FIN_SALE_DATA_THOR = "select SUM(total_sales_cost) from sales_by_dc_nbr_and_posting_date where source_cc='US' and wm_item_nbr='#item_number#' and source_nbr=#src_number# ALLOW FILTERING";
	public static final String DC_FIN_ADJUSTMENT_THOR = "select sum(total_adjusted_cost) from inv_adjust_by_dc_nbr_and_posting_date where wmt_item_nbr='#itemNumber#' and adjusted_reason_code='#adjustment_code#' and source_nbr=#src_number# ALLOW FILTERING";
	public static final String DC_FIN_OSDR_QUERY_THOR = "select original_payload from gdis_delivery_finalization where delivery_nbr='#delivery_number#' ALLOW FILTERING";
	public static final String DC_FIN_SALES_DATA_THOR = "select * from sales_by_dc_nbr_and_posting_date where source_nbr=6086 and source_cc='US' and wm_item_nbr='#itemNbr#' ALLOW FILTERING";
	public static final String DC_FIN_ADJUSTMENT_DATA_THOR = "select * from inv_adjust_by_dc_nbr_and_posting_date where source_nbr=6086 and source_cc='US' and wmt_item_nbr='#itemNbr#' ALLOW FILTERING";
	public static final String DC_FIN_ITEM_DATA_CLEAN = "delete from purchase_item_details where wmt_item_nbr='#itemNumber#' and source_nbr=#sourceNumber# and source_cc='#source_CC#'";
	public static final String DC_FIN_PO_DATA_CLEAN = "delete from oms_po_data where po_doc_id='#poNumber#' and source_nbr=#sourceNumber# and source_cc='#source_CC#'";
	
	//Witron cassendra
	
	public static final String WITRON_DC_FIN_PURCHASE_DATA_PO_ITEM = "select * from purchase_by_dc_nbr_and_posting_date where po_doc_id='#po_number#' and po_line_nbr='#line_nbr#' and parent_ctr_trackingid='#container#' ALLOW FILTERING";
	public static final String WITRON_DC_FIN_GDIS = "select * from gdis_pol_qty where po_num='#po_number#' and po_line_num=#line_nbr# ALLOW FILTERING";
	public static final String WITRON_DC_FIN_PO_LINE_CLOSURE = "select * from po_lines_closure_meta_data where po_num='#po_number#' and po_line_num=#line_nbr# ALLOW FILTERING";
	public static final String WITRON_DC_FIN_VTR_PURCHASE_DATA = "select * from purchase_by_dc_nbr_and_posting_date where transaction_type='#transaction#' and parent_ctr_trackingid='#container#' ALLOW FILTERING";
	public static final String WITRON_DC_FIN_ADJUSTMENT = "select * from inv_adjust_by_dc_nbr_and_posting_date where parent_cntnr_tracking_id='#container#' and adjusted_qty=#qty# and adjusted_reason_code='#adjustmentcode#' ALLOW FILTERING";
	public static final String WITRON_DC_FIN_SALES_DATA = "select * from sales_by_dc_nbr_and_posting_date where wm_item_nbr='#wm_item_nbr#' and invoice_nbr='#invoice_nbr#' and inventory_type='#inventory_type#' ALLOW FILTERING";
	
	public static final String LIST_OF_LOADS_AND_DOOR = "select loc.wm_location_name,load.load_id,load.load_create_ts from gls_shipping:load as load inner join gls_shipping:load_door as load_door on load.load_id=load_door.load_id inner join gls_shipping:wm_location as loc on load_door.door_id=loc.wm_location_id where loc.wm_location_name in (#doors#) order by load.load_create_ts;";
	// Loading Cleanup queries
	public static final String QUERY_SELECT_SHIPPING_CONTAINER = "select shipping_container_id from gls_shipping:informix.load_shipment as ls join gls_shipping:informix.container_shipment as cs on ls.shipment_id=cs.shipment_id and ls.load_id='#load_id#'";
	public static final String QUERY_SELECT_LOAD_SEAL = "select seal_id from gls_shipping:informix.seal_load where load_id='#load_id#'";
	public static final String QUERY_SELECT_LOAD_DOOR = "select load_id from gls_shipping:informix.load_door where door_id in (select wm_location_id from gls_shipping:informix.wm_location where wm_location_name='#door_id#')";
	public static final String QUERY_DELETE_CONTAINER_ACTIVITY = "delete from gls_shipping:informix.container_activity where shipping_container_id in (#shipping_container_id#)";
	public static final String QUERY_DELETE_CONTAINER_ACTIVITY_BY_LOAD = "delete from gls_shipping:informix.container_activity where load_id='#load_id#'";
	public static final String QUERY_DELETE_LOAD_CONTAINER_MAP = "delete from gls_shipping:informix.load_container_map where load_id='#load_id#'";
	public static final String QUERY_DELETE_SHIPPING_CONTAINER = "delete from gls_shipping:informix.shipping_container where shipping_container_id in (#shipping_container_id#)";
	public static final String QUERY_DELETE_CONTAINER_SHIPMENT = "delete from gls_shipping:informix.container_shipment where shipping_container_id in (#shipping_container_id#)";
	public static final String QUERY_DELETE_LOAD_PLAN = "delete from gls_shipping:informix.load_plan where load_id='#load_id#'";
	public static final String QUERY_DELETE_ROUTING_NBR = "delete from gls_shipping:informix.routing_release where routing_release_nbr in (select routing_release_nbr from gls_shipping:informix.load where load_id='#load_id#' )";
	public static final String QUERY_DELETE_LOAD_SEAL = "delete from gls_shipping:informix.seal_load where load_id='#load_id#'";
	public static final String QUERY_DELETE_SEAL = "delete from gls_shipping:informix.seal where seal_id =#seal_id#";
	public static final String QUERY_DELETE_LOAD_DOOR = "delete from gls_shipping:informix.load_door where load_id='#load_id#'";
	public static final String QUERY_DELETE_LOAD_ACTIVITY = "delete from gls_shipping:informix.load_activity where load_id='#load_id#'";
	public static final String QUERY_DELETE_LOAD_SHIPMENT = "delete from gls_shipping:informix.load_shipment where load_id = '#load_id#'";
	public static final String QUERY_DELETE_LOAD = "delete from gls_shipping:informix.load where load_id = '#load_id#'";

	// OP Cleanup queries
	public static final String DELETE_WHSE_ORDER = "delete from order_mgr:whse_order where item_nbr='#item_number#'";
	public static final String DELETE_ITEM_DEL_OM = "delete from order_mgr:po_item_dlvr  where item_nbr='#item_number#'";
	public static final String DELETE_ALLOC_ORDER = "delete from order_alloc:alloc_order  where item_nbr='#item_number#'";
	public static final String DELETE_ITEM_DEL_OA = "delete from order_alloc:po_item_delivery where item_nbr='#item_number#'";
	public static final String DELETE_OPR = "delete from order_track:order_pick_reference opr where opr.item_nbr='#item_number#' and opr.enrich_order_id in (select enrich_order_id from order_track:enrich_order_reference eor where eor.item_nbr='#item_number#')";
	public static final String DELETE_EOR = "delete from order_track:enrich_order_reference eor where eor.item_nbr='#item_number#'";
	
	public static final String DELETE_THOR_PURCHASE_DATA = "delete from purchase_by_dc_nbr_and_posting_date where wmt_item_nbr='#itemNbr#' ALLOW FILTERING";
	public static final String DELETE_THOR_ADJUSTMENTS_DATA = "delete from inv_adjust_by_dc_nbr_and_posting_date where wmt_item_nbr='#itemNbr#' ALLOW FILTERING";
	public static final String DELETE_THOR_SALES_DATA = "delete from sales_by_dc_nbr_and_posting_date where source_nbr=#source_nbr# and source_cc='#source_cc#' and ending_inv_sales_date ='#ending_inv_sales_date#' and dept_nbr=#dept_nbr# and sales_unique_id='#sales_unique_id#'";
	public static final String DELETE_THOR_ADJUSTMENT_DATA = "delete from inv_adjust_by_dc_nbr_and_posting_date where source_nbr=#source_nbr# and source_cc='#source_cc#' and ending_inv_adjust_date ='#ending_inv_adjust_date#' and dept_nbr=#dept_nbr# and inv_adjust_unique_id='#inv_adjust_unique_id#'";
	
}
